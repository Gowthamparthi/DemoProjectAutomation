package com.rallio.automation.api.test;
import static com.rallio.automation.common.manager.ConfigManager.getValue;

import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.rallio.automation.api.newrallio.NewRallioAPI;
import com.rallio.automation.api.newrallio.NewRallioAPITestBase;
import com.rallio.automation.common.enums.Steps;
import com.rallio.automation.common.testng.CustomReport;
import com.rallio.automation.common.util.LogUtil;
import com.rallio.automation.core.listener.AutomationListener;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

// TODO: Auto-generated Javadoc
/**
 * The Class NewRallioStageDeleteFunctionality.
 */
@Listeners({ CustomReport.class, AutomationListener.class })
public class NewRallioStageDeleteFunctionalityTest extends NewRallioAPITestBase {
	
    /** The token. */
    private String token;

	/** The account id. */
	private String franchisorId, accountId;

    
   /**
    * Validate login API.
    *
    * @throws Exception the exception
    */
   @BeforeTest()

   public void validateLoginAPI() throws Exception {
		String environment = System.getProperty("env");
		if (environment.equals("stg")) {
			LogUtil.log(Steps.START, "Validate Login API");
			Map<String, Object> loginMap = NewRallioAPI.login(getNewRallioBrandUser());
			String apiResponseCode = (String) loginMap.get("responseCode");
			Assert.assertEquals(apiResponseCode, "200");
			token = (String) loginMap.get("tokenId");
			accountId = (String) loginMap.get("accountId");
			Assert.assertNotNull(token, "Token cannot be Null.");
			// NewRallioAPI.getAccountSwitcher(token, "1");

		} else
			LogUtil.log(Steps.START,
					"You're given " + environment + " as a environent, please provide 'stg' environent.");
	}

   @Test(priority = 1)
   public void contentTabPostPageDeletePost() throws Exception {

      LogUtil.log(Steps.START, "Delete The TestPosts");
       Assert.assertTrue((deletePosts(token, "testPost", 12)), "No Total Post found");
   }


   /**
    * Delete test posts.
    *
    * @throws Exception the exception
    */
   public boolean deletePosts(String token, String searchterm, int numToDelete) {
       
       /*String getUrl = "https://rallio-staging.herokuapp.com/activate_local_api/content_summaries?per=12&text=test&status_id[]=3&only_available_and_boosted=0&sent_to_franchisor=1&franchisor_id=2&not_blank=1";
       String deleteUrl = "https://rallio-staging.herokuapp.com/activate_local_api/contents/";
      */ int TotalPostDeleted = 0;
       
       RestAssured.baseURI = getValue("postPageDeleteGetUrl");    
       Response response = RestAssured.given().header("X-Rallio-API-Key", token).contentType("Application/json")
               .header("Content-Type", "application/json").queryParam("per", numToDelete)
               .queryParam("text", searchterm).queryParam("status_id[]", "3")
               .queryParam("only_available_and_boosted", "0").queryParam("after", " ")
               .queryParam("sent_to_franchisor", "1").queryParam("franchisor_id", "2").queryParam("after", "1149067")
               .queryParam("not_blank", "1").when().get(" ");
       if (response.getStatusCode() == 200) {
           JsonPath jsonPath = new JsonPath(response.getBody().asString());
           List<Integer> contentIdList = jsonPath.getList("content_summaries.content_id");
           LogUtil.log(Steps.START, "contentId is:" + contentIdList);
          for (Integer contentId : contentIdList) {
               RestAssured.baseURI = getValue("postPageDeleteUrl");
               String body = "{\"content\":{\"delete_descendants\":\"1\",\"delete_remote_posts\":\"1\"}}";
               RequestSpecification Request = RestAssured.given().header("X-Rallio-API-Key", token)
                       .header("Content-Type", "application/json");
               Response res = Request.body(body).put(contentId + "/mass_delete");
               Assert.assertEquals(res.getStatusCode(), 200);
               LogUtil.log(Steps.START, "status code is:" + res.getStatusCode());
               TotalPostDeleted++;
           }
       } else {
           LogUtil.log(Steps.START, "Get status code is: " + response.getStatusCode());
           LogUtil.log(Steps.START, "Get Method is Not Successful");
       }
          Assert.assertTrue((numToDelete == TotalPostDeleted));
	return true;
	
	
   }

}
	

	
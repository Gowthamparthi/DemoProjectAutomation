package com.rallio.automation.api.test;

import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.rallio.automation.api.enums.LeaderBoardListType;
import com.rallio.automation.api.enums.PostsTypeEnum;
import com.rallio.automation.api.enums.RewardProgramsTypeEnum;
import com.rallio.automation.api.rallioactivate.RallioAPITestBase;
import com.rallio.automation.api.rallioactivate.RallioActivateAPI;
import com.rallio.automation.api.util.DateRangeUtil;
import com.rallio.automation.business.enums.AccountType;
import com.rallio.automation.business.enums.DateRange;
import com.rallio.automation.business.rallioActivate.entity.AccountSwticher;
import com.rallio.automation.business.rallioActivate.entity.AdvocacyPosts;
import com.rallio.automation.business.rallioActivate.entity.Assets;
import com.rallio.automation.business.rallioActivate.entity.AssetsSubmitted;
import com.rallio.automation.business.rallioActivate.entity.BrandAndHubs;
import com.rallio.automation.business.rallioActivate.entity.CommunityManagementAdvocatesData;
import com.rallio.automation.business.rallioActivate.entity.CommunityManagementStatsData;
import com.rallio.automation.business.rallioActivate.entity.Contents;
import com.rallio.automation.business.rallioActivate.entity.EngagementFromAssets;
import com.rallio.automation.business.rallioActivate.entity.FavouriteTags;
import com.rallio.automation.business.rallioActivate.entity.Franchisors;
import com.rallio.automation.business.rallioActivate.entity.ListOfLocations;
import com.rallio.automation.business.rallioActivate.entity.MonthlyPostMetrics;
import com.rallio.automation.business.rallioActivate.entity.PostMetrics;
import com.rallio.automation.business.rallioActivate.entity.PostsStats;
import com.rallio.automation.business.rallioActivate.entity.PromotionList;
import com.rallio.automation.business.rallioActivate.entity.RecentPost;
import com.rallio.automation.business.rallioActivate.entity.RewardProgram;
import com.rallio.automation.business.rallioActivate.entity.RewardProgramDetails;
import com.rallio.automation.business.rallioActivate.entity.RewardProgramStats;
import com.rallio.automation.business.rallioActivate.entity.SavedPosts;
import com.rallio.automation.business.rallioActivate.entity.Tags;
import com.rallio.automation.business.rallioActivate.entity.TotalAssetsStats;
import com.rallio.automation.business.rallioActivate.entity.TotalMetrics;
import com.rallio.automation.business.rallioActivate.entity.TotalScore;
import com.rallio.automation.business.rallioActivate.entity.User;
import com.rallio.automation.common.enums.Steps;
import com.rallio.automation.common.testng.CustomReport;
import com.rallio.automation.common.util.LogUtil;
import com.rallio.automation.core.listener.AutomationListener;

import io.restassured.response.Response;

// TODO: Auto-generated Javadoc
/**
 * The Class RalioActivateApiTest.
 */
@Listeners({ CustomReport.class, AutomationListener.class })
public class RallioActivateApiTest extends RallioAPITestBase {

	/** The franchisor id. */
	private String token, franchisorId, accountId;

	/** The user. */
	private User user;

	/**
	 * Login API.
	 *
	 * @throws Exception the exception
	 */
	@BeforeTest()
	public void validateLoginAPI() throws Exception {

		LogUtil.log(Steps.START, "Validate Login API");
		Map<String, Object> loginMap = RallioActivateAPI.login(getRallioActivateUser());
		String apiResponseCode = (String) loginMap.get("responseCode");
		Assert.assertEquals(apiResponseCode, "200");
		token = (String) loginMap.get("tokenId");
		franchisorId = (String) loginMap.get("franchisorId");
		user = (User) loginMap.get("user");
		Assert.assertNotNull(token, "Token cannot be Null.");
		accountId = String.valueOf(RallioActivateAPI.getAccountSwitcher(token, franchisorId).getAccounts().get(0).getId());

	}

	/**
	 * Gets the franchisor details.
	 *
	 * @return the franchisor details
	 * @throws Exception the exception
	 */
	@Test(priority = 1, enabled = false)
	public void validateFranchisorDetails() throws Exception {

		LogUtil.log(Steps.START, "Validate FranchisorDetails API Test");
		Franchisors franchisors = RallioActivateAPI.getFranchisorDetails(token, franchisorId);
		Assert.assertEquals(String.valueOf(franchisors.getId()), franchisorId, "Invalid FranchisorId Found");

	}

	/**
	 * Rallio_TC_2.2 - Gets the location list.
	 *
	 * @return the location list
	 * @throws Exception the exception
	 */
	@Test(priority = 2)
	public void validateLocationList() throws Exception {

		LogUtil.log(Steps.START, "Validate LocationList API");
		ListOfLocations listOfLocations = RallioActivateAPI.getLocationList(token, franchisorId);
		Assert.assertTrue(listOfLocations.getAccounts().size() > 0, "No Location List Found");

	}

	/**
	 * Rallio_TC_2.2 - Gets the total metrics.
	 *
	 * @return the total metrics
	 * @throws Exception the exception
	 */
	@Test(priority = 3)
	public void validateTotalMetrics() throws Exception {

		LogUtil.log(Steps.START, "Validate TotalMetrics API");
		String date = DateRangeUtil.getTimeStamp(DateRange.YEAR_TO_DATE);
		TotalMetrics totalMetrics = RallioActivateAPI.getTotalMetrics(token, AccountType.FRANCHISOR, franchisorId, date);
		Assert.assertTrue(totalMetrics.getUsers_count() > 0, "No Total Users Count Found.");
	}

	/**
	 * Rallio_TC_2.2 - Gets the post metrics.
	 *
	 * @return the post metrics
	 * @throws Exception the exception
	 */
	@Test(priority = 4)
	public void validatePostMetrics() throws Exception {

		LogUtil.log(Steps.START, "Validate PostMetrics API");
		PostMetrics postMetrics = RallioActivateAPI.getPostMetrics(token, franchisorId, AccountType.FRANCHISOR);
		Assert.assertTrue(postMetrics.getPosts_count() != null, "No Posts Found");
	}

	/**
	 * Rallio_TC_2.2 - Gets the monthly post metrics.
	 *
	 * @return the monthly post metrics
	 * @throws Exception the exception
	 */
	@Test(priority = 5)
	public void validateMonthlyPostMetrics() throws Exception {

		LogUtil.log(Steps.START, " Validate MonthlyPost API");
		MonthlyPostMetrics monthlyPostMetrics = RallioActivateAPI.getMonthlyPostMetrics(token, franchisorId);
		Assert.assertTrue(monthlyPostMetrics.getTotal_posts_result().size() > 0, "No Total Posts Found.");
	}

	/**
	 * Rallio_TC_2.2 - Gets the recent posts.
	 *
	 * @return the recent posts
	 * @throws Exception the exception
	 */
	@Test(priority = 6)
	public void validateRecentPosts() throws Exception {

		LogUtil.log(Steps.START, "Validate RecentPosts API");
		List<RecentPost> recentPosts = RallioActivateAPI.getRecentPosts(token, franchisorId);
		Assert.assertTrue(recentPosts.size() > 0, "No Recent Posts Found.");

	}

	/**
	 * Gets the tags.
	 *
	 * @return the tags
	 * @throws Exception the exception
	 */
	@Test(priority = 7, enabled = false)
	public void validateTags() throws Exception {

		LogUtil.log(Steps.START, " Validate Tags API");
		List<Tags> tags = RallioActivateAPI.getTags(token);
		Assert.assertTrue(tags.size() > 0, "No Tags Found.");

	}

	/**
	 * Rallio_TC_6.2 - Gets the reward programs.
	 *
	 * @return the reward programs
	 * @throws Exception the exception
	 */
	@Test(priority = 8)
	public void validateGetAllRewardPrograms() throws Exception {

		LogUtil.log(Steps.START, "Validate RewardPrograms API");
		List<RewardProgramDetails> rewardProgramDetails = RallioActivateAPI.getAllRewardPrograms(token, franchisorId);
		Assert.assertTrue(rewardProgramDetails.size() > 0, "No ProgramDetails Found");
	}

	/**
	 * Gets the account switcher.
	 *
	 * @return the account switcher
	 * @throws Exception the exception
	 */
	@Test(priority = 9, enabled = false)
	public void validateAccountSwitcher() throws Exception {

		LogUtil.log(Steps.START, "Validate AccountSwitcher API");
		AccountSwticher accountSwticher = RallioActivateAPI.getAccountSwitcher(token, franchisorId);
		Assert.assertEquals(String.valueOf(accountSwticher.getCurrent_account_or_franchisor().getId()), franchisorId, "No FranchisorID Found.");
		Assert.assertEquals(accountSwticher.getCurrent_name(), accountSwticher.getCurrent_account_or_franchisor().getName(), "Account Name not matched");

	}

	/**
	 * Filter rewards program.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 10, enabled = false)
	public void filterRewardsProgram() throws Exception {

		LogUtil.log(Steps.START, "FilterRewards API Test");
		Response response = RallioActivateAPI.filterRewardsProgram(token, franchisorId, RewardProgramsTypeEnum.ALL);
		Assert.assertEquals(response.getStatusCode(), 200);
		Assert.assertTrue(getStringObject(response, "status").equals("success"), "No Filtered Reward Programs Found.");

	}

	/**
	 * Gets the favourite tags.
	 *
	 * @return the favourite tags
	 * @throws Exception the exception
	 */
	@Test(priority = 11, enabled = false)
	public void validateFavouriteTags() throws Exception {

		LogUtil.log(Steps.START, "Validate FavouriteTags API");
		List<FavouriteTags> listOfTags = RallioActivateAPI.getFavouriteTags(token, franchisorId);
		// Assert.assertTrue(listOfTags.size() > 0, "No Tags Found.");

	}

	/**
	 * Rallio_TC_6.2 - Search reward program page.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 12)
	public void validateSearchRewardProgramPage() throws Exception {

		LogUtil.log(Steps.START, "Validate SearchRewards Program API");
		Response response = RallioActivateAPI.searchRewardProgramPage(token, franchisorId, "Test", RewardProgramsTypeEnum.REWARD_PROGRAMS_ONLY);
		Assert.assertEquals(response.statusCode(), 200);
		Assert.assertTrue(getStringObject(response, "status").equals("success"), "No Searched Rewards Programs Found.");

	}

	/**
	 * Filter post page.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 13, enabled = false)
	public void validateFilterPostPage() throws Exception {

		LogUtil.log(Steps.START, "Validate FilterPost API");
		Response response = RallioActivateAPI.filterPostPage(token, franchisorId, PostsTypeEnum.PUBLISHED);
		Assert.assertEquals(response.statusCode(), 200);
		Assert.assertTrue(getListObject(response, "contents").size() > 0, "No Filtered Posts Found.");

	}

	/**
	 * Post page list view contents.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 14, enabled = false)
	public void validatePostPageListViewContents() throws Exception {

		LogUtil.log(Steps.START, "Validate PostPageListView Components API");
		Response response = RallioActivateAPI.postPageListViewContents(token, franchisorId);
		Assert.assertEquals(response.statusCode(), 200);
		Assert.assertTrue(getListObject(response, "contents").size() > 0, "No Filtered Posts Found.");
	}

	/**
	 * Rallio_TC_3.2 - Gets the content stats.
	 *
	 * @return the content stats
	 * @throws Exception the exception
	 */
	@Test(priority = 15)
	public void validateContentStats() throws Exception {

		LogUtil.log(Steps.START, "Validate ContentStats API");
		PostsStats postsStats = RallioActivateAPI.getContentStats(token, franchisorId);
		Assert.assertTrue(postsStats.getTotal_posts() > 0, "No Total Post found");
	}

	/**
	 * Gets the post stats.
	 *
	 * @return the post stats
	 * @throws Exception the exception
	 */
	@Test(priority = 16, enabled = false)
	public void validatePostStats() throws Exception {

		LogUtil.log(Steps.START, "Validate PostStats API");
		PostsStats postsStats = RallioActivateAPI.getPostStats(token, accountId);
		Assert.assertTrue(postsStats.getTotal_posts() > 0, "No Total Post found");
	}

	/**
	 * Gets the saved posts.
	 *
	 * @return the saved posts
	 * @throws Exception the exception
	 */
	@Test(priority = 17, enabled = false)
	public void validateSavedPosts() throws Exception {

		LogUtil.log(Steps.START, "Validate SavedPosts API");
		List<SavedPosts> savedPosts = RallioActivateAPI.getSavedPosts(token, accountId);
		Assert.assertTrue(savedPosts.size() > 0, "No Saved Posts Found.");
	}

	/**
	 * Rallio_TC_4.2 - Validate assets stats.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 19)
	public void validateAssetsStats() throws Exception {

		LogUtil.log(Steps.START, "Validate AssetsStats API");
		TotalAssetsStats totalAssetsStats = RallioActivateAPI.getTotalAssetsStats(franchisorId, token);
		Assert.assertEquals(totalAssetsStats.getTotal_assets(), totalAssetsStats.getTotal_photos() + totalAssetsStats.getTotal_videos(), "Total Assets Count not matched");

	}

	/**
	 * Rallio_TC_6.2 - Validate reward program stats.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 20)
	public void validateRewardProgramStats() throws Exception {

		LogUtil.log(Steps.START, "Validate RewardProgram Stats API");
		RewardProgramStats rewardProgramStats = RallioActivateAPI.getRewardProgramStats(AccountType.FRANCHISOR, franchisorId, token);
		Assert.assertEquals(rewardProgramStats.getTotalPageCount(), rewardProgramStats.getReward_program_count() + rewardProgramStats.getRecommended_program_count(),
		        "Reward Program Stats Count not matched");
	}

	/**
	 * Validate brand and hub.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 21, enabled = false)
	public void validateBrandAndHub() throws Exception {

		LogUtil.log(Steps.START, "Validate BrandHubsLocation API");
		BrandAndHubs brandAndHubs = RallioActivateAPI.getBrandAndHubs(accountId, token, AccountType.LOCATION);
		Assert.assertEquals(accountId, String.valueOf(brandAndHubs.getAccounts().get(0).getId()), "Account Id Not Matched");
		brandAndHubs = RallioActivateAPI.getBrandAndHubs(franchisorId, token, AccountType.FRANCHISOR);
		Assert.assertEquals(franchisorId, String.valueOf(brandAndHubs.getFranchisors().get(0).getId()), "Franchisor Id Not Matched");

	}

	/**
	 * Rallio_TC_4.2 - Validate get all assets.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 22)
	public void validategetAllAssets() throws Exception {

		LogUtil.log(Steps.START, "Validate Get All Assets API");
		List<Assets> assets = RallioActivateAPI.getAllAssets(franchisorId, token);
		Assert.assertTrue(assets.size() > 0, "No Assets Found");
	}

	/**
	 * Rallio_TC_3.2 - Validate get all contents.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 23)
	public void validategetAllContents() throws Exception {

		LogUtil.log(Steps.START, "Validate Get All Contents API");
		List<Contents> contents = RallioActivateAPI.getAllContents(franchisorId, token);
		Assert.assertTrue(contents.size() > 0, "No Contents Found");
	}

	/**
	 * Validate get specific content.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 24, enabled = false)
	public void validategetSpecificContent() throws Exception {

		LogUtil.log(Steps.START, "Validate Get Specific Content API");
		List<Contents> contents = RallioActivateAPI.getAllContents(franchisorId, token);
		Assert.assertTrue(contents.size() > 0, "No Contents Found");
		Contents content = RallioActivateAPI.getSpecificContent(franchisorId, token, contents.get(0).getId());
		Assert.assertEquals(content.getId(), contents.get(0).getId(), "Content Id Not Matched");
	}

	/**
	 * Validate get specific asset.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 25, enabled = false)
	public void validategetSpecificAsset() throws Exception {

		LogUtil.log(Steps.START, "Validate Get Specific Asset API");
		List<Assets> assets = RallioActivateAPI.getAllAssets(franchisorId, token);
		Assert.assertTrue(assets.size() > 0, "No Assets Found");
		Assets asset = RallioActivateAPI.getSpecificAsset(franchisorId, token, assets.get(0).getId(), assets.get(0).getMedia_type());
		Assert.assertEquals(asset.getId(), assets.get(0).getId(), "Assets Id not matched");
		Assert.assertEquals(asset.getMedia_type(), assets.get(0).getMedia_type(), "MediaType not matched");
		Assert.assertEquals(asset.getName(), assets.get(0).getName(), "Media Name not matched");
	}

	/**
	 * Validate get specific reward programs.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 26, enabled = false)
	public void validateGetSpecificRewardProgram() throws Exception {

		LogUtil.log(Steps.START, "Validate Get Specific RewardProgram API");
		List<RewardProgramDetails> rewardProgramDetails = RallioActivateAPI.getAllRewardPrograms(token, franchisorId);
		Assert.assertTrue(rewardProgramDetails.size() > 0, "No RewardProgram Found");
		RewardProgram rewardProgram = RallioActivateAPI.getRewardProgram(franchisorId, token, rewardProgramDetails.get(0).getProgramId());
		Assert.assertEquals(rewardProgram.getProgramDetails().getProgramId(), rewardProgramDetails.get(0).getProgramId(), "RewardProgram Id Not Matched");

	}

	/*
	 * @Test(priority = 27) public void validateGetAchieversList() throws
	 * Exception {
	 * 
	 * int id = 892; LogUtil.log(Steps.START, "Validate Get AchieversList API");
	 * List<RewardProgramDetails> rewardProgramDetails =
	 * RallioActivateAPI.getAllRewardPrograms(token, franchisorId);
	 * Assert.assertTrue(rewardProgramDetails.size() > 0,
	 * "No RewardProgram Found"); //int id =
	 * rewardProgramDetails.get(0).getProgramId(); List<AchieversList>
	 * achieversList = RallioActivateAPI.getAchieversList(token, id);
	 * Assert.assertEquals(id,
	 * achieversList.get(0).getProgramId(),"Program Id Not Matched"); }
	 */

	/**
	 * Rallio_TC_6.2 - Validate promotion vault.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 28)
	public void validatePromotionVault() throws Exception {

		LogUtil.log(Steps.START, "Validate Promotion Vault API");
		String bearerToken = RallioActivateAPI.getStripeSession();
		PromotionList promotionList = RallioActivateAPI.getPromotionList(bearerToken);
		Assert.assertEquals(promotionList.getResults_count(), promotionList.getData().size(), "Promotion Count not matched");;
	}

	/*
	 * @Test(priority = 29) public void validateCreditCards() throws Exception {
	 * 
	 * LogUtil.log(Steps.START, "Validate Credit Cards API"); List<CreditCard>
	 * creditCard = RallioActivateAPI.getCreditCards(token, user.getEmail());
	 * Assert.assertTrue(creditCard.size() > 0, "Credit cards not found"); }
	 */

	/**
	 * Rallio_TC_7.2 - Validate community management stats.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 30)
	public void validateCommunityManagementStats() throws Exception {

		LogUtil.log(Steps.START, "Validate Community Management stats API");
		CommunityManagementStatsData communityManagementStats = RallioActivateAPI.getCommunityManagementStats(token, franchisorId);
		Assert.assertNotEquals(communityManagementStats, null, "CommunityManagement statsData not received");
	}

	/**
	 * Rallio_TC_7.2 - Validate community management advocates list.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 31)
	public void validateCommunityManagementAdvocatesList() throws Exception {

		LogUtil.log(Steps.START, "Validate Community Management advocates list API");
		List<CommunityManagementAdvocatesData> advocatesList = RallioActivateAPI.getCommunityManagementAdvocatesList(token, franchisorId);
		Assert.assertNotEquals(advocatesList, null, "CommunityManagement advocates data not received");
	}

	/**
	 * Rallio_TC_5.2 - Validate leader board filter assets submitted.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 32)
	public void validateLeaderBoardFilterAssetsSubmitted() throws Exception {

		LogUtil.log(Steps.START, "Validate LeaderBoard Assets Submitted API");
		String date = DateRangeUtil.getTimeStamp(DateRange.MONTH_TO_DATE);
		AssetsSubmitted assets = RallioActivateAPI.filterLeaderBoardAssetsSubmitted(token, AccountType.FRANCHISOR, franchisorId, date, LeaderBoardListType.LOCATION);
		Assert.assertNotNull(assets, "No Assets Found");
	}

	/**
	 * Rallio_TC_5.2 - Validate leader board filter engagement from assets.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 33)
	public void validateLeaderBoardFilterEngagementFromAssets() throws Exception {

		LogUtil.log(Steps.START, "Validate LeaderBoard Engagement From Assets API");
		String date = DateRangeUtil.getTimeStamp(DateRange.MONTH_TO_DATE);
		EngagementFromAssets assets = RallioActivateAPI.filterLeaderBoardEngagementFromAssets(token, AccountType.FRANCHISOR, franchisorId, date, LeaderBoardListType.LOCATION);
		Assert.assertNotNull(assets, "No Assets Found");
	}

	/**
	 * Rallio_TC_5.2 - Validate leader board filter advocacy posts.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 34)
	public void validateLeaderBoardFilterAdvocacyPosts() throws Exception {

		LogUtil.log(Steps.START, "Validate LeaderBoard Advocacy posts API");
		String date = DateRangeUtil.getTimeStamp(DateRange.MONTH_TO_DATE);
		AdvocacyPosts assets = RallioActivateAPI.filterLeaderBoardAdvocacyPosts(token, AccountType.FRANCHISOR, franchisorId, date, LeaderBoardListType.LOCATION);
		Assert.assertNotNull(assets, "No Assets Found");
	}

	/**
	 * Rallio_TC_5.2 - Validate leader board filter total score.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 35)
	public void validateLeaderBoardFilterTotalScore() throws Exception {

		LogUtil.log(Steps.START, "Validate LeaderBoard Total score API");
		String date = DateRangeUtil.getTimeStamp(DateRange.MONTH_TO_DATE);
		TotalScore assets = RallioActivateAPI.filterLeaderBoardTotalScore(token, AccountType.FRANCHISOR, franchisorId, date, LeaderBoardListType.LOCATION);
		Assert.assertNotNull(assets, "No Assets Found");
	}

	/**
	 * Log out.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 36, enabled = false)
	public void validateLogOut() throws Exception {

		LogUtil.log(Steps.START, "Validate LogOut API");
		Response response = RallioActivateAPI.logOut(token);
		Assert.assertEquals(response.getStatusCode(), 200);

	}
}

package com.rallio.automation.api.test;

import java.util.*;

import org.testng.*;
import org.testng.annotations.*;

import com.rallio.automation.api.newrallio.*;
import com.rallio.automation.api.util.*;
import com.rallio.automation.bussiness.newRallio.entity.*;
import com.rallio.automation.common.enums.*;
import com.rallio.automation.common.testng.*;
import com.rallio.automation.common.util.*;
import com.rallio.automation.core.listener.*;

// TODO: Auto-generated Javadoc
/**
 * The Class NewRallioApiTest.
 */
@Listeners({ CustomReport.class, AutomationListener.class })
public class NewRallioApiTest extends NewRallioAPITestBase {

	/** The account id. */
	private String token, accountId;

	/**
	 * Validate login API.
	 *
	 * @throws Exception the exception
	 */
	@BeforeTest()
	public void validateLoginAPI() throws Exception {

		LogUtil.log(Steps.START, "Validate Login API");
		Map<String, Object> loginMap = NewRallioAPI.login(getNewRallioUser());
		String apiResponseCode = (String) loginMap.get("responseCode");
		Assert.assertEquals(apiResponseCode, "200");
		token = (String) loginMap.get("tokenId");
		accountId = (String) loginMap.get("accountId");
		Assert.assertNotNull(token, "Token cannot be Null.");
		NewRallioAPI.getAccountSwitcher(token, "1");
	}

	/**
	 * Validate test.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 1)
	public void validatePostStats() throws Exception {

		LogUtil.log(Steps.START, "Validate PostStats API");
		PostsStats postsStats = NewRallioAPI.getPostStats(token, accountId);
		Assert.assertTrue(postsStats.getTotal_posts() > 0, "No Total Post found");
	}

	/**
	 * Validate scheduled posts.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 2)
	public void validateScheduledPosts() throws Exception {

		LogUtil.log(Steps.START, "Validate ScheduledPosts API");
		List<ScheduledPosts> scheduledPosts = NewRallioAPI.getScheduledPosts(token, accountId);
		Assert.assertTrue(scheduledPosts.size() > 0, "No scheduled posts found");
	}

	/**
	 * Validateget photos.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 3)
	public void validategetPhotos() throws Exception {

		LogUtil.log(Steps.START, "Validate Get Photos API");
		List<Photos> photos = NewRallioAPI.getPhotos(token, accountId, 1, "all");
		Assert.assertTrue(photos.size() > 0, "No photos found");
	}
	
	/**
	 * Validate photos with date range.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 4)
	public void validatePhotosWithDateRange() throws Exception{
		
		LogUtil.log(Steps.START, "Validate Get Photos with date range API");
		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
		List<Photos> photos = NewRallioAPI.getPhotosWithDateRange(token, "1", 2, "all", "photo", 1614191400, 1616696999);
		Assert.assertTrue(photos.size() > 0, "No photos found");
	}

	/**
	 * Validate social contents.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 5)
	public void validateSandBoxSocialContents() throws Exception {

		LogUtil.log(Steps.START, "Validate SandBox Social contents");
		NewRallioAPI.getAccountSwitcher(token, accountId);
		List<SocialContents> socialContents = NewRallioAPI.getSandBoxSocialContents(token, 3);
		Assert.assertTrue(socialContents.size() > 0);
	}

	/**
	 * Validate inbox social contents.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 6)
	public void validateInboxSocialContents() throws Exception {

		LogUtil.log(Steps.START, "Validate Inbox Social contents");
		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
		long date_range1 = date_range[0];
		long date_range2 = date_range[1];
		NewRallioAPI.getAccountSwitcher(token, "1");
		List<SocialContents> socialContents = NewRallioAPI.getInboxSocialContents(token, "1", "$franchisorId", String.valueOf(date_range1), String.valueOf(date_range2));
		Assert.assertTrue(socialContents.size() > 0);

	}
	
	/**
	 * Validate inbox social contents sample.
	 *
	 * @throws Exception the exception
	 */
	@Test(priority = 7)
	public void validateInboxSocialContentsSample() throws Exception {

		LogUtil.log(Steps.START, "Validate Inbox Social contents");
		List<SocialContents> socialContents = NewRallioAPI.getInboxSocialContentsSample(token);
	}
}

package com.rallio.automation.api.test;

import com.rallio.automation.api.testlink.*;
import com.rallio.automation.common.enums.*;
import com.rallio.automation.common.util.*;
import org.testng.annotations.*;
import testlink.api.java.client.*;

import java.net.*;

public class TestLinkResultsPushTest  {

    @Test
    public void validateTestLinkResults() throws MalformedURLException, TestLinkAPIException {

        LogUtil.log("Validating The TestLink Result Push", LogLevel.LOW);
        String stgbuildName = "Rv3:RallioV3 " + " " + DateUtil.getCurrentDate(DateUtil.YEAR_MONTH_DATE);
        String prodbuildName = "ProdSanity " + " " + DateUtil.getCurrentDate(DateUtil.YEAR_MONTH_DATE);
        String environment = System.getProperty("env");
        if(environment.equals("stg")){
            TestLinkResultsPushPage.updateReasultsInTestLink(environment,ParamUtil.getModuleName(),ParamUtil.getTestSuiteName(),stgbuildName);
        }
        else if (environment.equals("prod")){
            TestLinkResultsPushPage.updateReasultsInTestLink(environment,ParamUtil.getModuleName(), ParamUtil.getTestSuiteName(),prodbuildName);
        }
    }
}

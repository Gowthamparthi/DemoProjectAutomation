package com.rallio.automation.api.test;

import java.io.IOException;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.rallio.automation.api.testlink.TestlinkBasePage;
import br.eti.kinoshita.testlinkjavaapi.TestLinkAPI;

// TODO: Auto-generated Javadoc
public class RallioTestlinkCoverageReport extends TestlinkBasePage{
		
	TestLinkAPI api;
	String projectName = null;	
	String reportName = null;
		
	@BeforeTest
	public void started() {
		System.out.println("Started...Coverage Report preparation for stage environment.");
		loadConfig();
		projectName = getValue("projectName");	
		reportName = getValue("reportNameStage");
	}

	@Test(priority=1)
	public void getCurrentStageEnvironmentTestlinkStatusReport() throws IOException {
		
		TestLinkAPI api = getTestLinkAPIConnection();
		generateHTMLReportOfTheTestProject(api, projectName, reportName,"testlinkstg");
	}
	
	@AfterTest
	public void end() {
		System.out.println("End...Coverage validation");
	}

}

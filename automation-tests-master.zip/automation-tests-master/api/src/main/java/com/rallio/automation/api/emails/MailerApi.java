package com.rallio.automation.api.emails;

import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.rallio.automation.api.entity.RequestEntity;
import com.rallio.automation.api.entity.ResponseEntity;
import com.rallio.automation.api.enums.ContentType;
import com.rallio.automation.api.enums.EmailAutoOpsEnum;
import com.rallio.automation.api.util.ClientServiceUtil;
import com.rallio.automation.bussiness.newRallio.entity.Mailer;
import com.rallio.automation.common.enums.FilterBy;
import com.rallio.automation.common.enums.LogLevel;
import com.rallio.automation.common.util.LogUtil;

// TODO: Auto-generated Javadoc
/**
 * The Class MailerApi.
 */
public class MailerApi {

	/** The instance. */
	private static MailerApi instance;

	/**
	 * Instantiates a new mailer api.
	 */
	private MailerApi() {

	}
	
	/**
	 * Gets the single instance of MailerApi.
	 *
	 * @return single instance of MailerApi
	 */
	public static MailerApi getInstance() {

		if (instance == null) {
			synchronized (MailerApi.class) {
				if (instance == null) {
					instance = new MailerApi();
				}
			}
		}
		return instance;
	}

	/**
	 * Read email quickly.
	 *
	 * @param mailer the mailer
	 * @param filterBy the filter by
	 * @return the mailer
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public Mailer readEmailQuickly(Mailer mailer, FilterBy filterBy) throws IOException {

		mailer.setFilterBy(filterBy);
		RequestEntity request = new RequestEntity();
		request.setUrl(
				EmailAutoOpsEnum.APIURL.getEmailAutoOpsEnum() + EmailAutoOpsEnum.READMAILQUICKLY.getEmailAutoOpsEnum());
		request.setContentType(ContentType.JSON);
		request.setBodyContent(new ObjectMapper().writeValueAsString(mailer));
		ResponseEntity response = null;
		response = ClientServiceUtil.post(request, "Basic YXJ0aGk6YXJ0aGk=");

		Gson g = new Gson();
		Mailer received = g.fromJson(response.getResponse(), Mailer.class);

		return received;
	}

	/**
	 * Read email.
	 *
	 * @param mailer the mailer
	 * @param filterBy the filter by
	 * @return the mailer
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public Mailer readEmail(Mailer mailer, FilterBy filterBy) throws IOException {

		mailer.setFilterBy(filterBy);
		RequestEntity request = new RequestEntity();
		request.setUrl(EmailAutoOpsEnum.APIURL.getEmailAutoOpsEnum() + EmailAutoOpsEnum.READMAIL.getEmailAutoOpsEnum());
		request.setContentType(ContentType.JSON);
		request.setBodyContent(new ObjectMapper().writeValueAsString(mailer));
		ResponseEntity response = null;
		response = ClientServiceUtil.post(request, "Basic YXJ0aGk6YXJ0aGk=");
		Gson gson = new Gson();
		LogUtil.log("Mailer Respsonse : " + response.getResponse(), LogLevel.HIGH);
		Mailer received = gson.fromJson(response.getResponse(), Mailer.class);

		return received;
	}

}

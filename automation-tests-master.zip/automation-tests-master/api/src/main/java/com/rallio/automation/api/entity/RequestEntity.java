package com.rallio.automation.api.entity;

import java.util.Map;

import javax.ws.rs.core.NewCookie;

import com.rallio.automation.api.enums.ContentType;

// TODO: Auto-generated Javadoc
/**
 * The Class RequestEntity.
 */
public class RequestEntity {

	/** The url. */
	private String url;

	/** The body content. */
	private String bodyContent;

	/** The parameters. */
	private Map<String, String> parameters;

	/** The obj parameters. */
	private Map<String, Object> objParameters;

	/** The content type. */
	private ContentType contentType;

	/** The cookies. */
	private Map<String, NewCookie> cookies = null;

	/** The obj header. */
	private Map<String, String> objHeader;

	/**
	 * Gets the url.
	 *
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}
	/**
	 * Sets the url.
	 *
	 * @param url the new url
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * Gets the body content.
	 *
	 * @return the body content
	 */
	public String getBodyContent() {
		return bodyContent;
	}

	/**
	 * Sets the body content.
	 *
	 * @param bodyContent the new body content
	 */
	public void setBodyContent(String bodyContent) {
		this.bodyContent = bodyContent;
	}

	/**
	 * Gets the parameters.
	 *
	 * @return the parameters
	 */
	public Map<String, String> getParameters() {
		return parameters;
	}

	/**
	 * Sets the parameters.
	 *
	 * @param parameters the parameters
	 */
	public void setParameters(Map<String, String> parameters) {
		this.parameters = parameters;
	}

	/**
	 * Gets the content type.
	 *
	 * @return the content type
	 */
	public ContentType getContentType() {
		return contentType;
	}

	/**
	 * Sets the content type.
	 *
	 * @param contentType the new content type
	 */
	public void setContentType(ContentType contentType) {
		this.contentType = contentType;
	}

	/**
	 * Gets the cookies.
	 *
	 * @return the cookies
	 */
	public Map<String, NewCookie> getCookies() {
		return cookies;
	}

	/**
	 * Sets the cookies.
	 *
	 * @param cookies the cookies
	 */
	public void setCookies(Map<String, NewCookie> cookies) {
		this.cookies = cookies;
	}

	/**
	 * Gets the obj parameters.
	 *
	 * @return the obj parameters
	 */
	public Map<String, Object> getObjParameters() {
		return objParameters;
	}

	/**
	 * Sets the obj parameters.
	 *
	 * @param objParameters the obj parameters
	 */
	public void setObjParameters(Map<String, Object> objParameters) {
		this.objParameters = objParameters;
	}

	/**
	 * Gets the obj header.
	 *
	 * @return the obj header
	 */
	public Map<String, String> getObjHeader() {
		return objHeader;
	}

	/**
	 * Sets the obj header.
	 *
	 * @param objHeader the obj header
	 */
	public void setObjHeader(Map<String, String> objHeader) {
		this.objHeader = objHeader;
	}
	
}
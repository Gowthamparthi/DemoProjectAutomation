package com.rallio.automation.api.testlink;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.rallio.automation.api.enums.TestlinkReportComponentsEnum;
import com.rallio.automation.common.enums.LogLevel;
import com.rallio.automation.common.util.LogUtil;

import br.eti.kinoshita.testlinkjavaapi.TestLinkAPI;
import br.eti.kinoshita.testlinkjavaapi.constants.ExecutionType;
import br.eti.kinoshita.testlinkjavaapi.constants.TestCaseDetails;
import br.eti.kinoshita.testlinkjavaapi.model.TestCase;
import br.eti.kinoshita.testlinkjavaapi.model.TestProject;
import br.eti.kinoshita.testlinkjavaapi.model.TestSuite;
import br.eti.kinoshita.testlinkjavaapi.util.TestLinkAPIException;

public class TestlinkBasePage {

	private final String XML_RPC_URL = "https://testlink.rallio.com/lib/api/xmlrpc/v1/xmlrpc.php";

	private final String TESTLINK_DEVKEY = "33ee6398e1c021d7f3595d00a7e19c11";

	private static TestLinkAPI testlinkAPI = null;

	URL testlinkURL = null;

	static Properties config = new Properties();
	

	protected synchronized TestLinkAPI getTestLinkAPIConnection() {

		URL testlinkURL = null;
		try {
			testlinkURL = new URL(XML_RPC_URL);
		} catch (MalformedURLException exception) {
			exception.printStackTrace();
		}
		try {
			testlinkAPI = new TestLinkAPI(testlinkURL, TESTLINK_DEVKEY);
		} catch (TestLinkAPIException apiException) {
			apiException.printStackTrace();
		}

		return testlinkAPI;
	}

	public static void loadConfig() {

		try {
			config.load(TestlinkBasePage.class.getClassLoader().getResourceAsStream("Testlink.properties"));
			System.out.println("Property file loaded successfully.");
		} catch (Exception e) {
			System.out.println("No config file Testlink.properties.");
		}
	}

	public static String getValue(String key) {

		String value = null;
		if (key != null) {
			value = config.getProperty(key);
		} else {
			System.out.println("No Value found for the specified key:" + key + " in file ralioactivate-stg.properties");
		}
		return value;
	}

	public static List<String> getListOfValues(String key) {

		List<String> values = null;
		if (key != null) {
			values = Arrays.asList(config.getProperty(key).split(","));
		} else {
			System.out.println("No Value found for the specified key:" + key + " in file reviqmetric-stg.properties");
		}
		return values;
	}

	public int getAutomatedCasesCountOfTheSuite(TestCase[] testCases) {

		int suiteAutomatedCasesCount = 0;

		for (TestCase testCase : testCases) {
			ExecutionType type = testCase.getExecutionType();
			if (type == null)
				continue;
			else if (type.getValue() == 2)
				suiteAutomatedCasesCount++;
		}
		return suiteAutomatedCasesCount;
	}

	/**
	 * Gets the manual cases count of the suite.
	 *
	 * @param testCases the test cases
	 * @return the manual cases count of the suite
	 */
	public int getManualCasesCountOfTheSuite(TestCase[] testCases) {

		int suiteAutomatedCasesCount = 0;

		for (TestCase testCase : testCases) {
			ExecutionType type = testCase.getExecutionType();
			if (type == null)
				continue;
			else if (type.getValue() == 1)
				suiteAutomatedCasesCount++;
		}
		return suiteAutomatedCasesCount;
	}

	/**
	 * Adds the array values.
	 *
	 * @param array the array
	 * @return the int
	 */
	public int addArrayValues(ArrayList<Integer> array) {
		int totalValue = 0;
		System.out.println("Array :" + array);
		for (int total : array) {
			totalValue = totalValue + total;
		}
		System.out.println("Total Value :" + totalValue);
		return totalValue;
	}

	/**
	 * Percentage calculator.
	 *
	 * @param obtainedCount the obtained count
	 * @param totalCount    the total count
	 * @return the float
	 */
	public float percentageCalculator(int obtainedCount, int totalCount) {

		float percentage = (((float) obtainedCount) / ((float) totalCount) * 100);
		String formattedString = String.format("%.02f", percentage);
		percentage = Float.valueOf(formattedString);
		System.out.println("Percentage :" + percentage);
		return percentage;
	}
	
	public File getHTMLReportFile(String fileName, String reportContent,String fileDirectory) {
		
		File reportFile = new File(fileDirectory+"\\"+fileName+"_"+new SimpleDateFormat("YYYY-MM-D-HH:MM").format(new Date())+ ".html");	
		try {
			if (reportFile.createNewFile()) {
				BufferedWriter bw = new BufferedWriter(new FileWriter(reportFile));
				bw.write(reportContent);
				bw.close();
				System.out.println("file " + reportFile.getAbsolutePath() + " Created Successfull.");
			} else
				System.out.println("file doesn't created.");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return reportFile;
	}
	
	public void sendMail(String FromAddress,String fromPassword,String reportContent,String testlinkenv) throws Exception {

		List<String> recipientsList = getListOfValues("mail.recipients");
		for(String recipient : recipientsList) {
			LogUtil.log("Mail Recipient :"+recipient,LogLevel.LOW);
		}
		
		String mailSubject = null;
		if(testlinkenv.equals("testlinkstg"))
			mailSubject = getValue("mail.stagesubject");
		else
			mailSubject = getValue("mail.productionsubject");
		 getValue("mail.subject");
		final String from = FromAddress.trim();
		System.out.println("From mail id :"+from);
		final String password = fromPassword.trim();
		System.out.println("From mail id :"+password);

		List<String> recipients = recipientsList;
		Properties prop = new Properties();
		
		prop.put("mail.smtp.host", "smtp.gmail.com");
		prop.put("mail.smtp.port", "465");
		prop.put("mail.smtp.auth", "true");
		prop.put("mail.smtp.socketFactory.port", "465");
		prop.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
		prop.put("mail.smtp.starttls.enable", "true");
		
//		prop.put("mail.smtp.host", "smtp.office365.com");
//		prop.put("mail.smtp.port", "587");
//		prop.put("mail.smtp.auth", "true");
//		prop.put("mail.smtp.socketFactory.port", "587");
//		prop.put("mail.smtp.starttls.enable", "true");

		Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(from, password);
			}
		});

		try {
			Message message = new MimeMessage(session);
			InternetAddress[] addresses = new InternetAddress[recipients.size()];
			for (int i = 0; i < recipients.size(); i++) {
				addresses[i] = new InternetAddress(recipients.get(i));
			}
			message.setFrom(new InternetAddress(from));
			message.setRecipients(Message.RecipientType.TO, addresses);
			message.setSubject(mailSubject);
			
			MimeBodyPart mimeBodyPart = new MimeBodyPart();
			mimeBodyPart.setContent(reportContent, "text/html");	
			
//			MimeBodyPart attachmentBodyPart = new MimeBodyPart();
//			attachmentBodyPart.attachFile(reportFile);
				
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(mimeBodyPart);
//			multipart.addBodyPart(attachmentBodyPart);
			
			message.setContent(multipart);
			Transport.send(message);
			System.out.println("Testlink coverage report mail has been successfully sent..");

		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}
	
	public void sendMail(File reportFile) throws Exception {

		List<String> sendAddress = getListOfValues("mail.sendAddress");
		List<String> recipientsList = getListOfValues("mail.recipients");
		for(String recipient : recipientsList) {
			LogUtil.log("Mail Recipient :"+recipient,LogLevel.LOW);
		}
		String mailSubject = getValue("mail.subject") + " "
				+ new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss").format(new Date());
		String mailContentBody = getValue("mail.content");
		final String from = sendAddress.get(0);
		final String password = sendAddress.get(1);

		List<String> recipients = recipientsList;
		Properties prop = new Properties();
		prop.put("mail.smtp.host", "smtp.office365.com");
		prop.put("mail.smtp.port", "587");
		prop.put("mail.smtp.auth", "true");
		prop.put("mail.smtp.socketFactory.port", "587");
		prop.put("mail.smtp.starttls.enable", "true");

		Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(from, password);
			}
		});

		try {
			Message message = new MimeMessage(session);
			InternetAddress[] addresses = new InternetAddress[recipients.size()];
			for (int i = 0; i < recipients.size(); i++) {
				addresses[i] = new InternetAddress(recipients.get(i));
			}
			message.setFrom(new InternetAddress(from));
			message.setRecipients(Message.RecipientType.TO, addresses);
			message.setSubject(mailSubject);

			MimeBodyPart mimeBodyPart = new MimeBodyPart();
			mimeBodyPart.setContent(mailContentBody, "text/html");

			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(mimeBodyPart);

			MimeBodyPart attachmentBodyPart = new MimeBodyPart();
			attachmentBodyPart.attachFile(reportFile);
			multipart.addBodyPart(attachmentBodyPart);

			message.setContent(multipart);

			Transport.send(message);
			System.out.println("Testlink report mail has been successfully sent..");

		} catch (MessagingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	protected void generateHTMLReportOfTheTestProject(TestLinkAPI api, String testProjectName, String reportName,String testlinkenv) throws IOException {
		
		String mailFromAddress = getValue("mail.SenderAddress");
		String mailFromAddressPassword = getValue("mail.SenderPassword");
		final String directory = System.getProperty("user.dir");
		TestProject[] projects = api.getProjects();
		TestSuite[] firstLevelSuites = null;	
		String mailContent = null;
		
		if(testlinkenv.equals("testlinkstg"))
			mailContent = getValue("mail.stagecontent");
		else
			mailContent = getValue("mail.productioncontent");
		for (TestProject project : projects) {
			if (project.getName().equals(testProjectName))
				firstLevelSuites = api.getFirstLevelTestSuitesForTestProject(project.getId());
		}
		String htmlHeader = TestlinkReportComponentsEnum.HTML_REPORT_HEADER.getComponent();
		String htmlBody = String.format(TestlinkReportComponentsEnum.HTML_REPORT_BODY.getComponent(),mailContent,testProjectName);
		StringBuilder htmlReportBuilder = new StringBuilder().append(htmlHeader).append(htmlBody);
		
		//Workaround to skip this below modules.
		String[] ignoremodules1 = new String[] { "Production API", "Now_Tech_Public_API" };
		String[] ignoremodules2 = new String[] { "Overview", "Calendar", "Page Analytics", "Media", "Leaderboard",
				"Notification settings", "Logins", "Site_Login", "Inbox", "Posts", "Creator", "Location_user_logins",
				"Outbox", "Now_Tech_Staging_API" };
				
		switch (testlinkenv) {
		case "testlinkstg":
			System.out.println("Executing the Stage-environment testplan results from testlink.");
			getTestCaseDetailsTableOfTheTestSuite(api, firstLevelSuites[0], htmlReportBuilder, null);
			getTestCaseDetailsTableOfTheTestSuite(api, firstLevelSuites[2], htmlReportBuilder, ignoremodules1);
			break;
		case "testlinkprod":
			System.out.println("Executing the Production-environment testplan results from testlink.");
		    getTestCaseDetailsTableOfTheTestSuite(api, firstLevelSuites[1],htmlReportBuilder, null);
			getTestCaseDetailsTableOfTheTestSuite(api, firstLevelSuites[2], htmlReportBuilder, ignoremodules2);
			getTestCaseDetailsTableOfTheTestSuite(api, firstLevelSuites[3],htmlReportBuilder, null);
			break;
		default:
			System.out.println("Please Provide the valid environment Like \"stg\" or \"prod\"");
		}
		String htmlFooterText = String.format(TestlinkReportComponentsEnum.HTML_REPORT_BOTTOM_TEXT.getComponent(),"Automation Team");
		String htmlFooter = TestlinkReportComponentsEnum.HTML_REPORT_FOOTER.getComponent();
		htmlReportBuilder.append(htmlFooterText);
		htmlReportBuilder.append(htmlFooter);	
		getHTMLReportFile(reportName,htmlReportBuilder.toString(),directory);	
		try {
			sendMail(mailFromAddress,mailFromAddressPassword,htmlReportBuilder.toString(),testlinkenv);
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}

	/**
	 * Gets the test case details table of the test suite.
	 *
	 * @param api               the api
	 * @param testPlan          the test plan
	 * @param htmlReportBuilder the html report builder
	 * @param ignoremodules     the ignoremodules
	 * @return the test case details table of the test suite
	 */
	public String getTestCaseDetailsTableOfTheTestSuite(TestLinkAPI api, TestSuite testPlan,
			StringBuilder htmlReportBuilder, String[] ignoremodules) {

		String subPlan = null;
		if (ignoremodules != null && ignoremodules.length == 2)
			subPlan = "Stage API modules :";
		else if (ignoremodules != null && ignoremodules.length == 14)
			subPlan = "Production API modules :";
		String htmlReportTableHeader = TestlinkReportComponentsEnum.HTML_REPORT_TABLE_HEADER.getComponent();
		htmlReportBuilder
				.append(String.format(TestlinkReportComponentsEnum.HTML_REPORT_PLANNAME.getComponent(), testPlan.getName()));
		if (subPlan != null)
			htmlReportBuilder
					.append(String.format(TestlinkReportComponentsEnum.HTML_REPORT_SUB_PLANNAME.getComponent(), subPlan));
		htmlReportBuilder.append(htmlReportTableHeader);

		TestSuite[] testPlanModules = api.getTestSuitesForTestSuite(testPlan.getId());

		ArrayList<Integer> planTotalTestCases = new ArrayList<Integer>();
		ArrayList<Integer> planTotalautomatedCases = new ArrayList<Integer>();
		ArrayList<Integer> planTotalManualCases = new ArrayList<Integer>();
		int serielNo = 1;
	
		module: for (TestSuite testPlanModule : testPlanModules) {
			if (ignoremodules != null)
				for (String ignoreModule : ignoremodules) {
					if (ignoreModule.equals(testPlanModule.getName()))
						continue module;
				}
			TestCase[] testCases = api.getTestCasesForTestSuite(testPlanModule.getId(), true, TestCaseDetails.FULL);
			int moduleTotalCount = testCases.length;
			int moduleAutomatedCount = getAutomatedCasesCountOfTheSuite(testCases);
			int moduleManualCount = getManualCasesCountOfTheSuite(testCases);
			float moduleAutomatedPercentage = percentageCalculator(moduleAutomatedCount, moduleTotalCount);
			float moduleManualPercentage = percentageCalculator(moduleManualCount, moduleTotalCount);

			String htmlTableRow = String.format(TestlinkReportComponentsEnum.HTML_REPORT_TABLE_ROW.getComponent(), serielNo,
					testPlanModule.getName(), moduleTotalCount, moduleAutomatedCount, moduleAutomatedPercentage,
					moduleManualCount, moduleManualPercentage);
			htmlReportBuilder.append(htmlTableRow);
			System.out.println(htmlTableRow);
			planTotalTestCases.add(moduleTotalCount);
			planTotalautomatedCases.add(moduleAutomatedCount);
			planTotalManualCases.add(moduleManualCount);

			serielNo++;
		}
	
		int planTotalTestCasesCount = addArrayValues(planTotalTestCases);
		int planTotalautomatedCasesCount = addArrayValues(planTotalautomatedCases);
		int planTotalManualCasesCount = addArrayValues(planTotalManualCases);
		float planAutomatedPercentage = percentageCalculator(planTotalautomatedCasesCount,
				planTotalTestCasesCount);
		float planManualPercentage = percentageCalculator(planTotalManualCasesCount, planTotalTestCasesCount);

		String bottomRow = String.format(TestlinkReportComponentsEnum.HTML_REPORT_TABLE_BOTTOM_ROW.getComponent(), "",
				"Total", planTotalTestCasesCount, planTotalautomatedCasesCount, planAutomatedPercentage,
				planTotalManualCasesCount, planManualPercentage);
		planTotalTestCases.clear();
		planTotalautomatedCases.clear();
		planTotalManualCases.clear();
		htmlReportBuilder.append(bottomRow);
		
		return htmlReportBuilder.toString();
	}
	
}

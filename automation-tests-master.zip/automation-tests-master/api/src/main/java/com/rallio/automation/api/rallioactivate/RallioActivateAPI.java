package com.rallio.automation.api.rallioactivate;

import static com.rallio.automation.api.rallioactivate.RallioAPITestBase.getListObject;

import java.net.URI;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rallio.automation.api.enums.AssetTypeEnum;
//import com.rallio.automation.api.enums.ContentType;
import com.rallio.automation.api.enums.LeaderBoardListType;
import com.rallio.automation.api.enums.MediaReleaseFormTypeEnum;
import com.rallio.automation.api.enums.MediaSourceTypeEnum;
import com.rallio.automation.api.enums.PostUsageTypeEnum;
import com.rallio.automation.api.enums.PostsTypeEnum;
import com.rallio.automation.api.enums.RewardProgramsTypeEnum;
import com.rallio.automation.api.util.APIUtil;
import com.rallio.automation.business.enums.AccountType;
import com.rallio.automation.business.rallioActivate.entity.AccountSwticher;
import com.rallio.automation.business.rallioActivate.entity.AccountsList;
import com.rallio.automation.business.rallioActivate.entity.AchieversList;
import com.rallio.automation.business.rallioActivate.entity.AdvocacyPosts;
import com.rallio.automation.business.rallioActivate.entity.Assets;
import com.rallio.automation.business.rallioActivate.entity.AssetsSubmitted;
import com.rallio.automation.business.rallioActivate.entity.BrandAndHubs;
import com.rallio.automation.business.rallioActivate.entity.CommunityManagementAdvocatesData;
import com.rallio.automation.business.rallioActivate.entity.CommunityManagementStatsData;
import com.rallio.automation.business.rallioActivate.entity.Content;
import com.rallio.automation.business.rallioActivate.entity.Contents;
import com.rallio.automation.business.rallioActivate.entity.CreditCard;
import com.rallio.automation.business.rallioActivate.entity.EngagementFromAssets;
import com.rallio.automation.business.rallioActivate.entity.FavouriteTags;
import com.rallio.automation.business.rallioActivate.entity.Franchisors;
import com.rallio.automation.business.rallioActivate.entity.ListOfLocations;
import com.rallio.automation.business.rallioActivate.entity.MonthlyPostMetrics;
import com.rallio.automation.business.rallioActivate.entity.PostMetrics;
import com.rallio.automation.business.rallioActivate.entity.PostsStats;
import com.rallio.automation.business.rallioActivate.entity.PromotionList;
import com.rallio.automation.business.rallioActivate.entity.RallioActivateUser;
import com.rallio.automation.business.rallioActivate.entity.RecentPost;
import com.rallio.automation.business.rallioActivate.entity.RewardProgram;
import com.rallio.automation.business.rallioActivate.entity.RewardProgramDetails;
import com.rallio.automation.business.rallioActivate.entity.RewardProgramStats;
import com.rallio.automation.business.rallioActivate.entity.SavedPosts;
import com.rallio.automation.business.rallioActivate.entity.Tags;
import com.rallio.automation.business.rallioActivate.entity.TotalAssetsStats;
import com.rallio.automation.business.rallioActivate.entity.TotalMetrics;
import com.rallio.automation.business.rallioActivate.entity.TotalScore;
import com.rallio.automation.business.rallioActivate.entity.User;
import com.rallio.automation.common.enums.LogLevel;
import com.rallio.automation.common.enums.Steps;
import com.rallio.automation.common.util.FileUtil;
import com.rallio.automation.common.util.LogUtil;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.http.ContentType;

// TODO: Auto-generated Javadoc
/**
 * The Class RallioActivateAPI.
 */
public class RallioActivateAPI {

	/**
	 * Instantiates a new rallio activate API.
	 */
	private RallioActivateAPI() {

	}

	/**
	 * Login.
	 *
	 * @param ralioActivateUser the ralio activate user
	 * @return true, if successful
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, Object> login(RallioActivateUser ralioActivateUser) throws Exception {

		LogUtil.log("Login API", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/login.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL(), ralioActivateUser.getUserName(), ralioActivateUser.getPassword());
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().queryParams((Map<String, ?>) payload.get("parameters")).body((Map<String, ?>) payload.get("parameters")).when()
		        .post(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		LogUtil.log("Response Code :" + response.getStatusCode(), LogLevel.LOW);
		LogUtil.log("Response Message: " + response.getBody().asString(), LogLevel.LOW);
		String franchisorId = null;
		JsonPath jsonPath = new JsonPath(response.getBody().asString());
		String token = null;
		boolean franchisor = false;
		try {
			token = jsonPath.getString("rallio_access_token.token");
			if (jsonPath.getList("user_detail.franchisors_managed").size() != 0) {
				franchisorId = jsonPath.getString("franchisor.id");
				franchisor = true;
			} else {
				franchisorId = jsonPath.getString("account.id");
				franchisor = false;
			}
			User user = jsonPath.getObject(("user"), User.class);
			LogUtil.log("Token id " + token, LogLevel.LOW);
			LogUtil.log("Franchisor Id:" + franchisorId, LogLevel.LOW);
			LogUtil.log(" ", LogLevel.LOW);
			return Stream.of(new AbstractMap.SimpleEntry<>("responseCode", String.valueOf(response.getStatusCode())), new AbstractMap.SimpleEntry<>("tokenId", token),
			        new AbstractMap.SimpleEntry<>("franchisorId", franchisorId), new AbstractMap.SimpleEntry<>("user", user),
			        new AbstractMap.SimpleEntry<>("franchisor", franchisor)).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
		} catch (Exception e) {

			LogUtil.log("Exception caught: " + e, LogLevel.LOW);
			LogUtil.log("Token Id generated " + token, LogLevel.LOW);
			LogUtil.log(" ", LogLevel.LOW);
			return null;

		}
	}

	/**
	 * Gets the franchisor details.
	 *
	 * @param token the token
	 * @param franchisorId the franchisor id
	 * @return the franchisor details
	 * @throws Exception the exception
	 */
	public static Franchisors getFranchisorDetails(String token, String franchisorId) throws Exception {

		LogUtil.log("Get Franchisor Details", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/franchisorAPICall.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL :" + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters :" + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).when().get(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		JsonPath jsonPath = new JsonPath(responseBody);
		LogUtil.log("Franchisor Count" + jsonPath.getObject(("franchisor"), Franchisors.class).getChild_count(), LogLevel.LOW);
		Franchisors franchisors = jsonPath.getObject(("franchisor"), Franchisors.class);
		return franchisors;
	}
	/**
	 * Gets the location list.
	 *
	 * @param token the token
	 * @param franchisorId the franchisor id
	 * @return the location list
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static ListOfLocations getLocationList(String token, String franchisorId) throws Exception {

		LogUtil.log("Get Location List", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getLocationList.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).when()
		        .get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		String responsebody = response.getBody().asString();
		LogUtil.log(responsebody, LogLevel.LOW);
		List<?> accounts = getListObject(response, "accounts");
		LogUtil.log("List of accounts " + accounts, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		ObjectMapper objectMapper = new ObjectMapper();
		ListOfLocations listOfLocations = objectMapper.readValue(responsebody, ListOfLocations.class);
		Assert.assertNotNull(listOfLocations, "Empty Total Metrics");
		return listOfLocations;
	}

	/**
	 * Gets the total metrics.
	 *
	 * @param token the token
	 * @param accountType the account type
	 * @param franchisorId the franchisor id
	 * @return the total metrics
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static TotalMetrics getTotalMetrics(String token, AccountType accountType, String franchisorId, String date) throws Exception {

		LogUtil.log("Get Total Metrics", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getTotalMetrics.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		//inputData = inputData.replace("$dateRange", date);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		HashMap<String, String> map = new HashMap<>();
		switch (accountType) {
		case FRANCHISOR:
			map.put("franchisor_id", franchisorId);
			break;

		case LOCATION:
			map.put("account_id", franchisorId);
			break;
		default:
			break;
		}
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + map, LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).when().get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		String responsebody = response.getBody().asString();
		LogUtil.log(responsebody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		ObjectMapper objectMapper = new ObjectMapper();
		TotalMetrics totalMetrics = objectMapper.readValue(responsebody, TotalMetrics.class);
		Assert.assertNotNull(totalMetrics, "Empty Total Metrics");
		return totalMetrics;

	}

	/**
	 * Gets the post metrics.
	 *
	 * @param token the token
	 * @param franchisorId the franchisor id
	 * @param accountType the account type
	 * @return the post metrics
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static PostMetrics getPostMetrics(String token, String franchisorId, AccountType accountType) throws Exception {

		LogUtil.log("Get Post Metrics", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getPostMetrics.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		HashMap<String, String> map = new HashMap<>();
		switch (accountType) {
		case FRANCHISOR:
			map.put("franchisor_id", franchisorId);
			break;

		case LOCATION:
			map.put("account_id", franchisorId);
			break;
		default:
			break;
		}
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) map).when().get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = new JsonPath(response.getBody().asString());
		PostMetrics postMetrics = jsonPath.getObject(("posts_metrics"), PostMetrics.class);
		return postMetrics;

	}

	/**
	 * Gets the content stats.
	 *
	 * @param token the token
	 * @param franchisorId the franchisor id
	 * @return the content stats
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static PostsStats getContentStats(String token, String franchisorId) throws Exception {

		LogUtil.log("Get Content Stats", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getContentStats.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).when()
		        .get(new URI((String) payload.get("url")));
		int responseCode = response.statusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		ObjectMapper objectMapper = new ObjectMapper();
		PostsStats postsStats = objectMapper.readValue(responseBody, PostsStats.class);
		return postsStats;
	}

	/**
	 * Post page list view contents.
	 *
	 * @param token the token
	 * @param franchisorId the franchisor id
	 * @return the response
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static Response postPageListViewContents(String token, String franchisorId) throws Exception {

		LogUtil.log("PostPage ListView Contents", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/postPageListView.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).when()
		        .get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		return response;
	}

	/**
	 * Gets the post stats.
	 *
	 * @param token the token
	 * @param accountId the account id
	 * @return the post stats
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static PostsStats getPostStats(String token, String accountId) throws Exception {

		LogUtil.log("Get PostStats", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/postStats.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$accountId", accountId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).when()
		        .get(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		String responseBody = response.getBody().asString();
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		ObjectMapper objectMapper = new ObjectMapper();
		PostsStats postsStats = objectMapper.readValue(responseBody, PostsStats.class);
		return postsStats;
	}

	/**
	 * Gets the saved posts.
	 *
	 * @param token the token
	 * @param accountId the account id
	 * @return the saved posts
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static List<SavedPosts> getSavedPosts(String token, String accountId) throws Exception {

		LogUtil.log("Get SavedPosts API", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/savedPosts.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$accountId", accountId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).when()
		        .get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.statusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = new JsonPath(response.getBody().asString());
		List<SavedPosts> savedPosts = Arrays.asList(jsonPath.getObject(("saved_posts"), SavedPosts[].class));
		return savedPosts;
	}

	/**
	 * Creates the post.
	 *
	 * @param token the token
	 * @param accountId the account id
	 * @return the saved posts
	 * @throws Exception the exception
	 */
	public static SavedPosts createPost(String token, String accountId) throws Exception {

		LogUtil.log(Steps.START, "Create Post In Accounts API");
		String inputData = FileUtil.getStringData("RallioActivateAPIs/savedPosts.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		SavedPosts savedPosts = new SavedPosts();
		savedPosts.setAccount_id(Integer.parseInt(accountId));
		savedPosts.setCloudinary_resource_type("photo");
		savedPosts.setCloudinary_video_id("");
		savedPosts.setLocked(false);
		savedPosts.setLong_text("TestPosts");
		savedPosts.setPhoto_urls(new ArrayList<String>() {

			{
				add("https://res.cloudinary.com/ralliohq/q_auto/tkpfcee0gvdl9crpoi8k.jpg");
			}
		});
		savedPosts.setShort_text("TestPosts");
		savedPosts.setTags_list("");
		savedPosts.setUse_facebook(true);
		savedPosts.setUse_instagram(true);
		savedPosts.setUse_linkedin(true);
		savedPosts.setUse_twitter(true);

		ObjectMapper objectMapper = new ObjectMapper();
		String json = "";
		try {
			json = objectMapper.writeValueAsString(savedPosts);
		} catch (Exception e) {
			// TODO: handle exception
		}
		JSONObject jsonObject = new JSONObject(json);
		JSONObject object = new JSONObject();
		object.put("saved_post", jsonObject);
		object.put("userOwnership", "account");
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).header("Content-Type", "application/json").contentType(ContentType.JSON).body(object.toString())
		        .when().post(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.statusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = new JsonPath(response.getBody().asString());
		SavedPosts savedPost = jsonPath.getObject("saved_post", SavedPosts.class);
		return savedPost;
	}

	/**
	 * Edits the post.
	 *
	 * @param token the token
	 * @param accountId the account id
	 * @param id the id
	 * @return the saved posts
	 * @throws Exception the exception
	 */
	public static SavedPosts editPost(String token, String accountId, int id) throws Exception {

		LogUtil.log(Steps.START, "Edit Post In Accounts API");
		String inputData = FileUtil.getStringData("RallioActivateAPIs/editPost.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$id", String.valueOf(id));
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		SavedPosts savedPosts = new SavedPosts();
		savedPosts.setAccount_id(Integer.parseInt(accountId));
		savedPosts.setCloudinary_resource_type("photo");
		savedPosts.setCloudinary_video_id("");
		savedPosts.setLocked(false);
		savedPosts.setLong_text("TestPosts12");
		savedPosts.setPhoto_urls(new ArrayList<String>() {

			{
				add("https://res.cloudinary.com/ralliohq/q_auto/tkpfcee0gvdl9crpoi8k.jpg");
			}
		});
		savedPosts.setShort_text("TestPosts,TestPosts");
		savedPosts.setTags_list("Animal");
		savedPosts.setUse_facebook(true);
		savedPosts.setUse_instagram(true);
		savedPosts.setUse_linkedin(true);
		savedPosts.setUse_twitter(true);

		ObjectMapper objectMapper = new ObjectMapper();
		String json = "";
		try {
			json = objectMapper.writeValueAsString(savedPosts);
		} catch (Exception e) {
			// TODO: handle exception
		}
		JSONObject jsonObject = new JSONObject(json);
		JSONObject object = new JSONObject();
		object.put("saved_post", jsonObject);
		object.put("userOwnership", "account");
		object.put("isEditPost", true);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).header("Content-Type", "application/json").contentType(ContentType.JSON).body(object.toString())
		        .when().put(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.statusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = new JsonPath(response.getBody().asString());
		SavedPosts savedPost = jsonPath.getObject("saved_post", SavedPosts.class);
		return savedPost;
	}

	/**
	 * Delete post.
	 *
	 * @param token the token
	 * @param id the id
	 * @return the saved posts
	 * @throws Exception the exception
	 */
	public static SavedPosts deletePost(String token, int id) throws Exception {

		LogUtil.log(Steps.START, "Delete Post In Accounts API");
		String inputData = FileUtil.getStringData("RallioActivateAPIs/deletePost.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$id", String.valueOf(id));
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).header("Content-Type", "application/json").body(payload.get("parameters")).when()
		        .patch(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.statusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = new JsonPath(response.getBody().asString());
		SavedPosts savedPost = jsonPath.getObject("saved_post", SavedPosts.class);
		return savedPost;
	}

	/**
	 * Gets the monthly post metrics.
	 *
	 * @param token the token
	 * @param franchisorId the franchisor id
	 * @return the monthly post metrics
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static MonthlyPostMetrics getMonthlyPostMetrics(String token, String franchisorId) throws Exception {

		LogUtil.log("Get Monthly Post Metrics", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getMonthlyPostMetrics.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).when()
		        .get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		JsonPath jsonPath = new JsonPath(responseBody);
		MonthlyPostMetrics monthlyPostMetrics = jsonPath.getObject(("monthly_posts_metrics"), MonthlyPostMetrics.class);
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		return monthlyPostMetrics;
	}

	/**
	 * Gets the recent posts.
	 *
	 * @param token the token
	 * @param franchisorId the franchisor id
	 * @return the recent posts
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static List<RecentPost> getRecentPosts(String token, String franchisorId) throws Exception {

		LogUtil.log("Get Recent Post Metrics", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getRecentPosts.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).when()
		        .get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		String responseBody = response.getBody().asString();
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = new JsonPath(responseBody);
		List<RecentPost> recentPosts = Arrays.asList(jsonPath.getObject(("recent_posts"), RecentPost[].class));
		return recentPosts;
	}

	/**
	 * Log out.
	 *
	 * @param token the token
	 * @return the response
	 * @throws Exception the exception
	 */
	public static Response logOut(String token) throws Exception {

		LogUtil.log("Logout API", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/logOut.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("${token}", token);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().delete(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		return response;
	}

	/**
	 * Gets the tags.
	 *
	 * @param token the token
	 * @return the tags
	 * @throws Exception the exception
	 */
	public static List<Tags> getTags(String token) throws Exception {

		LogUtil.log("Get Tags", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getTags.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).when().get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = new JsonPath(response.getBody().asString());
		List<Tags> tags = Arrays.asList(jsonPath.getObject(("tags"), Tags[].class));
		return tags;

	}

	/**
	 * Gets the reward programs.
	 *
	 * @param token the token
	 * @param franchisorId the franchisor id
	 * @return the reward programs
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static List<RewardProgramDetails> getAllRewardPrograms(String token, String franchisorId) throws Exception {

		LogUtil.log("Get All Reward Programs", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getAllRewardPrograms.json");
		inputData = String.format(inputData, "https://app-api.rall.io");
		inputData = inputData.replace("$franchisorId", franchisorId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters"))
		        .get(new URI((String) payload.get("url")));
		int responseCode = response.statusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = new JsonPath(response.getBody().asString());
		String status = jsonPath.getString("status");
		Assert.assertEquals("success", status, "Failed to get success message");
		List<RewardProgramDetails> listOfProgramDetails = Arrays.asList(jsonPath.getObject(("data.programDetails"), RewardProgramDetails[].class));
		return listOfProgramDetails;
	}

	/**
	 * Gets the reward program.
	 *
	 * @param franchisorId the franchisor id
	 * @param token the token
	 * @param id the id
	 * @return the reward program
	 * @throws Exception the exception
	 */
	public static RewardProgram getRewardProgram(String franchisorId, String token, int id) throws Exception {

		LogUtil.log("Get Specific Reward Programs", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getRewardProgram.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateRewardBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		inputData = inputData.replace("$id", String.valueOf(id));
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).when().get(new URI((String) payload.get("url")));
		int responseCode = response.statusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = new JsonPath(response.getBody().asString());
		String status = jsonPath.getString("status");
		Assert.assertEquals("success", status, "Failed to get success message");
		RewardProgram rewardProgram = jsonPath.getObject(("data"), RewardProgram.class);
		return rewardProgram;
	}

	/**
	 * Creates the reward program.
	 *
	 * @param franchisorId the franchisor id
	 * @param token the token
	 * @param rewardProgram the reward program
	 * @return the int
	 * @throws Exception the exception
	 */
	public static int createRewardProgram(String franchisorId, String token, RewardProgram rewardProgram) throws Exception {

		LogUtil.log("Create New Reward Program", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/createRewardProgram.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateRewardBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		// RewardProgram POJO class
		/*
		 * RewardProgramDetails rewardProgramDetails = new
		 * RewardProgramDetails(); rewardProgramDetails.setProgramId(322);
		 * rewardProgramDetails.setProgramBudget("3");
		 * rewardProgramDetails.setProgramDuration(0);
		 * rewardProgramDetails.setName("New Reward Program For API Testing");
		 * rewardProgramDetails.setRewardsType(1);
		 * rewardProgramDetails.setRecommendedType(1);
		 * rewardProgramDetails.setFranchisorId(2);
		 * rewardProgramDetails.setFranchisorName("Bean Me Up");
		 * rewardProgramDetails.setStartDate("2020-06-03T05:13:50.000Z");;;
		 * rewardProgramDetails.setEndDate("2020-06-24T18:29:59.000Z");
		 * rewardProgramDetails.setDuration(0);
		 * rewardProgramDetails.setEndafter(0);
		 * rewardProgramDetails.setOccurrences(0);
		 * rewardProgramDetails.setStage(1);
		 * rewardProgramDetails.setRewardTimezone("Asia/Calcutta");
		 * rewardProgramDetails.setAdminEmail("suganya.g@aximsoft.com");
		 * rewardProgramDetails.setUserName("Suganya Ganesan");
		 * rewardProgramDetails.setUserId(5);
		 * rewardProgramDetails.setCreatedAt("2020-96-03 06:44:00");
		 * rewardProgramDetails.setAccountId(0); RewardProgramActions
		 * rewardProgramActions = new RewardProgramActions();
		 * rewardProgramActions.setAction(1);
		 * rewardProgramActions.setProgram("assets_submitted");
		 * rewardProgramActions.setOperator(">=");
		 * rewardProgramActions.setValue(2);
		 * rewardProgramActions.setCondition("or");
		 * rewardProgramActions.setNonCashRewards("");
		 * rewardProgramActions.setGiftCost(1);
		 * rewardProgramActions.setEmployeesTodo("imgsVideos");
		 * rewardProgramActions.setRewards("15698660574");
		 * 
		 * List<RewardProgramActions> reProgramAction = new
		 * ArrayList<RewardProgramActions>();
		 * reProgramAction.add(rewardProgramActions); RewardProgramLocations
		 * rewardProgramLocations = new RewardProgramLocations();
		 * rewardProgramLocations.setAccounts(new ArrayList<String>());
		 * rewardProgramLocations.setFranchisors(new ArrayList<String>());
		 * rewardProgramLocations.setSelectedLocationCount(0);
		 */

		ObjectMapper mapper = new ObjectMapper();
		JSONObject object = new JSONObject();
		String json = null;
		JSONObject jsonObject;
		try {
			json = mapper.writeValueAsString(rewardProgram.getProgramDetails());
		} catch (JsonProcessingException e) {
		}
		jsonObject = new JSONObject(json);
		object.put("programDetails", jsonObject);
		try {
			json = mapper.writeValueAsString(rewardProgram.getProgramAction());
		} catch (JsonProcessingException e) {
		}
		JSONArray jsonArray = new JSONArray(json);
		object.put("programAction", jsonArray);
		try {
			json = mapper.writeValueAsString(rewardProgram.getProgramHuLocations());
		} catch (JsonProcessingException e) {
		}
		jsonObject = new JSONObject(json);
		object.put("programHuLocations", jsonObject);
		LogUtil.log("Json " + object.toString(), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).contentType(ContentType.JSON).body(object.toString()).when()
		        .post(new URI((String) payload.get("url")));
		int responseCode = response.statusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = new JsonPath(response.getBody().asString());
		String status = jsonPath.getString("status");
		Assert.assertEquals("success", status, "Failed to get success message");
		int programId = jsonPath.getInt("data.rewardsProgramId");
		return programId;
	}

	/**
	 * Edits the reward program.
	 *
	 * @param franchisorId the franchisor id
	 * @param token the token
	 * @param id the id
	 * @param rewardProgram the reward program
	 * @throws Exception the exception
	 */
	public static void editRewardProgram(String franchisorId, String token, int id, RewardProgram rewardProgram) throws Exception {

		LogUtil.log("Edit existing Reward Program", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/createRewardProgram.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateRewardBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);

		// RewardProgram POJO class
		/*
		 * RewardProgramDetails rewardProgramDetails = new
		 * RewardProgramDetails(); rewardProgramDetails.setProgramId(322);
		 * rewardProgramDetails.setProgramBudget("3");
		 * rewardProgramDetails.setProgramDuration(0);
		 * rewardProgramDetails.setName("New Reward Program For API Testing");
		 * rewardProgramDetails.setRewardsType(1);
		 * rewardProgramDetails.setRecommendedType(1);
		 * rewardProgramDetails.setFranchisorId(2);
		 * rewardProgramDetails.setFranchisorName("Bean Me Up");
		 * rewardProgramDetails.setStartDate("2020-06-03T05:13:50.000Z");;;
		 * rewardProgramDetails.setEndDate("2020-06-24T18:29:59.000Z");
		 * rewardProgramDetails.setDuration(0);
		 * rewardProgramDetails.setEndafter(0);
		 * rewardProgramDetails.setOccurrences(0);
		 * rewardProgramDetails.setStage(1);
		 * rewardProgramDetails.setRewardTimezone("Asia/Calcutta");
		 * rewardProgramDetails.setAdminEmail("suganya.g@aximsoft.com");
		 * rewardProgramDetails.setUserName("Suganya Ganesan");
		 * rewardProgramDetails.setUserId(5);
		 * rewardProgramDetails.setCreatedAt("2020-96-03 06:44:00");
		 * rewardProgramDetails.setAccountId(0); RewardProgramActions
		 * rewardProgramActions = new RewardProgramActions();
		 * rewardProgramActions.setAction(1);
		 * rewardProgramActions.setProgram("assets_submitted");
		 * rewardProgramActions.setOperator(">=");
		 * rewardProgramActions.setValue(2);
		 * rewardProgramActions.setCondition("or");
		 * rewardProgramActions.setNonCashRewards("");
		 * rewardProgramActions.setGiftCost(1);
		 * rewardProgramActions.setEmployeesTodo("imgsVideos");
		 * rewardProgramActions.setRewards("15698660574");
		 * 
		 * List<RewardProgramActions> reProgramAction = new
		 * ArrayList<RewardProgramActions>();
		 * reProgramAction.add(rewardProgramActions); RewardProgramLocations
		 * rewardProgramLocations = new RewardProgramLocations();
		 * rewardProgramLocations.setAccounts(new ArrayList<String>());
		 * rewardProgramLocations.setFranchisors(new ArrayList<String>());
		 * rewardProgramLocations.setSelectedLocationCount(0);
		 */

		ObjectMapper mapper = new ObjectMapper();
		JSONObject object = new JSONObject();
		String json = null;
		JSONObject jsonObject;
		try {
			json = mapper.writeValueAsString(rewardProgram.getProgramDetails());
		} catch (JsonProcessingException e) {
		}
		jsonObject = new JSONObject(json);
		object.put("programDetails", jsonObject);
		try {
			json = mapper.writeValueAsString(rewardProgram.getProgramAction());
		} catch (JsonProcessingException e) {
		}
		JSONArray jsonArray = new JSONArray(json);
		object.put("programAction", jsonArray);
		try {
			json = mapper.writeValueAsString(rewardProgram.getProgramHuLocations());
		} catch (JsonProcessingException e) {
		}
		jsonObject = new JSONObject(json);
		object.put("programHuLocations", jsonObject);
		LogUtil.log("Json " + object.toString(), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).contentType(ContentType.JSON).body(object.toString()).when()
		        .put(new URI((String) payload.get("url")));
		int responseCode = response.statusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = new JsonPath(response.getBody().asString());
		String status = jsonPath.getString("status");
		Assert.assertEquals("success", status, "Failed to get success message");
	}

	/**
	 * Delete reward program.
	 *
	 * @param token the token
	 * @param id the id
	 * @param paymentSubscriptionId the payment subscription id
	 * @throws Exception the exception
	 */
	public static void deleteRewardProgram(String token, int id, String paymentSubscriptionId) throws Exception {

		LogUtil.log("Delete existing Reward Program", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/createRewardProgram.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateRewardBaseURL());
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("id", id);
		jsonObject.put("recurringPaymentSubscriptionId", paymentSubscriptionId);
		jsonObject.put("showModal", true);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).contentType(ContentType.JSON).body(jsonObject.toString()).when()
		        .delete(new URI((String) payload.get("url")));
		int responseCode = response.statusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = new JsonPath(response.getBody().asString());
		String status = jsonPath.getString("status");
		Assert.assertEquals("success", status, "Failed to get success message");
	}

	/**
	 * Gets the account switcher.
	 *
	 * @param token the token
	 * @param franchisorId the franchisor id
	 * @return the account switcher
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static AccountSwticher getAccountSwitcher(String token, String franchisorId) throws Exception {

		LogUtil.log("Get Account Switcher", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getAccountSwitcher.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		ObjectMapper objectMapper = new ObjectMapper();
		AccountSwticher accountSwticher = objectMapper.readValue(responseBody, AccountSwticher.class);
		return accountSwticher;
	}

	/**
	 * Search post page.
	 *
	 * @param token the token
	 * @param franchisorId the franchisor id
	 * @param searchContent the search content
	 * @param postsTypeEnum the posts type enum
	 * @return the response
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static Response searchPostPage(String token, String franchisorId, String searchContent, PostsTypeEnum postsTypeEnum) throws Exception {

		LogUtil.log("Search Post Page", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/postpagesearch.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		inputData = inputData.replace("$searchText", searchContent);
		inputData = setPostsPageFilter(inputData, postsTypeEnum);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		return response;
	}

	/**
	 * Filter leader board advocacy posts.
	 *
	 * @param token the token
	 * @param accountType the account type
	 * @param franchisorId the franchisor id
	 * @param date the date
	 * @param leaderBoardListType the leader board list type
	 * @return the advocacy posts
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static AdvocacyPosts filterLeaderBoardAdvocacyPosts(String token, AccountType accountType, String franchisorId, String date, LeaderBoardListType leaderBoardListType)
	        throws Exception {

		LogUtil.log("Advocacy Filter LeaderBoard Page", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/leaderboardFilterAdvocacyPosts.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$dateRange", date);
		inputData = inputData.replace("$list", leaderBoardListType.getType());
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		HashMap<String, Object> map = (HashMap<String, Object>) payload.get("parameters");
		switch (accountType) {
		case FRANCHISOR:
			map.put("franchisor_id", franchisorId);
			break;

		case LOCATION:
			map.put("account_id", franchisorId);
			break;
		default:
			break;
		}
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + map, LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) map).get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		String responseBody = response.getBody().asString();
		ObjectMapper mapper = new ObjectMapper();
		AdvocacyPosts advocacyPosts = mapper.readValue(responseBody, AdvocacyPosts.class);
		return advocacyPosts;

	}

	/**
	 * Filter leader board assets submitted.
	 *
	 * @param token the token
	 * @param accountType the account type
	 * @param franchisorId the franchisor id
	 * @param date the date
	 * @param leaderBoardListType the leader board list type
	 * @return the assets submitted
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static AssetsSubmitted filterLeaderBoardAssetsSubmitted(String token, AccountType accountType, String franchisorId, String date, LeaderBoardListType leaderBoardListType)
	        throws Exception {

		LogUtil.log("Assets Submitted Filter LeaderBoard Page", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/leaderboardFilterAssetsSubmitted.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$dateRange", date);
		inputData = inputData.replace("$list", leaderBoardListType.getType());
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		HashMap<String, Object> map = (HashMap<String, Object>) payload.get("parameters");
		switch (accountType) {
		case FRANCHISOR:
			map.put("franchisor_id", franchisorId);
			break;

		case LOCATION:
			map.put("account_id", franchisorId);
			break;
		default:
			break;
		}
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + map, LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) map).get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		ObjectMapper mapper = new ObjectMapper();
		AssetsSubmitted assets = mapper.readValue(responseBody, AssetsSubmitted.class);
		return assets;
	}

	/**
	 * Filter leader board engagement from assets.
	 *
	 * @param token the token
	 * @param accountType the account type
	 * @param franchisorId the franchisor id
	 * @param date the date
	 * @param leaderBoardListType the leader board list type
	 * @return the engagement from assets
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static EngagementFromAssets filterLeaderBoardEngagementFromAssets(String token, AccountType accountType, String franchisorId, String date,
	        LeaderBoardListType leaderBoardListType) throws Exception {

		LogUtil.log("Engagements From Assets Filter LeaderBoard Page", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/leaderboardFilterEngagementFromAssets.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$dateRange", date);
		inputData = inputData.replace("$list", leaderBoardListType.getType());
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		HashMap<String, Object> map = (HashMap<String, Object>) payload.get("parameters");
		switch (accountType) {
		case FRANCHISOR:
			map.put("franchisor_id", franchisorId);
			break;

		case LOCATION:
			map.put("account_id", franchisorId);
			break;
		default:
			break;
		}
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + map, LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) map).get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		String responseBody = response.getBody().asString();
		ObjectMapper mapper = new ObjectMapper();
		EngagementFromAssets engagementFromAssets = mapper.readValue(responseBody, EngagementFromAssets.class);
		return engagementFromAssets;

	}

	/**
	 * Filter leader board total score.
	 *
	 * @param token the token
	 * @param accountType the account type
	 * @param franchisorId the franchisor id
	 * @param date the date
	 * @param leaderBoardListType the leader board list type
	 * @return the total score
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static TotalScore filterLeaderBoardTotalScore(String token, AccountType accountType, String franchisorId, String date, LeaderBoardListType leaderBoardListType)
	        throws Exception {

		LogUtil.log("TotalScore Filter LeaderBoard Page", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/leaderboardFilterTotalScore.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$dateRange", date);
		inputData = inputData.replace("$list", leaderBoardListType.getType());
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		HashMap<String, Object> map = (HashMap<String, Object>) payload.get("parameters");
		switch (accountType) {
		case FRANCHISOR:
			map.put("franchisor_id", franchisorId);
			break;

		case LOCATION:
			map.put("account_id", franchisorId);
			break;
		default:
			break;
		}
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + map, LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) map).when().get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		String responseBody = response.getBody().asString();
		ObjectMapper mapper = new ObjectMapper();
		TotalScore totalScore = mapper.readValue(responseBody, TotalScore.class);
		return totalScore;

	}

	/**
	 * Filter rewards program.
	 *
	 * @param token the token
	 * @param franchisorId the franchisor id
	 * @param rewardProgramsEnum the reward programs enum
	 * @return the response
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static Response filterRewardsProgram(String token, String franchisorId, RewardProgramsTypeEnum rewardProgramsEnum) throws Exception {

		LogUtil.log("Filter RewardPrograms Page", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/rewardProgramFilter.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateRewardBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		inputData = setRewardProgramsFilter(inputData, rewardProgramsEnum);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		return response;
	}

	/**
	 * Search reward program page.
	 *
	 * @param token the token
	 * @param franchisorId the franchisor id
	 * @param searchText the search text
	 * @param rewardProgramsEnum the reward programs enum
	 * @return the response
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static Response searchRewardProgramPage(String token, String franchisorId, String searchText, RewardProgramsTypeEnum rewardProgramsEnum) throws Exception {

		LogUtil.log("Search RewardPrograms Page", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/rewardProgramPageSearch.json");
		inputData = String.format(inputData, "https://app-api.rall.io");
		inputData = inputData.replace("$franchisorId", franchisorId);
		inputData = inputData.replace("$searchText", searchText);
		inputData = setRewardProgramsFilter(inputData, rewardProgramsEnum);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		return response;
	}

	/**
	 * Gets the favourite tags.
	 *
	 * @param token the token
	 * @param franchisorId the franchisor id
	 * @return the favourite tags
	 * @throws Exception the exception
	 */
	public static List<FavouriteTags> getFavouriteTags(String token, String franchisorId) throws Exception {

		LogUtil.log("Get Favourite Tags", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getFavouriteTags.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = new JsonPath(response.getBody().asString());
		List<FavouriteTags> listOfFavouriteTags = Arrays.asList(jsonPath.getObject(("favorite_tags"), FavouriteTags[].class));
		return listOfFavouriteTags;

	}

	/**
	 * Filter post page.
	 *
	 * @param token the token
	 * @param franchisorId the franchisor id
	 * @param postsTypeEnum the posts type enum
	 * @return the response
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static Response filterPostPage(String token, String franchisorId, PostsTypeEnum postsTypeEnum) throws Exception {

		LogUtil.log("Filter Posts Page", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/postPageFilter.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		inputData = setPostsPageFilter(inputData, postsTypeEnum);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		return response;
	}

	/**
	 * Search media gallery page.
	 *
	 * @param token the token
	 * @param franchisorId the franchisor id
	 * @param assetTypeEnum the asset type enum
	 * @param postUsageTypeEnum the post usage type enum
	 * @param mediaSourceTypeEnum the media source type enum
	 * @param mediaReleaseFormTypeEnum the media release form type enum
	 * @param dateRange the date range
	 * @param searchText the search text
	 * @return the response
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static Response searchMediaGalleryPage(String token, String franchisorId, AssetTypeEnum assetTypeEnum, PostUsageTypeEnum postUsageTypeEnum,
	        MediaSourceTypeEnum mediaSourceTypeEnum, MediaReleaseFormTypeEnum mediaReleaseFormTypeEnum, String dateRange, String searchText) throws Exception {

		LogUtil.log("Search MediaGallery Page", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/mediaGallerySearch.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		inputData = inputData.replace("$date_range", dateRange);
		inputData = inputData.replace("$searchText", searchText);
		inputData = setMediaGalleryFilter(inputData, assetTypeEnum, postUsageTypeEnum, mediaSourceTypeEnum, mediaReleaseFormTypeEnum);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		return response;
	}

	/**
	 * Filter media gallery page.
	 *
	 * @param token the token
	 * @param franchisorId the franchisor id
	 * @param assetTypeEnum the asset type enum
	 * @param postUsageTypeEnum the post usage type enum
	 * @param mediaSourceTypeEnum the media source type enum
	 * @param mediaReleaseFormTypeEnum the media release form type enum
	 * @param dateRange the date range
	 * @param searchText the search text
	 * @return the response
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static Response filterMediaGalleryPage(String token, String franchisorId, AssetTypeEnum assetTypeEnum, PostUsageTypeEnum postUsageTypeEnum,
	        MediaSourceTypeEnum mediaSourceTypeEnum, MediaReleaseFormTypeEnum mediaReleaseFormTypeEnum, String dateRange, String searchText) throws Exception {

		LogUtil.log("Filter MediaGallery Page", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/mediaGalleryFilter.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		inputData = inputData.replace("$date_range", dateRange);
		inputData = setMediaGalleryFilter(inputData, assetTypeEnum, postUsageTypeEnum, mediaSourceTypeEnum, mediaReleaseFormTypeEnum);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(response.getBody().asString(), LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		return response;
	}

	/**
	 * Gets the total assets stats.
	 *
	 * @param franchisorId the franchisor id
	 * @param token the token
	 * @return the total assets stats
	 * @throws Exception the exception
	 */
	public static TotalAssetsStats getTotalAssetsStats(String franchisorId, String token) throws Exception {

		LogUtil.log("Get Total Assets Stats", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/assetsStats.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).when()
		        .get(new URI((String) payload.get("url")));
		String responseBody = response.getBody().asString();
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		ObjectMapper objectMapper = new ObjectMapper();
		TotalAssetsStats totalAssetsStats = objectMapper.readValue(responseBody, TotalAssetsStats.class);
		return totalAssetsStats;
	}

	/**
	 * Gets the reward program stats.
	 *
	 * @param accountType the account type
	 * @param franchisorId the franchisor id
	 * @param token the token
	 * @return the reward program stats
	 * @throws Exception the exception
	 */
	public static RewardProgramStats getRewardProgramStats(AccountType accountType, String franchisorId, String token) throws Exception {

		LogUtil.log("Get RewardProgram Stats API", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/rewardProgramStats.json");
		inputData = String.format(inputData, "https://app-api.rall.io");
		inputData = inputData.replace("$franchisorId", franchisorId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		HashMap<String, Object> map = (HashMap<String, Object>) payload.get("parameters");
		switch (accountType) {
		case FRANCHISOR:
			map.put("franchisorId", franchisorId);
			break;

		case LOCATION:
			map.put("accountId", franchisorId);
			break;
		default:
			break;
		}
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + map, LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).header("Content-Type", "application/json").queryParams((Map<String, ?>) map).when()
		        .get(new URI((String) payload.get("url")));
		String responseBody = response.getBody().asString();
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = response.jsonPath();
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals("success", jsonPath.get("status"), "No Success Message Found");
		RewardProgramStats rewardProgramStats = jsonPath.getObject(("data.pageStats"), RewardProgramStats.class);
		rewardProgramStats.setTotalPageCount(jsonPath.getInt("data.totalPageCount"));
		return rewardProgramStats;

	}

	/**
	 * Gets the brand and hubs.
	 *
	 * @param franchisorId the franchisor id
	 * @param token the token
	 * @param accountType the account type
	 * @return the brand and hubs
	 * @throws Exception the exception
	 */
	public static BrandAndHubs getBrandAndHubs(String franchisorId, String token, AccountType accountType) throws Exception {

		LogUtil.log("Get Brand&Hubs API", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/brand_hubs_location.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		HashMap<String, String> map = new HashMap<>();
		switch (accountType) {
		case FRANCHISOR:
			map.put("franchisor_id", franchisorId);
			break;

		case LOCATION:
			map.put("account_id", franchisorId);
			break;
		default:
			Assert.assertTrue(false, "Invalid Account Type Specified:" + accountType.name());
			break;
		}
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		payload.put("parameters", map);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).when()
		        .get(new URI((String) payload.get("url")));
		String responseBody = response.getBody().asString();
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = response.jsonPath();
		LogUtil.log(" ", LogLevel.LOW);
		BrandAndHubs brandAndHubs = new BrandAndHubs();
		switch (accountType) {
		case FRANCHISOR:
			List<Franchisors> franchisors = new ArrayList<Franchisors>();
			franchisors.addAll(Arrays.asList(jsonPath.getObject(("brand_hubs_locations.franchisors"), Franchisors[].class)));
			try {
				franchisors.addAll(Arrays.asList(jsonPath.getObject(("brand_hubs_locations.franchisors[0].franchisors"), Franchisors[].class)));
			} catch (Exception e) {
				LogUtil.log("No Child Franchisor Found", LogLevel.LOW);
			}
			brandAndHubs.setFranchisors(franchisors);
			break;
		case LOCATION:
			brandAndHubs.setAccounts(Arrays.asList(jsonPath.getObject(("brand_hubs_locations.account"), AccountsList[].class)));
			break;
		default:
			Assert.assertTrue(false, "Invalid Account Type Specified:" + accountType.name());
			break;

		}
		return brandAndHubs;
	}

	/**
	 * Gets the all assets.
	 *
	 * @param franchisorId the franchisor id
	 * @param token the token
	 * @return the all assets
	 * @throws Exception the exception
	 */
	public static List<Assets> getAllAssets(String franchisorId, String token) throws Exception {

		LogUtil.log("Get All Assets API", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getAllAssets.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).when()
		        .get(new URI((String) payload.get("url")));
		String responseBody = response.getBody().asString();
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = response.jsonPath();
		LogUtil.log(" ", LogLevel.LOW);
		List<Assets> assets = Arrays.asList(jsonPath.getObject(("assets"), Assets[].class));
		return assets;
	}

	/**
	 * Gets the all contents.
	 *
	 * @param franchisorId the franchisor id
	 * @param token the token
	 * @return the all contents
	 * @throws Exception the exception
	 */
	public static List<Contents> getAllContents(String franchisorId, String token) throws Exception {

		LogUtil.log("Get All Assets API", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getAllContents.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).when()
		        .get(new URI((String) payload.get("url")));
		String responseBody = response.getBody().asString();
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = response.jsonPath();
		LogUtil.log(" ", LogLevel.LOW);
		List<Contents> contents = Arrays.asList(jsonPath.getObject(("contents"), Contents[].class));
		return contents;

	}

	/**
	 * Gets the specific content.
	 *
	 * @param franchisorId the franchisor id
	 * @param token the token
	 * @param id the id
	 * @return the specific content
	 * @throws Exception the exception
	 */
	public static Contents getSpecificContent(String franchisorId, String token, int id) throws Exception {

		LogUtil.log("Get Content API", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getSpecificContent.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		inputData = inputData.replace("$id", String.valueOf(id));
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).when()
		        .get(new URI((String) payload.get("url")));
		String responseBody = response.getBody().asString();
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = response.jsonPath();
		LogUtil.log(" ", LogLevel.LOW);
		Contents contents = jsonPath.getObject(("content"), Contents.class);
		return contents;
	}

	/**
	 * Gets the specific asset.
	 *
	 * @param franchisorId the franchisor id
	 * @param token the token
	 * @param id the id
	 * @param mediaType the media type
	 * @return the specific asset
	 * @throws Exception the exception
	 */
	public static Assets getSpecificAsset(String franchisorId, String token, int id, String mediaType) throws Exception {

		LogUtil.log("Get Asset API", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getSpecificAsset.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		inputData = inputData.replace("$id", String.valueOf(id));
		inputData = inputData.replace("$mediaType", mediaType);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).when()
		        .get(new URI((String) payload.get("url")));
		String responseBody = response.getBody().asString();
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = response.jsonPath();
		LogUtil.log(" ", LogLevel.LOW);
		Assets asset = jsonPath.getObject(("asset"), Assets.class);
		return asset;
	}

	/**
	 * Delete specific asset.
	 *
	 * @param token the token
	 * @param id the id
	 * @param mediaType the media type
	 * @throws Exception the exception
	 */
	public static void deleteSpecificAsset(String token, int id, String mediaType) throws Exception {

		LogUtil.log("Delete Asset API", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getSpecificAsset.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$id", String.valueOf(id));
		inputData = inputData.replace("$mediaType", mediaType);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).when()
		        .delete(new URI((String) payload.get("url")));
		String responseBody = response.getBody().asString();
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = response.jsonPath();
		LogUtil.log(" ", LogLevel.LOW);
	}

	/**
	 * Delete specific content.
	 *
	 * @param token the token
	 * @param id the id
	 * @return the contents
	 * @throws Exception the exception
	 */
	public static Contents deleteSpecificContent(String token, int id) throws Exception {

		LogUtil.log("Delete Content API", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getSpecificContent.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$id", String.valueOf(id));
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).when().delete(new URI((String) payload.get("url")));
		String responseBody = response.getBody().asString();
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = response.jsonPath();
		LogUtil.log(" ", LogLevel.LOW);
		Contents contents = jsonPath.getObject(("content"), Contents.class);
		return contents;
	}

	/**
	 * Creates the content.
	 *
	 * @param franchisorId the franchisor id
	 * @param token the token
	 * @param inputContent the input content
	 * @return the contents
	 * @throws Exception the exception
	 */
	public static Contents createContent(String franchisorId, String token, Content inputContent) throws Exception {

		LogUtil.log("Create Content API", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/createContent.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		List<Integer> photList = new ArrayList<>();
		JSONObject object = new JSONObject();
		/*
		 * Content inputContent = new Content();
		 * inputContent.setFacebook_text("facebook_text23");
		 * inputContent.setFranchisor_id(StringUtil.convertStringToInteger(
		 * franchisorId)); inputContent.setTags_list("Waters");
		 * inputContent.setSent_to_franchisor(true);
		 * inputContent.setPhoto_ids(photList); inputContent.setVideo_id("");
		 * inputContent.setUse_facebook(true);
		 * inputContent.setUse_google(false);
		 * inputContent.setUse_instagram(true);
		 * inputContent.setUse_linkedin(true);
		 * inputContent.setUse_twitter(true);
		 */
		ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(inputContent);
		} catch (JsonProcessingException e) {
		}
		JSONObject jsonObj = new JSONObject(json);
		object.put("content", jsonObj);
		object.put("userOwnership", "franchisor");
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).body(object.toString()).contentType(ContentType.JSON).when()
		        .post(new URI((String) payload.get("url")));
		String responseBody = response.getBody().asString();
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = response.jsonPath();
		LogUtil.log(" ", LogLevel.LOW);
		Contents responseContent = jsonPath.getObject(("content"), Contents.class);
		Assert.assertEquals(responseContent.getFacebook_text(), inputContent.getFacebook_text(), "Contents Not Matched");
		return responseContent;
	}

	/**
	 * Edits the content.
	 *
	 * @param franchisorId the franchisor id
	 * @param token the token
	 * @param id the id
	 * @param inputContent the input content
	 * @return the contents
	 * @throws Exception the exception
	 */
	public static Contents editContent(String franchisorId, String token, int id, Content inputContent) throws Exception {

		LogUtil.log("Edit Content API", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/editContent.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateBaseURL());
		inputData = inputData.replace("$franchisorId", franchisorId);
		inputData = inputData.replace("$id", String.valueOf(id));
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		List<Integer> photList = new ArrayList<>();
		JSONObject object = new JSONObject();
		/*
		 * Content inputContent = new Content();
		 * inputContent.setFacebook_text("API Test Post");
		 * inputContent.setFranchisor_id(StringUtil.convertStringToInteger(
		 * franchisorId)); inputContent.setTags_list("Waters");
		 * inputContent.setSent_to_franchisor(true);
		 * inputContent.setPhoto_ids(photList); inputContent.setVideo_id("");
		 * inputContent.setUse_facebook(true);
		 * inputContent.setUse_google(false);
		 * inputContent.setUse_instagram(true);
		 * inputContent.setUse_linkedin(true);
		 * inputContent.setUse_twitter(true);
		 */
		ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(inputContent);
		} catch (JsonProcessingException e) {
		}
		JSONObject jsonObj = new JSONObject(json);
		object.put("content", jsonObj);
		object.put("userOwnership", "franchisor");
		object.put("isEditPost", true);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).contentType(ContentType.JSON).body(object.toString()).when()
		        .put(new URI((String) payload.get("url")));
		String responseBody = response.getBody().asString();
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = response.jsonPath();
		LogUtil.log(" ", LogLevel.LOW);
		Contents responseContent = jsonPath.getObject(("content"), Contents.class);
		Assert.assertEquals(responseContent.getFacebook_text(), inputContent.getFacebook_text(), "Contents Not Matched");
		return responseContent;
	}

	/**
	 * Gets the achievers list.
	 *
	 * @param token the token
	 * @param id the id
	 * @return the achievers list
	 * @throws Exception the exception
	 */
	public static List<AchieversList> getAchieversList(String token, int id) throws Exception {

		LogUtil.log("Get Achievers List API", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getAchieversList.json");
		inputData = String.format(inputData, APIUtil.getRallioActivateRewardBaseURL());
		inputData = inputData.replace("$id", String.valueOf(id));
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).when().get(new URI((String) payload.get("url")));
		String responseBody = response.getBody().asString();
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = response.jsonPath();
		LogUtil.log(" ", LogLevel.LOW);
		String status = jsonPath.getString("status");
		Assert.assertEquals("success", status, "Success Status is not received");
		List<AchieversList> achieversList = Arrays.asList(jsonPath.getObject(("data.achieversList"), AchieversList[].class));
		return achieversList;
	}

	/**
	 * Gets the stripe session.
	 *
	 * @return the stripe session
	 * @throws Exception the exception
	 */
	public static String getStripeSession() throws Exception {

		LogUtil.log("Get Stripe Session API", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/stripelogin.json");
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().body(payload.get("parameters")).when().post(new URI((String) payload.get("url")));
		String responseBody = response.getBody().asString();
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = response.jsonPath();
		String status = jsonPath.getString("status");
		Assert.assertEquals("true", status, "Success Status is not received");
		LogUtil.log(" ", LogLevel.LOW);
		String bearerToken = jsonPath.getString("token");
		return bearerToken;
	}

	/**
	 * Gets the promotion list.
	 *
	 * @param bearerToken the bearer token
	 * @return the promotion list
	 * @throws Exception the exception
	 */
	public static PromotionList getPromotionList(String bearerToken) throws Exception {

		LogUtil.log(Steps.START, "Get PromotionList API");
		String inputData = FileUtil.getStringData("RallioActivateAPIs/promotion.json");
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("Authorization", "Bearer " + bearerToken).when().get(new URI((String) payload.get("url")));
		String responseBody = response.getBody().asString();
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = response.jsonPath();
		LogUtil.log(" ", LogLevel.LOW);
		String status = jsonPath.getString("status");
		Assert.assertEquals("true", status, "Success Status is not received");
		ObjectMapper objectMapper = new ObjectMapper();
		PromotionList promotionList = objectMapper.readValue(responseBody, PromotionList.class);
		return promotionList;
	}

	/**
	 * Gets the credit cards.
	 *
	 * @param token the token
	 * @param userEmail the user email
	 * @return the credit cards
	 * @throws Exception the exception
	 */
	public static List<CreditCard> getCreditCards(String token, String userEmail) throws Exception {

		LogUtil.log(Steps.START, "Get CreditCards API");
		String inputData = FileUtil.getStringData("RallioActivateAPIs/getCreditCardDetails.json");
		inputData = inputData.replace("$userEmail", userEmail);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).header("authorization", payload.get("authorization"))
		        .queryParams((Map<String, ?>) payload.get("parameters")).when().get(new URI((String) payload.get("url")));
		String responseBody = response.getBody().asString();
		Assert.assertNotNull(response.getBody(), "Recieved Null Response");
		int responseCode = response.getStatusCode();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		JsonPath jsonPath = response.jsonPath();
		LogUtil.log(" ", LogLevel.LOW);
		List<CreditCard> creditCards = Arrays.asList(jsonPath.getObject(("data"), CreditCard[].class));
		return creditCards;
	}

	/**
	 * Gets the community management stats.
	 *
	 * @param token the token
	 * @param franchisorId the franchisor id
	 * @return the community management stats
	 * @throws Exception the exception
	 */
	public static CommunityManagementStatsData getCommunityManagementStats(String token, String franchisorId) throws Exception {

		LogUtil.log("Get Community Management stats", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/community_management_stats.json");
		inputData = String.format(inputData, "https://app-api.rall.io");
		inputData = inputData.replace("$franchisorId", franchisorId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		HashMap<String, Object> map = (HashMap<String, Object>) payload.get("parameters");
		map.put("franchisorId", franchisorId);
		LogUtil.log("URL :" + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters :" + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).header("Content-Type", "application/json").queryParams((Map<String, ?>) map).when()
		        .get(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		JsonPath jsonPath = new JsonPath(responseBody);
		CommunityManagementStatsData communityManagementStats = jsonPath.getObject(("data"), CommunityManagementStatsData.class);
		return communityManagementStats;
	}

	/**
	 * Gets the community management advocates list.
	 *
	 * @param token the token
	 * @param franchisorId the franchisor id
	 * @return the community management advocates list
	 * @throws Exception the exception
	 */
	public static List<CommunityManagementAdvocatesData> getCommunityManagementAdvocatesList(String token, String franchisorId) throws Exception {

		LogUtil.log("Get Community Management advocates list", LogLevel.LOW);
		String inputData = FileUtil.getStringData("RallioActivateAPIs/community_management.json");
		inputData = String.format(inputData, "https://app-api.rall.io");
		inputData = inputData.replace("$franchisorId", franchisorId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		HashMap<String, Object> map = (HashMap<String, Object>) payload.get("parameters");
		map.put("franchisorId", franchisorId);
		LogUtil.log("URL :" + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Parameters :" + payload.get("parameters"), LogLevel.LOW);
		Response response = RestAssured.given().header("X-Rallio-API-Key", token).header("Content-Type", "application/json").queryParams((Map<String, ?>) map).when()
		        .get(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		JsonPath jsonPath = new JsonPath(responseBody);
		List<CommunityManagementAdvocatesData> advocatesList = Arrays.asList(jsonPath.getObject(("data"), CommunityManagementAdvocatesData[].class));
		return advocatesList;
	}

	/**
	 * Sets the media gallery filter.
	 *
	 * @param inputData the input data
	 * @param assetTypeEnum the asset type enum
	 * @param postUsageTypeEnum the post usage type enum
	 * @param mediaSourceTypeEnum the media source type enum
	 * @param mediaReleaseFormTypeEnum the media release form type enum
	 * @return the string
	 */
	public static String setMediaGalleryFilter(String inputData, AssetTypeEnum assetTypeEnum, PostUsageTypeEnum postUsageTypeEnum, MediaSourceTypeEnum mediaSourceTypeEnum,
	        MediaReleaseFormTypeEnum mediaReleaseFormTypeEnum) {

		inputData = inputData.replace("$mediaType", assetTypeEnum.getAssetType());
		inputData = inputData.replace("$sourceType", mediaSourceTypeEnum.getMediaSourceType());
		inputData = inputData.replace("$used", postUsageTypeEnum.getPostUsageType());
		inputData = inputData.replace("$mediaRelease", mediaReleaseFormTypeEnum.getMediaReleaseFormType());
		if (mediaSourceTypeEnum == MediaSourceTypeEnum.BRAND)
			inputData = inputData.replace("$copy_to_descendants", "1");
		return inputData;

	}

	/**
	 * Sets the reward porgrams filter.
	 *
	 * @param inputData the input data
	 * @param rewardProgramsEnum the reward programs enum
	 * @return the string
	 */
	public static String setRewardProgramsFilter(String inputData, RewardProgramsTypeEnum rewardProgramsEnum) {

		switch (rewardProgramsEnum) {

		case REWARD_PROGRAMS_ONLY:
			inputData = inputData.replace("$rewardProgram", "1").replace("$recommendedProgram", "");
			return inputData;
		case RECOMMENDED_PROGRAMS_ONLY:
			inputData = inputData.replace("$rewardProgram", "").replace("$recommendedProgram", "1");
			return inputData;
		case ALL:
			inputData = inputData.replace("$rewardProgram", "1").replace("$recommendedProgram", "1");
			return inputData;
		default:
			LogUtil.log("Invalid case: " + inputData, LogLevel.LOW);
			return inputData;
		}
	}

	/**
	 * Sets the posts page filter.
	 *
	 * @param inputData the input data
	 * @param postsTypeEnum the posts type enum
	 * @return the string
	 */
	public static String setPostsPageFilter(String inputData, PostsTypeEnum postsTypeEnum) {

		switch (postsTypeEnum) {

		case PUBLISHED:
			inputData = inputData.replace("$published", "1");
			return inputData;
		case NOT_PUBLISHED:
			inputData = inputData.replace("$published", "0");
			return inputData;
		case ALL:
			inputData = inputData.replace("$published", "");
			return inputData;
		default:
			LogUtil.log("Invalid case: " + inputData, LogLevel.LOW);
			return inputData;
		}
	}

}

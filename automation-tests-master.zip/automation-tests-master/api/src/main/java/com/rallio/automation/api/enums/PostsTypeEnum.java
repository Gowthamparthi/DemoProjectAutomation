package com.rallio.automation.api.enums;

public enum PostsTypeEnum {

	PUBLISHED,
	
	NOT_PUBLISHED,
	
	ALL;
}

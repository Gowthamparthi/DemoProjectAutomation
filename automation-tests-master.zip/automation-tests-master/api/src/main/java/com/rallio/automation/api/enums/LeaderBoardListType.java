package com.rallio.automation.api.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum LeaderBoardListType.
 */
public enum LeaderBoardListType {

	/** The employee. */
	EMPLOYEE("employee", "Employee"),

	/** The location. */
	LOCATION("location", "Locations");

	/** The list type. */
	private String listType;

	/** The text. */
	private String text;

	/**
	 * Instantiates a new leader board list type.
	 *
	 * @param listType the list type
	 * @param text the text
	 */
	private LeaderBoardListType(String listType, String text) {

		this.listType = listType;
		this.text = text;

	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {

		return listType;
	}

	/**
	 * Gets the text.
	 *
	 * @return the text
	 */
	public String getText() {

		return text;
	}

}

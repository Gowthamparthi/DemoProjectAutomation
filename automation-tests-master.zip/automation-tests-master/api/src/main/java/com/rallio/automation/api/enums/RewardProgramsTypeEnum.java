package com.rallio.automation.api.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum RewardProgramsEnum.
 */
public enum RewardProgramsTypeEnum {

	/** The reward programs only. */
	REWARD_PROGRAMS_ONLY,

	/** The recommended programs only. */
	RECOMMENDED_PROGRAMS_ONLY,

	/** The both. */
	ALL;
}

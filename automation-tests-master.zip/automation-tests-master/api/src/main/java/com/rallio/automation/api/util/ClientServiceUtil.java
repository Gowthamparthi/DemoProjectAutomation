package com.rallio.automation.api.util;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.client.JerseyClientBuilder;
import org.json.JSONException;

import com.google.gson.Gson;
import com.rallio.automation.api.entity.RequestEntity;
import com.rallio.automation.api.entity.ResponseEntity;
import com.rallio.automation.api.enums.ContentType;

// TODO: Auto-generated Javadoc
/**
 * The Class ClientServiceUtil.
 */
public final class ClientServiceUtil {

	/** The Constant client. */
	private static final Client client;

	static {
		ClientConfig config = new ClientConfig();
		config.property(ClientProperties.FOLLOW_REDIRECTS, false);

		client = JerseyClientBuilder.createClient(config);
	}

	/**
	 * Instantiates a new client service util.
	 */
	private ClientServiceUtil() {
	}

	/**
	 * Gets the.
	 *
	 * @param request the request
	 * @return the response entity
	 */
	public static ResponseEntity get(RequestEntity request) {

		ResponseEntity response = null;

		try {
			WebTarget webTarget = client.target(request.getUrl());

			if (request.getParameters() != null && request.getParameters().size() > 0) {
				webTarget = setQueryParam(webTarget, request.getParameters());
			}

			if (request.getObjParameters() != null && request.getObjParameters().size() > 0) {
				webTarget = setQueryParamFormObjectValue(webTarget, request.getObjParameters());
			}
			Builder builder = webTarget.request();

			if (request.getCookies() != null && request.getCookies().size() > 0) {
				setCookies(builder, request.getCookies());
			}

			Response output = builder.get();

			response = new ResponseEntity();
			response.setStatus(output.getStatus());
			response.setCookies(output.getCookies());

			if (String.valueOf(output.getStatus()).startsWith("3")) {
				response.setLocation((String) output.getHeaders().getFirst("Location"));
			} else {
				response.setResponse(output.readEntity(String.class));
			}
		} catch (Exception e) {
			e.printStackTrace();
			// throw new CommonException(e);
		}

		return response;
	}

	/**
	 * Gets the.
	 *
	 * @param request             the request
	 * @param authourizationToken the authourization token
	 * @return the response entity
	 */
	public static ResponseEntity get(RequestEntity request, String authourizationToken) {

		ResponseEntity response = null;

		try {
			WebTarget webTarget = client.target(request.getUrl());

			if (request.getParameters() != null && request.getParameters().size() > 0) {
				webTarget = setQueryParam(webTarget, request.getParameters());
			}

			if (request.getObjParameters() != null && request.getObjParameters().size() > 0) {
				webTarget = setQueryParamFormObjectValue(webTarget, request.getObjParameters());
			}
			Builder builder = webTarget.request().header(HttpHeaders.AUTHORIZATION, authourizationToken);

			if (request.getCookies() != null && request.getCookies().size() > 0) {
				setCookies(builder, request.getCookies());
			}

			Response output = builder.get();

			response = new ResponseEntity();
			response.setStatus(output.getStatus());
			response.setCookies(output.getCookies());

			if (String.valueOf(output.getStatus()).startsWith("3")) {
				response.setLocation((String) output.getHeaders().getFirst("Location"));
			} else {
				response.setResponse(output.readEntity(String.class));
			}
		} catch (Exception e) {
			e.printStackTrace();
			// throw new CommonException(e);
		}

		return response;
	}

	/**
	 * Post form data.
	 *
	 * @param request the request
	 * @return the response entity
	 */
	public static ResponseEntity postFormData(RequestEntity request) {

		ResponseEntity response = null;

		try {
			WebTarget webTarget = client.target(request.getUrl());
			Builder builder = webTarget.request();

			if (request.getCookies() != null && request.getCookies().size() > 0) {
				setCookies(builder, request.getCookies());
			}

			Response output = null;

			if (request.getContentType().equals(ContentType.FORM_DATA)) {
				output = builder.post(
						Entity.entity(getFormObjParam(request.getParameters()), MediaType.APPLICATION_FORM_URLENCODED));
			}
			response = new ResponseEntity();
			response.setStatus(output.getStatus());
			response.setCookies(output.getCookies());

			if (String.valueOf(output.getStatus()).startsWith("3")) {
				response.setLocation((String) output.getHeaders().getFirst("Location"));
			} else {
				response.setResponse(output.readEntity(String.class));
			}

		} catch (Exception e) {
			e.printStackTrace();
			// throw new CommonException(e);
		}
		return response;
	}

	/**
	 * Post multi part form data.
	 *
	 * @param request the request
	 * @return the response entity
	 */

	/**
	 * Post.
	 *
	 * @param request the request
	 * @return the response entity
	 */
	public static ResponseEntity post(RequestEntity request) {

		ResponseEntity response = null;

		try {
			WebTarget webTarget = client.target(request.getUrl());

			if (request.getObjParameters() != null && request.getObjParameters().size() > 0) {
				webTarget = setQueryParamFormObjectValue(webTarget, request.getObjParameters());
			}
			Builder builder = webTarget.request();
			if (request.getCookies() != null && request.getCookies().size() > 0) {
				setCookies(builder, request.getCookies());
			}

			Response output = null;

			if (request.getContentType().equals(ContentType.JSON)) {
				output = builder.post(Entity.entity(request.getBodyContent(), MediaType.APPLICATION_JSON));
			} else if (request.getContentType().equals(ContentType.XML)) {
				output = builder.post(Entity.entity(request.getBodyContent(), MediaType.APPLICATION_XML));
			} else if (request.getContentType().equals(ContentType.FORM_DATA)) {
				output = builder.post(
						Entity.entity(getFormParam(request.getParameters()), MediaType.APPLICATION_FORM_URLENCODED));
			} else {
				output = builder.post(Entity.text(""));
			}

			response = new ResponseEntity();
			response.setStatus(output.getStatus());
			response.setCookies(output.getCookies());

			if (String.valueOf(output.getStatus()).startsWith("3")) {
				response.setLocation((String) output.getHeaders().getFirst("Location"));
			} else {
				response.setResponse(output.readEntity(String.class));
			}
		} catch (Exception e) {
			e.printStackTrace();
			// throw new CommonException(e);
		}

		return response;
	}

	/**
	 * Post request with header.
	 *
	 * @param request the request
	 * @return the response entity
	 */
	public static ResponseEntity postRequestWithHeader(RequestEntity request) {

		ResponseEntity response = null;

		try {

			WebTarget webTarget = client.target(request.getUrl());

			if (request.getObjParameters() != null && request.getObjParameters().size() > 0) {
				webTarget = setQueryParamFormObjectValue(webTarget, request.getObjParameters());
			}

			Builder builder = null;

			MultivaluedMap<String, Object> form = new MultivaluedHashMap<>();

			if (request.getObjHeader() != null && request.getObjHeader().size() > 0) {

				for (Map.Entry<String, String> entry : request.getObjHeader().entrySet()) {
					form.add(entry.getKey(), entry.getValue());
				}
				builder = webTarget.request(MediaType.TEXT_PLAIN).headers(form);

			}

			if (request.getCookies() != null && request.getCookies().size() > 0) {
				setCookies(builder, request.getCookies());
			}

			Response output = null;

			if (request.getContentType().equals(ContentType.JSON)) {
				output = builder.post(Entity.entity(request.getBodyContent(), MediaType.APPLICATION_JSON));
			} else if (request.getContentType().equals(ContentType.XML)) {
				output = builder.post(Entity.entity(request.getBodyContent(), MediaType.APPLICATION_XML));
			} else if (request.getContentType().equals(ContentType.FORM_DATA)) {
				output = builder.post(
						Entity.entity(getFormParam(request.getParameters()), MediaType.APPLICATION_FORM_URLENCODED));
			} else {
				output = builder.post(Entity.text(""));
			}

			response = new ResponseEntity();
			response.setStatus(output.getStatus());
			response.setCookies(output.getCookies());

			if (String.valueOf(output.getStatus()).startsWith("3")) {
				response.setLocation((String) output.getHeaders().getFirst("Location"));
			} else {
				response.setResponse(output.readEntity(String.class));
			}

		} catch (Exception e) {
			e.printStackTrace();
			// throw new CommonException(e);
		}

		return response;
	}

	/**
	 * Post.
	 *
	 * @param request             the request
	 * @param authourizationToken the authourization token
	 * @return the response entity
	 */
	public static ResponseEntity post(RequestEntity request, String authourizationToken) {

		ResponseEntity response = null;

		try {
			WebTarget webTarget = client.target(request.getUrl());

			if (request.getObjParameters() != null && request.getObjParameters().size() > 0) {
				webTarget = setQueryParamFormObjectValue(webTarget, request.getObjParameters());
			}

			Builder builder = webTarget.request().header(HttpHeaders.AUTHORIZATION, authourizationToken);
			if (request.getCookies() != null && request.getCookies().size() > 0) {
				setCookies(builder, request.getCookies());
			}

			Response output = null;

			if (request.getContentType().equals(ContentType.JSON)) {
				output = builder.post(Entity.entity(request.getBodyContent(), MediaType.APPLICATION_JSON));
			} else if (request.getContentType().equals(ContentType.XML)) {
				output = builder.post(Entity.entity(request.getBodyContent(), MediaType.APPLICATION_XML));
			} else if (request.getContentType().equals(ContentType.FORM_DATA)) {
				output = builder.post(
						Entity.entity(getFormParam(request.getParameters()), MediaType.APPLICATION_FORM_URLENCODED));
			} else {
				output = builder.post(Entity.text(""));
			}

			response = new ResponseEntity();
			response.setStatus(output.getStatus());
			response.setCookies(output.getCookies());

			if (String.valueOf(output.getStatus()).startsWith("3")) {
				response.setLocation((String) output.getHeaders().getFirst("Location"));
			} else {
				response.setResponse(output.readEntity(String.class));
			}
		} catch (Exception e) {
			e.printStackTrace();
			// throw new CommonException(e);
		}

		return response;
	}

	/**
	 * Put.
	 *
	 * @param request             the request
	 * @param authourizationToken the authourization token
	 * @return the response entity
	 */
	public static ResponseEntity put(RequestEntity request, String authourizationToken) {

		ResponseEntity response = null;

		try {
			WebTarget webTarget = client.target(request.getUrl());

			if (request.getParameters() != null && request.getParameters().size() > 0) {
				webTarget = setQueryParam(webTarget, request.getParameters());
			}

			if (request.getObjParameters() != null && request.getObjParameters().size() > 0) {
				webTarget = setQueryParamFormObjectValue(webTarget, request.getObjParameters());
			}
			Builder builder = webTarget.request().header(HttpHeaders.AUTHORIZATION, authourizationToken);

			if (request.getCookies() != null && request.getCookies().size() > 0) {
				setCookies(builder, request.getCookies());
			}

			Response output = builder.put(Entity.entity(request.getBodyContent(), MediaType.APPLICATION_JSON));

			response = new ResponseEntity();
			response.setStatus(output.getStatus());
			response.setCookies(output.getCookies());

			if (String.valueOf(output.getStatus()).startsWith("3")) {
				response.setLocation((String) output.getHeaders().getFirst("Location"));
			} else {
				response.setResponse(output.readEntity(String.class));
			}
		} catch (Exception e) {
			// throw new CommonException(e);
			e.printStackTrace();
		}

		return response;
	}

	/**
	 * Delete.
	 *
	 * @param request             the request
	 * @param authourizationToken the authourization token
	 * @return the response entity
	 */
	public static ResponseEntity delete(RequestEntity request, String authourizationToken) {

		ResponseEntity response = null;

		try {
			WebTarget webTarget = client.target(request.getUrl());

			if (request.getParameters() != null && request.getParameters().size() > 0) {
				webTarget = setQueryParam(webTarget, request.getParameters());
			}

			if (request.getObjParameters() != null && request.getObjParameters().size() > 0) {
				webTarget = setQueryParamFormObjectValue(webTarget, request.getObjParameters());
			}
			Builder builder = webTarget.request().header(HttpHeaders.AUTHORIZATION, authourizationToken);

			if (request.getCookies() != null && request.getCookies().size() > 0) {
				setCookies(builder, request.getCookies());
			}

			Response output = builder.delete();

			response = new ResponseEntity();
			response.setStatus(output.getStatus());
			response.setCookies(output.getCookies());

			if (String.valueOf(output.getStatus()).startsWith("3")) {
				response.setLocation((String) output.getHeaders().getFirst("Location"));
			} else {
				response.setResponse(output.readEntity(String.class));
			}
		} catch (Exception e) {
			e.printStackTrace();
			// throw new CommonException(e);
		}

		return response;
	}

	/**
	 * Sets the query param.
	 *
	 * @param webTarget  the web target
	 * @param parameters the parameters
	 * @return the web target
	 */
	private static WebTarget setQueryParam(WebTarget webTarget, Map<String, String> parameters) {

		for (String key : parameters.keySet()) {
			webTarget = webTarget.queryParam(key, parameters.get(key));
		}

		return webTarget;
	}

	/**
	 * Sets the query param form object value.
	 *
	 * @param webTarget  the web target
	 * @param parameters the parameters
	 * @return the web target
	 */
	private static WebTarget setQueryParamFormObjectValue(WebTarget webTarget, Map<String, Object> parameters) {

		for (String key : parameters.keySet()) {
			webTarget = webTarget.queryParam(key, parameters.get(key));
		}

		return webTarget;
	}

	/**
	 * Gets the form param.
	 *
	 * @param parameters the parameters
	 * @return the form param
	 */
	private static Form getFormParam(Map<String, String> parameters) {

		Form form = new Form();
		if (parameters != null) {

			for (String key : parameters.keySet()) {
				form.param(key, String.valueOf(parameters.get(key)));
			}
		}

		return form;
	}

	/**
	 * Gets the form obj param.
	 *
	 * @param parameters the parameters
	 * @return the form obj param
	 * @throws JSONException the JSON exception
	 */
	private static Form getFormObjParam(Map<String, String> parameters) throws JSONException {

		Form form = new Form();
		if (parameters != null) {

			for (String key : parameters.keySet()) {
				Gson gson = new Gson();
				String jsonString = gson.toJson(parameters.get(key), LinkedHashMap.class);
				form.param(key, jsonString);
			}
		}

		return form;
	}

	/**
	 * Sets the cookies.
	 *
	 * @param builder the builder
	 * @param cookies the cookies
	 */
	private static void setCookies(Builder builder, Map<String, NewCookie> cookies) {

		StringBuilder values = new StringBuilder();
		boolean flag = false;

		for (String name : cookies.keySet()) {

			NewCookie cookie = cookies.get(name);

			if (flag)
				values.append("; ");
			else
				flag = true;

			values.append(cookie.getName() + "=" + cookie.getValue());
		}

		builder.header("Cookie", values.toString());
	}
}
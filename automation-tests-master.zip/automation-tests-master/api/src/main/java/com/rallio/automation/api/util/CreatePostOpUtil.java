package com.rallio.automation.api.util;

import java.net.URI;

import org.testng.Assert;

import com.rallio.automation.common.enums.LogLevel;
import com.rallio.automation.common.util.LogUtil;

import io.restassured.RestAssured;
import io.restassured.response.Response;

// TODO: Auto-generated Javadoc
/**
 * The Class CreatePostOpUtil.
 */
public class CreatePostOpUtil {

	/**
	 * Gets the random post name.
	 *
	 * @return the random post name
	 */
	public static String getRandomPostName() {

		try {
			Response response = RestAssured.given().when().get(new URI("http://localhost:8080/autoOpsRallioApi/RallioOp/getPostName"));
			Assert.assertNotNull(response.getBody(), "Recieved Null Response");
			int responseCode = response.getStatusCode();
			LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
			String responsebody = response.getBody().asString();
			Assert.assertEquals(responseCode, 200, "Invalid Response Code");
			return responsebody;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}

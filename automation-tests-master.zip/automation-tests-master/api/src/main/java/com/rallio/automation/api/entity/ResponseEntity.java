package com.rallio.automation.api.entity;

import java.util.Map;

import javax.ws.rs.core.NewCookie;

// TODO: Auto-generated Javadoc
//import javax.ws.rs.core.NewCookie;
/**
 * The Class ResponseEntity.
 */
public class ResponseEntity {

	/** The status. */
	private int status;

	/** The response. */
	private String response;

	/** The location. */
	private String location;

	/** The cookies. */
	private Map<String, NewCookie> cookies;

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public int getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(int status) {
		this.status = status;
	}
	/**
	 * Gets the response.
	 *
	 * @return the response
	 */
	public String getResponse() {
		return response;
	}

	/**
	 * Sets the response.
	 *
	 * @param response the new response
	 */
	public void setResponse(String response) {
		this.response = response;
	}

	/**
	 * Gets the location.
	 *
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * Sets the location.
	 *
	 * @param location the new location
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * Gets the cookies.
	 *
	 * @return the cookies
	 */
	public Map<String, NewCookie> getCookies() {
		return cookies;
	}

	/**
	 * Sets the cookies.
	 *
	 * @param cookies the cookies
	 */
	public void setCookies(Map<String, NewCookie> cookies) {
		this.cookies = cookies;
	}
}
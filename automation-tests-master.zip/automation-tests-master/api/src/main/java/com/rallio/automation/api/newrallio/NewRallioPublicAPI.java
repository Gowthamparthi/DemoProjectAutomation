package com.rallio.automation.api.newrallio;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;

import com.rallio.automation.api.util.APIUtil;
import com.rallio.automation.common.enums.LogLevel;
import com.rallio.automation.common.util.FileUtil;
import com.rallio.automation.common.util.LogUtil;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

// TODO: Auto-generated Javadoc
/**
 * The Class NewRallioPublicAPI.
 */
public class NewRallioPublicAPI {

	/**
	 * Instantiates a new new rallio public API.
	 */
	private NewRallioPublicAPI() {

	}

	/**
	 * Creates the user.
	 *
	 * @param applicationId the application id
	 * @param applicationSecret the application secret
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static void createUser(String applicationId, String applicationSecret) throws Exception {

		LogUtil.log("CreateUser API method : ", LogLevel.LOW);
		String inputData = FileUtil.getStringData("NewRallioPublicAPIs/createUsers.json");
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Request body - " + payload.get("body"), LogLevel.LOW);
		Response response = RestAssured.given().header("Content-Type", "application/json").header("X-Application-ID", applicationId)
		        .header("X-Application-Secret", applicationSecret).body((Map<String, ?>) payload.get("body")).post(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		// ObjectMapper objectMapper = new ObjectMapper();
		// PostsStats postsStats = objectMapper.readValue(responseBody,
		// PostsStats.class);
		// return postsStats;
	}

	/**
	 * User mapping.
	 *
	 * @param applicationId the application id
	 * @param applicationSecret the application secret
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static void userMapping(String applicationId, String applicationSecret) throws Exception {

		LogUtil.log("UserMapping API method : ", LogLevel.LOW);
		String inputData = FileUtil.getStringData("NewRallioPublicAPIs/accountOwnerships.json");
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Request body - " + payload.get("body"), LogLevel.LOW);
		Response response = RestAssured.given().header("Content-Type", "application/json").header("X-Application-ID", applicationId)
		        .header("X-Application-Secret", applicationSecret).body((Map<String, ?>) payload.get("body")).post(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		// ObjectMapper objectMapper = new ObjectMapper();
		// PostsStats postsStats = objectMapper.readValue(responseBody,
		// PostsStats.class);
		// return postsStats;
	}

	/**
	 * Upload image.
	 *
	 * @param applicationId the application id
	 * @param applicationSecret the application secret
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static void uploadImage(String applicationId, String applicationSecret) throws Exception {

		LogUtil.log("UploadImage API method : ", LogLevel.LOW);
		String inputData = FileUtil.getStringData("NewRallioPublicAPIs/uploadImage.json");
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Request body - " + payload.get("body"), LogLevel.LOW);
		Response response = RestAssured.given().header("Content-Type", "application/json").header("X-Application-ID", applicationId)
		        .header("X-Application-Secret", applicationSecret).body((Map<String, ?>) payload.get("body")).post(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		// ObjectMapper objectMapper = new ObjectMapper();
		// PostsStats postsStats = objectMapper.readValue(responseBody,
		// PostsStats.class);
		// return postsStats;
	}

	/**
	 * Upload image on franchisor.
	 *
	 * @param applicationId the application id
	 * @param applicationSecret the application secret
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static void uploadImageOnFranchisor(String applicationId, String applicationSecret) throws Exception {

		LogUtil.log("UploadImage on Franchisor API method : ", LogLevel.LOW);
		String inputData = FileUtil.getStringData("NewRallioPublicAPIs/uploadImageOnFranchisor.json");
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Request body - " + payload.get("body"), LogLevel.LOW);
		Response response = RestAssured.given().header("Content-Type", "application/json").header("X-Application-ID", applicationId)
		        .header("X-Application-Secret", applicationSecret).body((Map<String, ?>) payload.get("body")).post(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		// ObjectMapper objectMapper = new ObjectMapper();
		// PostsStats postsStats = objectMapper.readValue(responseBody,
		// PostsStats.class);
		// return postsStats;
	}

	/**
	 * Upload video.
	 *
	 * @param applicationId the application id
	 * @param applicationSecret the application secret
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static void uploadVideo(String applicationId, String applicationSecret) throws Exception {

		LogUtil.log("UploadVideo API method : ", LogLevel.LOW);
		String inputData = FileUtil.getStringData("NewRallioPublicAPIs/uploadVideo.json");
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Request body - " + payload.get("body"), LogLevel.LOW);
		Response response = RestAssured.given().header("Content-Type", "application/json").header("X-Application-ID", applicationId)
		        .header("X-Application-Secret", applicationSecret).body((Map<String, ?>) payload.get("body")).post(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		// ObjectMapper objectMapper = new ObjectMapper();
		// PostsStats postsStats = objectMapper.readValue(responseBody,
		// PostsStats.class);
		// return postsStats;
	}

	/**
	 * Creates the content.
	 *
	 * @param applicationId the application id
	 * @param applicationSecret the application secret
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public static void createContent(String applicationId, String applicationSecret) throws Exception {

		LogUtil.log("CreateContent API method : ", LogLevel.LOW);
		String inputData = FileUtil.getStringData("NewRallioPublicAPIs/createContent.json");
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Request body - " + payload.get("body"), LogLevel.LOW);
		Response response = RestAssured.given().header("Content-Type", "application/json").header("X-Application-ID", applicationId)
		        .header("X-Application-Secret", applicationSecret).body((Map<String, ?>) payload.get("body")).post(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		// ObjectMapper objectMapper = new ObjectMapper();
		// PostsStats postsStats = objectMapper.readValue(responseBody,
		// PostsStats.class);
		// return postsStats;
	}
	
	@SuppressWarnings("unchecked")
	public static void updateLocation(String applicationId, String applicationSecret) throws Exception {

		LogUtil.log("UpdateLocation API method : ", LogLevel.LOW);
		String inputData = FileUtil.getStringData("NewRallioPublicAPIs/updateLocation.json");
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Request body - " + payload.get("body"), LogLevel.LOW);
		Response response = RestAssured.given().header("Content-Type", "application/json").header("X-Application-ID", applicationId)
		        .header("X-Application-Secret", applicationSecret).body((Map<String, ?>) payload.get("body")).put(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		// ObjectMapper objectMapper = new ObjectMapper();
		// PostsStats postsStats = objectMapper.readValue(responseBody,
		// PostsStats.class);
		// return postsStats;
	}
	
	@SuppressWarnings("unchecked")
	public static void deleteImage(String applicationId, String applicationSecret) throws Exception {

		LogUtil.log("DeleteImage API method : ", LogLevel.LOW);
		String inputData = FileUtil.getStringData("NewRallioPublicAPIs/deleteImage.json");
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Request body - " + payload.get("body"), LogLevel.LOW);
		Response response = RestAssured.given().header("Content-Type", "application/json").header("X-Application-ID", applicationId)
		        .header("X-Application-Secret", applicationSecret).body((Map<String, ?>) payload.get("body")).delete(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		// ObjectMapper objectMapper = new ObjectMapper();
		// PostsStats postsStats = objectMapper.readValue(responseBody,
		// PostsStats.class);
		// return postsStats;
	}
	
	@SuppressWarnings("unchecked")
	public static void deleteVideo(String applicationId, String applicationSecret) throws Exception {

		LogUtil.log("DeleteVideo API method : ", LogLevel.LOW);
		String inputData = FileUtil.getStringData("NewRallioPublicAPIs/deleteVideo.json");
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Request body - " + payload.get("body"), LogLevel.LOW);
		Response response = RestAssured.given().header("Content-Type", "application/json").header("X-Application-ID", applicationId)
		        .header("X-Application-Secret", applicationSecret).body((Map<String, ?>) payload.get("body")).delete(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		// ObjectMapper objectMapper = new ObjectMapper();
		// PostsStats postsStats = objectMapper.readValue(responseBody,
		// PostsStats.class);
		// return postsStats;
	}
	
	@SuppressWarnings("unchecked")
	public static void deleteImageOnFranchisor(String applicationId, String applicationSecret) throws Exception {

		LogUtil.log("DeleteImageOnFranchisor API method : ", LogLevel.LOW);
		String inputData = FileUtil.getStringData("NewRallioPublicAPIs/deleteImageOnFranchisor.json");
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Request body - " + payload.get("body"), LogLevel.LOW);
		Response response = RestAssured.given().header("Content-Type", "application/json").header("X-Application-ID", applicationId)
		        .header("X-Application-Secret", applicationSecret).body((Map<String, ?>) payload.get("body")).delete(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		// ObjectMapper objectMapper = new ObjectMapper();
		// PostsStats postsStats = objectMapper.readValue(responseBody,
		// PostsStats.class);
		// return postsStats;
	}
	
	@SuppressWarnings("unchecked")
	public static void createContentPublicAPI(String applicationId, String applicationSecret) throws Exception {

		LogUtil.log("CreateContent Public API method : ", LogLevel.LOW);
		String inputData = FileUtil.getStringData("NewRallioPublicAPIs/createContentPublicAPI.json");
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Request body - " + payload.get("body"), LogLevel.LOW);
		Response response = RestAssured.given().header("Content-Type", "application/json").header("X-Application-ID", applicationId)
		        .header("X-Application-Secret", applicationSecret).body((Map<String, ?>) payload.get("body")).post(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		// ObjectMapper objectMapper = new ObjectMapper();
		// PostsStats postsStats = objectMapper.readValue(responseBody,
		// PostsStats.class);
		// return postsStats;
	}
	
	@SuppressWarnings("unchecked")
	public static String createUserPublicAPI(String applicationId, String applicationSecret) throws Exception {

		LogUtil.log("CreateUser Public API method : ", LogLevel.LOW);
		String inputData = FileUtil.getStringData("NewRallioPublicAPIs/createUsersPublicAPI.json");
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Request body - " + payload.get("body"), LogLevel.LOW);
		Response response = RestAssured.given().header("Content-Type", "application/json").header("X-Application-ID", applicationId)
		        .header("X-Application-Secret", applicationSecret).body((Map<String, ?>) payload.get("body")).post(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		JsonPath jsonPath = new JsonPath(responseBody);
		String createdUserId = jsonPath.getJsonObject("user.id").toString();
		return createdUserId;
	}
	
	@SuppressWarnings("unchecked")
	public static void editUserPublicAPI(String applicationId, String applicationSecret, String createdUserId) throws Exception {

		LogUtil.log("EditUser Public API method : ", LogLevel.LOW);
		String inputData = FileUtil.getStringData("NewRallioPublicAPIs/editUserPublicAPI.json");
		inputData = String.format(inputData, createdUserId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Request body - " + payload.get("body"), LogLevel.LOW);
		Response response = RestAssured.given().header("Content-Type", "application/json").header("X-Application-ID", applicationId)
		        .header("X-Application-Secret", applicationSecret).body((Map<String, ?>) payload.get("body")).put(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		// ObjectMapper objectMapper = new ObjectMapper();
		// PostsStats postsStats = objectMapper.readValue(responseBody,
		// PostsStats.class);
		// return postsStats;
	}
	
	@SuppressWarnings("unchecked")
	public static void deleteUserPublicAPI(String applicationId, String applicationSecret, String createdUserId) throws Exception {

		LogUtil.log("DeleteUser Public API method : ", LogLevel.LOW);
		String inputData = FileUtil.getStringData("NewRallioPublicAPIs/deleteUserPublicAPI.json");
		inputData = String.format(inputData, createdUserId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Request body - " + payload.get("body"), LogLevel.LOW);
		Response response = RestAssured.given().header("Content-Type", "application/json").header("X-Application-ID", applicationId)
		        .header("X-Application-Secret", applicationSecret).body((Map<String, ?>) payload.get("body")).delete(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		// ObjectMapper objectMapper = new ObjectMapper();
		// PostsStats postsStats = objectMapper.readValue(responseBody,
		// PostsStats.class);
		// return postsStats;
	}
	
	@SuppressWarnings("unchecked")
	public static void deleteUserFromDatabasePublicAPI(String applicationId, String applicationSecret, String createdUserId) throws Exception {

		LogUtil.log("DeleteUser from database PublicAPI method : ", LogLevel.LOW);
		String inputData = FileUtil.getStringData("NewRallioPublicAPIs/deleteUserFromDatabasePublicAPI.json");
		inputData = String.format(inputData, createdUserId);
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Request body - " + payload.get("body"), LogLevel.LOW);
		Response response = RestAssured.given().header("Content-Type", "application/json").header("X-Application-ID", applicationId)
		        .header("X-Application-Secret", applicationSecret).queryParams((Map<String, ?>) payload.get("parameters")).body((Map<String, ?>) payload.get("body")).delete(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		// ObjectMapper objectMapper = new ObjectMapper();
		// PostsStats postsStats = objectMapper.readValue(responseBody,
		// PostsStats.class);
		// return postsStats;
	}
	
	@SuppressWarnings("unchecked")
	public static void updateLocationPublicAPI(String applicationId, String applicationSecret) throws Exception {

		LogUtil.log("UpdateLocation Public API method : ", LogLevel.LOW);
		String inputData = FileUtil.getStringData("NewRallioPublicAPIs/updateLocationPublicAPI.json");
		Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
		LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
		LogUtil.log("Request body - " + payload.get("body"), LogLevel.LOW);
		Response response = RestAssured.given().header("Content-Type", "application/json").header("X-Application-ID", applicationId)
		        .header("X-Application-Secret", applicationSecret).body((Map<String, ?>) payload.get("body")).put(new URI((String) payload.get("url")));
		int responseCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
		LogUtil.log(responseBody, LogLevel.LOW);
		LogUtil.log(" ", LogLevel.LOW);
		Assert.assertEquals(responseCode, 200, "Invalid Response Code");
		Assert.assertNotNull(responseBody, "Recieved Null Response");
		// ObjectMapper objectMapper = new ObjectMapper();
		// PostsStats postsStats = objectMapper.readValue(responseBody,
		// PostsStats.class);
		// return postsStats;
	}
}

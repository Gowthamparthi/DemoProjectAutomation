package com.rallio.automation.api.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum PostUsageTypeEnum.
 */
public enum PostUsageTypeEnum {

	/** The used. */
	USED("1"),

	/** The not used. */
	NOT_USED("0"),

	/** The all. */
	ALL("");

	/** The post usage type. */
	private String postUsageType;

	/**
	 * Instantiates a new post usage type enum.
	 *
	 * @param postUsage the post usage
	 */
	private PostUsageTypeEnum(String postUsage) {
		this.postUsageType = postUsage;
	}

	/**
	 * Gets the post usage type.
	 *
	 * @return the post usage type
	 */
	public String getPostUsageType() {
		return postUsageType;
	}
}
package com.rallio.automation.api.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum AssetTypeEnum.
 */
public enum AssetTypeEnum {

	/** The images. */
	IMAGES("photo"),

	/** The videos. */
	VIDEOS("video"),

	/** The all. */
	ALL("");

	/** The asset type. */
	private String assetType;

	/**
	 * Instantiates a new asset type enum.
	 *
	 * @param assetType the asset type
	 */
	private AssetTypeEnum(String assetType) {
		this.assetType = assetType;
	}

	/**
	 * Gets the asset type.
	 *
	 * @return the asset type
	 */
	public String getAssetType() {
		return assetType;
	}
}

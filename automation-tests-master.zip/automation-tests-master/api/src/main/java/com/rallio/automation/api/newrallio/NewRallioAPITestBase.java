package com.rallio.automation.api.newrallio;

import static com.rallio.automation.common.manager.ConfigManager.*;

import java.util.*;

import org.json.*;
import org.testng.*;
import org.testng.annotations.*;

//import com.jayway.restassured.response.*;
import com.rallio.automation.bussiness.newRallio.entity.*;
import com.rallio.automation.common.enums.*;
import com.rallio.automation.common.util.*;

import io.restassured.response.Response;

// TODO: Auto-generated Javadoc
/**
 * The Class NewRallioAPITestBase.
 */
public class NewRallioAPITestBase {

	/**
	 * Sets the up before test.
	 *
	 * @param context the new up before test
	 */
	@BeforeTest()
	public void setupBeforeTest(final ITestContext context) {

		LogUtil.log("Before Test", LogLevel.LOW);
		TestCaseLogUtil.printAllTestcases(context);
		String env = System.getProperty("env");
		loadConfigPropertiesFile(env);
		LogUtil.log("Running Tests In '" + env.toUpperCase() + "'", LogLevel.LOW);
	}

	/**
	 * Load config properties file.
	 *
	 * @param env the env
	 */
	public void loadConfigPropertiesFile(String env) {

		switch (env) {
		case "stg":
			loadConfig("newrallio-stg.properties");
			break;

		case "prod":
			loadConfig("newrallio-prod.properties");
			break;

		default:
			LogUtil.log("Invalid Environment parameter specified. No config file loaded", LogLevel.LOW);
			break;
		}
	}

	/**
	 * Gets the string object.
	 *
	 * @param response the response
	 * @param key the key
	 * @return the string object
	 */
	public static String getStringObject(Response response, String key) {

		return response.jsonPath().getString(key);
	}

	/**
	 * Gets the list object.
	 *
	 * @param response the response
	 * @param key the key
	 * @return the list object
	 */
	public static List<?> getListObject(Response response, String key) {

		return response.jsonPath().getList(key);
	}

	/**
	 * Gets the map object.
	 *
	 * @param response the response
	 * @param key the key
	 * @return the map object
	 */
	public static Map<?, ?> getMapObject(Response response, String key) {

		return response.jsonPath().getMap(key);
	}

	/**
	 * Gets the int object.
	 *
	 * @param response the response
	 * @param key the key
	 * @return the int object
	 */
	public static int getIntObject(Response response, String key) {

		return response.jsonPath().getInt(key);
	}

	/**
	 * Gets the double object.
	 *
	 * @param response the response
	 * @param key the key
	 * @return the double object
	 */
	public static Double getDoubleObject(Response response, String key) {

		return response.jsonPath().getDouble(key);
	}

	/**
	 * Gets the boolean object.
	 *
	 * @param response the response
	 * @param key the key
	 * @return the boolean object
	 */
	public static boolean getBooleanObject(Response response, String key) {

		return response.jsonPath().getBoolean(key);

	}

	/**
	 * Gets the json object.
	 *
	 * @param response the response
	 * @param key the key
	 * @return the json object
	 */
	public static JSONObject getJsonObject(Response response, String key) {

		return response.jsonPath().getJsonObject(key);
	}

	/**
	 * Gets the new rallio user.
	 *
	 * @return the new rallio user
	 */
	public NewRallioUser getNewRallioUser() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("newrallioUser.login"), NewRallioUser.class);
		return newRallioUser;
	}
	
	public NewRallioUser getNewRallioBrandUser() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("brandUser.login"), NewRallioUser.class);
		return newRallioUser;
	}
	
}

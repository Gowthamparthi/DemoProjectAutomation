package com.rallio.automation.api.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum HTMLTableComponents.
 */
public enum TestlinkReportComponentsEnum{

	/** The html report header. */
	HTML_REPORT_HEADER(
			"<!DOCTYPE html><html><style>table, th, td { border:1px solid black; border-collapse: collapse;}</style> <head><title>NewRallio Coverage Report</title></head>",
			"HTML_Report_Header"),

	/** The html report body. */
	HTML_REPORT_BODY("<body><p>Hi Team,</p><p>		%s</p><h4> Project Name - %s</h4>",
			"HTML_Report_body"),
	
	HTML_REPORT_BODY_TEXT("<p>Hi Team,</p><p>		%s</p>",
			"HTML_Report_body Text"),

	/** The html report planname. */
	HTML_REPORT_PLANNAME("<h4> TestPlan Name : %s</h4>", "HTML_Report_Planname"),

	/** The html report sub planname. */
	HTML_REPORT_SUB_PLANNAME("<h4> SubPlan Name : %s</h4>", "HTML_Report_Sub_PlanName"),

	/** The html report table header. */
	HTML_REPORT_TABLE_HEADER(
			"<table><tr style=\"background-color:#4682B4\";\"font-weight: bold;\" border-radius: 1px\";>"
					+ "<th>S.No</th><th>Suite Name</th><th>Total Cases</th> <th>Automated Cases</th> <th>Automated Status(%)</th><th>Manual Cases</th><th>Manual Status(%)</th></tr>",
			"HTML_Report_Table_Header"),

	/** The html report table row. */
	HTML_REPORT_TABLE_ROW(
			"<tr style=\"background-color:#D3D3D3\";>"
					+ "<td>%d</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>",
			"HTML_Report_Table_Row"),

	/** The html report table bottom row. */
	HTML_REPORT_TABLE_BOTTOM_ROW("<tr style=\"background-color:#4682B4\";>"
			+ "<td><b>%s</b></td><td><b>%s</b></td><td><b>%d</b></td><td><b>%d</b></td><td><b>%.2f%%</b></td><td><b>%d</b></td><td><b>%.2f%%</b></td></tr></table>",
			"HTML_Report_Table__Bottom_Row"),
	
	HTML_REPORT_BOTTOM_TEXT("<p> Thanks,<br>%s</p>", "HTML_Report_Bottom"),

	/** The html report footer. */
	HTML_REPORT_FOOTER("</body></html>", "HTML_Report_Footer");

	/** The description. */
	private String component, description;

	/**
	 * Instantiates a new HTML table components.
	 *
	 * @param component the component
	 */
	private TestlinkReportComponentsEnum(String component) {

		this.component = component;

	}

	/**
	 * Instantiates a new HTML table components.
	 *
	 * @param component the component
	 * @param description the description
	 */
	private TestlinkReportComponentsEnum(String component, String description) {

		this.component = component;
		this.description = description;
	}

	/**
	 * Gets the component.
	 *
	 * @return the component
	 */
	public String getComponent() {
		return component;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

}

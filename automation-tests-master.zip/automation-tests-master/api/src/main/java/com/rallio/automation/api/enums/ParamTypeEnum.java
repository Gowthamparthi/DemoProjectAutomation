package com.rallio.automation.api.enums;


public enum ParamTypeEnum {

	ACCOUNT_ID,
	
	FRANCHISOR_ID;
}

package com.rallio.automation.api.newrallio;

import java.net.URI;
import java.util.AbstractMap;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.testng.Assert;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rallio.automation.api.util.APIUtil;
import com.rallio.automation.api.util.DateRangeUtil;
import com.rallio.automation.bussiness.newRallio.entity.AccountSwticher;
import com.rallio.automation.bussiness.newRallio.entity.NewRallioUser;
import com.rallio.automation.bussiness.newRallio.entity.Photos;
import com.rallio.automation.bussiness.newRallio.entity.PostsStats;
import com.rallio.automation.bussiness.newRallio.entity.ScheduledPosts;
import com.rallio.automation.bussiness.newRallio.entity.SocialContents;
import com.rallio.automation.bussiness.newRallio.entity.User;
import com.rallio.automation.common.enums.LogLevel;
import com.rallio.automation.common.util.FileUtil;
import com.rallio.automation.common.util.JsonUtil;
import com.rallio.automation.common.util.LogUtil;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

// TODO: Auto-generated Javadoc

/**
 * The Class NewRallioAPI.
 */
public class NewRallioAPI {

    /**
     * Instantiates a new new rallio API.
     */
    private NewRallioAPI() {

    }

    /**
     * Login.
     *
     * @param newRallioUser the new rallio user
     * @return the map
     * @throws Exception the exception
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> login(NewRallioUser newRallioUser) throws Exception {

        LogUtil.log("Login API", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/login.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL(), newRallioUser.getUserName(), newRallioUser.getPassword());
        System.out.println("Input data : " + inputData);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        System.out.println("Payload : " + payload);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().queryParams((Map<String, ?>) payload.get("parameters")).body((Map<String, ?>) payload.get("parameters")).when()
                .post(new URI((String) payload.get("url")));
        Assert.assertNotNull(response.getBody(), "Recieved Null Response");
        LogUtil.log("Response Code :" + response.getStatusCode(), LogLevel.LOW);
        LogUtil.log("Response Message: " + response.getBody().asString(), LogLevel.LOW);
        String accountId = null;
        JsonPath jsonPath = new JsonPath(response.getBody().asString());
        String token = null;
        boolean account = false;

        token = jsonPath.getString("rallio_access_token.token");
        if (jsonPath.getList("user_detail.accounts_managed").size() != 0) {
            String accountIdString = new ObjectMapper().writeValueAsString(jsonPath.getList("user_detail.accounts_managed").get(1));
            Map<String, Object> accountIdMap = APIUtil.read(accountIdString, HashMap.class, String.class, Object.class);
            accountId = accountIdMap.get("id").toString();
            account = true;
        } else {
            //accountId = jsonPath.getString("account.id");
            account = false;
        }
        User user = jsonPath.getObject(("user"), User.class);
        LogUtil.log("Token id " + token, LogLevel.LOW);
        LogUtil.log("Account Id:" + accountId, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        try {
            return Stream
                    .of(new AbstractMap.SimpleEntry<>("responseCode", String.valueOf(response.getStatusCode())), new AbstractMap.SimpleEntry<>("tokenId", token),
                            new AbstractMap.SimpleEntry<>("accountId", accountId), new AbstractMap.SimpleEntry<>("user", user), new AbstractMap.SimpleEntry<>("account", account))
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        } catch (Exception e) {
            return Stream
                    .of(new AbstractMap.SimpleEntry<>("responseCode", String.valueOf(response.getStatusCode())), new AbstractMap.SimpleEntry<>("tokenId", token),
                            new AbstractMap.SimpleEntry<>("user", user), new AbstractMap.SimpleEntry<>("account", account))
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        }
    }

    /**
     * Gets the account switcher.
     *
     * @param token     the token
     * @param accountId the account id
     * @return the account switcher
     * @throws Exception the exception
     */
    @SuppressWarnings("unchecked")
    public static AccountSwticher getAccountSwitcher(String token, String accountId) throws Exception {

        LogUtil.log("Get Account Switcher", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getAccountSwitcher.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$accountId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        AccountSwticher accountSwticher = objectMapper.readValue(responseBody, AccountSwticher.class);
        return accountSwticher;
    }

    /**
     * Gets the post stats.
     *
     * @param token     the token
     * @param accountId the account id
     * @return the post stats
     * @throws Exception the exception
     */
    @SuppressWarnings("unchecked")
    public static PostsStats getPostStats(String token, String accountId) throws Exception {

        LogUtil.log("Get PostStats", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/postStats.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$accountId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        ObjectMapper objectMapper = new ObjectMapper();
        PostsStats postsStats = objectMapper.readValue(responseBody, PostsStats.class);
        return postsStats;

    }

    /**
     * Gets the scheduled posts.
     *
     * @param token     the token
     * @param accountId the account id
     * @return the scheduled posts
     * @throws Exception the exception
     */
    @SuppressWarnings("unchecked")
    public static List<ScheduledPosts> getScheduledPosts(String token, String accountId) throws Exception {

        LogUtil.log("Get Scheduled Posts", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getScheduledPosts.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$accountId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        List<ScheduledPosts> scheduledPosts = Arrays.asList(jsonPath.getObject(("scheduled_posts"), ScheduledPosts[].class));
        return scheduledPosts;
    }

    /**
     * Gets the photos.
     *
     * @param token      the token
     * @param accountId  the account id
     * @param page       the page
     * @param source     the source
     * @param media_type the media type
     * @return the photos
     * @throws Exception the exception
     */
    @SuppressWarnings("unchecked")
    public static List<Photos> getPhotos(String token, String accountId, int page, String source) throws Exception {

        LogUtil.log("Get Photos", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getPhotos.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL(), page, source);
        inputData = inputData.replace("$accountId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
	    /*ObjectMapper objectMapper = new ObjectMapper();
		List<Photos> photos = new ArrayList<Photos>();
		JsonPath jsonPath = new JsonPath(responseBody);
		List<String> jsonlist = new ArrayList<String>();
		jsonlist = jsonPath.getList("photos");
		for(Object jsonString : jsonlist)
			photos.add(objectMapper.readValue(objectMapper.writeValueAsString(jsonString), Photos.class));*/
        List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getPhotosStats(String token, String accountId) throws Exception {

        LogUtil.log("Get Photos stats", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getPhotosStats.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$accountId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getVideosStats(String token, String accountId) throws Exception {

        LogUtil.log("Get Videos stats", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getVideosStats.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$accountId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getPhotosUsageStats(String token, String accountId) throws Exception {

        LogUtil.log("Get Photos Usage stats", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getPhotosUsageStats.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$accountId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getVideos(String token, String accountId, int page, String source) throws Exception {

        LogUtil.log("Get Videos", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getVideos.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL(), page, source);
        inputData = inputData.replace("$accountId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getAssetsStatsAndSearch(String token, String accountId, String source, String searchAsset) throws Exception {

        LogUtil.log("Get Assets stats and Search", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getAssetsStatsAndSearch.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL(), source, searchAsset);
        inputData = inputData.replace("$accountId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getCreatorScheduledPosts(String token, String accountId) throws Exception {

        LogUtil.log("Get Creator scheduledPosts", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getCreatorScheduledPosts.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$accountId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getCalendarScheduledPosts(String token, String accountId) throws Exception {

        LogUtil.log("Get Calendar scheduledPosts", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getCalendarScheduledPosts.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$accountId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getAccountLists(String token, String accountId) throws Exception {

        LogUtil.log("Get Account lists", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getAccountLists.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getContentComments(String token, String id) throws Exception {

        LogUtil.log("Get Content comments", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getContentComments.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL(), id);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getUsers(String token) throws Exception {

        LogUtil.log("Get Users", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getUsers.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        //LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getContents(String token) throws Exception {

        LogUtil.log("Get Contents", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getContents.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        //LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("Content-Type", "application/json").header("X-Rallio-API-Key", token).body((Map<String, ?>) payload.get("body")).post(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getMediaTags(String token) throws Exception {

        LogUtil.log("Get Media tags", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getMediaTags.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        //LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getCalendarTags(String token) throws Exception {

        LogUtil.log("Get Calendar tags", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getCalendarTags.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        //LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getAccounts(String token, String accountId) throws Exception {

        LogUtil.log("Get Accounts", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getAccounts.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL(), accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        //LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getFranchisors(String token, String accountId) throws Exception {

        LogUtil.log("Get Franchisors", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getFranchisors.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL(), accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        //LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    /**
     * Gets the photos with date range.
     *
     * @param token       the token
     * @param accountId   the account id
     * @param page        the page
     * @param source      the source
     * @param media_type  the media type
     * @param date_range1 the date range 1
     * @param date_range2 the date range 2
     * @return the photos with date range
     * @throws Exception the exception
     */
    @SuppressWarnings("unchecked")
    public static List<Photos> getPhotosWithDateRange(String token, String accountId, int page, String source, String media_type, long date_range1, long date_range2) throws Exception {

        LogUtil.log("Get Photos with date range", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getPhotosWithDateRange.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL(), page, source, media_type, date_range1, date_range2);
        inputData = inputData.replace("$accountId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        return photos;
    }

    /**
     * Gets the sand box social contents.
     *
     * @param token the token
     * @param page  the page
     * @return the sand box social contents
     * @throws Exception the exception
     */
    @SuppressWarnings("unchecked")
    public static List<SocialContents> getSandBoxSocialContents(String token, int page) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/getSandBoxSocialContents.json");
        long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL(), page, date_range[0], date_range[1]);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        LogUtil.log("Social contents list size is: " + socialContents.size(), LogLevel.LOW);
        return socialContents;
    }

    /**
     * Gets the inbox social contents.
     *
     * @param token       the token
     * @param page        the page
     * @param accountId   the account id
     * @param date_range1 the date range 1
     * @param date_range2 the date range 2
     * @return the inbox social contents
     * @throws Exception the exception
     */
    @SuppressWarnings("unchecked")
    public static List<SocialContents> getInboxSocialContents(String token, String accountId, String franchisorId, String startDate, String endDate) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/getInboxSocialContents.json");
//		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$accountId", accountId);
        inputData = inputData.replace("$franchisorId", franchisorId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).queryParams("date_range[]", startDate).queryParams("date_range[]", endDate).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        LogUtil.log("Social contents list size is: " + socialContents.size(), LogLevel.LOW);
        return socialContents;
    }

    @SuppressWarnings("unchecked")
    public static void getInboxSocialContents2(String token, String franchisorId, String startDate, String endDate) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/inboxSocialContents.json");
//		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", franchisorId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).queryParams("date_range[]", startDate).queryParams("date_range[]", endDate).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        //LogUtil.log("Social contents list size is: " + socialContents.size(), LogLevel.LOW);
        //return socialContents;
    }

    @SuppressWarnings("unchecked")
    public static void getInboxSocialContentsStats(String token, String franchisorId, String startDate, String endDate) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/inboxSocialContentsStats.json");
//		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", franchisorId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).queryParams("date_range[]", startDate).queryParams("date_range[]", endDate).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        //LogUtil.log("Social contents list size is: " + socialContents.size(), LogLevel.LOW);
        //return socialContents;
    }

    @SuppressWarnings("unchecked")
    public static void getPostsMetrics(String token, String accountId, long date_range1, long date_range2) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/getPostMetrics.json");
//		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL(), date_range1, date_range2);
        inputData = inputData.replace("$accountId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        //LogUtil.log("Social contents list size is: " + socialContents.size(), LogLevel.LOW);
        //return socialContents;
    }

    @SuppressWarnings("unchecked")
    public static void getPostsMetrics2(String token, String franchisorId, String date_range1, String date_range2) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/postMetrics.json");
//		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL(), date_range1, date_range2);
        inputData = inputData.replace("$franchisorId", franchisorId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        //LogUtil.log("Social contents list size is: " + socialContents.size(), LogLevel.LOW);
        //return socialContents;
    }

    @SuppressWarnings("unchecked")
    public static void getConsolidateAdvocacy(String token, String accountId, long date_range1, long date_range2) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/getConsolidateAdvocacy.json");
//		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL(), String.valueOf(date_range1), String.valueOf(date_range2));
        inputData = inputData.replace("$accountId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        //List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        //LogUtil.log("Social contents list size is: " + socialContents.size(), LogLevel.LOW);
        //return socialContents;
    }

    @SuppressWarnings("unchecked")
    public static void getTotalMetricsOverview(String token, String accountId, long date_range1, long date_range2) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/getTotalMetricsOverview.json");
//		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL(), String.valueOf(date_range1), String.valueOf(date_range2));
        inputData = inputData.replace("$accountId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        //LogUtil.log("Social contents list size is: " + socialContents.size(), LogLevel.LOW);
        //return socialContents;
    }

    @SuppressWarnings("unchecked")
    public static void getTotalMetricsOverview2(String token, String franchisorId, String date_range1, String date_range2) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/totalMetricsOverview.json");
//		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL(), date_range1, date_range2);
        inputData = inputData.replace("$franchisorId", franchisorId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        //LogUtil.log("Social contents list size is: " + socialContents.size(), LogLevel.LOW);
        //return socialContents;
    }

    @SuppressWarnings("unchecked")
    public static List<SocialContents> getOutboxSocialContents(String token, int page, String accountId, long date_range1, long date_range2) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/getOutboxSocialContents.json");
//		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL(), page, date_range1, date_range2);
        inputData = inputData.replace("$accountId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsonPath = new JsonPath(responseBody);
        List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        LogUtil.log("Social contents list size is: " + socialContents.size(), LogLevel.LOW);
        return socialContents;
    }

    /**
     * Gets the inbox social contents sample.
     *
     * @param token the token
     * @return the inbox social contents sample
     * @throws Exception the exception
     */
    @SuppressWarnings("unchecked")
    public static List<SocialContents> getInboxSocialContentsSample(String token) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/getInboxSocialContentsSample.json");
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        JsonPath jsonPath = new JsonPath(responseBody);
        List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        return socialContents;
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> mobileAppLogin() throws Exception {

        LogUtil.log("Login API", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/mobileAppGetSessions.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().queryParams((Map<String, ?>) payload.get("parameters")).body((Map<String, ?>) payload.get("parameters")).when()
                .post(new URI((String) payload.get("url")));
        Assert.assertNotNull(response.getBody(), "Recieved Null Response");
        LogUtil.log("Response Code :" + response.getStatusCode(), LogLevel.LOW);
        LogUtil.log("Response Message: " + response.getBody().asString(), LogLevel.LOW);
        JsonPath jsonPath = new JsonPath(response.getBody().asString());
        String token = null;

        token = jsonPath.getString("rallio_access_token.token");
        User user = jsonPath.getObject(("user"), User.class);
        LogUtil.log("Token id : " + token, LogLevel.LOW);
        return Stream
                .of(new AbstractMap.SimpleEntry<>("responseCode", String.valueOf(response.getStatusCode())), new AbstractMap.SimpleEntry<>("tokenId", token),
                        new AbstractMap.SimpleEntry<>("user", user)).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    @SuppressWarnings("unchecked")
    public static void getMobileAppPhotos(String token, String accountId) throws Exception {

        LogUtil.log("Get MobileApp photos", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/mobileAppGetPhotos.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL(), accountId);
        //inputData = inputData.replace("$accountId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).header("Content-Type", "application/json").body((Map<String, ?>) payload.get("parameters")).post(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getSocialAnalyticsSummary(String token, String accountId, String startDate, String endDate) throws Exception {

        LogUtil.log("Get SocialAnalytics summary", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/socialAnalyticsSummary.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", accountId);
        inputData = inputData.replace("$start_date", startDate);
        inputData = inputData.replace("$end_date", endDate);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getSocialAnalytics(String token, String accountId, String startDate, String endDate) throws Exception {

        LogUtil.log("Get SocialAnalytics", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/socialAnalytics.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", accountId);
        inputData = inputData.replace("$start_date", startDate);
        inputData = inputData.replace("$end_date", endDate);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getContentAnalyticsFacebookStats(String token, String accountId, String startDate, String endDate) throws Exception {

        LogUtil.log("Get ContentAnalytics facebook stats", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/contentAnalyticsFacebookStats.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", accountId);
        inputData = inputData.replace("$start_date", startDate);
        inputData = inputData.replace("$end_date", endDate);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getProfileAnalytics(String token, String accountId, String startDate, String endDate) throws Exception {

        LogUtil.log("Get ProfileAnalytics", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getProfileAnalytics.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$accountId", accountId);
        inputData = inputData.replace("$start_date", startDate);
        inputData = inputData.replace("$end_date", endDate);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getProfileAnalytics2(String token, String franchisorId, String startDate, String endDate) throws Exception {

        LogUtil.log("Get ProfileAnalytics", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/profileAnalytics.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", franchisorId);
        inputData = inputData.replace("$start_date", startDate);
        inputData = inputData.replace("$end_date", endDate);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getReviewAnalytics(String token, String accountId, String startDate, String endDate) throws Exception {

        LogUtil.log("Get ReviewAnalytics", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/reviewAnalytics.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).queryParam("date_range[]", startDate, endDate).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getReviewAnalyticsReplied(String token, String accountId, String startDate, String endDate) throws Exception {

        LogUtil.log("Get ReviewAnalytics Replied", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/reviewAnalyticsSegmentAsReplied.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).queryParam("date_range[]", startDate, endDate).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getReviewAnalyticsSummary(String token, String accountId, String startDate, String endDate) throws Exception {

        LogUtil.log("Get ReviewAnalytics Summary", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/reviewAnalyticsSummary.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).queryParam("date_range[]", startDate, endDate).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getAnalyticsLeaderboard(String token, String startDate, String endDate) throws Exception {

        LogUtil.log("Get Analytics leaderboard", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/analyticsLeaderboard.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$start_date", startDate);
        inputData = inputData.replace("$end_date", endDate);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getContentsStats(String token, String accountId, String startDate, String endDate) throws Exception {

        LogUtil.log("Get ContentsStats", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getContentsStats.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).queryParam("date_range[]", startDate, endDate).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getContentsSummaries(String token, String accountId, String startDate, String endDate) throws Exception {

        LogUtil.log("Get ContentsSummaries", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/getContentsSummaries.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", accountId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).queryParam("date_range[]", startDate, endDate).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getSandboxSocialContents2(String token, String franchisorId, String startDate, String endDate) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/sandboxSocialContents.json");
//		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", franchisorId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).queryParams("date_range[]", startDate).queryParams("date_range[]", endDate).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        //LogUtil.log("Social contents list size is: " + socialContents.size(), LogLevel.LOW);
        //return socialContents;
    }

    @SuppressWarnings("unchecked")
    public static void getSandboxSocialContentsStats(String token, String franchisorId, String startDate, String endDate) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/sandboxSocialContentsStats.json");
//		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", franchisorId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).queryParams("date_range[]", startDate).queryParams("date_range[]", endDate).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        //LogUtil.log("Social contents list size is: " + socialContents.size(), LogLevel.LOW);
        //return socialContents;
    }

    @SuppressWarnings("unchecked")
    public static void getReviews(String token, String franchisorId, String startDate, String endDate) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/getReviews.json");
//		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", franchisorId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).queryParams("date_range[]", startDate).queryParams("date_range[]", endDate).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        //LogUtil.log("Social contents list size is: " + socialContents.size(), LogLevel.LOW);
        //return socialContents;
    }

    @SuppressWarnings("unchecked")
    public static void getReviewsStats(String token, String franchisorId, String startDate, String endDate) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/getReviewsStats.json");
//		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", franchisorId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).queryParams("date_range[]", startDate).queryParams("date_range[]", endDate).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        //LogUtil.log("Social contents list size is: " + socialContents.size(), LogLevel.LOW);
        //return socialContents;
    }

    @SuppressWarnings("unchecked")
    public static void getOutboxSocialContents2(String token, String franchisorId, String startDate, String endDate) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/outboxSocialContents.json");
//		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", franchisorId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).queryParams("date_range[]", startDate).queryParams("date_range[]", endDate).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        //LogUtil.log("Social contents list size is: " + socialContents.size(), LogLevel.LOW);
        //return socialContents;
    }

    @SuppressWarnings("unchecked")
    public static void getOutboxSocialContentsStats(String token, String franchisorId, String startDate, String endDate) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/outboxSocialContentsStats.json");
//		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", franchisorId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).queryParams("date_range[]", startDate).queryParams("date_range[]", endDate).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        //LogUtil.log("Social contents list size is: " + socialContents.size(), LogLevel.LOW);
        //return socialContents;
    }

    @SuppressWarnings("unchecked")
    public static void getDatewisePostMetrics(String token, String franchisorId, String startDate, String endDate) throws Exception {

        LogUtil.log("Get Datewise post metrics", LogLevel.LOW);
        String inputData = FileUtil.getStringData("NewRallioAPIs/datewisePostMetrics.json");
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", franchisorId);
        inputData = inputData.replace("$start_date", startDate);
        inputData = inputData.replace("$end_date", endDate);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<Photos> photos = Arrays.asList(jsonPath.getObject(("photos"), Photos[].class));
        //return photos;
    }

    @SuppressWarnings("unchecked")
    public static void getRecentPosts(String token, String franchisorId, String date_range1, String date_range2) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/recentPosts.json");
//		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL(), date_range1, date_range2);
        inputData = inputData.replace("$franchisorId", franchisorId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        //LogUtil.log("Social contents list size is: " + socialContents.size(), LogLevel.LOW);
        //return socialContents;
    }

    @SuppressWarnings("unchecked")
    public static void getConsolidateAdvocacy2(String token, String franchisorId, String date_range1, String date_range2) throws Exception {

        String inputData = FileUtil.getStringData("NewRallioAPIs/consolidateAdvocacy.json");
//		long[] date_range = DateRangeUtil.getCurrentDateTimeRange();
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL(), date_range1, date_range2);
        inputData = inputData.replace("$franchisorId", franchisorId);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        //JsonPath jsonPath = new JsonPath(responseBody);
        //List<SocialContents> socialContents = Arrays.asList(jsonPath.getObject(("social_contents"), SocialContents[].class));
        //LogUtil.log("Social contents list size is: " + socialContents.size(), LogLevel.LOW);
        //return socialContents;
    }


    @SuppressWarnings("unchecked")
    public static void getAIAssistedAndNonAssistedPosts(String token, String accountId, String assistedTypeValue) throws Exception {

        String expectedPhrase = "\\bai_post=\\S+\\b";
        String inputData = null;
        if (accountId.length() == 4) {
            inputData = FileUtil.getStringData("NewRallioAPIs/getAIAssistedNonAssistedPosts.json");
            inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
            inputData = inputData.replace("$accountid", accountId);
        } else if (accountId.length() == 5) {
            inputData = FileUtil.getStringData("NewRallioAPIs/getAIAssistedAndNonAssistedPostsInBrandLevel.json");
            inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
            inputData = inputData.replace("$franchisorId", accountId);
        }
        inputData = inputData.replace("$assistedNonAssisted", assistedTypeValue);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertEquals(responseCode, 200, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        JsonPath jsnPath = new JsonPath(responseBody);
        String yourJson = jsnPath.getJsonObject("saved_post_summaries").toString();
        System.out.println("Expected : " + JsonUtil.getObject(yourJson, String.class));
        Pattern pattern = Pattern.compile(expectedPhrase);
        Matcher matcher = pattern.matcher(yourJson);
        if (assistedTypeValue.equals("1")) {
            while (matcher.find()) {
                System.out.println("Matcher : " + matcher.group());
                Assert.assertTrue(matcher.group().contains("true"));
            }
        } else if (assistedTypeValue.equals("0")) {
            while (matcher.find()) {
                System.out.println("Matcher : " + matcher.group());
                Assert.assertTrue(matcher.group().contains("false"));
            }
        }
    }


    public static int validateSocialMediasAIPostsType(String filePath, String token, String francisorId, String from_yyyy_mm_dd, String to_yyyy_mm_dd, String postType, String expectedJsonKey) throws Exception {

        int postCountInAPIResponse = 0;

        LogUtil.log("Get ContentAnalytics AI- Posts Verification In Facebook Posts.", LogLevel.LOW);
        String inputData = FileUtil.getStringData(filePath);
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", francisorId);
        inputData = inputData.replace("$start_date", from_yyyy_mm_dd);
        inputData = inputData.replace("$end_date", to_yyyy_mm_dd);
        if (postType != null)
            inputData = inputData.replace("$aiPostType", postType);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);

        LogUtil.log("URL " + payload.get("url") + payload.get("parameters"), LogLevel.LOW);
        @SuppressWarnings("unchecked")
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        //	LogUtil.log("Response Status : " + response.getStatusCode()+" && Response Time :"+response.getTime()+"\nResponse Body : "+response.getBody().asPrettyString(), LogLevel.LOW);
        System.out.println("Status : " + response.getStatusCode() + " Time : " + response.getTime());
        //	Assert.assertTrue(response.getStatusCode() == 200 && response.getTime() < 5000 , "Invalid Response Code");
        if (postType == null)
            postCountInAPIResponse = NewRallioAPI.getNoOfPostsPresentInTheResponse(response.getBody().asPrettyString(), expectedJsonKey, "id");
        else
            postCountInAPIResponse = verifyExpectedAIPostIsPresent(response.getBody().asPrettyString(), Integer.valueOf(postType), expectedJsonKey);

        return postCountInAPIResponse;

    }

    public static int verifyExpectedAIPostIsPresent(String responseBody, int assistedTypeValue, String jsonObjectName) throws Exception {

        String expectedPhrase = "\\bai_post=\\S+\\b";
        int postsCount = 0;

        JsonPath jsnPath = new JsonPath(responseBody);
        String yourJson = jsnPath.getJsonObject(jsonObjectName).toString();
        System.out.println("Expected : " + JsonUtil.getObject(yourJson, String.class));
        Pattern pattern = Pattern.compile(expectedPhrase);
        Matcher matcher = pattern.matcher(yourJson);
        if (assistedTypeValue == 1) {
            while (matcher.find()) {
                System.out.println("Matcher : " + matcher.group());
                Assert.assertTrue(matcher.group().contains("true"));
                postsCount++;
            }
        } else if (assistedTypeValue == 0) {
            while (matcher.find()) {
                System.out.println("Matcher : " + matcher.group());
                Assert.assertTrue(matcher.group().contains("false"));
                postsCount++;
            }
        }

        return postsCount;
    }


    public static int getNoOfPostsPresentInTheResponse(String responseBody, String expectedJsonRootKey, String expectedJsonSubKey) throws Exception {

        JsonNode nodeData = null;
        Set<String> posts = new HashSet<String>();

        ObjectMapper mapper = new ObjectMapper();
        JsonNode node = (mapper.readTree(responseBody));
        if (node != null)
            nodeData = node.get(expectedJsonRootKey);
        System.out.println(nodeData.size());
        if (nodeData != null) {
            int i = 0;
            while (i < nodeData.size()) {
                String id = nodeData.get(i).get(expectedJsonSubKey).asText();
                posts.add(id);
                System.out.println(id);
                i++;
            }
            System.out.println(posts + " : " + posts.size());
        } else
            return 0;

        return posts.size();

    }

    public static int getNoOfPostsPresentInTheResponse(Response response, String jsonPath) throws Exception {

        List<String> posts = null;
        if (response.getStatusCode() == 200) {

            try {
                posts = JsonPath.from(response.asString()).getList(jsonPath);
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        } else
            LogUtil.log("Invalid Status Code " + response.getStatusCode(), LogLevel.LOW);

        if (posts != null)
            return posts.size();

        return 0;
    }


    public static int validateSocialMediaReelsAIPostsType(String filePath, String token, String francisorId, String from_yyyy_mm_dd, String to_yyyy_mm_dd, String postType, String expectedJsonKey) throws Exception {

        int postCountInAPIResponse = 0;

        LogUtil.log("Get ContentAnalytics AI-Posts Verification In Facebook Posts.", LogLevel.LOW);
        String inputData = FileUtil.getStringData(filePath);
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", francisorId);
        inputData = inputData.replace("$start_date", from_yyyy_mm_dd);
        inputData = inputData.replace("$end_date", to_yyyy_mm_dd);
        if (postType != null)
            inputData = inputData.replace("$aiPostType", postType);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);

        LogUtil.log("URL " + payload.get("url") + payload.get("parameters"), LogLevel.LOW);
        @SuppressWarnings("unchecked")
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        //	LogUtil.log("Response Status : " + response.getStatusCode()+" && Response Time :"+response.getTime()+"\nResponse Body : "+response.getBody().asPrettyString(), LogLevel.LOW);
        Assert.assertTrue(response.getStatusCode() == 200 && response.getTime() < 5000, "Invalid Response Code");
        if (postType == null)
            postCountInAPIResponse = NewRallioAPI.getNoOfPostsPresentInTheResponse(response.getBody().asPrettyString(), expectedJsonKey, "id");
        else
            postCountInAPIResponse = verifyExpectedAIPostIsPresent(response.getBody().asPrettyString(), Integer.valueOf(postType), expectedJsonKey);
        System.out.println("No Of Posts : " + NewRallioAPI.getNoOfPostsPresentInTheResponse(response.getBody().asPrettyString(), expectedJsonKey, "id"));

        return postCountInAPIResponse;

    }

    public static int validateSocialMediasAIPostsTypeInLocal(String filePath, String token, String francisorId, String from_yyyy_mm_dd, String to_yyyy_mm_dd, String postType, String expectedJsonKey) throws Exception {

        int postCountInAPIResponse = 0;

        LogUtil.log("Get ContentAnalytics AI-Posts Verification In Facebook Posts.", LogLevel.LOW);
        String inputData = FileUtil.getStringData(filePath);
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace("$franchisorId", francisorId);
        inputData = inputData.replace("$start_date", from_yyyy_mm_dd);
        inputData = inputData.replace("$end_date", to_yyyy_mm_dd);
        if (postType != null)
            inputData = inputData.replace("$aiPostType", postType);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);

        LogUtil.log("URL " + payload.get("url") + payload.get("parameters"), LogLevel.LOW);
        @SuppressWarnings("unchecked")
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
//	LogUtil.log("Response Status : " + response.getStatusCode()+" && Response Time :"+response.getTime()+"\nResponse Body : "+response.getBody().asPrettyString(), LogLevel.LOW);
        Assert.assertTrue(response.getStatusCode() == 200 && response.getTime() < 5000, "Invalid Response Code");
        if (postType == null)
            postCountInAPIResponse = NewRallioAPI.getNoOfPostsPresentInTheResponse(response.getBody().asPrettyString(), expectedJsonKey, "id");
        else
            postCountInAPIResponse = verifyExpectedAIPostIsPresent(response.getBody().asPrettyString(), Integer.valueOf(postType), expectedJsonKey);
        System.out.println("No Of Posts : " + NewRallioAPI.getNoOfPostsPresentInTheResponse(response.getBody().asPrettyString(), expectedJsonKey, "id"));

        return postCountInAPIResponse;

    }


    @SuppressWarnings("unchecked")
    public static Response readFile(String token, String filelocation, String idformat, String idValue) throws Exception {

        LogUtil.log("Get Account Switcher", LogLevel.LOW);
        String inputData = FileUtil.getStringData(filelocation);
        inputData = String.format(inputData, APIUtil.getNewRallioBaseURL());
        inputData = inputData.replace(idformat, idValue);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertTrue(response.getStatusCode() == 200 && response.getTime() < 5000, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        return response;

    }

    public static Response readFile(String token, String apiUrl,String filelocation, String idformat, String idValue) throws Exception {

        LogUtil.log("Get Account Switcher", LogLevel.LOW);
        String inputData = FileUtil.getStringData(filelocation);
        inputData = String.format(inputData,apiUrl,idformat, idValue);
        inputData = inputData.replace(idformat, idValue);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().header("X-Rallio-API-Key", token).queryParams((Map<String, ?>) payload.get("parameters")).get(new URI((String) payload.get("url")));
        int responseCode = response.getStatusCode();
        String responseBody = response.getBody().asString();
        LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
        LogUtil.log(responseBody, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        Assert.assertTrue(response.getStatusCode() == 200 && response.getTime() < 5000, "Invalid Response Code");
        Assert.assertNotNull(responseBody, "Recieved Null Response");
        return response;

    }

    public static Map<String, Object> login(String filename,String url, String ssoToken) throws Exception {

        LogUtil.log("Login API", LogLevel.LOW);
        String inputData = FileUtil.getStringData(filename);
        inputData = String.format(inputData,url, ssoToken);
        System.out.println("Input data : " + inputData);
        Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
        LogUtil.log("Payload : " + payload, LogLevel.LOW);
        LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
        LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
        Response response = RestAssured.given().queryParams((Map<String, ?>) payload.get("parameters")).body((Map<String, ?>) payload.get("parameters")).when()
                .post(new URI((String) payload.get("url")));
        Assert.assertNotNull(response.getBody(), "Recieved Null Response");
        LogUtil.log("Response Code :" + response.getStatusCode(), LogLevel.LOW);
        LogUtil.log("Response Message: " + response.getBody().asString(), LogLevel.LOW);
        String accountId = null;
        JsonPath jsonPath = new JsonPath(response.getBody().asString());
        String token = null;
        boolean account = false;

        token = jsonPath.getString("rallio_access_token.token");
        if (jsonPath.getList("user_detail.accounts_managed").size() != 0) {
            String accountIdString = new ObjectMapper().writeValueAsString(jsonPath.getList("user_detail.accounts_managed").get(0));
            Map<String, Object> accountIdMap = APIUtil.read(accountIdString, HashMap.class, String.class, Object.class);
            accountId = accountIdMap.get("id").toString();
            account = true;
        } else {
            //accountId = jsonPath.getString("account.id");
            account = false;
        }
        User user = jsonPath.getObject(("user"), User.class);
        LogUtil.log("Token id " + token, LogLevel.LOW);
        LogUtil.log("Account Id:" + accountId, LogLevel.LOW);
        LogUtil.log(" ", LogLevel.LOW);
        try {
            return Stream
                    .of(new AbstractMap.SimpleEntry<>("responseCode", String.valueOf(response.getStatusCode())), new AbstractMap.SimpleEntry<>("tokenId", token),
                            new AbstractMap.SimpleEntry<>("accountId", accountId), new AbstractMap.SimpleEntry<>("user", user), new AbstractMap.SimpleEntry<>("account", account))
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        } catch (Exception e) {
            return Stream
                    .of(new AbstractMap.SimpleEntry<>("responseCode", String.valueOf(response.getStatusCode())), new AbstractMap.SimpleEntry<>("tokenId", token),
                            new AbstractMap.SimpleEntry<>("user", user), new AbstractMap.SimpleEntry<>("account", account))
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        }

    }

  public static  List<String> getPostContents(String token,String fileLocation,String previewSection,String imageName, String rootpath) throws Exception {
      String inputData = FileUtil.getStringData(fileLocation);
      inputData = String.format(inputData, APIUtil.getRallioBaseUrl(),previewSection,imageName);
      Map<String, Object> payload = APIUtil.read(inputData, HashMap.class, String.class, Object.class);
      LogUtil.log("URL " + payload.get("url"), LogLevel.LOW);
      LogUtil.log("Parameters " + payload.get("parameters"), LogLevel.LOW);
      Response response = RestAssured.given().header("X-Rallio-API-Key", token).header("Content-Type", "application/json").body((Map<String, ?>) payload.get("parameters")).post(new URI((String) payload.get("url")));
      int responseCode = response.getStatusCode();
      String responseBody = response.getBody().asPrettyString();
      LogUtil.log("Response Code :" + responseCode, LogLevel.LOW);
      LogUtil.log(responseBody, LogLevel.LOW);
      Assert.assertTrue(response.getStatusCode() == 200 && response.getTime() < 5000 , "Invalid Response Code");
      List<String> content = response.jsonPath().getList(rootpath);
      LogUtil.log("Response Content "+ content, LogLevel.LOW);
      return content;
  }


}

package com.rallio.automation.api.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum EmailAutoOpsEnum.
 */
public enum EmailAutoOpsEnum {

	/** The apiurl. */
	APIURL("http://localhost:8080/autoOpsRallioApi"), // for local validation purpose.

	/** The readmail. */
 READMAIL("/mailer/readMail"),

	/** The readsms. */
	READSMS("/mailer/readSMS"),

	/** The readandreplysms. */
	READANDREPLYSMS("/mailer/readSMSAndDoReply"),

	/** The readmailquickly. */
	READMAILQUICKLY("/mailer/readMailQuickly"),

	/** The readmailmarketing. */
	READMAILMARKETING("/mailer/readMailMarketing"),

	/** The writemail. */
	WRITEMAIL("/mailer/writeMail"),

	/** The add asr content. */
	ADD_ASR_CONTENT("/UrlHandler/loadFile"),

	/** The delete asr content. */
	DELETE_ASR_CONTENT("/UrlHandler/deleteFile");

	/** The email auto ops enum. */
	private final String emailAutoOpsEnum;

	/**
	 * Instantiates a new email auto ops enum.
	 *
	 * @param emailAutoOpsEnum the email auto ops enum
	 */
	private EmailAutoOpsEnum(final String emailAutoOpsEnum) {

		this.emailAutoOpsEnum = emailAutoOpsEnum;
	}

	/**
	 * Gets the email auto ops enum.
	 *
	 * @return the email auto ops enum
	 */
	public String getEmailAutoOpsEnum() {

		return emailAutoOpsEnum;
	}
	
}

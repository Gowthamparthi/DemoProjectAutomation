package com.rallio.automation.api.testlink;

import com.rallio.automation.common.enums.*;
import com.rallio.automation.common.manager.*;
import com.rallio.automation.common.util.*;
import org.joda.time.*;
import org.w3c.dom.*;
import testlink.api.java.client.*;

import javax.xml.parsers.*;
import java.io.*;
import java.util.*;

import static com.rallio.automation.common.manager.ConfigManager.*;

public class TestLinkResultsPush {

    private static String devKey = "33ee6398e1c021d7f3595d00a7e19c11";

    private static String testLinkUrl = "https://testlink.rallio.com/testlink/lib/api/xmlrpc/v1/xmlrpc.php";

    private static String projectName = "RallioV3";

    private static  TestLinkAPIClient apiClient = new TestLinkAPIClient(devKey, testLinkUrl);

    public static Map<String, String> getTestStatusFromXml(String moduleName) {
        Map<String, String> resultMap = new HashMap<>();
        try {
            String xmlPath = ParamUtil.isLamda() ? "" : "../";
            File file = new File(xmlPath + moduleName + "/testresult/testng-results.xml");
            //File file = new File(xmlPath + moduleName + "/test-output/testng-results.xml");
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(file);
            NodeList testNodes = document.getElementsByTagName("test");

            for (int i = 0; i < testNodes.getLength(); i++) {
                Element testElement = (Element) testNodes.item(i);
                NodeList classNodes = testElement.getElementsByTagName("class");

                for (int j = 0; j < classNodes.getLength(); j++) {
                    Element classElement = (Element) classNodes.item(j);
                    NodeList testMethodNodes = classElement.getElementsByTagName("test-method");

                    for (int k = 0; k < testMethodNodes.getLength(); k++) {
                        Element testMethodElement = (Element) testMethodNodes.item(k);
                        if (!testMethodElement.getAttribute("is-config").equalsIgnoreCase("true")) {
                            String testMethodName = testMethodElement.getAttribute("name");
                            String testMethodStatus = testMethodElement.getAttribute("status");
                            resultMap.put(testMethodName, testMethodStatus);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultMap;
    }

    public static Map<String, String> getPropertyValues(String propertyValue) {
        Map<String, String> resultMap = new HashMap<>();
        String[] keyValuePairs = propertyValue.substring(1, propertyValue.length() - 1).split(",");
        for (String pair : keyValuePairs) {
            String[] keyValue = pair.split("=");
            resultMap.put(keyValue[0], keyValue[1]);
        }
        return resultMap;
    }

    public static void updateTestStatusInTestLink(String projectName, String projectPlan, String caseId, String buildName, String status) {

        LogUtil.log("Validate update Test Status In TestLink", LogLevel.LOW);
        try {
            if (status.toLowerCase().contains("p")) {
                apiClient.reportTestCaseResult(projectName, projectPlan, caseId, buildName, "Test Passed", "p");
                LogUtil.log("Test result updated as " + status + " successfully in TestLink", LogLevel.LOW);
            } else if (status.toLowerCase().contains("f")) {
                apiClient.reportTestCaseResult(projectName, projectPlan, caseId, buildName, "Test Failed", "f");
                LogUtil.log("Test result updated as " + status + " successfully in TestLink", LogLevel.LOW);
            } else if (status.equals("SKIP") || status.toLowerCase().contains("n")) {
                apiClient.reportTestCaseResult(projectName, projectPlan, caseId, buildName, "Test Not Run", "n");
                LogUtil.log("Test result updated as " + status + " successfully in TestLink", LogLevel.LOW);
            } else
                LogUtil.log("Invalid status provided", LogLevel.LOW);
        } catch (TestLinkAPIException e) {
            e.printStackTrace();
        }
    }


    public static void validateTestLink(String moduleName,String propertyKey, String projectPlan, String buildName) {

        Map<String, String> getStatus = getTestStatusFromXml(moduleName);
        LogUtil.log("Method Name and Status : " + getStatus, LogLevel.LOW);
        Map<String, String> getMethodId = getPropertyValues(getValue(propertyKey));
        //  LogUtil.log("Method Name and ID : " + getMethodId, LogLevel.LOW);
        List<String> allKeys = new ArrayList<>(getStatus.keySet());
        long time = Calendar.getInstance().getTimeInMillis();
        String startTime = DateUtil.formatToZone(time, DateTimeZone.forID("Asia/Kolkata"), DateUtil.LARGE_FORMAT);
        LogUtil.log("TestLink Status Update START TIME : " + startTime, LogLevel.LOW);
        for (String key : allKeys) {
            if (getMethodId.get(key) != null) {
                LogUtil.log("Method Name : " + key + "Case Id = " + getMethodId.get(key) + " " + "Method Status = " + getStatus.get(key), LogLevel.LOW);
                updateTestStatusInTestLink(projectName, projectPlan, getMethodId.get(key), buildName, getStatus.get(key));
            }
            else
                LogUtil.log("Failed to update Method Name : " + key + "Case Id = " + getMethodId.get(key) + " " + "Method Status = " + getStatus.get(key), LogLevel.LOW);
        }
        long time2 = Calendar.getInstance().getTimeInMillis();
        String endTime = DateUtil.formatToZone(time2, DateTimeZone.forID("Asia/Kolkata"), DateUtil.LARGE_FORMAT);
        LogUtil.log("TestLink Status Update END TIME : " + endTime, LogLevel.LOW);
    }

    public static void updateReasultInTestLink(String environment, String moduleName,String className, String buildName) {

        if (environment.equals("stg")) {
            loadConfig(environment);
            createNewBuild(projectName, getValue("projectPlan"), buildName);
            validateTestLink(moduleName,className, getValue("projectPlan"), buildName);
        } else if (environment.equals("prod")) {
            loadConfig(environment);
            createNewBuild(projectName, getValue("projectPlan"), buildName);
            validateTestLink(moduleName,className, getValue("projectPlan"), buildName);
        } else
            LogUtil.log("Invalid Environment parameter specified.", LogLevel.LOW);
    }


    public static void addBuild(String projectPlan, String buildName) {
        TestLinkAPIClient apiClient = new TestLinkAPIClient(devKey, testLinkUrl);
        try {
            apiClient.createBuild(projectName, projectPlan, buildName, "Build created automatically with TestLink.");
            LogUtil.log("Build created successfully in TestLink.", LogLevel.LOW);
        } catch (TestLinkAPIException e) {
            e.printStackTrace();
        }
    }


    public static void createNewBuild(String projectName, String projectPlan, String buildName) {

        try {
            LogUtil.log("Fetching builds for project plan: " + projectPlan, LogLevel.LOW);
            TestLinkAPIResults results = apiClient.getLatestBuildForTestPlan(projectName, projectPlan);
            Map<String, Object> data = (Map<String, Object>) results.getData(0);
            LogUtil.log("Testlink created Build Data: " + data, LogLevel.LOW);
            Object name = data.get("name");
            String createdBuildName = (name != null) ? name.toString().replaceAll("[^a-zA-Z0-9]", "") : "";
            if (createdBuildName.toLowerCase().equalsIgnoreCase(buildName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase())) {
                LogUtil.log("Build with the name '" + buildName + "' already exists in TestLink.",LogLevel.LOW);
            } else {
                LogUtil.log("Creating build: " + buildName + " for project plan: " + projectPlan,LogLevel.LOW);
                addBuild(projectPlan, buildName);
            }
        } catch (TestLinkAPIException e) {
            e.printStackTrace();
            System.err.println("Failed to create build: " + e.getMessage());
        }
    }

    public static void loadConfig(String env) {

        try {
            if (env.equals("stg")) {
                ConfigManager.loadConfig("newrallioRegressionStg.properties");
                LogUtil.log(env +" Property file loaded successfully.",LogLevel.LOW);
            }
            else if(env.equals("prod")){
                ConfigManager.loadConfig("newrallioProdSanity.properties");
                LogUtil.log(env +" Property file loaded successfully.",LogLevel.LOW);
            }
        } catch (Exception e) {
            LogUtil.log("No config file Testlink.properties.",LogLevel.LOW);
        }
    }



}

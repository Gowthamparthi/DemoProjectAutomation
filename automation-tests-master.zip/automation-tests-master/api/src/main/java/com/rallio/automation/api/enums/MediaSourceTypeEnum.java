package com.rallio.automation.api.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum MediaSourceTypeEnum.
 */
public enum MediaSourceTypeEnum {

	/** The brand. */
	BRAND("brand"),

	/** The location. */
	LOCATION("local"),

	/** The all. */
	ALL("all");

	/** The media source type. */
	private String mediaSourceType;

	/**
	 * Instantiates a new media source type enum.
	 *
	 * @param mediaSourceType the media source type
	 */
	private MediaSourceTypeEnum(String mediaSourceType) {
		this.mediaSourceType = mediaSourceType;
	}

	/**
	 * Gets the media source type.
	 *
	 * @return the media source type
	 */
	public String getMediaSourceType() {
		return mediaSourceType;
	}
}

package com.rallio.automation.api.util;

import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.dataformat.xml.*;
import com.rallio.automation.common.enums.*;
import com.rallio.automation.common.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class JSONUtil.
 */
public final class APIUtil {

	/** The Constant mapper. */
	private static final ObjectMapper mapper = new ObjectMapper();

	/**
	 * Instantiates a new JSON util.
	 */
	private APIUtil() {

	}

	/**
	 * Read.
	 *
	 * @param <T> the generic type
	 * @param input the input
	 * @param clazz the clazz
	 * @return the t
	 * @throws Exception the exception
	 */
	public static <T> T read(String input, Class<T> clazz) throws Exception {

		T result = null;

		try {
			result = mapper.readValue(input, clazz);
		} catch (Exception e) {
			throw new Exception(e);
		}

		return result;
	}

	/**
	 * Read.
	 *
	 * @param <T> the generic type
	 * @param input the input
	 * @param collectionClass the collection class
	 * @param elementClass the element class
	 * @return the list
	 * @throws Exception the exception
	 */
	@SuppressWarnings("rawtypes")
	public static <T> List<T> read(String input, Class<? extends Collection> collectionClass, Class<T> elementClass) throws Exception {

		List<T> result = null;

		try {
			result = mapper.readValue(input, mapper.getTypeFactory().constructCollectionType(collectionClass, elementClass));
		} catch (Exception e) {
			throw new Exception(e);
		}

		return result;
	}

	/**
	 * Write.
	 *
	 * @param <T> the generic type
	 * @param input the input
	 * @return the string
	 * @throws Exception the exception
	 */
	public static <T> String write(T input) throws Exception {

		String result = null;

		try {
			result = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(input);
		} catch (Exception e) {
			throw new Exception(e);
		}

		return result;
	}

	/**
	 * Read.
	 *
	 * @param <T> the generic type
	 * @param <K> the key type
	 * @param <V> the value type
	 * @param input the input
	 * @param mapClass the map class
	 * @param keyClass the key class
	 * @param valueClass the value class
	 * @return the map
	 * @throws Exception the exception
	 */
	@SuppressWarnings("rawtypes")
	public static <T, K, V> Map<K, V> read(String input, Class<? extends Map> mapClass, Class<K> keyClass, Class<V> valueClass) throws Exception {

		Map<K, V> result = null;

		try {
			result = mapper.readValue(input, mapper.getTypeFactory().constructMapType(mapClass, keyClass, valueClass));
		} catch (Exception e) {
			throw new Exception(e);
		}

		return result;
	}

	/**
	 * Gets the map from xml data.
	 *
	 * @param input the input
	 * @return the map from xml data
	 * @throws JsonParseException the json parse exception
	 * @throws JsonMappingException the json mapping exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, Object> getMapFromXmlData(String input) throws JsonParseException, JsonMappingException, IOException {

		XmlMapper xmlMapper = new XmlMapper();
		Map<String, Object> data = xmlMapper.readValue(input, Map.class);

		return data;
	}

	/**
	 * Gets the rallio activate base URL.
	 *
	 * @return the rallio activate base URL
	 */
	public static String getRallioActivateBaseURL() {

		String env = System.getProperty("env");
		switch (env) {

		case "prod":
			return "https://app.rallio.com";

		case "stg":
			return "https://rallio-staging.herokuapp.com";

		default:
			LogUtil.log("Invalid Parameter Specified", LogLevel.LOW);
			return null;
		}
	}

	/**
	 * Gets the rallio activate reward base URL.
	 *
	 * @return the rallio activate reward base URL
	 */
	public static String getRallioActivateRewardBaseURL() {

		String env = System.getProperty("env");
		switch (env) {

		case "prod":
			return "https://activate-api.rallio.com";

		case "stg":
			return "https://activate-nodeapi-staging.rallio.com";

		default:
			LogUtil.log("Invalid Parameter Specified", LogLevel.LOW);
			return null;
		}
	}

	/**
	 * Gets the new rallio base URL.
	 *
	 * @return the new rallio base URL
	 */
	public static String getNewRallioBaseURL() {

		String env = System.getProperty("env");
		switch (env) {

		case "prod":
			return "https://app.rallio.com";

		case "stg":
			return "https://rallio-staging.herokuapp.com";

		default:
			LogUtil.log("Invalid Parameter Specified", LogLevel.LOW);
			return null;
		}
	}

	public static String getRallioBaseUrl() {

		String env = System.getProperty("env");
		switch (env) {

			case "stg":
				return "https://app-staging.rallio.com";

			default:
				LogUtil.log("Invalid Parameter Specified", LogLevel.LOW);
				return null;
		}
	}

}
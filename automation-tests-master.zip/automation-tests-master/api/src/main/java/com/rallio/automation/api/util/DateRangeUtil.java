package com.rallio.automation.api.util;

import java.text.*;

import java.util.*;

import org.testng.*;

import java.time.*;

import com.rallio.automation.business.enums.*;
import com.rallio.automation.common.enums.*;
import com.rallio.automation.common.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class DateRangeUtil.
 */
public class DateRangeUtil {

	/**
	 * Gets the current time stamp.
	 *
	 * @return the current time stamp
	 */
	public static long getCurrentTimeStamp() {

		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat format = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss aa");
		String currentDate = format.format(calendar.getTime());
		Date currentDateTime = null;
		try {
			currentDateTime = format.parse(currentDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return currentDateTime.getTime();
	}

	/**
	 * Gets the time stamp.
	 *
	 * @param dateRange the date range
	 * @return the time stamp
	 */
	public static String getTimeStamp(DateRange dateRange) {

		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat format = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss aa");
		int month = calendar.get(Calendar.MONTH);
		int year = calendar.get(Calendar.YEAR);
		long startDate = 0;
		long endDate = 0;
		switch (dateRange) {

		case MONTH_TO_DATE:
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, month);
			calendar.set(Calendar.DAY_OF_MONTH, 0);
			calendar.set(Calendar.HOUR, 12);
			calendar.set(Calendar.MINUTE, 00);
			calendar.set(Calendar.SECOND, 00);
			calendar.set(Calendar.AM_PM, 1);
			startDate = getTime(calendar, format);
			endDate = getCurrentTimeStamp();
			break;

		case YEAR_TO_DATE:
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, 0);
			calendar.set(Calendar.DAY_OF_MONTH, 0);
			calendar.set(Calendar.HOUR, 12);
			calendar.set(Calendar.MINUTE, 00);
			calendar.set(Calendar.SECOND, 00);
			calendar.set(Calendar.AM_PM, 1);
			startDate = getTime(calendar, format);
			endDate = getCurrentTimeStamp();
			break;

		case ALL_TIME:
			startDate = 0;
			endDate = getCurrentTimeStamp();
			break;

		case LAST_MONTH:
			calendar.add(Calendar.MONTH, -1);
			year = calendar.get(Calendar.YEAR);
			month = calendar.get(Calendar.MONTH);
			calendar.set(Calendar.DAY_OF_MONTH, 0);
			calendar.set(Calendar.HOUR, 12);
			calendar.set(Calendar.MINUTE, 00);
			calendar.set(Calendar.SECOND, 00);
			calendar.set(Calendar.AM_PM, 1);
			startDate = getTime(calendar, format);
			Calendar endCalendar = calendar;
			endCalendar.set(Calendar.YEAR, year);
			endCalendar.set(Calendar.MONTH, month);
			endCalendar.set(Calendar.DAY_OF_MONTH, endCalendar.getActualMaximum(Calendar.DATE));
			endCalendar.set(Calendar.HOUR, 11);
			endCalendar.set(Calendar.MINUTE, 59);
			endCalendar.set(Calendar.SECOND, 59);
			endCalendar.set(Calendar.AM_PM, 1);
			endDate = getTime(endCalendar, format);
			break;

		default:
			LogUtil.log("Invalid Option '" + dateRange.getText() + "'", LogLevel.LOW);
			Assert.assertFalse(true, "Invalid Option '" + dateRange.getText() + "'");
			break;

		}

		return String.valueOf(startDate / 1000 + "-" + endDate / 1000);

	}

	/**
	 * Gets the time.
	 *
	 * @param calendar the calendar
	 * @param format   the format
	 * @return the time
	 */
	public static long getTime(Calendar calendar, SimpleDateFormat format) {

		String desiredDate = format.format(calendar.getTime());
		Date desiredDateTime = null;
		try {
			desiredDateTime = format.parse(desiredDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return desiredDateTime.getTime();
	}

	/**
	 * Gets the current date time range.
	 *
	 * @return the current date time range
	 */
	public static long[] getCurrentDateTimeRange() {

		LocalDateTime ldt = LocalDateTime.now();
		System.out.println(ldt);
		LocalDateTime startOfDay = ldt.with(LocalTime.MIN).minusMonths(1);
		long epoch = startOfDay.toEpochSecond(ZoneOffset.ofHoursMinutes(5, 30));
		System.out.println(epoch);
		LogUtil.log("Start date range: " + epoch, LogLevel.LOW);

		ZonedDateTime zdt = ZonedDateTime.now(ZoneId.of("America/Los_Angeles"));
		long epoch1 = zdt.toEpochSecond();
		LogUtil.log("End date range: " + epoch1, LogLevel.LOW);
		long[] date_range = { epoch, epoch1 };
		return date_range;
	}
}

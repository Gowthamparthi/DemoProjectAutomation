package com.rallio.automation.api.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum PostUsageTypeEnum.
 */
public enum MediaReleaseFormTypeEnum {

	/** The with. */
	WITH("1"),

	/** The without. */
	WITHOUT("0");

	/** The media release form type. */
	private String mediaReleaseFormType;

	/**
	 * Instantiates a new post usage type enum.
	 *
	 * @param mediaReleaseFormType the media release form type
	 */
	private MediaReleaseFormTypeEnum(String mediaReleaseFormType) {
		this.mediaReleaseFormType = mediaReleaseFormType;
	}
	
	public String getMediaReleaseFormType() {
		return this.mediaReleaseFormType;
	}
}
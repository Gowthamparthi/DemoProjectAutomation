package com.rallio.automation.api.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum RankingTargetTypeEnum.
 */
public enum RankingTargetTypeEnum {

	/** The locations. */
	LOCATIONS("location"),

	/** The employee. */
	EMPLOYEE("employee");

	/** The filter type. */
	private String filterType;

	/**
	 * Instantiates a new ranking target type enum.
	 *
	 * @param filterType the filter type
	 */
	private RankingTargetTypeEnum(String filterType) {
		this.filterType = filterType;
	}

	/**
	 * Gets the filter type.
	 *
	 * @return the filter type
	 */
	public String getFilterType() {
		return filterType;
	}
	
	
}

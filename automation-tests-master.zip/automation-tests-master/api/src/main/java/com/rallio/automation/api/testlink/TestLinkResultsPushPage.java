package com.rallio.automation.api.testlink;

import br.eti.kinoshita.testlinkjavaapi.*;
import br.eti.kinoshita.testlinkjavaapi.constants.*;
import br.eti.kinoshita.testlinkjavaapi.model.*;
import com.rallio.automation.common.enums.*;
import com.rallio.automation.common.manager.*;
import com.rallio.automation.common.util.*;
import org.joda.time.*;
import org.w3c.dom.*;
import testlink.api.java.client.*;

import javax.xml.parsers.*;
import java.io.*;
import java.net.*;
import java.util.*;

import static com.rallio.automation.common.manager.ConfigManager.*;

public class TestLinkResultsPushPage {

    private static String devKey = "33ee6398e1c021d7f3595d00a7e19c11";

 // private static String testLinkUrl = "https://testlink.rallio.com/testlink/lib/api/xmlrpc/v1/xmlrpc.php";

    private static String testLinkUrl = "https://testlink.rallio.com/lib/api/xmlrpc/v1/xmlrpc.php";

 //   private static String testLinkUrl = "http://34.220.104.33:8080/lib/api/xmlrpc/v1/xmlrpc.php";

    private static String projectName = "RallioV3";

    private static  TestLinkAPIClient apiClient = new TestLinkAPIClient(devKey, testLinkUrl);

    private static   TestLinkAPI api;

    static {
        try {
            api = new TestLinkAPI(new URL(testLinkUrl), devKey);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }

    public static Map<String, String> getPropertyValues(String propertyValue) {
        Map<String, String> resultMap = new HashMap<>();
        String[] keyValuePairs = propertyValue.substring(1, propertyValue.length() - 1).split(",");
        for (String pair : keyValuePairs) {
            String[] keyValue = pair.split("=");
            resultMap.put(keyValue[0], keyValue[1]);
        }
        return resultMap;
    }

    public static Map<String, String> getTestStatusFromXml(String moduleName) {
        Map<String, String> resultMap = new HashMap<>();
        try {
            String xmlPath = ParamUtil.isLamda() ? "" : "../";
            File file = new File(xmlPath + moduleName + "/testresult/testng-results.xml");
            //File file = new File(xmlPath + moduleName + "/test-output/testng-results.xml");
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(file);
            NodeList testNodes = document.getElementsByTagName("test");

            for (int i = 0; i < testNodes.getLength(); i++) {
                Element testElement = (Element) testNodes.item(i);
                NodeList classNodes = testElement.getElementsByTagName("class");

                for (int j = 0; j < classNodes.getLength(); j++) {
                    Element classElement = (Element) classNodes.item(j);
                    NodeList testMethodNodes = classElement.getElementsByTagName("test-method");

                    for (int k = 0; k < testMethodNodes.getLength(); k++) {
                        Element testMethodElement = (Element) testMethodNodes.item(k);
                        if (!testMethodElement.getAttribute("is-config").equalsIgnoreCase("true")) {
                            String testMethodName = testMethodElement.getAttribute("name");
                            String testMethodStatus = testMethodElement.getAttribute("status");
                            resultMap.put(testMethodName, testMethodStatus);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultMap;
    }

    public static void pushTestResult(String propertyKey,String moduleName) throws TestLinkAPIException {

        Map<String, String> getStatus = getTestStatusFromXml(moduleName);
        LogUtil.log("Method Name and Status : " + getStatus, LogLevel.LOW);
        Map<String, String> getMethodId = getPropertyValues(getValue(propertyKey));
        List<String> allKeys = new ArrayList<>(getStatus.keySet());
        long time = Calendar.getInstance().getTimeInMillis();
        String startTime = DateUtil.formatToZone(time, DateTimeZone.forID("Asia/Kolkata"), DateUtil.LARGE_FORMAT);
        LogUtil.log("TestLink Status Update START TIME : " + startTime, LogLevel.LOW);
        for (String key : allKeys) {
            if (getMethodId.get(key) != null) {
                Map<String, String> getCaseId = mappingCaseIdandExternalId(getTestSuiteId(getMethodId.get(key)));
                //  LogUtil.log("ExternalId = " + getMethodId.get(key), LogLevel.LOW);
                if (getStatus.get(key).toLowerCase().equals("pass")) {
                    LogUtil.log("Method Name : " + key + " " + "ExternalId = " + getMethodId.get(key) + " " + " Method Status = " + getStatus.get(key) + " CaseId =" + Integer.valueOf(getCaseId.get(getMethodId.get(key))) + " Latest Build Id " + getlatestBuildId(), LogLevel.LOW);
                    apiClient.reportTestCaseResult(Integer.valueOf(getValue("testPlanId")), Integer.valueOf(getCaseId.get(getMethodId.get(key))), getlatestBuildId(), "Test Passed", "p");
                    LogUtil.log("Test result updated as " + getStatus.get(key) + " successfully in TestLink", LogLevel.LOW);
                } else if (getStatus.get(key).toLowerCase().equals("fail")) {
                    LogUtil.log("Method Name : " + key + " " + "ExternalId = " + getMethodId.get(key) + " " + " Method Status = " + getStatus.get(key) + " CaseId =" + Integer.valueOf(getCaseId.get(getMethodId.get(key))) + " Latest Build Id " + getlatestBuildId(), LogLevel.LOW);
                    apiClient.reportTestCaseResult(Integer.valueOf(getValue("testPlanId")), Integer.valueOf(getCaseId.get(getMethodId.get(key))), getlatestBuildId(), "Test Failed", "f");
                    LogUtil.log("Test result updated as " + getStatus.get(key) + " successfully in TestLink", LogLevel.LOW);
//                } else if (getStatus.get(key).toLowerCase().equals("skip") || getStatus.get(key).toLowerCase().contains("n")) {
//                    LogUtil.log("Method Name : " + key + " " + "ExternalId = " + getMethodId.get(key) + " " + " Method Status = " + getStatus.get(key) + " CaseId =" + Integer.valueOf(getCaseId.get(getMethodId.get(key))) + " Latest Build Id " + getlatestBuildId(), LogLevel.LOW);
//                    apiClient.reportTestCaseResult(Integer.valueOf(getValue("testPlanId")), Integer.valueOf(getCaseId.get(getMethodId.get(key))), getlatestBuildId(), "Test NotRun", "n");
//                    LogUtil.log("Test result updated as " + getStatus.get(key) + " successfully in TestLink", LogLevel.LOW);
                } else
                    LogUtil.log("Test result updated as SKIP " + "Method Name : " + key + " " + "ExternalId = " + getMethodId.get(key) +" Method Status = " + getStatus.get(key)+ " CaseId =" +  Integer.valueOf(getCaseId.get(getMethodId.get(key))) + " successfully in TestLink", LogLevel.LOW);
            }
        }
        long time2 = Calendar.getInstance().getTimeInMillis();
        String endTime = DateUtil.formatToZone(time2, DateTimeZone.forID("Asia/Kolkata"), DateUtil.LARGE_FORMAT);
        LogUtil.log("TestLink Status Update END TIME : " + endTime, LogLevel.LOW);
    }

    public static int getlatestBuildId()   {

        Build testPlanId = api.getLatestBuildForTestPlan( Integer.parseInt(getValue("testPlanId")));
        int latestbuildId = testPlanId.getId();
       // LogUtil.log("latestBuildForTestPlan = " + latestbuildId, LogLevel.LOW);
        return latestbuildId;
    }


    public  static Map<String, String> mappingCaseIdandExternalId(int suitId){

        TestCase[] testCases = api.getTestCasesForTestSuite(suitId, true, TestCaseDetails.FULL);
        Map<String, String> getCaseId =new HashMap<>(); ;
        for (TestCase testCase : testCases) {
          //  LogUtil.log("testCaseId = " + testCase.getId(), LogLevel.LOW);
            // LogUtil.log("testCaseFullExternalId = " + testCase.getFullExternalId(), LogLevel.LOW);
            getCaseId.put(testCase.getFullExternalId(), String.valueOf(testCase.getId()));
        }
        return getCaseId;
    }

    public static int getTestSuiteId(String fullExternalId) {
        Integer testSuiteId = api.getTestCaseByExternalId(String.valueOf(fullExternalId), null).getTestSuiteId();
        return testSuiteId;
    }

    public static void createNewBuild(String projectName, String projectPlan, String buildName) {

        try {
            LogUtil.log("Fetching builds for project plan: " + projectPlan, LogLevel.LOW);
            TestLinkAPIResults results = apiClient.getLatestBuildForTestPlan(projectName, projectPlan);
            Map<String, Object> data = (Map<String, Object>) results.getData(0);
            LogUtil.log("Testlink created Build Data: " + data, LogLevel.LOW);
            Object name = data.get("name");
            String createdBuildName = (name != null) ? name.toString().replaceAll("[^a-zA-Z0-9]", "") : "";
            if (createdBuildName.toLowerCase().equalsIgnoreCase(buildName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase())) {
                LogUtil.log("Build with the name '" + buildName + "' already exists in TestLink.",LogLevel.LOW);
            } else {
                LogUtil.log("Creating build: " + buildName + " for project plan: " + projectPlan,LogLevel.LOW);
                addBuild(projectPlan, buildName);
            }
        } catch (TestLinkAPIException e) {
            e.printStackTrace();
            System.err.println("Failed to create build: " + e.getMessage());
        }
    }

    public static void addBuild(String projectPlan, String buildName) {
        TestLinkAPIClient apiClient = new TestLinkAPIClient(devKey, testLinkUrl);
        try {
            apiClient.createBuild(projectName, projectPlan, buildName, "Build created automatically with TestLink.");
            LogUtil.log("Build created successfully in TestLink.", LogLevel.LOW);
        } catch (TestLinkAPIException e) {
            e.printStackTrace();
        }
    }

    public static void loadConfig(String env) {

        try {
            if (env.equals("stg")) {
                ConfigManager.loadConfig("newrallioRegressionStg.properties");
                LogUtil.log(env +" Property file loaded successfully.",LogLevel.LOW);
            }
            else if(env.equals("prod")){
                ConfigManager.loadConfig("newrallioProdSanity.properties");
                LogUtil.log(env +" Property file loaded successfully.",LogLevel.LOW);
            }
        } catch (Exception e) {
            LogUtil.log("No config file Testlink.properties.",LogLevel.LOW);
        }
    }

    public static void updateReasultsInTestLink(String environment, String moduleName,String className, String buildName) throws MalformedURLException, TestLinkAPIException {

        if (environment.equals("stg")) {
            loadConfig(environment);
            createNewBuild(projectName, getValue("projectPlan"), buildName);
            pushTestResult(className, moduleName);
        } else if (environment.equals("prod")) {
            loadConfig(environment);
            createNewBuild(projectName, getValue("projectPlan"), buildName);
            pushTestResult(className, moduleName);
        } else
            LogUtil.log("Invalid Environment parameter specified.", LogLevel.LOW);
    }
}

package com.rallio.automation.common.adapter;

import java.lang.reflect.*;

import org.openqa.selenium.*;
import org.testng.*;

import com.rallio.automation.common.enums.*;
import com.rallio.automation.common.util.*;

/**
 * The Class AbstractPageAdapter.
 */
public abstract class AbstractPageAdapter {

	/** The driver. */
	protected static WebDriver driver;

	/**
	 * Gets the element locator.
	 *
	 * @param enums    the enums
	 * @param doAssert the do assert
	 * @return the element locator
	 */
	protected WebElement getElementLocator(Enum<?> enums, Boolean doAssert) {

		By by = null;
		String description = "";
		Enum<?> xpathEnum = enums.getClass().getEnumConstants()[0];

		try {

			@SuppressWarnings({ "unchecked", "static-access" })
			Enum<?> pageEnum = xpathEnum.valueOf(enums.getClass(), enums.name());
			Method byMethod = null;
			Method descriptionMethod = null;

			byMethod = pageEnum.getClass().getMethod("getByLocator");
			descriptionMethod = pageEnum.getClass().getMethod("getDescription");

			by = (By) byMethod.invoke(pageEnum);

			description = (String) descriptionMethod.invoke(pageEnum);
		} catch (Exception ex) {
			ex.printStackTrace();
			LogUtil.log("Error in getting the locator : " + ex.getMessage(), LogLevel.HIGH);
		}

		PageUtil.waitForElementVisibility(driver, by, Timeout.SHORT_TIMEOUT);
		WebElement element = PageUtil.getElement(driver, by, Timeout.FIVE_SEC);
		if (doAssert) {
			Assert.assertTrue(element != null && element.isDisplayed(), description + " field is not displayed");
		}

		return element;
	}

	/**
	 * Fill text box value.
	 *
	 * @param          <T> the generic type
	 * @param enums    the enums
	 * @param value    the value
	 * @param doAssert the do assert
	 */
	protected <T> void fillTextBoxValue(Enum<?> enums, String value, Boolean doAssert) {

		By by = null;
		String description = "";
		Enum<?> xpathEnum = enums.getClass().getEnumConstants()[0];

		try {

			@SuppressWarnings({ "unchecked", "static-access" })
			Enum<?> pageEnum = xpathEnum.valueOf(enums.getClass(), enums.name());
			Method byMethod = null;
			Method descriptionMethod = null;

			byMethod = pageEnum.getClass().getMethod("getByLocator");
			descriptionMethod = pageEnum.getClass().getMethod("getDescription");

			by = (By) byMethod.invoke(pageEnum);

			description = (String) descriptionMethod.invoke(pageEnum);
		} catch (Exception ex) {
			ex.printStackTrace();
			LogUtil.log("Error in Filling Text box values : " + ex.getMessage(), LogLevel.HIGH);
		}

		if (value != null && !value.isEmpty()) {
			PageUtil.waitForElementVisibility(driver, by, Timeout.SHORT_TIMEOUT);
			WebElement element = PageUtil.getElement(driver, by, Timeout.FIVE_SEC);
			if (doAssert) {
				Assert.assertTrue(element != null && element.isDisplayed(), description + " field is not displayed");
			}
			PageUtil.setText(element, value);

		}
	}

	/**
	 * Click.
	 *
	 * @param          <T> the generic type
	 * @param enums    the enums
	 * @param doAssert the do assert
	 * @throws InterruptedException
	 */
	protected <T> void click(Enum<?> enums, Boolean doAssert) throws InterruptedException {

		By by = null;
		String description = "";
		Enum<?> xpathEnum = enums.getClass().getEnumConstants()[0];

		try {

			@SuppressWarnings({ "unchecked", "static-access" })
			Enum<?> pageEnum = xpathEnum.valueOf(enums.getClass(), enums.name());
			Method byMethod = null;
			Method descriptionMethod = null;

			byMethod = pageEnum.getClass().getMethod("getByLocator");
			descriptionMethod = pageEnum.getClass().getMethod("getDescription");

			by = (By) byMethod.invoke(pageEnum);

			description = (String) descriptionMethod.invoke(pageEnum);
		} catch (Exception ex) {
			ex.printStackTrace();
			LogUtil.log("Error in Clicking the button : " + ex.getMessage(), LogLevel.HIGH);
		}
		PageUtil.waitForElementVisibility(driver, by, Timeout.SHORT_TIMEOUT);
		WebElement element = PageUtil.getElement(driver, by, Timeout.THIRTY_SEC);
		if (doAssert) {
			Assert.assertTrue(element != null && element.isDisplayed(), description + " field is not displayed");
		}
		// PageUtil.scrollIntoView(driver, element);
		PageUtil.click(element, driver);

	}

	/**
	 * Checks if is element loaded.
	 *
	 * @param enums the enums
	 * @return true, if is element loaded
	 */
	public abstract boolean isElementLoaded(Enum<?> enums);

	/**
	 * Checks if is element displayed.
	 *
	 * @param enums the enums
	 * @return true, if is element displayed
	 */
	public abstract boolean isElementDisplayed(Enum<?> enums);

	/**
	 * Trigger text box events.
	 *
	 * @param setEnum      the set enum
	 * @param value        the value
	 * @param doAssert     the do assert
	 * @param authenticate the authenticate
	 * @param getEnum      the get enum
	 * @return true, if successful
	 */
	public abstract boolean triggerTextBoxEvents(Enum<?> setEnum, final String value, Boolean doAssert,
			Boolean authenticate, Enum<?> getEnum);

	/**
	 * Trigger click events.
	 *
	 * @param setEnum      the set enum
	 * @param doAssert     the do assert
	 * @param authenticate the authenticate
	 * @param getEnum      the get enum
	 * @return true, if successful
	 */
	public abstract boolean triggerClickEvents(Enum<?> setEnum, Boolean doAssert, Boolean authenticate,
			Enum<?> getEnum);

}
package com.rallio.automation.common.enums;

/**
 * The Enum Minutes.
 */
public enum MinutesOfHour {

	/** The zero. */
	ZERO(0),

	/** The thirty. */
	THIRTY(30);

	/** The minutes. */
	private int minutes;

	/**
	 * Instantiates a new minutes.
	 *
	 * @param minutes the minutes
	 */
	private MinutesOfHour(int minutes) {

		this.minutes = minutes;
	}

	/**
	 * Gets the minutes.
	 *
	 * @return the minutes
	 */
	public int getMinutes() {

		return minutes;
	}
}

package com.rallio.automation.common.util;

import java.lang.reflect.Method;
import java.util.LinkedList;
import java.util.List;

import com.rallio.automation.common.html.*;

public class ConvertPojoToHtml {

	/**
	 * Convert.
	 * 
	 * @param obj the obj
	 * @return the string
	 */
	public static String convert(Object obj) {

		String mainContent = "";
		String classname = obj.getClass().getSimpleName();
		for (Method method : obj.getClass().getMethods()) {
			String tabularDisplay = "";
			String methoName = method.getName();
			String returnType = method.getReturnType().toString();
			boolean headerAdded = false;
			if (returnType.contains("com.rallio.automation") && method.getParameterTypes().length == 0) {
				Object obj2;
				try {
					if (methoName.contains("get")) {
						obj2 = method.invoke(obj);
						if (obj2 != null && obj2.getClass().getMethods().length > 0 && methoName.contains("get") && !methoName.contains("getClass")) {

							LinkedList<Rows> rowData = new LinkedList<>();

							headerAdded = true;
							for (Method method2 : obj2.getClass().getMethods()) {
								String methoName2 = method2.getName();
								rowData = generateRows(obj2, tabularDisplay, method2, methoName2, rowData);
							}
							if (rowData != null && rowData.size() > 0) {

								rowData = addHeader(obj2.getClass().getSimpleName(), rowData);
								mainContent += HtmlUtil.createTable("display:inline-table;margin-left:5px;", "1px", "");
								mainContent += HtmlUtil.createRowsAndColumns(rowData);
							}

						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {

				if (obj.getClass().getMethods().length > 0 && methoName.contains("get") && !methoName.contains("getClass")) {


					LinkedList<Rows> rowData = new LinkedList<>();

					rowData = generateRows(obj, tabularDisplay, method, methoName, rowData);

					if (rowData != null && rowData.size() > 0 && rowData.get(0) != null && rowData.get(0).getColumn() != null) {

						if (!headerAdded && rowData.get(0).getTable() == null || rowData.get(0).getTable().size() == 0) {

							rowData = addHeader(classname, rowData);
							headerAdded = true;
						}
						mainContent += HtmlUtil.createTable("display:inline-table;margin-left:5px;", "1px", "");
						mainContent += HtmlUtil.createRowsAndColumns(rowData);

					}
				}

			}

			mainContent += tabularDisplay;
		}
		return mainContent;
	}

	/**
	 * Generate rows.
	 * 
	 * @param obj the obj
	 * @param tabularDisplay the tabular display
	 * @param method the method
	 * @param methodName the metho name
	 * @return the string
	 */
	private static LinkedList<Rows> generateRows(Object obj, String tabularDisplay, Method method, String methodName, LinkedList<Rows> rowData) {

		if (methodName.contains("get") && !methodName.contains("getClass")) {
			try {
				if (method.getParameterTypes().length == 0) {
					Object obj2 = method.invoke(obj);
					Rows rows = new Rows();
					if (obj2 != null && !obj2.toString().contains(".entity.")) {

						LinkedList<Columns> columnList = new LinkedList<>();

						if (obj2.getClass().isArray()) {
							Object[] objArray = (Object[]) obj2;
							String fieldName = method.getName();
							fieldName = fieldName.replace("get", "");

							Columns column = new Columns();
							column.setValue(fieldName);
							columnList.add(column);

							for (Object iterable_element : objArray) {
								Columns column2 = new Columns();
								column2.setValue(fieldName + iterable_element.toString() + ",");
								columnList.add(column);
							}
						} else {

							Columns column1 = new Columns();
							Columns column2 = new Columns();

							String fieldName = method.getName();
							fieldName = fieldName.replace("get", "");

							column1.setValue(fieldName);
							column2.setValue(obj2.toString());
							columnList.add(column1);
							columnList.add(column2);
						}
						rows.setColumn(columnList);
						rowData.add(rows);
					} else if (obj2 != null && obj2.toString().contains("[com.rallio.")) {
						LinkedList<Table> tableList = populateDataForList(obj2);
						rows.setTable(tableList);
						rowData.add(rows);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return rowData;
	}

	/**
	 * Populate data for list.
	 * 
	 * @param obj the obj
	 * @return the string
	 */
	private static LinkedList<Table> populateDataForList(Object obj) {

		LinkedList<Table> tableList = new LinkedList<>();
		@SuppressWarnings("rawtypes")
		List objList = (List) obj;

		for (Object object : objList) {

			Table table = new Table();
			table.setStyle("display:inline-table;margin-left:5px;");

			LinkedList<Rows> rowData = new LinkedList<>();

			for (Method method : object.getClass().getMethods()) {

				Rows rows2 = new Rows();

				LinkedList<Columns> columnList = new LinkedList<>();
				try {
					String methoName = method.getName();

					if (methoName.contains("get") && !methoName.contains("getClass") && method.getParameterTypes().length == 0) {

						Object obj2 = method.invoke(object);

						if (obj2 != null && obj2.toString().contains(".entity.")) {

							for (Method method2 : obj2.getClass().getMethods()) {
								String methoName2 = method2.getName();
								rowData = generateRows(obj2, "", method2, methoName2, rowData);
							}

						} else if (obj2 != null) {

							Columns column1 = new Columns();
							Columns column2 = new Columns();

							String fieldName = method.getName();
							fieldName = fieldName.replace("get", "");
							column1.setValue(fieldName);
							column2.setValue(obj2.toString());
							columnList.add(column1);
							columnList.add(column2);
							rows2.setColumn(columnList);
							rowData.add(rows2);

						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			if (rowData != null && rowData.size() > 0 && rowData.get(0) != null && rowData.get(0).getColumn() != null) {
				rowData = addHeader(object.getClass().getSimpleName(), rowData);
				table.setRows(rowData);
				tableList.add(table);
			}

		}

		return tableList;
	}

	private static LinkedList<Rows> addHeader(String headingName, LinkedList<Rows> rowData) {

		Rows rows = new Rows();
		LinkedList<Columns> cs = new LinkedList<>();
		Columns colum = new Columns();

		colum.setHeading(headingName);
		colum.setColspan("2");
		cs.add(colum);
		rows.setColumn(cs);
		rowData.addFirst(rows);

		return rowData;
	}

	/**
	 * The main method.
	 * 
	 * @param args the arguments
	 */
	/*
	 * @SuppressWarnings("static-access") public static void main(String[] args)
	 * {
	 * 
	 * ConvertPojoToHtml ct2 = new ConvertPojoToHtml();
	 * 
	 * Rows rows = new Rows(); rows.setAbc("abc");; rows.setBcd("bcd");
	 * rows.setEdc("edc"); ct2.convert(rows);
	 * 
	 * }
	 */
}

package com.rallio.automation.common.util;

import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonParser.Feature;
import com.fasterxml.jackson.core.JsonPointer;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rallio.automation.common.enums.*;

/**
 * The Class JsonUtil.
 * 
 * @author $Author:$
 * @version $Rev:$ $Date:$
 */
public class JsonUtil {

	/**
	 * Gets the object.
	 * 
	 * @param            <T> the
	 * @param jsonString the json string
	 * @param className  the class name
	 * @return the object
	 */
	public static <T> T getObject(String jsonString, Class<T> className) {

		final ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.readValue(jsonString, className);
		} catch (NullPointerException ex) {

			LogUtil.log(jsonString == null ? "The File for the environment is not loaded"
					: "The required data " + jsonString + " is not in property file", LogLevel.MEDIUM);
		} catch (IOException e) {
			LogUtil.log("Exception in JSON parsing. Cause: " + e, LogLevel.MEDIUM);
		}
		return null;
	}

	/**
	 * Gets the object.
	 *
	 * @param                 <T> the
	 * @param jsonString      the json string
	 * @param rootElementName the root element name
	 * @param className       the class name
	 * @return the object
	 */
	public static <T> T getObject(String jsonString, String rootElementName, Class<T> className) {

		final ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.readValue(mapper.readTree(jsonString).get(rootElementName).toString(), className);
		} catch (NullPointerException ex) {

			LogUtil.log(jsonString == null ? "The File for the environment is not loaded"
					: "The required data " + jsonString + " is not in property file", LogLevel.MEDIUM);
		} catch (IOException e) {
			LogUtil.log("Exception in JSON parsing. Cause: " + e, LogLevel.MEDIUM);
		}
		return null;
	}

	/**
	 * Gets the string.
	 *
	 * @param obj the obj
	 * @return the string
	 */
	public static String getString(Object obj) {

		ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.writeValueAsString(obj);
		} catch (IOException e) {
			LogUtil.log("Exception in JSON parsing. Cause: " + e, LogLevel.MEDIUM);
		}
		return null;
	}

	/**
	 * Gets the list object.
	 * 
	 * @param            <T> the
	 * @param jsonString the json string
	 * @param className  the class name
	 * @return the list object
	 */
	public static <T> List<T> getListObject(String jsonString, Class<T> className) {

		ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.readValue(jsonString, mapper.getTypeFactory().constructCollectionType(List.class, className));
		} catch (IOException e) {
			LogUtil.log("Exception in JSON parsing. Cause: " + e, LogLevel.MEDIUM);
		}
		return null;
	}

	/**
	 * Gets the list object.
	 *
	 * @param                 <T> the
	 * @param jsonString      the json string
	 * @param rootElementName the root element name
	 * @param className       the class name
	 * @return the list object
	 */
	public static <T> List<T> getListObject(String jsonString, String rootElementName, Class<T> className) {

		ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.readValue(mapper.readTree(jsonString).get(rootElementName).toString(),
					mapper.getTypeFactory().constructCollectionType(List.class, className));
		} catch (IOException e) {
			LogUtil.log("Exception in JSON parsing. Cause: " + e, LogLevel.MEDIUM);
		}
		return null;
	}

	/**
	 * Gets the list object.
	 *
	 * @param            <T> the
	 * @param jsonString the json string
	 * @param jsonPath   the path to necessary element
	 * @param className  the class name
	 * @return the list object
	 */
	public static <T> List<T> getListObjectForPath(String jsonString, String jsonPath, Class<T> className) {

		ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.readValue(mapper.readTree(jsonString).at(JsonPointer.compile(jsonPath)).toString(),
					mapper.getTypeFactory().constructCollectionType(List.class, className));
		} catch (IOException e) {
			LogUtil.log("Exception in JSON parsing. Cause: " + e, LogLevel.MEDIUM);
		}
		return null;
	}

	/**
	 * Gets the list object.
	 *
	 * @param object the object
	 * @return the list object
	 */
	public static String toJson(Object object) {

		ObjectMapper mapper = new ObjectMapper();
		try {
			mapper.configure(Feature.ALLOW_UNQUOTED_CONTROL_CHARS, true);
			return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(object);
		} catch (IOException e) {
			LogUtil.log("Exception in JSON parsing. Cause: " + e, LogLevel.MEDIUM);
		}
		return null;
	}

	/**
	 * Map to json string.
	 *
	 * @param values the values
	 * @return the string
	 */
	public static String mapToJsonString(Map<String, String> values) {

		String result = null;
		ObjectMapper mapper = new ObjectMapper();

		try {
			result = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(values);
		} catch (Exception e) {
			LogUtil.log("Exception in Map to JSON String parsing. Cause: " + e, LogLevel.MEDIUM);
			e.printStackTrace();
		}

		return result;
	}

	/**
	 * Json string to map.
	 *
	 * @param jsonString the json string
	 * @return the map
	 */
	public static Map<String, Object> jsonStringToMap(String jsonString) {

		Map<String, Object> result = null;
		ObjectMapper mapper = new ObjectMapper();

		try {
			result = mapper.readValue(jsonString, new TypeReference<Map<String, Object>>() {
			});
		} catch (Exception e) {
			LogUtil.log("Exception in JSON String to Map parsing. Cause: " + e, LogLevel.MEDIUM);
			e.printStackTrace();
		}

		return result;
	}

	/**
	 * Gets the object from json file.
	 *
	 * @param            <T> the
	 * @param fileReader the file reader
	 * @param className  the class name
	 * @return the object from json file
	 */
	public static <T> T getObjectFromJsonFile(String fileReader, Class<T> className) {

		final ObjectMapper mapper = new ObjectMapper();
		try {
			FileReader file = new FileReader(fileReader);
			return mapper.readValue(file, className);
		} catch (NullPointerException ex) {

			LogUtil.log(fileReader == null ? "The File for the environment is not loaded"
					: "The required data " + fileReader + " is not in property file", LogLevel.MEDIUM);
		} catch (IOException e) {
			LogUtil.log("Exception in JSON parsing. Cause: " + e, LogLevel.MEDIUM);
		}
		return null;
	}
}
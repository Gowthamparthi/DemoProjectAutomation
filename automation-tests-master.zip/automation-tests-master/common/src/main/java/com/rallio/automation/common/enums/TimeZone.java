package com.rallio.automation.common.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum TimeZone.
 */
public enum TimeZone {

	/** The ist. */
	IST("UTC+05:30"),

	/** The pst. */
	PST("UTC-08:00");

	/** The time zone. */
	private String timeZone;

	/**
	 * Instantiates a new time zone.
	 *
	 * @param timeZone the time zone
	 */
	private TimeZone(String timeZone) {

		this.timeZone = timeZone;
	}

	/**
	 * Gets the time zone.
	 *
	 * @return the time zone
	 */
	public String getTimeZone() {

		return timeZone;
	}
}

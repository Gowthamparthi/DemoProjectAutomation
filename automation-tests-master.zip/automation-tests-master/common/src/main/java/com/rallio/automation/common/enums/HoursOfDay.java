package com.rallio.automation.common.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum Hours.
 */
public enum HoursOfDay {

	/** The zero. */
	ZERO(0),

	/** The one. */
	ONE(1),

	/** The two. */
	TWO(2),

	/** The three. */
	THREE(3),

	/** The four. */
	FOUR(4),

	/** The five. */
	FIVE(5),

	/** The six. */
	SIX(6),

	/** The seven. */
	SEVEN(7),

	/** The eight. */
	EIGHT(8),

	/** The nine. */
	NINE(9),

	/** The ten. */
	TEN(10),

	/** The eleven. */
	ELEVEN(11),

	/** The twelve. */
	TWELVE(12),

	/** The thirteen. */
	THIRTEEN(13),

	/** The fourteen. */
	FOURTEEN(14),

	/** The fifteen. */
	FIFTEEN(15),

	/** The sixteen. */
	SIXTEEN(16),

	/** The seventeen. */
	SEVENTEEN(17),

	/** The eighteen. */
	EIGHTEEN(18),

	/** The nineteen. */
	NINETEEN(19),

	/** The twenty. */
	TWENTY(20),

	/** The twenty one. */
	TWENTY_ONE(21),

	/** The twenty two. */
	TWENTY_TWO(22),

	/** The twenty three. */
	TWENTY_THREE(23);

	/** The hours. */
	private int hours;

	/**
	 * Instantiates a new hours.
	 *
	 * @param hours the hours
	 */
	private HoursOfDay(int hours) {

		this.hours = hours;
	}

	/**
	 * Gets the hours.
	 *
	 * @return the hours
	 */
	public int getHours() {

		return hours;
	}
}

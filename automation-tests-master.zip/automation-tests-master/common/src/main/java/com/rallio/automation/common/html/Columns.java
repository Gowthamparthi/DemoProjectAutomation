package com.rallio.automation.common.html;



/**
 * The Class Columns.
 * 
 * @author $Author:$
 * @version $Rev:$ $Date:$
 */
public class Columns {

	private String value;
	private String heading;
	private String style;
	private String colspan;

	/**
	 * Gets the value.
	 * 
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * Sets the value.
	 * 
	 * @param value the new value
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * Gets the style.
	 * 
	 * @return the style
	 */
	public String getStyle() {
		return style;
	}

	/**
	 * Sets the style.
	 * 
	 * @param style the new style
	 */
	public void setStyle(String style) {
		this.style = style;
	}

	/**
	 * Gets the colspan.
	 * 
	 * @return the colspan
	 */
	public String getColspan() {
		return colspan;
	}

	/**
	 * Sets the colspan.
	 * 
	 * @param colspan the new colspan
	 */
	public void setColspan(String colspan) {
		this.colspan = colspan;
	}

	/**
	 * Gets the heading.
	 * 
	 * @return the heading
	 */
	public String getHeading() {
		return heading;
	}

	/**
	 * Sets the heading.
	 * 
	 * @param heading the new heading
	 */
	public void setHeading(String heading) {
		this.heading = heading;
	}

}

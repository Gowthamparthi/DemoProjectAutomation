package com.rallio.automation.common.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum Color.
 */
public enum Color {

	/** The foreground black. */
	FOREGROUND_BLACK("\033[30m"),

	/** The foreground red. */
	FOREGROUND_RED("\033[31m"),

	/** The foreground green. */
	FOREGROUND_GREEN("\033[32m"),

	/** The foreground yellow. */
	FOREGROUND_YELLOW("\033[33m"),

	/** The foreground blue. */
	FOREGROUND_BLUE("\033[34m"),

	/** The foreground magenta. */
	FOREGROUND_MAGENTA("\033[35m"),

	/** The foreground cyan. */
	FOREGROUND_CYAN("\033[36m"),

	/** The foreground white. */
	FOREGROUND_WHITE("\033[37m"),

	/** The background black. */
	BACKGROUND_BLACK("\033[40m"),

	/** The background red. */
	BACKGROUND_RED("\033[41m"),

	/** The background green. */
	BACKGROUND_GREEN("\033[42m"),

	/** The background yellow. */
	BACKGROUND_YELLOW("\033[43m"),

	/** The background blue. */
	BACKGROUND_BLUE("\033[44m"),

	/** The background magenta. */
	BACKGROUND_MAGENTA("\033[45m"),

	/** The background cyan. */
	BACKGROUND_CYAN("\033[46m"),

	/** The background white. */
	BACKGROUND_WHITE("\033[47m"),

	/** The no color. */
	NO_COLOR("NO_COLOR");

	/** The value. */
	private String value;

	/**
	 * Instantiates a new color.
	 *
	 * @param value the value
	 */
	private Color(String value) {

		this.value = value;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public String getValue() {

		return value;
	}
}

package com.rallio.automation.common.enums;
// TODO: Auto-generated Javadoc

/**
 * The Enum Steps.
 */
public enum Steps {

	/** The start. */
	START,
	/** The end. */
	END
}

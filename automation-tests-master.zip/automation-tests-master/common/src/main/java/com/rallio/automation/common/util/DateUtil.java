package com.rallio.automation.common.util;

import com.rallio.automation.common.enums.TimeZone;
import com.rallio.automation.common.enums.*;
import org.joda.time.LocalDateTime;
import org.joda.time.Period;
import org.joda.time.*;
import org.joda.time.format.*;

import javax.xml.datatype.*;
import java.text.*;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.*;
import java.time.temporal.*;
import java.util.*;
import java.util.concurrent.*;

// TODO: Auto-generated Javadoc
/**
 * The Class DateUtil.
 * 
 * @author $Author:$
 * @version $Rev:$ $Date:$
 */
public class DateUtil {

	/**
	 * The Constant DATE_ONLY_FMT.
	 */
	public static final String DATE_ONLY_FMT = "MM/dd/yyyy";

	/**
	 * The Constant DATE_ONLY_FMT.
	 */
	public static final String DATE_ONLY_SMALL_FMT = "M-d-yyyy";

	/**
	 * The Constant SMALL_FMT.
	 */
	public static final String SMALL_FMT = "yyMMddHHmms";

	/**
	 * The Constant YEAR_MON_DATE_ONLY_FMT.
	 */
	public static final String YEAR_MON_DATE_ONLY_FMT = "yyyy/MM/dd";

	/**
	 * The Constant DATE_FMT.
	 */
	public static final String DATE_FMT = "yyyy-MM-dd HH:mm:ss";

	/**
	 * The Constant DATE_FMT_FULL.
	 */
	public static final String DATE_FMT_FULL = "yyyy-MM-dd HH:mm:ss aa";

	/**
	 * The Constant DATE_FMT_FULL_TZ.
	 */
	public static final String DATE_FMT_FULL_TZ = "yyyy-MM-dd HH:mm:ss aa Z";

	/**
	 * The Constant DATE_MONTH_YEAR_FMT.
	 */
	public static final String DATE_MONTH_YEAR_FMT = "d MMMM yyyy";

	/**
	 * The Constant MM_DD_YY.
	 */
	public static final String MM_DD_YY = "MM/dd/yy HH:mm aa";

	/**
	 * The Constant MM_DD_YY.
	 */
	public static final String DD_MM_YY = "dd-mm-yy";

	/**
	 * The Constant MM_DD_YY.
	 */
	public static final String DD_MM_YYYY = "dd-mm-yyyy";

	/**
	 * The Constant MM_DD_YY.
	 */
	public static final String MM_DD_YYYY = "MM-dd-yyyy";

	/**
	 * The Constant MM_DD_YY.
	 */
	public static final String MM_DD_YY_SHORT = "mm-dd-yy";

	/**
	 * The Constant LARGE_FORMAT.
	 */
	public static final String LARGE_FORMAT = "EEEE, MMMM dd, yyyy HH:mm:ss aa";

	/**
	 * The Constant HOUR_FORMAT.
	 */
	public static final String HOUR_FORMAT = "HH:mm:ss aa";

	/**
	 * The Constant DATE_ONLY_FMT.
	 */
	public static final String DATE_MONTH_ABBREVIATION = "dd MMM yyyy";

	/**
	 * The Constant TIME_FORMAT.
	 */
	public static final String TIME_FORMAT = "h:mm a";

	/**
	 * The Constant TIME_FORMAT.
	 */
	public static final String TIME_FORMAT_HH_MM_A = "hh:mm a";

	/**
	 * The Constant YYYY_DD_MM.
	 */
	public static final String YYYY_MM_DD = "yyyy-MM-dd";

	/**
	 * The Constant YYYYMMDD.
	 */
	public static final String YYYYMMDD = "yyyyMMdd";

	/**
	 * The Constant SIMPLE_FMT. MMMddHHmm
	 */
	public static final String SIMPLE_FMT = "MMMddHHmm";

	/**
	 * The Constant HH24_MM_ss.
	 */
	public static final String HH24_MM_ss = "HH:mm:ss";

	/**
	 * The Constant STANDARD_ISO.
	 */
	public static final String STANDARD_ISO = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

	/**
	 * The Constant MMDDYY_HH24_MI_SS.
	 */
	public static final String MMDDYY_HH24_MM_SS = "MMddYY HH:mm:ss";

	/**
	 * The Constant YYMMDDHH24_MM_SS_SSS.
	 */
	public static final String YYMMDDHH24_MM_SS_SSS = "yyMMddHHmmssSSS";

	/**
	 * The Constant ISO_8601.
	 */
	public static final String ISO_8601 = "yyyy-MM-dd'T'00:00:00.00-07:00";


	public static final String  YEAR_MONTH_DATE = "YYY-MM-d";

	/**
	 * The Constant MONTH_DATE_YEAR.
	 */
	public static final String MONTH_DATE_YEAR = "MMM dd, yyyy";

	/**
	 * The Constant MONTH_DATE_YEAR1.
	 */
	public static final String MONTH_DATE_YEAR1 = "MMM d, yyyy";

	/**
	 * The Constant SESSION.
	 */
	public static final String SESSION = "a";

	/**
	 * The Constant MINUTES.
	 */
	public static final String MINUTES = "h:mm";

	/**
	 * The Constant WEEKDAY.
	 */
	public static final String WEEKDAY = "E";

	/**
	 * The Constant DAY_MONTH_TIME_SESSION.
	 */
	public static final String DAY_MONTH_TIME_SESSION = "EEE, MMM d hh:mm aa";

	/**
	 * The Constant DAY_MONTH_TIME_SESSION_WITHOUTAMPM.
	 */
	public static final String DAY_MONTH_TIME_SESSION_WITHOUTAMPM = "EEE, MMM d hh:mm";

	/**
	 * The Constant DAY_MONTH_DATE_YEAR.
	 */
	public static final String DAY_MONTH_DATE_YEAR = "EEE MMM d, yyyy";

	/**
	 * The Constant DAYFULL_MONTH_DATE_YEAR.
	 */
	public static final String DAYFULL_MONTH_DATE_YEAR = "EEEE MMM d, yyyy";

	/**
	 * The Constant YYYY_MM_DD_T_HH_MM_SS.
	 */
	public static final String YYYY_MM_DD_T_HH_MM_SS = "yyyy-MM-dd'T'00:00:00";

	/**
	 * The Constant YYYY_MM_DDTHH_MM_SS.
	 */
	public static final String YYYY_MM_DDTHH_MM_SS = "yyyy-MM-dd'T'HH:mm:ss";


	/**
	 * Gets the current month.
	 *
	 * @return the current month
	 */
	public static String getCurrentMonth() {

		final String[] months = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
		final Calendar cal = Calendar.getInstance();
		String month = "";
		month = months[cal.get(Calendar.MONTH)];
		return month;
	}

	/**
	 * Gets the next month.
	 *
	 * @param format the format
	 * @param month  the month
	 * @return the next month
	 */
	public static String getMonth(String format, int month) {

		Calendar currentMonth = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		currentMonth.add(Calendar.MONTH, month);
		String nextMonth = dateFormat.format(currentMonth.getTime());
		return nextMonth;
	}

	/**
	 * Gets the next year.
	 *
	 * @param format the format
	 * @param year  the month
	 * @return the next year
	 */
	public static String getNextYear(String format, int year) {

		Calendar currentYear = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		currentYear.add(Calendar.YEAR, year);
		String nextMonth = dateFormat.format(currentYear.getTime());
		return nextMonth;
	}

	/**
	 * Gets the week date.
	 *
	 * @param dateFormat the date format
	 * @param count      the count
	 * @return the week date
	 */
	public static String getWeekDate(String dateFormat, int count) {

		SimpleDateFormat format = new SimpleDateFormat(dateFormat);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, count);
		String weekdate = format.format(cal.getTime());
		return weekdate;
	}

	/**
	 * Gets the current date.
	 *
	 * @return the current date
	 */
	public static int getCurrentDate() {

		final Calendar now = Calendar.getInstance();
		int date = 0;
		date = now.get(Calendar.DATE);
		return date;
	}

	/**
	 * Gets the current year.
	 *
	 * @return the current year
	 */
	public static int getCurrentYear() {

		final Calendar now = Calendar.getInstance();
		int year = 0;
		year = now.get(Calendar.YEAR);
		return year;
	}

	/**
	 * Checks if is last date.
	 *
	 * @return true, if is last date
	 */
	public static boolean isLastDate() {

		DateTime startDate = new DateTime(DateTimeZone.UTC);
		int max = startDate.dayOfMonth().getMaximumValue();
		int current = startDate.getDayOfMonth();
		return current == max;
	}

	/**
	 * Gets the last date of month.
	 *
	 * @return the last date of month
	 */
	public static Map<String, Integer> getLastDateOfMonth() {

		final HashMap<String, Integer> monthMap = new HashMap<String, Integer>();
		monthMap.put("January", 31);
		monthMap.put("February", 28);
		monthMap.put("March", 31);
		monthMap.put("April", 30);
		monthMap.put("May", 31);
		monthMap.put("June", 30);
		monthMap.put("July", 31);
		monthMap.put("August", 31);
		monthMap.put("September", 30);
		monthMap.put("October", 31);
		monthMap.put("November", 30);
		monthMap.put("December", 31);

		return monthMap;
	}


	/**
	 * Gets the month.
	 *
	 * @return the month
	 */
	public static Map<String, String> getMonth() {

		final HashMap<String, String> monthMap = new HashMap<String, String>();
		monthMap.put("01", "January");
		monthMap.put("02", "February");
		monthMap.put("03", "March");
		monthMap.put("04", "April");
		monthMap.put("05", "May");
		monthMap.put("06", "June");
		monthMap.put("07", "July");
		monthMap.put("08", "August");
		monthMap.put("09", "September");
		monthMap.put("10", "October");
		monthMap.put("11", "November");
		monthMap.put("12", "December");

		return monthMap;
	}


	/**
	 * Gets the last date of particular month.
	 *
	 * @param month the month
	 * @return the last date of particular month
	 */
	public static int getLastDateOfParticularMonth(String month) {

		return getLastDateOfMonth().get(month);
	}

	/**
	 * Difference in minutes.
	 *
	 * @param date1 the date1
	 * @param date2 the date2
	 * @return the long
	 */
	public static long differenceInMinutes(final Date date1, final Date date2) {

		final long diff = date2.getTime() - date1.getTime();
		return diff / (60 * 1000);
	}

	/**
	 * Gets the calendar.
	 *
	 * @param dateTime the date time
	 * @param pattern  the pattern
	 * @return the calendar
	 * @throws ParseException the parse exception
	 */
	public static Calendar getCalendar(final String dateTime, String pattern) throws ParseException {

		DateTimeFormatter fmt = DateTimeFormat.forPattern(pattern);
		DateTime dt = fmt.parseDateTime(dateTime);
		return dt.toCalendar(Locale.ENGLISH);
	}

	/**
	 * Gets the calendar.
	 *
	 * @param dateTime the date time
	 * @param pattern  the pattern
	 * @param timeZone the time zone
	 * @return the calendar
	 * @throws ParseException the parse exception
	 */
	public static Calendar getCalendar(String dateTime, final String pattern, String timeZone) throws ParseException {

		DateTime dt = new DateTime(DateTimeZone.forID(timeZone));
		Calendar calendar = dt.toCalendar(Locale.ENGLISH);
		SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.ENGLISH);
		Date date = sdf.parse(dateTime);
		calendar.setTime(date);
		return calendar;
	}

	/**
	 * Gets the calendar.
	 *
	 * @param startTime the start time
	 * @param minutes   the minutes
	 * @param pattern   the pattern
	 * @return the calendar
	 */
	public static Calendar getCalendar(Calendar startTime, int minutes, final String pattern) {

		Calendar endTime = null;
		DateTime start = new DateTime(startTime);
		DateTime end = start.plusMinutes(minutes);
		DateTimeFormatter fmt = DateTimeFormat.forPattern(pattern);
		fmt = fmt.withZoneUTC();
		endTime = parseToUTCCalendar(fmt.print(end), pattern);
		return endTime;
	}

	/**
	 * Gets the calendar for time zone.
	 *
	 * @param timeZone the time zone
	 * @return the calendar for time zone
	 * @throws ParseException the parse exception
	 */
	public static Calendar getCalendarForTimeZone(final String timeZone) throws ParseException {

		DateTime dateTime = new DateTime(DateTimeZone.forID(timeZone));
		Calendar tzCalendar = dateTime.toCalendar(Locale.ENGLISH);
		return tzCalendar;
	}

	/**
	 * Gets the calendar for date.
	 *
	 * @param date the date
	 * @return the calendar for date
	 */
	public static Calendar getCalendarForDate(final Date date) {

		DateTime dt = new DateTime(date);
		Calendar calendar = dt.toCalendar(Locale.ENGLISH);
		calendar.setTime(date);
		return calendar;
	}

	/**
	 * Copy to utc.
	 *
	 * @param calendar the calendar
	 * @param pattern  the pattern
	 * @return the calendar
	 */
	public static Calendar copyToUTC(Calendar calendar, String pattern) {

		Calendar aCalendar = null;
		String date = format(calendar, pattern);
		aCalendar = parseToUTCCalendar(date, pattern);
		return aCalendar;
	}

	/**
	 * Gets the UTC current time stamp.
	 *
	 * @param pattern the pattern
	 * @return the UTC current time stamp
	 */
	public static String getUTCCurrentTimeStamp(String pattern) {

		DateTimeFormatter fmt = DateTimeFormat.forPattern(pattern);
		return fmt.print(new DateTime(DateTimeZone.UTC));
	}

	/**
	 * Gets the current time stamp for zone.
	 *
	 * @param timeZone the time zone
	 * @param pattern  the pattern
	 * @return the current time stamp for zone
	 */
	public static String getCurrentTimeStampForZone(String timeZone, String pattern) {

		DateTime startDate = new DateTime(DateTimeZone.forID(timeZone));
		DateTimeFormatter fmt = DateTimeFormat.forPattern(pattern);
		return fmt.print(startDate);
	}

	/**
	 * Gets the UTC time from local.
	 *
	 * @param localTimeInMillis the local time in millis
	 * @param timeZone          the time zone
	 * @return the UTC time from local
	 */
	public static long getUTCTimeFromLocal(long localTimeInMillis, String timeZone) {

		long utcTime = 0;
		DateTimeZone dateTimeZone = DateTimeZone.forID(timeZone);
		utcTime = dateTimeZone.convertLocalToUTC(localTimeInMillis, false);
		return utcTime;
	}

	/**
	 * To date.
	 *
	 * @param calendar the calendar
	 * @return the date
	 * @throws ParseException the parse exception
	 */
	public static Date toDate(final Calendar calendar) throws ParseException {

		Date date = new Date();
		date = calendar.getTime();
		return date;
	}

	/**
	 * To date with timezone.
	 *
	 * @param dateTime the date time
	 * @param pattern  the pattern
	 * @return the date
	 * @throws ParseException the parse exception
	 */
	public static Date toDateWithTimezone(String dateTime, String pattern) throws ParseException {

		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.ENGLISH);
		date = sdf.parse(dateTime);
		return date;
	}

	/**
	 * Format.
	 *
	 * @param calendar the calendar
	 * @param pattern  the pattern
	 * @return the string
	 */
	public static String format(Calendar calendar, String pattern) {

		DateTimeFormatter fmt = DateTimeFormat.forPattern(pattern);
		return fmt.print(new DateTime(calendar));
	}

	/**
	 * Format to utc.
	 *
	 * @param calendar the calendar
	 * @param pattern  the pattern
	 * @return the string
	 */
	public static String formatToUTC(Calendar calendar, String pattern) {

		DateTimeFormatter fmt = DateTimeFormat.forPattern(pattern);
		fmt = fmt.withZoneUTC();
		String strDate = fmt.print(new DateTime(calendar));
		return strDate;
	}

	/**
	 * Format to utc.
	 *
	 * @param date    the date
	 * @param pattern the pattern
	 * @return the string
	 */
	public static String formatToUTC(Date date, String pattern) {

		DateTimeFormatter fmt = DateTimeFormat.forPattern(pattern);
		fmt = fmt.withZoneUTC();
		String strDate = fmt.print(new DateTime(date));
		return strDate;
	}

	/**
	 * Format.
	 *
	 * @param date    the date
	 * @param pattern the pattern
	 * @return the string
	 */
	public static String format(Date date, String pattern) {

		DateTimeFormatter fmt = DateTimeFormat.forPattern(pattern);
		String strDate = fmt.print(new DateTime(date));
		return strDate;
	}

	/**
	 * Format to utc.
	 *
	 * @param milliseconds the milliseconds
	 * @param pattern      the pattern
	 * @return the string
	 */
	public static String formatToUTC(Long milliseconds, String pattern) {

		DateTimeFormatter fmt = DateTimeFormat.forPattern(pattern);
		fmt = fmt.withZoneUTC();
		String strDate = fmt.print(new DateTime(milliseconds));
		return strDate;
	}

	/**
	 * Format to zone.
	 *
	 * @param milliseconds the milliseconds
	 * @param zone         the zone
	 * @param pattern      the pattern
	 * @return the string
	 */
	public static String formatToZone(Long milliseconds, DateTimeZone zone, String pattern) {

		DateTimeFormatter fmt = DateTimeFormat.forPattern(pattern);
		fmt = fmt.withZone(zone);
		String strDate = fmt.print(new DateTime(milliseconds));
		return strDate;
	}

	/**
	 * Parses the to utc calendar.
	 *
	 * @param timestamp the timestamp
	 * @param pattern   the pattern
	 * @return the calendar
	 */
	public static Calendar parseToUTCCalendar(String timestamp, String pattern) {

		DateTimeFormatter fmt = DateTimeFormat.forPattern(pattern);
		fmt = fmt.withZoneUTC();
		DateTime dt = fmt.parseDateTime(timestamp);
		dt = dt.toDateTime(DateTimeZone.UTC);
		return dt.toCalendar(Locale.ENGLISH);
	}

	/**
	 * Parses the to time zone calendar.
	 *
	 * @param timestamp the timestamp
	 * @param pattern   the pattern
	 * @param timeZone  the time zone
	 * @return the calendar
	 */
	public static Calendar parseToTimeZoneCalendar(String timestamp, String pattern, String timeZone) {

		DateTimeFormatter fmt = DateTimeFormat.forPattern(pattern);
		fmt = fmt.withZoneUTC();
		DateTime dt = fmt.parseDateTime(timestamp);
		dt = dt.toDateTime(DateTimeZone.forID(timeZone));
		return dt.toCalendar(Locale.ENGLISH);
	}

	/**
	 * Parses the to utc date.
	 *
	 * @param timestamp the timestamp
	 * @param pattern   the pattern
	 * @return the date
	 */
	public static Date parseToUTCDate(String timestamp, String pattern) {

		DateTimeFormatter fmt = DateTimeFormat.forPattern(pattern);
		fmt = fmt.withZoneUTC();
		Date date = fmt.parseDateTime(timestamp).toDate();
		return date;
	}

	/**
	 * Parses the to utcms.
	 *
	 * @param timestamp the timestamp
	 * @param pattern   the pattern
	 * @return the long
	 */
	public static Long parseToUTCMS(String timestamp, String pattern) {

		DateTimeFormatter fmt = DateTimeFormat.forPattern(pattern);
		fmt = fmt.withZoneUTC();
		Date date = fmt.parseDateTime(timestamp).toDate();
		return date.getTime();
	}

	/**
	 * Convert timezone.
	 *
	 * @param date         the date
	 * @param srcTimeZone  the src time zone
	 * @param destTimeZone the dest time zone
	 * @return the date
	 */
	public static Date convertTimezone(LocalDateTime date, String srcTimeZone, String destTimeZone) {

		DateTime srcDateTime = date.toDateTime(DateTimeZone.forID(srcTimeZone));
		DateTime dstDateTime = srcDateTime.withZone(DateTimeZone.forID(destTimeZone));
		return dstDateTime.toLocalDateTime().toDateTime().toDate();
	}

	/**
	 * Gets the future date.
	 *
	 * @return the future date
	 */
	public static int getFutureDate() {

		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, 2);
		int date = calendar.get(Calendar.DATE);
		return date;
	}

	/**
	 * Gets the future date from date.
	 *
	 * @param selectedDate the selected date
	 * @param daysCount    the days count
	 * @return the future date from date
	 */
	public static int getFutureDateFromDate(int selectedDate, int daysCount) {

		Calendar calendar = Calendar.getInstance();
		if (selectedDate != 0) {
			calendar.set(Calendar.DATE, selectedDate);
		}
		calendar.add(Calendar.DATE, daysCount);
		int date = calendar.get(Calendar.DATE);
		return date;
	}

	/**
	 * Gets the system time.
	 *
	 * @param pattern the pattern
	 * @return the system time
	 */
	public static String getSystemTime(String pattern) {

		long secs = System.currentTimeMillis();
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		Date date = new Date(secs);
		return sdf.format(date);
	}

	/**
	 * Gets the day number suffix.
	 *
	 * @param day the day
	 * @return the day number suffix
	 */
	public static String getDayNumberSuffix(int day) {

		if (day >= 11 && day <= 13) {
			return "th";
		}
		switch (day % 10) {
			case 1:
				return "st";
			case 2:
				return "nd";
			case 3:
				return "rd";
			default:
				return "th";
		}
	}

	/**
	 * Gets the uTC date.
	 *
	 * @return the uTC date
	 */
	public static Date getUTCDate() {

		DateTime dt = new DateTime(DateTimeZone.UTC);
		Date utcDate = null;
		try {
			utcDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(dt.toString("yyyy-MM-dd HH:mm:ss"));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return utcDate;
	}

	/**
	 * Gets the XML gregorian calendar date.
	 *
	 * @param days the days
	 * @return the XML gregorian calendar date
	 * @throws DatatypeConfigurationException the datatype configuration
	 *                                        exception
	 */
	public static XMLGregorianCalendar getXMLGregorianCalendarDate(int days) throws DatatypeConfigurationException {

		GregorianCalendar calendar = new GregorianCalendar();
		calendar.add(Calendar.DATE, days);

		XMLGregorianCalendar xmlDate = DatatypeFactory.newInstance().newXMLGregorianCalendarDate(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1,
				calendar.get(Calendar.DATE), DatatypeConstants.FIELD_UNDEFINED);
		return xmlDate;
	}

	/**
	 * Gets the XML gregorian calendar time.
	 *
	 * @param hours   the hours
	 * @param minutes the minutes
	 * @return the XML gregorian calendar time
	 * @throws DatatypeConfigurationException the datatype configuration
	 *                                        exception
	 */
	public static XMLGregorianCalendar getXMLGregorianCalendarTime(HoursOfDay hours, MinutesOfHour minutes) throws DatatypeConfigurationException {

		XMLGregorianCalendar xmlDate = DatatypeFactory.newInstance().newXMLGregorianCalendarTime(hours.getHours(), minutes.getMinutes(), 0, DatatypeConstants.FIELD_UNDEFINED);
		return xmlDate;
	}

	/**
	 * Gets the XML gregorian calendar date time.
	 *
	 * @param hours   the hours
	 * @param minutes the minutes
	 * @param days    the days
	 * @return the XML gregorian calendar date time
	 * @throws DatatypeConfigurationException the datatype configuration
	 *                                        exception
	 */
	public static XMLGregorianCalendar getXMLGregorianCalendarDateTime(HoursOfDay hours, MinutesOfHour minutes, int days) throws DatatypeConfigurationException {

		GregorianCalendar calendar = new GregorianCalendar();
		calendar.add(Calendar.DATE, days);

		XMLGregorianCalendar xmlDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1,
				calendar.get(Calendar.DATE), hours.getHours(), minutes.getMinutes(), 0, DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED);
		return xmlDate;
	}

	/**
	 * Gets the UTC calendar.
	 *
	 * @return the UTC calendar
	 */
	public static Calendar getUTCCalendar() {

		DateTime dt = new DateTime(DateTimeZone.UTC);
		Calendar utcCalendar = dt.toCalendar(Locale.ENGLISH);
		return utcCalendar;
	}

	/**
	 * Sort date.
	 *
	 * @param dateTimeList the date time list
	 * @param order        the order
	 * @return the list
	 */
	public static List<DateTime> sortDate(List<DateTime> dateTimeList, String order) {

		Collections.sort(dateTimeList, new Comparator<DateTime>() {

			public int compare(DateTime o1, DateTime o2) {

				DateTimeComparator dtc = DateTimeComparator.getInstance();
				return dtc.compare(o1, o2);
			}

		});

		if (order.equalsIgnoreCase("desc")) {
			Collections.reverse(dateTimeList);
		}
		return dateTimeList;

	}

	/**
	 * Gets the date after no of days.
	 *
	 * @param daysCount the days count
	 * @return the date after no of days
	 */
	public static Date getDateAfterNoOfDays(int daysCount) {

		Calendar c = Calendar.getInstance();
		c.add(Calendar.DAY_OF_WEEK, daysCount);
		Date date = c.getTime();
		return date;
	}

	/**
	 * Gets the week day of tomorrow.
	 *
	 * @return the week day of tomorrow
	 */
	public static String getWeekDayOfTomorrow() {

		LogUtil.log(Steps.START, "Get Next day");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_WEEK, 1);
		final String parsedDate = new SimpleDateFormat("EEE").format(cal.getTime());
		return parsedDate.toLowerCase();
	}

	/**
	 * Gets the formatted date.
	 *
	 * @param date       the date
	 * @param dateFormat the date format
	 * @return the formatted date
	 */
	public static String getFormattedDate(Date date, String dateFormat) {

		LogUtil.log("Get String format for date: " + date + " with respect to date time format :" + dateFormat, LogLevel.LOW);
		final String parsedDate = new SimpleDateFormat(dateFormat).format(date);
		LogUtil.log("Required date: " + parsedDate, LogLevel.LOW);
		return parsedDate;
	}

	/**
	 * Gets the formatted date.
	 *
	 * @param days the days
	 * @return the formatted date
	 */
	public static String getFormattedDate(int days) {

		LocalDateTime localDate = LocalDateTime.now();
		LocalDateTime localDateBefore = localDate.minusDays(days);
		Calendar cal = Calendar.getInstance();
		String date;
		if (days == 0) {
			cal.set(Calendar.DAY_OF_MONTH, localDate.getDayOfMonth());
			Date dateTime = cal.getTime();
			SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			date = dateFormat.format(dateTime);
			LogUtil.log("Date formatted:" + date, LogLevel.LOW);

		} else {
			cal.set(Calendar.DAY_OF_MONTH, localDateBefore.getDayOfMonth());
			DateTimeFormatter dateTimeFormat = DateTimeFormat.forPattern("MM/dd/YYYY");
			date = localDateBefore.toString(dateTimeFormat);
			LogUtil.log("Date formatted:" + date, LogLevel.LOW);

		}
		return date;

	}

	/**
	 * Convert string to date.
	 *
	 * @param dateString the date string
	 * @param pattern    the pattern
	 * @return the date
	 * @throws ParseException the parse exception
	 */
	public static Date convertStringToDate(String dateString, String pattern) throws ParseException {

		LogUtil.log("Convert String to date", LogLevel.MEDIUM);
		SimpleDateFormat formate = new SimpleDateFormat(pattern);
		Date date = formate.parse(dateString);
		return date;
	}

	/**
	 * Gets the last date for current month.
	 *
	 * @param format the format
	 * @return the last date for current month
	 */
	public static String getLastDateForCurrentMonth(String format) {

		LogUtil.log("Get last date for the current month", LogLevel.MEDIUM);
		int lastDate = getLastDateOfParticularMonth(getCurrentMonth());
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_MONTH, lastDate);
		Date date = cal.getTime();

		return format(date, format);
	}

	/**
	 * Gets the first date for month and year.
	 *
	 * @param month  the month
	 * @param year   the year
	 * @param format the format
	 * @return the first date for month and year
	 */
	public static String getFirstDateForMonthAndYear(int month, int year, String format) {

		LogUtil.log("Get first date for the given month and year", LogLevel.MEDIUM);
		Calendar cal = Calendar.getInstance();
		cal.set(year, month, 1);
		Date date = cal.getTime();
		return format(date, format);
	}

	/**
	 * Gets the previous date.
	 *
	 * @param format the format
	 * @return the previous date
	 */
	public static String getPreviousDate(String format) {

		LogUtil.log("Get prvious date from current date", LogLevel.MEDIUM);
		final Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);

		return format(cal.getTime(), format);
	}

	/**
	 * Gets the current date.
	 *
	 * @param format the format
	 * @return the current date
	 */
	public static String getCurrentDate(String format) {

		final Calendar cal = Calendar.getInstance();
		return format(cal.getTime(), format);
	}

	/**
	 * Gets the back date from current date.
	 *
	 * @param format   the format
	 * @param backDate the back date
	 * @return the back date from current date
	 */
	public static String getBackDateFromCurrentDate(String format, int backDate) {

		LogUtil.log("Go " + backDate + " days back from current date", LogLevel.MEDIUM);

		DateTime dateTime = new DateTime();

		return dateTime.minusDays(backDate).toString(format);
	}

	/**
	 * Wait until difference in minutes.
	 */
	public static void waitUntilDifferenceInMinutes() {

		LocalTime currentTime = LocalTime.now();
		int time = currentTime.getMinute();
		int neededWait = ((time / 15) + 1) * 15 - time;
		LogUtil.log(Steps.START, "Needed wait in Minutes :" + neededWait);
		WaitUtil.waitUntil(neededWait * 60);

	}

	/**
	 * Gets the local time.
	 *
	 * @return the local time
	 */
	public static DateTime getLocalTime() {

		DateTime currentTime = DateTime.now();
		return currentTime;
	}

	/**
	 * Adds the minutes.
	 *
	 * @param dateTime the date time
	 * @param minutes  the minutes
	 * @return the date time
	 */
	public static DateTime addMinutes(DateTime dateTime, int minutes) {

		return dateTime.plusMinutes(minutes);
	}

	/**
	 * Gets the first date of specific month.
	 *
	 * @param format    the format
	 * @param backMonth the back month
	 * @return the first date of specific month
	 */
	public static String getFirstDateOfSpecificMonth(String format, int backMonth) {

		LogUtil.log("Go " + backMonth + " month back from current month", LogLevel.MEDIUM);
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.MONTH, -backMonth);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		SimpleDateFormat formatType = new SimpleDateFormat(format);

		return formatType.format(cal.getTime());
	}

	/**
	 * To find wait time for next hour.
	 *
	 * @param timeZone the time zone
	 * @param type     - inputs "MINUTES","SECONDS","MILLISECONDS"
	 * @return minutes/seconds/milliseconds based on type.
	 */
	public long getWaitTimeForNextHour(TimeZone timeZone, TimeUnit type) {

		ZonedDateTime plusHours = Instant.now().atZone(ZoneId.of(timeZone.getTimeZone()));
		int min = 60 - plusHours.getMinute();
		switch (type) {
			case MINUTES:
				return min;
			case SECONDS:
				return TimeUnit.MINUTES.toSeconds(min);
			case MILLISECONDS:
				return TimeUnit.MINUTES.toMillis(min);
			default:
				return 0;
		}
	}

	/**
	 * To find wait time for next hour and timezone is considered to be PST by
	 * default.
	 *
	 * @param type - inputs "MINUTES","SECONDS","MILLISECONDS"
	 * @return minutes/seconds/milliseconds based on type.
	 */
	public long getWaitTimeForNextHour(TimeUnit type) {

		ZonedDateTime plusHours = Instant.now().atZone(ZoneId.of(TimeZone.PST.getTimeZone()));
		int min = 60 - plusHours.getMinute();
		switch (type) {
			case MINUTES:
				return min;
			case SECONDS:
				return TimeUnit.MINUTES.toSeconds(min);
			case MILLISECONDS:
				return TimeUnit.MINUTES.toMillis(min);
			default:
				return 0;
		}
	}

	/**
	 * Gets the current time stamp for zone.
	 *
	 * @param timeZone the time zone
	 * @return the current time stamp for zone
	 */
	public static DateTime getCurrentTimeStampForZone(String timeZone) {

		DateTime startDate = new DateTime(DateTimeZone.forID(timeZone));
		return startDate;
	}

	/**
	 * Format date.
	 *
	 * @param date    the date
	 * @param pattern the pattern
	 * @return the string
	 */
	public static String formatDate(DateTime date, String pattern) {

		return date.toString(pattern);
	}

	/**
	 * String to date.
	 *
	 * @param date    the date
	 * @param pattern the pattern
	 * @return the string
	 */
	public static DateTime stringToDate(String date, String pattern) {

		return DateTimeFormat.forPattern(pattern).parseDateTime(date);
	}

	/**
	 * Checks if is valid format.
	 *
	 * @param format the format
	 * @param value  the value
	 * @return true, if is valid format
	 */
	public static boolean isValidFormat(String format, String value) {

		Date date = null;
		try {
			date = new SimpleDateFormat(format).parse(value);
		} catch (ParseException ex) {

		}
		return date != null;
	}

	/**
	 * Checks if is hour in interval.
	 *
	 * @param target the target
	 * @param start  the start
	 * @param end    the end
	 * @return true, if is hour in interval
	 */
	public static boolean isHourInInterval(String target, String start, String end) {

		return ((target.compareTo(start) >= 0) && (target.compareTo(end) <= 0));
	}

	/**
	 * Convert millisecs to minutes.
	 *
	 * @param milliseconds the milliseconds
	 * @return the double
	 */
	public static double convertMillisecsToMinutes(long milliseconds) {

		long minutes = TimeUnit.MILLISECONDS.toMinutes(milliseconds);
		return minutes;
	}

	/**
	 * Gets the difference.
	 *
	 * @param startDateTime the start date time
	 * @param endDateTime   the end date time
	 * @return the difference
	 */
	public static String getDifference(DateTime startDateTime, DateTime endDateTime) {

		Period p = new Period(startDateTime, endDateTime);
		int hours = p.getHours();
		int minutes = p.getMinutes();
		int seconds = p.getSeconds();
		int mSeconds = p.getMillis();
		String returnHourValue = hours == 0 ? "" : hours + "hr ,";
		String returnMinuteValue = minutes == 0 ? "" : minutes + "mins";
		String returnSecondsValue = seconds == 0 ? "" : seconds + "sec";
		String returnMSecondsValue = mSeconds == 0 ? "" : mSeconds + "msec";
		return returnHourValue + " " + returnMinuteValue + " " + returnSecondsValue + " " + returnMSecondsValue;
	}

	/**
	 * Counting number of days between 2 Dates.
	 *
	 * @param dateBeforeString the date before string
	 * @param dateAfterString  the date after string
	 * @return the long
	 */
	public static long countNumberOfDays(String dateBeforeString, String dateAfterString) {

		LocalDate dateBefore = LocalDate.parse(dateBeforeString);
		LocalDate dateAfter = LocalDate.parse(dateAfterString);

		long noOfDaysBetween = ChronoUnit.DAYS.between(dateBefore, dateAfter);
		return noOfDaysBetween;
	}

	/**
	 * Count number of days between 2 dates.
	 *
	 * @param dateBeforeString  the date before string
	 * @param dateAfterString   the date after string
	 * @param dateTimeFormatter the date time formatter
	 * @return the long
	 */
	public static long countNumberOfDays(String dateBeforeString, String dateAfterString, java.time.format.DateTimeFormatter dateTimeFormatter) {

		LocalDate dateBefore = LocalDate.parse(dateBeforeString, dateTimeFormatter);
		LocalDate dateAfter = LocalDate.parse(dateAfterString, dateTimeFormatter);

		long noOfDaysBetween = ChronoUnit.DAYS.between(dateBefore, dateAfter);
		return noOfDaysBetween;
	}

	/**
	 * Gets the last month.
	 *
	 * @return the last month
	 */
	public static String getLastMonth() {

		DateTime month = new DateTime().minusMonths(1);
		String pastMonth = DateUtil.getMonth().get(String.valueOf(month.getMonthOfYear()));

		return pastMonth;
	}


	/**
	 * Gets the time in format.
	 *
	 * @param format the format
	 * @return the time in format
	 */
	public static String getTimeInFormat(String format) {

		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		String localTimeFormat = formatter.format(date);
		return localTimeFormat;

	}

	/**
	 * Gets the time with additional seconds.
	 *
	 * @param minutesToAdd the format
	 * @param time   the time
	 * @return the time with additional seconds
	 */
	public static String getTimeWithAdditionalSeconds(String time, int minutesToAdd) {

		DateTimeFormatter formatter = DateTimeFormat.forPattern("HH:mm");
		DateTime dateTime = formatter.parseDateTime(time);

		DateTime newDateTime = dateTime.plusMinutes(minutesToAdd);
		String newTimeString = newDateTime.toString(formatter);
		LogUtil.log("Original Time: " + time, LogLevel.LOW);
		LogUtil.log("Time after adding " + minutesToAdd + " minutes: " + newTimeString, LogLevel.LOW);
		return newTimeString;

	}

	/**
	 * Gets the inbetween dates.
	 *
	 * @param fromDate the from date
	 * @param todate   the todate
	 * @param format   the format
	 * @return the inbetween dates
	 */
	public static List<String> getInbetweenDates(String fromDate, String todate, String format) {

		List<String> dateList = new ArrayList<String>();
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			Date date1 = sdf.parse(fromDate);
			Date date2 = sdf.parse(todate);

			Date currentDate = date1;

			while (currentDate.before(date2)) {
				dateList.add(sdf.format(currentDate));
				currentDate.setTime(currentDate.getTime() + (24 * 60 * 60 * 1000));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dateList;
	}

	/**
	 * Gets the up coming time.
	 *
	 * @param format the format
	 * @param sec    the sec
	 * @return the up coming time
	 */
	public static String getUpComingTime(String format, int sec) {

		Calendar c = Calendar.getInstance();
		c.setTime(new Date());
		c.add(Calendar.MINUTE, sec - (c.get(Calendar.MINUTE) % sec));
		Date time = c.getTime();
		SimpleDateFormat timeFormat = new SimpleDateFormat(format);
		String currentTime = timeFormat.format(time);
		return currentTime;
	}


	/**
	 * Gets the next date.
	 *
	 * @param format   the format
	 * @param noOfDays the no of days
	 * @return the next date
	 */
	public static String getNextDate(String format, int noOfDays) {

		SimpleDateFormat df = new SimpleDateFormat(format);
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR, noOfDays);
		Date tomorrow = calendar.getTime();
		String upcomingDate = df.format(tomorrow);
		LogUtil.log("Date : " + upcomingDate, LogLevel.LOW);

		return upcomingDate;
	}

	/**
	 * Gets the epochh time.
	 *
	 * @param humanDate the human date
	 * @return the epochh time
	 * @throws ParseException the parse exception
	 */
	public static String getEpochhTime(String humanDate) throws ParseException {

		Date date = null;
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		try {
			date = df.parse(humanDate);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		long epoch = date.getTime();
		System.out.println("Epoch Time : " + epoch);

		return String.valueOf(epoch);

	}

	/**
	 * Gets the day name.
	 *
	 * @param dayformat the dayformat
	 * @return the day name
	 */
	public static String getDayName(String dayformat) {
		SimpleDateFormat format = new SimpleDateFormat(dayformat);
		String dayName = format.format(new Date());
		return dayName;
	}

	/**
	 * Gets the time with addtional mins.
	 *
	 * @param timeString the time string
	 * @param min        the min
	 * @return the time with addtional mins
	 */
	public static String getTimeWithAddtionalMins(String timeString, long min) {

		LocalTime time = LocalTime.parse(timeString);
		LocalTime newTime = time.plusMinutes(min);
		String newTimeString = newTime.toString();
		return newTimeString;
	}

	public static String getTimeWithAddtionalMins(String pattern,String inputTime, int count) {

		DateTimeFormatter formatter = DateTimeFormat.forPattern(pattern);
		DateTime time = formatter.parseDateTime(inputTime);
		time = time.plusMinutes(count);
		String formattedTime = (time.isBeforeNow() ? "": "") + formatter.print(time);
		System.out.println(formattedTime);
		return formattedTime;
}


	public static String getBeforeMonthsStartDate(String pattern,int count) {

		DateTimeFormatter fmt = DateTimeFormat.forPattern(pattern);
		DateTime currentDateTime = DateTime.now();
		DateTime twoMonthsBefore = currentDateTime.minusMonths(count);
		DateTime startDate = twoMonthsBefore.withDayOfMonth(1);
		String startDates = fmt.print(startDate);
		return startDates;
	}

	public static String getNextDatesWithDaysCount(String date,String pattern, int datecount) {

		DateTimeFormatter formatter = DateTimeFormat.forPattern(pattern);
		DateTime inputDate = formatter.parseDateTime(date);

		DateTime nextDate = inputDate.plusDays(datecount);
		String nextDates = formatter.print(nextDate);
		return nextDates;
	}

	public static String getFutureDateInFormatt(String date,String pattern,int daysToAdd){
		DateTimeFormatter formatter = DateTimeFormat.forPattern(pattern);
		DateTime parsedDate = formatter.parseDateTime(date);

		DateTime futureDate = parsedDate.plusDays(daysToAdd);

		String formattedFutureDate = futureDate.toString(pattern);
		System.out.println("Future Date: " + formattedFutureDate);
		return formattedFutureDate;
	}

	public static String getDateInFormated(String inputdate, String currentpattern,String changepattern) {
		DateTimeFormatter originalFormatter = DateTimeFormat.forPattern(currentpattern);
		DateTime originalDate = originalFormatter.parseDateTime(inputdate);
		DateTimeFormatter outputFormatter = DateTimeFormat.forPattern(changepattern);
		String formattedDate = outputFormatter.print(originalDate);
		return formattedDate;
}

	public static String getDateInFormat(String inputDate, String inputFormat,String outputFormat,int daysToAdd) {
		DateTimeFormatter inputFormatter = DateTimeFormat.forPattern(inputFormat);
		DateTime parsedDate = inputFormatter.parseDateTime(inputDate);
		DateTime futureDate = parsedDate.plusDays(daysToAdd);
		DateTimeFormatter outputFormatter = DateTimeFormat.forPattern(outputFormat);
		String formattedDate = futureDate.toString(outputFormatter);
		LogUtil.log("Date In Formatted: "+ formattedDate,LogLevel.LOW);

        return formattedDate;
}

}
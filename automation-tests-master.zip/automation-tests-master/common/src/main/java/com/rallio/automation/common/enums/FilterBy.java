package com.rallio.automation.common.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum FilterBy.
 */
public enum FilterBy {

	/** The subject. */
	SUBJECT("Subject"),

	/** The from. */
	FROM("From");
	
	/** The filter type. */
	String filterType;

	/**
	 * Instantiates a new filter by.
	 *
	 * @param filterBy the filter by
	 */
	FilterBy(String filterBy) {

		this.filterType = filterBy;
	}
	
	
}

package com.rallio.automation.common.enums;

public enum UserType {
	
	
	LOCATION_USER,
	
	BRAND_USER,
	
	HUB_USER,
	
	ADMIN_USER;
	

}

package com.rallio.automation.common.manager;

import java.util.*;

import com.rallio.automation.common.enums.*;
import com.rallio.automation.common.util.*;

/**
 * The Class ConfigManager.
 */
public class ConfigManager {

	/** The config. */
	static Properties config = new Properties();

	/**
	 * Load config.
	 *
	 * @param propertyFile the property file
	 */
	public static void loadConfig(String propertyFile) {

		try {
			config.load(ConfigManager.class.getClassLoader().getResourceAsStream(propertyFile));
		} catch (Exception e) {
			LogUtil.log("No config file " + propertyFile, LogLevel.HIGH);
		}
	}

	/**
	 * Gets the value.
	 *
	 * @param key the key
	 * @return the value
	 */
	public static String getValue(String key) {

		String value = null;
		if (key != null) {
			value = config.getProperty(key);

		} else {
			LogUtil.log("No Value found for the specified key:" + key + " in file ralioactivate-stg.properties", LogLevel.LOW);
		}
		return value;
	}
	
	/**
	 * Gets the list of values.
	 *
	 * @param key the key
	 * @return the list of values
	 */
	public static List<String> getListOfValues(String key) {

		List<String> values = null;
		if (key != null) {
			values = Arrays.asList(config.getProperty(key).split(","));

		} else {
			LogUtil.log("No Value found for the specified key:" + key + " in file reviqmetric-stg.properties", LogLevel.LOW);
		}
		LogUtil.log("List Of Values From TestData:"+values.toString(), LogLevel.LOW);
		return values;
	}
}

package com.rallio.automation.common.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum LogLevel.
 */
public enum LogLevel {

	/** The low. */
	LOW(0),
	/** The medium. */
	MEDIUM(1),
	/** The high. */
	HIGH(2);

	/**
	 * The value.
	 */
	private final int value;

	/**
	 * Instantiates a new custom log level.
	 * 
	 * @param value the value
	 */
	private LogLevel(final int value) {

		this.value = value;
	}

	/**
	 * Gets the value.
	 * 
	 * @return the value
	 */
	public int getValue() {

		return value;
	}
}

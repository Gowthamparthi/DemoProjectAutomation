package com.rallio.automation.common.util;


import java.util.LinkedList;
import java.util.List;

import com.rallio.automation.common.html.*;

/**
 * The Class HtmlUtil.
 * 
 * @author $Author:$
 * @version $Rev:$ $Date:$
 */
public class HtmlUtil {

	/**
	 * Creates the table.
	 * 
	 * @param style the style
	 * @param border the border
	 * @param width the width
	 * @return the string
	 */
	public static String createTable(String style, String border, String width) {

		String table = "<table style=\"" + style + "\" border=\"" + border + "\">";
		return table;
	}

	/**
	 * Creates the rows and columns.
	 * 
	 * @param rowData the row data
	 * @return the string
	 */
	public static String createRowsAndColumns(List<Rows> rowData) {
		String content = "";
		for (Rows rows : rowData) {
			String rowValue = "<tr>";
			for (Columns column : rows.getColumn()) {
				String attr = "";
				String value = column.getValue();
				if (column.getColspan() != null && !column.getColspan().isEmpty()) {
					attr = "colspan=\"" + column.getColspan() + "\"";
					if(column.getHeading()!=null)
					{
						attr+=" style=\"text-align:center\"";
						value = "<b>"+ column.getHeading() +"</b>";
					}
				}
				
				rowValue += "<td " + attr + ">" + value + "</td>";
			}
			rowValue += "</tr>";
			content += rowValue;

			if (rows.getTable() != null && rows.getTable().size() > 0) {
				content += "</table>";

				for (Table table : rows.getTable()) {
					content += createRowsAndColumns(table);
				}
			}
		}

		if (content.lastIndexOf("table>") == -1) {
			content += "</table>";
		}

		return content;
	}

	/**
	 * Creates the rows and columns.
	 * 
	 * @param tableContent the table content
	 * @return the string
	 */
	private static String createRowsAndColumns(Table tableContent) {

		String table = "<table style=\"" + tableContent.getStyle() + "\" border=\"" + tableContent.getBorder() + "\">";
		String row = "";
		LinkedList<Rows> rowData = tableContent.getRows();
		for (Rows rows : rowData) {
			String rowValue = "<tr>";
			for (Columns column : rows.getColumn()) {
				String attr = "";
				String value = column.getValue();
				if (column.getColspan() != null && !column.getColspan().isEmpty()) {
					attr = "colspan=\"" + column.getColspan() + "\"";
					if(column.getHeading()!=null)
					{
						attr+=" style=\"text-align:center\"";
						value = "<b>"+ column.getHeading() +"</b>";
					}
				}
				
				rowValue += "<td " + attr + ">" + value + "</td>";
			}
			rowValue += "</tr>";
			row += rowValue;
		}
		return table + row + "</table>";
	}

	/**
	 * Close table.
	 * 
	 * @return the string
	 */
	public static String closeTable() {
		String table = "</table>";
		return table;
	}

	/**
	 * The main method.
	 * 
	 * @param args the arguments
	 */
	public static void main(String[] args) {

		LinkedList<Rows> rowData = new LinkedList<>();
		Rows rows2 = new Rows();
		LinkedList<Columns> cs2 = new LinkedList<>();
		Columns colum2 = new Columns();
		colum2.setValue("Heading");
		colum2.setColspan("4");
		cs2.add(colum2);
		rows2.setColumn(cs2);
		rowData.add(rows2);

		for (int i = 0; i < 2; i++) {
			Rows rows = new Rows();
			LinkedList<Columns> cs = new LinkedList<>();
			for (int j = 0; j < 4; j++) {
				Columns column = new Columns();
				column.setValue("ABC  " + j);
				cs.add(column);
			}

			rows.setColumn(cs);
			rowData.add(rows);
		}		
	}

}

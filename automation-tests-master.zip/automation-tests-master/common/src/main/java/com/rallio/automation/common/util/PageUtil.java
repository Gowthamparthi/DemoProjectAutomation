package com.rallio.automation.common.util;

import com.rallio.automation.common.enums.*;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;

import java.lang.reflect.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

// TODO: Auto-generated Javadoc
/**
 * The Class PageUtil.
 * 
 * @author $Author:$
 * @version $Rev:$ $Date:$
 */
public class PageUtil {

	/**
	 * The Enum EnumFields.
	 */
	private enum EnumFields {

	/** The by. */
	BY,
	/** The description. */
	DESCRIPTION;
	}

	/**
	 * Clear and set text.
	 * 
	 * @param driver the driver
	 * @param locator the locator
	 * @param innerText the inner text
	 * @param timeout the timeout
	 */
	public static void clearAndSetText(final WebDriver driver, final By locator, final String innerText, final Timeout timeout) {

		// added for testing if wait required.
		waitForElementVisibility(driver, locator, timeout);
		final WebElement element = getElement(driver, locator, timeout);
		// WebElement element = driver.findElement(locator);
		Assert.assertTrue(PageUtil.isDisplayed(driver, element, Timeout.FIVE_SEC), "Element cannot be null");
		try {
			//driver.findElement(locator).clear();
			element.clear();
			element.sendKeys(innerText);
			element.sendKeys(Keys.ENTER);
			WaitUtil.waitUntil(Timeout.ATOMIC_TIMEOUT);
		}

		catch (Exception e) {
			//driver.findElement(locator).click();
			//driver.findElement(locator).clear();
			//driver.findElement(locator).click();
			element.click();
			element.clear();
			element.click();
			element.sendKeys(innerText);
			element.sendKeys(Keys.ENTER);
			WaitUtil.waitUntil(Timeout.ATOMIC_TIMEOUT);
		}
	}

	/**
	 * Clear and set text without click enter.
	 *
	 * @param driver the driver
	 * @param locator the locator
	 * @param innerText the inner text
	 * @param timeout the timeout
	 */
	public static void clearAndSetTextWithoutClickEnter(final WebDriver driver, final By locator, final String innerText, final Timeout timeout) {

		final WebElement element = getElement(driver, locator, timeout);
		Assert.assertNotNull(element, "Element cannot be null");
		//element.clear();
		element.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		element.sendKeys(innerText);
	}
	
	/**
	 * Clear and set text click enter.
	 *
	 * @param driver the driver
	 * @param locator the locator
	 * @param innerText the inner text
	 * @param timeout the timeout
	 */
	public static void clearAndSetTextClickEnter(final WebDriver driver, final By locator, final String innerText, final Timeout timeout) {

		final WebElement element = getElement(driver, locator, timeout);
		Assert.assertNotNull(element, "Element cannot be null");
		//element.clear();
		element.click();
		element.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		element.sendKeys(innerText);
	}
	
	/**
	 * Clear text and set text.
	 *
	 * @param driver the driver
	 * @param locator the locator
	 * @param innerText the inner text
	 * @param timeout the timeout
	 */
	public static void clearTextAndSetText(final WebDriver driver, final By locator, final String innerText, final Timeout timeout) {

		final WebElement element = getElement(driver, locator, timeout);
		Assert.assertNotNull(element, "Element cannot be null");
		WaitUtil.waitUntil(Timeout.THREE_SEC);
		element.sendKeys(Keys.chord(Keys.CONTROL, "a"));
		element.sendKeys(Keys.BACK_SPACE);
		WaitUtil.waitUntil(Timeout.THREE_SEC);
		element.sendKeys(innerText);
	}
	/**
	 * Clear and set text without click enter.
	 *
	 * @param driver the driver
	 * @param element the locator
	 * @param innerText the inner text
	 * @param timeout the timeout
	 */
	public static void clearAndSetTextInFieldWithoutClickEnter(final WebDriver driver, final WebElement element, final String innerText, final Timeout timeout) {

		Assert.assertNotNull(element, "Element cannot be null");
		element.clear();
		element.sendKeys(innerText);
	}

	/**
	 * Clear and set text press enter.
	 * 
	 * @param driver the driver
	 * @param locator the locator
	 * @param innerText the inner text
	 * @param timeout the timeout
	 */
	public static void clearAndSetTextPressEnter(final WebDriver driver, final By locator, final String innerText, final Timeout timeout) {

		final WebElement element = getElement(driver, locator, timeout);
		element.clear();
		element.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		/*
		 * JavascriptExecutor jse = (JavascriptExecutor) driver;
		 * jse.executeScript("arguments[0].value='" + innerText + "';",
		 * element);
		 */
		element.clear();
		Actions actions = new Actions(driver);
		actions.sendKeys(element, innerText);
		actions.build().perform();
		/*
		 * String input = ""; for (int i = 0; i < innerText.length(); i++) {
		 * input += innerText.charAt(i); element.sendKeys(input); input = ""; }
		 */
		element.sendKeys(Keys.ENTER);
		WaitUtil.waitDefault(Timeout.THREE_SEC);

	}

	/**
	 * Sets the emoji.
	 *
	 * @param driver the driver
	 * @param locator the locator
	 * @param innerText the inner text
	 * @param timeout the timeout
	 */
	public static void setEmoji(final WebDriver driver, final By locator, final String innerText, final Timeout timeout) {

		final WebElement element = getElement(driver, locator, timeout);
		element.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].value='" + innerText + "';", element);
		element.sendKeys(Keys.ENTER);
	}

	/**
	 * Clear text.
	 * 
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 */
	public static void clearText(final WebDriver driver, final By locator, final Timeout timeout) {

		final WebElement element = getElement(driver, locator, timeout);
		try {
			element.clear();
			element.sendKeys(Keys.ENTER);
		}

		catch (Exception e) {
		}
	}

	/**
	 * Click.
	 *
	 * @param element the element
	 * @param driver the driver
	 */
	public static void click(WebElement element, final WebDriver driver) {

		/*
		 * JavascriptExecutor executor = (JavascriptExecutor) driver;
		 * executor.executeScript("arguments[0].click();", elem);
		 */
		JavascriptExecutor executor = (JavascriptExecutor) driver;

		try {
			if (element != null && !isDisplayed(driver, element, Timeout.FIVE_SEC)) {
				executor.executeScript("arguments[0].scrollIntoView(true);", element);
			}

			Assert.assertTrue(isDisplayed(driver, element, Timeout.FIVE_SEC), "Element not found in page for scroll to work.");
			executor.executeScript("arguments[0].click();", element);
		} catch (StaleElementReferenceException ex) {

			LogUtil.log("Stale exception occured, waiting for rebuilding the element.", LogLevel.HIGH);
			new WebDriverWait(driver, 60).until(ExpectedConditions.refreshed(ExpectedConditions.stalenessOf(element)));
			executor.executeScript("arguments[0].scrollIntoView(true);", element);
			Assert.assertTrue(isDisplayed(driver, element, Timeout.FIVE_SEC), "Element not found in page for scroll to work.");

			executor.executeScript("arguments[0].click();", element);
		}

	}

	/**
	 * Checks if is displayed.
	 * 
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 * @return true, if is displayed
	 */
	public static boolean isDisplayed(final WebDriver driver, final By locator, final Timeout timeout) {

		try {
			WebElement eleToScroll = getElement(driver, locator, timeout);

			if (eleToScroll != null && !eleToScroll.isDisplayed()) {
				scrollIntoView(driver, eleToScroll);
			}
		} catch (StaleElementReferenceException ex) {
			WebElement eleToScroll = getElement(driver, locator, timeout);

			if (eleToScroll != null && !eleToScroll.isDisplayed()) {
				scrollIntoView(driver, eleToScroll);
			}
		}
		String customTimeoutName = System.getProperty("CUSTOM_IS_DISPLAYED_TIMEOUT_NAME");
		final Timeout waitTimeout = customTimeoutName != null && !(customTimeoutName.isEmpty()) && Timeout.getByName(customTimeoutName) != null
		        ? Timeout.getByName(customTimeoutName)
		        : timeout;
		try {
			return new WebDriverWait(driver, waitTimeout.getValue()).until(ExpectedConditions.visibilityOfElementLocated(locator)).isDisplayed();
		} catch (Exception ex) {
			return false;
		}

	}

	/**
	 * Checks if is displayed.
	 *
	 * @param driver the driver
	 * @param element the element
	 * @param timeout the timeout
	 * @return true, if is displayed
	 */
	public static boolean isDisplayed(final WebDriver driver, final WebElement element, final Timeout timeout) {

		if (element != null && !element.isDisplayed()) {
			scrollIntoView(driver, element);
		}

		WebElement ele = null;
		try {
			ele = new WebDriverWait(driver, timeout.getValue()).until(new ExpectedCondition<WebElement>() {

				public WebElement apply(final WebDriver driver) {

					if (element != null && element.isDisplayed()) {
						return element;
					}
					return null;
				}
			});
		} catch (Exception e) {

		}

		return ele != null && ele.isDisplayed();

	}

	/**
	 * get case in sensitive xpath for contained string.
	 * 
	 * @param text the text
	 * 
	 * @return the xpath string for case Insensitive Contained String
	 */
	public static String caseInsensitiveContainedString(final String text) {

		return "contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + text.toLowerCase() + "')";
	}

	/**
	 * Checks if is visible.
	 * 
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 * @return true, if is visible
	 */
	public static boolean isVisible(final WebDriver driver, final By locator, final Timeout timeout) {

		try {
			return new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.visibilityOf(driver.findElement(locator))).isDisplayed();
		} catch (Exception ex) {
			return false;
		}
	}

	/**
	 * Wait until visibility.
	 * 
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 */
	public static void waitUntilVisibility(final WebDriver driver, final By locator, final Timeout timeout) {

		try {
			new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.visibilityOf(driver.findElement(locator)));
		} catch (Exception ex) {
			LogUtil.log("Exception in getting the Visible of Element", LogLevel.HIGH);
		}
	}
	
	/**
	 * Strong Wait until visibility.
	 * 
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 */
	public static void waitForElementVisibility(final WebDriver driver, final By locator, final Timeout timeout) {

		try {

			new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.visibilityOfElementLocated(locator));

		} catch (Exception ex) {
			LogUtil.log("Exception in getting the Visible of Element", LogLevel.HIGH);
			throw ex;
		}
	}

	public static boolean waitUntilElementNotDisplayed(final WebDriver driver, final By locator, final Timeout timeout) {
		try {
			new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.invisibilityOfElementLocated(locator));
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	/**
	 * Wait until element visible.
	 * 
	 * @param driver the driver
	 * @param element the element
	 * @param timeout the timeout
	 */
	public static void waitUntilElementVisible(final WebDriver driver, WebElement element, final Timeout timeout) {

		try {
			new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.visibilityOf(element));
		} catch (Exception ex) {
			LogUtil.log("Exception in getting the Visible of Element", LogLevel.HIGH);
		}
	}

	/**
	 * Checks if is visible.
	 * 
	 * @param driver the driver
	 * @param element the element
	 * @param timeout the timeout
	 * @return true, if is visible
	 */
	public static boolean isVisible(final WebDriver driver, final WebElement element, final Timeout timeout) {

		try {
			return new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.visibilityOf(element)).isDisplayed();
		} catch (Exception ex) {
			return false;
		}
	}

	/**
	 * Checks if is not displayed.
	 * 
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 * @return true, if is not displayed
	 */
	public static boolean isNotDisplayed(final WebDriver driver, final By locator, final Timeout timeout) {

		try {
			return new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.invisibilityOfElementLocated(locator));
		} catch (Exception ex) {
			return false;
		}
	}

	/**
	 * Checks if is not displayed.
	 *
	 * @param driver the driver
	 * @param locator the locator
	 * @param innerText the inner text
	 * @param timeout the timeout
	 * @return true, if is not displayed
	 */
	public static boolean isNotDisplayed(final WebDriver driver, final By locator, final String innerText, final Timeout timeout) {

		try {
			return new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.invisibilityOfElementWithText(locator,innerText));
		} catch (Exception ex) {
			return false;
		}
	}
	
	/**
	 * Checks if is enabled.
	 * 
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 * @return true, if is enabled
	 */
	public static boolean isEnabled(final WebDriver driver, final By locator, final Timeout timeout) {

		try {
			return new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.presenceOfElementLocated(locator)).isEnabled();
		} catch (Exception ex) {
			return false;
		}
	}

	/**
	 * Checks if is disabled.
	 *
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 * @return true, if is disabled
	 */
	public static boolean isDisabled(final WebDriver driver, final By locator, final Timeout timeout) {

		if (new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.presenceOfElementLocated(locator)).isEnabled())
			return false;
		else
			return true;
	}

	/**
	 * Checks if is selected.
	 * 
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 * @return true, if is selected
	 */
	public static boolean isSelected(final WebDriver driver, final By locator, final Timeout timeout) {

		try {
			return new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.presenceOfElementLocated(locator)).isSelected();
		} catch (Exception ex) {
			return false;
		}
	}

	/**
	 * Checks if is element clickable.
	 * 
	 * @param driver the driver
	 * @param element the element
	 * @param timeout the timeout
	 * @return the web element
	 */
	public static WebElement isElementClickable(final WebDriver driver, final WebElement element, final Timeout timeout) {

		try {
			return new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.elementToBeClickable(element));
		} catch (Exception te) {
			return null;
		}
	}

	/**
	 * Checks if is element present.
	 * 
	 * @param driver the driver
	 * @param locator the locator
	 * @return precense state
	 */
	public static boolean isElementPresent(final WebDriver driver, final By locator) {

		try {
			return driver.findElements(locator).size() > 0;
		} catch (Exception te) {
			return false;
		}
	}

	/**
	 * Checks if is web element clickable.
	 * 
	 * @param driver the driver
	 * @param element the element
	 * @param timeout the timeout
	 * @return true, if is web element clickable
	 */
	public static boolean isWebElementClickable(final WebDriver driver, final WebElement element, final Timeout timeout) {

		try {
			return new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.elementToBeClickable(element)).isDisplayed();
		} catch (Exception te) {
			return false;
		}
	}

	/**
	 * Checks if is web element not clickable.
	 *
	 * @param driver the driver
	 * @param element the element
	 * @param timeout the timeout
	 * @return true, if is web element not clickable
	 */
	public static boolean isWebElementNotClickable(final WebDriver driver, final WebElement element, final Timeout timeout) {

		try {
			return new WebDriverWait(driver, timeout.getValue()).until((ExpectedConditions.not(ExpectedConditions.elementToBeClickable(element))));
		} catch (Exception te) {
			return false;
		}
	}

	/**
	 * Gets the element.
	 * 
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 * @return the element
	 */
	public static WebElement getElement(final WebDriver driver, final By locator, final Timeout timeout) {

		try {
			return new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.presenceOfElementLocated(locator));
		} catch (StaleElementReferenceException ex) {

			return getElementOvercomingStale(driver, locator, timeout);
		} catch (Exception e) {
			return null;
		}

	}

	/**
	 * Gets the element overcoming stale.
	 *
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 * @return the element overcoming stale
	 */
	public static WebElement getElementOvercomingStale(final WebDriver driver, final By locator, final Timeout timeout) {

		try {
			LogUtil.log("Get element overcominng stale.", LogLevel.LOW);
			return new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated(locator)));
		} catch (Exception ex) {
			return null;
		}
	}

	/**
	 * Gets the element overcoming stale.
	 *
	 * @param driver the driver
	 * @param webElement the web element
	 * @param timeout the timeout
	 * @return the element overcoming stale
	 */
	public static WebElement getElementOvercomingStale(final WebDriver driver, final WebElement webElement, final Timeout timeout) {

		try {
			LogUtil.log("Get element overcominng stale.", LogLevel.LOW);
			return new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated((By) webElement)));
		} catch (Exception ex) {
			return webElement;
		}
	}

	/**
	 * Gets the first visible element.
	 * 
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 * @return the first visible element
	 */
	public static WebElement getFirstVisibleElement(final WebDriver driver, final By locator, final Timeout timeout) {

		final List<WebElement> visibleElements = getVisibleElements(driver, locator, timeout);
		return visibleElements.size() > 0 ? visibleElements.get(0) : null;
	}

	/**
	 * Gets the visible elements. Returns an array of webElements that are
	 * visible. If there are no visible DOM elements that match the criteria,
	 * then NULL is returned.
	 * 
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 * @return the visible elements
	 */
	public static List<WebElement> getVisibleElements(final WebDriver driver, final By locator, final Timeout timeout) {

		final List<WebElement> visibleElements = new ArrayList<>();
		try {
			for (final WebElement element : getElements(driver, locator, timeout)) {
				if (element.isDisplayed()) {
					visibleElements.add(element);
				}
			}
		} catch (Exception ex) {
			LogUtil.log("Element either not found or not visible.", LogLevel.HIGH);
		}
		return visibleElements;
	}

	/**
	 * Gets the element.
	 * 
	 * @param driver the driver
	 * @param attributeName the attribute name
	 * @param attributeValue the attribute value
	 * @param timeout the timeout
	 * @return the element
	 */
	public static WebElement getElement(final WebDriver driver, final String attributeName, final String attributeValue, final Timeout timeout) {

		try {
			return new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.presenceOfElementLocated(attribute(attributeName, attributeValue)));
		} catch (Exception ex) {
			return null;
		}
	}

	/**
	 * Gets the element by text.
	 * 
	 * @param driver the driver
	 * @param locator the locator
	 * @param innerText the inner text
	 * @param timeout the timeout
	 * @return the element by text
	 */
	public static WebElement getElementByText(final WebDriver driver, final By locator, final String innerText, final Timeout timeout) {

		for (final WebElement webElement : getElements(driver, locator, timeout)) {
			if (webElement.isDisplayed() && webElement.isEnabled() && webElement.getText().trim().equalsIgnoreCase(innerText)) {
				return webElement;
			}
		}
		return null;
	}

	/**
	 * Gets the element by text contains.
	 * 
	 * @param driver the driver
	 * @param locator the locator
	 * @param innerText the inner text
	 * @param timeout the timeout
	 * @return the element by text contains
	 */
	public static WebElement getElementByTextContains(final WebDriver driver, final By locator, final String innerText, final Timeout timeout) {

		for (final WebElement webElement : getElements(driver, locator, timeout)) {
			if (webElement.isDisplayed() && webElement.isEnabled() && webElement.getText().trim().contains(innerText)) {
				return webElement;
			}
		}
		return null;
	}

	/**
	 * Gets the elements.
	 * 
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 * @return the elements
	 */
	public static List<WebElement> getElements(final WebDriver driver, final By locator, final Timeout timeout) {

		try {
			return new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.presenceOfAllElementsLocatedBy(locator));
		} catch (Exception ex) {
			return null;
		}
	}

	/**
	 * Gets the element by sub element.
	 * 
	 * @param driver the driver
	 * @param element the element
	 * @param locator the locator
	 * @param timeout the timeout
	 * @return the element by sub element
	 */
	public static WebElement getElementBySubElement(final WebDriver driver, final WebElement element, final By locator, Timeout timeout) {

		try {
			return new WebDriverWait(driver, timeout.getValue()).until(new ExpectedCondition<WebElement>() {

				public WebElement apply(final WebDriver driver) {

					if (element.findElement(locator) != null) {
						return element.findElement(locator);
					}
					return null;
				}
			});
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * Gets the elements by sub element.
	 * 
	 * @param driver the driver
	 * @param element the element
	 * @param locator the locator
	 * @param timeout the timeout
	 * @return the elements by sub element
	 */
	public static List<WebElement> getElementsBySubElement(final WebDriver driver, final WebElement element, final By locator, Timeout timeout) {

		try {
			return new WebDriverWait(driver, timeout.getValue()).until(new ExpectedCondition<List<WebElement>>() {

				public List<WebElement> apply(final WebDriver driver) {

					if (element.findElement(locator) != null) {
						return element.findElements(locator);
					}
					return null;
				}
			});
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * Gets the element by sub element text.
	 * 
	 * @param driver the driver
	 * @param subElement the sub element
	 * @param locator the locator
	 * @param innerText the inner text
	 * @param timeout the timeout
	 * @return the element by sub element text
	 */
	public static WebElement getElementBySubElementText(final WebDriver driver, final WebElement subElement, final By locator, final String innerText, final Timeout timeout) {

		for (final WebElement webElement : getElementsBySubElement(driver, subElement, locator, timeout)) {
			final String valueAttribute = webElement.getText();
			if (valueAttribute.trim().equalsIgnoreCase(innerText)) {
				return webElement;
			}
		}
		return null;
	}

	/**
	 * Gets the element by sub element text contains.
	 * 
	 * @param driver the driver
	 * @param subElement the sub element
	 * @param locator the locator
	 * @param innerText the inner text
	 * @param timeout the timeout
	 * @return the element by sub element text contains
	 */
	public static WebElement getElementBySubElementTextContains(final WebDriver driver, final WebElement subElement, final By locator, final String innerText,
	        final Timeout timeout) {

		for (final WebElement webElement : getElementsBySubElement(driver, subElement, locator, timeout)) {
			final String valueAttribute = webElement.getText();
			if (valueAttribute.trim().contains(innerText)) {
				return webElement;
			}
		}
		return null;
	}

	/**
	 * Checks if is page load complete.
	 * 
	 * @param driver the driver
	 * @return true, if is page load complete
	 */
	public static boolean isPageLoadComplete(final WebDriver driver) {

		try {
			return new WebDriverWait(driver, 120).until(new ExpectedCondition<Boolean>() {

				public Boolean apply(final WebDriver driver) {

					return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
				}
			});
		} catch (Exception ex) {
			return false;
		}
	}

	/**
	 * Checks if is page load complete.
	 *
	 * @param driver the driver
	 * @param loadingElementXpath the loading element xpath
	 * @return true, if is page load complete
	 */
	public static boolean isPageLoadComplete(WebDriver driver, String loadingElementXpath) {

		boolean pageLoaded = false;
		By loadingElement = By.xpath(loadingElementXpath);
		WebDriverWait wait = new WebDriverWait(driver, 300);
		System.out.println("Page load start:" + DateUtil.format(Calendar.getInstance(), "HH:mm:ss"));
		try {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(loadingElement));
			pageLoaded = true;
		} catch (Exception e) {
			LogUtil.log("Page keeps on loading more than 300 seconds", LogLevel.MEDIUM);

		}
		System.out.println("Page load end:" + DateUtil.format(Calendar.getInstance(), "HH:mm:ss"));
		return pageLoaded;
	}

	/**
	 * Checks if is loading symbol disappears.
	 *
	 * @param driver the driver
	 * @return true, if is loading symbol disappears
	 */
	public static boolean isLoadingSymbolDisappears(WebDriver driver) {

		boolean pageLoaded = false;
		By loadingElement = By.xpath("//*[text()='Loading... Please wait' and @class='x-mask-msg-text']");
		WebDriverWait wait = new WebDriverWait(driver, 600);
		LogUtil.log("Page load start:" + DateUtil.format(Calendar.getInstance(), "HHmmSSss"), LogLevel.LOW);
		try {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(loadingElement));
			pageLoaded = true;
		} catch (Exception e) {
			LogUtil.log("Page keeps on loading more than 300 seconds", LogLevel.MEDIUM);
		}

		LogUtil.log("Page load end:" + DateUtil.format(Calendar.getInstance(), "HHMMSSss"), LogLevel.LOW);
		return pageLoaded;
	}

	/**
	 * Checks if is loading complete.
	 * 
	 * @param driver the driver
	 * @return true, if is loading complete
	 */
	public static boolean isLoadingComplete(final WebDriver driver) {

		boolean isloaded = false;
		try {
			new WebDriverWait(driver, 300).until(ExpectedConditions.presenceOfElementLocated(
			        By.xpath(".//*[contains(@class,'xt-common-header-button navigation x-box-item xt-common-header-button-default') or @id='busTitle']")));
			isloaded = true;
		} catch (Exception ex) {
			isloaded = false;
		}
		return isloaded;
	}

	/**
	 * Checks if is loading complete for the specific timeout.
	 * 
	 * @param driver the driver
	 * @param timeout the timeout
	 * @return true, if is loading complete
	 */
	public static boolean isLoadingComplete(final WebDriver driver, final Timeout timeout) {

		WaitUtil.waitUntil(Timeout.ATOMIC_TIMEOUT);
		boolean isloaded = false;
		try {
			new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.presenceOfElementLocated(
			        By.xpath(".//*[contains(@class,'xt-common-header-button navigation x-box-item xt-common-header-button-default') or @id='busTitle']")));
			isloaded = true;
		} catch (Exception ex) {
			isloaded = false;
		}
		LogUtil.log("is loading image dissapers :" + isloaded, LogLevel.HIGH);

		return isloaded;
	}

	/**
	 * Attribute.
	 * 
	 * @param tagname the tagname
	 * @param value the value
	 * @return the by
	 */
	public static By attribute(final String tagname, final String value) {

		return By.cssSelector("[" + tagname + "=\"" + value + "\"]");
	}

	/**
	 * Checks if is page loaded.
	 * 
	 * @param driver the driver
	 * @param element the element
	 * @return true, if is page loaded
	 */
	public static boolean isPageLoaded(WebDriver driver, WebElement... element) {

		boolean elementLoaded = false;
		try {

			for (int i = 0; i < element.length; i++) {
				elementLoaded = element[i].isDisplayed();
				if (!elementLoaded) {
					break;
				}
			}
			LogUtil.log("Page load :" + elementLoaded, LogLevel.HIGH);
			elementLoaded = elementLoaded && PageUtil.isPageLoadComplete(driver);
		} catch (Exception ex) {
			elementLoaded = false;
		}
		return elementLoaded;

	}

	/**
	 * Wait until loading symbol disappers.
	 *
	 * @param driver the driver
	 * @param timeout the timeout
	 * @return true, if successful
	 */
	public static boolean isLoadingSymbolDisappeared(final WebDriver driver, Timeout timeout) {

		boolean isloaded = false;
		try {
			new WebDriverWait(driver, timeout.getValue())
			        .until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'loader')]//span[@class='info-state']")));
			isloaded = true;
		} catch (Exception ex) {
			isloaded = false;
		}
		return isloaded;
	}

	/**
	 * Wait until loading symbol disappers.
	 *
	 * @param driver the driver
	 * @param timeout the timeout
	 * @return true, if successful
	 */
	public static boolean isMarketingLoadingSymbolHidden(final WebDriver driver, Timeout timeout) {

		boolean isloaded = false;
		try {
			LogUtil.log("Waiting for marketing page to load", LogLevel.HIGH);
			new WebDriverWait(driver, timeout.getValue())
			        .until(ExpectedConditions.numberOfElementsToBe(By.xpath("//*[@class='x-mask-msg' and not(contains(@style,'display: none'))]"), 0));
			isloaded = true;
		} catch (Exception ex) {
			isloaded = false;
		}
		LogUtil.log("Marketing page loaded", LogLevel.HIGH);
		return isloaded;
	}

	/**
	 * Drag and drop.
	 * 
	 * @param driver the driver
	 * @param fromElement the from element
	 * @param toElement the to element
	 * @param xOffset the x offset
	 * @param yOffset the y offset
	 */
	public static void dragAndDrop(final WebDriver driver, final WebElement fromElement, final WebElement toElement, final int xOffset, final int yOffset) {

		final Actions builder = new Actions(driver);
		builder.dragAndDrop(fromElement, toElement).build().perform();

	}

	/**
	 * Move to element.
	 * 
	 * @param driver the driver
	 * @param element the element
	 */
	public static void moveToElement(final WebDriver driver, final WebElement element) {

		final Actions builder = new Actions(driver);

		builder.moveToElement(element).build().perform();
	}

	/**
	 * Double click.
	 * 
	 * @param driver the driver
	 * @param element the element
	 */
	public static void doubleClick(final WebDriver driver, final WebElement element) {

		new Actions(driver).doubleClick(element).perform();
	}

	/**
	 * Checks if is text displayed in source.
	 * 
	 * @param driver the driver
	 * @param content the content
	 * @param timeout the timeout
	 * @return true, if is text displayed in source
	 */
	public static boolean isTextDisplayedInSource(final WebDriver driver, final String content, Timeout timeout) {

		try {
			return new WebDriverWait(driver, timeout.getValue()).until(new ExpectedCondition<Boolean>() {

				public Boolean apply(final WebDriver driver) {

					return driver.getPageSource().contains(content);
				}
			});
		} catch (Exception ex) {
			return false;
		}
	}

	/**
	 * Check and accept if alert displayed.
	 *
	 * @param driver the driver
	 */
	public static void checkAndAcceptIfAlertDisplayed(final WebDriver driver) {

		if (isAlertPresent(driver)) {
			driver.switchTo().alert().accept();
		}
	}

	/**
	 * Gets the alert text.
	 * 
	 * @param driver the driver
	 * @return the alert text
	 */
	public static String getAlertText(final WebDriver driver) {

		Alert alert = driver.switchTo().alert();
		String alertText = alert.getText();
		alert.accept();
		return alertText;
	}

	/**
	 * Checks if is alert present.
	 * 
	 * @param driver the driver
	 * @return true, if is alert present
	 */
	public static boolean isAlertPresent(final WebDriver driver) {

		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException Ex) {
			return false;
		}
	}

	/**
	 * Execute script by class name.
	 * 
	 * @param name the name
	 * @param propertyName the property name
	 * @param driver the driver
	 * @return the object
	 */
	public static Object executeScriptByClassName(final String name, final String propertyName, final WebDriver driver) {

		final JavascriptExecutor javascript = (JavascriptExecutor) driver;
		final Object val = javascript.executeScript(new StringBuilder("return window.document.defaultView.getComputedStyle(window.document.getElementsByClassName('").append(name)
		        .append("')[0]).getPropertyValue('").append(propertyName).append("');").toString());
		return val;
	}

	/**
	 * Gets the value by id.
	 * 
	 * @param id the id
	 * @param driver the driver
	 * @return the value by id
	 */
	public static String getValueById(final String id, final WebDriver driver) {

		final JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
		final Object val = jsExecutor.executeScript("return window.document.getElementById('" + id + "').value;");
		return val.toString();
	}

	/**
	 * Method to set date in a date picker.
	 * 
	 * @author Ruth Chirinos
	 * @param driver the WebDriver
	 * @param xpathDatePicker the xpath of the datePicker
	 * @param dateRequested the date requested
	 * @return true, if successful
	 * @throws InterruptedException the interrupted exception
	 * @throws ParseException the parse exception
	 */
	@SuppressWarnings("deprecation")
	public static boolean setDateInDatePicker(WebDriver driver, String xpathDatePicker, Date dateRequested) throws InterruptedException, ParseException {

		Calendar dateRequestedCalendar = DateUtil.getCalendarForDate(dateRequested);
		LogUtil.log("Date for changing is > " + DateUtil.format(dateRequestedCalendar, DateUtil.DATE_MONTH_ABBREVIATION), LogLevel.LOW);
		boolean processOk = false;
		String dateSelectedString = "";
		Date dateSelected = null;

		SimpleDateFormat simpleFormat = new SimpleDateFormat(DateUtil.DATE_MONTH_YEAR_FMT);
		WebElement datePicker = driver.findElement(By.xpath(xpathDatePicker));
		datePicker.click();
		WebElement monthYearElement = driver.findElement(By.xpath("//div[@class='x-datepicker-month']/div/div/a/span[1]"));
		WebElement daySelected = driver.findElement(By.xpath("//*[contains(@class, 'x-datepicker-selected')]/a"));
		dateSelectedString = daySelected.getAttribute("innerHTML") + " " + monthYearElement.getAttribute("innerHTML");
		dateSelected = simpleFormat.parse(dateSelectedString);

		WebElement pickerPrevEl = driver.findElement(By.xpath("//div[@class='x-datepicker-header']/a[contains(@class, 'x-datepicker-prev')]"));
		WebElement pickerNextEl = driver.findElement(By.xpath("//div[@class='x-datepicker-header']/a[contains(@class, 'x-datepicker-next')]"));

		// Choosing the year
		while (dateRequested.getYear() < dateSelected.getYear()) {
			pickerPrevEl.click();
			monthYearElement = driver.findElement(By.xpath("//div[@class='x-datepicker-month']/div/div/a/span[1]"));
			dateSelectedString = daySelected.getAttribute("innerHTML") + " " + monthYearElement.getAttribute("innerHTML");
			dateSelected = simpleFormat.parse(dateSelectedString);
		}

		while (dateRequested.getYear() > dateSelected.getYear()) {
			pickerNextEl.click();
			monthYearElement = driver.findElement(By.xpath("//div[@class='x-datepicker-month']/div/div/a/span[1]"));
			dateSelectedString = daySelected.getAttribute("innerHTML") + " " + monthYearElement.getAttribute("innerHTML");
			dateSelected = simpleFormat.parse(dateSelectedString);
		}

		// Choosing the months
		while (dateRequested.getMonth() < dateSelected.getMonth()) {
			pickerPrevEl.click();
			monthYearElement = driver.findElement(By.xpath("//div[@class='x-datepicker-month']/div/div/a/span[1]"));
			dateSelectedString = daySelected.getAttribute("innerHTML") + " " + monthYearElement.getAttribute("innerHTML");
			dateSelected = simpleFormat.parse(dateSelectedString);
		}

		while (dateRequested.getMonth() > dateSelected.getMonth()) {
			pickerNextEl.click();
			monthYearElement = driver.findElement(By.xpath("//div[@class='x-datepicker-month']/div/div/a/span[1]"));
			dateSelectedString = daySelected.getAttribute("innerHTML") + " " + monthYearElement.getAttribute("innerHTML");
			dateSelected = simpleFormat.parse(dateSelectedString);
		}

		// Choosing the day
		WebElement dateWidget = driver.findElement(By.className("x-datepicker-inner"));
		List<WebElement> columns = dateWidget.findElements(By.tagName("td"));
		int aux = 0;

		for (WebElement cell : columns) {
			if (cell.getText().equals(dateRequested.getDate() + "")) {
				processOk = cell.getAttribute("class").contains("x-datepicker-active");
				if (processOk) {
					cell.findElement(By.tagName("a")).click();;
					LogUtil.log("The date was selected.", LogLevel.LOW);
					aux = 1;
					break;
				}
			}
		}

		if (aux == 0) {
			LogUtil.log("The date selected is not enabled.", LogLevel.LOW);
		}
		return processOk;
	}

	/*
	 * Verify if a string contains an email format
	 */
	/**
	 * Check email format.
	 * 
	 * @param email the email
	 * @return true, if successful
	 */
	public static boolean checkEmailFormat(String email) {

		boolean result = false;
		Pattern patternEmail = Pattern
		        .compile("^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$");
		if (patternEmail.matcher(email).matches()) {
			result = true;
		}
		return result;
	}

	/**
	 * Switch to next window.
	 * 
	 * @param driver the driver
	 */
	public static void switchToNextWindow(WebDriver driver) {

		for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle);
		}
	}

	/**
	 * Switch to specefied window.
	 *
	 * @param driver the driver
	 * @param windowHandle the window handle
	 */
	public static void switchToSpecefiedWindow(WebDriver driver, int windowHandle) {

		Set<String> winHandles = driver.getWindowHandles();
		List<String> winHandlesList = new ArrayList<String>(winHandles);
		driver.switchTo().window(winHandlesList.get(windowHandle));
	}

	/**
	 * Checks for multiple windows.
	 *
	 * @param driver the driver
	 * @return true, if successful
	 */
	public static boolean hasMultipleWindows(WebDriver driver) {

		return driver.getWindowHandles().size() > 1 ? true : false;
	}

	public static void switchToOpenNewtab(WebDriver driver,String url) {
		((JavascriptExecutor) driver).executeScript("window.open()");
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		driver.get(url);
	}

	/**
	 * Scroll into view.
	 *
	 * @param driver the driver
	 * @param element the element
	 */
	public static void scrollIntoView(final WebDriver driver, WebElement element) {

		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);

	}

	/**
	 * Scroll into view if needed.
	 *
	 * @param driver the driver
	 * @param element the element
	 */
	public static void scrollIntoViewIfNeeded(final WebDriver driver, WebElement element) {

		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoViewIfNeeded(true);", element);

	}

	/**
	 * Maximize windows.
	 *
	 * @param driver the driver
	 */
	public static void maximizeWindows(WebDriver driver) {

		if (SystemUtil.isChrome()) {
			driver.manage().window().setSize(new Dimension(1366, 768));
			driver.manage().window().setPosition(new Point(0, 0));
//			driver.manage().window().maximize();
		} else if (SystemUtil.isUnix() && SystemUtil.isChrome()) {
			driver.manage().window().setSize(new Dimension(1400, 768));
		} else if (SystemUtil.isUnix() && ParamUtil.getBrowser().equalsIgnoreCase("chromeEmulator")) {
			LogUtil.log("Browser not maximized", LogLevel.LOW);
		} else {
			driver.manage().window().maximize();
		}
	}

	/**
	 * Checks if is page reloaded.
	 *
	 * @param driver the driver
	 * @param element the element
	 * @param timeout the timeout
	 * @return true, if is page reloaded
	 */
	public static boolean isPageReloaded(WebDriver driver, WebElement element, Timeout timeout) {

		try {
			new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.stalenessOf(element));
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	/**
	 * Checks if is displayed after load.
	 *
	 * @param driver the driver
	 * @param locator the locator
	 * @return true, if is displayed after load
	 */
	public static boolean isDisplayedAfterLoad(WebDriver driver, By locator) {

		try {
			isPageLoadComplete(driver);
			PageUtil.isLoadingComplete(driver, Timeout.TEN_SEC);
			new WebDriverWait(driver, 20).until(ExpectedConditions.presenceOfElementLocated(locator));
			return driver.findElement(locator).isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Checks if is element after load.
	 *
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 * @return true, if is element after load
	 */
	public static boolean isElementFoundAfterPageLoad(WebDriver driver, By locator, Timeout timeout) {

		boolean displayed = false;
		try {
			isPageLoadComplete(driver);
			PageUtil.isLoadingComplete(driver);
			new WebDriverWait(driver, timeout.getValue()).until(ExpectedConditions.visibilityOfElementLocated(locator));
			displayed = true;
		} catch (Exception e) {

		}

		return displayed;
	}

	/**
	 * Gets the element after load.
	 *
	 * @param driver the driver
	 * @param locator the locator
	 * @return the element after load
	 */
	public static WebElement getElementAfterLoad(WebDriver driver, By locator) {

		try {
			isPageLoadComplete(driver);
			PageUtil.isLoadingComplete(driver, Timeout.TEN_SEC);
			new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(locator));
			return driver.findElement(locator);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * Gets the by locator.
	 *
	 * @param enums the enums
	 * @return the by locator
	 */
	private static Map<EnumFields, Object> getByLocator(Enum<?> enums) {

		Map<EnumFields, Object> result = new HashMap<EnumFields, Object>();
		By by = null;
		String description = "";
		Enum<?>[] enumArray = enums.getClass().getEnumConstants();

		for (final Enum<?> xpathEnum : enumArray) {

			try {

				@SuppressWarnings({ "unchecked", "static-access" })
				Enum<?> pageEnum = xpathEnum.valueOf(enums.getClass(), enums.name());
				Method byMethod = null;
				Method descriptionMethod = null;

				byMethod = pageEnum.getClass().getMethod("getByLocator");
				descriptionMethod = pageEnum.getClass().getMethod("getDescription");

				by = (By) byMethod.invoke(pageEnum);
				description = (String) descriptionMethod.invoke(pageEnum);

				result.put(EnumFields.BY, by);
				result.put(EnumFields.DESCRIPTION, description);

			} catch (Exception ex) {
				ex.printStackTrace();
				LogUtil.log("Error in Filling Text box values : " + ex.getMessage(), LogLevel.HIGH);
			}
		}

		return result;
	}

	/**
	 * Fill text box value.
	 *
	 * @param <T> the generic type
	 * @param driver the driver
	 * @param enums the enums
	 * @param value the value
	 * @param doAssert the do assert
	 */
	public static <T> void fillText(WebDriver driver, Enum<?> enums, final String value, Boolean doAssert) {

		Map<EnumFields, Object> locator = getByLocator(enums);
		if (value != null && !value.isEmpty()) {

			WebElement element = PageUtil.getElement(driver, (By) locator.get(EnumFields.BY), Timeout.FIVE_SEC);
			scrollIntoView(driver, element);
			if (doAssert) {
				Assert.assertTrue(element != null && element.isDisplayed(), (String) locator.get(EnumFields.DESCRIPTION) + " field is not displayed");
			}
			setText(element, value);
		}
	}

	/**
	 * Click.
	 *
	 * @param <T> the generic type
	 * @param driver the driver
	 * @param enums the enums
	 * @param doAssert the do assert
	 */
	public static <T> void click(WebDriver driver, Enum<?> enums, Boolean doAssert) {

		Map<EnumFields, Object> locator = getByLocator(enums);
		WebElement element = PageUtil.getElement(driver, (By) locator.get(EnumFields.BY), Timeout.FIVE_SEC);
		scrollIntoView(driver, element);
		if (doAssert) {
			Assert.assertTrue(element.isDisplayed(), (String) locator.get(EnumFields.DESCRIPTION) + " button is not displayed");
		}
		click(element, driver);
	}

	/**
	 * Sets the text.
	 *
	 * @param fieldName the field name
	 * @param value the value
	 */
	public static void setText(WebElement fieldName, String value) {

		clearText(fieldName);
		fieldName.clear();
		if (value != null) {
			fieldName.sendKeys(value);
		}
	}

	/**
	 * Sets the text without clearing field.
	 *
	 * @param element the element
	 * @param value the value
	 */
	public static void setTextWithoutClearingField(WebElement element, String value) {

		if (value != null) {
			element.sendKeys(value);
		}
	}

	/**
	 * Clear text.
	 *
	 * @param fieldName the field name
	 */
	private static void clearText(WebElement fieldName) {

		fieldName.sendKeys(Keys.SHIFT, Keys.HOME, Keys.BACK_SPACE);
	}

	/**
	 * Generate a random email.
	 * 
	 * @return random email.
	 */
	public static String getEmail() {

		String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		StringBuilder salt = new StringBuilder();
		Random rnd = new Random();
		while (salt.length() < 10) { // length of the random string.
			int index = (int) (rnd.nextFloat() * SALTCHARS.length());
			salt.append(SALTCHARS.charAt(index));
		}
		String saltStr = salt.toString();
		return saltStr + "@gmail.com";
	}

	/**
	 * Gets the text from the specified locator.
	 *
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 * @return the text from locator
	 */
	public static String getTextFromLocator(WebDriver driver, By locator, Timeout timeout) {

		WebElement textEl = getElement(driver, locator, timeout);
		return textEl.getText();
	}

	/**
	 * Refresh the CUrrent URL.
	 *
	 * @param driver the driver
	 */
	public static void refresh(WebDriver driver) {

		LogUtil.log("Do refresh.", LogLevel.LOW);
		WaitUtil.waitUntil(2);
		driver.navigate().refresh();
		LogUtil.log("Refresh done.", LogLevel.LOW);
	}

	/**
	 * Checks if is number present in element text.
	 *
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 * @return true, if is number present in element text
	 */
	public static boolean isNumberPresentInElementText(WebDriver driver, By locator, Timeout timeout) {

		try {
			String text = getTextFromLocator(driver, locator, timeout);
			LogUtil.log("Text present in Element :" + text, LogLevel.LOW);
			return text.matches(".*\\d.*");
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Select dropdown option.
	 *
	 * @param webElement the web element
	 * @param option the option
	 */
	public static void selectDropdownOption(final WebElement webElement, final String option) {

		Select dropdown = new Select(webElement);
		dropdown.selectByVisibleText(option);
	}

	/**
	 * Gets the text from selected dropdown option.
	 *
	 * @param webElement the web element
	 * @return the text from selected dropdown option
	 */
	public static String getTextFromSelectedDropdownOption(final WebElement webElement) {

		Select dropdown = new Select(webElement);
		String selectedOption = dropdown.getFirstSelectedOption().getText();
		return selectedOption;
	}

	/**
	 * Select random option from dropdown.
	 *
	 * @param webElement the web element
	 */
	public static void selectRandomOptionFromDropdown(final WebElement webElement) {

		Select dropdown = new Select(webElement);
		int randomOption = dropdown.getOptions().size();
		dropdown.selectByIndex(ThreadLocalRandom.current().nextInt(0, randomOption));
	}

	/**
	 * Gets the attribute text from element.
	 *
	 * @param webElement the web element
	 * @param attribute the attribute
	 * @return the attribute text from element
	 */
	public static String getAttributeTextFromElement(final WebElement webElement, String attribute) {

		try {

			return webElement.getAttribute(attribute);

		} catch (Exception e) {
			LogUtil.log("No Attribute " + attribute + " found.", LogLevel.LOW);
			return null;
		}
	}

	/**
	 * Checks if is number present in element value attribute.
	 *
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 * @return true, if is number present in element value attribute
	 */
	public static boolean isNumberPresentInElementValueAttribute(WebDriver driver, By locator, Timeout timeout) {

		WebElement webElement = getElement(driver, locator, timeout);
		String text = getAttributeTextFromElement(webElement, "value");
		LogUtil.log("Text present in Element :" + text, LogLevel.LOW);
		System.out.println("text = " + text);
		return text.matches(".*\\d.*");

	}

	/**
	 * Press enter.
	 *
	 * @param driver the driver
	 * @param locator the locator
	 * @param timeout the timeout
	 */
	public static void pressEnter(final WebDriver driver, final By locator, final Timeout timeout) {

		final WebElement element = getElement(driver, locator, timeout);
		element.sendKeys(Keys.ENTER);
	}

	/**
	 * Scroll to end of page.
	 *
	 * @param driver the driver
	 */
	public static void scrollToEndOfPage(final WebDriver driver) {

		((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		/*
		 * JavascriptExecutor js = (JavascriptExecutor)driver; Point point =
		 * webElement.getLocation(); int x = point.getX(); int y = point.getY();
		 * Actions action = new Actions(driver);
		 * //action.doubleClick(webElement).moveByOffset(150,200).build().
		 * perform(); js.executeScript("window.scrollBy(0,1000)");
		 * action.moveToElement(webElement, 1,1).build().perform();
		 */
	}
	
	/**
	 * Validate back to top option.
	 *
	 * @param driver the driver
	 * @param locator1 the locator 1
	 * @param locator2 the locator 2
	 * @param timeout the timeout
	 * @param scrollCount the scroll count
	 */
	public static void validateBackToTopOption(final WebDriver driver,final By locator1,final By locator2,final Timeout timeout,int scrollCount) {
		
		int i = 0;
		if(scrollCount <=5) {
			 LogUtil.log(Steps.START, "Scroll to The Element List");
			 while (i < scrollCount) {
				 final WebElement element = getElement(driver, locator1, timeout);
				 moveToElement(driver, element);
				 WaitUtil.waitUntil(Timeout.FIVE_SEC);
				 i++;
			}
		}
		final WebElement element1 = getElement(driver, By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"), timeout);
		Assert.assertTrue(PageUtil.isDisplayed(driver, element1, Timeout.FIVE_SEC), "Element cannot be null");
		LogUtil.log(Steps.START, "click the Back To Top button");
		element1.click();
		WaitUtil.waitUntil(Timeout.FIVE_SEC);
		if(locator2 != null)
		        Assert.assertTrue(PageUtil.isElementPresent(driver, locator2));
	}
	
	
	/**
	 * Sort the list in alphapetical.
	 *
	 * @param names the names
	 * @return the list
	 */
	public static List<String> sortTheListInAlphapetical(List<String> names) {

  		Collections.sort(names, new Comparator<String>()
  		{
  		    @Override
  		    public int compare(String text1, String text2)
  		    {
  		        return text1.compareToIgnoreCase(text2);
  		    }
  		});
  		return names;
  	}
	
	/**
	 * Gets the counts list.
	 *
	 * @param driver the driver
	 * @param locator1 the locator 1
	 * @return the counts list
	 */
	public static List<String> getCountsList(final WebDriver driver,final By locator1) {

		List<WebElement> countsWebElementList = PageUtil.getElements(driver, locator1, Timeout.THIRTY_SEC);
		List<String> countsList = new ArrayList<String>();
		for (WebElement webElement : countsWebElementList)
			if (!webElement.getText().contains("N/A"))
				if (webElement.getText().contains("K"))
					countsList.add(String.valueOf(Double.parseDouble(webElement.getText().replaceAll("K", "")) * 1000));
				else
					countsList.add(webElement.getText().replaceAll(",", ""));
		return countsList;
	}

	 /**
 	 * Sorting list.
 	 *
 	 * @param driver the driver
 	 * @param locator the locator
 	 * @param sorting the sorting
 	 * @return the list
 	 */
 	public static List<String> sortingList(final WebDriver driver,final  By locator,String sorting){
	        
	        List<String> datesSorting = new ArrayList<>();
	        List<String> dateCountList = getCountsList(driver,locator);
	        for (int i = 0; i < dateCountList.size() / 2; i++) {
	        	datesSorting.add(dateCountList.get(i));
			}
	        switch(sorting) {
	        case("Ascendingorder"):
	        	LogUtil.log(Steps.START, "Sorting the Date in Ascending order");  
		        Collections.sort(dateCountList);
		        LogUtil.log("Sorting the Date in Ascending order"+datesSorting,LogLevel.LOW);
	            break;
	        case("Descendingorder"):   
	        	LogUtil.log(Steps.START, "Sorting the Date in Descending order");
	            Collections.reverse(dateCountList);
	            LogUtil.log("Sorting the Date in Descending order"+datesSorting,LogLevel.LOW);
	            break;
	        }
	       return datesSorting;
	    }

	public static void waitUntilPageLoad(final WebDriver driver, final Timeout timeout) {

		int i = 0;
		while (i < 5) {
			boolean displayed = isDisplayed(driver, By.xpath("//span[@class='info-state']//parent::div//parent::div[contains(@class,'loader')]"), timeout);
			if (!displayed)
				break;
			else{
				WaitUtil.waitUntil(Timeout.FIVE_SEC);
				LogUtil.log("Page Load was completed", LogLevel.LOW);
			}
			i++;
		}
	}

}
	 
	
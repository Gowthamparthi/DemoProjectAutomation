package com.rallio.automation.common.adapter;

import java.lang.reflect.Method;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.rallio.automation.common.enums.*;
import com.rallio.automation.common.util.*;

/**
 * The Class PageAdapter.
 */
public class PageAdapter extends AbstractPageAdapter {

	/** The page adapter. */
	private static PageAdapter pageAdapter = null;

	/**
	 * Instantiates a new page adapter.
	 *
	 * @param driver the driver
	 */
	public PageAdapter(WebDriver driver) {

		AbstractPageAdapter.driver = driver;
	}

	/**
	 * Gets the single instance of PageAdapter.
	 *
	 * @param driver the driver
	 * @return single instance of PageAdapter
	 */
	public static PageAdapter getInstance(WebDriver driver) {

		if (pageAdapter == null)
			pageAdapter = new PageAdapter(driver);
		return pageAdapter;
	}

	/**
	 * Reset.
	 *
	 * @param driver the driver
	 * @return the page adapter
	 */
	public static PageAdapter reset(WebDriver driver) {

		pageAdapter = new PageAdapter(driver);
		return pageAdapter;
	}

	/*
	 * Method override
	 */
	@Override
	public boolean isElementLoaded(Enum<?> enums) {

		return false;
	}

	/*
	 * Method override
	 */
	public boolean triggerTextBoxEvents(Enum<?> setEnum, final String value, Boolean doAssert, Boolean authenticate, Enum<?> getEnum) {

		fillTextBoxValue(setEnum, value, doAssert);

		if (authenticate) {
			return isElementLoaded(getEnum);
		}

		return false;
	}

	/*
	 * Method override
	 */
	public boolean triggerClickEvents(Enum<?> setEnum, final Boolean doAssert, Boolean authenticate, Enum<?> getEnum) {

		try {
			click(setEnum, doAssert);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (authenticate) {
			return isElementDisplayed(getEnum);
		}
		return false;
	}

	/*
	 * Method override
	 */
	@Override
	public boolean isElementDisplayed(Enum<?> enums) {

		By by = null;
		Enum<?> xpathEnum = enums.getClass().getEnumConstants()[0];

		try {
			@SuppressWarnings({ "unchecked", "static-access" })
			Enum<?> pageEnum = xpathEnum.valueOf(enums.getClass(), enums.name());
			Method byMethod = null;
			byMethod = pageEnum.getClass().getMethod("getByLocator");
			by = (By) byMethod.invoke(pageEnum);
		} catch (Exception ex) {
			ex.printStackTrace();
			LogUtil.log("Exception in display element: " + ex.getMessage(), LogLevel.HIGH);
		}

		WebElement element = PageUtil.getElement(driver, by, Timeout.FIVE_SEC);
		return element != null && element.isDisplayed();
	}

	/**
	 * Select option from list.
	 *
	 * @param selectBox the select box
	 * @param doAssert the do assert
	 * @param optionLocator the option locator
	 */
	public void selectOptionFromList(Enum<?> selectBox, final Boolean doAssert, By optionLocator) {

		try {
			click(selectBox, doAssert);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (PageUtil.isDisplayed(driver, optionLocator, Timeout.FIVE_SEC)) {
			WebElement option = PageUtil.getElement(driver, optionLocator, Timeout.FIVE_SEC);
			PageUtil.click(option, driver);
		}
	}

	/**
	 * Gets the element text.
	 *
	 * @param enums the enums
	 * @param doAssert the do assert
	 * @return the element text
	 */
	public String getElementText(Enum<?> enums, final Boolean doAssert) {

		return getElementLocator(enums, doAssert).getText().trim();
	}

}

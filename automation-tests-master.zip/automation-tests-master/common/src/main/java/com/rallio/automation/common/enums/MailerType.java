package com.rallio.automation.common.enums;

public enum MailerType {

	BRANDUSER("BrandUser"),
	
	ENDUSER("EndUser");
	
	String mailerType ;
	
	MailerType(String mailerType){
		this.mailerType = mailerType;
	}
}

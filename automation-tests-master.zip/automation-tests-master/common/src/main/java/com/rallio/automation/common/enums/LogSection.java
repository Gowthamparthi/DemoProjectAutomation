package com.rallio.automation.common.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum LogSection.
 */
public enum LogSection {

	/** The start. */
	START,
	/** The end. */
	END;
}

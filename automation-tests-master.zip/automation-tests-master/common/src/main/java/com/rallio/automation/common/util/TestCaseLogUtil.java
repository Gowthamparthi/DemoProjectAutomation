package com.rallio.automation.common.util;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.TreeMap;

import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.Reporter;

import com.rallio.automation.common.data.*;
import com.rallio.automation.common.enums.*;

/**
 * The Class TestCasePrintUtil.
 * 
 * @author $Author:$
 * @version $Rev:$ $Date:$
 */
public class TestCaseLogUtil {

	/**
	 * Prints the all testcases.
	 * 
	 * @param context the context
	 */
	public static void printAllTestcases(final ITestContext context) {

		System.out.println("SuiteName ==" + context.getSuite().getName());
		final ITestNGMethod[] allMethods = context.getAllTestMethods();
		Reporter.log(
				ColorUtil.style("--------------------------------------------", Color.FOREGROUND_RED, Style.NO_STYLE),
				true);
		Reporter.log(ColorUtil.style("Automation Test methods (" + allMethods.length + ")", Color.FOREGROUND_RED,
				Style.NO_STYLE), true);
		Reporter.log(
				ColorUtil.style("--------------------------------------------", Color.FOREGROUND_RED, Style.NO_STYLE),
				true);
		Reporter.log("", true);
		TreeMap<Integer, TestMethodDetails> testCaseMap = new TreeMap<Integer, TestMethodDetails>();
		int priority = 1;
		for (ITestNGMethod testNGMethod : allMethods) {
			TestMethodDetails testMethod = new TestMethodDetails();
			testMethod.setTestCaseName(testNGMethod.getMethodName());
			testMethod.setClassName(testNGMethod.getTestClass().getName());
			testCaseMap.put(priority, testMethod);
			priority++;
		}
		printGrid(context, testCaseMap);
	}

	/**
	 * Prints the grid.
	 *
	 * @param context     the context
	 * @param testCaseMap the test case map
	 */
	private static void printGrid(final ITestContext context, TreeMap<Integer, TestMethodDetails> testCaseMap) {

		FileUtil fileUtil = new FileUtil();
		Properties mproperties = new Properties();
		String suiteName = ParamUtil.getTestSuiteName();
		if (suiteName != null) {
			mproperties = fileUtil.getMethodNameOfProperty(suiteName);
		}
		String threadLine = "==================================================================================================================";
		try {
			Reporter.log("Test Case Grid", true);
			Reporter.log(threadLine, true);
			Reporter.log(
					"|   S.No.  |                   Test Case Name                               |           Test Case ID             |",
					true);
			Reporter.log(threadLine, true);
			Iterator<Entry<Integer, TestMethodDetails>> testCaseIterator = testCaseMap.entrySet().iterator();
			Integer serialNo = 1;
			while (testCaseIterator.hasNext()) {
				Entry<Integer, TestMethodDetails> pairs = testCaseIterator.next();
				TestMethodDetails testNgDetails = pairs.getValue();
				String testMethod = getTestMethodName(testNgDetails.getTestCaseName());
				String testCaseId = getTestCaseId(mproperties,
						testNgDetails.getClassName() + "#" + testNgDetails.getTestCaseName());

				Reporter.log("| " + StringUtil.addSpace(serialNo.toString(), 9) + "| "
						+ StringUtil.addSpace(testMethod, 63) + "| " + StringUtil.addSpace(testCaseId, 35) + "| ",
						true);
				serialNo++;
			}
			Reporter.log(threadLine, true);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * Gets the test case id.
	 * 
	 * @param props the props
	 * @param key   the key
	 * @return the test case id
	 */
	private static String getTestCaseId(Properties props, String key) {

		String caseId = null;
		if (props != null && props.get(key) != null) {
			caseId = props != null ? props.get(key).toString() : null;
		}
		return caseId != null ? "C" + caseId : "-";
	}

	/**
	 * Gets the test rail id.
	 * 
	 * @param testMethod the test method
	 * @return the test rail id
	 */
	public static String getTestMethodName(String testMethod) {

		if (testMethod != null && (testMethod.length() > 58)) {

			testMethod = testMethod.substring(0, 58).concat("..");
		}
		return testMethod;
	}
}

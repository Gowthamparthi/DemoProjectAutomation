package com.rallio.automation.common.html;


import java.util.*;

/**
 * The Class Rows.
 * 
 * @author $Author:$
 * @version $Rev:$ $Date:$
 */
public class Rows {

	private String value;
	private String style;
	private String rowspan;
	private List<Columns> column = new ArrayList<>();
	private LinkedList<Table> table;

	/**
	 * Gets the value.
	 * 
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * Sets the value.
	 * 
	 * @param value the new value
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * Gets the style.
	 * 
	 * @return the style
	 */
	public String getStyle() {
		return style;
	}

	/**
	 * Sets the style.
	 * 
	 * @param style the new style
	 */
	public void setStyle(String style) {
		this.style = style;
	}

	/**
	 * Gets the rowspan.
	 * 
	 * @return the rowspan
	 */
	public String getRowspan() {
		return rowspan;
	}

	/**
	 * Sets the rowspan.
	 * 
	 * @param rowspan the new rowspan
	 */
	public void setRowspan(String rowspan) {
		this.rowspan = rowspan;
	}	

	/**
	 * Gets the total colums.
	 * 
	 * @return the total colums
	 */
	public int getTotalColums() {
		return getColumn() != null ? getColumn().size() : 0;
	}

	/**
	 * Gets the column.
	 * 
	 * @return the column
	 */
	public List<Columns> getColumn() {
	    return column;
    }

	/**
	 * Sets the column.
	 * 
	 * @param column the new column
	 */
	public void setColumn(List<Columns> column) {
	    this.column = column;
    }

	/**
	 * Gets the table.
	 * 
	 * @return the table
	 */
	public LinkedList<Table> getTable() {
	    return table;
    }

	/**
	 * Sets the table.
	 * 
	 * @param table the new table
	 */
	public void setTable(LinkedList<Table> table) {
	    this.table = table;
    }
}

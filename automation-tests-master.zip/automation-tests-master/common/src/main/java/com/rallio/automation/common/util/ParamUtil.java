package com.rallio.automation.common.util;

import com.rallio.automation.common.enums.*;

import java.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class ParamUtil.
 */
public class ParamUtil {

	/**
	 * Gets the browser.
	 * 
	 * @return the browser
	 */
	public static String getBrowser() {

		return System.getProperty("browser");
	}

	/**
	 * Checks for browser param.
	 * 
	 * @return true, if successful
	 */
	public static boolean hasBrowserParam() {

		return getBrowser() != null && !getBrowser().isEmpty();
	}

	/**
	 * Gets the test suite name.
	 * 
	 * @return the test suite name
	 */
	public static String getTestSuiteName() {

		String tests = System.getProperty("tests");
		if (tests == null || tests.isEmpty()) {
			String javaCommand = System.getProperty("sun.java.command");
			if (javaCommand != null && !javaCommand.isEmpty()) {
				boolean iterateAndGet = false;
				String xmlPath = "";
				String[] arayValues = javaCommand.split(" ");
				for (String value : arayValues) {
					if (iterateAndGet) {
						xmlPath = value;
						break;
					}
					if (value != null && value.equalsIgnoreCase("-xmlpathinjar")) {
						iterateAndGet = true;
					}
				}
				if (xmlPath.contains("/")) {
					int slashIndex = xmlPath.lastIndexOf("/");
					xmlPath = xmlPath.substring(slashIndex + 1, xmlPath.length() - 4);
					tests = xmlPath;
				}
			}
		}
		return tests;
	}

	/**
	 * Gets the test env.
	 * 
	 * @return the test env
	 */
	public static String getTestEnv() {

		return System.getProperty("TestEnv");
	}

	/**
	 * Gets the log level.
	 * 
	 * @return the log level
	 */
	public static LogLevel getLogLevel() {

		final String logLevel = System.getProperty("logLevel");
		return logLevel == null ? LogLevel.HIGH : LogLevel.valueOf(logLevel.toUpperCase(Locale.getDefault()));
	}

	/**
	 * Checks if is quit terminal.
	 *
	 * @return true, if is quit terminal
	 */
	public static boolean isQuitTerminal() {

		final String noTerminal = System.getProperty("quitTerminal");
		if (noTerminal == null || noTerminal.isEmpty()) {
			return true;
		}
		return noTerminal != null && Boolean.valueOf(noTerminal);
	}

	/**
	 * Adds the timestamp.
	 *
	 * @return true, if successful
	 */
	public static boolean addTimestamp() {

		final String addTimestamp = System.getProperty("addTimestamp");
		return addTimestamp != null && Boolean.valueOf(addTimestamp);
	}

	public static boolean isSeleniumGrid() {

		final String seleniumGrid = System.getProperty("seleniumGrid");
		return seleniumGrid != null && Boolean.valueOf(seleniumGrid);
	}

	/**
	 * Gets the grid host.
	 *
	 * @return the grid host
	 */
	public static String getGridHost() {

		String gridHost = System.getProperty("gridHost");
		LogUtil.log("Grid Host : " + gridHost, LogLevel.HIGH);
		return gridHost;
	}


	/**
	 * Checks if is API implementation.
	 *
	 * @return true, if is API implementation
	 */
	public static boolean isAPIExecution() {

		String flag = System.getProperty("APIExecution");

		if (flag != null && !flag.isEmpty() && flag.equalsIgnoreCase("true")) {
			LogUtil.log("Executing via API." + flag, LogLevel.HIGH);
		}
		return flag != null && !flag.isEmpty() && Boolean.parseBoolean(flag);
	}

	/**
	 * Checks if is sauce labs.
	 *
	 * @return true, if is sauce labs
	 */
	public static boolean isSauceLabs() {
		 return Boolean.valueOf(System.getProperty("sauceLabs"));
	}

	/**
	 * Checks if is lamda.
	 *
	 * @return true, if is lamda
	 */
	public static boolean isLamda() {
		 return Boolean.valueOf(System.getProperty("lambda"));
	}
	
	/**
	 * Checks if is virtual.
	 *
	 * @return true, if is virtual
	 */
	public static boolean isVirtual() {
		return Boolean.valueOf(System.getProperty("isVirtual"));
	}

	/**
	 * Gets the mobile device name.
	 *
	 * @return the mobile device name
	 */
	public static String getPlatform() {
		return System.getProperty("platform");
	}

	/**
	 * Gets the mobile device regex.
	 *
	 * @return the mobile device regex
	 */
	public static String getMobileDeviceRegex() {
		return System.getProperty("deviceRegex");
	}
	
	/**
	 * Gets the mobile device version.
	 *
	 * @return the mobile device version
	 */
	public static String getMobileDeviceVersion() {
		return System.getProperty("deviceVersion");
	}
	
	/**
	 * Checks for start appium.
	 *
	 * @return true, if successful
	 */
	public static boolean hasStartAppium() {
		return Boolean.valueOf(System.getProperty("hasStartAppium"));
	}
	
	public static String getDevice() {
		return System.getProperty("device");
	}

	public static String getVersion() {
		return System.getProperty("version");
	}

	/**
	 * @return Module Name
	 */
	public static String getModuleName() {
		if (System.getProperty("module") == null) {
			return "";
		}
		return System.getProperty("module");
	}

}

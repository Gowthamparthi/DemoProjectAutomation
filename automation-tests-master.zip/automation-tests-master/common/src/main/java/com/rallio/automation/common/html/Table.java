package com.rallio.automation.common.html;


import java.util.LinkedList;

/**
 * The Class Table.
 * 
 * @author $Author:$
 * @version $Rev:$ $Date:$
 */
public class Table {

	private String style;
	private String border;
	private String width;
	private LinkedList<Rows> rows;

	/**
	 * Gets the style.
	 * 
	 * @return the style
	 */
	public String getStyle() {
		return style;
	}

	/**
	 * Sets the style.
	 * 
	 * @param style the new style
	 */
	public void setStyle(String style) {
		this.style = style;
	}

	/**
	 * Gets the border.
	 * 
	 * @return the border
	 */
	public String getBorder() {
		return border;
	}

	/**
	 * Sets the border.
	 * 
	 * @param border the new border
	 */
	public void setBorder(String border) {
		this.border = border;
	}

	/**
	 * Gets the width.
	 * 
	 * @return the width
	 */
	public String getWidth() {
		return width;
	}

	/**
	 * Sets the width.
	 * 
	 * @param width the new width
	 */
	public void setWidth(String width) {
		this.width = width;
	}

	/**
	 * Gets the rows.
	 * 
	 * @return the rows
	 */
	public LinkedList<Rows> getRows() {
		return rows;
	}

	/**
	 * Sets the rows.
	 * 
	 * @param rows the new rows
	 */
	public void setRows(LinkedList<Rows> rows) {
		this.rows = rows;
	}
}

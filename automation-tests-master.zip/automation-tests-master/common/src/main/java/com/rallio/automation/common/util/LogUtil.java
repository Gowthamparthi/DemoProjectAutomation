package com.rallio.automation.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Reporter;

import com.rallio.automation.common.enums.*;

/**
 * The Class LogUtil.
 */
public class LogUtil {

	/** The no of sections. */
	private static ThreadLocal<Integer> noOfSections = new ThreadLocal<Integer>();

	/** The no of steps. */
	private static ThreadLocal<Integer> noOfSteps = new ThreadLocal<Integer>();

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(LogUtil.class);

	/** The steps running. */
	private static ThreadLocal<Boolean> stepsRunning = new ThreadLocal<Boolean>();

	static {
		clear();
	}

	/**
	 * Log.
	 *
	 * @param s the s
	 * @param logLevel the log level
	 */
	public static void log(String s, final LogLevel logLevel) {

		if (ParamUtil.getLogLevel().getValue() >= logLevel.getValue()) {
			printSections(null, s);
			commonConsoleLog(s);
		}
	}

	/**
	 * Console log.
	 *
	 * @param s the s
	 * @param logLevel the log level
	 */
	public static void consoleLog(String s, final LogLevel logLevel) {

		String space = StringUtil.addIndent(stepsRunning.get() ? getNoOfSections() + 2 : getNoOfSections());
		LOGGER.info(new StringBuilder(space).append(s).toString());
	}

	/**
	 * Console log.
	 *
	 * @param s the s
	 * @param logLevel the log level
	 */
	public static void consoleLog(int s, final LogLevel logLevel) {

		String space = StringUtil.addIndent(stepsRunning.get() ? getNoOfSections() + 2 : getNoOfSections());
		LOGGER.info(new StringBuilder(space).append(s).toString());
	}

	/**
	 * Log.
	 * 
	 * @param logSection the log section
	 * @param s the s
	 */
	public static void log(LogSection logSection, String s) {

		printSections(logSection, s);
	}

	/**
	 * Log.
	 *
	 * @param steps the steps
	 * @param s the s
	 */
	public static void log(Steps steps, String s) {

		printSteps(steps, s);
	}

	/**
	 * Gets the no of sections.
	 * 
	 * @return the no of sections
	 */
	public static int getNoOfSections() {

		if (noOfSections.get() == null) {
			noOfSections.set(new Integer(0));
		}
		return noOfSections.get();
	}

	/**
	 * Sets the no of sections.
	 * 
	 * @param sections the new no of sections
	 */
	public static void setNoOfSections(int sections) {

		noOfSections.set(sections);
	}

	/**
	 * Gets the no of steps.
	 *
	 * @return the no of steps
	 */
	public static Integer getNoOfSteps() {

		if (noOfSteps.get() == null) {
			noOfSteps.set(new Integer(0));
		}
		return noOfSteps.get();
	}

	/**
	 * Sets the no of steps.
	 *
	 * @param steps the new no of steps
	 */
	public static void setNoOfSteps(Integer steps) {

		noOfSteps.set(steps);
	}

	/**
	 * Prints the steps.
	 *
	 * @param steps the steps
	 * @param log the log
	 */
	private static void printSteps(Steps steps, String log) {

		String space = StringUtil.addIndent(getNoOfSections() + 1);
		if (steps == Steps.START) {
			int currentStep = getNoOfSteps() + 1;
			stepsRunning.set(true);
			LOGGER.info(new StringBuilder(space).append("STEP  " + currentStep + " :" + log).toString());
			space = space.replaceAll(" ", "&nbsp;");
			Reporter.log(new StringBuilder(space)
			        .append("<font style=\"background-color:#ffff88\">STEP  " + currentStep + " :" + log + "</font>").toString());
			space = StringUtil.addIndent(getNoOfSections() + 2);
			space = space.replaceAll(" ", "&nbsp;");
			setNoOfSteps(getNoOfSteps() + 1);
		} else if (steps == Steps.END) {
			stepsRunning.set(false);
			LOGGER.info(new StringBuilder(space).append(log).toString());
			LOGGER.info("");
			space = space.replaceAll(" ", "&nbsp;");
			Reporter.log(new StringBuilder(space).append(log).toString());
			Reporter.log("");
		}
	}

	/**
	 * Clear.
	 */
	public static void clear() {

		noOfSections.set(new Integer(0));
		noOfSteps.set(new Integer(0));
		stepsRunning.set(false);
	}

	/**
	 * Prints the in html.
	 *
	 * @param logSection the log section
	 * @param log the log
	 */
	private static void printSections(LogSection logSection, String log) {

		String space = StringUtil.addIndent(getNoOfSections());

		if (logSection == LogSection.START) {
			LOGGER.info(new StringBuilder(space).append(log).toString());
			LOGGER.info(new StringBuilder(space).append(StringUtil.addUnderline(log.length())).toString());
			space = space.replaceAll(" ", "&nbsp;");
			Reporter.log(new StringBuilder(space).append("<b>" + log + "</b>").toString(), false);
			Reporter.log(new StringBuilder(space).append(StringUtil.addUnderline(log.length())).toString(), false);
			setNoOfSections(getNoOfSections() + 1);
		} else if (logSection == LogSection.END) {
			setNoOfSections(getNoOfSections() - 1);
			space = StringUtil.addIndent(getNoOfSections());
			LOGGER.info(new StringBuilder(space).append(log).toString());
			LOGGER.info(new StringBuilder(space).append(StringUtil.addUnderline(log.length())).toString());
			space = space.replaceAll(" ", "&nbsp;");
			Reporter.log(new StringBuilder(space).append("<b>" + log + "</b>").toString(), false);
			Reporter.log(new StringBuilder(space).append(StringUtil.addUnderline(log.length())).toString(), false);
		}
	}

	/**
	 * Common console log.
	 *
	 * @param log the log
	 */
	public static void commonConsoleLog(String log) {

		if (stepsRunning == null || stepsRunning.get() == null) {
			stepsRunning.set(false);
		}
		String space = StringUtil.addIndent(stepsRunning.get() ? getNoOfSections() + 2 : getNoOfSections());
		LOGGER.info(new StringBuilder(space).append(StringUtil.changeHtmlToPlain(log)).toString());
		space = space.replaceAll(" ", "&nbsp;");
		Reporter.log(new StringBuilder(space).append(log).toString(), false);
	}

	/**
	 * Debug log.
	 *
	 * @param log the log
	 */
	public static void debugLog(String log) {

		if (stepsRunning == null || stepsRunning.get() == null) {
			stepsRunning.set(false);
		}
		String space = StringUtil.addIndent(stepsRunning.get() ? getNoOfSections() + 2 : getNoOfSections());
		LOGGER.info(new StringBuilder(space).append(StringUtil.changeHtmlToPlain(log)).toString());
	}

	/**
	 * Common end console log.
	 *
	 * @param log the log
	 */
	public static void commonEndConsoleLog(String log) {

		LOGGER.info(new StringBuilder(StringUtil.changeHtmlToPlain(log)).toString());
	}
}
package com.rallio.automation.common.util;

import java.util.*;
import java.util.Objects;
import java.util.concurrent.*;
import java.util.stream.*;

import org.apache.commons.lang3.*;
import org.openqa.selenium.*;

import com.google.common.base.*;
import com.rallio.automation.common.enums.*;

// TODO: Auto-generated Javadoc
/**
 * The Class StringUtil.
 * 
 * @author $Author:$
 * @version $Rev:$ $Date:$
 */
public class StringUtil {

	/**
	 * Adds the space.
	 * 
	 * @param word the word
	 * @param noOfCharac the no of charac
	 * @return the string
	 */
	public static String addSpace(String word, int noOfCharac) {

		int wordLength = word.length();
		int noOfSpace = noOfCharac - wordLength;
		if (noOfSpace < 0) {
			return word;
		} else {
			String space = "";
			for (int val = 0; val < noOfSpace; val++) {
				space += " ";
			}
			word = word + space;
		}
		return word;
	}

	/**
	 * Adds the indent.
	 *
	 * @param indentLevel the indent level
	 * @return the string
	 */
	public static String addIndent(int indentLevel) {

		indentLevel += indentLevel;
		final StringBuilder space = new StringBuilder("");
		for (int i = 0; i < indentLevel; i++) {
			space.append("  ");
		}
		return space.toString();
	}

	/**
	 * Adds the underline to log statements.
	 * 
	 * @param indentLevel the indent level
	 * @return the string
	 */
	public static String addUnderline(final int indentLevel) {

		final StringBuilder space = new StringBuilder("");
		for (int i = 0; i < indentLevel; i++) {
			space.append('-');
		}
		return space.toString();
	}

	/**
	 * Change html to plain.
	 *
	 * @param text the text
	 * @return the string
	 */
	public static String changeHtmlToPlain(final String text) {

		String plainText = text.replaceAll("\\<.*?\\>", "");
		return plainText;
	}

	/**
	 * Checks if is null or white space.
	 *
	 * @param string the string
	 * @return true, if is null or white space
	 */
	public static boolean isNullOrWhiteSpace(final String string) {

		try {
			return Strings.isNullOrEmpty(string) && string.trim().isEmpty();
		} catch (NullPointerException npe) {
			return Strings.isNullOrEmpty(string);
		}
	}

	/**
	 * Checks for value.
	 *
	 * @param string the string
	 * @return true, if successful
	 */
	public static boolean hasProperValue(final String string) {

		try {
			return !Strings.isNullOrEmpty(string) && !string.equalsIgnoreCase("null") && !string.trim().isEmpty() && string.trim().length() > 0;
		} catch (NullPointerException npe) {
			return false;
		}
	}

	/**
	 * Checks for proper required value.
	 *
	 * @param string the string
	 * @param requiredValues the required values
	 * @return true, if successful
	 */
	public static boolean hasProperRequiredValueInList(final String string, List<String> requiredValues) {

		try {
			return !Strings.isNullOrEmpty(string) && !string.equalsIgnoreCase("null") && !string.trim().isEmpty() && string.trim().length() > 0
			        && requiredValues.stream().anyMatch(x -> x.equalsIgnoreCase(string));
		} catch (NullPointerException npe) {
			return false;
		}
	}

	/**
	 * Format get parameter.
	 *
	 * @param param the param
	 * @return the string
	 */
	public static String formatGetParameter(Map<String, Object> param) {

		StringBuilder result = new StringBuilder();

		for (String key : param.keySet()) {

			if (result.length() > 0) {
				result.append("&");
			}

			result.append(key + "=" + param.get(key).toString());
		}

		return result.toString();
	}

	/**
	 * Gets the digits from string.
	 *
	 * @param s the s
	 * @return the digits from string
	 */
	public static int getDigitsFromString(String s) {

		return Integer.parseInt(CharMatcher.digit().retainFrom(s));
	}

	/**
	 * Gets the digits from string.
	 *
	 * @param list the list
	 * @return the digits from string
	 */
	public static List<Integer> getDigitsFromString(List<String> list) {

		return list.parallelStream().map(StringUtil::getDigitsFromString).collect(Collectors.toList());
	}

	/**
	 * Gets the digits from web elements.
	 *
	 * @param list the list
	 * @return the digits from web elements
	 */
	public static List<Integer> getDigitsFromWebElements(List<WebElement> list) {

		return getTextFromWebElements(list).parallelStream().map(StringUtil::getDigitsFromString).collect(Collectors.toList());
	}

	/**
	 * Gets the text from web elements.
	 *
	 * @param source the source
	 * @return the text from web elements
	 */
	public static List<String> getTextFromWebElements(List<WebElement> source) {

		return source.stream().map(WebElement::getText).collect(Collectors.toList());
	}

	/**
	 * Gets the text from web elements.
	 *
	 * @param source the source
	 * @return the text from web elements
	 */
	public static String getTextFromWebElements(WebElement source) {

		return Objects.nonNull(source) ? source.getText() : StringUtils.EMPTY;
	}

	/**
	 * Gets the word from string line.
	 *
	 * @param string the string
	 * @param startIndex the start index
	 * @param endIndex the end index
	 * @return the word from string line
	 */
	public static String getWordFromStringLine(String string, int startIndex, int endIndex) {

		String formattedString = string.substring(startIndex, endIndex);
		return formattedString;
	}

	/**
	 * Gets the word from string line.
	 *
	 * @param string the string
	 * @param index the index
	 * @return the word from string line
	 */
	public static String getWordFromStringLine(String string, int index) {

		String formattedString = string.substring(index);
		return formattedString;
	}

	/**
	 * Gets the text from string based on delimiter.
	 *
	 * @param string the string
	 * @param startingDelimiter the starting delimiter
	 * @param endingDelimiter the ending delimiter
	 * @return the text from string based on delimiter
	 */
	public static String getTextFromStringBasedOnStartingAndEndingDelimiters(String string, char startingDelimiter, char endingDelimiter) {

		return string.substring(string.indexOf(startingDelimiter) + 1, string.lastIndexOf(endingDelimiter));
	}

	/**
	 * Gets the text from string based on starting delimiters alone.
	 *
	 * @param string the string
	 * @param startingDelimiter the starting delimiter
	 * @return the text from string based on starting delimiters alone
	 */
	public static String getTextFromStringBasedOnStartingDelimitersAlone(String string, String startingDelimiter) {

		return string.substring(string.indexOf(startingDelimiter));
	}

	/**
	 * Gets the text from string based on ending delimiters alone.
	 *
	 * @param string the string
	 * @param endingDelimiter the ending delimiter
	 * @return the text from string based on ending delimiters alone
	 */
	public static String getTextFromStringBasedOnEndingDelimitersAlone(String string, String endingDelimiter) {

		return string.substring(0, string.lastIndexOf(endingDelimiter));
	}

	/**
	 * Gets the random generated string with random number appended.
	 *
	 * @param text the text
	 * @return the random generated string with random number appended
	 */
	public static String getRandomGeneratedStringWithRandomNumberAppended(String text) {

		return text + ThreadLocalRandom.current().nextInt(0, 99) + System.nanoTime();
	}

	/**
	 * Gets the random generated number.
	 *
	 * @return the random generated number
	 */
	public static String getRandomGeneratedNumber() {

		Long num = ThreadLocalRandom.current().nextInt(0, 99) + System.nanoTime();
		return num.toString();
	}
	
	/**
	 * Gets the random numeric number.
	 *
	 * @return the random numeric number
	 */
	public static String getRandomNumericNumber() {
		
		String randomNumber = String.valueOf(System.currentTimeMillis());
		return randomNumber;
	}

	/**
	 * Convert string to integer.
	 *
	 * @param text the text
	 * @return the int
	 */
	public static int convertStringToInteger(String text) {

		return Integer.parseInt(text);
	}

	/**
	 * Adds the two numbers and convert to string.
	 *
	 * @param num1 the num 1
	 * @param num2 the num 2
	 * @return the string
	 */
	public static String addTwoNumbersAndConvertToString(int num1, int num2) {

		return String.valueOf(num1 + num2);
	}

	/**
	 * Checks if is number present in string.
	 *
	 * @param text the text
	 * @return true, if is number present in string
	 */
	public static boolean isNumberPresentInString(String text) {

		LogUtil.log("Text present in Element :" + text, LogLevel.LOW);
		return text.matches(".*\\d.*");
	}

	/**
	 * Verify regex pattern.
	 *
	 * @param strings the strings
	 * @return true, if successful
	 */
	public static boolean verifyRegexPattern(String... strings) {

		boolean status = false;
		for (String string : strings) {
			status = string.matches("[0-9]+(,[0-9]+)*");
			LogUtil.log("Verify whether String displayed is of Number format seperated by comma ?", LogLevel.LOW);
			if (status == false) {
				LogUtil.log("Given String '" + string + "' is not of Number format", LogLevel.LOW);
				return false;
			}
		}
		return status;
	}

	/**
	 * Verify alphanumeric string.
	 *
	 * @param text the text
	 * @return true, if successful
	 */
	public static boolean verifyAlphanumericString(String text) {

		boolean value = false;
		if (text.matches("[a-zA-Z]+"))
			value = false;
		else if (text.matches("[0-9]+"))
			value = false;
		else if (text.matches("[a-zA-Z0-9]+"))
			value = true;
		return value;
	}

	/**
	 * Gets the string with specific characters deleted.
	 *
	 * @param text the text
	 * @param startIndex the start index
	 * @param endIndex the end index
	 * @return the string with specific characters deleted
	 */
	public static String getStringWithSpecificCharactersDeleted(String text, int startIndex, int endIndex) {

		StringBuilder sb = new StringBuilder(text);
		String formattedText = new String(sb.delete(startIndex, endIndex));
		return formattedText;
	}

	public static String generateRandomMobileNumber() {
		StringBuilder mobileNumber = new StringBuilder();
		Random random = new Random();
		for (int i = 0; i <= 9; i++) {
			mobileNumber.append(random.nextInt(10));
		}
		return mobileNumber.toString();
	}
}

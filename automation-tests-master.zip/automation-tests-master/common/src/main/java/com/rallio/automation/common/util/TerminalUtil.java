package com.rallio.automation.common.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

/**
 * The Class TerminalUtil.
 */
public class TerminalUtil {

	/**
	 * Execute.
	 *
	 * @param command the command
	 * @return the string
	 */
	public static String execute(String command) {

		StringBuilder sb = new StringBuilder();
		String[] commands = new String[] { "/bin/sh", "-c", command };
		try {
			Process proc = new ProcessBuilder(commands).start();
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));

			BufferedReader stdError = new BufferedReader(new InputStreamReader(proc.getErrorStream()));

			String s = null;
			while ((s = stdInput.readLine()) != null) {
				sb.append(s);
				sb.append("\n");
			}
			while ((s = stdError.readLine()) != null) {
				sb.append(s);
				sb.append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sb.toString();
	}

	/**
	 * Run commands.
	 *
	 * @param commands the commands
	 * @return the string[]
	 */
	public static String[] runCommands(final List<String> commands) {

		String[] cmdOutput = null;
		String line = null;
		try {
			final ProcessBuilder process = new ProcessBuilder(commands);
			final Process processOutput = process.start();
			final InputStreamReader reader = new InputStreamReader(processOutput.getInputStream());
			final BufferedReader bufferedReader = new BufferedReader(reader);
			final StringBuilder builder = new StringBuilder();
			while ((line = bufferedReader.readLine()) != null) {
				builder.append(line).append('\n');
			}
			cmdOutput = builder.toString().split("\n");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cmdOutput;
	}

	/**
	 * Convert list to array.
	 *
	 * @param arrayGoals the array goals
	 * @return the string[]
	 */
	private static String[] convertListToArray(List<String> arrayGoals) {

		String[] arrayVal = new String[arrayGoals.size()];
		for (int i = 0; i < arrayGoals.size(); i++) {
			arrayVal[i] = arrayGoals.get(i);
		}
		return arrayVal;
	}
}

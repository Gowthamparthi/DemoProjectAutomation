package com.rallio.automation.core.manager;

import org.apache.commons.lang3.SystemUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.safari.*;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.rallio.automation.common.enums.*;
import com.rallio.automation.common.util.*;
import com.rallio.automation.core.browser.*;
import com.rallio.automation.core.listener.*;

/**
 * The Class DriverManager.
 * 
 * @author $Author:$
 * @version $Rev:$ $Date:$
 */
public class DriverManager {


	/** The web driver thread. */
	private static ThreadLocal<EventFiringWebDriver> webDriverThread = new ThreadLocal<EventFiringWebDriver>();

	/**
	 * Inits the driver.
	 */
	public static void initializeDriver() {

		String browser = ParamUtil.getBrowser();
		initializeDriver(browser);

	}

	/**
	 * Initialize driver.
	 * 
	 * @param browser the browser
	 */
	public static void initializeDriver(final String browser) {

		final WebDriver webDriver = getBrowserDriver(browser);
		registerDriver(webDriver);
	}

	/**
	 * Gets the browser driver.
	 * 
	 * @param browser the browser
	 * @return the browser driver
	 */
	public static WebDriver getBrowserDriver(final String browser) {

		WebDriver webDriver = null;
		switch (browser) {
		case "firefox":
			webDriver = FirefoxBrowser.createDriver();
			break;
		case "chrome":
			if (SystemUtils.IS_OS_LINUX) {
				LogUtil.log("Chrome Driver for Linux ", LogLevel.HIGH);
				webDriver = ChromeBrowser.createDriver();
			} else {
				webDriver = ChromeBrowser.createDriver();
			}
		break;
		case "edge":
			webDriver = MicrosoftEdgeBrowser.createDriver();
			break;
		case "safari":
			webDriver = new SafariDriver();
			break;
		default:
			break;
		}
		PageUtil.maximizeWindows(webDriver);
		return webDriver;
	}

	/**
	 * Register driver.
	 * 
	 * @param webDriver the web driver
	 */
	public static void registerDriver(final WebDriver webDriver) {

		LogUtil.log("Registering Driver ", LogLevel.HIGH);
		final EventListener eventListener = new EventListener();
		final EventFiringWebDriver efd = new EventFiringWebDriver(webDriver);
		efd.register(eventListener);
		webDriverThread.set(efd);
		LogUtil.log(" Driver registered " + webDriverThread.get(), LogLevel.HIGH);

	}

	/**
	 * Close.
	 */
	public static void reload() {

		if (getDriver() != null) {
			String url = getDriver().getCurrentUrl();
			getDriver().get(url);
			WaitUtil.waitUntil(10);
		}
	}

	/**
	 * Close.
	 */
	public static void close() {

		if (getDriver() != null) {
			close(getDriver());
		}
	}

	/**
	 * Close.
	 * 
	 * @param webDriver the web driver
	 */
	public static void close(final WebDriver webDriver) {

		webDriver.manage().deleteAllCookies();
		webDriver.quit();
	}

	/**
	 * Gets the driver.
	 * 
	 * @return the driver
	 */
	public static EventFiringWebDriver getDriver() {

		return webDriverThread != null ? webDriverThread.get() : null;
	}

	/**
	 * Gets the web driver.
	 * 
	 * @return the web driver
	 */
	public static WebDriver getWebDriver() {

		return getDriver().getWrappedDriver();
	}

	/**
	 * Gets the loaded URL.
	 *
	 * @return the loaded URL
	 */
	public static String getLoadedURL() {

		return getDriver().getCurrentUrl();
	}
}

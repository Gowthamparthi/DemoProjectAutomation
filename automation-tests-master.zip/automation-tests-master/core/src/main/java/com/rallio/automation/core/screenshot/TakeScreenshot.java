package com.rallio.automation.core.screenshot;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.rallio.automation.common.enums.*;
import com.rallio.automation.common.util.*;
import com.rallio.automation.core.manager.*;

/**
 * The Class TakeScreenshot.
 * 
 * @author $Author:$
 * @version $Rev:$ $Date:$
 */
public class TakeScreenshot {

	/**
	 * Take screenshot.
	 * 
	 * @param fileName the file name
	 */
	public static void takeScreenshot(String fileName) {

		try {

			WebDriver driver = null;
			driver = DriverManager.getDriver();
			LogUtil.log("Driver object " + driver, LogLevel.LOW);
			final Path screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE).toPath();
			final Path screenShotDir = getTargetScreenshotPath(fileName);
			Files.copy(screenshot, screenShotDir, StandardCopyOption.REPLACE_EXISTING);
			LogUtil.log("Screenshot taken "+fileName+" File path: "+screenShotDir.toString(), LogLevel.LOW);
		} catch (Exception ex) {
			LogUtil.log("Excpetion in taking screenshot. " + ex, LogLevel.LOW);
		}

	}

	/**
	 * Gets the target screenshot path.
	 * 
	 * @param fileName the file name
	 * @return the target screenshot path
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private static Path getTargetScreenshotPath(final String fileName) throws IOException {

		final String dir = System.getProperty("user.dir");
		final Path baseDir = Paths.get(dir, fileName);
		Files.createDirectories(baseDir);
		return baseDir;
	}
}

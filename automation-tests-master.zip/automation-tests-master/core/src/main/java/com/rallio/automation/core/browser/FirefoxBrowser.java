package com.rallio.automation.core.browser;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.rallio.automation.common.enums.*;
import com.rallio.automation.common.util.*;


/**
 * The Class FirefoxBrowser.
 */
@SuppressWarnings("deprecation")
public class FirefoxBrowser {
	
	/**
	 * Creates the driver.
	 *
	 * @return the web driver
	 */
	public static WebDriver createDriver() {

	/*
			DesiredCapabilities caps = DesiredCapabilities.firefox();
			caps.setBrowserName("firefox");
			try {
	            return new RemoteWebDriver(new URL("http://"+ParamUtil.getGridHost()+":4444/wd/hub"), caps);
            } catch (MalformedURLException e) {	           
	            e.printStackTrace();
            }
		*/
		
		DesiredCapabilities dc= DesiredCapabilities.firefox();
		
		dc.setCapability("applicationCacheEnabled", true);
		FirefoxProfile profile = firefoxProfile();
		profile.setPreference("browser.cache.disk.enable", true); 
		profile.setPreference("browser.cache.memory.enable", true); 
		profile.setPreference("browser.cache.offline.enable", true); 
		profile.setPreference("network.http.use-cache", true); 
		dc.setCapability(FirefoxDriver.PROFILE, profile);
		
		System.setProperty(FirefoxDriver.SystemProperty.DRIVER_USE_MARIONETTE,"true");
		WebDriver driver = new FirefoxDriver();
		return driver;
	}

	/**
	 * Firefox profile.
	 *
	 * @return the firefox profile
	 */
	@SuppressWarnings("unused")
    private static FirefoxProfile firefoxProfileOld() {

		String downloadPath = getFilePath();
		FirefoxProfile fprofile = new FirefoxProfile();
		fprofile.setPreference("browser.download.dir", downloadPath);
		fprofile.setPreference("browser.download.folderList", 2);
		fprofile.setPreference(
		        "browser.helperApps.neverAsk.saveToDisk",
		        "text/csv,application/x-msexcel,application/excel,application/x-excel,application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml");
		fprofile.setPreference("browser.download.manager.showWhenStarting", false);
		return fprofile;
	}
	
	@SuppressWarnings("deprecation")
	private static FirefoxProfile firefoxProfile() {

		String downloadPath = getFilePath();		
		ProfilesIni profile = new ProfilesIni();
		FirefoxProfile firefoxProfile = profile.getProfile("AutomationProfile");
		if(firefoxProfile==null)
		{
			firefoxProfile = new FirefoxProfile();
		}
		
		firefoxProfile.setPreference("browser.cache.disk.enable", true);
		firefoxProfile.setPreference("browser.cache.memory.enable", true);
		firefoxProfile.setPreference("browser.cache.memory.capacity", -1);
		
		firefoxProfile.setPreference("browser.download.folderList", 2);
		firefoxProfile.setPreference("browser.download.manager.showWhenStarting", false);
		firefoxProfile.setPreference("browser.download.dir", downloadPath);
		firefoxProfile.setPreference(
		        "browser.helperApps.neverAsk.saveToDisk",
		        "text/csv,application/x-msexcel,application/excel,application/pdf,application/x-excel,application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml,application/octet-stream");		
		firefoxProfile.setPreference("pdfjs.disabled", true);

		// Use this to disable Acrobat plugin for previewing PDFs in Firefox (if
		// you have Adobe reader installed on your computer)
		firefoxProfile.setPreference("plugin.scan.Acrobat", "99.0");
		firefoxProfile.setPreference("plugin.scan.plid.all", false);
		
		

		return firefoxProfile;
	}


	/**
	 * Gets the file path.
	 *
	 * @return the file path
	 */
	public static String getFilePath() {

		String downloadPath = "";
		try {
			File downloadFile = new File("");
			downloadPath = downloadFile.getAbsolutePath();
			downloadPath = downloadPath + File.separator +"testresult";
		} catch (Exception ex) {
			ex.printStackTrace();
			LogUtil.log("Error in reading file path ", LogLevel.HIGH);
		}
		return downloadPath;
	}
}

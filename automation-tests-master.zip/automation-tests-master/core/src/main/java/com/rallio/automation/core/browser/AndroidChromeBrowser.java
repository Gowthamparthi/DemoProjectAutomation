package com.rallio.automation.core.browser;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.rallio.automation.common.enums.LogLevel;
import com.rallio.automation.common.util.LogUtil;

// TODO: Auto-generated Javadoc
/**
 * The Class AndroidChromeBrowser.
 */
public class AndroidChromeBrowser {

	/**
	 * Creates the driver.
	 *
	 * @return the web driver
	 */
	public static WebDriver createDriver() {

		ChromeOptions chromeOptions = new ChromeOptions();

		chromeOptions.setExperimentalOption("androidPackage", "com.android.chrome");

		chromeOptions.setExperimentalOption("androidDeviceSerial", getDeviceId()[0]);

		return new ChromeDriver(chromeOptions);

	}

	

	/**
	 * Gets the device id.
	 *
	 * @return the device id
	 */
	private static String[] getDeviceId() {

		List<String> commands = new ArrayList<String>();

		String[] deviceId;

		commands.add("adb");

		commands.add("devices");

		String[] devices = runCommands(commands);

		deviceId = new String[devices.length - 1];

		for (int i = 1; i < devices.length; i++) {

			deviceId[i - 1] = devices[i].split("\t")[0].trim();

		}

		return deviceId;

	}

	
	/**
	 * Run commands.
	 *
	 * @param commands the commands
	 * @return the string[]
	 */
	private static String[] runCommands(final List<String> commands) {

		String[] cmdOutput = null;

		String line = null;

		try {

			final ProcessBuilder process = new ProcessBuilder(commands);

			final Process processOutput = process.start();

			final InputStreamReader reader = new InputStreamReader(processOutput.getInputStream());

			final BufferedReader bufferedReader = new BufferedReader(reader);

			final StringBuilder builder = new StringBuilder();

			while ((line = bufferedReader.readLine()) != null) {

				builder.append(line).append('\n');

			}

			cmdOutput = builder.toString().split("\n");

		} catch (Exception e) {

			LogUtil.log(
					new StringBuilder("Exception in running ProcessBuilder Commands, Error : ").append(e.getMessage())

							.toString(),
					LogLevel.HIGH);

		}

		return cmdOutput;

	}
}

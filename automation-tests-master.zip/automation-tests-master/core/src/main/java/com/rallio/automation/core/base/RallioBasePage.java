package com.rallio.automation.core.base;

import org.openqa.selenium.*;

import com.rallio.automation.common.adapter.*;

// TODO: Auto-generated Javadoc
/**
 * The Class CP8BasePage.
 */
public abstract class RallioBasePage {

	/** The driver. */
	protected WebDriver driver;

	/** The pageAdapter. */
	protected PageAdapter pageAdapter;

	/**
	 * Instantiates a new CP 8 base page.
	 *
	 * @param driver the driver
	 */
	public RallioBasePage(WebDriver driver) {

		this.driver = driver;
		this.pageAdapter = PageAdapter.getInstance(driver);
	}

	/**
	 * Instantiates a new CP 8 base page.
	 *
	 * @param driver the driver
	 * @param pageAdapter the page adapter
	 */
	public RallioBasePage(WebDriver driver, Boolean pageAdapter) {

		this.driver = driver;
		if (pageAdapter) {
			this.pageAdapter = PageAdapter.reset(driver);
		}

	}

	/**
	 * Gets the driver.
	 *
	 * @return the driver
	 */
	protected WebDriver getDriver() {

		return driver;
	}

	/**
	 * Checks if is page load.
	 *
	 * @return true, if is page load
	 */
	public abstract boolean isPageLoad();

	/**
	 * Gets the validation page.
	 *
	 * @param <T> the generic type
	 * @return the validation page
	 */
	public abstract <T> T getValidationPage();


	/**
	 * Fill text box value for supplied parameter.
	 *
	 * @param by the by
	 * @param value the value
	 * @param doAssert the do assert
	 */

}
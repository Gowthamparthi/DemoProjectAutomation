package com.rallio.automation.core.browser;

import org.openqa.selenium.*;
import org.openqa.selenium.edge.*;

// TODO: Auto-generated Javadoc
/**
 * The Class MicrosoftEdgeBrowser.
 */
public class MicrosoftEdgeBrowser {

	/**
	 * Creates the driver.
	 *
	 * @return the web driver
	 */
	public static WebDriver createDriver() {

		WebDriver driver = new EdgeDriver();
		return driver;
	}
}

package com.rallio.automation.core.manager;

import org.apache.commons.lang3.SystemUtils;
import org.openqa.selenium.WebDriver;

import com.rallio.automation.common.enums.LogLevel;
import com.rallio.automation.common.util.LogUtil;
import com.rallio.automation.common.util.PageUtil;
import com.rallio.automation.common.util.ParamUtil;
import com.rallio.automation.core.browser.AndroidChromeBrowser;
import com.rallio.automation.core.browser.ChromeBrowser;
import com.rallio.automation.core.browser.FirefoxBrowser;

import io.appium.java_client.AppiumDriver;


public class MobileDriverManager {

	/** The web driver thread. */
	private static ThreadLocal<WebDriver> webDriverThread = new ThreadLocal<WebDriver>();
	
	public static void initializeDriver() {

		String browser = ParamUtil.getBrowser();
		initializeDriver(browser);		
	}
	
	/**
	 * Initialize driver.
	 * 
	 * @param browser the browser
	 */
	public static void initializeDriver(final String browser) {

		final WebDriver webDriver = getBrowserDriver(browser);
		LogUtil.log("Web Driver : " + webDriver, LogLevel.HIGH);
		registerDriver(webDriver);		
	}
	
	public static WebDriver getBrowserDriver(String browser) {
		LogUtil.log("Browser : " + browser, LogLevel.HIGH);
		browser = browser.trim().toLowerCase();
		WebDriver webDriver = null;
		switch (browser) {
		case "firefox":
			webDriver = FirefoxBrowser.createDriver();
			PageUtil.maximizeWindows(webDriver); 
			break;
		case "chrome":
			if (SystemUtils.IS_OS_LINUX) {
				LogUtil.log("Chrome Driver for Linux ", LogLevel.HIGH);
				//System.setProperty("webdriver.chrome.driver", "/home/batuser/Downloads/chromeDriver/chromedriver");
				webDriver = ChromeBrowser.createDriver();
			} else {
				LogUtil.log("Create Chrome Driver", LogLevel.HIGH);
				webDriver = ChromeBrowser.createDriver();
			}
			PageUtil.maximizeWindows(webDriver); 
			break;
		case "android":
			webDriver = AndroidChromeBrowser.createDriver();
			break;
		default:
			break;
		}
		return webDriver;
	}
	
	/**
	 * Register driver.
	 * 
	 * @param webDriver the web driver
	 */
	public static void registerDriver(final WebDriver webDriver) {

		LogUtil.log("Registering Driver ", LogLevel.HIGH);	
		webDriverThread = new ThreadLocal<WebDriver>();
		webDriverThread.set(webDriver);
	}
	
	/**
	 * Gets the driver.
	 * 
	 * @return the driver
	 */
	public static WebDriver getDriver() {

		return webDriverThread != null ? webDriverThread.get() : null;
	}
	
	public static AppiumDriver getAppiumDriver() {

		return webDriverThread != null ? (AppiumDriver)webDriverThread.get() : null;
	}
	
	
	public static void close() {
		
		webDriverThread.get().quit();
		webDriverThread = new ThreadLocal<WebDriver>();
	}
	
}
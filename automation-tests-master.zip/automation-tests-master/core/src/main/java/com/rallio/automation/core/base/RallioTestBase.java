package com.rallio.automation.core.base;

import static com.rallio.automation.common.manager.ConfigManager.*;

import org.testng.*;
import org.testng.annotations.*;

import com.rallio.automation.common.enums.*;
import com.rallio.automation.common.util.*;
import com.rallio.automation.core.manager.*;

// TODO: Auto-generated Javadoc
/**
 * The Class RalioTestBase.
 */
public class RallioTestBase {

	/**
	 * Sets the up before.
	 *
	 * @param context the new up before
	 */
	@BeforeTest()
	public void setupBeforeTest(final ITestContext context) {

		LogUtil.log("Before Test", LogLevel.LOW);
		TestCaseLogUtil.printAllTestcases(context);
		String env = System.getProperty("env");
		String account = System.getProperty("account");
		loadConfigPropertiesFile(env, account);
		DriverManager.initializeDriver();
		LogUtil.log("Running Tests In '" + env + "' with '" + account + "' Account", LogLevel.LOW);
		loadRallioActivateSite(getValue("user.loginUrl"));
	}

	/**
	 * Load config properties file.
	 *
	 * @param env the env
	 * @param account the account
	 */
	public void loadConfigPropertiesFile(String env, String account) {

		switch (env) {

		case "stg":
			String fileName = "rallioActivate-stg";
			switch (account) {
			case "BeanMeUp":
				// fileName = "ralioactivate-stg.properties";
				break;

			case "BeanMeDown":
				fileName += "-BeanMeDown";
				break;

			case "BeanMeUpChicago":
				fileName += "-BeanMeUpChicago";
				break;

			case "BeanMeUpLA":
				fileName += "-BeanMeUpLA";
				break;

			case "BeanMeUpNorCal":
				fileName += "-BeanMeUpNorCal";
				break;

			case "BeanMeUpPortland":
				fileName += "-BeanMeUpPortland";
				break;

			case "BeanMeUpSF":
				fileName += "-BeanMeUpSF";
				break;

			case "BeanMeUpSoCal":
				fileName += "-BeanMeUpSoCal";
				break;

			default:
				LogUtil.log("Invalid Environment parameter specified. No config file loaded", LogLevel.LOW);
				break;
			}
			loadConfig(fileName + ".properties");
			break;

		case "prod":
			loadConfig("ralioactivate-prod.properties");
			break;

		default:
			LogUtil.log("Invalid Environment parameter specified. No config file loaded", LogLevel.LOW);
			break;
		}
	}

	/**
	 * Load URL.
	 * 
	 * @param url the url
	 */
	public void loadRallioActivateSite(String url) {

		LogUtil.log(Steps.START, "Load URL:" + url);
		DriverManager.getDriver().get(url);
	}

	/**
	 * Close browser.
	 */
	@AfterTest(alwaysRun = true)
	public void AfterTest() {

		DriverManager.getDriver().quit();
	}

}

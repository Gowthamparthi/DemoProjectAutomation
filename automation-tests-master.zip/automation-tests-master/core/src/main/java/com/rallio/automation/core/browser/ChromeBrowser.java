package com.rallio.automation.core.browser;

import com.rallio.automation.common.enums.*;
import com.rallio.automation.common.util.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.remote.*;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * The Class ChromeBrowser.
 */
public class ChromeBrowser {

	/**
	 * Creates the driver.
	 *
	 * @return the web driver
	 */
	public static WebDriver createDriver() {

		String downloadFilepath = getFilePath();

		WebDriver driver = null;

		HashMap<String, Object> preferences = new HashMap<String, Object>();
		preferences.put("plugins.always_open_pdf_externally", "true");
		preferences.put("download.default_directory", downloadFilepath);
		preferences.put("profile.default_content_settings.popups", 0);
		preferences.put("download.prompt_for_download", "false");
		preferences.put("browser.helperApps.neverAsk.saveToDisk",
		        "text/csv,application/x-msexcel,application/excel,application/pdf,application/x-excel,application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml,application/octet-stream");
		preferences.put("profile.default_content_setting_values.notifications", 2);
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("--no-sandbox");
		chromeOptions.addArguments("--disable-gpu");
		chromeOptions.addArguments("--disable-dev-shm-usage");
		chromeOptions.setExperimentalOption("prefs", preferences);
		DesiredCapabilities cap = DesiredCapabilities.chrome();
		cap.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
		cap.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);

		if (ParamUtil.isSeleniumGrid()) {
			try {
				String url = "http://" + ParamUtil.getGridHost() + "/wd/hub";
				driver = new RemoteWebDriver(new URL(url), cap);
				LogUtil.log("Grid URL : " + url, LogLevel.HIGH);
			} catch (Throwable e) {
				e.printStackTrace();
			}
		} else {
			driver = new ChromeDriver(chromeOptions);
		}

		String browserVersion = ((RemoteWebDriver) driver).getCapabilities().getVersion();
		LogUtil.log("Browser Version : " + browserVersion, LogLevel.HIGH);

		return driver;
	}

	/**
	 * Gets the file path.
	 *
	 * @return the file path
	 */
	public static String getFilePath() {

		String downloadPath = "";

		try {
			File downloadFile = new File("");
			downloadPath = downloadFile.getAbsolutePath();
			downloadPath = downloadPath + File.separator + "testresult";
			LogUtil.log("Download File Path :" + downloadPath, LogLevel.HIGH);
		} catch (Exception ex) {
			ex.printStackTrace();
			LogUtil.log("Error in reading file path ", LogLevel.HIGH);
		}
		return downloadPath;
	}

	/**
	 * Checks if is file download complete.
	 *
	 * @param downloadPath the download path
	 * @param fileName the file name
	 * @return true, if is file download complete
	 */
	public static boolean isFileDownloadComplete(String downloadPath, String fileName) {

		Calendar currentTime = DateUtil.getUTCCalendar();
		Calendar endTime = DateUtil.getUTCCalendar();
		endTime.add(Calendar.MINUTE, 2);
		boolean flag = false;
		File dir = new File(downloadPath);
		while (currentTime.before(endTime)) {
			if (dir.exists()) {
				return flag = true;
			}
		}
		return flag;
	}

}

package com.rallio.automation.newrallio.enums;

public enum RevvSurveysEmailRatingTypeEnum {

	
	 	EXCELLENT_RATING,
	    
	    /** The location button. */
	    GOOD_RATING,
		
	    /** The location selector search tab. */
	    OK_RATING,
	    
	    /** The location select from dropdown. */
	    DISAPPOINTED_RATING,

	  /** The location list dropdown. */
	    POOR_RATING,
	  
	  /** The location selector ok button. */
	    CANT_SEE_THIS_EMAIL;    
	    
}

package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum CreatePostPageEnum.
 */
public enum CreatePostPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//span[text()='Creator']//following::section[contains(@class,'item-g filter')]//ancestor::div//section[@id='main-container-sec']//div[@class='addpost-section-main-wrp creator__main--content']"), "The page load"),
	
	/** The create post header. */
	CREATE_POST_HEADER(By.xpath("//div[contains(@class,'creator__header--title')]//span[@class='pk-title' and text()='Create Post']"), "CreatePost header"),

	/** The package id. */
	PACKAGE_ID(By.xpath("//div[contains(@class,'creator__header--title')]//span[@class='pk-title' and text()='Package ID: ']"),
	        "Package id"),

	/** Start over button. */
	START_OVER_BUTTON(By.xpath("//div[contains(@class,'creator__header--right')]//span[text()='Start Over']"), "Start over button"),

	/** The post status. */
	POST_STATUS(By.xpath("//div[contains(@class,'creator__header--right')]//div[@class='title-text-section']//span[text()='Status:']//following-sibling::span[text()='Draft']"), "Post status"),

    // Post Creation Page Left Side Section Elements
    
    /** The localize post button. */
    LOCALIZE_POST_BUTTON(By.xpath("//span[text()='Localize Post with Unique Fields']//ancestor::label[@class='checkbox-item']//span//input[@name='localizePost']"), "Localize post button"),
    
    /** The localize post section input. */
    LOCALIZE_POST_SECTION_INPUT(By.xpath("//div[@id='localize-post-insert-fields']//input"), "LocalizePost section input"),
        
    LOCALIZE_POST_SECTION_CONTAINER(By.xpath("//div[@class='rp-dats dropdown-action-items__control css-s68f6i-control']//div[contains(@class,'css-tlfecz-indicatorContainer')]"),"Localize Post Section Container"),
    
    LOCALIZE_POST_DROPDOWN(By.xpath("//div[@class='rp-dats dropdown-action-items__menu-list css-11unzgr']"),"Localize Dropdown "),
    
    LOCALIZE_POST_DROPDOWN_CONTENT(By.xpath("//div[contains(@class,'rp-dats dropdown-action-items')]//div[contains(@class,'rp-dats dropdown-action-items__menu-list')]//div[contains(@id,'react-select')]"),"Localize Post Dropdown Content"),
    
    LOCALIZE_POST_DROPDOWN_CONTENT_FIELD("//div[contains(@class,'rp-dats dropdown-action-items')]//div[contains(@class,'rp-dats dropdown-action-items__menu-list')]//div[contains(@id,'react-select') and text()='%s']","Localize Post Dropdown Content Field"),
    
	/** The localize post section content. */
	LOCALIZE_POST_SECTION_CONTENT(By.xpath("//div[@class='rcpm-txtArea']//div[@class='public-DraftStyleDefault-block public-DraftStyleDefault-ltr']//span//span"), "LocalizePost section content"),	

	/** The facebook tab. */
	FACEBOOK_TAB(By.xpath("//ul[@role='tablist']//button[text()='Facebook' and contains(@class,'nav-link')]"), "Facebook Tab"),

	/** The facebook tab active. */
	FACEBOOK_TAB_ACTIVE(By.xpath("//li[@class='nav-item']//button[text()='Facebook' and contains(@class,'nav-link active')]"), "Facebook Tab active"),

	/** The twitter tab. */
	TWITTER_TAB(By.xpath("//ul[@role='tablist']//button[text()='Twitter' and contains(@class,'nav-link')]"), "Twitter Tab"),

	/** The twitter tab active. */
	TWITTER_TAB_ACTIVE(By.xpath("//li[@class='nav-item']//button[text()='Twitter' and contains(@class,'nav-link active')]"), "Twitter Tab active"),

    TWITTER_LIMIT_EXIST_ALERT(By.xpath("//div//p[contains(text(),'Content exceeds Twitter/X character limit')]"),"Twitter Exist Alert"),
	
	/** The instagram tab. */
	INSTAGRAM_TAB(By.xpath("//ul[@role='tablist']//button[text()='Instagram' and contains(@class,'nav-link')]"), "Instagram Tab"),
	
	/** The instagram tab active. */
	INSTAGRAM_TAB_ACTIVE(By.xpath("//li[@class='nav-item']//button[text()='Instagram' and contains(@class,'nav-link active')]"), "Instagram Tab active"),
	
	INSTAGRAM_ALERT_FOR_NO_IMAGE(By.xpath("//div[@class='instaAlert']//p[text()='You must include an image or video in order to post to Instagram.']"),"INSTAGRAM_ALERT_FOR_NO_IMAGE"),
	
	INSTAGRAM_CHARACTER_EXIST_LIMIT_ALERT(By.xpath("//div[@class='instaAlert']//p[text()='Content exceeds instagram character limit']"),"INSTAGRAM_ALERT_CHARACTER_EXIST_LIMIT"),
	
	INSTARAGRAM_HASHTAG_EXIST_ALERT(By.xpath("//div[@class='instaAlert']//p[text()='Content exceeds instagram hashtag limit']"),"INSTARAGRAM_HASHTAG_EXIST_ALERT"),
	
	/** The linkedin tab active. */
	LINKEDIN_TAB_ACTIVE(By.xpath("//li[@class='nav-item']//button[text()='Linkedin' and contains(@class,'nav-link active')]"), "LinkedIn Tab active"),
	
	/** The instagram tab active. */

	/** The linkedin tab. */
	LINKEDIN_TAB(By.xpath("//ul[@role='tablist']//button[text()='Linkedin' and contains(@class,'nav-link')]"), "LinkedIn Tab"),

	LINKEDIN_COUNT_EXIST_LIMIT_ALERT(By.xpath("//p[text()='Content exceeds linkedin character limit']"),"LINKEDIN_COUNT_EXIST_LIMIT_ALERT"),
	
	INACTIVE_POST_PREVIEW(By.xpath("//div[contains(@class,'addpost-preview-section-wrp')]//div[@class='card-bg']//div[@class='p-mock-line']"),"INACTIVE_POST_PREVIEW"),
	
	ACTIVE_POST_PREVIEW(By.xpath("//div[contains(@class,'addpost-preview-section-wrp')]//div[contains(@class,'p-body previewtLinks')]"),"ACTIVE_POST_PREVIEW"),
	
	/** The linkedin tab active. */

	GOOGLE_TAB(By.xpath("//ul[@role='tablist']//button[text()='Google' and contains(@class,'nav-link')]"), "Google tab"),
	
	/** The google tab active. */
	GOOGLE_TAB_ACTIVE(By.xpath("//nav[@role='tablist']//a[text()='Google' and contains(@class,'nav-link active')]"), "Google tab active"),
	
	/** The settings tab. */
	SETTINGS_TAB(By.xpath("//ul[@role='tablist']//button[contains(@class,'nav-link') and text()='Settings']"), "Settings Tab"),

	/** The lock post checkbox. */
	LOCK_POST_CHECKBOX(By.xpath("//label[@class='checkbox-item']//div[text()='Lock Post']"), "Lock post checkbox"),

	/** The lock post checkbox. */
	LOCK_POST_CHECKBOX_INACTIVE(By.xpath("//label[@class='checkbox-item']//div[text()='Lock Post']"), "Lock post checkbox"),

	TIK_TOK_TAB(By.xpath("//ul[@role='tablist']//button[text()='Tiktok' and contains(@class,'nav-link')]"),"Tik Tok Tab"),

	POST_DESCRIBTION_INACTIVE(By.xpath("//div[@class='public-DraftEditor-content' and @contenteditable='false']"),"POST_DESCRIBTION_INACTIVE"),
	
    // LOCKPOST_CHECKBOX(By.xpath("//div[contains(text(),'Employee
    // Advocates')]//preceding-sibling::span//input[@type='checkbox']"),
    // "Lockpost Checkbox"),

	/** The lockpost i button. */
	LOCKPOST_I_BUTTON(By.xpath("//div[contains(text(),'Lock Post')]//div[contains(@class,'info__tool')]"), "Lockpost I-button"),

	LOCKPOST_I_BUTTON_HOVER_CONTENTS(By.xpath("//div[@class='common-tooltip--wrp' and contains(text(),'Checking this option locks the post from being')]"),"LOCKPOST_I_BUTTON_HOVER_CONTENTS"),
	
	/** The employee advocates checkbox. */
	EMPLOYEE_ADVOCATES_CHECKBOX(By.xpath("//label[@class='checkbox-item']//div[text()='Employee Advocates']"), "Employee Advocates checkbox"),

    // EMPLOYEE_ADVOCATES_CHECKBOX(By.xpath("//input[@name='mobile_app_only_enabled'
    // and @type='checkbox']"), "Employee Advocates Checkbox"),

	/** The employee advocates i button. */
	EMPLOYEE_ADVOCATES_I_BUTTON(By.xpath("//div[contains(text(),'Employee Advocates')]//div[contains(@class,'info__tool')]"), "Employee Advocates I-button"),

	EMPLOYEE_ADVOCATES_I_BUTTON_HOVER_CONTENTS_FOR_BRAND(By.xpath("//div[@class='common-tooltip--wrp' and contains(text(),'Checking this option provides your Employee Advocates the ability')]"),"EMPLOYEE_ADVOCATES_I_BUTTON_HOVER_CONTENTS"),
	
	EMPLOYEE_ADVOCATES_I_BUTTON_HOVER_CONTENTS_FOR_LOC(By.xpath("//div[@class='common-tooltip--wrp' and contains(text(),'Employee Advocates')]"),"EMPLOYEE_ADVOCATES_I_BUTTON_HOVER_CONTENTS_FOR_LOC"),
	
	/** Added Internal tags tab. */
	INTERNAL_TAGS_TAB(By.xpath("//ul[@role='tablist']//button[contains(@class,'nav-link') and text()='Internal Tags']"), "Add Internal tags"),

	/** The internal tags search field. */
	INTERNAL_TAGS_SEARCH_FIELD(By.xpath("//div[@class='fade tab-pane active show']//div[@class='creator-internaltags-wrp-section']//div[@class='react-tags__search-wrapper']//input[@aria-owns='ReactTags']"),
	        "Internal tags search field"),

	/** The added internal tags. */
	ADDED_INTERNAL_TAGS("//span[@class='list-expanded-tag-text' and text()='%s']", "Added Internal tags"),

	/** Remove Internal tags. */
	REMOVE_INTERNAL_TAGS("//span[text()='%s']//following-sibling::span[@class='list-expanded-tag-remove']", "Remove Internal tags"),

	/** The internal notes tab. */
	INTERNAL_NOTES_TAB(By.xpath("//ul[@role='tablist']//button[contains(@class,'nav-link') and text()='Internal Notes']"), "Internal notes tab"),

	/** The save this post to add internal notes. */
	SAVE_THIS_POST_TO_ADD_INTERNAL_NOTES(By.xpath(
	        "//button[contains(@class,'nav-link') and text()='Internal Notes']//ancestor::ul[@role='tablist']//following-sibling::div[@class='tab-content']//div[text()='Save this post to add internal notes.']"),
	        "Save this post to add internal notes"),

	/** The internal note input field. */
	INTERNAL_NOTE_INPUT_FIELD(By.xpath("//div[@class='cmi']//button//following-sibling::textarea[@id='internalnote']"), "InternalNote input field"),

	/** The internal note add button. */
	INTERNAL_NOTE_ADD_BUTTON(By.xpath("//div[@class='cmi']//textarea[@id='internalnote']//preceding-sibling::button"), "InternalNote add button"),

	/** The added internal note. */
	ADDED_INTERNAL_NOTE("//div[@class='cmi']//textarea[@id='internalnote' and @placeholder and contains(text(),'%s')]", "Added internal note"),

	/** The post description text area. */
	POST_DESCRIPTION_TEXT_AREA(By.xpath("//div[@class='DraftEditor-editorContainer']//span//parent::div//parent::div"), "Post Description textarea"),

	/** The post description for location */
	POST_DESCRIPTION_BOX_TEXT_FOR_LOCATION(By.xpath("//div[@id='placeholder-editor-location-creator' and contains(text(),'If you are creating an AI post, click the AI assistant button below. Otherwise, type your caption here...')]"), "Post Description textarea Content"),

	POST_DESCRIPTION_BOX_TEXT(By.xpath("//div[@id='placeholder-editor-brand-creator' and text()='If you are creating an AI post, click the AI assistant button below. Otherwise, type your caption here...']"),"Post Description"),
	
	/** The post description field. */
	POST_DESCRIPTION_FIELD("//div[@class='DraftEditor-editorContainer']//span//span[contains(text(),'%s')]","Post Text Area Field"),
	
	/** The post content input section. */
	POST_CONTENT_INPUT_SECTION(By.xpath("//div[@class='DraftEditor-editorContainer']//span//parent::div//parent::div"), "Post content input section"),


	/** The post to checkbox. */
	POST_TO_CHECKBOX(By.xpath("//label[@class='checkbox-item']//span[contains(text(),'Post to')]"), "Post to checkbox"),
	
	/** The Publish as Reel option. */
	PUBLISH_AS_REEL(By.xpath("//label[@class='checkbox-item']//div[@class='label-txt' and text()='Publish as Reel']"), "Publish as reel option"),
	
	/** The short video alert. */
	FACEBOOK_SHORT_VIDEO_ALERT(By.xpath("//div[@class='instaAlert']//p[text()='Video is too short. Facebook Reels must be at least 3 seconds long.']"), "Facebook Short video alert"),
	
	/** The short video alert. */
	INSTAGRAM_SHORT_VIDEO_ALERT(By.xpath("//div[@class='instaAlert']//p[text()='Video is too short. Instagram Reels must be at least 3 seconds long.']"), "Instagram Short video alert"),

	/** The add content from button. */
	ADD_CONTENT_FROM_BUTTON(By.xpath("//div[@class='tab-content']//div[@class='cs-select__value-container css-1d8n9bt']//div[contains(text(),'Add Content From')]"), "Add content from button"),

	/** The add content from facebook. */
	ADD_CONTENT_FROM_FACEBOOK(By.xpath("//div[@class='at-textarea-overlay-updated']//span[text()='Add Content From Facebook']"),"Add content from facebook"),
	
	/** The add content from twitter. */
	ADD_CONTENT_FROM_TWITTER(By.xpath("//div[@class='at-textarea-overlay-updated']//span[text()='Add Content From Twitter']"),"Add content from Twitter"),
	
	/** The add content from dropdown facebook. */
	ADD_CONTENT_FROM_DROPDOWN_FACEBOOK(
	        By.xpath("//div[text()='Add Content From']//parent::div//parent::div//following-sibling::div[contains(@class,'cs-select__menu')]//div[text()='Facebook']"),
	        "Add content from dropdown facebook"),

	/** The add content from dropdown twitter. */
	ADD_CONTENT_FROM_DROPDOWN_TWITTER(
	        By.xpath("//div[text()='Add Content From']//parent::div//parent::div//following-sibling::div[contains(@class,'cs-select__menu')]//div[text()='X (Formerly Twitter)']"),
	        "Add content from dropdown twitter"),

	/** Uploaded image in CreatePost section. */
	UPLOADED_IMAGE_IN_CREATEPOST_SECTION(By.xpath("//div[@class='card-bg active']//div[contains(@class,'image-roll-holder')]//div[@class='img-thumb']//img"),
			"Uploaded image in CreatePost section"),

	/** The add content from dropdown linkedin. */
	ADD_CONTENT_FROM_DROPDOWN_LINKEDIN(
	        By.xpath("//div[text()='Add Content From']//parent::div//parent::div//following-sibling::div[contains(@class,'cs-select__menu')]//div[text()='LinkedIn']"),
	        "Add content from dropdown linkedin"),

	/** The add content from dropdown instagram. */
	ADD_CONTENT_FROM_DROPDOWN_INSTAGRAM(
	        By.xpath("//div[text()='Add Content From']//parent::div//parent::div//following-sibling::div[contains(@class,'cs-select__menu')]//div[text()='Instagram Business']"),
	        "Add content from dropdown instagram"),

	/** The add new content button. */
	ADD_NEW_CONTENT_BUTTON(By.xpath("//div[@class='social-section-copy-wrp']//span[contains(text(),'Add New Content')]"), "Add Newcontent button"),

	POST_DESCRIPTION_EMOJI_OPTION(By.xpath("//div[@class='add__post--main']//div[contains(@class,'add__post--icon emoji-20')]//img[@alt='Emoji']"), "Post description emoji option"),

	/** The emotes list box. */
	EMOTES_LIST_BOX(By.xpath("//section[@class='emoji-mart emoji-mart-light']"), "Emotes list box"),

	/** The emotes search field. */
	EMOTES_SEARCH_FIELD(By.xpath("//section[@class='emoji-mart-search']//input"), "Emotes search field"),

	/** The emotes search result. */
	EMOTES_SEARCH_RESULT(By.xpath("//button[contains(@aria-label,'grinning')]//span"), "Emotes search result"),

	TAGS_DETAILVIEW_PAGE(By.xpath("//h3[text()='Tag Pages']//parent::div[@class='modal-body']"),"Tags Detailview Page"),

	/** The tag pages to post button. */
	TAG_PAGES_TO_POST_BUTTON(By.xpath("//div[@class='add__post--main']//div[contains(@class,'add__post--icon')]//img[@alt='Tags']"), "Tag pages to post button"),

	TAGS_SEARCHBOX(By.xpath("//div[@class='modal-dialog modal-sm modal-dialog-centered']//input[@class='react-tags__search-input']"),"Tags Search Boxs"),

	TAGS_AXIMAUTORALL_SUGGESTION("//div[@class='modal-dialog modal-sm modal-dialog-centered']//div[@class='p-header-title']//h5[text()='%s']","TAGS_AXIMAUTORALL_SUGGESTION"),

	TAGS_AXIMAUTORALL_SUGGESTION_ACTIVE("//div[@class='modal-dialog modal-sm modal-dialog-centered']//div[@class='p-header-title active']//h5[text()='%s']","Tags AximAutoRall Active"),

	TAGS_DEATILVIEW_DONE_BUTTON(By.xpath("//div[@class='modal-dialog modal-sm modal-dialog-centered']//div[@class='modal-footer']//div[@class='tags-btn-done']"),"Tags Detailview Done Button"),

	TAG_PAGES_TO_POST_BUTTON_DISABLED(By.xpath("//div[@class='add__post--main']//div[contains(@class,'tags disabled')]//img[@alt='Tags']"),"Tag To Post Button Disabled"),

	TAGS_HOVER_CONTENT(By.xpath("//div[@class='common-tooltip--wrp' and text()='Tags']"),"TAGS Hover Content"),

	/** The add images to post button. */
	ADD_IMAGES_TO_POST_BUTTON(By.xpath("//div[contains(@class,'add__post')]//img[@alt='Images']"), "Add Images to post button"),

	CTA_TAG_BUTTON(By.xpath("//div[contains(@class,'add__post--icon')]//img[@alt='GooglePost']"),"CTA Tag Button"),

	CTA_DETAILVIEW_CALL_ACTION_TEXT(By.xpath("//div[@class='modal-body']//h3[@class='gm__title']"),"CTA DetailView Call Action Text"),

	CTA_ENTER_URL(By.xpath("//div[@class='form-group form-field-item ']//input[@name='action_url']"),"CTA Enter Url"),

	CTA_DETAILVIEW_DONE_BUTTON(By.xpath("//button[@class='ac-btn ac-primary ac-block' and text()='Done']"),"CTA Detailview Done Button"),

	/** The add images to post button. */
	ADD_IMAGES_TO_POST_BUTTON_DISABLED(By.xpath("//div[@class='add__post--main']//div[contains(@class,'add-img disabled')]//img"), "Add Images to post button Disabled"),

	IMAGES_HOVER_CONTENT(By.xpath("//div[@class='common-tooltip--wrp' and text()='Images']")," Images Hover Content"),

	/** The add videos to post button. */
	ADD_VIDEOS_TO_POST_BUTTON(By.xpath("//div[@class='add__post--main']//div[contains(@class,'add-vid')]//img"), "Add Videos to post button"),

	/** The add videos to post button. */
	ADD_VIDEOS_TO_POST_BUTTON_DISABLED(By.xpath("//div[@class='add__post--main']//div[contains(@class,'add-vid disabled')]//img"), "Add Videos to post button Disabled"),

	VIDEOS_HOVER_CONTENT(By.xpath("//div[@class='common-tooltip--wrp' and text()='Videos']")," video Hover content"),

	/** The add coupon to post button. */
	ADD_COUPON_TO_POST_BUTTON(By.xpath("//div[@class='add__post--main']//div[contains(@class,'coupons')]//img"), "Add Coupon to post button"),

	/** The add coupon to post button. */
	ADD_COUPON_TO_POST_BUTTON_DISABLED(By.xpath("//div[@class='add__post--main']//div[contains(@class,'coupons disabled')]//img"), "Add Coupon to post button Disabled"),

	COUPON_HOVER_CONTENT(By.xpath("//div[@class='common-tooltip--wrp' and text()='Coupons']"),"Coupon Hover content"),

	/** The add link to post button. */
	ADD_LINK_TO_POST_BUTTON(By.xpath("//div[@class='add__post--main']//div[contains(@class,'add-links')]//img"), "Add Link to post button"),

	/** The add link to post button. */
	ADD_LINK_TO_POST_BUTTON_DISABLED(By.xpath("//div[@class='add__post--main']//div[contains(@class,'add-links add-hls disabled')]//img"), "Add Link to post button"),

	CALL_TO_ACTION_HOVER_TEXT(By.xpath("//div[@class='common-tooltip--wrp' and text()='Call To Action']"),"Call To Action Hover Text"),

	LINK_HOVER_CONTENT(By.xpath("//div[@class='common-tooltip--wrp' and text()='Links']"),"Link Hover Content"),

	/** The add boost to post button. */
	ADD_BOOST_TO_POST_BUTTON(By.xpath("//div[@class='add__post--main']//div[contains(@class,'add-boost')]//img"), "Add Boost to post button"),

	/** The search in tag pages tab. */
	SEARCH_IN_TAG_PAGES_TAB(By.xpath("//h3[text()='Tag Pages']//parent::div//div[@class='react-tags__search']//input"), "Search in tagPages tab"),

	/** The tag pages suggestion results. */
	TAG_PAGES_SUGGESTION_RESULTS("//h4[text()='SUGGESTIONS']//parent::div//div[@class='p-title']//h5[text()='%s']", "TagPages suggestion results"),

	/** The tag pages done button. */
	TAG_PAGES_DONE_BUTTON(By.xpath("//div[@class='tags-btn-done' and text()='Done' and not(@disabled)]"), "TagPages done button"),

	/** The tagged link in preview. */
	TAGGED_LINK_IN_PREVIEW("//div[@class='post-preview']//div[@class='p-content']//div[@class='p-body previewtLinks']//a//span[text()='%s']", "Tagged link in preview"),

	/** Add new image tab. */
	ADD_NEW_IMAGE_TAB(By.xpath("//div[@class='modal-body']//button[@id='add-tabs-tab-add_new_image']"), "Add new image tab"),

	TAG_OPTION_TO_POST_BUTTON(By.xpath("//div[@class='add__post--main']//div[contains(@class,'add__post')]//img[@alt='Tags']"),"Tag To Post Button"),

	/** Upload image. */
	UPLOAD_IMAGE(By.xpath("//div[@id='add-tabs-tabpane-add_new_image']//input[@type='file' and @accept]"), "Upload image"),

	/** The browse button. */
	BROWSE_BUTTON(By.xpath("//div[@id='add-tabs-tabpane-add_new_image']//button[text()='Browse']"), "Browse button"),

	/** Uploaded image. */
	UPLOADED_IMAGE(By.xpath("//div[contains(@class,'add__image--upload')]//div[@class='m-ast-itm m-ast-img']//img"), "Uploaded image"),

	/** The remove uploaded image. */
	REMOVE_UPLOADED_IMAGE(By.xpath("//div[contains(@class,'add__image--upload')]//div[@class='m-ast-itm m-ast-img']//following-sibling::div//img[@alt='Remove']"),
	        "Remove uploaded image"),

	/** Clear button. */
	CLEAR_BUTTON(By.xpath("//div[contains(@class,'add__post')]//button[text()='Clear' and not(@disabled)]"), "Clear button"),

	/** Use image button. */
	USE_IMAGE_BUTTON(By.xpath("//div[contains(@class,'add__post')]//button[text()='Use Image' and not(@disabled)]"), "Use Image button"),

	USE_IMAGES_BUTTON(By.xpath("//div[contains(@class,'add__post')]//button[text()='Use Images' and not(@disabled)]"),"Use Images Button"),


	/** The uploaded image delete button. */
	UPLOADED_IMAGE_DELETE_BUTTON(By.xpath("//div[contains(@class,'tw-content')]//div[@class='ctmc-item ctmc-delete']//img[@alt='Delete']"), "Uploaded image delete button"),
	
	/** The uploaded image in instagram tab. */
	UPLOADED_IMAGE_IN_INSTAGRAM_TAB(By.xpath("//div[contains(@class,'image-roll-holder')]//img[@alt='instagram-preview-image']"), "Uploaded image in Instagram tab"),
	
	/** The pad image button. */
	PAD_IMAGE_BUTTON(By.xpath("//input//following-sibling::span[text()='Pad Instagram Image']"), "Pad image button"),
	
	/** The crop image button. */
	CROP_IMAGE_BUTTON(By.xpath("//input//following-sibling::span[text()='Crop Instagram Image']"), "Crop image button"),
	
	/** The content section add images button. */
	CONTENT_SECTION_ADD_IMAGES_BUTTON(By.xpath("//div[contains(@class,'image-roll-holder ctm')]//img[@alt='add-img-btn']"), "Content section addImages button"),
	
	/** My Images tab. */
	MY_IMAGES_TAB(By.xpath("//div[@class='modal-body']//button[@id='add-tabs-tab-my_images']"), "My Images tab"),

	/** The instagram my images tab. */
	INSTAGRAM_MY_IMAGES_TAB("", ""),
	
	/** Search image in My Images tab. */
	SEARCH_IMAGE_IN_MY_IMAGES_TAB(By.xpath("//div[@id='add-tabs-tabpane-my_images']//div[@class='react-tags__search']//input"), "Search image in My Images tab"),

	MY_IMAGE_IMAGE_LIST(By.xpath("//div[@class='masonry-grid']//div[@class='m-item']//div[@class='m-ast']//img"),"My Image Image List"),

	MY_IMAGE_IMAGE_LIST_FIELD("//div[@class='masonry-grid']//div[@class='m-item']//div[@class='m-ast']//img[@src=\"%s\"]","My Image Image List Field"),

	/** Image list in My Images tab. */
	IMAGE_LIST_IN_MY_IMAGES_TAB(By.xpath("//div[@id='add-tabs-tabpane-my_images']//div[contains(@class,'local-ini myAssets')]//div[@class='m-item']"),
	        "Image list in My Images tab"),

	/** Search result in My Images tab. */
	SEARCH_RESULT_IN_MY_IMAGES_TAB("//div[@id='add-tabs-tabpane-my_images']//div[contains(@class,'m-item')]//div[@title='%s']", "Search result in My Images tab"),

	/** The search results in my images tab. */
	SEARCH_RESULTS_IN_MY_IMAGES_TAB(By.xpath("//div[@id='add-tabs-tabpane-my_images']//div[@class='m-item']//div[@title]"), "Search results in My Images tab"),

	/** The selected image in my images tab. */
	SELECTED_IMAGE_IN_MY_IMAGES_TAB(By.xpath("//div[@id='add-tabs-tabpane-my_images']//div[@class='m-item active']//div[@title]"), "Selected image in MyImages tab"),

	/** Brand Images tab. */
	BRAND_IMAGES_TAB(By.xpath("//div[@class='modal-body']//button[@id='add-tabs-tab-brand_images']"), "Brand Images tab"),

	/** The brand images tab select favourite tags. */
	BRAND_IMAGES_TAB_SELECT_FAVOURITE_TAGS("//div[@id='add-tabs-tabpane-brand_images']//h3[text()='Favorite Tags:']//parent::div//span[@class='fav-tags' and text()='%s']",
	        "BrandImages tab select favourite tags"),

	/** Search image in Brand Images tab. */
	SEARCH_IMAGE_IN_BRAND_IMAGES_TAB(By.xpath("//div[@id='add-tabs-tabpane-brand_images']//div[@class='react-tags__search']//input"), "Search image in Brand Images tab"),

	/** Image list in Brand Images tab. */
	IMAGE_LIST_IN_BRAND_IMAGES_TAB(By.xpath("//div[@id='add-tabs-tabpane-brand_images']//div[contains(@class,'local-ini myAssets')]//div[@class='m-item']"),
	        "Image list in Brand Images tab"),

	/** Search result in Brand Images tab. */
	SEARCH_RESULT_IN_BRAND_IMAGES_TAB("//div[@id='add-tabs-tabpane-brand_images']//div[@class='m-item']//div[@title='%s']", "Search result in Brand Images tab"),

	/** The search results in brand images tab. */
	SEARCH_RESULTS_IN_BRAND_IMAGES_TAB(By.xpath("//div[@id='add-tabs-tabpane-brand_images']//div[@class='m-item']//div[@title]"), "Search results in Brand Images tab"),

	/** Add new video tab. */
	ADD_NEW_VIDEO_TAB(By.xpath("//div[@class='modal-body']//button[@id='add-tabs-tab-add_new_video']"), "Add new video tab"),

	/** Upload video. */
	UPLOAD_VIDEO(By.xpath("//div[@id='add-tabs-tabpane-add_new_video']//input[@type='file']"), "Upload video"),

	/** Uploaded video. */
	UPLOADED_VIDEO(By.xpath("//div[contains(@class,'add__image--upload')]//div[@class='m-ast']//video"), "Uploaded video"),

	/** Use video button. */
	USE_VIDEO_BUTTON(By.xpath("//div[contains(@class,'add__post')]//button[text()='Use Video' and not(@disabled)]"), "Use video button"),

	/** Uploaded video in CreatePost section. */
	UPLOADED_VIDEO_IN_CREATEPOST_SECTION(By.xpath("//div[contains(@class,'image-roll-holder ctm')]//video"),
	        "Uploaded video in CreatePost section"),

	/** The uploaded image delete button. */
	UPLOADED_VIDEO_DELETE_BUTTON(By.xpath("//div[contains(@class,'ctmc-item ctmc-delete')]//img[@alt='Delete']"), "Uploaded Video delete button"),
	
	/** My videos tab. */
	MY_VIDEOS_TAB(By.xpath("//div[@class='modal-body']//button[@id='add-tabs-tab-my_videos']"), "My videos tab"),

	/** Search video in My videos tab. */
	SEARCH_VIDEO_IN_MY_VIDEOS_TAB(By.xpath("//div[@id='add-tabs-tabpane-my_videos']//div[@class='react-tags__search']//input"), "Search video in My videos tab"),

	/** video list in My videos tab. */
	VIDEO_LIST_IN_MY_VIDEOS_TAB(By.xpath("//div[@id='add-tabs-tabpane-my_videos']//div[contains(@class,'local-ini myAssets')]//div[@class='m-item video-element']"),
	        "video list in My videos tab"),

	/** Search result in My videos tab. */
	SEARCH_RESULT_IN_MY_VIDEOS_TAB("//div[@id='add-tabs-tabpane-my_videos']//div[@class='m-item video-element']//div[@title='%s']", "Search result in My videos tab"),

	/** The search results in my videos tab. */
	SEARCH_RESULTS_IN_MY_VIDEOS_TAB(By.xpath("//div[@id='add-tabs-tabpane-my_videos']//div[@class='m-item video-element']//div[@title]"), "Search results in My videos tab"),

	/** The selected video in my videos tab. */
	SELECTED_VIDEO_IN_MY_VIDEOS_TAB(By.xpath("//div[@id='add-tabs-tabpane-my_videos']//div[@class='m-item active video-element']//div[@title]"), "Selected video in MyVideos tab"),

	/** Brand videos tab. */
	BRAND_VIDEOS_TAB(By.xpath("//div[@class='modal-body']//button[@id='add-tabs-tab-brand_videos']"), "Brand videos tab"),

	/** Search video in Brand videos tab. */
	SEARCH_VIDEO_IN_BRAND_VIDEOS_TAB(By.xpath("//div[@id='add-tabs-tabpane-brand_videos']//div[@class='react-tags__search']//input"), "Search video in Brand videos tab"),

	/** video list in Brand videos tab. */
	VIDEO_LIST_IN_BRAND_VIDEOS_TAB(By.xpath("//div[@id='add-tabs-tabpane-brand_videos']//div[contains(@class,'local-ini myAssets')]//div[@class='m-item video-element']"),
	        "video list in Brand video tab"),

	/** Search result in Brand videos tab. */
	SEARCH_RESULT_IN_BRAND_VIDEOS_TAB("//div[@id='add-tabs-tabpane-brand_videos']//div[@class='m-item video-element']//div[@title='%s']", "Search result in Brand videos tab"),

	/** The search results in brand videos tab. */
	SEARCH_RESULTS_IN_BRAND_VIDEOS_TAB(By.xpath("//div[@id='add-tabs-tabpane-brand_videos']//div[@class='m-item video-element']//div[@title]"),
	        "Search results in Brand videos tab"),
	
	COUPON_TAB(By.xpath("//div[contains(@class,'add__post--icon')]//img[@alt='Coupon']"),"Coupon Tab"),
	
	/** The add coupon tab. */
	ADD_COUPON_TAB(By.xpath("//div[@class='modal-body']//div[@class='ap-head']//h3[text()='Add Coupon']"), "Add coupon tab"),

	/** The search coupon in add coupon tab. */
	SEARCH_COUPON_IN_ADD_COUPON_TAB(By.xpath("//div[contains(@class,'addCouponMain')]//div[@class='react-tags__search']//input"), "Search coupon in add coupon tab"),

	/** The coupon list in add coupon tab. */
	COUPON_LIST_IN_ADD_COUPON_TAB(By.xpath("//div[contains(@class,'addCouponMain')]//div[@class='apInfinity adcInfnty']//div[@class='adc-item']"), "Coupon list in AddCoupon tab"),

	/** The search result in add coupon tab. */
	SEARCH_RESULT_IN_ADD_COUPON_TAB("//div[contains(@class,'addCouponMain')]//div[@class='adc-item']//span[contains(text(),'%s')]",
	        "Search result in add coupon tab"),

	/** The selected coupon in add coupon tab. */
	SELECTED_COUPON_IN_ADD_COUPON_TAB(By.xpath("//div[contains(@class,'addCouponMain')]//div[@class='adc-item active']"), "Slected coupon in AddCoupon tab"),

	/** The add coupon tab add button. */
	ADD_COUPON_TAB_ADD_BUTTON(By.xpath("//div[@class='modal-content']//button[text()='Add' and not(@disabled)]"), "Add coupon tab add button"),

	/** The add coupon tab cancel button. */
	ADD_COUPON_TAB_CANCEL_BUTTON(By.xpath("//div[@class='modal-content']//button[text()='Cancel' and not(@disabled)]"), "Add coupon tab cancel button"),

	/** The added coupon in createpost section. */
	ADDED_COUPON_IN_CREATEPOST_SECTION(By.xpath("//div[@class='creator-addcoupon-active-wrp']"), "Added coupon in createPost section"),

	/** The add link text box. */
	ADD_LINK_TEXT_BOX(By.xpath("//div[@class='modal-body']//input[@placeholder='Add Link']"), "Add link textbox"),

	ADD_LINK_ACTIVE_BUTTON(By.xpath("//div[contains(@class,'add-links')]//img"),"Add Link Active Button"),
	
	/** The add link tab add button. */
	ADD_LINK_TAB_ADD_BUTTON(By.xpath("//div[@class='modal-body']//button[text()='Add link' and not(@disabled)]"), "Add link tab add button"),

	/** The add link tab delete button. */
	ADD_LINK_TAB_DELETE_BUTTON(By.xpath("//div[@class='modal-body']//button[text()='Delete link' and not(@disabled)]"), "Add link tab delete button"),

	/** The added link in createpost section. */
	ADDED_LINK_IN_CREATEPOST_SECTION(By.xpath("//div[@class='creator-addcoupon-active-wrp']"), "Added link in createPost section"),

	/** The image in added link preview. */
	IMAGE_IN_ADDED_LINK_PREVIEW(By.xpath("//div[@class='creator-addcoupon-active-wrp']//div[@class='coupan-card-left']//div[@class='coupon-content']//div[@class='coupon-details']"),
	        "Image in addedLink preview"),

	/** The thumbnail in added link preview. */
	THUMBNAIL_IN_ADDED_LINK_PREVIEW(By.xpath("//div[@class='creator-addcoupon-active-wrp']//div[@class='coupon-content']//input[@name='isNoThumbnail']"),
	        "Thumbnail in addedLink preview"),

	/** The close in added link preview. */
	CLOSE_IN_ADDED_LINK_PREVIEW(By.xpath("//div[@class='creator-addcoupon-active-wrp']//span[@class='apui-close-creator-cou']"), "cLOSE in addedLink preview"),

    // Post Creation Right sideSection Elements
	/** The preview section. */
	PREVIEW_SECTION(By.xpath("//div[contains(@class,'addpost-preview-section-wrp')]//div[@class='post-preview']"), "Preview Section"),

	/** The add boost button. */
	ADD_BOOST_BUTTON(By.xpath("//button[contains(@class,'add-boost-btn') and not(contains(@class,'disabled'))]//span[text()='Add Boost']"), "Add boost button"),

	/** The Schedule - add boost button. */
	SCHEDULE_MODAL_ADD_BOOST_BUTTON(By.xpath("//div[contains(@class,'add-boost')]//div[@class='left-column']//span[text()='Add Boost']"), "Schedule modal pop up - Add boost button"),

	POST_PREVIEW_SECTION_IMAGE(By.xpath("//div[@class='am-media-preview pmg']//img[@src]"),"Post Preview Section Image"),

	/** The facebook post preview. */
	FACEBOOK_POST_PREVIEW("//div[@class='post-preview']//h4[text()='Facebook Page']//parent::div[@class='p-content-header']//following-sibling::div//p[contains(@title,'%s')]",
	        "FacebookPost preview"),

	/** The twitter post preview. */
	TWITTER_POST_PREVIEW("//div[@class='post-preview']//h4[text()='X (Formerly Twitter)']//parent::div[@class='p-content-header']//following-sibling::div//p[contains(@title,'%s')]",
	        "TwitterPost preview"),

	/** The linkedin post preview. */
	LINKEDIN_POST_PREVIEW("//div[@class='post-preview']//h4[text()='LinkedIn']//parent::div[@class='p-content-header']//following-sibling::div//p[contains(@title,'%s')]",
	        "LinkedinPost preview"),

	GOOGLE_POST_PREVIEW("//div[@class='post-preview']//h4[text()='Google My Business']//parent::div[@class='p-content-header']//following-sibling::div//p[contains(@title,'%s')]",
	        "GooglePost preview"),
	
	/** The instagram post preview. */
	INSTAGRAM_POST_PREVIEW(
	        "//div[@class='post-preview']//h4[text()='Instagram Business']//parent::div[@class='p-content-header']//following-sibling::div//p[contains(@title,'%s')]",
	        "InstagramPost preview"),

	/** The schedule post button. */
	SCHEDULE_POST_BUTTON(By.xpath("//button[text()='Schedule' and not(contains(@class,'disabled'))]"), "Schedule post button"),

	SCHEDULE_DETAILVIEW_SCHEDULE_BUTTON(By.xpath("//button[@class='ac-btn ac-secondary ac-block ' and text()='Schedule']"),"Schedule DetailView Schedule Button"),
	
	/** The schedule post option. */
	SCHEDULE_POST_OPTION(By.xpath("//button[text()='Schedule']"), "Schedule post option"),

	SCHEDULE_BUTTON(By.xpath("//div[@class='btn schedule-btn' and text()='Schedule']"),"Schedule button"),
	
	/** The syndicate button. */
	SYNDICATE_BUTTON(By.xpath("//button[text()='Syndicate' and not(contains(@class,'disabled'))]"), "Syndicate button"),

	SYNDICATE_BUTTON_ACTIVE(By.xpath("//div[@class='react-ripples ac-primary-box']//button[text()='Schedule']"),"Syndicate button active"),

	/** The syndicate option. */
	SYNDICATE_OPTION(By.xpath("//button[text()='Syndicate']"), "Syndicate option"),

	/** The schedule section view. */
	SCHEDULE_SECTION_VIEW(By.xpath("//div[@class='modal-content']//div[@class='modal-body']"), "Schedule section view"),

	/** The schedule section postnow button. */
	SCHEDULE_SECTION_POSTNOW_BUTTON(By.xpath("//h3[text()='Schedule']//parent::div[@class='modal-body']//button[text()='Post Now']"), "Schedule section postNow button"),

	/** The schedule section schedule button. */
	SCHEDULE_SECTION_SCHEDULE_BUTTON(By.xpath("//h3[text()='Schedule']//parent::div[@class='modal-body']//button[text()='Schedule']"), "Schedule section schedule button"),

	SCHEDULE_SECTION_DISABLE("//div[@class='createpost-right-section-new-section']//div[contains(@class,'pointer-events-none')]//button[text()='%s']","Schedule section disable"),

	BRAND_SCHEDULE_SECTION_SCHEDULE_BUTTON(By.xpath("//div[@class='modal-body']//div[text()='Schedule']"),"BRAND_SCHEDULE_SECTION_SCHEDULE_BUTTON"),

	/** The schedule section override option. */
	SCHEDULE_SECTION_OVERRIDE_OPTION(By.xpath("//h3[text()='Schedule']//parent::div[@class='modal-body']//label[@class='checkbox-item']//div[text()='Override Posting Permissions']"), "Schedule section override option"),
	
	/** The override option selected. */
	OVERRIDE_OPTION_SELECTED(By.xpath("//h3[text()='Schedule']//parent::div[@class='modal-body']//label[@class='checkbox-item active']//div[text()='Override Posting Permissions']"), "Override option selected"),
	
	/** The schedule section date button. */
	SCHEDULE_SECTION_DATE_BUTTON(By.xpath("//div[@class='react-datepicker__input-container']//input[@placeholder='Date']"), "Schedule section date button"),
	
	/** The schedule section calendar view. */
	SCHEDULE_SECTION_CALENDAR_VIEW(By.xpath("//div[@class='react-datepicker__tab-loop']//div[@class='react-datepicker__month-container']"), "Schedule section calendarView"),
	
	/** The schedule section close button. */
	SCHEDULE_SECTION_CLOSE_BUTTON(By.xpath("//div[@class='mod__close--icon']//img[@alt='close']"), "Schedule section close button"),

	/** The schedule section addboost button. */
	SCHEDULE_SECTION_ADDBOOST_BUTTON(By.xpath("//div[@class='add-boost-accordian-section corp-boost']//span[text()='Add Boost']"), "Schedule section addBoost button"),

	/** The schedule section addboost close. */
	SCHEDULE_SECTION_ADDBOOST_CLOSE(By.xpath("//div[@class='add-boost-accordian-section corp-boost cb-on']//img[@alt='delete']"), "Schedule section addBoost close"),
	
	/** The lifetime spend input. */
	LIFETIME_SPEND_INPUT(By.xpath("//div[@class='add-boost-accordian-section corp-boost cb-on']//input[@name='lifetimeSpend']"), "Lifetime spend input"),
	
	/** The daily spend input. */
	DAILY_SPEND_INPUT(By.xpath("//div[@class='add-boost-accordian-section corp-boost cb-on']//input[@name='duration']"), "Daily spend input"),
	
	/** The addboost weight option. */
	ADDBOOST_WEIGHT_OPTION(By.xpath("//div[text()='Weight']//preceding-sibling::input[@name='boostType']"), "AddBoost weight option"),
	
	/** The addboost flat option. */
	ADDBOOST_FLAT_OPTION(By.xpath("//div[text()='Flat']//preceding-sibling::input[@name='boostType']"), "AddBoost flat option"),
	
	/** The view average spend locations. */
	VIEW_AVERAGE_SPEND_LOCATIONS(By.xpath("//div[@class='add-boost-accordian-section corp-boost cb-on']//div[text()='View Average spend locations']"), "View average spend locations"),

	/** The view average spend locations - Total location count */
	VIEW_AVERAGE_SPEND_LOCATIONS_TOTAL_COUNT(By.xpath("//table[@class=' responsiveTable']//tbody//span[@class='total-txt']//span[text()]"), "The View average spend locations - Total location count"),

	/** The average location spends content. */
	AVERAGE_LOCATION_SPENDS_CONTENT(By.xpath("//div[@class='modal-content']//h2[text()='Average Location Spends']//following-sibling::div[@class='adv-leaderboardwrp']"), "Average location spends content"),
	
	/** The average location spends close. */
	AVERAGE_LOCATION_SPENDS_CLOSE(By.xpath("//div[contains(@class,'boost-asl modal show')]//div[@class='mod__close--icon']//img[@alt='mod__close--img']"), "Average location spends close"),
	
	/** The totals average daily spend. */
	TOTALS_AVERAGE_DAILY_SPEND(By.xpath("//div[@class='tdBefore' and text()='Average Daily Spend']//following-sibling::div//span[contains(@class,'total-txt')]"), "Totals average daily spend"),
	
	/** The totals average total spend. */
	TOTALS_AVERAGE_TOTAL_SPEND(By.xpath("//div[@class='tdBefore' and text()='Average Total Spend']//following-sibling::div//span[contains(@class,'total-txt')]"), "Totals average total spend"),
	
	TOTAL_AVERAGE_SPENT_DAILY(By.xpath("//div[@class='daily-spend-text' and text()='Daily Spend']//following-sibling::div//span[contains(@class,'corpdValue')]"),"TOTAL_AVERAGE_SPENT_DAILY"),
	
	TOTAL_AVERAGE_SPENT_TOTAL(By.xpath("//div[@class='form-group form-field-item']//input[@name='lifetimeSpend']"),"TOTAL_AVERAGE_SPENT_TOTAL"),
	
	/** The all locations option. */
	ALL_LOCATIONS_OPTION(By.xpath("//div[@class='modal-body']//input//following-sibling::label[text()='All Locations']"), "AllLocations option"),
	
	ALL_LOCATIONS_OPTION_ACTIVE(By.xpath("//div[@class='modal-body']//button[@aria-selected='true']//input//following-sibling::label[text()='All Locations']"), "AllLocations option Active"),
	
	/** The corporate only option. */
	CORPORATE_ONLY_OPTION(By.xpath("//div[@class='modal-body']//input//following-sibling::label[text()='Corporate Only']"), "CorporateOnly option"),
	
	/** The specific locations option. */
	SPECIFIC_LOCATIONS_OPTION(By.xpath("//div[@class='modal-body']//input//following-sibling::label[text()='Specific Locations/Lists']"), "SpecificLocations option"),
	
	SPECIFI_LOCATION_LOCATION_LIST_FIELD("//div[@class='rs-drp__menu-list css-11unzgr']//div[@title='%s']","Specific Location Location List Field"),
	
	SPECIFIC_LOCATION_LIST_OPTION(By.xpath("//div[@class='modal-body']//input//following-sibling::label[text()='Specific Location List']"),"Specific Location List Option"),
	
	SPECIFIC_LOCATION_SELECT_LIST(By.xpath("//div[contains(@id,'specific_location_list')]//button//span[text()='Select List']"),"Specific Location Select list"),
	
	/** The select locations button. */
	SELECT_LOCATIONS_BUTTON(By.xpath("//div[contains(@id,'specific_locations_or_lists')]//button//span[text()='Select Locations']"), "Select Locations button"),
	
	/** The select locations dropdown. */
	SELECT_LOCATIONS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='fade tab-pane active show']//span[text()='Select Locations']//parent::button//parent::div//div[@id='select-locations-dropdown']"), "Select Locations dropdown"),
	
	SYNDICATE_SELECT_LOCATION_LIST_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='fade tab-pane active show']//span[text()='Select List']//parent::button//parent::div//div[@id='syndicate-dropdown']"),"Syndicate Location List Dropdown"),
	
	SYNDICATE_SELECT_LIST_SEARCH(By.xpath("//div[@class='modal-body']//div[@class='fade tab-pane active show']//span[text()='Select List']//parent::button//parent::div//div[@id='syndicate-dropdown']//input"),"SYNDICATE_SELECT_LIST_SEARCH"),
	
	/** The select locations search result. */
	SYNDICATE_SELECT_LOCATIONS_SEARCH_RESULT("//div[@class='modal-body']//div[@class='fade tab-pane active show']//div[contains(@id,'dropdown')]//div[contains(@class,'rs-drp__option') and contains(text(),'%s')]", "Select Locations searchResult"),
	
	/** The select locations search field. */
	SELECT_LOCATIONS_SEARCH_FIELD(By.xpath("//div[@class='modal-body']//div[@class='fade tab-pane active show']//span[text()='Select Locations']//parent::button//parent::div//div[@id='select-locations-dropdown']//input"), "Select Locations searchField"),
	
	/** The select locations search result. */
	SELECT_LOCATIONS_SEARCH_RESULT("//div[@class='modal-body']//div[@class='fade tab-pane active show']//div[@id='select-locations-dropdown']//div[contains(@class,'rs-drp__option') and contains(text(),'%s')]", "Select Locations searchResult"),
	
	/** The selected location. */
	SELECTED_LOCATION("//div[@class='modal-body']//div[@class='fade tab-pane active show']//div[@class='blh-type']//span[contains(text(),'%s')]", "Selected location"),
	
	/** The selected specific active checkbox. */
	SELECTED_SPECIFIC_ACTIVE_CHECKBOX("//div[@class='fade tab-pane active show']//span[contains(text(),'%s')]//ancestor::li[@class='active']//span[@class='checkbox-n']","Selected Specific Active Locations"),
	
	/** The selected specific inactive checkbox. */
	SELECTED_SPECIFIC_INACTIVE_CHECKBOX("//div[@class='fade tab-pane active show']//span[contains(text(),'%s')]//ancestor::li[not(@class='active')]//span[@class='checkbox-n']","Selected Specific InActive Location"),
	
	/** The selected specific location remove. */
	SELECTED_SPECIFIC_LOCATION_REMOVE("//div[@class='fade tab-pane active show']//span[contains(text(),'%s')]//ancestor::div[@class='blh-head']//div[@class='glbl__round--delete']//img","Selected Specific Remove Button"),

	SELECTED_SPECIFIC_LOCATION_NAME_REMOVE("//span[contains(text(),'%s')]//ancestor::div//div[@class='glbl__round--delete']//img","SELECTED_SPECIFIC_LOCATION_NAME_REMOVE"),

	/** The syndicate section all locations option. */
	SYNDICATE_SECTION_ALL_LOCATIONS_OPTION(By.xpath("//div[@class='modal-body']//input//following-sibling::label[text()='All Locations']"), "Syndicate section AllLocations option"),
	
	/** The syndicate section specific lists option. */
	SYNDICATE_SECTION_SPECIFIC_LISTS_OPTION(By.xpath("//div[@class='modal-body']//input//following-sibling::label[text()='Specific Location List']"), "Syndicate section specificLists option"),
	
	/** The syndicate section anytime option. */
	SYNDICATE_SECTION_ANYTIME_OPTION(By.xpath("//div[@class='modal-body']//input//following-sibling::div[text()='Anytime']"), "Syndicate section anyTime option"),

	SYNDICATE_SECTION_OPTION_ACTIVE("//label[@class='r-flx r-flx-ac active']//div[text()='%s']","Syndicate Section Option Active"),

	/** The syndicate section custom option. */
	SYNDICATE_SECTION_CUSTOM_OPTION(By.xpath("//div[@class='modal-body']//input//following-sibling::div[text()='Custom']"), "Syndicate section custom option"),

	/** The syndicate section fromto option. */
	SYNDICATE_SECTION_FROMTO_OPTION(By.xpath("//div[@class='when-section-grid']//div[@class='section-01']//following-sibling::div[@class='section-02']"), "Syndicate section fromTo option"),

	SYNDICATE_DETAILVIEW_SYNDICATE_BUTTON(By.xpath("//div[@class='footer-section']//button[text()='Syndicate']"),"Syndicate Detailview Syndiacate Button"),

	/** The select list button. */
	SELECT_LIST_BUTTON(By.xpath("//div[@class='modal-body']//button//span[text()='Select List']"), "Select List button"),
	
    /** The select list dropdown. */
    SELECT_LIST_DROPDOWN(By.xpath("//div[@class='modal-body']//span[text()='Select List']//parent::button//parent::div//div[@id='syndicate-dropdown']"), "Select List dropdown"),
	
	/** The select list search field. */
	SELECT_LIST_SEARCH_FIELD(By.xpath("//div[@class='modal-body']//span[text()='Select List']//parent::button//parent::div//div[@id='syndicate-dropdown']//input"), "Select List searchField"),
	
	/** The select list search result. */
	SELECT_LIST_SEARCH_RESULT("//div[@class='modal-body']//div[@id='syndicate-dropdown']//div[contains(@class,'rs-drp__option') and contains(text(),'%s')]", "Select List searchResult"),
	
	/** The selected list. */
	SELECTED_LIST("//div[@class='modal-body']//div[@class='select-location-section-wrp']//div[@class='grid-section']//span[text()='%s']", "Selected List"),

	/** The syndicate section syndicate button. */
	SYNDICATE_SECTION_SYNDICATE_BUTTON(By.xpath("//h3[text()='Syndicate']//parent::div[@class='modal-body']//button[text()='Syndicate']"), "Syndicate section syndicate button"),
	
	/** The post syndicated message. */
	POST_SYNDICATED_MESSAGE(By.xpath("//div[@class='message-sub-text' and text()='This post has been syndicated']"), "Post syndicated message"),
	
	/** The are you sure post now button. */
	ARE_YOU_SURE_POST_NOW_BUTTON(By.xpath("//div[text()='Are you sure you want to post now?']//ancestor::div[@class='modal-content']//button[text()='Post Now']"),
	        "post Now button"),

	MEDI_SYNDICATED_MESSAGE(By.xpath("//div[@class='message-sub-text' and text()='This media has been syndicated']"), "Post syndicated message"),

	/** The Calendar view - footer. */
	VIEW_CALENDAR_FOOTER(By.xpath("//td[@class='fc-timegrid-slot fc-timegrid-slot-lane '][last()]"),"Footer"),

	/** The donot show this again. */
	DONOT_SHOW_THIS_AGAIN(By.xpath("//div[@class='modal-content']//label//div[text()='Do not show me this again']"), "Do not show this again"),
	
	/** The save as draft button. */
	SAVE_AS_DRAFT_BUTTON(By.xpath("//button[contains(@class,'ac-btn ac-primary') and text()='Save as Draft']"), "Save As Draft button"),

	/** The save as ready button. */
	SAVE_AS_READY_BUTTON(By.xpath("//div[contains(@class,'ac-primary-box')]//button[contains(text(),'Save as Ready')]"), "Save As Ready Button"),

	/** The send for approval button. */
	SEND_FOR_APPROVAL_BUTTON(By.xpath("//div[contains(@class,'ac-primary-box')]//button[contains(text(),'Send for Approval')]"), "SendForApproval button"),
	
	/** The post now button. */
	POST_NOW_BUTTON(By.xpath("//button[contains(@class,'ac-btn ac-primary ac-block ') and text()='Post Now' and not(contains(@class,'disabled'))]"), "post Now button"),

	
	/** The post now option in post now modal pop up. */
	POST_NOW_OPTION_POST_NOW_MODAL_POP_UP(By.xpath("//div[@class='cretor-postnow-modal-wrp']//button[@class='ac-btn ac-primary']"), "The post now option in post now modal pop up"),
	
	/** The postt now button inactive. */
	POSTT_NOW_BUTTON_INACTIVE(By.xpath("//button[contains(@class,'ac-btn ac-primary ac-block disabled') and text()='Post Now']"),"Post Now button Inactive"),
	
	/** The post now option. */
	POST_NOW_OPTION(By.xpath("//button[text()='Post Now']"), "Post Now option"),
	
	/** The assign to campaign option. */
	ASSIGN_TO_CAMPAIGN_OPTION(By.xpath("//button[text()='Assign to Campaign']"), "Assign to campaign option"),
	
	AI_OPTION_BUTTON(By.xpath("//div[contains(@class,'ai-btn ai-creator-btn ai-anim-btn')]//img[@class='add__post--icon add-boost']"),"Ai Option Button"),

	AI_OPTION_DETAILVIEW(By.xpath("//div[@class='aia-bg-fill ai-results-Inactive ai-assets-not-selected']//div[@class='flex-content modal-title h4']//following::div[@class='flex modal-body']"),"AI Option DetailView"),
	
	AI_DETAILVIEW_CAPTIONS_AND_HASTAGS_BUTTON(By.xpath("//span[text()='Captions & Hashtags']"),"AI DetailView Captions Button"),
	
	AI_DETAILVIEW_CAPTIONS_AND_HASTAGS_ACTIVE(By.xpath("//li[@class='active']//span[text()='Captions & Hashtags']"),"AI DetailView Captions Button"),
	
	AI_DETAILVIEW_PROMPT_EDITOR(By.xpath("//div[@class='topHeader']//h3[text()='AI Prompt Editor']//following::img[contains(@src,'info-blue.svg')]"), "Prompt Editor Header"),
	
	AI_DETAILVIEW_PROMPT_EDITOR_ICON_DISABLE(By.xpath("//div[@class='topHeader']//h3[text()='AI Prompt Editor']//following::img[@class='info-inactive']"),"Prompt Editor Header Icon Inactive"),
	
	AI_DETAILVIEW_PROMPT_DESCRIPTION_CONTENT(By.xpath("//textarea[@id='exampleForm.ControlTextarea1' and @placeholder='Provide details about the caption you want the AI to generate and click Generate Captions']"),"AI Detailview Prompt Text Content"),

	AI_DETAILVIEW_PROMPT_CONTENT_FIELD("//textarea[@id='exampleForm.ControlTextarea1' and @placeholder and contains(text(),\"%s\")]","Ai DetailView Prompt Content Field"),

	AI_DETAILVIEW_VIEW_RECENT_PROMPT_BUTTON(By.xpath("//div[@class='aip-toggle aip-tog-off']//button[@class='tog-btn']"),"Ai Detailview Recent Prompt Button"),
	
	AI_DETAILVIEW_GENERATE_HASTAGS_ACTIVE(By.xpath("//div[@class='tog-options']//label//span[text()='Generate Hashtags']//following-sibling::div[@class='react-switch-section active']"),"Generate Hastags Active"),

	AI_DETAILVIEW_INCLUDE_EMOJI_ACTIVE(By.xpath("//div[@class='tog-options']//label//span[text()='Include Emoji']//following-sibling::div[@class='react-switch-section active']"),"Ai Detailview Include Emoji Active"),

	AI_DETAILVIEW_GENERATE_CAPTIONS_BUTTON(By.xpath("//button[@class='gnrc-btn blue-gnr ']//span[text()='Generate Captions!']"),"Ai Detailview Generate captions button"),

	AI_DETAILVIEW_GENERATE_CAPTIONS_DISABLE(By.xpath("//button[@class='gnrc-btn blue-gnr pEvents-none' and @disabled]"),"Ai Detailview Generate Captions Disable"),

	AI_GENERATING_ICON(By.xpath("//div[@class='aia-right-top']//div[@class='ai-bot-results ai-ht-off cmplnce-off']"),"AI_GENERATING_ICON"),

	AI_DETAILVIEW_PAGELOAD(By.xpath("//button[text()='Captions']//following::div[@class='accordion-collapse collapse show']"),"Ai Results Detailview PageLoad"),

	AI_DETAILVIEW_COMPLIANCE(By.xpath("//div[@class='compliance-wrap']//h2[text()='Compliance']"),"Ai Detailview Compliance"),

    AI_DETAILVIEW_COMPLIANCE_TEXT(By.xpath("//div[@class='compliance-wrap']//h2[text()='Compliance']//parent::div//p[text()]"),"AI Detailview Compliance Text"),

	AI_DETAILVIEW_CAPTIONS_BUTTON(By.xpath("//button[@class='accordion-button' and text()='Captions']//parent::h2"),"Ai Detailveiw Captions Button"),

	AI_GENERATED_CAPTIONS(By.xpath("//div[@class='aitc ai-tab-contents']//div[contains(@class,'ai-picks aitc-item')]"),"Ai Results Generated Contents"),

	AI_GENERATED_CAPTION_SELECT_BUTTON(By.xpath("//div[@class='aitc ai-tab-contents']//button[@class='ac-btn turquoise']//span[text()='Select']"),"AI Results Generated caption button"),

	AI_GENERATED_CAPTION_SELECTED_BUTTON(By.xpath("//div[@class='aitc ai-tab-contents']//button[@class='ac-btn turquoise']//span[text()='Selected']"),"AI Results Generated Caption Selected Button"),

	AI_GENERATED_HASTAGS(By.xpath("//div[@class='aitc ai-tab-hashtags']//div[contains(@class,'ai-picks aitht-item')]"),"AI Results Generated Hastags"),

	AI_RESULTS_HASTAGS_VIEW_OPENED(By.xpath("//div[@class='accordion-collapse collapse show']//div[@class='accordion-body']//div[@class='aitc ai-tab-hashtags']"),"AI Results Hastags View Opened"),

	AI_RESULTS_GENERATED_HASTAGS_SELECT_BUTTON(By.xpath("//div[@class='ai-picks aitht-item ']//button[@class='ac-btn turquoise']//span[text()='Select']"),"AI Results Generated caption button"),

	AI_HASTAGS_BUTON(By.xpath("//button[@class='accordion-button collapsed' and text()='hashtags']//parent::h2"),"Hastags button"),

	AI_HASTAGS_DEATILVIEW(By.xpath("//div[@class='aitc ai-tab-hashtags']"),"Ai Results Hastags DetailView"),

	AI_DETAILVIEW_CAPTIONS_AND_HASTAGS_CLOSE(By.xpath("//div[@class='modal-content']//div[@class='mod__close--icon']"),"Ai Detailview Captions And Hastags Close"),

	BE_SPECIFIC_HEADER_TEXT(By.xpath("//div[@class='ai-ideas']//strong[text()='Be specific:']//parent::p//span[text()]"),"Be Specific Header Text"),
	
	USE_RELEVANT_KEYWORDS_TEXT(By.xpath("//div[@class='ai-ideas']//strong[text()='Use relevant keywords:']//parent::p//span[text()]"),"Use Relevant Keywords Text"),
	
	BE_CREATIVE_TEXT(By.xpath("//div[@class='ai-ideas']//strong[text()='Be creative:']//parent::p//span[text()]"),"Be Creative Text"),
	
	TEST_DIFFERENT_PROMPT_TEXT(By.xpath("//div[@class='ai-ideas']//strong[text()='Test different prompts:']//parent::p//span[text()]"),"Test Different Prompt Text"),
	
	IMPERSONATE_TEXT(By.xpath("//div[@class='ai-ideas']//strong[text()='Impersonate a celebrity voice:']//parent::p//span[text()]"),"Impersonate Text"),
	
	USE_PRODUCT_PAGE_URLS(By.xpath("//div[@class='ai-ideas']//strong[text()='Use product page URLs:']//parent::p//span[text()]"),"Use Product Page Urls Text"),
	
	INFORMATION_ICONS_CLOSE_BUTTON(By.xpath("//div[@class='react-ripples ac-primary-box']//span[text()='X']"),"Information Icons Close"),
	
	AI_DETAILVIEW_AI_IMAGES(By.xpath("//span[text()='AI Image']"),"AI DETAILVIEW AI IMAGES"),
	
	AI_DETAILVIEW_AI_IMAGES_ACTIVE(By.xpath("//li[@class='active']//span[text()='AI Image']"),"AI DETAILVIEW AI IMAGES"),
	
	AI_IMAGES_EDITOR_WITH_ICON(By.xpath("//h3[text()='AI Image Editor']//following::img[@alt='Best Results From AI Assistant' and contains(@src,'info-blue.svg')]"),"Ai Images Editor with ICon"),
	
	AI_IMAGES_EDITOR_INFORMATION_ICON_DISABLE(By.xpath("//h3[text()='AI Image Editor']//following::img[@class='info-inactive' and contains(@src,'info-blue.svg')]"),"AI images Editor with ICon Disable"),
	
	AI_IMAGES_EDITOR_RECENT_PROMPT_BUTTON(By.xpath("//div[@class='aip-toggle aip-tog-off']//button[@class='tog-btn']"),"Ai Image Editor Recent Prompt Button"),
	
	ADDED_POST_DESCRIPTION_TEXT(By.xpath("//div[@class='DraftEditor-editorContainer']//span//parent::div//parent::div//div//span//span"),"Added Post Description Text"),

	AI_DETAILVIEW_IMAGE_PROMPT_ICON(By.xpath("//div[@class='topHeader']//h3[text()='AI Prompt Editor']//following::img[contains(@src,'info-blue.svg')]"),"Ai Image prompt Editor Icon"),

	AI_DETAILVIEW_AI_IMAGE_ICON(By.xpath("//div[@class='topHeader']//h3[text()='AI Image Editor']//following::img[contains(@src,'info-blue.svg')]"),"Ai DetailView Image Icon"),

	AI_RESULTS_DETAILVIEW_WANT_TO_ADD_IMAGE(By.xpath("//button[@class='gnrc-btn blue-gnr']//span[text()='Want to add image?']"),"AI_RESULTS_DETAILVIEW_WANT_TO_ADD_IMAGE"),

	AI_IMAGES_EDITOR_DESCRIPTION_CONTENTS(By.xpath("//textarea[@id='exampleForm.ControlTextarea1' and @placeholder='Provide details about the image you want the AI to generate and click Generate Image']"),"AI_IMAGES_EDITOR_DESCRIPTION_CONTENT"),

	/** The assign to campaign button. */
	ASSIGN_TO_CAMPAIGN_BUTTON(By.xpath("//button[text()='Assign to Campaign' and not(contains(@class,'disabled'))]"), "Assign to campaign button"),

	AI_DETAILVIEW_IMAGE_ASPECT_RATIO(By.xpath("//h3[text()='Image Aspect Ratio']//parent::div//div[@id='ai-image-aspect-ratio']"),"AI_DETAILVIEW_IMAGE_ASPECT_RATION"),

	AI_IMAGE_ICON_DETAILVIEW_WHAT_GOOD_TEXT(By.xpath("//h3[text()='What makes a good prompt?']"),"What makes Good Prompt Text"),

	AI_IMAGE_DETAILVIEW_ASPECT_RATIO_SQURAE_BUTTON(By.xpath("//div[@id='ai-image-aspect-ratio']//div[@class='iar__control css-s68f6i-control']//div[2]"),"AI_IMAGE_DETAILVIEW_ASPECT_RATIO_SQURAE_BUTTON"),

	AI_IMAGE_DETAILVIEW_SELECT_ASPECT_RATIO("//div[@class='iar__menu-list css-11unzgr']//div[contains(@class,'iar__option css-yt9ioa-option') and contains(text(),'%s')]","Ai Image Detailview Select Aspect Ratio"),

	AI_IMAGE_DETAILVIEW_GENERATE_IMAGE_BUTTON(By.xpath("//button[@class='gnrc-btn blue-gnr ']//span[text()='Generate Image!']"),"AI Generate Image Button"),

	AI_IMAGE_DETAILVIEW_GENERATING_IMAGE_VIEW(By.xpath("//div[contains(@class,'Typist')]//span[@class='typist-body-txt']//following-sibling::span"),"Ai Image DetailView Generating Image View"),

	AI_IMAGE_DETAILVIEW_GENERATED_IMAGE(By.xpath("//div[@class='ai-img-asset']//img[@class='m-ast-itm m-ast-img']"),"Ai Image DetailView Genearted Image"),

	AI_IMAGE_DETAILVIEW_PERFECT_BUTTON(By.xpath("//button[@class='gnrc-btn skyblue']//span[contains(text(),'Perfect!')]")," PerFect Use This Image Button"),

	/** The add search campaign section. */
//	ADD_SEARCH_CAMPAIGN_SECTION(By.xpath("//div[@class='modal-body']//h3[text()='Add / Search Campaign']"), "Add search campaign section"),
	
//	/** The search campaign input. */
//	SEARCH_CAMPAIGN_INPUT(By.xpath("//div[@class='modal-body']//input[@placeholder='Search campaign']"), "Search campaign input"),
//	
//	/** The searched campaign. */
//	SEARCHED_CAMPAIGN("//div[@class='modal-body']//div[@class='react-tags__suggestions']//ul//mark[text()='%s']", "Searched campaign"),
//	
//	/** The selected campaign. */
//	SELECTED_CAMPAIGN("//div[@class='modal-body']//div[@class='list-expanded-tag-item']//span[@title='%s']", "Selected campaign"),

	APPROVED_POPUP(By.xpath("//span[@class='success-mess-txt' and text()='Approved!']"),"Approved popup"),

	/** The default selected campaign. */
	DEFAULT_SELECTED_CAMPAIGN(By.xpath("//div[@class='modal-body']//div[@class='list-expanded-tag-item']//span[@title]"), "Default selected campaign"),
	
	/** The campaign section save button. */
	CAMPAIGN_SECTION_SAVE_BUTTON(By.xpath("//div[@class='modal-body']//h3[text()='Add / Search Campaign']//parent::div//button//span[text()='Save']"), "Campaign section save button"),
	
	/** The campaign section cancel button. */
	CAMPAIGN_SECTION_CANCEL_BUTTON(By.xpath("//div[@class='modal-body']//h3[text()='Add / Search Campaign']//parent::div//button//span[text()='Cancel']"), "Campaign section cancel button"),
	
	/** The alertbox post now button. */
	ALERTBOX_POST_NOW_BUTTON(By.xpath("//div[@class='modal-btn-grp-wraps']//button[text()='Post Now']"), "Alertbox postNow button"),

	/** The right side current date. */
	RIGHT_SIDE_CURRENT_DATE(By.xpath("//div[@class='current-time-stamp']//span"), "Current Date"),


	/** The view calender - more posts options. */
	VIEW_CALENDER_LINK(By.xpath("//span[@class='view-calendar-text' and text()='View Calendar']"), "View Calendar Link"),

	/** The view calender - more posts options. */
	VIEW_CALENDER_MORE_POSTS(By.xpath("//div[contains(@class,'fc-daygrid-day')]//div[@class='fc-daygrid-day-bottom']//a[text()]"), "View Calendar - more posts options"),

	/** The view calender - more posts options date */
	VIEW_CALENDER_MORE_POSTS_DATE(By.xpath("//div[@class='modal-body']//div[@class='head-section']//h3"), "View Calendar - more posts date"),

	/** The view calender - more option list of posts */
	VIEW_CALENDER_MORE_OPTION_LIST_OF_POSTS(By.xpath("//div[@class='main-cps']//div[@class='modal-body']//div[contains(@class,'creator-schedule-section-wrp')]"), "The view calender - more option list of posts "),




	/** The grid calender section. */
	GRID_CALENDER_SECTION(By.xpath("//div[@class='grid-calendar-section']"), "Grid Calendar"),

	/** The upcoming weekdays. */
	UPCOMING_WEEKDAYS(By.xpath("//span[text()='Upcoming Days']//parent::div//following-sibling::div[@class='grid-calendar-section']//span[contains(@class,'days')]"),
	        "DayS of the week"),

	/** The add to post sections close button. */
	ADD_TO_POST_SECTIONS_CLOSE_BUTTON(By.xpath("//div[@class='modal-content']//img[@alt='close']"), "Add to Post sections Close button"),

    // SAVE_TO_DATABASE_BUTTON(By.xpath("//button[text()='Save to Database']"),
    // "Save to database button"),

    // SEND_FOR_APPROVAL_BUTTON(By.xpath("//button[text()='Send For
    // Approval']"), "Send for approval button"),

	/** The post saved success message. */
	POST_SAVED_SUCCESS_MESSAGE(By.xpath("//span[@class='success-mess-txt']"), "Create Post Success Message"),
	
	/** The schedule post calendar view. */
	SCHEDULE_POST_CALENDAR_VIEW(By.xpath("//div[@class='modal-body']//div[@class='react-datepicker']"), "SchedulePost calendar view"),

	/** The previous month button. */
	CALENDAR_PREVIOUS_MONTH_BUTTON(By.xpath("//div[@class='react-datepicker']//button[text()='Previous Month']"), "Previous month button"),

	/** The next month button. */
	CALENDAR_NEXT_MONTH_BUTTON(By.xpath("//div[@class='react-datepicker']//button[text()='Next Month']"), "Next month button"),

	/** Calendar view - month name */
	CALENDAR_VIEW_MONTH_NAME(By.xpath("//div[contains(@class,'view-fullcalendar')]//div[@class='fc-toolbar-chunk'][2]//h2[text()]"), "Calendar view - month name "),

	/** Calendar view - month button*/
	CALENDAR_VIEW_CURRENT_MONTH_BUTTON(By.xpath("//div[contains(@class,'calendar-section')]//div[@class='fc-button-group']//button[@title='Month']"), "Calendar view - month button"),

	/** Calendar view - week button*/
	CALENDAR_VIEW_CURRENT_WEEK_BUTTON(By.xpath("//div[contains(@class,'calendar-section')]//div[@class='fc-button-group']//button[@title='Week']"), "Calendar view - week button"),

	/** Calendar view - Date button*/
	CALENDAR_VIEW_CURRENT_DATE_BUTTON(By.xpath("//div[contains(@class,'calendar-section')]//div[@class='fc-button-group']//button[@title='Today']"), "Calendar view - Date button"),


	/** The select date from calendar. */
	SELECT_DATE_FROM_CALENDAR(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week']//div[@aria-disabled='false']"), "Select date from calendar"),

	/** The select nextdate from calendar. */
	SELECT_NEXTDATE_FROM_CALENDAR(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week']//div[@aria-disabled='false'][2]"), "Select nextDate from calendar"),
	
	UPDATE_SAVED_POST_BUTTON(By.xpath("//button[@class='ac-btn ac-primary ac-block ' and text()='Update Saved Post']"),"Updated Saved Post Button"),

	//div[not(contains(@class,'react-datepicker__day--outside-month'))  and contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]
	DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]","Date Picker"),

	DISABLE_DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and @aria-disabled='true']","Disable Date Picker"),

	/** The calendarview cancel button. */
	CALENDARVIEW_CANCEL_BUTTON(By.xpath("//div[@class='footer-btn-section']//button[text()='Cancel']"), "CalendarView cancel button"),

	CALENDARDETAILVIEW_OK_BUTTON(By.xpath("//div[@class='footer-btn-section']//button[text()='Ok']"),"Calendar DetailView Ok Button"),
	
	/** The calendarview ok button. */
	CALENDARVIEW_OK_BUTTON(By.xpath("//div[@class='footer-btn-section']//button[text()='Schedule post']"), "CalendarView ok button"),

	SCHEDULE_DETAILVIEW_SCHEDULE_POST_BUTTON(By.xpath("//button[contains(@class,'ac-btn ac-primary ac-block') and text()='Schedule post']"),"Schedule Detailview Schedule Post Button"),
	
	SCHEDULE_TIME_BUTTON(By.xpath("//div[@class='react-datepicker__input-container']//input[@class='fltr-date-item fltr-from-date fltr-pt-time']"),"Schedule Time Button"),
	
	SCHEDULE_TIME_PICKER_DROPDOWN(By.xpath("//div[@class='react-datepicker__time-container ']//div[@class='react-datepicker__time']"),"Schedule Time Picker Dropdown"),
	
	SCHEDULE_TIME_PICKER("//div[contains(@class,'react-datepicker')]//div[@class='react-datepicker__time-box']//li[contains(@class,'time-list-item') and contains(text(),'%s')]","Schedule time Picker"),
	
	SCHEDULE_TIME_FIELD("//div[@class='react-datepicker__input-container']//input[contains(@value,'%s')]","Schedule time Field"),
	
	/** The goal edit cancel button. */
	GOAL_EDIT_CANCEL_BUTTON(By.xpath("//div[@class='modal-body']//span[@class='boost__box--title' and text()='Goal']//parent::div//parent::div//button[text()='Cancel']"), "GoalEdit cancel button"),
	
	/** The goal edit save button. */
	GOAL_EDIT_SAVE_BUTTON(By.xpath("//div[@class='modal-body']//span[@class='//div[@class='modal-body']//span[@class='boost__box--title' and text()='Goal']//parent::div//parent::div//button[text()='Cancel']' and text()='Goal']//parent::div//parent::div//button[text()='Save' and not(@disabled)]"), "GoalEdit save button"),
	
	/** The goal one. */
	GOAL_ONE(By.xpath("//div[@class='goal-list__wrp']//div//span[text()='Get more messages']"), "Goal one"),
	
	/** The goal two. */
	GOAL_TWO(By.xpath("//div[@class='goal-list__wrp']//div//span[text()='Get more engagement']"), "Goal two"),
	
	/** The goal three. */
	GOAL_THREE(By.xpath("//div[@class='goal-list__wrp']//div//span[text()='Get more website visitors']"), "Goal three"),
	
	/** The goal edit button. */
	GOAL_EDIT_BUTTON(By.xpath("//span[text()='Goal']//parent::div//following-sibling::div[@class='boost__media--icon cu-pointer']//img[@alt='edit']"), "GoalEdit button"),
	
	/** The selected goal. */
	SELECTED_GOAL(By.xpath("//div[contains(@class,'boost__goal')]//div//span[@class='boost__inner--title']"), "Selected goal"),
	
	/** The boost page close button. */
	BOOST_PAGE_CLOSE_BUTTON(By.xpath("//span[text()='Boost']//parent::div//img[@alt='close']"), "BoostPage close button"),
	
	/** The boost page save button. */
	BOOST_PAGE_SAVE_BUTTON(By.xpath("//span[@class='title' and text()='Boost']//ancestor::div[@class='sec-conn__wrp']//button[text()='Save' and not(@disabled)]"), "BoostPage save button"),

	/** The boost page remove button. */
	BOOST_PAGE_REMOVE_BUTTON(By.xpath("//span[@class='title' and text()='Boost']//ancestor::div[@class='sec-conn__wrp']//button//span[text()='Remove Boost' and not(@disabled)]"), "BoostPage remove button"),
	
	/** The boosted post success message. */
	BOOSTED_POST_SUCCESS_MESSAGE(By.xpath("//span[@class='success-mess-txt' and text()='Your post will be boosted with the settings you specified']"), "BoostedPost success message"),
	
	/** The add boost page. */
	ADD_BOOST_PAGE(By.xpath("//span[text()='Boost']//ancestor::div[@class='sec-conn__wrp']//div[@class='sec-main__content']"), "Add boost page"),
	
	/** The edit goal page. */
	EDIT_GOAL_PAGE(By.xpath("//span[@class='boost__box--title' and text()='Goal']//following-sibling::div[text()='What results would you like to see?']"), "EditGoal page"),

	/** The audience option. */
	AUDIENCE_OPTION(By.xpath("//div[contains(@class,'boost__white--box audience-wrp')]//span[@class='boost__box--title' and text()='Audience']//parent::div//following-sibling::div[contains(@class,'audience-option')]//span[text()='People you choose through targeting']"), "Audience option"),
	
	/** The audience details. */
	AUDIENCE_DETAILS(By.xpath("//div[contains(@class,'audience-option')]//div[@class='audience-details']//div[text()='Location:']//following-sibling::div[text()='Age: ']"), "Audience details"),
	
	/** The audience details edit button. */
	AUDIENCE_DETAILS_EDIT_BUTTON(By.xpath("//div[@class='audience-details']//img[@class='edit']"), "Audience details edit button"),
	
	/** The edit audience page. */
	EDIT_AUDIENCE_PAGE(By.xpath("//div[@class='modal-body']//span[@class='boost__box--title' and text()='Edit Audience']"), "Edit audience page"),
	
	/** The select gender section. */
	SELECT_GENDER_SECTION(By.xpath("//div[@class='modal-body']//div[@class='wb-fields gender-sec']//label[@for='gender-0']//following-sibling::label[@for='gender-1']//following-sibling::label[@for='gender-2']"), "Select gender section"),
	
	/** The select age section. */
	SELECT_AGE_SECTION(By.xpath("//div[@class='modal-body']//div[@class='wb-fields age-sec']//div[contains(@class,'wbf-inputs')]"), "Select age section"),

	/** The select interests section. */
	SELECT_INTERESTS_SECTION(By.xpath("//div[@class='modal-body']//div[@class='wb-fields ea-tops']//span[text()='Interests']//parent::div//following-sibling::div[contains(@class,'wbf-inputs')]"), "Select interests section"),

	/** The select locations section. */
	SELECT_LOCATIONS_SECTION(By.xpath("//div[@class='modal-body']//div[@class='wb-fields cea']//parent::div//following-sibling::div[@class='addzip r-mt1']//following-sibling::div//div[@class='map--wrp']"), "Select locations section"),

	/** The select locations text section. */
	SELECT_LOCATIONS_TEXT_SECTION(By.xpath("//div[@class='modal-content']//div[@class='wb-fields cea']//div[@class='qn' and text()]"), "Select locations section"),

	/** The save audience button. */
	SAVE_AUDIENCE_BUTTON(By.xpath("//div[@class='modal-body']//span[@class='boost__box--title' and text()='Edit Audience']//parent::div//following-sibling::div//button[text()='Save Audience']"), "Save audience button"),
	
	/** The edit audience cancel button. */
	EDIT_AUDIENCE_CANCEL_BUTTON(By.xpath("//div[@class='modal-body']//span[@class='boost__box--title' and text()='Edit Audience']//parent::div//following-sibling::div//button[text()='Cancel']"), "Edit audience cancel button"),
	
	/** The add boost fb disconnect button. */
	ADD_BOOST_FB_DISCONNECT_BUTTON(By.xpath("//div[@class='fb-acc--option']//button[text()='Disconnect']"), "AddBoost fb disconnect button"),
	
	/** The add boost fb change account button. */
	ADD_BOOST_FB_CHANGE_ACCOUNT_BUTTON(By.xpath("//div[@class='fb-acc--option']//button[text()='Change Account']"), "AddBoost fb changeAccount button"),
	
	/** The add boost fb disconnect alert cancel button. */
	ADD_BOOST_FB_DISCONNECT_ALERT_CANCEL_BUTTON(By.xpath("//span[@class='modal-itm-wraps modal-danger-wraps']//ancestor::div[@class='modal-content']//button[text()='Cancel']"), "AddBoost fb disconnect alert cancel button"),
	
	/** The add boost fb disconnect alert ok button. */
	ADD_BOOST_FB_DISCONNECT_ALERT_OK_BUTTON(By.xpath("//span[@class='modal-itm-wraps modal-danger-wraps']//ancestor::div[@class='modal-content']//button[text()='Ok']"), "AddBoost fb disconnect alert ok button"),
	
	/** The continue as button. */
	CONTINUE_AS_BUTTON(By.xpath("//div[@role='button']//span[contains(text(),'Continue as ')]"), "Continue as button"),

	/** The select ad account page. */
	SELECT_AD_ACCOUNT_PAGE(By.xpath("//div[@class='modal-content']//h3[text()='Please select an Ad Account']"), "Select ad account page"),
	
	/** The view calendar tableview. */
	VIEW_CALENDAR_TABLEVIEW(By.xpath("//div[contains(@class,'creator-view-calendar-wrp-modal')]//div[contains(@class,'fc-view')]//table[contains(@class,'fc-scrollgrid')]"), "ViewCalendar table view"),
	
	/** The scheduled post in monthly view. */
	SCHEDULED_POST_IN_MONTHLY_VIEW("//div[contains(@class,'creator-view-calendar-wrp-modal')]//div[contains(@class,'fc-dayGridMonth')]//div[@class='fc-event-main']//div[@class='post-content' and contains(text(),'%s')]", "Scheduled post in monthly view"),
	
	/** The scheduled post in weekly view. */
	SCHEDULED_POST_IN_WEEKLY_VIEW("//div[contains(@class,'creator-view-calendar-wrp-modal')]//div[contains(@class,'fc-dayGridWeek')]//div[@class='fc-event-main']//div[@class='post-content' and contains(text(),'%s')]", "Scheduled post in weekly view"),
	
	/** The scheduled post in daily view. */
	SCHEDULED_POST_IN_DAILY_VIEW("//div[contains(@class,'creator-view-calendar-wrp-modal')]//div[contains(@class,'fc-timeGridDay')]//div[@class='fc-event-main']//div[@class='post-content' and contains(text(),'%s')]", "Scheduled post in daily view"),
	
	/** The monthly view button. */
	MONTHLY_VIEW_BUTTON(By.xpath("//button[contains(@class,'fc-dayGridMonth-button')]"), "Monthly view button"),
	
	/** The weekly view button. */
	WEEKLY_VIEW_BUTTON(By.xpath("//button[contains(@class,'fc-dayGridWeek-button')]"), "Weekly view button"),
	
	/** The daily view button. */
	DAILY_VIEW_BUTTON(By.xpath("//button[contains(@class,'fc-timeGridDay-button')]"), "Daily view button"),
	
	/** The today button. */
	TODAY_BUTTON(By.xpath("//button[contains(@class,'fc-today-button')]"), "Today button"),
	
	/** The table view previous button. */
	TABLE_VIEW_PREVIOUS_BUTTON(By.xpath("//button[contains(@class,'fc-prev-button')]"), "TableView previous button"),
	
	/** The table view next button. */
	TABLE_VIEW_NEXT_BUTTON(By.xpath("//button[contains(@class,'fc-next-button')]"), "TableView next button"),
	
	/** The view calendar tableview close button. */
	VIEW_CALENDAR_TABLEVIEW_CLOSE_BUTTON(By.xpath("//div[@class='modal-content']//div//img[@alt='close']"), "ViewCalendar tableView close button"),
	
	/** The view calendar post detailedview. */
	VIEW_CALENDAR_POST_DETAILEDVIEW(By.xpath("//div[@class='modal-body']//div[@class='cal-social-preview-sec']//div[@class='p-header']"), "ViewCalendar post detailedView"),
	
	/** The view calendar post close button. */
	VIEW_CALENDAR_POST_CLOSE_BUTTON(By.xpath("//div[@class='cal-social-preview-sec']//parent::div[@class='modal-body']//preceding-sibling::div[@class='close']//img"), "ViewCalendar post close button"),
	
	/** The unsaved changes alertbox. */
	UNSAVED_CHANGES_ALERTBOX(By.xpath("//div[@class='modal-body']//div[text()='You have unsaved changes that will be lost. Continue anyway?']"), "Unsaved changes alertbox"),
	
	/** The alertbox cancel button. */
	ALERTBOX_CANCEL_BUTTON(By.xpath("//div[@class='modal-content']//button[text()='Cancel']"), "Alertbox cancel button"),
	
	/** The alertbox ok button. */
	ALERTBOX_OK_BUTTON(By.xpath("//div[@class='modal-content']//button[text()='Ok']"), "Alertbox ok button "),
	
	INSTAGRAM_CONTENT_LIMIT(By.xpath("//div[contains(@class,'tw-content')]//p[@class='letter-count-text']//span[@class='l-total']"),"Instagram Total limit"),
	
	CONTENT_TOTAL_COUNT_VALUE(By.xpath("//div[contains(@class,'tw-content')]//p[@class='letter-count-text']//span[@class='l-count']"),"Twitter Content Total Value Count"),
	
	CONTENT_TOTAL_COUNT("//div[contains(@class,'tw-content')]//p[@class='letter-count-text']//span[@class='l-count' and text()='%s']","Content Total Value Count"),
	
	/** The twitter content limit. */
	TWITTER_CONTENT_LIMIT(By.xpath("//div[contains(@class,'tw-content')]//p[@class='letter-count-text']//span[@class='l-total']"), "Twitter content limit"),
	
	TWITTER_CONTENT_TOTAL_COUNT_VALUE(By.xpath("//div[contains(@class,'tw-content')]//p[@class='letter-count-text']//span[@class='l-count']"),"Twitter Content Total Value Count"),
	
	/** The linkedin content limit. */
	LINKEDIN_CONTENT_LIMIT(By.xpath("//div[contains(@class,'tw-content')]//p[@class='letter-count-text']//span[@class='l-total']"), "Linkedin content limit"),
	
	/** The linkedin content limit. */
	CONTENT_LIMIT(By.xpath("//div[contains(@class,'tw-content')]//p[@class='letter-count-text']//span[@class='l-total']"), "Linkedin content limit"),
	
	/** The update savedpost button. */
	UPDATE_SAVEDPOST_BUTTON(By.xpath("//button[contains(@class,'ac-btn ac-primary ac-block ') and text()='Update Saved Post' or text()='Update Post' and not(contains(@class,'disabled'))]"), "Update savedPost button"),

	SELECT_DESCRIPTION_TAG_DROPDOWN(By.xpath("//div[@class='ral-mSuggestions']//div[contains(@id,'mention-option')]"),"SELECT_DESCRIPTION_TAG_DROPDOWN"),

	/** The select description box tags. */
	SELECT_DESCRIPTION_BOX_TAGS("//div[@class='ral-mSuggestions']//div[contains(@id,'mention-option')]//*[text()='%s']", "Select description box tags"),
	
	/** The added description tag. */
	ADDED_DESCRIPTION_TAG("//div[@class='DraftEditor-editorContainer']//a[contains(@href,'facebook.com')]//span[text()='%s']", "Added description tag"),
	
	/** The scheduled post description tag. */
	SCHEDULED_POST_DESCRIPTION_TAG("//div[contains(@class,'list-item')]//p[@class='post-message' and contains(@title,'%s')]//a[@href]//span[text()='%s']", "Scheduled post description tag"),
	
	/** The created post description tag. */
	CREATED_POST_DESCRIPTION_TAG("//div[@class='fade tab-pane active show']//div[@class='st-tc-item']//p[@class='post-message' and contains(@title,'%s')]//a[@href]//span[text()='%s']", "Created post description tag"),
	
	/** Employee advocacy tab. */
	EMPLOYEE_ADVOCACY_TAB(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Employee Advocacy']"), "Employee advocacy tab"),

	/** Advocacy tab overview. */
	ADVOCACY_TAB_OVERVIEW(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Overview']"), "Advocacy tab overview"),
	
	/** The edited post save button. */
	EDITED_POST_SAVE_BUTTON(By.xpath("//div[contains(@class,'calendar-edit__modal')]//button[text()='Save']"), "Edited Post Save Button"),

	/** The post description ai text. */
	POST_DESCRIPTION_AI_TEXT(By.xpath("//div[@class='DraftEditor-editorContainer']//span[@data-offset-key]//span"),"Post Description AI Text"),
	
	/** The post descriptions ai tags. */
	POST_DESCRIPTIONS_AI_TAGS(By.xpath("//div[@class='DraftEditor-editorContainer']//span[@class='hngfxw3']//span"),"Post Description Tags"),

	/** The post descriptions with image. */
	POST_DESCRIPTIONS_WITH_IMAGE(By.xpath("//div[contains(@class,'image-roll-holder')]//div[@class='ctvm ct-img']//div[@class='img-thumb']//img"),"Post Descriptions with Image"),
	
	/** The post descriptions with videos. */
	POST_DESCRIPTIONS_WITH_VIDEOS(By.xpath("//div[contains(@class,'image-roll-holder')]//div[contains(@class,'ct-video')]//div//video"),"Post Descriptions with Video"),
	
	/** The ai option inactive button. */
	AI_OPTION_INACTIVE_BUTTON(By.xpath("//div[@class='ai-btn ai-creator-btn ai-anim-btn ai-events-none ']//img[@alt='AI']"),"AI Option InActive"),

	POST_PREVIEW_TAGS(By.xpath("//div[@class='post-preview']//div[contains(@class,'p-body previewtLinks')]//p//a[@rel='noreferrer noopener']"),"Post Preview Tags"),

	POST_PREVIEW_DESCRIPION_FIELD("//div[@class='post-preview']//div[contains(@class,'p-body previewtLinks')]//p[contains(@title,'%s')]","POST_PREVIEW_DESCRIPION_FIELD"),
	
	/** The my images tab tag. */
	MY_IMAGES_TAB_TAG("", ""),

	/** The brand images tab tag. */
	BRAND_IMAGES_TAB_TAG("", ""),

	/** The brand images tab favourite tags. */
	BRAND_IMAGES_TAB_FAVOURITE_TAGS("", ""),

	/** The my videos tab tag. */
	MY_VIDEOS_TAB_TAG("", ""),

	/** The brand videos tab tag. */
	BRAND_VIDEOS_TAB_TAG("", ""),
	
	/**  New Enums *. */
	
	SEND_FOR_APPROVAL_POPUP(By.xpath("//div//span[text()='Your post has been sent for approval']"),"The Send for Approval Popup Message"),
	
    /** The approvalpost edit alert. */
    APPROVALPOST_EDIT_ALERT(By.xpath("//div[contains(text(),'Are you sure you want to edit') and @class='modal-message-wraps-text']//parent::div[@class='edit-approval-post-wrp-modal']"),"The Approval for Edit"),
    	
	/** The schedule section time button. */
	SCHEDULE_SECTION_TIME_BUTTON(By.xpath("//div[@class='react-datepicker__input-time-container']//input[@placeholder='Time']"), "Schedule section date button"),

	SCHEDULED_SECTION_TIME("//div[@class='react-datepicker__input-time-container']//input[@placeholder='Time' and @value=\"%s\"]","Scheduled Section Time"),

	SCHEDULING_POST_PAST_ALERT(By.xpath("//div[text()='Sorry, you cannot schedule a post in the past.']"),"Scheduling Post Past Alert"),

	/** The schedule section header month. */
	SCHEDULE_SECTION_HEADER_MONTH(By.xpath("//div[@class='react-datepicker__header ']//div[contains(@class,'current-month')]"), "Schedule section Header Month"),
		
	/** The calendar time field. */
	CALENDAR_TIME_FIELD(By.xpath("//div[@class='react-datepicker__input-time-container']//input[@placeholder='Time']"),
     "Schedule view Time field"),
	 
	/** The content tab calendar. */
	CONTENT_TAB_CALENDAR(By.xpath("//div[contains(@class,'sub-nav-tabs')]//ul//li//span[contains(text(),'Calendar')]"),
			"Content tab Calendar"),
	
	/** The content tab posts. */
	CONTENT_TAB_POSTS(By.xpath("//div[contains(@class,'sub-nav-tabs')]//ul//li//span[contains(text(),'Posts')]"),
			"Content tab Posts"),
	
	UPLOADED_IMAGE_TOOLTIP_DESCRIPTION("//div[@class='common-tooltip--wrp' and contains(text(),'%s')]","Uploaded Image toolTip Description"),
	
	/** The approvalpost edit ok. */
	APPROVALPOST_EDIT_OK(By.xpath("//div[contains(text(),'Are you sure you want to edit')]//ancestor::div//div[@class='modal-footer']//following::button[text()='OK']"),"The Approval Edit Ok button"),
	
	/** The ai subscribtion video play. */
	AI_SUBSCRIBTION_VIDEO_PLAY(By.xpath("//div[@role='tooltip']//div[@class='aicoach-body']//div[@class='aicoach-cnt']//div[@class='ai-coach-video']"),"AI Subscribtion Video Play"),
	
	ADD_SEARCH_CAMPAIGN_SECTION(By.xpath("//h3[text()='Add / Search Campaign']"), "Add search campaign section"),

	//Campaign Locators - create post page enum
	CAMPAIGNS_LIST_CAMPAIGN_BY_INDEX("//div[@class='asc-list']//label[contains(@id,'alpha-data')][%s]//input", "CAMPAIGNS_LIST_CAMPAIGN_BY_INDEX"),

	CAMPAIGNS_LIST_SELECTED_CAMPAIGN_BY_INDEX("//div[@class='asc-list']//label[contains(@id,'alpha-data') and contains(@class,'active')][%s]", "CAMPAIGNS_LIST_SELECTED_CAMPAIGN_BY_INDEX"),

	SELECTED_CAMPAIGNS_COUNT(By.xpath("//div[@class='asc-options']//span[contains(text(),'Selected')]"), "SELECTED_CAMPAIGNS_COUNT"),

	CAMPAIGN_SECTION_CLOSE_BUTTON(By.xpath("//div[@class='modal-body']//h3[text()='Add / Search Campaign']//parent::div//preceding-sibling::div//img"), "CAMPAIGN_SECTION_CLOSE_BUTTON"),

	SEARCH_CAMPAIGN_INPUT(By.xpath("//input[@placeholder='Search Campaign']"), "Search campaign input"),
	
	/** The searched campaign. */
	SEARCHED_CAMPAIGN("//div[@class='asc-list']//span[text()='%s']//parent::label[@class='checkbox-item']", "Searched campaign"),
	
	/** The selected campaign. */
	SELECTED_CAMPAIGN("//div[@class='asc-list']//span[text()='%s']//parent::label[@class='checkbox-item active']", "Selected campaign"),
		
	/** The searched campaign. */
	SEARCH_CAMPAIGN_LIST_OF_CAMPAIGNS("//div[@class='asc-list']//span[text()='%s']//parent::label[@class='checkbox-item']", "SEARCH_CAMPAIGN_LIST_OF_CAMPAIGNS"),
	
	SEARCH_CAMPAIGN_PAGE_LIST_OF_CAMPAIGNS(By.xpath("//div[@class='asc-list']//span//parent::label[@class='checkbox-item']"), "SEARCH_CAMPAIGN_LIST_OF_CAMPAIGNS"),

	/** The selected campaign. */
	SEARCH_CAMPAIGN_LIST_OF_SELECTED_CAMPAIGNS("//div[@class='asc-list']//span[text()='%s']//parent::label[@class='checkbox-item active']", "SEARCH_CAMPAIGN_LIST_OF_SELECTED_CAMPAIGNS"),
	
	SEARCH_CAMPAIGN_PAGE_LIST_OF_SELECTED_CAMPAIGNS(By.xpath("//div[@class='asc-list']//span//parent::label[@class='checkbox-item active']"), "SEARCH_CAMPAIGN_LIST_OF_SELECTED_CAMPAIGNS"),

	PERSONALIZED_TAGS(By.xpath("//div[@class='personalizedTag']//img[@alt='personalizedTag']//following-sibling::span"),"PersonalizedTag"),
	
	EDIT_SCHEDULE_BUTTON(By.xpath("//button[@class='ac-btn ac-secondary ac-block filter-sc-btn' and text()='Edit Schedule']"),"Edit Schedule button"),

	EDIT_DETAILVIEW_SECHEDULE_TIME(By.xpath("//div[@class='package-id-holder mb-20']//div[@class='title-text-section']//span[2]"),"Edit Detailview Schedule Time"),

	EDIT_DETAILVIEW_CLOSE(By.xpath("//div[@class='mod__close--icon header__close--icon']//img[@alt='close']"),"Edit Detailview Close"),

	SCHEDULE_TIME(By.xpath("//input[@class='react-datepicker-time__input' and @name='time-input']"),"Schedule Time"),
	
	/** The ai video donot show me checkbox. */
	AI_VIDEO_DONOT_SHOW_ME_CHECKBOX(By.xpath("//div[@class='aicoach-body']//label[@class='checkbox-item']//span[@class='checkbox-hover']//input[@name='localizePost']"),"AI Subscribtion Video Check Box"),
	
	//Syndicate Option
	
	SYNDICATE_OPTION_VIEW(By.xpath("//div[@class='modal-body']//h3[@class='glbl__title--txt' and text()='Syndicate']"),"Syndicate Option View"),
	
	SYNDICATE_WHERE_HEADER(By.xpath("//div[@class='glbl__modal--card card']//div[@class='card-header' and text()='Where']"),"SYNDICATE_WHERE_HEADER"),
	
	SYNDICATE_ALL_FRANCHISORS_CONSULTANT_BUTTON(By.xpath("//div//label[text()='All Franchise Consultants']"),"Syndicate All Franchisors Consultant Button"),
	
	SYNDICATE_SELECT_FANCHISORS_CONSULTANT_BUTTON(By.xpath("//div//label[text()='Select Franchise Consultants']"),"SYNDICATE_FANCHISORS_CONSULTANT_BUTTON"),
	
	SYNDICATE_SELECT_FRANCHISES_CONSULTANT(By.xpath("//div[contains(@id,'franchise_consultants')]//div[@class='form-group form-field-item']//div[@class='ds-dropdown']//button//span"),"SYNDICATE_SELECT_FRANCHISES_CONSULTANT"),
	
	SYNDICATE_SELECT_FRANCHISES_SEARCH(By.xpath("//div[@class='rs-drp__input-container css-ackcql']//input[@class='rs-drp__input']"),"SYNDICATE_SELECT_FRANCHISES_SEARCH"),
	
	SYNDICATE_FRANCHISES_DROPDOWN(By.xpath("//div[@class='ds-dropdown']//div[contains(@id,'syndicate-dropdown')]"),"SYNDICATE_FRANCHISES_DROPDOWN"),
	
	SYNDICATE_SELECT_FRANCHISES_DROPDOWN("//div[@class='rs-drp__menu css-ik6y5r']//div[contains(@class,'rs-drp__option') and contains(text(),\"%s\")]","SYNDICATE_SELECT_FRANCHISES_DROPDOWN"),
	
	SYNDICATE_SELCETD_LIST_FROM_DROPDOWN("//div[@class='modal-body']//div[@class='select-location-section-wrp']//div[contains(@class,'grid-section')]//span[text()='%s']","SYNDICATE_SELECTED_LISTFROM_DROPDOWN"),

	SYNDICATE_ALL_BRAND(By.xpath("//ul[@class='card-header-tabs nav nav-tabs']//label[text()='All Brands']"),"Syndicate All Brand"),

	SYNDICATE_SPECIFIC_BRAND(By.xpath("//ul[@class='card-header-tabs nav nav-tabs']//label[text()='Specific Brands']"),"Syndicate Specific Brand"),

	SYNDICATE_SPECIFIC_BRAND_LOCATION_LIST(By.xpath("//div[@class='select-location-section-wrp']//div[@class='card-body']"),"SYNDICATE_SPECIFIC_BRAND_LOCATION_LIST"),

	/** The boost Button */
	ADD_BOOST_TO_POST_CONTENT(By.xpath("//div[@class='add__post--main']//div[contains(@class,'add-boost')]//img"), "Boost button"),
	
	/** The boost Hover */
	BOOST_HOVER_CONTENT(By.xpath(" //div[@class='common-tooltip--wrp' and text()='Boost']"), "Boost hover content"),
	
	/** The Call to action button. */
	CALL_TO_ACTION_BUTTON(By.xpath("//div[contains(@class,'add__post')]//img[@alt='GooglePost']"), "The call to action button"),
	
	/** Creator placeholder text. */
	CREATOR_PLACEHOLDER_TEXT("//div[@class='public-DraftEditorPlaceholder-root']//div[@id='placeholder-editor-location-creator' and text()='%s']", " Creator placeholder text."),
	
	
	/***HAST TAG***/
	HASH_TAG_TAB(By.xpath("//div[contains(@class,'add__post--icon')]//img[contains(@src,'hash-tags.svg')]"),"Hash Tag Tab"),
	
	HASH_TAG_DETAILVIEW(By.xpath("//h3[text()='Hashtags']//parent::div[@class='modal-body']//div"),"Hash Tag DetailView"),
	
	HASH_TAG_SEARCH_BAR(By.xpath("//h3[text()='Hashtags']//parent::div//input[@placeholder='Search / Add Hashtag']"),"Hash Tag Search Bar"),
	
	HASH_TAG_ADD_BUTTON(By.xpath("//button[@class='add-items']//img[@alt='Add HashTags']"),"Hash Tag Add Button"),
	
	HASH_TAG_SELECT_ALL_CHECKBOX(By.xpath("//span[text()='Select All']//parent::label//span[@class='checkbox-hover']//input[@name='All']"),"Hash Tag Select All Check box"),
	
	HASH_TAG_LIST(By.xpath("//div[@class='aih-w-group']//div[@class='ai-hashtags']//div[@class='ai-picks aitht-item cursor-pointer ']//div[@class='ait-front']//span[text()]"),"Has Tag List"),
	
	HASH_TAG_SELECT_LIST("//div[@class='aih-w-group']//div[@class='ai-hashtags']//div[@class='ai-picks aitht-item cursor-pointer ']//div[@class='ait-front']//span[text()='%s']","SELECT HASH TAG LIST"),
	
	HASH_TAG_SELCTED_IN_LIST("//div[@class='aih-w-group']//div[@class='ai-hashtags']//div[@class='ai-picks aitht-item cursor-pointer active']//div[@class='ait-front']//span[text()='%s']","Selected Hash Tag"),
	
	HASH_TAG_DONE_BUTTON(By.xpath("//button[@class='ac-btn ac-primary ac-block' and text()='Done']"),"Hash Tag Done Button"),
	
	HASH_TAG_DELETE_BUTTON(By.xpath("//button[@class='aih-w-right-btn']//img[@alt='Delete HashTags']"),"Hash Tag Delete Button"),
	
	HASH_TAG_CLOSE(By.xpath("//div[@class='mod__close--icon']//img[@alt='close']"),"Hash Tag Close Option"),
	
	HASH_TAG_SELECTED_COUNT(By.xpath("//span[@class='sel-count-wrap']//span[@class='sel-count']"),"Hash Tag Selected Count"),
	
	/** The Call to action - select action dropdown. */
	CALL_TO_ACTION_ACTION_DROPDOWN(By.xpath("//div[@id='boost-duration-dropdown']//div[@class='glbl__dropdown__control css-s68f6i-control']"), "The call to action select action dropdown"),

	/** The Call to action - select book now option. */
	CALL_TO_ACTION_SELECT_BUY_NOW_OPTION(By.xpath("//div[@id='boost-duration-dropdown']//div[@class='glbl__dropdown__option css-yt9ioa-option' and text()='Buy Now']"), "The call to action select buy now option"),

	/** The Call to action - Action URL. */
	CALL_TO_ACTION_ACTION_URL(By.xpath("//div[@class='modal-body']//input[@name='action_url']"), "The call to action action URL"),

	/** The Call to action - Done button. */
	CALL_TO_ACTION_DONE_BUTTON(By.xpath("//div[@class='modal-body']//div[@class='btn-wrp-separate']//button[@type='button' and text()='Done']"), "The call to action done button"),

	/** The Call to action Button in preview */
	CALL_TO_ACTION_BUTTON_IN_PREVIEW(By.xpath("//div[contains(@class,'new-preview')]//div[contains(@class,'react-ripples ac-secondary')]//button[@class='ac-btn ac-secondary-white ac-outline ac-block border-0']"), "The call to action button preview"),

	/** The Call to action Button in posts page */
	CALL_TO_ACTION_BUTTON_IN_POSTS_DETAIL_VIEW(By.xpath("//div[@class='new-preview']//div[@class='np-content']//button[contains(@class,'ac-btn ac-secondary')]"), "The Call to action Button in posts page"),


	/** The Call to action image in posts page */
	CALL_TO_ACTION_IMAGE_IN_POSTS_DETAIL_VIEW(By.xpath("//div[@id='detailed-tabs-tabpane-facebook']//div[@class='new-preview']//div[@class='np-img']//img[@class='img-thumb']"), "The Call to action image in posts page "),


	/** Add Link - Customize checkbox */
	ADD_LINK_CUSTOMIZE_CHECKBOX(By.xpath("//div[@class='modal-content']//label[@class='checkbox-item']//div[text()='Customize']//parent::label//span//input[@type='checkbox']"), "Add Link - Customize checkbox"),

	/** Add Link - Customize Business link */
	ADD_LINK_CUSTOMIZE_BUSINESS_LINK(By.xpath("//div[@class='modal-content']//div[contains(@class,'form-group')]//input[@type='text']"), "Add Link - Customize Busniess link"),

	/** Add Link - Customize thumbnail option */
	ADD_LINK_CUSTOMIZE_THUMBNAIL_OPTION(By.xpath("//div[@class='alc-item']//h6[contains(text(),'Thumbnail')]//parent::div//button[@class='drag__drop--btn' and text()='Browse']"), "Add Link - Customize thumbnail option"),

	ADD_NEW_VIDE_BROWSE_BUTTON(By.xpath("//div//button[@class='drag__drop--btn' and text()='Browse']"),"ADD_NEW_VIDE_BROWSE_BUTTON"),

	/** Add Link - Customize title option */
	ADD_LINK_CUSTOMIZE_TITLE_OPTION(By.xpath("//div[@class='alc-item']//h6[contains(text(),'Title')]//parent::div//div//input[@name='link_preview_title']"), "Add Link - Customize title option"),

	/** Add Link - Customize decsription option */
	ADD_LINK_CUSTOMIZE_DESCRIPTION_OPTION(By.xpath("//div[@class='alc-item alc-ta']//h6[text()='Description']//parent::div//div//textarea[@class='form-control  ']"), "Add Link - Customize description option"),

	/** Add Link - Customize Done button */
	ADD_LINK_CUSTOMIZE_DONE_BUTTON(By.xpath("//div[@class='modal-content']//div[@class='btn-wrp-separate']//button[@type='button' and text()='Done']"), "Add Link - Customize Done button"),

	/** Browse image for Link */
	ADD_LINK_CUSTOMIZE_BROWSE_IMAGE(By.xpath("//div[@class='at-cnt creator-post-media-wrp']//input[@type='file' and @accept]"), "Browse image for Link"),

	MYIMAGE_LIST(By.xpath("//div[@class='masonry-grid_column']//div[@class='m-item']//div[@class='mastg-main']//div[@class='sm-txt-top']"),"MyImage List"),

	/** The marketing tab Targetting page */
	MARKETING_TAB_TARGETTING(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Targeting']"), "Marketing tab Targetting page"),

	/** The Instagram padded image in preview */
	INSTAGRAM_PADDED_IMAGE_IN_PREVIEW(By.xpath("//div[@class='post-preview']//div[@class='am-media-preview pmg']//div//img[contains(@src,'c_pad')]"), "Instagram padded image in preview"),

	/** The Instagram cropped image in preview */
	INSTAGRAM_CROPPED_IMAGE_IN_PREVIEW(By.xpath("//div[@class='post-preview']//div[@class='am-media-preview pmg']//div//img[contains(@src,'c_fill')]"), "Instagram cropped image in preview"),

	PLEASE_START_TYPING_FIRST_ALERT(By.xpath("//div[@class='instaAlert']//p[text()='Please start typing first.']"),"PLEASE_START_TYPING_FIRST_ALERT"),

	SCHEDULE_DATE_PICKER_NEXT_MONTH(By.xpath("//div[contains(@class,'react-datepicker')]//span[text()='Next Month']//parent::button[@aria-label='Next Month']"),"Schedule date picker next month button"),

	VIEW_CALENDAR_NEXT_MONTH(By.xpath("//div[contains(@class,'cal-lc-views calendar')]//div[@class='fc-button-group']//button[contains(@class,'fc-next-button')]"),"View calendar - Next month button"),

	/** Selecting specific date in date picker */
	SPECIFIC_DATE_FROM_DATE_PICKER(By.xpath("//div[@class='react-datepicker']//div[@class='react-datepicker__week']//div[contains(@class,'react-datepicker') and text()='13']"), "Selecting specific date in date picker "),


	/** Drag and drop from date */
	DRAG_AND_DROP_FROM_DATE(By.xpath("//tbody//td[contains(@data-date,'-13')]//div[@class='fc-daygrid-day-frame fc-scrollgrid-sync-inner']//div[@class='fc-daygrid-day-events']"), "Drag and drop from date"),

	/** Drag and drop to date */
	DRAG_AND_DROP_TO_DATE(By.xpath("//tbody//td[contains(@data-date,'-14')]//div[@class='fc-daygrid-day-frame fc-scrollgrid-sync-inner']"), "Drag and drop to date"),

	/** Drag and drop from date in weekly view */
	DRAG_AND_DROP_FROM_DATE_WEEKLY_VIEW(By.xpath("//tbody//td[contains(@class,'fc-daygrid-day')]//div[@class='fc-daygrid-day-frame fc-scrollgrid-sync-inner']//div[contains(@class,'creator-schedule')]"), "Drag and drop from date - Weekly view"),

	/** Drag and drop to date in weekly view */
	DRAG_AND_DROP_TO_DATE_WEEKLY_VIEW(By.xpath("//tbody//td[contains(@class,'fc-day fc-day')]//div[@class='fc-daygrid-day-frame fc-scrollgrid-sync-inner']"), "Drag and drop to date - Weekly view"),


	/** Dragged data in calendar view */
	DATA_AFTER_DRAGGING_IN_CALENDAR_VIEW(By.xpath("//tbody//td[contains(@data-date,'-14')]//div[@class='fc-event-main']//div[contains(@class,'creator-schedule')]"), "Dragged data in calendar view"),


	/** Data before dragging in calendar view */
	DATA_BEFORE_DRAGGING_IN_CALENDAR_VIEW(By.xpath("//tbody//td[contains(@data-date,'-13')]//div[@class='fc-event-main']//div[contains(@class,'creator-schedule')]"), "Data before dragging in calendar view "),

	/** Scheduled post in calendar */
	SCHEDULED_POST_IN_CALENDAR("//div[contains(@class,'creator-schedule')]//div[@class='grid-section']//p[text()='%s']","Scheduled post in calendar"),

	/** Daily view data */
	DAILY_VIEW_DATA(By.xpath("//tbody//td[contains(@class,'fc-timegrid-col')]//div[@class='fc-event-main']//div[contains(@class,'creator-schedule')]"), "Daily view data"),


	/** Daily view drop data */
	DAILY_VIEW_DROP_DATA(By.xpath("//tbody//tbody//tr//td[2]"), "Daily view drop data "),


	/** Timestamp before dragging data */
	TIMESTAMP_BEFORE_DRAGGING_DATA(By.xpath("//tbody//td[contains(@class,'fc-daygrid-day')]//div[@class='fc-event-main']//div[contains(@class,'creator-schedule')]//div//div[@class='time-stamp' and text()]"), "Timestamp before dragging data"),

	/** Timestamp after dragging data */
	TIMESTAMP_AFTER_DRAGGING_DATA(By.xpath("//tbody//td[contains(@class,'fc-daygrid-day')]//div[@class='fc-event-main']//div[contains(@class,'creator-schedule')]//div//div[@class='time-stamp' and text()]"), "Timestamp after dragging data"),

	/** Timestamp after dragging data */
	TIMESTAMP_IN_DAILY_VIEW(By.xpath("//div[@class='fc-timegrid-col-frame']//div[@class='fc-event-main']//div//div[@class='time-stamp' and text()]"), "Timestamp after dragging data"),

	/** Calendar data */
	DAILY_VIEW_CALENDAR_DATA(By.xpath("//div[@class='fc-event-main']//div[contains(@class,'creator-schedule')]"), "Calendar data"),

	/* Specific date*/
	SPECIFIC_DATE(By.xpath("//div[@class='modal-content']//div[@class='react-datepicker__week']//div[contains(@class,'react-datepicker__day--022')]"), "Specific date"),

    /* List view timestamp */
     LISTVIEW_POST_TIMESTAMP(By.xpath("//div[@class='li-view-main']//div[@class='header-section']//div[@class='p-title']//h6[text()]"),"Listview timestamp"),

	DAY_WITHOUT_APPROVAL(By.xpath("//span[@class='days-without-bg']"),"Day without Approval"),

	DAY_WITH_APPROVAL_FIELD("//div[@class='grid-calendar-section']//span[@class='days-approval-bg' and text()='%s']","Day With Aproval Field"),

	DAY_WITH_GREEN_COLOR("//span[@class='days-bg' and text()='%s']","Day with Green Color"),

	ONE_POST_WAITING_FOR_APPROVAL_TOOLTIP(By.xpath("//div[contains(@class,'grid-cal-tooltip-section')]//div[text()='1 Post waiting for approval.']"),"ONE_POST_WAITING_FOR_APPROVAL_TOOLTIP"),

	TWO_POST_LINED_UP_TOOLTIP(By.xpath("//div[contains(@class,'grid-cal-tooltip-section')]//div[text()='You have 2 posts lined up for this day with 1 requiring approval.']"),"TWO_POST_LINED_UP_TOOLTIP"),

	TWO_POST_SCHEDULED_THIS_DAY_TOOLTIP(By.xpath("//div[@class='grid-cal-tooltip-section day-03 apc-off']//div[text()='2 Posts scheduled for this day.']"),"Two Post Scheduled This Day ToolTip"),

	/* Calendar view - week data */
	CALENDAR_VIEW_WEEKLY_HEADER_DATA(By.xpath("//div[contains(@class,'cal-lc-views calendar')]//div[contains(@class,'fc-header-toolbar')]//h2[@class='fc-toolbar-title' and text()]"),"Calendar view - weekly header data"),

	PUBLISH_TEXT_WITH_STAR(By.xpath("//p[@class='label-txt' and text()='Publish ']//span[@class='mandatory cursor-help']"),"Publish text with star"),

	TRANSLATE_BUTTON_INACTIVE(By.xpath("//div[@class='translateMain pointer-events-none']//div[@class='translateTextWrap']//div[@class='sign-text']"),"Translate button inactive"),

	TRANSLATE_BUTTON_ACTIVE(By.xpath("//div[@class='translateMain ']//div[@class='translateTextWrap']//div[@class='sign-text']"),"Translate button active"),

	PUBLISH_SWITCH_INACTIVE(By.xpath("//div[@class='tab-content']//p[text()='Publish ']//parent::div//div[@class='react-switch-section ']"),"Publish switch inactive"),

	CREATE_POST_BUTTON(By.xpath("//div[@class='tab-content']//div[@class='prsData__single-value css-qc6sy-singleValue' and text()='Post']//following::div[@class='prsData__indicators css-1wy0on6']"),"Create Post Button"),

	POST_DROPDOWN_POST_ACTIVE(By.xpath("//div[@class='prsData__menu-list css-11unzgr']//div[contains(@class,'prsData__option prsData__option--is-focused') and text()='Post']"),"Post Dropdown Post Active"),

	POST_DROPDOWN_SELECT_FIELD("//div[@class='prsData__menu-list css-11unzgr']//div[contains(@class,'prsData__option') and text()='%s']","POST DROPDOWN SELECT FIELD"),

	STORY_TO_INCLUDE_IMAGE_OR_VIDEO_ALERT(By.xpath("//p[text()='You must include an image or video in order to post a story to Facebook.']"),""),

	REELS_TO_INCLUDE_VIDEO_ALERT(By.xpath("//p[text()='You must include a video in order to post a reel to Facebook.']"),"Reels to include video alert"),

	FACEBOOK_STORY_IMAGE_PREVIEW(By.xpath("//div[@class='tt-asset-wrap']//parent::div[@class='tt-wraps finsWrap fb-previewWrap fb-preview-story-wrap']//parent::div[contains(@class,'fb-in-active')]//div//img[@alt='Image asset']"),"FACEBOOK_STORY_IMAGE_PREVIEW"),

	INSTAGARAM_STORY_IMAGE_PREVIEW(By.xpath("//h4[text()='Instagram Business']//ancestor::div[@class='p-content ']//div[contains(@class,'tt-wraps finsWrap insta-previewWrap')]//div//img[@alt='Image asset']"),"INSTAGARAM_STORY_IMAGE_PREVIEW"),
	FACEBOOK_STORY_PREVIEW_ACTIVE(By.xpath("//div[@class='tt-asset-wrap']//parent::div[@class='tt-wraps finsWrap fb-previewWrap fb-preview-story-wrap']//parent::div[contains(@class,'fb-in-active')]"),"Facebook Story Preview Active"),
	INSTAGRAM_STORY_PREVIEW_ACTIVE(By.xpath("//h4[text()='Instagram Business']//ancestor::div[@class='p-content ']//div[contains(@class,'tt-wraps finsWrap insta-previewWrap')]"),"Instagram Story Preview Active"),

	FACEBOOK_REEL_PREVIEW_ACTIVE(By.xpath("//div[@class='tt-asset-wrap']//parent::div[@class='tt-wraps finsWrap fb-previewWrap fb-preview-reels-wrap']//parent::div[contains(@class,'fb-in-active')]"),"Facebook Story Preview Active"),

	INSTAGRAM_REEL_PREVIEW_ACTIVE(By.xpath("//h4[text()='Instagram Business']//ancestor::div[@class='p-content ']//div[contains(@class,'p-body previewtLinks')]"),"Instagram Story Preview Active"),

	SCHEDULE_BUTTON_ACTIVE(By.xpath("//button[text()='Schedule' and  not(contains(@class,'disabled'))]"), "Schedule post option"),

	CUSTOM_START_DATE(By.xpath("//div[@class='react-datepicker-wrapper']//input[@placeholder='Start Date']"),"Custom start date"),

	CUSTOM_END_DATE(By.xpath("//div[@class='react-datepicker-wrapper']//input[@placeholder='End Date']"),"Custom start date"),

	ALERT_OK_BUTTON(By.xpath("//div[@class='modal-content']//button[text()='OK']"),"Alert OK Button"),

	ADD_TO_TAGS_POST_ICON(By.xpath("//div[@class='add__post--main']//div[contains(@class,'add__post--icon tags add-tags')]//img[@alt='Tags']"), "Add Tags to post button "),
	ADD_TO_HASHTAGS_ICON(By.xpath("//div[@class='add__post--main']//div[contains(@class,'add__post--icon add-links add-hts')]//img[@alt='Hashtags']"), "Add HasTags to post button"),
	ADD_TO_CALL_ACTION_ICON(By.xpath("//div[@class='add__post--main']//div[contains(@class,'add__post--icon add-gpost')]//img[@alt='GooglePost']"),"Add Boost to post button"),

	ADD_LINK_VIEW_BUSINESS_LINK_FILED(By.xpath("//div[@class='modal-content']//div/h3[text()='Add Link']/../div//div//input[@placeholder='Business Link']"),"Add Link view Business Link field"),
	UPLOAD_FILE(By.xpath("//div[contains(@class,'at-cnt creator-post-media-wrp amseWrap me-lv-wrap')]//input[@type='file']"),"Drag & Drop your files here to upload (Select video up to 500 MB)"),

	/** creator page initial platform active state */
	INITIAL_PLATFORM_ACTIVE_STATE(By.xpath("//ul[@class='nav nav-posts nav-tabs']//li[@class='nav-item']//button[@class='content-added nav-link active  ']"), " creator page initial platform active state"),

	/** creator page Publish option in active state */
	PUBLISH_SWITCH_ACTIVE(By.xpath("//div[@class='tab-content']//p[text()='Publish ']//parent::div//div[@class='react-switch-bg']"),"Publish switch active"),

	/** The scheduled post  edit ok button. */
	SCHEDULED_POST_EDIT_OK_BUTTON(By.xpath("//div[@class='footer-btn-section']//button[text()='Ok']"),"Scheduled Post Edit Ok Button"),

	;

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new creates the post page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private CreatePostPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new creates the post page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private CreatePostPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

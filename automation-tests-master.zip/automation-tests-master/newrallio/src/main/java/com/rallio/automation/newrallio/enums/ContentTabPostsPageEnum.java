package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum ContentTabPostsPageEnum.
 */
public enum ContentTabPostsPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//li[@class='ripple active']//span[text()='Posts']//following::section[contains(@class,'item-g filter')]//ancestor::main//section[@id='main-container-sec']//div[@class='g-post postwrap mbl-head--margin']"), "The page load"),

	/** Campaign section. */
	CAMPAIGNS_PAGE_LOAD(By.xpath("//div[@id='campaign-post-folder-ifs']//div[contains(@class,'infinite-scroll-component_')]"), "Campaigns page load"),

	/** The campaigns total stats count. */
	CAMPAIGNS_TOTAL_STATS_COUNT(By.xpath("//div[contains(@class,'total-count')]//span[text()='Campaigns']//parent::div//span[@class='mod-count']//span"),
	        "Campaigns total stats count"),

	/** The active campaigns stats count. */
	ACTIVE_CAMPAIGNS_STATS_COUNT(By.xpath("//span[@class='platform-text' and text()='Active Campaigns']//following-sibling::span//span"), "Active campaigns stats count"),

	/** The available campaigns stats count. */
	AVAILABLE_CAMPAIGNS_STATS_COUNT(By.xpath("//span[@class='platform-text' and text()='Available Campaigns']//following-sibling::span//span"), "Available campaigns stats count"),

	/** The create campaign button. */
	CREATE_CAMPAIGN_BUTTON(By.xpath("//div[contains(@class,'stats-item sicp')]//span[text()='CREATE CAMPAIGN']"), "Create campaign button"),

	/** The add campaign input field. */
	ADD_CAMPAIGN_INPUT_FIELD(By.xpath("//div[@class='modal-body']//input[@placeholder='Add campaign']"), "Add campaign input field"),

	/** The add campaign section add button. */
	ADD_CAMPAIGN_SECTION_ADD_BUTTON(By.xpath("//div[@class='modal-body']//button//span[text()='Add']"), "Add campaign section add button"),

	/** The add campaign section cancel button. */
	ADD_CAMPAIGN_SECTION_CANCEL_BUTTON(By.xpath("//div[@class='modal-body']//button//span[text()='Cancel']"), "Add campaign section cancel button"),

	/** The campaign added success message. */
	CAMPAIGN_ADDED_SUCCESS_MESSAGE(By.xpath("//span[@class='success-mess-txt']"), "Campaign added success message"),

	/** The search campaign text box. */
	SEARCH_CAMPAIGN_TEXT_BOX(By.xpath("//div[@class='react-tags__search-input']//input[@placeholder='Search campaign']"), "Search campaign text box"),

	/** The campaigns all filter. */
	CAMPAIGNS_ALL_FILTER(By.xpath("//input[@name='campaigns_status-Campaigns Status']//following-sibling::span[contains(text(),'All')]"), "Campaigns All filter"),

	/** The campaigns active filter. */
	CAMPAIGNS_ACTIVE_FILTER(By.xpath("//input[@name='campaigns_status-Campaigns Status']//following-sibling::span[contains(text(),'Active')]"), "Campaigns Active filter"),

	/** The campaigns available filter. */
	CAMPAIGNS_AVAILABLE_FILTER(By.xpath("//input[@name='campaigns_status-Campaigns Status']//following-sibling::span[contains(text(),'Available')]"), "Campaigns Available filter"),

	/** The search campaigns result. */
	SEARCH_CAMPAIGNS_RESULT("//div[@id='campaign-post-folder-ifs']//div[contains(@class,'m-item ')]//div[@class='prime-sub-dtls']//h3[contains(text(),'%s')]",
	        "Search campaigns result"),

	/** The campaign detailedview button. */
	CAMPAIGN_DETAILEDVIEW_BUTTON(By.xpath("//div[@id='campaign-post-folder-ifs']//div[contains(@class,'m-item ')]//img[@alt='Expand']"), "Campaign detailedView button"),

	/** The start campaign button in campaign listview. */
	START_CAMPAIGN_BUTTON_IN_CAMPAIGN_LISTVIEW(By.xpath("//div[@id='campaign-post-folder-ifs']//div[contains(@class,'m-item ')]//button//span[text()='Start Campaign']"),
	        "Start campaign button in campaign listView"),

	/** The stop campaign button in campaign listview. */
	STOP_CAMPAIGN_BUTTON_IN_CAMPAIGN_LISTVIEW(By.xpath("//div[@id='campaign-post-folder-ifs']//div[contains(@class,'m-item ')]//button//span[text()='Stop Campaign']"),
	        "Stop campaign button in campaign listView"),

	/** The stop campaign alert yes button. */
	STOP_CAMPAIGN_ALERT_YES_BUTTON(
	        By.xpath("//div[@class='modal-body']//div[text()='Are you sure you want to stop this campaign?']//ancestor::div[@class='modal-content']//button[text()='Yes']"),
	        "Stop campaign alert yes button"),

	/** The stop campaign alert no button. */
	STOP_CAMPAIGN_ALERT_NO_BUTTON(
	        By.xpath("//div[@class='modal-body']//div[text()='Are you sure you want to stop this campaign?']//ancestor::div[@class='modal-content']//button[text()='No']"),
	        "Stop campaign alert no button"),

	/** The campaign started stopped alert message. */
	CAMPAIGN_STARTED_STOPPED_ALERT_MESSAGE(By.xpath("//div[@id='success']//span[text()='Done!']"), "Campaign started stopped alert message"),

	/** Start campaign section. */
	START_CAMPAIGN_VIEW("//div[@class='modal-body']//h3[text()='Start Campaign - %s']", "Start campaign view"),

	/** The all locations option. */
	ALL_LOCATIONS_OPTION(By.xpath("//div[@class='modal-body']//input//following-sibling::label[text()='All Locations']"), "AllLocations option"),

	/** The corporate only option. */
	CORPORATE_ONLY_OPTION(By.xpath("//div[@class='modal-body']//input//following-sibling::label[text()='Corporate Only']"), "CorporateOnly option"),

	/** The specific locations option. */
	SPECIFIC_LOCATIONS_OPTION(By.xpath("//div[@class='modal-body']//input//following-sibling::label[text()='Specific Locations/Lists']"), "SpecificLocations option"),

	/** The select locations button. */
	SELECT_LOCATIONS_BUTTON(By.xpath("//div[@class='modal-body']//div[@class='fade tab-pane active show']//button//span[text()='Select Locations']"), "Select Locations button"),

	/** The select locations dropdown. */
	SELECT_LOCATIONS_DROPDOWN(By.xpath(
	        "//div[@class='modal-body']//div[@class='fade tab-pane active show']//span[text()='Select Locations']//parent::button//parent::div//div[@id='select-locations-dropdown']"),
	        "Select Locations dropdown"),

	/** The select locations search field. */
	SELECT_LOCATIONS_SEARCH_FIELD(By.xpath(
	        "//div[@class='modal-body']//div[@class='fade tab-pane active show']//span[text()='Select Locations']//parent::button//parent::div//div[@id='select-locations-dropdown']//input"),
	        "Select Locations searchField"),

	/** The select locations search result. */
	SELECT_LOCATIONS_SEARCH_RESULT(
	        "//div[@class='modal-body']//div[@class='fade tab-pane active show']//div[@id='select-locations-dropdown']//div[contains(@class,'rs-drp__option') and contains(text(),'%s')]",
	        "Select Locations searchResult"),

	/** The selected location. */
	SELECTED_LOCATION("//div[@class='modal-body']//div[@class='select-location-section-wrp']//div[@class='grid-section']//span[text()='%s']", "Selected location"),

	/** The set start end date option. */
	SET_START_END_DATE_OPTION(By.xpath("//input[@name='duration_type']//following-sibling::span[text()='Set a Start and End Date']"), "Set startEnd date option"),

	/** The ongoing option. */
	ONGOING_OPTION(By.xpath("//input[@name='duration_type']//following-sibling::span[text()='Ongoing']"), "Ongoing option"),

	/** The start on date. */
	START_ON_DATE(By.xpath("//div[@class='wdt-item da-date']//input[@name='start_datetime']"), "Start on date"),

	/** The stop on date. */
	STOP_ON_DATE(By.xpath("//div[@class='wdt-item da-date']//input[@name='end_datetime']"), "Stop on date"),

	/** The start on time. */
	START_ON_TIME(By.xpath("//div[@class='wdt-item da-time']//input[@name='start_datetime']"), "Start on time"),

	/** The stop on time. */
	STOP_ON_TIME(By.xpath("//div[@class='wdt-item da-time']//input[@name='end_datetime']"), "Stop on time"),

	/** The calendar previous month button. */
	CALENDAR_PREVIOUS_MONTH_BUTTON(By.xpath("//div[@class='react-datepicker']//button[@aria-label='Previous Month']"), "Previous month button"),

	/** The calendar next month button. */
	CALENDAR_NEXT_MONTH_BUTTON(By.xpath("//div[@class='react-datepicker']//button[@aria-label='Next Month']"), "Next month button"),

	/** The select nextdate from calendar. */
	SELECT_NEXTDATE_FROM_CALENDAR(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week']//div[@aria-disabled='false'][2]"),
	        "Select nextDate from calendar"),

	/** The select schedule day. */
	SELECT_SCHEDULE_DAY("//div[@class='wf-schedule']//div[@class='wfs-row']//span[text()='%s']", "Select schedule day"),

	/** The schedule day add button. */
	SCHEDULE_DAY_ADD_BUTTON("//div[@class='wf-schedule']//div[@class='wfs-row']//span[text()='%s']//parent::div//parent::div//button//img[@alt='Add']", "Schedule day add button"),

	/** The schedule day hour input. */
	SCHEDULE_DAY_HOUR_INPUT(By.xpath("//div[@class='wf-schedule']//div[@class='wfs-row whs-open']//label[@for='campaign-ws-hour']//input"), "Schedule day hour input"),

	/** The schedule day minute input. */
	SCHEDULE_DAY_MINUTE_INPUT(By.xpath("//div[@class='wf-schedule']//div[@class='wfs-row whs-open']//label[@for='campaign-ws-minute']//input"), "Schedule day minute input"),

	/** The schedule day row cancel button. */
	SCHEDULE_DAY_ROW_CANCEL_BUTTON(By.xpath("//div[@class='wf-schedule']//div[@class='wfs-row whs-open']//button//span[text()='Cancel']"), "Schedule day row cancel button"),

	/** The schedule day row add button. */
	SCHEDULE_DAY_ROW_ADD_BUTTON(By.xpath("//div[@class='wf-schedule']//div[@class='wfs-row whs-open']//button//span[text()='Add']"), "Schedule day row add button"),

	/** The schedule day row added time. */
	SCHEDULE_DAY_ROW_ADDED_TIME("//div[@class='wf-schedule']//div[@class='wfs-row']//span[text()='%s']//parent::div//parent::div//span[@class='tg-time']",
	        "Schedule day row added time"),

	/** The no of campaign post per week. */
	NO_OF_CAMPAIGN_POST_PER_WEEK(By.xpath("//div[@class='modal-body']//h3[text()='Total number of campaign post per week:']//span"), "No of campaign post per week"),

	/** The start campaign view go back button. */
	START_CAMPAIGN_VIEW_GO_BACK_BUTTON(By.xpath("//div[@class='modal-body']//button//span[text()='Go Back']"), "Start Campaign view go back button"),

	/** The start campaign view start campaign button. */
	START_CAMPAIGN_VIEW_START_CAMPAIGN_BUTTON(By.xpath("//div[@class='modal-body']//button//span[text()='Start Campaign']"), "Start Campaign view start campaign button"),

	/** The campaign detailed view. */
	CAMPAIGN_DETAILED_VIEW("//div[@class='gnricCnt campaign-list avl-cmpgn']//div[@class='rel-head-label']//span[text()='%s']", "Campaign detailed view"),

	/** The campaign view close button. */
	CAMPAIGN_VIEW_CLOSE_BUTTON(By.xpath("//div[@class='gnricCnt campaign-list avl-cmpgn']//button//img[@alt='Close']"), "Campaign view close button"),

	/** The campaign view create post button. */
	CAMPAIGN_VIEW_CREATE_POST_BUTTON(By.xpath("//div[@class='gnricCnt campaign-list avl-cmpgn']//button//img[@alt='Create Post']"), "Campaign view createPost button"),

	/** The campaign view start campaign button. */
	CAMPAIGN_VIEW_START_CAMPAIGN_BUTTON(By.xpath("//div[@class='filter-item stc-btns']//button//span[text()='Start Campaign']"), "Campaign view startCampaign button"),

	/** The post in campaign view. */
	POST_IN_CAMPAIGN_VIEW("//div[@id='campaign-post-list-ifs']//div[contains(@class,'m-item ')]//div[contains(@class,'mi-front')]//p[contains(text(),'%s')]", "Post in Campaign view"),

	/** The campaign view post detailed view button. */
	CAMPAIGN_VIEW_POST_DETAILED_VIEW_BUTTON(
	        "//div[contains(@class,'m-item ')]//div[contains(@class,'mi-front')]//p[contains(text(),'%s')]//ancestor::div[contains(@class,'m-item ')]//img[@alt='Expand']",
	        "CampaignView post detailedView button"),

	/** The campaign view post delete button. */
	CAMPAIGN_VIEW_POST_DELETE_BUTTON(
	        "//div[contains(@class,'m-item ')]//div[contains(@class,'mi-front')]//p[contains(text(),'%s')]//ancestor::div[contains(@class,'m-item ')]//button//span[text()='Delete']",
	        "CampaignView post delete button"),

	/** The view calendar button. */
	VIEW_CALENDAR_BUTTON(By.xpath("//div[@class='cmpgn-day-picker']//button//span[text()='View Calendar']"), "View calendar button"),

	/** The scheduled campaign post in view calendar. */
	SCHEDULED_CAMPAIGN_POST_IN_VIEW_CALENDAR("//div[@class='fc-event-main']//p[@class='post-content' and text()='%s']", "Scheduled campaign post in view calendar"),

	/** The view calendar close button. */
	VIEW_CALENDAR_CLOSE_BUTTON(By.xpath("//div[@class='modal-content']//img[@alt='close']"), "View calendar close button"),

	/** The campaign view edit campaign button. */
	CAMPAIGN_VIEW_EDIT_CAMPAIGN_BUTTON(By.xpath("//div[@class='cf-itemGroup']//button//span[text()='Edit Campaign']"), "CampaignView edit campaign button"),

	/** The campaign view stop campaign button. */
	CAMPAIGN_VIEW_STOP_CAMPAIGN_BUTTON(By.xpath("//div[@class='cf-itemGroup']//button//span[text()='Stop Campaign']"), "CampaignView stop campaign button"),

	/** The edit campaign view. */
	EDIT_CAMPAIGN_VIEW("//div[@class='modal-body']//h3[text()='Edit Campaign - %s']", "Edit campaign view"),

	/** The restart campaign button. */
	RESTART_CAMPAIGN_BUTTON(By.xpath("//div[@class='modal-body']//button//span[text()='Restart Campaign']"), "Restart campaign button"),

	/** The search text box. */
	SEARCH_TEXT_BOX(By.xpath("//div[@class='react-tags__search-input']//input[@placeholder='Search text']"), "Search text box"),

	/** The search tags box. */
	SEARCH_TAGS_BOX(By.xpath("//div[@class='react-tags']//input[@placeholder='Search tags']"), "Search tags box"),

	/** The tags suggestion. */
	TAGS_SUGGESTION(By.xpath("//div[@class='react-tags']//input[@placeholder='Search tags']//parent::div//parent::div//div[@class='react-tags__suggestions']//mark[text()]"),
	        "Tags suggestion"),

	/** The favorite tags section. */
	FAVORITE_TAGS_SECTION(By.xpath("//div[contains(@class,'tagnew-margin')]//h3[text()='Favorite Tags']"), "Favorite tags section"),
	//div[contains(@class,'m-item')]//div[contains(@class,'mi-front')]//div[@class='msg-wrapper']//p[contains(text(),\"%s\")]
	/** Search result. */
	SEARCH_RESULT("//div[contains(@class,'m-item')]//div[@class='msg-wrapper']//p[contains(text(),\"%s\")]", "Search result"),

	/** The search result on post content. */
	SEARCH_RESULT_ON_POST_CONTENT("//div[contains(@class,'m-item')]//div[contains(@class,'mi-front')]//div[@class='msg-wrapper']//p[contains(text(),\"%s\")]", "Search result on PostContent"),

	/** The search result tags. */
	SEARCH_RESULT_TAGS("//div[@class='react-tags__suggestions']//li//span//mark[contains(text(),'%s')]", "Search result tags"),

	/** The post detailedview delete button. */
	POST_DETAILEDVIEW_DELETE_BUTTON(By.xpath("//div[contains(@class,'btn-ac--wrp')]//button[text()='Delete']"), "Post detailedView delete button"),

	/** The post detailedview draft status. */
	POST_DETAILEDVIEW_DRAFT_STATUS(By.xpath("//div[@class='wbf-item']//span[@class='wbf-label' and text()='Status']//parent::div//following-sibling::div//span[text()='Draft']"),
	        "Post detailedView draft status"),

	/** The post detailedview ready status. */
	POST_DETAILEDVIEW_READY_UNUSED_STATUS(By.xpath("//div[@class='wbf-item']//span[@class='wbf-label' and text()='Status']//parent::div//following-sibling::div//span[text()='Approved & Unused']"),
	        "Post detailedView ready status is : Approved & Unused"),
	POST_DETAILEDVIEW_READY_USED_STATUS(By.xpath("//div[@class='wbf-item']//span[@class='wbf-label' and text()='Status']//parent::div//following-sibling::div//span[text()='Approved & Used']"),"Post detailedView ready status is : Approved & Used"),

	/** The post detailedview pending status. */
	POST_DETAILEDVIEW_PENDING_STATUS(
	        By.xpath("//div[@class='wbf-item']//span[@class='wbf-label' and text()='Status']//parent::div//following-sibling::div//span[text()='Pending Approval']"),
	        "Post detailedView pending status"),

	/** The post detailedview approve button. */
	POST_DETAILEDVIEW_APPROVE_BUTTON(By.xpath("//div[contains(@class,'btn-ac--wrp')]//button[text()='Approve']"), "The Post Approve "),

	/** The post detailedview approved status. */
	POST_DETAILEDVIEW_APPROVED_STATUS(
	        By.xpath("//div[@class='wbf-item']//span[@class='wbf-label' and text()='Status']//parent::div//following-sibling::div//span[text()='Approved & Unused']"),
	        "Post detailedView approved status"),

	/** The post detailedview editschedule button. */
	POST_DETAILEDVIEW_EDITSCHEDULE_BUTTON(By.xpath("//div[contains(@class,'btn-ac--wrp')]//button[text()='Edit/Schedule Post' or text()='Edit']"), "Post detailedView editSchedule button"),

	POST_DETAIL_VIEW_TAGS_FIELD("//div[@class='li-base msg-wrapper']//p//a[@rel='noreferrer noopener']//span[text()='%s']","POST_DETAIL_VIEW_TAGS_FIELD"),

	/** The post delete alertbox. */
	POST_DELETE_ALERTBOX(By.xpath("//div[@class='modal-body']//div[contains(text(),'Are you sure')]"), "Post Delete alertbox"),

	/** The delete alert cancel button. */
	DELETE_ALERT_CANCEL_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Cancel']"), "Delete alert cancel button"),

	/** The delete alert delete button. */
	DELETE_ALERT_DELETE_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Delete']"), "Delete alert delete button"),

	/** The remove from hubs and locations option. */
	REMOVE_FROM_HUBS_AND_LOCATIONS_OPTION(
	        By.xpath("//div[@class='modal-content']//label[@class='checkbox-item']//div[text()='Remove this post from my Hubs and any scheduled locations']"),
	        "Remove from hubs and locations option"),

	/** The remove from facebook and twitter option. */
	REMOVE_FROM_FACEBOOK_AND_TWITTER_OPTION(
	        By.xpath("//div[@class='modal-content']//label[@class='checkbox-item']//div[text()='Remove this post from Facebook and Twitter if it has already posted']"),
	        "Remove from facebook and twitter option"),

	/** The post deleted message. */
	POST_DELETED_MESSAGE(By.xpath("//span[@class='success-mess-txt' and text()='Post deleted']"), "Post deleted message"),

    // AVAILABLE_BOOSTED_POSTS_BUTTON(By.xpath("//button[text()='Available
    // Boosted Posts']"), "Available boosted posts button"),

	/** The total stats count. */
	TOTAL_STATS_COUNT(By.xpath("//div[contains(@class,'total-count')]//span[text()='POSTS']//parent::div//span[@class='mod-count']//div"), "Total stats count"),

	/** The ready stats count. */
	READY_STATS_COUNT(By.xpath("//span[@class='platform-text' and text()='Ready']//following-sibling::span//div"), "Ready stats count"),

	/** The pending stats count. */
	PENDING_STATS_COUNT(By.xpath("//span[@class='platform-text' and text()='Pending']//following-sibling::span//div"), "Pending stats count"),

	/** The approval ai generated count. */
	APPROVAL_AI_GENERATED_COUNT(By.xpath("//span[text()='Approval']//parent::div//parent::div[contains(@class,'stats-item fb-sc si-pending')]//div[@class='platform-icon']//img[@alt='AI Generated']//ancestor::div[@class='r-flx r-flx-gap1']//span//div"),"Approval AI GeneratedCount"),
	
	/** The draft stats count. */
	DRAFT_STATS_COUNT(By.xpath("//span[@class='platform-text' and text()='Draft']//following-sibling::span//div"), "Draft stats count"),

	/** The rejected stats count. */
	REJECTED_STATS_COUNT(By.xpath("//span[@class='platform-text' and text()='Rejected']//following-sibling::span//div"), "Rejected stats count"),

	/** The awaiting approval mycontent statscount. */
	AWAITING_APPROVAL_MYCONTENT_STATSCOUNT(
	       By.xpath("//span[text()='Awaiting']//following-sibling::span[text()='My Content']//parent::div//preceding-sibling::span[contains(@class,'platform-count')]//div"),
	        "AwaitingApproval MyContent statsCount"),

	/** The awaiting approval locationcontent statscount. */
	AWAITING_APPROVAL_LOCATIONCONTENT_STATSCOUNT(
	        By.xpath("//span[text()='Awaiting']//following-sibling::span[text()='Location Content']//parent::div//preceding-sibling::span[contains(@class,'platform-count')]//div"),
	        "AwaitingApproval LocationContent statsCount"),

	/** The clear filter option. */
	CLEAR_FILTER_OPTION(By.xpath("//button//span[text()='Clear Filter']"), "Clear Filter option"),

	/** The clear all filter. */
	CLEAR_ALL_FILTER(By.xpath("//div[@class='react-ripples ac-primary-box' and not(contains(@class,'pointer-events-none'))]//button//span[text()='Clear Filter']"),
	        "Clear All Filter"),

	/** The from date. */
	FROM_DATE(By.xpath("//div[@class='dp-item date-end__wrp dp-from']//div[contains(@class,'react-datepicker__input-container')]//input[@placeholder='MM/DD/YYYY']"), "From date"),

	/** The from date active. */
	FROM_DATE_ACTIVE(By.xpath("//section[contains(@class,'filter')]//div[@class='dp-item dp-from active']"), "From date active"),

	/** The from date content. */
	FROM_DATE_CONTENT(By.xpath("//div[contains(@class,'dp-from')]//div[@class='react-datepicker__input-container']//input"), "From date content"),

	/** The select from date. */
	SELECT_FROM_DATE("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]", "Select From date"),

	/** The select from date with month. */
	SELECT_FROM_DATE_WITH_MONTH(
	        "//section[contains(@class,'filter')]//div[contains(@class,'dp-item dp-from')]//div[2]//div[@aria-disabled='false' and  contains(@aria-label,'%s')]",
	        "Select from date with month"),

	/** The from date previous month. */
	FROM_DATE_PREVIOUS_MONTH(By.xpath("//section[contains(@class,'filter')]//div//button[@aria-label ='Previous Month']"),
	        "From date previous month button"),

	/** The from date next month. */
	FROM_DATE_NEXT_MONTH(By.xpath("//section[contains(@class,'filter')]//button[@aria-label='Next Month']"),
	        "From date next month button"),

	/** The select date from calendar. */
	SELECT_DATE_FROM_CALENDAR(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week']//div[@aria-disabled='false']"), "Select date from calendar"),

	/** The calendar displayed. */
	CALENDAR_DISPLAYED(By.xpath("//div[@class='react-datepicker__month']"), "Calendar displayed"),

	/** The select last date. */
	SELECT_LAST_DATE(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week'][3]//div[@aria-disabled='false'][last()]"), "Select last date"),

	/** The to date. */
	TO_DATE(By.xpath("//div[@class='dp-item date-end__wrp dp-to']//div[contains(@class,'react-datepicker__input-container')]//input"), "To date"),

	/** The to date active. */
	TO_DATE_ACTIVE(By.xpath("//section[contains(@class,'filter')]//div[@class='dp-item dp-to active']"), "To date active"),

	/** The to date content. */
	TO_DATE_CONTENT(By.xpath("//div[contains(@class,'dp-to')]//div[@class='react-datepicker__input-container']//input"), "To date content"),

	/** The to date previous month. */
	TO_DATE_PREVIOUS_MONTH(By.xpath("//section[contains(@class,'filter')]//button[@aria-label='Previous Month']"),
	        "To date previous month button"),

	/** The to date next month. */
	TO_DATE_NEXT_MONTH(By.xpath("//section[contains(@class,'filter')]//button[@aria-label='Next Month']"), "To date next month button"),

	/** The select to date. */
	SELECT_TO_DATE("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]", "Select To date"),

	/** The select to date with month. */
	SELECT_TO_DATE_WITH_MONTH("//section[contains(@class,'filter')]//div[contains(@class,'dp-item dp-to')]//div[2]//div[@aria-disabled='false' and  contains(@aria-label,'%s')]",
	        "Select to date with month"),

	/** The platform filter. */
	PLATFORM_FILTER(By.xpath("//section[contains(@class,'filter')]//div[@class='filter-item']//h3[text()='Platform']"), "Platform filter"),

	/** The all filter platform. */
	ALL_FILTER_PLATFORM(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'all-platform')]//parent::button"), "All filter platform"),

	/** The all filter selected. */
	ALL_FILTER_SELECTED(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'all-platform')]//parent::button[contains(@class,'active')]"),
	        "All filter selected"),

	/** The facebook filter button. */
	FACEBOOK_FILTER_BUTTON(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'fb-platform')]//parent::button"),
	        "Facebook filter button"),

	/** The facebook filter selected. */
	FACEBOOK_FILTER_SELECTED(
	        By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'fb-platform')]//parent::button[contains(@class,'active')]"),
	        "Facebook filter selected"),

	/** The twitter filter button. */
	TWITTER_FILTER_BUTTON(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'twitter-platform')]//parent::button"),
	        "Twitter filter button"),

	/** The twitter filter selected. */
	TWITTER_FILTER_SELECTED(
	        By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'twitter-platform')]//parent::button[contains(@class,'active')]"),
	        "Twitter filter selected"),

	/** The linkedin filter button. */
	LINKEDIN_FILTER_BUTTON(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'linkedin-platform')]//parent::button"),
	        "LinkedIn filter button"),

	/** The linkedin filter selected. */
	LINKEDIN_FILTER_SELECTED(
	        By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'linkedin-platform')]//parent::button[contains(@class,'active')]"),
	        "LinkedIn filter selected"),

	/** The instagram filter button. */
	INSTAGRAM_FILTER_BUTTON(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'instagram-platform')]//parent::button"),
	        "Instagram filter button"),

	/** The instagram filter selected. */
	INSTAGRAM_FILTER_SELECTED(
	        By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'instagram-platform')]//parent::button[contains(@class,'active')]"),
	        "Instagram filter selected"),

	/** The google filter button. */
	GOOGLE_FILTER_BUTTON(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'google-platform')]//parent::button"),
	        "Google filter button"),

	/** The TikTok filter button. */
	TIKTOK_FILTER_BUTTON(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'tiktok-platform')]//parent::button"),
			"TikTok filter button"),

	/** The google filter selected. */
	GOOGLE_FILTER_SELECTED(
	        By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'google-platform')]//parent::button[contains(@class,'active')]"),
	        "Google filter selected"),

	/** The TikTok filter selected. */
	TIKTOK_FILTER_SELECTED(
			By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'tiktok-platform')]//parent::button[contains(@class,'active')]"),
			"TikTok filter selected"),


	/** Create post button. */
	CREATE_POST_BUTTON(By.xpath("//div[contains(@class,'stats-item')]//span[text()='CREATE POST']"), "Create post button"),

	/** Posts list. */
	POSTS_LIST(By.xpath("//div[contains(@class,'pls post-list__main')]//div[contains(@class,'m-item')]"), "Posts list"),
	
	/** The post list byname. */
	POST_LIST_BYNAME("//div[@id='post-list-ifs']//div[contains(@class,'m-item')]//p[contains(text(),'%s')]","Post List By Name"),

	/** The common post. */
	COMMON_POST(By.xpath("//div[contains(@class,'m-item ')]//div[contains(@class,'mi-front')]//p[text()]"), "Common post"),

	COMMON_POST_WITH_IMAGE(By.xpath("//div[contains(@class,'m-item ')]//div[@class='m-ast']//img//parent::div//preceding-sibling::div//div[@class='msg-wrapper']//p[text()]"),"Common Post with image"),

	/** The show all posts button. */
	SHOW_ALL_POSTS_BUTTON(By.xpath("//input[@name='type-']//following-sibling::span[text()='Show all posts']"), "Show allPosts button"),

	/** The show campaigns button. */
	SHOW_CAMPAIGNS_BUTTON(By.xpath("//input[@name='type-']//following-sibling::span[text()='Show campaigns']"), "Show campaigns button"),
	
	/** The clear date range button. */
	CLEAR_DATE_RANGE_BUTTON(By.xpath("//button[@class='cdr-btn']//span[text()='Clear Date Range']"),"Clear date Range Button"),
	
	/** The specific daterange button. */
	SPECIFIC_DATERANGE_BUTTON(By.xpath("//input[@name='type-']//following-sibling::span[text()='Specific date range']"), "Specific dateRange button"),

	/** The usage all filter. */
	USAGE_ALL_FILTER(By.xpath("//input[@name='usage-Usage']//following-sibling::span[contains(text(),'All')]"), "Usage All filter"),

	/** Used filter. */
	USED_FILTER(By.xpath("//input[@name='usage-Usage']//following-sibling::span[contains(text(),'Used')]"), "Used filter"),

	/** Unused filter. */
	UNUSED_FILTER(By.xpath("//input[@name='usage-Usage']//following-sibling::span[contains(text(),'Unused')]"), "Unused filter"),

	/** The status all filter. */
	STATUS_ALL_FILTER(By.xpath("//input[@name='status-Status']//following-sibling::span[text()='All']"), "Status All filter"),

	/** The ai generated filter. */
	AI_GENERATED_FILTER(By.xpath("//label//input[@value='ai_generated']//following-sibling::span[text()='AI Generated']"),"AI Generated Filter"),
	
	/** The ready filter. */
	READY_FILTER(By.xpath("//input[@name='status-Status']//following-sibling::span[text()='Ready']"), "Ready filter"),

	/** The posts filter. */
	POSTS_FILTER(By.xpath("//div[contains(@class,'total-count stats-level')]//span[text()='POSTS']"),"Posts Filter"),
	
	/** The pending filter. */
	PENDING_FILTER(By.xpath("//input[@name='status-Status']//following-sibling::span[text()='Pending']"), "Pending filter"),

	/** The draft filter. */
	DRAFT_FILTER(By.xpath("//input[@name='status-Status']//following-sibling::span[text()='Draft']"), "Draft filter"),

	/** The rejected filter. */
	REJECTED_FILTER(By.xpath("//input[@name='status-Status']//following-sibling::span[text()='Rejected']"), "Rejected filter"),

	/** The awaiting approval mycontent filter. */
	AWAITING_APPROVAL_MYCONTENT_FILTER(By.xpath("//input[@name='status-Status']//following-sibling::span[text()='Awaiting Approval (My Content)']"),
	        "AwaitingApproval MyContent filter"),

	/** The awaiting approval locationcontent filter. */
	AWAITING_APPROVAL_LOCATIONCONTENT_FILTER(By.xpath("//input[@name='status-Status']//following-sibling::span[text()='Awaiting Approval (Location Content)']"),
	        "AwaitingApproval LocationContent filter"),

	/** The awaiting approval ai generated filter. */
	AWAITING_APPROVAL_AI_GENERATED_FILTER(By.xpath("//label//input[@value='ai_generated']//following-sibling::span[text()='Awaiting Approval (AI Generated)']"),"Awaiting Aprroval AI Generated Filter"),
	
	/** The image filter. */
	IMAGE_FILTER(By.xpath("//h3[text()='Post Type']//following-sibling::div//span[text()='Image']"), "Image filter"),

	/** The link filter. */
	LINK_FILTER(By.xpath("//h3[text()='Post Type']//following-sibling::div//span[text()='Link']"), "Link filter"),

	/** The copy filter. */
	COPY_FILTER(By.xpath("//h3[text()='Post Type']//following-sibling::div//span[text()='Copy']"), "Copy filter"),

	/** The no data to show. */
	NO_DATA_TO_SHOW(By.xpath("//div[@class='no-data']//span[text()='No data to show']"), "No data to show"),

	TABLE_NO_DATA_TO_SHOW(By.xpath("//td[text()=' No Data to show']"),"Table No Data To Show"),
	
	/** The facebook contents. */
	FACEBOOK_CONTENTS(By.xpath("//div[contains(@class,'m-item ')]//div[contains(@class,'mi-front')]//div[@class='fltr-imc selectsocial']//img[@alt='Facebook']"), "Facebook contents"),

	/** The instagram contents. */
	INSTAGRAM_CONTENTS(By.xpath("//div[contains(@class,'m-item ')]//div[contains(@class,'mi-front')]//div[@class='fltr-imc selectsocial']//img[@alt='Instagram']"), "Instagram contents"),

	/** The linkedin contents. */
	LINKEDIN_CONTENTS(By.xpath("//div[contains(@class,'m-item ')]//div[contains(@class,'mi-front')]//div[@class='fltr-imc selectsocial']//img[@alt='LinkedIn']"), "Linkedin contents"),

	/** The twitter contents. */
	TWITTER_CONTENTS(By.xpath("//div[contains(@class,'m-item ')]//div[contains(@class,'mi-front')]//div[@class='fltr-imc selectsocial']//img[@alt='Twitter']"), "Twitter contents"),

	/** The google contents. */
	GOOGLE_CONTENTS(By.xpath("//div[contains(@class,'m-item ')]//div[contains(@class,'mi-front')]//div[@class='fltr-imc selectsocial']//img[@alt='GooglePlus']"), "Google contents"),

	/** The TikTok contents. */
	TIKTOK_CONTENTS(By.xpath("//div[contains(@class,'m-item ')]//div[contains(@class,'mi-front')]//div[@class='fltr-imc selectsocial']//img[@alt='Tiktok']"), " The TikTok contents."),

	/** The post stats colour. */
	POST_STATS_COLOUR(By.xpath("//div[@class='chart-container']//div[@class='progress-vertical']"),"Post Stats Colour"),
	
	/** The post status. */
	POST_STATUS(By.xpath("//div[contains(@class,'m-item ')]//div[contains(@class,'mi-front')]//div[contains(@class,'round-asset brand-icon')]//img[@alt='Asset status']"), "Post status"),

	/** The post filter. */
	POST_FILTER(By.xpath("//span[text()='POSTS']//parent::div[@class='chart-module-top']//parent::div"),"Post Filter"),
	
	/** The post id. *//*
	POST_ID(By.xpath("//div[contains(@class,'m-item ')]//div[contains(@class,'mi-front')]//div[@class='prime-sub-dtls']//h3[text()]"), "Post id"),
*/
	/** The post date. */
	POST_DATE(By.xpath("//div[contains(@class,'m-item ')]//div[contains(@class,'mi-front')]//div[@class='prime-sub-dtls']//span[text()]"), "Post date"),

	/** The post socialmedia icons. */
	POST_SOCIALMEDIA_ICONS(By.xpath("//div[contains(@class,'m-item ')]//div[contains(@class,'mi-front')]//div[@class='fltr-imc selectsocial']"), "Post socialMedia Icons"),

	/** The post description. */
	POST_DESCRIPTION(By.xpath("//div[contains(@class,'m-item ')]//div[contains(@class,'mi-front')]//p[@title and text()]"), "Post description"),

	/** The common post id. */
	COMMON_POST_DATE(By.xpath("//div[contains(@class,'m-item ')]//div[contains(@class,'mi-front')]//div[@class='prime-sub-dtls']//span"), "Common post date"),

    /** The post list link button. */
    POST_LIST_LINK_BUTTON("//p[contains(text(),\"%s\")]//ancestor::div[contains(@class,'m-item ')]//div[@class='mi-cntrls']//img[@alt='Link']","Post List Link button"),
   
    POST_DETAILVIEW_POSTLINK(By.xpath("//div[contains(@class,'post-detailed post-detailed__main')]//div[contains(@class,'new-preview')]//div[@class='np-content']"),"POST DetailView PostLink"),
    
    POST_DEATILVIEW_IMAGE(By.xpath("//div[@class='fade tab-pane active show']//div[@class='new-preview']//div[@class='np-img']//img"),"Post Detail View Image"),

	POST_WITH_RALLIOLOGO("//p[text()='%s']//parent::div//parent::div//div[@class='sh-bLogo']//img[@src='https://stage-cdn.rallio.com/img/activate-v3/rIcon.svg']","Post with Rallio Logo"),

	POST_LOGO_BY_POSTNAME("//p[text()='%s']//parent::div//parent::div//div[@class='mif-left']//div[@class='sh-bLogo']//img","Post Logo by PostName"),

	/** The post detailedview button.*/
	POST_DETAILEDVIEW_BUTTON(By.xpath("//div[contains(@class,'m-item ')]//img[@alt='Expand']"), "Post detailedView button"),
	
	/** The post detailedview button field. */
	POST_DETAILEDVIEW_BUTTON_FIELD("//p[contains(text(),\"%s\")]//ancestor::div[contains(@class,'m-item ')]//img[@alt='Expand']", "Post detailedView button"),

	POST_EXPAND_DETAILEDVIEW_BUTTON("//p[contains(@title,\"%s\")]//ancestor::div[contains(@class,'m-item ')]//img[@alt='Expand']", "Post detailedView button"),

	/** The post list ai option. */
	POST_LIST_AI_GENRATEOPTION(By.xpath("//div[@class='infinite-list post-grid-wrp']//div[contains(@class,'pls post-list__main')]//div//div[contains(@class,'ai-btn ai-creator-')]//img[@alt='AI']"),"AI Option in Post list"),
	
	/** The postlist ai option field. */
	POSTLIST_AI_OPTION_FIELD("//div[contains(@class,'mi-front')]//p[contains(text(),\"%s\")]//ancestor::div[contains(@class,'m-item')]//div[@class='eai-wrap ai-tag']//img[@alt='AI']","Post List AI Option By Name"),
	
	/** The ai generating text with logo. */
	AI_GENERATING_TEXT_WITH_LOGO(By.xpath("//img[@alt='AI Content Generated']//parent::div[@class='spin-txt-wrap ai-loader']//img[@alt='AI Content Generated']"),"AI Generating Text with logo"),

	AI_POST_CREATED_SUCCESSFULLY_MESSAGE(By.xpath("//span[@class='success-mess-txt' and text()='AI post created successfully']"),"AI Post Created Successfully"),

	/** Footer. */
	FOOTER(By.xpath("//div[@id='post-list-ifs']//div[contains(@class,'m-item')][last()]"), "Footer"),

	/** The creator page load. */
	CREATOR_PAGE_LOAD(By.xpath("//span[text()='Creator']//following::section[contains(@class,'item-g filter')]//ancestor::div//section[@id='main-container-sec']//div[@class='addpost-section-main-wrp creator__main--content']"), "Creator pageLoad"),

	/** The favourite tags list. */
	FAVOURITE_TAGS_LIST(By.xpath("//h3[text()='Favorite Tags']//parent::div//following-sibling::div[@class='fts']//span"), "Favourite tags list"),

	/** The posts tab. */
	POSTS_TAB(By.xpath("//li//span[text()='Posts']"), "The Posts Tab"),

	/** The postnow popup message. */
	POSTNOW_POPUP_MESSAGE(By.xpath("//span[text()='Got it! Your post is on its way, and we’ve saved it in your database for later use']"), "The Post now popup"),

	/** The awaiting approval instagram button. */
	AWAITING_APPROVAL_INSTAGRAM_BUTTON(By.xpath("//li[@class='nav-item']//button[@id='detailed-tabs-tab-instagram' and text()='instagram']"),
	        "The Awaiting Approval Instagram Button"),

	/** The awaiting approval linkedin button. */
	AWAITING_APPROVAL_LINKEDIN_BUTTON(By.xpath("//li[@class='nav-item']//button[@id='detailed-tabs-tab-linkedin' and text()='linkedin']"),
	        "The Awaiting Approval Linkedin Button "),

	/** The awaiting approval facebook button. */
	AWAITING_APPROVAL_FACEBOOK_BUTTON(By.xpath("//li[@class='nav-item']//button[@id='detailed-tabs-tab-facebook' and text()='facebook']"), "The Awaiting Approval facebook Button"),

	/** The awaiting approval twitter button. */
	AWAITING_APPROVAL_TWITTER_BUTTON(By.xpath("//li[@class='nav-item']//button[@id='detailed-tabs-tab-twitter' and text()='twitter']"), "The Awaiting Approval twitter Button"),

	/** The detailedview close button. */
	DETAILEDVIEW_CLOSE_BUTTON(By.xpath("//div[contains(@class,'post-detailed__main')]//div//img[contains(@src,'xmark.svg') and @alt='close']"), "DetailedView close button"),

	/** The post detailedview describtion. */
	POST_DETAILEDVIEW_DESCRIBTION("//div[@class='social-tabs']//div[@class='tab-content']//div[@class='fade tab-pane active show']//div[@class='li-base msg-wrapper']//p[contains(text(),\"%s\")]", "The post Detailed view Describtion"),

	/** The campaign view calendar sunday. */
	CAMPAIGN_VIEW_CALENDAR_SUNDAY(By.xpath("//ul[@class='cdPicker nav nav-tabs']//button[text()='Su']"), "Campaign View Calendar Sunday"),

	/** The campaign view calendar monday. */
	CAMPAIGN_VIEW_CALENDAR_MONDAY(By.xpath("//ul[@class='cdPicker nav nav-tabs']//button[text()='Mo']"), "Campaign View Calendar Monday"),

	/** The campaign view calendar tuesday. */
	CAMPAIGN_VIEW_CALENDAR_TUESDAY(By.xpath("//ul[@class='cdPicker nav nav-tabs']//button[text()='Tu']"), "Campaign View Calendar Tuesday"),

	/** The campaign view calendar wednesday. */
	CAMPAIGN_VIEW_CALENDAR_WEDNESDAY(By.xpath("//ul[@class='cdPicker nav nav-tabs']//button[text()='We']"), "Campaign View Calendar Wednesday"),

	/** The campaign view calendar thursday. */
	CAMPAIGN_VIEW_CALENDAR_THURSDAY(By.xpath("//ul[@class='cdPicker nav nav-tabs']//button[text()='Th']"), "Campaign View Calendar Thursday"),

	/** The campaign view calendar firday. */
	CAMPAIGN_VIEW_CALENDAR_FIRDAY(By.xpath("//ul[@class='cdPicker nav nav-tabs']//button[text()='Fr']"), "Campaign View Calendar Friday"),

	/** The campain view number of post count. */
	CAMPAIN_VIEW_NUMBER_OF_POST_COUNT(
	        By.xpath("//input[@name='campaign_post_per_week']//following-sibling::span[@class='fltlabels' and text()='Number of campaign post per week']"),
	        "the Number of post Coun"),

	/** The campaign view calendar saturday. */
	CAMPAIGN_VIEW_CALENDAR_SATURDAY(By.xpath("//ul[@class='cdPicker nav nav-tabs']//button[text()='Sa']"), "Campaign View Calendar Saturday"),

	/** The campaign view calendar tooltip. */
	CAMPAIGN_VIEW_CALENDAR_TOOLTIP(By.xpath("//span[text()=' scheduled for this day' and text()='Post']//b"), "Campaign View Calendar Tooltip"),

	/** The schedule campaign am session. */
	SCHEDULE_CAMPAIGN_AM_SESSION(By.xpath("//div[@class='switch6']//span[text()='AM']"), "Schedule Campaign AM Session"),

	/** The schedule campaign pm session. */
	SCHEDULE_CAMPAIGN_PM_SESSION(By.xpath("//div[@class='switch6']//span[text()='PM']"), "Schedule Campaign PM Session"),

	/** The schedule campaign view calendar header month year. */
	SCHEDULE_CAMPAIGN_VIEW_CALENDAR_HEADER_MONTH_YEAR(By.xpath("//div[@class='datime-picker']//div[contains(@class,'react-datepicker__current-month')]"),
	        "Calendar Header Month and Year"),

	/** The day of the month. */
	DAY_OF_THE_MONTH("//div[contains(@class,'react-datepicker__day react-datepicker__day--%s')]", "Calendar Day Of The Month"),

	/** The campaign post facebook icon. */
	CAMPAIGN_POST_FACEBOOK_ICON("//div[@class='m-item mi-compact']//div[@class='fltr-imc selectsocial']//img[@alt='Facebook']", "Campaign Post Facebook Icon"),

	/** The campaign post instagram icon. */
	CAMPAIGN_POST_INSTAGRAM_ICON("//div[@class='m-item mi-compact']//div[@class='fltr-imc selectsocial']//img[@alt='Instagra']", "Campaign Post Instagrams Icon"),

	/** The campaign post twitter icon. */
	CAMPAIGN_POST_TWITTER_ICON("//div[@class='m-item mi-compact']//div[@class='fltr-imc selectsocial']//img[@alt='Twitter']", "Campaign Post Twitter Icon"),

	/** The campaign post linked icon. */
	CAMPAIGN_POST_LINKED_ICON("//div[@class='m-item mi-compact']//div[@class='fltr-imc selectsocial']//img[@alt='LinkedIn']", "Campaign Post LinkedIn Icon"),

	/** The campaign post detail view. */
	CAMPAIGN_POST_DETAIL_VIEW("//div[contains(@class,'post-detailed__main')]", "Campaign Post Detail View"),

	/** The campaign post detail view campaign name. */
	CAMPAIGN_POST_DETAIL_VIEW_CAMPAIGN_NAME(By.xpath(
	        "//span[text()='Campaign Details']//parent::div//following::div[@class='wb-f-main']//span[text()='Name']//parent::div//following::div[@class='wbfi-items']//span[@class='wbfi-txt blue-text']//span"),
	        "Campaign Post Detail View Campaign Name"),

	/** The campaign post detail view start date. */
	CAMPAIGN_POST_DETAIL_VIEW_START_DATE(By.xpath("//span[text()='Duration']//parent::div//following::div[@class='wbfi-items']//span[1]"), "Campaign Post Detail View Start Date"),

	/** The campaign post detail view end date. */
	CAMPAIGN_POST_DETAIL_VIEW_END_DATE(By.xpath("//span[text()='Duration']//parent::div//following::div[@class='wbfi-items']//span[3]"), "Campaign Post Detail View End Date"),

	/** The view monthly calendar more option. */
	VIEW_MONTHLY_CALENDAR_MORE_OPTION(
	        "//div[@class='modal-body']//div[contains(@class,'fc-view-harness')]//table//tr//td[contains(@class,'fc-daygrid-day fc-day fc-day-%s')]//div[@class='fc-daygrid-day-bottom']//a[contains(text(),'more')]",
	        "The Monthly Calendar more Option"),

	/** The view monthly calendar more option description. */
	VIEW_MONTHLY_CALENDAR_MORE_OPTION_DESCRIPTION("//div[@class='main-cps']//div[@class='modal-body']//div[@class='post-img']//p[@class='post-content' and text()='%s']",
	        "The Monthly View more Option Post description"),

	/** The view monthly calendater more option close. */
	VIEW_MONTHLY_CALENDATER_MORE_OPTION_CLOSE(By.xpath("//div[@class='modal-content']//div[@class='x-mark']//img[@alt='cancel']"), "The More Option close button"),

	/** The camapaign post list. */
	CAMAPAIGN_POST_LIST(By.xpath("//div[@class='pls post-list__main stackedCards']//div[@class='m-item mi-compact']"), "The Campaign List of Post"),

	/** The footer campaign. */
	FOOTER_CAMPAIGN(By.xpath("//div[@class='pls post-list__main stackedCards']//div[@class='m-item mi-compact'][last()]"), "The Footer for campaign"),

	/** The monthly calendar campaign icon. */
	MONTHLY_CALENDAR_CAMPAIGN_ICON("//p[@class='post-content' and text()='%s']//ancestor::div[@class='fc-daygrid-day-events']//div[@class='img-reduce cmp-icon']",
	        "The Monthly Calendar Campaign Icon"),

	/** The schedulepost date bysingleplatform. */
	SCHEDULEPOST_DATE_BYSINGLEPLATFORM(
	        "//tbody//td[contains(@class,'fc-day-%s fc-day-future')]//ancestor::div[@class='creator-schedule-section-wrp cg-green ']//p[@class='post-content' and @title='%s']",
	        "The Schedule post date"),

	/** The schedulepost date bymultiple platform. */
	SCHEDULEPOST_DATE_BYMULTIPLE_PLATFORM(
	        "//tbody//td[contains(@class,'fc-day-%s fc-day-future')]//div[@class='social-icon-sec-new']//img[@alt='Facebook']//parent::div//following-sibling::div//img[@alt='Twitter']//parent::div//following-sibling::div//img[@alt='LinkedIn']//ancestor::div[@class='creator-schedule-section-wrp cg-green ']//p[@class='post-content' and text()='%s']",
	        "The Schedule day by Multiple platform"),

	/** The view calendar page next month. */
	VIEW_CALENDAR_PAGE_NEXT_MONTH(By.xpath("//div[@class='fc-button-group']//span[@class='fc-icon fc-icon-chevron-`']"), "The View calendar page next Month Button"),

	/** The view calendar page previous month. */
	VIEW_CALENDAR_PAGE_PREVIOUS_MONTH(By.xpath("//div[@class='fc-button-group']//span[@class='fc-icon fc-icon-chevron-left']"), "The View Calendar previous Month"),

	/** The campaign right section locations. */
	CAMPAIGN_RIGHT_SECTION_LOCATIONS(By.xpath("//div[@class='mp-startCampaign cmp-form']//input[@name='included_accounts']"), "Campaign Right Section starting Date"),

	/** The campaign right section start date. */
	CAMPAIGN_RIGHT_SECTION_START_DATE(By.xpath("//div[@class='mp-startCampaign cmp-form']//input[@name='start_datetime']"), "Campaign Right Section starting Date"),

	/** The campaign right section end date. */
	CAMPAIGN_RIGHT_SECTION_END_DATE(By.xpath("//div[@class='mp-startCampaign cmp-form']//input[@name='end_datetime']"), "Campaign Right Section End Date"),

    // ***

	/** The post detailedview removepost hubloc. */
    POST_DETAILEDVIEW_REMOVEPOST_HUBLOC(By.xpath("//span[@class='checkbox-hover']//input[@name='removeFromHub&Loc']"), "The remvoe post from loc & hub checkbox"),

	/** The post detailedview removepost media. */
	POST_DETAILEDVIEW_REMOVEPOST_MEDIA(By.xpath("//span[@class='checkbox-hover']//input[@name='removeFromMedia']"), "The remove post from media"),

	/** The campaign post detail view edit button. */
	CAMPAIGN_POST_DETAIL_VIEW_EDIT_BUTTON(By.xpath("//div[contains(@class,'post-detailed__main')]//div[contains(@class,'btn-ac--wrp')]//button[text()='Edit']"),
	        "Campaign Post Detail View Edit Button"),

	/** The post view campaign tag of the post. */
	POST_VIEW_CAMPAIGN_TAG_OF_THE_POST(
	        "//div[contains(@class,'m-item ')]//div[contains(@class,'mi-front')]//p[text()='%s']//ancestor::div[@class='mi-front']//preceding-sibling::div[@class='campaign-tag']",
	        "Post in Campaign view"),

	/** The monthly calendar campaign posts. */
	MONTHLY_CALENDAR_CAMPAIGN_POSTS("//p[@class='post-content']//ancestor::div[@class='fc-daygrid-day-events']//div[@class='img-reduce cmp-icon']",
	        "The Monthly Calendar Campaign Icon"),

	/** The campaign view update active campaign modal. */
	CAMPAIGN_VIEW_UPDATE_ACTIVE_CAMPAIGN_MODAL(By.xpath("//div[@class='modal-message-wraps-text' and contains(text(),'You are editing an active campaign')]"),
	        "Campaign view update Active Campaign View"),

	/** The campaign view update active campaign modal update campaign button. */
	CAMPAIGN_VIEW_UPDATE_ACTIVE_CAMPAIGN_MODAL_UPDATE_CAMPAIGN_BUTTON(By.xpath(
	        "//div[@class='modal-message-wraps-text' and contains(text(),'You are editing an active campaign')]//parent::div//parent::div[@class='modal-body']//following-sibling::div//button[text()='Update Campaign']"),
	        "Campaign view update Active Campaign Model Update campaign"),

	/** The post describtion. */
	POST_DESCRIBTION(By.xpath("//div[contains(@class,'mi-front')]//div[@class='msg-wrapper']//p[text()]"),"Post Describtion"),
	
	/** The post describtion byname. */
	POST_DESCRIBTION_BYNAME("//div[contains(@class,'mi-front')]//div[@class='msg-wrapper']//p[contains(text(),\"%s\")]","Post Describtion Name"),

	POST_RESULT("//div[contains(@class,'mi-front')]//div[@class='msg-wrapper']//p[contains(@title,\"%s\")]","Post Describtion Name"),

	/** The month picker. */
	MONTH_PICKER(By.xpath("//select[@class='react-datepicker__month-select']"), "Month picker"),
	
	//User name , location navigation  and profile modification page enums;

	/** The Profile icon. */
	PROFILE_ICON(By.xpath(
		     "//div[@class='drop-items ha-item profile-items dropdown']//button[@id='dropitems-profile-items']"),
		        "Clicking on the profile icon"),
		
		/** The Edit option of profile icon. */
		PROFILE_EDIT_ICON(By.xpath(
		        "//div[@class='dropdown-menu show']//a[@role='button']//img[@alt='Edit profile details']"),
		        "clicking Edit icon in profile"),
		
		/** The Profile image Edit option of profile icon. */
		PROFILE_IMAGE_EDIT_ICON(By.xpath(
		        "//div[@class='change-password-modal-conent-section']//input[@type='file']"),
		        "Clicking on profile image edit icon"),
		
		
		/** The First name in profile icon. */
		FIRST_NAME(By.xpath(
		        "//div[@class='form-section-wrp']//div[@class='form-group form-field-item ']//input[@name='firstName']"),
		        "First name"),
		
		
		/** The Last name in profile icon. */
		LAST_NAME(By.xpath(
		        "//div[@class='form-section-wrp']//div[@class='form-group form-field-item ']//input[@name='lastName']"),
		        "Last name"),
		
		/** The Update button in profile icon. */
		UPDATE_BUTTON(By.xpath(
		        "//div[@class='form-section-wrp']//button[@class='ac-btn ac-primary ac-block ']"),
		        "Click on update button"),
		
		/** The Close Option. */
		CLOSE_ICON(By.xpath(
		        "//div[@class='change-password-modal-conent-section']//img[@alt='close']"),
		        "The Close option"),
		
		/** The Success message. */
		SUCCESS_MESSAGE(By.xpath(
		        "//div[@id='success']//span[@class='success-mess-txt' and text()='Saved!']"),
		        "The success message"),
		
		/** The Removing profile icon. */
		DELETE_PROFILE_IMAGE(By.xpath(
		        "//div[@class='profileinfo-user-section']//button[@class='btn btn-secondary']//div[@class='delete-icon']"),
		        "Deleting the profile image"),
		
		
		/** The user name. */
		USER_NAME(By.xpath(
		        "//div[@class='dropdown-menu show']//a[@title='Automation Testing']"),
		        "User name"),
		
		/** The user name. */
		HUB_USER_NAME(By.xpath(
		        "//div[@class='dropdown-menu show']//a[@title='QA Team']"),
		        "User name"),
		
		/** Clicking on location option. */
		ACCOUNT_SWITCHER_OPTION(By.xpath(
		        "//div[@class='brand-hub--active ha-item local-user  ']//div[@class='ds-dropdown']"),
		        "clicking on account switcher option"),
    
	ACCOUNT_SWITCHER_LOCATION(By.xpath("//div[@class='ds-dropdown']//span[@class='css-19r5em7']"),"ACCOUNT_SWITCHER_LOCATION"),
		
	/** The ai subscribtion video play. */
	AI_SUBSCRIBTION_VIDEO_PLAY(By.xpath(
			"//div[@role='tooltip']//div[@class='aicoach-body']//div[@class='aicoach-cnt']//div[@class='ai-coach-video']"),
			"AI Subscribtion Video Play"),

	/** The ai video donot show me checkbox. */
	AI_VIDEO_DONOT_SHOW_ME_CHECKBOX(By.xpath(
			"//div[@class='aicoach-body']//label[@class='checkbox-item']//span[@class='checkbox-hover']//input[@name='localizePost']"),
			"AI Subscribtion Video Check Box"),

	POST_LIST_INTERNAL_NOTES_TAB(By.xpath("//div[@class='mi-hover postlist-view-tooltipwrp post-new-list--wrp']//div[@class='mi-cntrls']//span[1]//img[@alt='Internal Notes']"),"Internal Notes Button"),

	POST_LIST_COPY_TAB(By.xpath("//div[@class='mi-hover postlist-view-tooltipwrp post-new-list--wrp']//div[@class='mi-cntrls']//span[1]//img[@alt='Copy']"),"POST_LIST_COPY_TAB"),

	POST_LIST_SCHEDULE_TAB(By.xpath("//div[@class='mi-hover postlist-view-tooltipwrp post-new-list--wrp']//div[@class='mi-cntrls']//span[1]//img[@alt='Time']"),"Post List Schedule Tab"),

	/** The status ready posts. */
	STATUS_READY_POSTS(By.xpath(
			"//div[contains(@class,'mi-front')]//div[@class='mif-head']//div[@class='round-asset brand-icon']//img[contains(@src,'approved.svg')]"),
			"STATUS_READY_POSTS"),

	/** The status awaiting approval location posts. */
	STATUS_AWAITING_APPROVAL_LOCATION_POSTS(By.xpath(
			"//div[contains(@class,'mi-front')]//div[@class='mif-head']//div[@class='round-asset brand-icon']//img[contains(@src,'pending-filled.svg')]"),
			"STATUS_AWAITING_APPROVAL_LOCATION_POSTS"),

	/** The status awaiting approval ai posts. */
	STATUS_AWAITING_APPROVAL_AI_POSTS(By.xpath(
			"//div[contains(@class,'mi-front')]//div[@class='mif-head']//div[contains(@class,'round-asset brand-icon')]//img[contains(@src,'pending-filled.svg')]"),
			"STATUS_AWAITING_APPROVAL_AI_POSTS"),

	/** The status awaiting approval mycontent posts. */
	STATUS_AWAITING_APPROVAL_MYCONTENT_POSTS(By.xpath(
			"//div[contains(@class,'mi-front')]//div[@class='mif-head']//div[@class='round-asset brand-icon']//img[contains(@src,'pending-filled.svg')]"),
			"STATUS_AWAITING_APPROVAL_MYCONTENT_POSTS"),

	/** The status draft posts. */
	STATUS_DRAFT_POSTS(By.xpath(
			"//div[contains(@class,'mi-front')]//div[@class='mif-head']//div[@class='round-asset brand-icon']//img[contains(@src,'draft-filled.svg')]"),
			"STATUS_DRAFT_POSTS"),
	
	/** The month dropdown. */
	MONTH_DROPDOWN(By.xpath("//select[@class='react-datepicker__month-select']"), "Month drop down"),

	/** The year dropdown. */
	YEAR_DROPDOWN(By.xpath("//select[@class='react-datepicker__year-select']"), "Year drop down."),
	
	/** The date picker. */
    DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]","Date Picker"),
	
	/** The awaiting ai generated filter. */
	AWAITING_AI_GENERATED_FILTER(By.xpath("//div[@class='pending-item loc-content']//div[@class='awt-txt-dtls']//span[text()='Awaiting']//following-sibling::span[text()='AI Generated']"),"Awaited AI Generated Filter"),
	
	/** The unapproved post status. */
	UNAPPROVED_POST_STATUS("//p[contains(text(),'%s')]//ancestor::div[@class='mi-front']//div[@class='mif-head']//div[@class='round-asset brand-icon']//img[contains(@src,'pending-filled.svg')]","UnApproved Post Status"),
	
	/** The campaign post by name. */
	CAMPAIGN_POST_BY_NAME("//div[contains(@class,'m-item')]//div[@class='campaign-tag']//following-sibling::div[@class='mi-front']//p[contains(text(),'%s')]","CAMPAIGN_POST_BY_NAME"),
	
	/** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),
	
	/** The approved post status. */
	APPROVED_POST_STATUS("//p[contains(text(),'%s')]//ancestor::div[@class='mi-front']//div[@class='mif-head']//div[@class='round-asset brand-icon']//img[contains(@src,'approved.svg')]","Approved Post Status"),
	
	/** The ai released alert popup. */
	AI_RELEASED_ALERT_POPUP(By.xpath("//div[contains(@class,'mbl-head--margin')]//div[contains(@class,'api-alert-box')]//div[@class='ab-cnt']//p[text()='Our latest AI has just been released! Try it now and experience some truly incredible results!']"),"AI_RELEASED_ALERT_POPUP"),
	
	/** The ai released alert popup cancel. */
	AI_RELEASED_ALERT_POPUP_CANCEL(By.xpath("//div[contains(@class,'mbl-head--margin')]//div[contains(@class,'api-alert-box')]//div[@class='ab-cnt']//following::div[@class='alert-icon ai-x']"),"AI_RELEASED_ALERT_POPUP_CANCEL"),
	
	/** The ai type all filter. */
	AI_TYPE_ALL_FILTER(By.xpath("//h3[text()='AI Type']//parent::div[@class='filter-item']//input[@class='option-input radio']//following-sibling::span[text()='All']"),"AI- Type All Filter"),
	
	/** The ai type ai assisted filter. */
	AI_TYPE_AI_ASSISTED_FILTER(By.xpath("//h3[text()='AI Type']//parent::div[@class='filter-item']//input[@class='option-input radio']//following-sibling::span[text()='AI Assisted']"),"AI TYPE AI ASSISTED FILTER"),
	
	/** The ai type non ai assisted filter. */
	AI_TYPE_NON_AI_ASSISTED_FILTER(By.xpath("//h3[text()='AI Type']//parent::div[@class='filter-item']//input[@class='option-input radio']//following-sibling::span[text()='Non-AI Assisted']"),"Non Ai Assisted Filter"),
	
	/** The ai type ai assisted filter active. */
	AI_TYPE_AI_ASSISTED_FILTER_ACTIVE(By.xpath("//h3[text()='AI Type']//parent::div[@class='filter-item']//input[@class='option-input radio']//following-sibling::span[text()='AI Assisted']"),"AI_TYPE_AI_ASSISTED_FILTER_ACTIVE"),
	
	/** The ai type non ai assisted filter active. */
	AI_TYPE_NON_AI_ASSISTED_FILTER_ACTIVE(By.xpath("//h3[text()='AI Type']//parent::div[@class='filter-item']//input[@class='option-input radio']//following-sibling::span[text()='AI Assisted']"),"AI_TYPE_NON_AI_ASSISTED_FILTER_ACTIVE"),

	/** The list of post as per internal notes of media. */
	POST_LIST(By.xpath("//div[@class='m-item mi-compact']//div[contains(@class,'mi-hover postlist-view')]"),"The list of post as per internal notes of media"),

	/** The Instagram padded image in detail view */
	INSTAGRAM_PADDED_IMAGE_IN_DETAIL_VIEW(By.xpath("//div[@class='lv-assets']//li[2]//div[contains(@class,'gma-item all-fade-in')]//img[contains(@src,'c_pad')]"), "Instagram padded image in detail view"),


	/** The Instagram cropped image in detail view */
	INSTAGRAM_CROPPED_IMAGE_IN_DETAIL_VIEW(By.xpath("//div[@class='lv-assets']//li[2]//div[contains(@class,'gma-item all-fade-in')]//img[contains(@src,'c_fill')]"), "Instagram cropped image in detail view"),

	POST_LAST_SYNDICATED_SECTION_LOCATION(
			"//span[@class='wbf-label' and text()='Last Syndicated']//following::div[@class='wbfi-items flex-wrap']//span[@class='wbfi-txt blue-text cur-pointer' and text()='%s']",
			"LAST_SYNDICATED_SECTION_LOCATION"),
	SEARCH_POST_RESULT("//div[contains(@class,'m-item')]//div[@class='msg-wrapper']//p[contains(@title,\"%s\")]", "Search result"),

	SECOND_COMMON_POST(By.xpath("(//div[contains(@class,'m-item ')]//div[contains(@class,'mi-front')]//p[text()])[2]"),"Second common post"),

	CONTENT_SUPPLIER_SOURCE_FILTER(By.xpath("//span[contains(text(),'Content Supplier')]//parent::label//input"),"Content Supplier Source Filter"),

	SELECT_SOURCE_FILTER("//h3[text()='Source']//ancestor::div[@class='filter-item']//span[contains(text(),'%s')]//parent::label//span[text()]","Select Source Filter"),

	SELECTED_SOURCE_FILTER("//h3[text()='Source']//ancestor::div[@class='filter-item']//span[contains(text(),'%s')]//parent::label[@class='active']//input","Selected Source Filter"),

	PLATFORM_BY_POST_NAME("//img[@alt='%s']//parent::button//ancestor::div[@class='mi-front']//div[@class='msg-wrapper']//p[contains(text(),'%s')]","Platform By Post Name");
	
	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new content tab posts page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private ContentTabPostsPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new content tab posts page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private ContentTabPostsPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

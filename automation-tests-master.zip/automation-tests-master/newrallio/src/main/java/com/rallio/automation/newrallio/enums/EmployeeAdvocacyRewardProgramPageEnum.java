package com.rallio.automation.newrallio.enums;

 

import org.openqa.selenium.By;

 

// TODO: Auto-generated Javadoc
/**
* The Enum EmployeeAdvocacyRewardProgramPageEnum.
*/
public enum EmployeeAdvocacyRewardProgramPageEnum {

    /** The page load. */
    PAGE_LOAD(By.xpath(
            "//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Reward Programs']//ancestor::div//section[contains(@class,'item-g filter rewards-filter')]//preceding::div//section[@id='main-container-sec']//div[@class='content-g']//div[contains(@class,'adv-onboarding-wrp adv-rewardsmainsection')]"),
            "Page load"),

    /** The reward program tab. */
    REWARD_PROGRAM_TAB(By.xpath("//span[text()='Reward Programs' and @class='sub-nav-item-txt']"),
            "Reward Program Tab"),

    /** The create program button. */
    CREATE_PROGRAM_BUTTON(By.xpath("//div//button[contains(@class,'create-program')]"), "Create Program Button"),

    /** The program moreoption button. */
    PROGRAM_MOREOPTION_BUTTON(By.xpath("//table[contains(@class,'table-global ad')]//tbody//tr//td//img[@class='info-icon']"), "Program More Option Button"),

    /** The search tab. */
    SEARCH_TAB(By.xpath("//div[@class='react-tags__search-input']//input"), "Search Tab"),

    /** The download csv. */
    DOWNLOAD_CSV(By.xpath("//span[text()='Download CSV']//preceding-sibling::img//parent::button"), "Download CSV"),

    /** The clear filter. */
    CLEAR_FILTER_BUTTON(By.xpath("//div[@class='filter-item clear-filter']//div[not(contains(@class,'pointer-events none'))]//button"), "Clear Filter Button"),

    /** The clear filter disable. */
    CLEAR_FILTER_BUTTON_DISABLED(By.xpath("//div[contains(@class,'pointer-events-none')]//button//span[text()='Clear Filter']//parent::button"), "Clear Filter Button Disabled"),

    /** The table program column. */
	TABLE_PROGRAM_COLUMN(
			By.xpath("//table//tr//th[text()='Program']//ancestor::table//td//span[contains(@class,'state-indications-txt')]"),
			"Table Program Column"),

	/** The table start date column. */
	TABLE_START_DATE_COLUMN(
			By.xpath("//table//thead//tr//th[text()='Start Date']//ancestor::table//tbody/tr//td[3]"),
			"Table Start Date column"),

	/** The table end date column. */
	TABLE_END_DATE_COLUMN(
			By.xpath("//table//thead//tr//th[text()='End Date']//ancestor::table//tbody/tr//td[4]"),
			"Table End Date Column"),

	/** The table total budget column. */
	TABLE_TOTAL_BUDGET_COLUMN(
			By.xpath("//table//thead//tr//th[text()='Total Budget']//ancestor::table//tbody/tr//td[5]"),
			"Table Total Budget column"),
	
	/** The table amount spent column. */
	TABLE_AMOUNT_SPENT_COLUMN(
			By.xpath("//table//thead//tr//th[text()='Amount Spent']//ancestor::table//tbody/tr//td[6]"),
			"Table Amount Spent Column"),

    /** The table achievers column. */
    TABLE_ACHIEVERS_COLUMN(
            By.xpath("//table//thead//tr//th[text()='Achievers']//ancestor::table//tbody/tr//td[7]"),
            "Table Achievers Column"),

    /** The table location column. */
	TABLE_LOCATION_COLUMN(
			By.xpath("//table//tr//th[text()='Locations']//ancestor::table//td//div[contains(@class,'rp-location-count-int')]//span[@class='rp-location-count-item']"),
			"Table Location column"),

	/** The footer. */
	FOOTER(By.xpath("//table[contains(@class,'table-global')]//tbody//tr[last()]"), "Footer"),
    
	/** The all program. */
    ALL_PROGRAM(By.xpath("//span[text()='All']//parent::label//input[@value='all']"), "All Program"),

    /** The recommended program. */
    RECOMMENDED_PROGRAM(
            By.xpath("//span[text()='Recommended Program']//parent::label//input[@value='recommended_program']"),
            "Recommended Program"),

    /** The reward program. */
    REWARD_PROGRAM(By.xpath("//span[text()='Reward Program']//parent::label//input[@value='reward_program']"),
            "Reward Program"),
	
	/** Search result of newly created recommended program with cash option */
	PROGRAM_SEARCH_RESULT("//div[contains(@class,'initial-status-head-wraps')]//span[contains(@class,'state-indications-txt') and text()='%s']",
			"Search result of newly created recommended program with cash option "),
	
	/** The create program text. */
	CREATE_PROGRAM_TEXT(By.xpath("//div[@class='modal-body']//span[@class='title' and text()='Create Program']"),
			"create program text"),
	
	/** The create program close option. */
	CREATE_PROGRAM_CLOSE_OPTION(By.xpath("//div[@class='modal-body']//div[@class='header-item__wrp']//img[@class='close']"),
			"create program close option"),
	
	/** The create program profile icon. */
	CREATE_PROGRAM_PROFILE_ICON(By.xpath("//div[contains(@class,'modal-wrp')]//div[contains(@class,'author-details')]//div[@class='avathar-icon']"),
			"create program profile icon"),
	
	/** The create program User name. */
	CREATE_PROGRAM_USER_NAME("//div[@class='list-expanded-asset-text-top']//span[@class='list-expanded-asset-author-name' and text()='%s']",
			"create program User name"),

	/** The create program User name. */
	CREATE_PROGRAM_LOCATION_USER_NAME("//div[@class='list-expanded-asset-text-top']//span[@class='list-expanded-asset-author-name' and text()='%s']",
			"create program User name"),
	
	
	/** The create program Date and time. */
	CREATE_PROGRAM_DATE_TIME(By.xpath("//div[contains(@class,'modal-wrp')]//span[@class='list-expanded-asset-date-time']"),
			"create program Date and time"),
	
	/** The Program details text */
	PROGRAM_DETAILS_TEXT(By.xpath("//div[contains(@class,'modal-wrp')]//div[@class='alert-heading h4' and text()='Program Details']"),
			"The Program details text"),
	
	/** The Program name */
	PROGRAM_NAME(By.xpath("//div[contains(@class,'modal-wrp')]//div[@class='left-section']//span[text()='Program Name ']//parent::div[@class='left-section']//following-sibling::div[@class='right-section']//input[@class='form-control']"),
			"The Program name"),
	
	/** The recommended program option */
	CREATE_PROGRAM_RECOMMENDED_PROGRAM_OPTION(By.xpath("//div[contains(@class,'modal-wrp')]//div[@class='left-section']//span[text()='Recommended Program ']//parent::div[@class='left-section']//following-sibling::div[contains(@class,'right-section')]//input[@type='checkbox']"),
			"The recommended program option"),
	
	/** The cash prize button */
	CASH_PRIZE_BUTTON(By.xpath("//div[contains(@class,'modal-wrp')]//div[@class='left-section']//span[text()='Type ']//parent::div[@class='left-section']//following-sibling::div[@class='right-section']//button[@type='button' and text()='Cash Prize']"),
			"The cash prize button"),

	/** The Non - cash prize button */
	NONCASH_PRIZE_BUTTON(By.xpath("//div[contains(@class,'modal-wrp')]//div[@class='left-section']//span[text()='Type ']//parent::div[@class='left-section']//following-sibling::div[@class='right-section']//button[@type='button' and text()='Non-Cash Prize']"),
			"The Non - cash prize button"),
	
	/** The Duration start and end date */
	DURATION_START_AND_END_DATE_OPTION(By.xpath("//div[contains(@class,'modal-wrp')]//div[@class='left-section']//span[text()='Duration']//parent::div[@class='left-section']//following-sibling::div[@class='right-section']//input[@type='radio']//parent::label//span[text()='Set a Start and End Date']"),
			"The Duration start and end date"),
	
	/** The Duration Ongoing option*/
	DURATION_ONGOING_OPTION(By.xpath("//div[contains(@class,'modal-wrp')]//div[@class='left-section']//span[text()='Duration']//parent::div[@class='left-section']//following-sibling::div[@class='right-section']//div[@class='duration-wrp']//span[@class='labelText' and text()='Ongoing']//parent::label//input[@type='radio']"),
			"The Duration OngoinG option"),
	
	/** The start option in duration*/
	DURATION_START_DATE_OPTION(By.xpath("//div[contains(@class,'modal-wrp')]//div[contains(@class,'datepicker__input')]//input[@placeholder='Start date & time']"),
			"The start option in duration"),
	
	/** The end option in duration*/
	DURATION_END_DATE_OPTION(By.xpath("//div[contains(@class,'modal-wrp')]//div[contains(@class,'datepicker__input')]//input[@placeholder='End date & time']"),
			"The end option in duration"),
	
	/** The Program budget*/
	PROGRAM_BUDGET(By.xpath("//div[contains(@class,'modal-wrp')]//div[@class='left-section']//span[text()='Program Budget']//parent::div[@class='left-section']//following-sibling::div[@class='right-section']//input[@name='programBudget']"),
			"The Program budget"),

	/** The Program actions and reward option*/
	PROGRAM_ACTION_AND_REWARDS(By.xpath("//div[contains(@class,'modal-wrp')]//div[@class='left-section' and text()='Program Action and Rewards']"),
			"The Program actions and reward option"),
	
	/** The Locations option*/
	LOCATIONS_OPTIONS(By.xpath("//div[contains(@class,'modal-wrp')]//div[@class='left-section' and text()='Locations']"),
			"The Locations option"),
	
	/** The Email template option*/
	EMAIL_TEMPLATE_OPTION(By.xpath("//div[contains(@class,'modal-wrp')]//div[@class='alert-heading h4' and text()='Email Template']"),
			"The Email template option"),
	
	/** The Payment option*/
	PAYMENT_OPTION(By.xpath("//div[contains(@class,'modal-wrp')]//div[@class='alert-heading h4' and text()='Payment']"),
			"The Payment option"),

	/** The Save as draft button*/
	SAVE_AS_DRAFT_BUTTON(By.xpath("//div[@class='modal-body']//div[@class='right-button-section']//button[contains(@class,'secondary-white')]"),
			"The Save as draft button"),
	
	/** The Save Program button*/
	SAVE_PROGRAM_BUTTON(By.xpath("//div[@class='modal-body']//div[@class='right-button-section']//button[contains(@class,'ac-primary')]"),
			"The Save Program button"),
	
	/** The Recommended Program data*/
	RECOMMENDED_PROGRAM_DATA(By.xpath("//table[contains(@class,'table-global')]//span[contains(@class,'si-blue')]//following-sibling::span[@class='rcmnd-item tool-tip-view base-r cursor-help blue' and text()='Recommended']"),
			"The Recommended Program data"),
	
	/** The Ongoing reward program data*/
	ONGOING_REWARD_PROGRAM_DATA(By.xpath("//table[contains(@class,'table-global')]//div[@class='initial-status-head-wraps rp-rcmnd-item grid-rwrd-tmp-1']//span[contains(@class,'si-green')]"),
			"The Ongoing reward program data"),
	
	/** The Expired reward program data*/
	EXPIRED_REWARD_PROGRAM_DATA(By.xpath("//table[contains(@class,'table-global')]//td[@class=' pivoted']//span[contains(@class,'si-grey')]"),
			"The Expired reward program data"),
	
	/** The Ending tomorrow reward program data*/
	ENDING_TOMORROW_REWARD_PROGRAM_DATA(By.xpath("//table[contains(@class,'table-global')]//td[@class=' pivoted']//span[contains(@class,'si-orange')]//following-sibling::span[@class='rcmnd-item tool-tip-view base-r orange' and text()='Ending Tomorrow']"),
			"The Ending tomorrow reward program data"),
	
	/** The Ending today reward program data*/
	ENDING_TODAY_REWARD_PROGRAM_DATA(By.xpath("//table[contains(@class,'table-global')]//td[@class=' pivoted']//span[contains(@class,'si-orange')]//following-sibling::span[@class='rcmnd-item tool-tip-view base-r orange' and text()='Ending Today']"),
			"The Ending today reward program data"),
	
	/** The draft reward program data*/
	DRAFT_REWARD_PROGRAM_DATA(By.xpath("//table[contains(@class,'table-global')]//span[contains(@class,'si-purple')]//following-sibling::span[@class='rcmnd-item tool-tip-view base-r purple' and text()='Draft']"),
			"The draft reward program data"),
	
	/** The Default data*/
	DEFAULT_DATA(By.xpath("//div[@class='form-group']//label[@class='active']//input[@value='all']"),
			"The Default data"),
	
	/** The table view list. */
	TABLE_VIEW_LIST(By.xpath("//table//tbody//tr//div[contains(@class,'initial-status')]"), "Table view list"),
	
	/** TableView list footer. */
	TABLE_VIEW_LIST_FOOTER(By.xpath("//table//tbody//tr[last()]"), "TableView list footer"),
	
	/** The search result for copy option. */
	SEARCH_RESULTS("//tr[@class='crData']//td//span[text()='%s']",
			"SEARCH_RESULTS"),

	/** The More option Copy button. */
	MORE_BUTTON_COPY_BUTTON(By.xpath("//tbody//div[@class='right-section-wrp']//button[contains(@class,'btn-items btn btn-primary')]"),
			"The More option Copy button"),
	
	/** The More option Edit button. */
	MORE_BUTTON_EDIT_BUTTON(By.xpath("//tbody//div[@class='right-section-wrp']//button[contains(@class,'edit-btn btn btn-primary')]"),
			"The More option Edit button."),
	
	/** The More option Delete button. */
	MORE_BUTTON_DELETE_BUTTON(By.xpath("//tbody//div[@class='right-section-wrp']//button[contains(@class,'delete-btn__hover btn btn')]"),
			"The More option Delete button."),
	
	/** The Copy Success message. */
	SUCCESS_MESSAGE(By.xpath("//div[@class='Toastify']//span[@class='success-mess-txt' and text()='Program copied successfully!']"),
			"The Copy Success message"),
	
	/** The Delete modal pop up */
	DELETE_MODAL_POP_UP(By.xpath("//div[@class='modal-content']//div[@class='modal-message-wraps' and text()='Are you sure you want to delete this reward program?']"),
			"TThe Delete modal pop up"),
	
	/** The Delete modal pop up cancel option */
	DELETE_MODAL_CANCEL_BUTTON(By.xpath("//div[@class='modal-content']//div[@class='modal-btn-grp-wraps']//button[@class='modal-btn-action-itm modal-cancel-btn' and text()='Cancel']"),
			"The Delete modal pop up cancel option "),

	/** The Delete modal pop up delete option */
	DELETE_MODAL_DELETE_BUTTON(By.xpath("//div[@class='modal-content']//div[@class='modal-btn-grp-wraps']//button[@class='modal-btn-action-itm modal-delete-btn' and text()='Delete']"),
			"The Delete modal pop up delete option "),
	
	/** The Delete Success message */
	DELETE_SUCCESS_MESSAGE(By.xpath("//div[@class='Toastify']//span[@class='success-mess-txt' and text()='Reward program deleted!']"),
			" The Delete Success message"),
	
	/** The Reward program Detail view */
	REWARD_PROGRAM_DETIAL_VIEW(By.xpath("//div[@class='rewards-programdetails-modal-wrp']//div[@class='card']"),
			"The Reward program Detail view"),
	
	/** The Detial view - delete button */
	DETIAL_VIEW_DELETE_BUTTON(By.xpath("//div[@class='right-button-section']//button[@class='ac-btn ac-danger ac-block' and text()='Delete']"),
			"The Detial view - delete button"),
	
	/** The Download started pop up */
	DOWNLOAD_STARTED_POP_UP(By.xpath("//div[@class='Toastify__toast-body']//span[@class='success-mess-txt' and text()='Download started']"),
			"The Download started pop up"),
	
	/** The Download done pop up */
	DOWNLOAD_DONE_POP_UP(By.xpath("//div[@class='Toastify__toast-body']//span[@class='success-mess-txt' and text()='Done!']"),
			"The Download done pop up"),
	
	/** The Reward program - Program name */
	CREATE_PROGRAM_PROGRAM_NAME(By.xpath("//div[contains(@class,'program-details')]//div[contains(@class,'form-group')]//input[@placeholder='Enter Program Name']"),
			"The Download done pop up"),
	
	/** The Reward program saved success message */
	SAVED_SUCCESS_MESSAGE(By.xpath("//div[@class='Toastify__toast-body']//span[@class='success-mess-txt' and text()='Program saved successfully!']"),
			"the Reward program saved success message"),
	
	/** The Draft program */
	DRAFT_PROGRAM("//table[contains(@class,'table-global')]//div[contains(@class,'initial-status')]//span[text()='%s']",
			"The Draft program"),
	
	/** The Add action button */
	CREATE_PROGRAM_ADD_ACTION(By.xpath("//div[@class='card-body']//div[@class='grid-sec-item1']//div[@class='left-section' and text()='Program Action and Rewards']//parent::div[@class='grid-sec-item1']//div[@class='cursor-pointer']"),
			"The Add action button "),
	
	/** The Add location button */
	CREATE_PROGRAM_ADD_LOCATION(By.xpath("//div[@class='card-body']//div[@class='info-icon' ]//img[@alt='add']"),
			"The Add location button"),
	
	/** Selecting all location from add location option */
	CREATE_PROGRAM_ADD_LOCATION_ALL_LOCATION_OPTION(By.xpath("//div[@class='modal-body']//h3[text()='Choose Program Hubs and Locations']//parent::div//label[text()='All Locations']//parent::div//input[@type='radio']"),
			"Selecting all location from add location option"),

	/** Selecting specific location from add location option */
	CREATE_PROGRAM_ADD_LOCATION_SPECIFIC_LOCATION_OPTION(By.xpath("//div[@class='modal-body']//h3[text()='Choose Program Hubs and Locations']//parent::div//label[text()='Specific Locations']//parent::div//input[@type='radio']"),
			"Selecting specific location from add location option"),


	/** Selecting specific location/list from add location option */
	CREATE_PROGRAM_ADD_LOCATION_SPECIFIC_LOCATION_AND_LIST_OPTION(By.xpath("//div[@class='modal-body']//h3[text()='Choose Program Hubs and Locations']//parent::div//label[text()='Specific Locations/Lists']//parent::div//input[@type='radio']"),
			"Selecting specific location/list from add location option"),

	/** Add location - save button */
	CREATE_PROGRAM_ADD_LOCATION_SAVE_BUTTON(By.xpath("//div[@class='modal-content']//button[@class='modal-btn-action-itm modal-post-now-btn' and text()='Save']"),
			"All location - save button"),
	
	/** Add location - Specific location */
	CREATE_PROGRAM_ADD_LOCATION_SPECIFIC_LOCATION(By.xpath("//div[contains(@class,'tree-location rc-tree')]//span[@title='QAA Location Two']//parent::div//span[@class='rc-tree-checkbox']"),
			"Add location - Selecting specific location"),
	
	/** Email template - send now option */
	CREATE_PROGRAM_EMAIL_TEMPLATE_SEND_NOW_OPTION(By.xpath("//div[@class='email-notify-grid-section']//span[@class='labelText' and text()='Send Now']//parent::label//input[@type='radio']"),
			"Email template - send now option"),
	
	/** Email template - Never send option */
	CREATE_PROGRAM_EMAIL_TEMPLATE_NEVER_SEND(By.xpath("//div[@class='email-notify-grid-section']//label[@class='active']//input[@value='2']"),
			"Email template - Never send option"),
	
	/** program actions and rewards  - Publish brand approved content option*/
	PUBLISH_BRAND_APPROVED_CONTENT(By.xpath("//label[@class='checkbox-item radio-item']//span[@class='label-txt' and text()='Publish Brand Approved Content']//parent::label//span[@class='checkmark']"),
			"select Publish brand approved content option"),
	
	/** program actions and rewards  - Advocacy post option*/
	CREATE_PROGRAM_ADVOCACY_POST_OPTION(By.xpath("//label[@class='checkbox-item radio-item']//span[@class='label-txt' and text()='By the number of advocacy posts they share']//parent::label//span[@class='checkmark']"),
			"select program actions and rewards  - Advocacy post option"),
	
	/** program actions and rewards  - Advocacy post count value*/
	CREATE_PROGRAM_ADVOCACY_POST_COUNT_VALUE(By.xpath("//div[@class='msdb-brand-email-wraps']//input[@name='actions.0.actionItem.value']"),
			"select program actions and rewards  - Advocacy post count value"),
	
	/** The Program action and rewards submitted option */
	CREATE_PROGRAM_PROGRAM_ACTION_AND_REWARDS_SUBMITTED_OPTION(By.xpath("//label[@class='checkbox-item radio-item']//span[@class='label-txt' and text()='submitted (Does not require \"like\" rating)']//parent::label[@class='checkbox-item radio-item']//span[@class='checkmark']"),
			"In Program action and rewards submitted option "),
	
	/** The Program action and rewards submitted option count value */
	CREATE_PROGRAM_PROGRAM_ACTION_AND_REWARDS_SUBMITTED_COUNT(By.xpath("//div[@class='msdb-brand-email-wraps']//div[@class='form-group']//input[@class='form-control msdb-input-text']"),
			"In Program action and rewards submitted option count value"),
	
	/** The Program action and rewards used submitted option count value */
	CREATE_PROGRAM_PROGRAM_ACTION_AND_REWARDS_USED_SUBMITTED_COUNT(By.xpath("//div[@class='msdb-brand-email-wraps']//div[@class='form-group']//input[@class='form-control msdb-input-text used']"),
			"In Program action and rewards used submitted option count value"),

	
	/** Select rewards option $5*/
	CREATE_PROGRAM_SELECT_REWARDS_OPTION_$5(By.xpath("//div[@class='rp-rewards-item-highlights']//select[@class='rp-dats dropdown-action-items']//option[@value='158568719839']"),
			"Select rewards option $5"),
	
	/** Select rewards option $1*/
	CREATE_PROGRAM_SELECT_REWARDS_OPTION_$1(By.xpath("//div[@class='rp-rewards-item-highlights']//select[@class='rp-dats dropdown-action-items']//option[@value='15698660574']"),
			"Select rewards option $1"),
	
	
	/** Select rewards option $1*/
	CREATE_PROGRAM_SELECT_REWARDS_DROPDOWN(By.xpath("//select[@class='rp-dats dropdown-action-items']"),
			"Select rewards"),
	
	/** Text reward option*/
	CREATE_PROGRAM_TEXT_REWARDS(By.xpath("//div[@class='card-body']//div[@class='rp-rewards-item-highlights']//input[@class='form-control msdb-input-text']"),
			" Text reward option"),
	
	/** Select rewards option $1 from action 2*/
	CREATE_PROGRAM_SELECT_REWARDS_DROPDOWN_FROM_ACTION2(By.xpath("//span[@class='rp-ac-item' and text()='2']//ancestor::div[@class='left-section-wrp actions-section-main']//select[@class='rp-dats dropdown-action-items']"),
			"Select rewards option $1 from action 2"),
	
	/** The program action and rewards save button*/
	CREATE_PROGRAM_PROGRAM_ACTIONS_AND_REWARDS_SAVE_BUTTON(By.xpath("//button[@class='primeblueaction btn btn-primary' and text()='Save']"),
			"The program action and rewards save button"),
	
	/** The program action and rewards cancel button*/
	CREATE_PROGRAM_PROGRAM_ACTIONS_AND_REWARDS_CANCEL_BUTTON(By.xpath("//button[contains(@class,'cancel') and text()='Cancel']"),
			"The program action and rewards cancel button"),
	
	/** The program action and rewards Add Action button*/
    CREATE_PROGRAM_PROGRAM_ACTIONS_AND_REWARDS_ADD_ACTION_BUTTON(By.xpath("//div[@class='details-section-scrol-wrp']//div[@class='info-icon']"),
			"The program action and rewards Add Action button"),
	
	/** The alert message while choosing same actions*/
	MESSAGE_VALIDATION_ON_SAME_ACTION(By.xpath("//span[@class='success-mess-txt' and text()='Condition already chosen. Unable to continue.']"),
			"The alert message while choosing same actions"),
	
	/** The start date at date picker*/
	CREATE_PROGRAM_DATE_PICKER("//div[@class='react-datepicker']//div[contains(@class,'react-datepicker__day react') and not( contains(@class,'react-datepicker__day--disabled'))  and text()='%s']",
			"The start date at date picker"),
	
	/** The Date picker next month option*/
	CREATE_PROGRAM_DATE_PICKER_NEXT_MONTH_OPTION(By.xpath("//div[@class='program-details-section-wrp']//div[@class='react-datepicker']//button[contains(@class,'navigation--next')]"),
			"The Date picker next month option"),
	
	/** The Payment details - New card option*/
	CREATE_PROGRAM_PAYMENT_DETAILS_NEW_CARD(By.xpath("//div[@class='card-details-section-grid']//button[contains(@id,'newCard')]"),
			"The Payment details - New card option"),
	
	/** The Payment details - card name*/
	CREATE_PROGRAM_PAYMENT_DETAILS_CARD_NAME(By.xpath("//div[@class='card-details-section-grid']//div[@class='pay-newcard-wrp']//input[@name='cardname']"),
			"The Payment details - card name"),
	
	/** The Payment details - card number*/
	CREATE_PROGRAM_PAYMENT_DETAILS_CARD_NUMBER(By.xpath("//span[@class='InputContainer']//input[@name='cardnumber']"),
			"The Payment details - card number"),
	
	/** The Payment details - Expiry date*/
	CREATE_PROGRAM_PAYMENT_DETAILS_EXPIRY_DATE(By.xpath("//span[@class='InputContainer']//input[@name='exp-date']"),
			"The Payment details - Expiry date"),
	
	/** The Payment details - CVC number*/
	CREATE_PROGRAM_PAYMENT_DETAILS_CVC_NUMBER(By.xpath("//span[@class='InputContainer']//input[@name='cvc']"),
			"The Payment details - CVC number"),
	
	/** The Payment details - iframe card number*/
	CREATE_PROGRAM_PAYMENT_DETAILS_IFRAME_CARD_NUMBER(By.xpath("(//iframe[contains(@name,'__privateStripeFrame')])[1]"),
			"The Payment details - iframe card number"),
	
	/** The Payment details - Expiry date*/
	CREATE_PROGRAM_PAYMENT_DETAILS_IFRAME_EXPIRY_DATE(By.xpath("(//iframe[contains(@name,'__privateStripeFrame')])[2]"),
			"The Payment details - Expiry date"),
	
	/** The Payment details - CVV number*/
	CREATE_PROGRAM_PAYMENT_DETAILS_IFRAME_CVC_NUMBER(By.xpath("(//iframe[contains(@name,'__privateStripeFrame')])[3]"),
			"The Payment details - CVV number"),

	
	/** The Payment details - Enabled card*/
	CREATE_PROGRAM_PAYMENT_DETAILS_ENABLED_CARD(By.xpath("//div[@class='card-details-section-grid']//div[@class='right-section']//div[@class='rs-cards visa-card-bg']"),
			"The Payment details - Enabled card"),
	
	/** The Payment details - Save a card button*/
	CREATE_PROGRAM_PAYMENT_DETAILS_SAVE_CARD_BUTTON(By.xpath("//div[contains(@class,'react-ripples')]//button[@class='ac-btn ac-primary ac-block ' and text()='Save a card']"),
			"The Payment details - Save a card button"),
	
	/** The Payment detail view - Update program*/
	PROGRAM_DETAIL_VIEW_UPDATE_PROGRAM_BUTTON(By.xpath("//div[@class='right-button-section']//button[@class='ac-btn ac-primary ac-block ' and text()='Update Program']"),
			"Clicking update program button"),
	
	/** The Payment details - Enabled card number*/
	CREATE_PROGRAM_PAYMENT_DETAILS_ENABLED_CARD_NUMBER(By.xpath("//div[@class='rs-cards visa-card-bg']//div[@class='card-number-wrp']//span[text()='4***']"),
			"The Payment details - Enabled card number"),
	
	/** The Payment details - Enabled card expiry date*/
	CREATE_PROGRAM_PAYMENT_DETAILS_ENABLED_CARD_EXPIRY_DATE(By.xpath("//div[@class='rs-cards visa-card-bg']//div[@class='expiry-date-wrp']//span[text()='** / **']"),
			"The Payment details - Enabled card expiry date"),
	
	/** Create program - edit action*/
	CREATE_PROGRAM_EDIT_ACTION(By.xpath("//div[contains(@class,'rewards-program')]//div[@class='cursor-pointer' and text()='Edit Action']"),
			"Click  Create program - edit action"),
	
	/** Create program - edit location*/
	CREATE_PROGRAM_EDIT_LOCATION(By.xpath("//div[contains(@class,'rewards-program')]//div[@class='cursor-pointer' and text()='Edit Location']"),
			"Click Create program - edit location"),
	
	/** All locations selected option*/
	CREATE_PROGRAM_DESELECT_ALL_LOCATION(By.xpath("//div[contains(@class,'tree-franchisor rc-tree')]//span[contains(@title,'All hubs and locations')]//parent::div//span[contains(@class,'checkbox-checked')]"),
			"Click All locations selected option checkbox"),

	/** create program - Other locations dropdown*/
	CREATE_PROGRAM_ADD_LOCATION_DROPDOWN(By.xpath("//div[@class='card-body']//div[contains(@id,'specific_locations')]//div[@class='spn-wrap']//div[@class='form-group form-field-item ']//button[@type='button']"),
			"create program - Other locations dropdown"),

	/** Create program Add location search option*/
	CREATE_PROGRAM_ADD_LOCATION_SEARCH_OPTION(By.xpath("//div[@class='ds-menu']//div[contains(@class,'rs-drp__input')]//input[@class='rs-drp__input']"),
			"Create program Add location search option"),

	/** The select locations search result. */
	SELECT_LOCATIONS_SEARCH_RESULT("//div[@class='modal-body']//div[@class='fade tab-pane active show']//div[@id='select-locations-dropdown']//div[contains(@class,'rs-drp__option') and contains(text(),'%s')]", "Select Locations searchResult"),


	/** Create program specific selected location*/
	CREATE_PROGRAM_SELECTED_SPECIFIC_LOCATION(By.xpath("//div[contains(@class,'action-rewards')][3]//div//button//span[text()='All Automation Hub one']"),
			"Create program specific selected location"),


	/** All locations - selecting other location*/
	CREATE_PROGRAM_ADD_LOCATION_OTHER_LOCATION_OPTION(By.xpath("//div[contains(@class,'tree-franchisor rc-tree-treenode')]//span[@title='Automation Hub one']//parent::div//span[@class='rc-tree-checkbox']"),
			"Selecting other location option"),
	
	/** Payment section - saved card*/
	CREATE_PROGRAM_SAVED_CARD(By.xpath("//div[@class='saved-card-new-section']//div[@class='moneycard visa-card-bg']"),
			"Payment section - selecting saved card"),
	
	/** Update program - success message*/
	UPDATE_PROGRAM_SUCCESS_MESSAAGE(By.xpath("//div[@class='Toastify']//span[@class='success-mess-txt' and text()='Program updated successfully!']"),
			"Update program - success message"),
	
	/** Edited program budget*/
	EDITED_PROGRAM_BUDGET_DATA(By.xpath("//div[@class='input-fields']//input[@value='150']"),
			"Edited program budget"),
	
	/** Edited program action and rewards*/
	EDITED_ACTION_DATA(By.xpath("//div[@class='card-body']//div[contains(@class,'description-text')]//span[text()='2']"),
			" Edited program action and rewards"),
	
	/** Edited locations*/
	EDITED_LOCATIONS_DATA("//div[@class='locaion-list-section-wrp']//button[@type='button']//span[text()='%s']",
			" Edited locations"),
	
	/** Edited send now*/
	EDITED_SEND_NOW_DATA(By.xpath("//label[@class='active']//span[@class='labelText']//parent::label//input[@type='radio']"),
			" Edited send now"),
	
	/** Detail view - All location option*/
	DEATIL_VIEW_ALL_LOCATION_SELECTED_OPTION(By.xpath("//div[@class='locaion-list-section-wrp']//button[@type='button']//span[text()]"),
			"All location option selected in detail view"),
	
	/** Detail view - Program name*/
	DEATIL_VIEW_PROGRAM_NAME("//div[contains(@class,'lz-active events-none pointer')]//input[@value='%s']",
			"Detail view - Program name"),
	
	/** Detail view - Achievers tab*/
	DEATIL_VIEW_ACHIEVERS_TAB(By.xpath("//li[@class='ripple']//span[@class='sub-nav-item-txt' and text()='Achievers']"),
			"Detail view - Achievers tab"),
	
	/** Detail view of reward program*/
	DEATIL_VIEW_REWARD_PROGRAM("//div[contains(@class,'initial-status-head')]//span[@class='state-indications-txt' and text()='%s']",
			"Detail view of reward program"),
	
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),
	
	/** Message validation on reward amount more than budget amount*/
	REWARDS_ALERT_MESSAGE(By.xpath("//span[@class='success-mess-txt' and text()='Your total reward amount should be less or equal to budget amount. Unable to continue.']"),
			"Message validation on reward amount more than budget amount");
	
	

    /** The by locator. */
    private By byLocator;

    /** The description. */
    private String xpath, description;

 

    /**
     * Instantiates a new employee advocacy reward program page enum.
     *
     * @param byLocator the by locator
     * @param description the description
     */
    private EmployeeAdvocacyRewardProgramPageEnum(By byLocator, String description) {

 

        this.byLocator = byLocator;
        this.description = description;
    }

 

    /**
     * Instantiates a new employee advocacy reward program page enum.
     *
     * @param xpath the xpath
     * @param description the description
     */
    private EmployeeAdvocacyRewardProgramPageEnum(String xpath, String description) {

 

        this.xpath = xpath;
        this.description = description;
    }

 

    /**
     * Gets the by locator.
     *
     * @return the by locator
     */
    public By getByLocator() {
        return byLocator;
    }

 

    /**
     * Gets the xpath.
     *
     * @return the xpath
     */
    public String getXpath() {
        return xpath;
    }

 

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

 

}
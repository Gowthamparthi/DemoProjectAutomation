package com.rallio.automation.newrallio.enums;


// TODO: Auto-generated Javadoc
/**
 * The Enum DirectoryListingsPaymentEnum.
 */
public enum DirectoryListingsPaymentEnum {
	
	/** The master. */
	MASTER,
	
	/** The visa. */
	VISA,
	
	/** The amex. */
	AMEX,
	
	/** The cash. */
	CASH,
	
	/** The cheque. */
	CHEQUE,
	
	/** The checks. */
	CHECKS,
	
	/** The credit cards. */
	CREDIT_CARDS,
	
	/** The china union pay. */
	CHINA_UNION_PAY,
	
	/** The dinners club. */
	DINNERS_CLUB,
	
	/** The jcb. */
	JCB,
	
	/** The debit cards. */
	DEBIT_CARDS,
	
	/** The meal coupun. */
	MEAL_COUPUN,
	
	/** The nfc mobile payments. */
	NFC_MOBILE_PAYMENTS,
	
	/** The google pay. */
	GOOGLE_PAY,
	
	
	/** The crypto. */
	//CRYPTO;
}

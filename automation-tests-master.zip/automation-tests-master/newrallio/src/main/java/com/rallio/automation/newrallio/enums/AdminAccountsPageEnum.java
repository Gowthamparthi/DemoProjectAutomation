package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum AdminAccountsPageEnum.
 */
public enum AdminAccountsPageEnum {
      
	/** The page load. */
	PAGE_LOAD(By.xpath(
	        "//span[text()='Accounts']//ancestor::div[@class='resizing-wrap']//label[@class='checkbox-item']//parent::div[@class='stc-item stc-right']//ancestor::div[contains(@class,'mainContent animate')]"),
	        "The Accounts Pageload"),

	/** The search tab. */
	SEARCH_TAB(By.xpath("//div//input[@placeholder='Search']"), "The search tab for input"),

	/** The includehideaccounts text. */
	INCLUDEHIDEACCOUNTS_TEXT(By.xpath("//span[text()='Include Hidden Accounts']"), "The Include Hide Accounts is displayed"),

	/** The includehideaccounts button. */
	INCLUDEHIDEACCOUNTS_BUTTON(By.xpath("//input[@name='hiddenAccounts']"),"The click radio button on Include Hide Accounts"),
	
	/** The accounts page heading. */
	ACCOUNTS_PAGE_HEADING(By.xpath("//table//tr[1]//th[text()='Name']//following::th[text()='Created']//following::th[text()='Dashboard']//following::th[text()='Setup']"),
	        "The Accounts page heading name,dashboard,created,setup are dispalyed"),

	/** The footer. */
	FOOTER(By.xpath("//div[@class='admn-thumb-right']//span[@class='ad-name']//ancestor::tbody//tr[last()]"),"The footer for scroll last element"),
	
	/** The table size. */
	TABLE_SIZE(By.xpath("//div[@class='admn-thumb-right']//span[@class='ad-name']//ancestor::table//td[1]"),"The scroll on element"),
	
	/** The accounts user byname. */
	ACCOUNTS_USER_BYNAME("//span[contains(text(),'%s')]","The account user name is dispalyed"),
	
	/** The dash view. */
	DASH_VIEW("(//span[contains(text(),'%s')]//ancestor::tr[1]//td[3]//span[text()='View'])[1]","The click the dash view"),
	
	/** The rallioprofile pageload. */
	RALLIOPROFILE_PAGELOAD(By.xpath("//h5[text()='Rallio  Profile']//ancestor::div//div[@class='sec-main__content']//div[contains(@class,'settings-rallio-profile-new-section')]//h3[text()='Profile Info']"),"The rallio profile Pageload"),
	
	/** The social pageload. */
	SOCIAL_PAGELOAD(By.xpath("//h5[text()='Social Profiles']//ancestor::div[@class='modal-body']//div[@class='csp']//div[@class='csp-item ss-metafb']//span[text()='Facebook']"),"The Social Pageload"),
	
	/** The setup button. */
	SETUP_BUTTON("(//span[contains(text(),'%s')]//ancestor::tr[1]//td[4]//span[text()='Setup'])[1]","The click setup button"),

	REQUIRED_ALERT_FIELDS(By.xpath("//div[@class='form-group form-field-item erroritem']//span[@class='fltlabels fltlabels-error-text']"),"Required Alert Fields"),

	/** The admin area tab. */
	ADMIN_AREA_TAB(By.xpath("//div[@class='react-ripples']//span[text()='Admin Area']"), "The click Admin Button"),

	/** The posts pageload. */
	POSTS_PAGELOAD(By.xpath(
	        "//li[@class='ripple active']//span[text()='Posts']//following::section[contains(@class,'item-g filter')]//ancestor::main//section[@id='main-container-sec']//div[@class='g-post postwrap mbl-head--margin']"),
	        "The Post Page Load"),
	
	/**  The ralio Profile Name *. */
	RALLIO_PROFILE_NAME_INPUT(By.xpath("//div//input[@name='name']"), "Rallio Profile Name"),
	
	/** The rallio profile address. */
	RALLIO_PROFILE_ADDRESS(By.xpath("//input[@name='street']"),"The rallio profile address"),
	
	/** The rallio profile zipcode. */
	RALLIO_PROFILE_ZIPCODE(By.xpath("//input[@name='zip']"),"The rallio profile Zipcode"),
	
	/** The rallio profile phone. */
	RALLIO_PROFILE_PHONE(By.xpath("//input[@name='phone']"),"The rallio profile PhoneNumber"),
	
	/** The no data. */
	NO_DATA(By.xpath("//td[text()=' No Data to show']"),"The  No Data to show on table"),
	
	/** The rallio profile next *. */
	RALLIO_PROFILE_NEXT(By.xpath("//div[contains(@class,'react-ripples ripple-unset ac-primary-box')]//button[text()='Next']"), "The rallio profile click next"),
	
	/** The setting tab. */
	SETTING_TAB(By.xpath("//li//div[1]//span[text()='Settings']"),"The click setting tab"),
	
	/** The rallio profilepage check. */
	RALLIO_PROFILEPAGE_CHECK("//input[@class='form-control used ' and @value='%s']","The rallio profile page contents"),
	
	/** The Socail Profile *. */
	SOCIAL_PROFILE_PAGE_LOAD(
	        By.xpath("//div[@class='smn']//span[text()='Facebook']//following::span[text()='Instagram']//following::span[text()='X (Formerly Twitter)']//following::span[text()='Linkedin']"),
	        "The social profile Page Load"),

	SAVE_ALL_BUTTON(By.xpath("//button[text()='Save All']"),"Save All Button"),

	PROFILE_UPDATED_SUCCESSFULL(By.xpath("//*[text()='Profile updated successfully']"),"Save All Button"),

	/** The socialprofile finish button. */
	SOCIALPROFILE_FINISH_BUTTON(By.xpath("//button[text()='Finish']"),"The click social profile page finish button");


	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new admin accounts page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private AdminAccountsPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new admin accounts page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private AdminAccountsPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

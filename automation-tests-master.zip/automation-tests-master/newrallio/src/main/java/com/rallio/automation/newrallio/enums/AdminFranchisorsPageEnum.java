/*
 * 
 */
package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum AdminFranchisorsPageEnum.
 */
public enum AdminFranchisorsPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath(
	        "//li[@class='ripple active']/span[text()='Franchisors']//ancestor::div//div[@class='content-g']//div[@class='adv-leaderboardwrp lpx resuseTable']"),
	        "The Franchisors PageLoad"),

	FRANCHISER_TAB(By.xpath("//span[@class='sub-nav-item-txt' and text()='Franchisors']"), "Franchiser Tab"),

	/** The search tab. */
	SEARCH_TAB(By.xpath("//div[@class='react-tags__search-input']//input[@placeholder='Search']"), "The Search input"),

	/** The franchisors heading contents. */
	FRANCHISORS_HEADING_CONTENTS(By.xpath(
	        "//thead//tr//th[text()='Name']//following::th[text()='Created']//following::th[text()='Stats']//following::th[text()='Report']//following::th[text()='Dash']//following::th[text()='Franchisor Content']//following::th[text()='New Location']//following::tbody"),
	        "The Franchisors headnig contents"),

	/** The footer. */
	FOOTER(By.xpath("//span[@class='ad-name']//parent::div[@class='admn-thumb-right']//ancestor::tbody//tr[last()]"), "The  last element"),

	/** The table size. */
	TABLE_SIZE(By.xpath("//table[@class='responsiveTable table']//tbody//tr//div[@class='adm-nid']"), "The table size by element"),

	/** The user byname. */
	USER_BYNAME(By.xpath("//tbody//tr//td[1]//div//div[2]"), "The select user by name"),
	
	/** The admin user. */
	ADMIN_USER("//div[contains(@class,'responsiveTable')]//thead//span[text()='Franchisee Name']//ancestor::div//div[@class='adm-nid']//div[@class='admn-thumb-right']//span[contains(@class,'ad-name cursor') and text()='%s']","The click admin user"),

	/** The user name. */
	USER_NAME("//div[@class='admn-thumb-right']//span[text()='%s']", "The user name is displayed "),

	/** The Stats view. */
	STATS_VIEW(By.xpath("//table[@class='responsiveTable table']//thead//th[text()='Stats']//ancestor::table//tbody//tr//td[3]//span[text()='View']"), "The Stats view button"),
	
	STATS_VIEW_FIELD("//span[contains(text(),'%s')]//parent::div//parent::div//parent::td//following-sibling::td[2]//span[text()='View']","Stats View Field"),
	
	/** The rallioprofile pageload. */
	RALLIOPROFILE_PAGELOAD(By.xpath("//h5[text()='Rallio  Profile']//ancestor::div//div[@class='sec-main__content']//div[contains(@class,'settings-rallio-profile-new-section')]//h3[text()='Profile Info']"),"The rallio profile Pageload"),

	/** The socailprofile pageload. */
	SOCAILPROFILE_PAGELOAD(By.xpath("//div[@class='header-item__wrp']//ancestor::div[@class='stepper-holder']//div[@class='step']//h5[text()='Social Profiles']"),"The Social Profile page load"),

	/** The calendar post. */
	CALENDAR_POST("//div[contains(@class,'creator-schedule')]//div[@class='grid-section']//p[text()='%s']","The calendar post"),

	/** The post approve button. */
	POST_APPROVE_BUTTON("//p[text()='%s']//ancestor::div[@class='li-view-main']//button[text()='Approve']","The click the post approve button"),
	
	POST_APPROVED_DISABLED("//p[text()='%s']//ancestor::div[@class='li-view-main']//button[@class='ac-btn ac-primary ac-block disabled' and text()='Approved']","Post Approved Diabled"),

	CALENDAR_POST_CLOSE_BUTTON(By.xpath("//div[contains(@class,'modal-dialog-centered')]//div[@class='modal-content']//img[@alt='close']"),"The calendar post close button"),


	//SCROLL_POST("//div[@class='liv-right list-item']//following-sibling::div//p[@title='%s']","The scroll to the post"),
	
	/** The Dash column view button */
	DASH_VIEW(By.xpath("//table[@class='responsiveTable table']//thead//th[text()='Dash']//ancestor::table//tbody//tr//td[5]//span[text()='View']"), "The click Dash view"),

	DASH_VIEW_FIELD("//span[text()='%s']//parent::div//parent::div//parent::td//following-sibling::td[4]//span[text()='View']","The click Dash view"),

	STATS_VIEW_BYID("//span[text()='%s']//parent::div//parent::div//parent::td//following-sibling::td[2]//span[text()='View']","Stats View Field"),

	/** The posts pageload. */
	POSTS_PAGELOAD(By.xpath(
	        "//li[@class='ripple active']//span[text()='Posts']//following::section[contains(@class,'item-g filter')]//ancestor::main//section[@id='main-container-sec']//div[@class='g-post postwrap mbl-head--margin']"),
	        "The Post Page Load"),
   
	/** The creator type your post. */
	CREATOR_TYPE_YOUR_POST(By.xpath("//div[@class='fade tab-pane active show']//ancestor::div//div[@class='DraftEditor-editorContainer']//span//parent::div") ,"The facebook type the post in creator"),
	
	/** The calendar tab. */
	CALENDAR_TAB(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Calendar']"),"The click calendar tab"),
	
	/** The schedule button. */
	SCHEDULE_BUTTON(By.xpath("//div[@class='action-btn-holder']//button[text()='Schedule']"),"The click the schedule button"),
	
	/** The schedule post. */
	SCHEDULE_POST(By.xpath("//div[@class='footer-section']//button[text()='Schedule']"),"The click schedule post button"),
	
	/** The schedule done. */
	SCHEDULE_DONE(By.xpath("//span[text()='Done! You can check your posting schedule to see this post']"),"the schedule post done is displayed"),
	
	/** The setting tab. */
	SETTING_TAB(By.xpath("//li//div[1]//span[text()='Settings']"),"setting tab"),
	
	/** The creator tab. */
	CREATOR_TAB(By.xpath("//li//span[text()='Creator']"),"The creator Tab click"),
	
	/** Content tab posts. */
	CONTENT_TAB_POSTS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Posts']"), "Content tab posts"),
	
	/** Content tab mediaGallery. */
	CONTENT_TAB_MEDIA_GALLERY(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Media']"), "Content tab mediaGallery"),
	
	/** The search tab name. */
	SEARCH_TAB_NAME("//span[contains(text(),'%s')]//following::span[@class='ad-id']//ancestor::div[@class='admn-thumb-right']", "The User Name and Id display on search Tab"),

	/** The posts count. */
	POSTS_COUNT("//table//tbody//tr//div[@class='admn-thumb-right']//span[text()='%s']//ancestor::tr//td[3]//span","The count befor post"),
	
	POST_COUNT_LIST(By.xpath("//td//span[text()='# Posts']//parent::div//parent::div//following-sibling::span"),"Post Count List"),
	
	/** The approved count. */
	APPROVED_COUNT("//table//tbody//tr//div[@class='admn-thumb-right']//span[text()='%s']//ancestor::tr//td[4]//span","The Approved count after post"),
	
	/** The back button. */
	BACK_BUTTON(By.xpath("//div[@class='back-all__wrp']//img[@class='back']//following-sibling::span[text()='Back']"),"The click back button"),
	
	/** The user table heading. */
	USER_TABLE_HEADING(By.xpath(
	        "//div[text()='Franchisee Name']//ancestor::tr//span[text()='Next unapproved post']//following::span[text()='# Posts']//following::span[text()='# Approved Posts']//parent::th//ancestor::tr"),
	        "The User Table heading by name"),

	/** The user name tablebody. */
	USER_NAME_TABLEBODY(By.xpath("//td//span[contains(@class,'ad-name')]//ancestor::tbody"),"The use name table body display"),
	
	/** The no data found. */
	NO_DATA_FOUND(By.xpath("//tr//td[text()='No Data Found.']"),"The NO data found on Table"),
	
	/** The franchisee button. */
	FRANCHISEE_BUTTON(By.xpath("//th//span[text()='Franchisee Name']"), "Franchisee Button"),

	/** The franchisors tab. */
	FRANCHISORS_TAB(By.xpath("//li//span[text()='Franchisors']"),"franchisors tab"),
	
	/** The franchiseename up arrow. */
	FRANCHISEENAME_UP_ARROW(By.xpath("//th[contains(@class,'cur-pointer')]//span[text()='Franchisee Name']//following-sibling::div//img[@class='sort-icon sort-icon__rotate']"),
	        "The franchisee Name up arrow"),

	/** The franchiseename down arrow. */
	FRANCHISEENAME_DOWN_ARROW(By.xpath("//th[contains(@class,'cur-pointer')]//span[text()='Franchisee Name']//following-sibling::div//img[@class='sort-icon ']"),
	        "The Franchisee down arrow"),

	/** The next unapproved button. */
	NEXT_UNAPPROVED_BUTTON(By.xpath("//th//span[text()='Next unapproved post']"), " Next unapproved button"),

	/** The next unapproved up arrow. */
	NEXT_UNAPPROVED_UP_ARROW(
	        By.xpath("//th[contains(@class,'cur-pointer')]//span[text()='Next unapproved post']//following-sibling::div//img[@class='sort-icon sort-icon__rotate']"),
	        " Next unapproved up arrow"),

	/** The next unapproved down arrow. */
	NEXT_UNAPPROVED_DOWN_ARROW(By.xpath("//th[contains(@class,'cur-pointer')]//span[text()='Next unapproved post']//following-sibling::div//img[@class='sort-icon ']"),
	        " Next unapproved down arrow"),

	FRANCHISEE_NAME(By.xpath("//div[@class='admn-thumb-right']//span[@class='ad-name cursor-pointer wbfi-txt blue-text']"),"Franchisee Name"),
	
	/** The posts button. */
	POSTS_BUTTON(By.xpath("//th//span[text()='# Posts']"), "Posts button"),

	/** The posts data */
	POSTS_DATA(By.xpath("//table//tbody//tr//td[3]//span"), "Posts data"),

	/** The Approved posts data */
	APPROVED_POSTS(By.xpath("//table//tbody//tr//td[4]//span"), "Approved Posts data"),

	UP_ARROW(By.xpath("//th[@class='cur-pointer active sort-active']//div//img[@class='sort-icon sort-icon__rotate']"),"Up Arrow"),

	DOWN_ARROW(By.xpath("//th[@class='cur-pointer active sort-active']//div//img[@class='sort-icon ']"),"Down Arrow"),

	/** The posts up arrow. */
	POSTS_UP_ARROW(By.xpath("//th[contains(@class,'cur-pointer')]//span[text()='# Posts']//following-sibling::div//img[@class='sort-icon sort-icon__rotate']"),
	        "Posts up arrow"),

	/** The posts down arrow. */
	POSTS_DOWN_ARROW(By.xpath("//th[contains(@class,'cur-pointer')]//span[text()='# Posts']//following-sibling::div//img[@class='sort-icon ']"), "Posts down arrow"),

	POSTS_COLUMN(By.xpath("//th[@class='sort-default'][2]//div//span[@class='to-ellipsis' and text()=\"# Posts\"]"), "Posts column button"),

	APPROVED_POSTS_COLUMN(By.xpath("//th[@class='sort-default'][3]//div//span[@class='to-ellipsis' and text()=\"# Approved Posts\"]"), "Approved column button"),


	/** The approvedposts button. */
	APPROVEDPOSTS_BUTTON(By.xpath("//th//span[text()='# Approved Posts']"), "Approved Posts button"),

	/** The approvedposts up arrow. */
	APPROVEDPOSTS_UP_ARROW(By.xpath("//th[contains(@class,'cur-pointer')]//span[text()='# Approved Posts']//following-sibling::div//img[@class='sort-icon sort-icon__rotate']"),
	        "Approved Up arrow"),

	/** The approvedposts down arrow. */
	APPROVEDPOSTS_DOWN_ARROW(By.xpath("//th[contains(@class,'cur-pointer')]//span[text()='# Approved Posts']//following-sibling::div//img[@class='sort-icon ']"),
	        "Approved down arrow"),

	/** The admin area tab. */
	ADMIN_AREA_TAB(By.xpath("//div[@class='react-ripples']//span[text()='Admin Area']"), "Admin Button"),

	/** The admin user byname. */
	ADMIN_USER_BYNAME(By.xpath("//tbody//tr//td//div[@class='admn-thumb-right']//span"), "The select admin user by name"),
	
	/** The admin user byname. */
	ADMIN_USER_FIELD("//tbody//tr//td//div[@class='admn-thumb-right']//span[contains(text(),'%s')]", "The select admin user by name"),


	/** The admin account name */
	ADMIN_USER_ACCOUNT_NAME(By.xpath("//tbody//tr//td//div[@class='admn-thumb-right']//span"), "Clicking on the account name"),

	 /** The report download button. */
	REPORT_DOWNLOAD_BUTTON("//span[text()='%s']//ancestor::tr//td[4]//img[@alt='cancel']//parent::div[contains(@class,'admn-txt')]",
	        "The click Report Download button"),

	/** The download started. */
	DOWNLOAD_DONE(By.xpath("//*[contains(text(),'Done!')]"), "The Download done is display"),

	/** The slider percentage. */
	SLIDER_PERCENTAGE(By.xpath("//span[text()='Bean Me Up NorCal']//ancestor::tr//td[6]//div[1]//div[4]"), "The get attribute"),

	/** The slider handle. */
	SLIDER_HANDLE(By.xpath("//tbody//tr[1]//td[6]//div//div//div[4][@class='rc-slider-handle']"), "The slider handle"),

	/**  The ralio Profile Name *. */
	RALLIO_PROFILE_NAME_INPUT(By.xpath("//div[@class='form-group form-field-item ']//input[@name='name']"), "Rallio Profile Name"),

	/** The rallio profile store code. */
	RALLIO_PROFILE_STORECODE_INPUT(By.xpath("//div[@class='form-group form-field-item ']//input[@name='short_name']"), "Rallio Store code"),

	/** The rallio profile city *. */
	RALLIO_PROFILE_CITY_INPUT(By.xpath("//input[@name='city']"), "Rallio profile city name"),

	/** The rallio profile state *. */
	RALLIO_PROFILE_STATE_INPUT(By.xpath("//div//input[@name='state']"), "Rallio profile state name"),

	/** The rallio profile country tab *. */
	RALLIO_PROFILE_COUNTRY_NAME(
	        By.xpath("//div[@class='cs-select__control css-s68f6i-control']//div[contains(@class,'has-value css-1d8n9bt')]//div[contains(@class,'css-qc6sy-singleValue') and text()='United States']"),
	        "The rallio country Tab click"),

	/** The rallio profile country dropdown *. */
	RALLIO_PROFILE_COUNTRY_DROPDOWN_LIST("//div[@id='react-select-2-listbox']//*[contains(text(),'%s')]", "The rallio country name select"),

	/** The rallio profile Time Zone *. */
	RALLIO_PROFILE_TIME_ZONE(By.xpath("//div[@class='cs-select__control css-s68f6i-control']"), "The rallio profile Time Zone"),

	/** The rallio profile Time zone dropdown *. */
	RALLIO_PROFILE_TIME_ZONE_DROPDOWN("//div[@id='react-select-3-listbox']//*[contains(text(),'%s')]", "The rallio Time zone Dropdown list"),

	/** The rallio profile next *. */
	RALLIO_PROFILE_NEXT(By.xpath("//button[@class='ac-btn ac-primary size-xs']"), "The rallio profile click next"),

	/** The rallio profilepage check. */
	RALLIO_PROFILEPAGE_CHECK("//input[@class='form-control used ' and @value='%s']","The check the rallio profile page contents"),
	
	/** The wizard button. */
	WIZARD_BUTTON("//span[text()='%s']//ancestor::tr//button//span[text()='Wizard']", "The click wizard button"),

	/** The facebook connect now. */
	FACEBOOK_CONNECT_NOW(By.xpath("//span[text()='Facebook']//ancestor::div[contains(@class,'csp-item')]//div[@class='csp-action']//button[text()='Connect Now']"),
	        "Facebook connect now"),

	/** The facebook connect now. */
	FACEBOOK_DISCONNECT_NOW(By.xpath(
	        "//span[text()='Facebook']//ancestor::div[@class='csp-item ss-metafb']//div[@class='csp-action']//button[text()='View page']//following-sibling::div//button[text()='Disconnect']"),
	        "Facebook disconnect now"),

	/** The facebook connect now. */
	FACEBOOK_DISCONNECTING(By.xpath("//div[@class='disconnect-notification-wrp']//div[@class='csp-action']//button[text()='Disconnect Now']"), "Facebook disconnecting"),

	/** The facebook page to connect button. */
	FACEBOOK_PAGE_TO_CONNECT_BUTTON(By.xpath("//div[@class='nac-txt' and text()='QA Testing Page 1']//ancestor::div[@class='aps-item']//button[text()='Connect Now']"),
	        "Facebook page to Connect button"),

	/** The facebook connect pageload. */
	FACEBOOK__SIGNINPAGE_CONNECT_PAGELOAD(By.xpath("//div[@class='modal-header']//ancestor::div//div[@id='scrollTargetFbpages']//following::button[text()='Cancel']"),
	        "The User login Id to click connect in facebook"),

	/** The facebook continue button. */
	FACEBOOK_CONTINUE_BUTTON(By.xpath("//span[text()='Continue as Bala Ksv']"), "The facebook continue button click"),

	/** The social page connect Now button *. */
	FACEBOOK_CONNECTNOW_BUTTON(By.xpath("//span[text()='Facebook']//ancestor::div[@class='csp-item ss-metafb']//div[@class='csp-action']//button[text()='Connect Now']"),
	        "The Click connect now button"),

	/** The social page facebook login button *. */
	FACEBOOK_PAGE_LOGIN_BUTTON(By.xpath("//label[@class='login_form_label']//following::label[@id='loginbutton']"), "The click facebook login button in social login page"),
	
	/** The social page Connect email input *. */
	FACEBOOK_CONNECT_EMAIL_INPUT(By.xpath("//input[@name='email' and @type='text']"), "The email as input for social connect pages"),

	/** The social page Connect email input *. */
	FACEBOOK_CONNECT_PASSWORD_INPUT(By.xpath("//input[@name='pass' and @type='password']"), "The password as input for social connect pages"),

	/** The facebook page signin button. */
	FACEBOOK_PAGE_SIGNIN_BUTTON(By.xpath("//input[@name='login' and @type='submit']"), "Facebook page SignIn button"),

	/** The Socail Profile *. */
	SOCIAL_PROFILE(By.xpath("//div[@class='header-item__wrp']//following::h5[text()='Social Profiles']"), "The social profile click"),

	/** The posts tab. */
	POSTS_TAB(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Posts']"),"the Posts Tab"),
	
	/** The calendar pageload. */
	CALENDAR_PAGELOAD(By.xpath("//li[@class='ripple active']//span[text()='Calendar']//ancestor::div//section[@class='item-g filter calendar-filter__main']//preceding::section[@id='main-container-sec']//div[contains(@class,'calendar-stats-section')]"), "The calendar page load"),

	/** The next unapproved button. */
    NEXT_UNAPPROVED_DOWN_BUTTON(By.xpath("//th[contains(@class,'cur-pointer')]//span[text()='Next unapproved post']//following-sibling::div//img[@class='sort-icon ']"),
    "Next unapproved down button"),
    
    /** Hold your horses Modal pop up */
    HOLD_YOUR_HORSES_MODAL_POP_UP(By.xpath("//div[@class='modal-content']//div//div//img[@alt='Hold your horses! - Get Started']"), "Hold your horses Modal pop up"),

	BUSINESS_INFORMATION_TEXT(By.xpath("//div[@class='wn-top-cnt']//span[text()='Business Information used within the Platform Only']"),"Business Information Text"),

	RALLIO_PROFILE_ADDRESS(By.xpath("//input[@name='street']"), "Address"),

	PHONE_NUMBER(By.xpath("//span[text()='Phone Number']//preceding-sibling::input"), "Phone number"),

	ZIP_POSTAL_CODE(By.xpath("//span[text()='Zip / Postal Code']//preceding-sibling::input"), "Zip postal code"),

	BUSINESS_INFO(By.xpath("//h3[@class='global__title--txt' and text()='Business Info']"),"Business Info"),

	/** The socialprofile finish button. */
	SOCIALPROFILE_FINISH_BUTTON(By.xpath("//button[text()='Finish']"),"The click social profile page finish button");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new admin franchisors page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private AdminFranchisorsPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new admin franchisors page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private AdminFranchisorsPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

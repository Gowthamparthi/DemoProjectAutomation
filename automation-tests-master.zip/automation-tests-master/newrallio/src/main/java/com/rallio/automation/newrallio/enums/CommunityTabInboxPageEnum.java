
package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum CommunityTabInboxPageEnum.
 */
public enum CommunityTabInboxPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath(
	        "//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Inbox']//ancestor::div//section[@class='item-g filter inbox-filter']//preceding::div//section[@id='main-container-sec']//div[contains(@class,'cisWrap inbxMain')]"),
	        "Page load"),

	/** The inbox tab. */
	INBOX_TAB(By.xpath("//div[contains(@class,'ra-page')]//header[@class='header']//li[contains(@class,'ripple')]//span[text()='Inbox']"), "Inbox tab"),

	/** The inbox page active. */
	INBOX_PAGE_ACTIVE(By.xpath("//div[contains(@class,'sub-nav-tabs')]//span[text()='Inbox']//parent::li[@class='ripple active']"), "Inbox page activae"),

	/** The inbox contents. */
	INBOX_CONTENTS(By.xpath("//div[contains(@class,'infinite-scroll-component local-ini')]//div[contains(@class,'list-view')]//div[contains(@class,'list-item')]"), "Inbox contents"),

	/** The total stats count. */
	TOTAL_STATS_COUNT(By.xpath("//div[contains(@class,'')]//span[text()='TOTALS']//parent::div//span[@class='mod-count']//div"), "Total stats count"),

	/** The facebook stats count. */
	FACEBOOK_STATS_COUNT(By.xpath("//div[contains(@class,'fb-sc')]//img[@alt='Facebook']//parent::div//preceding-sibling::div//span[2]//div"), "Facebook stats count"),

	/** The twitter stats count. */
	X_FORMERLY_TWITTER_STATS_COUNT(By.xpath("(//div[contains(@class,'ttr-sc')]//span[text()='X']//following-sibling::span[text()='(Formerly Twitter)']//following::span[@class='platform-count']//div)[1]"), "X Formerly Twitter stats count"),

	/** The instagram stats count. */
	INSTAGRAM_STATS_COUNT(By.xpath("//div[contains(@class,'insta-sc')]//img[@alt='Instagram']//parent::div//preceding-sibling::div//span[2]//div"), "Instagram stats count"),

	/** The linkedin stats count. */
	LINKEDIN_STATS_COUNT(By.xpath("//div[contains(@class,'lkdin-sc')]//img[@alt='LinkedIn']//parent::div//preceding-sibling::div//span[2]//div"), "Linkedin stats count"),

	TIKTOK_STATS_COUNT(By.xpath("//div[contains(@class,'tiktok-sc')]//img[@alt='TikTok']//parent::div//preceding-sibling::div//span[2]//div"), "Tiktok stats count"),

	/** The facebook stats highlighted. */
	FACEBOOK_STATS_HIGHLIGHTED(By.xpath("//div[contains(@class,'fb-sc') and contains(@class,'active')]"), "Facebook stats highlighted"),

	/** The twitter stats highlighted. */
	TWITTER_STATS_HIGHLIGHTED(By.xpath("//div[contains(@class,'ttr-sc') and contains(@class,'active')]"), "Twitter stats highlighted"),

	/** The instagram stats highlighted. */
	INSTAGRAM_STATS_HIGHLIGHTED(By.xpath("//div[contains(@class,'insta-sc') and contains(@class,'active')]"), "Instagram stats highlighted"),

	/** The linkedin stats highlighted. */
	LINKEDIN_STATS_HIGHLIGHTED(By.xpath("//div[contains(@class,'lkdin-sc') and contains(@class,'active')]"), "Linkedin stats highlighted"),

	/** The create post button. */
	CREATE_POST_BUTTON(By.xpath("//div[contains(@class,'stats community-stat')]//span[text()='CREATE POST']"), "Create Post button"),

	/** The clear all filter. */
	CLEAR_ALL_FILTER(By.xpath("//div[@class='react-ripples ac-primary-box' and not(contains(@class,'pointer-events-none'))]//button//span[text()='Clear Filter']"),
	        "Clear All Filter"),

	/** The clear filter option. */
	CLEAR_FILTER_OPTION(By.xpath("//button//span[text()='Clear Filter']"), "Clear Filter option"),

	/** The all posts button. */
	ALL_POSTS_BUTTON(By.xpath("//input[@name='posts-Engagement Status']//following-sibling::span[text()='All']"), "All posts button"),

	/** The posts with unread comments button. */
	POSTS_WITH_UNREAD_COMMENTS_BUTTON(By.xpath("//input[@name='posts-Engagement Status']//following-sibling::span[text()='Unread']"), "Posts with unread comments button"),

    // /** The post socialmedia name. */
    // POST_SOCIALMEDIA_NAME("//span[text()='%s']//ancestor::div[contains(@class,'gm-item')]//div[@class='gm-head'][1]//h3","Post
    // social media name"),
    //
    // /** The unread count. */
    // UNREAD_COUNT(By.xpath("//section[contains(@class,'stats')]//span[text()='Unread']//following-sibling::span"),
    // "Unread count"),

	/** The month picker. */
	MONTH_PICKER(By.xpath("//select[@class='react-datepicker__month-select']"), "Month picker"),

	/** The from date. */
	FROM_DATE(By.xpath("//div[@class='dp-item date-end__wrp dp-from']//div[contains(@class,'react-datepicker__input-container')]//input[@placeholder='MM/DD/YYYY']"), "From date"),

	/** The from date content. */
	FROM_DATE_CONTENT(By.xpath("//div[contains(@class,'dp-from')]//div[@class='react-datepicker__input-container']//input"), "From date content"),

	/** The select from date. */
	SELECT_FROM_DATE("//section[contains(@class,'filter')]//div//div[2]//div[text()='%s' and @aria-disabled='false']", "Select From date"),

	/** The select from date with month. */
	SELECT_FROM_DATE_WITH_MONTH(
	        "//section[contains(@class,'filter')]//div[contains(@class,'dp-item')]//div[2]//div[@aria-disabled='false' and  contains(@aria-label,'%s')]",
	        "Select from date with month"),

	/** The from date previous month. */
	FROM_DATE_PREVIOUS_MONTH(By.xpath("//section[@class='item-g filter inbox-filter']//div[@class='react-datepicker']//button[@aria-label='Previous Month']"),
	        "From date previous month button"),

	/** The from date next month. */
	FROM_DATE_NEXT_MONTH(By.xpath("//section[@class='item-g filter inbox-filter']//div[@class='react-datepicker']//button[@aria-label='Next Month']"),
	        "From date next month button"),

	/** The select date from calendar. */
	SELECT_DATE_FROM_CALENDAR(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week']//div[@aria-disabled='false']"), "Select date from calendar"),

	/** The calendar displayed. */
	CALENDAR_DISPLAYED(By.xpath("//div[@class='react-datepicker__month']"), "Calendar displayed"),

	/** The select last date. */
	SELECT_LAST_DATE(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week'][3]//div[@aria-disabled='false'][last()]"), "Select last date"),

	/** The to date. */
	TO_DATE(By.xpath("//div[@class='dp-item date-end__wrp dp-to']//div[contains(@class,'react-datepicker__input-container')]//input[@placeholder='Most Recent']"), "To date"),

	/** The to date content. */
	TO_DATE_CONTENT(By.xpath("//div[contains(@class,'dp-to')]//div[@class='react-datepicker__input-container']//input"), "To date content"),

	/** The to date content from calendar. */
	TO_DATE_CONTENT_FROM_CALENDAR(By.xpath("//section[contains(@class,'filter')]//div[contains(@class,'dp-item dp-to')]//div[contains(@class,'today react-datepicker')]"),
	        "To date content from calendar"),

	/** The to date previous month. */
	TO_DATE_PREVIOUS_MONTH(By.xpath("//section[contains(@class,'filter')]//div[@class='dp-item date-end__wrp dp-to']//div[2]//button[@aria-label='Previous Month']"),
	        "To date previous month button"),

	/** The to date next month. */
	TO_DATE_NEXT_MONTH(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='dp-item date-end__wrp dp-to']//div[2]//button[@aria-label='Next Month']"), "To date next month button"),

	/** The select to date. */
	SELECT_TO_DATE("//section[contains(@class,'filter')]//div[contains(@class,'dp-item dp-to')]//div[2]//div[contains(text(),'%s') and @aria-disabled='false']", "Select To date"),

	/** The select to date with month. */
	SELECT_TO_DATE_WITH_MONTH("//section[contains(@class,'filter')]//div[contains(@class,'dp-item date-end__wrp dp-to')]//div[2]//div[@aria-disabled='false' and  contains(@aria-label,'%s')]",
	        "Select to date with month"),

	/** The platform filter. */
	PLATFORM_FILTER(By.xpath("//section[contains(@class,'filter')]//div[contains(@class,'filter-item')]//h3[text()='Platform']"), "Platform filter"),

	/** The all filter button. */
	ALL_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'all-platform.svg')]//parent::button"),
	        "All filter button"),

	/** The all filter selected. */
	ALL_FILTER_SELECTED(
	        By.xpath(
	                "//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'all-platform.svg')]//parent::button[contains(@class,'active')]"),
	        "All filter selected"),

	/** The facebook filter button. */
	FACEBOOK_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'fb-platform')]//parent::button"),
	        "Facebook filter button"),

	/** The facebook filter selected. */
	FACEBOOK_FILTER_SELECTED(
	        By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'fb-platform')]//parent::button[contains(@class,'active')]"),
	        "Facebook filter selected"),

	/** The twitter filter button. */
	TWITTER_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'twitter-platform')]//parent::button"),
	        "Twitter filter button"),

	/** The twitter filter selected. */
	TWITTER_FILTER_SELECTED(
	        By.xpath(
	                "//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'twitter-platform')]//parent::button[contains(@class,'active')]"),
	        "Twitter filter selected"),

	/** The linkedin filter button. */
	LINKEDIN_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'linkedin-platform')]//parent::button"),
	        "LinkedIn filter button"),

	/** The linkedin filter selected. */
	LINKEDIN_FILTER_SELECTED(By
	        .xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'linkedin-platform')]//parent::button[contains(@class,'active')]"),
	        "LinkedIn filter selected"),

	/** The instagram filter button. */
	INSTAGRAM_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'instagram-platform')]//parent::button"),
	        "Instagram filter button"),

	/** The instagram filter selected. */
	INSTAGRAM_FILTER_SELECTED(By.xpath(
	        "//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'instagram-platform')]//parent::button[contains(@class,'active')]"),
	        "Instagram filter selected"),

	/** The engagement filter. */
	ENGAGEMENT_FILTER(By.xpath("//section[contains(@class,'filter')]//div[contains(@class,'filter-item')]//h3[text()='Engagement Type']"), "Engagement filter"),

	/** The all filter. */
	ALL_FILTER(By.xpath(
	        "//section[contains(@class,'filter')]//h3[text()='Engagement Type']//parent::div[contains(@class,'filter-item')]//div[contains(@class,'form-group')]//label//span[text()='All']"),
	        "All filter"),

	/** The all filter active. */
	ALL_FILTER_ACTIVE(By.xpath(
	        "//h3[text()='Engagement Type']//parent::div[contains(@class,'filter-item')]//div[contains(@class,'form-group')]//label//span[text()='All']//ancestor::label[@class='active']"),
	        "All filter active"),

	/** The comment filter. */
	COMMENT_FILTER(By.xpath(
	        "//section[contains(@class,'filter')]//h3[text()='Engagement Type']//parent::div[contains(@class,'filter-item')]//div[contains(@class,'form-group')]//label//span[contains(text(),'Comment')]"),
	        "Comment filter"),

	/** The comment filter active. */
	COMMENT_FILTER_ACTIVE(By.xpath(
	        "//h3[text()='Engagement Type']//parent::div[contains(@class,'filter-item')]//div[contains(@class,'form-group')]//label//span[contains(text(),'Comment')]//ancestor::label[@class='active']"),
	        "Comment filter active"),

	/** The message filter. */
	MESSAGE_FILTER(By.xpath(
	        "//section[contains(@class,'filter')]//h3[text()='Engagement Type']//parent::div[contains(@class,'filter-item')]//div[contains(@class,'form-group')]//label//span[text()='Message']"),
	        "Message filter"),

	/** The message filter active. */
	MESSAGE_FILTER_ACTIVE(By.xpath(
	        "//h3[text()='Engagement Type']//parent::div[contains(@class,'filter-item')]//div[contains(@class,'form-group')]//label//span[text()='Message']//ancestor::label[@class='active']"),
	        "Message filter active"),

	/** The post filter. */
	POST_FILTER(By.xpath(
	        "//section[contains(@class,'filter')]//h3[text()='Engagement Type']//parent::div[contains(@class,'filter-item')]//div[contains(@class,'form-group')]//label//span[text()='Post']"),
	        "Post filter"),

	/** The post filter active. */
	POST_FILTER_ACTIVE(By.xpath(
	        "//h3[text()='Engagement Type']//parent::div[contains(@class,'filter-item')]//div[contains(@class,'form-group')]//label//span[text()='Post']//ancestor::label[@class='active']"),
	        "Post filter active"),

	ENGAGEMENT_ALL_FILTER(By.xpath("//input[@name='engagement-Engagement Type' and @value='all']"),"ENGAGEMENT ALL FILTER"),
	
	ENGAGEMENT_ALL_FILTER_ACTIVE(By.xpath("//label[@class='active']//input[@name='engagement-Engagement Type' and @value='all']"),"ENGAGEMENT ALL FILTER Active"),
	
	ENGAGEMENT_POST_COMMENT_FILTER(By.xpath("//input[@name='engagement-Engagement Type']//following-sibling::span[text()='Post Comments']"),"Engagement Post Comment Filter"),
	
	ENGAGEMENT_POST_COMMENT_FILTER_ACTIVE(By.xpath("//label[@class='active']//input[@name='engagement-Engagement Type']//following-sibling::span[text()='Post Comments']"),"Engagement Post Comment Active Filter"),
	
	ENGAGEMENT_AD_COMMENT_FILTER(By.xpath("//input[@name='engagement-Engagement Type']//following-sibling::span[text()='Ad Comments']"),"Engagement Ad Comment Filter"),
	
	ENGAGEMENT_AD_COMMENT_FILTER_ACTIVE(By.xpath("//label[@class='active']//input[@name='engagement-Engagement Type']//following-sibling::span[text()='Ad Comments']"),"Engagement Ad Comment Filter Active"),
	
    ENGAGEMENT_DIRECT_MESSAGE_FILTER(By.xpath("//input[@name='engagement-Engagement Type']//following-sibling::span[text()='Direct Messages']"),"Engagement Direct Messages Filter"),
	
	ENGAGEMENT_DIRECT_MESSAGE_FILTER_ACTIVE(By.xpath("//label[@class='active']//input[@name='engagement-Engagement Type']//following-sibling::span[text()='Direct Messages']"),"Engagement Direct Messages Active Filter"),
	
	VIEW_MESSAGES(By.xpath("//div[@class='vc-item']//span[text()='View Messages']"),"View Mesages"),
	
	ENGAGEMENT_MENTIONS_FILTER(By.xpath("//label//input[@name='engagement-Engagement Type']//following-sibling::span[text()='Mentions']"),"Mentions Filter"),
	
	ENGAGEMENT_MENTIONS_FILTER_ACTIVE(By.xpath("//label[@class='active']//input[@name='engagement-Engagement Type']//following-sibling::span[text()='Mentions']"),"Engagement Mentions Active Filter"),
	
    // /** The filters close button. */
    // FILTERS_CLOSE_BUTTON(By.xpath("//div[contains(@class,'stats-assorted
    // ')]//button[@class='btnFilter fltrOpen fltrClose btn
    // btn-primary']"),"Filter close button"),
    //
    // /** The filters open button. */
    // FILTERS_OPEN_BUTTON(By.xpath("//div[contains(@class,'stats-assorted
    // ')]//button[@class='btnFilter fltrOpen btn btn-primary']"),"Filters open
    // button"),
    //
    // /** The search box. */
    // SEARCH_BOX(By.xpath("//div[@class='react-tags__search-input']//input"),
    // "Search Box"),
    //
    // /** The search result. */
    // SEARCH_RESULT("//div[contains(@class,'gm-item')]//div[@class='gm-content']//p[contains(text(),'%s')]",
    // "search result"),

	/** The locations filter. */
	LOCATIONS_FILTER(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='filter-item fltr-drp']//h3[text()='Locations']"), "Locations filter"),

	/** The locations filter dropdown. */
	LOCATIONS_FILTER_DROPDOWN(By.xpath("//section[contains(@class,'item-g filter')]//h3[text()='Locations']//parent::div//div//button"), "Locations filter dropdown"),

	/** The locations filter current location. */
	LOCATIONS_FILTER_CURRENT_LOCATION(By.xpath("//section[contains(@class,'item-g filter')]//h3[text()='Locations']//parent::div//div//button//span"), "Locations filter dropdown"),

	/** The select from locations filter. */
	SELECT_FROM_LOCATIONS_FILTER("//div[@id='locations-dropdown-inbox']//div[contains(@class,'rs-drp__menu-list')]//div[contains(text(),'%s')]", "Seect from locations filter"),

	/** The locations filter search box. */
	LOCATIONS_FILTER_SEARCH_BOX(By.xpath("//div[contains(@class,'rs-drp__value-container')]//input"), "Locations filter search box"),

	/** The footer. */
	FOOTER(By.xpath("//div[contains(@class,'list-view')]//div[contains(@class,'li-view-main')][last()]"), "Footer"),

	/** The no data to show. */
	NO_DATA_TO_SHOW(By.xpath("//div[@class='content-g']//div[@class='no-data']//span[text()='No data to show']"), "No data to show"),

	/** The facebook contents. */
	FACEBOOK_CONTENTS(By.xpath("//div[@class='li-view-main']//div[@class='li-top']//div[@class='round-asset platform-icon']//img[contains(@src,'fb-lv.svg')]"),
	        "Facebook contents"),

	/** The twitter contents. */
	TWITTER_CONTENTS(By.xpath("//div[@class='li-view-main']//div[@class='li-top']//div[@class='round-asset platform-icon']//img[contains(@src,'twitter-lv.svg')]"),
	        "Twitter contents"),

	/** The linkedin contents. */
	LINKEDIN_CONTENTS(By.xpath("//div[@class='li-view-main']//div[@class='li-top']//div[@class='round-asset platform-icon']//img[contains(@src,'linkedin-lv.svg')]"),
	        "Linked In contents"),

	/** The instagram contents. */
	INSTAGRAM_CONTENTS(By.xpath("//div[@class='li-view-main']//div[@class='li-top']//div[@class='round-asset platform-icon']//img[contains(@src,'instagram-lv.svg')]"),
	        "Instagram contents"),

	/** The social media icon.*/
	POST_SOCIAL_MEDIA_ICON(
	        "//div[@class='liv-right list-item']//p[contains(text(),'%s')]//ancestor::div[@class='li-view-main']//div[@class='li-top']//div[@class='round-asset platform-icon']//img",
	        "Social media icon"),
	/** The social media icon. */
	SOCIAL_MEDIA_ICON(By.xpath("//div[@class='li-view-main']//div[@class='li-top']//div[@class='round-asset platform-icon']//img"), "Social media icon"),

	/** The post profile icon. */
	POST_PROFILE_ICON(
	        "//div[@class='liv-right list-item']//p[contains(text(),'%s')]//ancestor::div[@class='li-view-main']//div[@class='li-top']//div[@class='round-asset brand-icon']//img",
	        "Post profile icon"),

	/** The profile icon. */
	PROFILE_ICON(By.xpath("//div[@class='liv-right list-item']//ancestor::div[@class='li-view-main']//div[@class='li-top']//div[@class='round-asset brand-icon']//img"), "Profile icon"),

	/** The location name. */
	POST_LOCATION_NAME("//div[@class='liv-right list-item']//p[contains(text(),'%s')]//ancestor::div[@class='li-view-main']//div[@class='li-top']//div[@class='lvt-details']//h3",
	        "Location name"),

	/** The location name. */
	LOCATION_NAME(By.xpath("//div[@class='liv-right list-item']//ancestor::div[@class='li-view-main']//div[@class='li-top']//div[@class='lvt-details']//h3"), "Location name"),

	/** The posted date time. */
	POSTED_DATE_TIME(
	        "//div[@class='liv-right list-item']//p[contains(text(),'%s')]//ancestor::div[@class='li-view-main']//div[@class='li-top']//div[@class='lvt-details']//div//span[@class='lvt-txt'][2]",
	        "Posted date time"),

	/** The date time. */
	DATE_TIME(By.xpath("//div[@class='liv-right list-item']//ancestor::div[@class='li-view-main']//div[@class='li-top']//div[@class='lvt-details']//div//span[@class='lvt-txt'][2]"),
	        "date time"),

	/** The social media profile image. */
	SOCIAL_MEDIA_PROFILE_IMAGE("//div[@class='liv-right list-item']//p[contains(text(),'%s')]//ancestor::div[@class='li-view-main']//div[@class='liv-left li-top']//div//img",
	        "Social media profile image"),

	/** The profile image. */
	PROFILE_IMAGE(By.xpath("//div[@class='liv-right list-item']//ancestor::div[@class='li-view-main']//div[@class='liv-left li-top']//div//img"), "profile image"),

	/** The social media profile name. */
	SOCIAL_MEDIA_PROFILE_NAME(
	        "//div[@class='liv-right list-item']//p[contains(text(),'%s')]//ancestor::div[@class='li-view-main']//div[@class='liv-left li-top']//div[@class='lvt-details']//h3",
	        "Social media profile name"),

	/** The profile name. */
	PROFILE_NAME(By.xpath("//div[@class='liv-right list-item']//ancestor::div[@class='li-view-main']//div[@class='liv-left li-top']//div[@class='lvt-details']//h3"), "Profile name"),

	/** The social media profilename hover text. */
	SOCIAL_MEDIA_PROFILENAME_HOVER_TEXT(By.xpath("//div[@class='rc-tooltip-content']//div[2]//div[@class='common-tooltip--wrp']"), "Profile name hover text"),

	/** The posted something to. */
	PROFILE_POSTED_SOMETHING_TO(
	        "//div[@class='liv-right list-item']//p[contains(text(),'%s')]//ancestor::div[@class='li-view-main']//div[@class='liv-left li-top']//div[@class='lvt-brief']//span[text()]",
	        "Posted something to"),

	/** The posted something to. */
	POSTED_SOMETHING_TO(By.xpath("//div[@class='liv-right list-item']//ancestor::div[@class='li-view-main']//div[@class='liv-left li-top']//div[@class='lvt-brief']//span[text()]"),
	        "Posted something to"),

	/** The three dots button. */
	THREE_DOTS_BUTTON(
	        "//div[@class='liv-right list-item']//p[contains(text(),'%s')]//ancestor::div[@class='li-view-main']//div[@class='li-top']//div[@class='drop-items dropdown']//button",
	        "Three dots button"),

	/** The three dots. */
	THREE_DOTS(By.xpath("//div[@class='liv-right list-item']//ancestor::div[@class='li-view-main']//div[@class='li-top']//div[@class='drop-items dropdown']//button"), "Three dots"),

	/** The link button. */
	LINK_BUTTON(By.xpath("//div[@class='li-view-main']//div[@class='li-top']//div[@class='drop-items show dropdown']//a//span[text()='Link to Post']"), "Link button"),

	/** The post delete button. */
	POST_DELETE_BUTTON(By.xpath("//div[@class='li-view-main']//div[@class='li-top']//div[@class='drop-items show dropdown']//a//span[text()='Delete']"), "Post delete button"),

	/** The post delete alert box. */
	POST_DELETE_ALERT_BOX(By.xpath("//div[text()='Are you sure you want to delete this post?']"), "Post delete alert box"),

	/** The delete alert cancel button. */
	DELETE_ALERT_CANCEL_BUTTON(By.xpath("//button[text()='Cancel']"), "Delete alert cancel button"),

	/** The delete alert delete button. */
	DELETE_ALERT_DELETE_BUTTON(By.xpath("//button[text()='Delete']"), "Delete alert delete button"),

	/** The post deleted message. */
	POST_DELETED_MESSAGE(By.xpath("//span[text()='Done!']"), "Post deleted message"),

	/** Posts list. */
	POSTS_LIST(By.xpath("//div[@class='list-view doubleSlots']//div[@class='li-view-main']"), "Posts list"),

	/** The comment only posts. */
	COMMENT_ONLY_POSTS(By.xpath("//div[@class='li-view-main']//div[@class='li-base']//div[@class='vc-item']//span[text()='Comments']"), "Comment only posts"),

    // /** The location posts. */
    // LOCATION_POSTS(By.xpath("//div[contains(@class,'gm-item')]//div[@class='gmi-cnt']//div[contains(@class,'gm-head')][1]//h3[text()]"),
    // "Location Posts"),
    //
    // /** The stats content unread. */
    // STATS_CONTENT_UNREAD(By.xpath("//div[contains(@class,'stats-item')]//span[text()='Unread']"),
    // "Stats content Unread"),

	/** The like button. */
	POST_LIKE_BUTTON("//div[@class='liv-right list-item']//p[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//span[text()='Like']", "Like button"),

	/** The like button. */
	LIKE_BUTTON(By.xpath("//div[@class='li-base']//div[@class='vc-item']//following-sibling::span[text()='Like']"), "like button"),

	/** The post reactions count. */
	POST_REACTIONS_COUNT(
	        By.xpath("//div[@class='liv-right list-item']//ancestor::div[@class='li-base']//div[@class='lvc-item']//span[text()='Reactions']//preceding-sibling::span[@class='lvc-count']"),
	        "Post reactions count"),

	/** The post shares count. */
	POST_SHARES_COUNT(
	        By.xpath("//div[@class='liv-right list-item']//ancestor::div[@class='li-base']//div[@class='lvc-item']//span[text()='Shares']//preceding-sibling::span[@class='lvc-count']"),
	        "Post shares count"),

	/** The unclickable comments count. */
	UNCLICKABLE_COMMENTS_COUNT(
	        By.xpath("//div[@class='liv-right list-item']//ancestor::div[@class='li-base']//div[@class='lvc-item']//span[text()='Comments']//preceding-sibling::span[@class='lvc-count']"),
	        "Unclickable comments count"),

	/** The post likes count. */
	POST_LIKES_COUNT(
	        By.xpath("//div[@class='liv-right list-item']//ancestor::div[@class='li-base']//div[@class='lvc-item']//span[text()='Likes']//preceding-sibling::span[@class='lvc-count']"),
	        "Post likes count"),

	/** The post favorites count. */
	POST_FAVORITES_COUNT(
	        By.xpath("//div[@class='liv-right list-item']//ancestor::div[@class='li-base']//div[@class='lvc-item']//span[text()='Favorites']//preceding-sibling::span[@class='lvc-count']"),
	        "Post favourites count"),

	/** The post retweets count. */
	POST_RETWEETS_COUNT(
	        By.xpath("//div[@class='liv-right list-item']//ancestor::div[@class='li-base']//div[@class='lvc-item']//span[text()='Retweets']//preceding-sibling::span[@class='lvc-count']"),
	        "Post retweets count"),

	/** The facebook post not liked. */
	FACEBOOK_POST_NOT_LIKED("//div[@class='liv-right list-item']//p[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'fb-like.svg')]",
	        "Facebook post not liked"),

	/** The fb post not liked. */
	FB_POST_NOT_LIKED(By.xpath("//div[@class='liv-right list-item']//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'fb-like.svg')]"), "FB post not liked"),

	/** The facebook post liked. */
	FACEBOOK_POST_LIKED("//div[@class='liv-right list-item']//p[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//img[@alt='Like']",
	        "Facebook post liked"),

	/** The fb post liked. */
	FB_POST_LIKED(By.xpath("//div[@class='liv-right list-item']//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'fb-like-a.svg')]"), "FB post liked"),

	/** The twitter post not liked. */
	TWITTER_POST_NOT_LIKED(
	        "//div[@class='liv-right list-item']//div[@class='liv-right list-item']//p[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'twitter-like.svg')]",
	        "Twitter post not liked"),

	/** The twitter post liked. */
	TWITTER_POST_LIKED("//div[@class='liv-right list-item']//div[@class='liv-right list-item']//p[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'twitter-like-a.svg')]",
	        "Twitter post liked"),

	/** The instagram post not liked. */
	INSTAGRAM_POST_NOT_LIKED(
	        "//div[@class='liv-right list-item']//p[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'instagram-like.svg')]",
	        "Instagram post not liked"),

	/** The instagram post liked. */
	INSTAGRAM_POST_LIKED(
	        "//div[@class='liv-right list-item']//p[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'instagram-like-a.svg')]",
	        "Instagram post liked"),

	/** The post comments button. */
	POST_COMMENTS_BUTTON("//div[@class='liv-right list-item']//p[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//span[text()='Comments']",
	        "post comments button"),

	/** The comments button. */
	COMMENTS_BUTTON(By.xpath("//div[@class='liv-right list-item']//div[@class='vc-item']//img//following-sibling::span[text()='Comments']"), "Comments button"),

	DISACTIVE_STAR_BUTTON(By.xpath("//div[@class='gmh-left']//following::div[@class='comment-item saveMark']//span[@class='star-filled']"),"DISACTIVE_STAR_BUTTON"),

	ACTIVE_START_BUTTON(By.xpath("//div[@class='gmh-left']//following::div[@class='comment-item saveMark']//span[@class='star-filled active']"),"ACTIVE_START_BUTTON"),

	SAVED_ENGAGEMENT_STATUS_FILTER(By.xpath("//input[@name='posts-Engagement Status']//following::span[text()='Saved']"),"SAVED_ENGAGEMENT_STATUS_FILTER"),

	/** The post comments count. */
	POST_COMMENTS_COUNT("//div[@class='liv-right list-item']//p[contains(text(),\"%s\")]//ancestor::div[@class='li-base']//div[@class='vc-item']//span[@class='count-red']//span",
	        "Post comments count"),

	POST_COMMENTS_COUNTS(By.xpath("//div[@class='liv-right list-item']//ancestor::div[@class='li-base']//div[@class='lvc-item']//span[text()='Comments']//preceding-sibling::span[@class='lvc-count']"),"Post Comments Count"),

	/** The post comments number. */
	POST_COMMENTS_NUMBER("//div[@class='liv-right list-item']//p[contains(text(),\"%s\")]//ancestor::div[@class='li-base']//following::div[@class='aib-item']//span[text()='Comments']//parent::div//span",
			 "Post comments Number"),
	
	/** The unread comments. */
	UNREAD_COMMENTS(By.xpath("//div[@class='vc-item']//span[@class='count-red']"),"The Unread Comments"),
	
	/** The unread comments field. */
	UNREAD_COMMENTS_FIELD("//p[contains(text(),'%s')]//ancestor::div[@class='liv-right list-item']//div[@class='vc-controls']//div[@class='vc-item']//span[@class='count-red']","Unread Comments Field"),
	
	/** The comments count. */
	COMMENTS_COUNT(By.xpath("//div[@class='liv-right list-item']//ancestor::div[@class='li-base']//div[@class='vc-item']//span[@class='count-red']//span"), "Comments count"),

	/** The post comments list. */
	//POST_COMMENTS_LIST(By.xpath("//div[@class='g-centre']//div[@class='li-view-main']//div[@class='liv-right list-item']"), "Post comments list"),

	POST_COMMENTS_LIST(By.xpath("//div[@class='g-centre']//div[@class='li-view-main']//div[@class='liv-right list-item']"), "Post comments list"),

	/** The post comments. */
	POST_COMMENTS(By.xpath("//div[@class='nested-items-wrp']//div[contains(@class,'gm-head')]"), "Post comments"),

	/** The post comment footer. */
	POST_COMMENT_FOOTER(By.xpath("//div[@class='nested-items-wrp']//div[contains(@class,'gm-head')][last()]"), "Post comment footer"),

	/** The post comment brand icon. */
	POST_COMMENT_BRAND_ICON(By.xpath("//div[@class='content-g']//div[contains(@class,'liv-left li-top')]//div[contains(@class,'brand-icon')]//img"),"Post comment brand icon"),
	
	/** The post comment media name. */
	POST_COMMENT_MEDIA_NAME(By.xpath("//div[@class='content-g']//div[contains(@class,'liv-left li-top')]//div[@class='lvt-details']//h3"),
	        "Post comment media name"),

	/** The post comment date time. */
	POST_COMMENT_DATE_TIME(By.xpath("//div[@class='liv-right list-item']//div[@class='li-top']//div[@class='lvt-brief']//span//following-sibling::span[text()]"),
	        "Post comment date and time"),

	/** The post comment content. */
	POST_COMMENT_CONTENT(By.xpath("//div[@class='nested-items-wrp']//div[contains(@class,'gm-head rb-gh-fs rb-gh-first')]//p[text()]"), "Post comment content"),

	/** The post comment like button. */
	POST_COMMENT_LIKE_BUTTON(
	        By.xpath("//img[contains(@src,'fb-like.svg')]//parent::div//span[text()='Like']"),
	        "Post comment like button"),

	/** The post comment liked. */
	POST_COMMENT_LIKED(By.xpath(
	        "//img[contains(@src,'fb-like-a.svg')]//parent::div//span[text()='Like']"),
	        "Post comment liked"),
////div[@class='nested-items-wrp']//div[contains(@class,'gm-head rb-gh-fs rb-gh-first')]//div[@class='comment-controls']//span[text()='Like' and @class='active']

	/** The post comment not liked. */
	POST_COMMENT_NOT_LIKED(By.xpath(
	        "//div[@class='nested-items-wrp']//div[contains(@class,'gm-head rb-gh-fs rb-gh-first')]//div[@class='comment-controls']//span[text()='Like' and not(contains(@class,'active'))]"),
	        "Post comment not liked"),

	/** The post comment replies count. */
	POST_COMMENT_REPLIES_COUNT(
	        By.xpath("//div[@class='nested-items-wrp']//div[contains(@class,'gm-head rb-gh-fs rb-gh-first')]//div[@class='comment-controls']//span[contains(@class,'text')]"),
	        "Post comment replies count"),

	/** The post comment replies open button red. */
	POST_COMMENT_REPLIES_OPEN_BUTTON_RED(By.xpath(
	        "//div[@class='nested-items-wrp']//div[contains(@class,'gm-head rb-gh-fs rb-gh-first')]//div[@class='comment-controls']//span[@class='s-red-text' and contains(text(),'Rep')]"),
	        "Post comments open button red"),

	/** The post comment replies open button blue. */
	POST_COMMENT_REPLIES_OPEN_BUTTON_BLUE(By.xpath(
	        "//div[@class='nested-items-wrp']//div[contains(@class,'gm-head rb-gh-fs rb-gh-first')]//div[@class='comment-controls']//span[@class='s-blue-text' and contains(text(),'Rep')]"),
	        "Post comment replies open button blue"),

	/** The post comment reply button. */
	POST_COMMENT_REPLY_BUTTON(
	        By.xpath("//div[@class='nested-items-wrp']//div[contains(@class,'gm-head rb-gh-fs rb-gh-first')]//div[@class='comment-controls']//span[text()='Reply']"),
	        "post comment reply button"),

	/** The post comment reply active. */
	POST_COMMENT_REPLY_ACTIVE(By.xpath(
	        "//div[@class='nested-items-wrp']//div[contains(@class,'gm-head rb-gh-fs rb-gh-first')]//div[@class='comment-controls']//span[text()='Reply' and @class='active']"),
	        "Post comment reply active"),

	/** The post comment reply text area. */
	POST_COMMENT_REPLY_TEXT_AREA(By.xpath(
	        "//div[@class='nested-items-wrp']//div[contains(@class,'gm-head rb-gh-fs rb-gh-first')]//div[@class='lv-comment']//span//parent::div[@class='public-DraftStyleDefault-block public-DraftStyleDefault-ltr']"),
	        "Post comment reply text area"),

	/** The post comment postreply button. */
	POST_COMMENT_POSTREPLY_BUTTON(
	        By.xpath("//div[@class='nested-items-wrp']//div[contains(@class,'gm-head rb-gh-fs rb-gh-first')]//div[@class='lv-comment']//div[@class='lvc-base']//button"),
	        "Post comment post reply button"),

	/** The reply sent message. */
	REPLY_SENT_MESSAGE(By.xpath("//span[contains(text(),'Reply sent!')]"), "Reply sent message"),

	POST_COMENT_DETAILVIEW_COMMENT(By.xpath("//div[@class='nested-items-wrp']//div[@class='comment-item']"),"Post Comment Detailview Comment"),

	/** The post comment delete button. */
	POST_COMMENT_DELETE_BUTTON(
	        By.xpath("//div[@class='nested-items-wrp']//div[contains(@class,'gm-head rb-gh-fs rb-gh-first')]//div[@class='comment-controls']//span[text()='Delete']"),
	        "post comment delete button"),

	/** The post comment delete. */
	POST_COMMENT_DELETE(By.xpath("//div[@class='liv-right list-item']//div[@class='nested-items-wrp']//div[contains(@class,'gm-head')]//div[@class='comment-controls']//span[text()='Delete']"),"Post Reply comment Delete"),
	
	/** The post comment delete alert box. */
	POST_COMMENT_DELETE_ALERT_BOX(By.xpath("//div[text()='Are you sure you want to delete this comment?']"), "Post comment delete alert box"),

	/** The comment replies. */
	COMMENT_REPLIES(By.xpath("//div[@class='nested-items-wrp']//div[contains(@class,'gm-head')]"), "Comment replies"),

	/** The comment replies footer. */
	COMMENT_REPLIES_FOOTER(By.xpath("//div[@class='nested-items-wrp']//div[contains(@class,'gm-head')][last()]"), "Comment replies footer"),

	/** The comment reply brand icon. */
	COMMENT_REPLY_BRAND_ICON(By.xpath("//div[@class='nested-items-wrp']//div[contains(@class,'gm-head')]//div[contains(@class,'brand-icon')]//img"),
	        "Comment reply brand icon"),

	/** The comment reply media name. */
	COMMENT_REPLY_MEDIA_NAME(By.xpath("//div[@class='nested-items-wrp']//div[contains(@class,'gm-head')]//div[@class='gmhl-ncd']//h3"),
	        "Comment reply media name"),

	/** The comment reply date time. */
	COMMENT_REPLY_DATE_TIME(By.xpath("//div[@class='nested-items-wrp']//div[contains(@class,'gm-head')]//div[@class='gmhl-ncd']//div"),
	        "Comment reply date and time"),

	/** The comment reply content. */
	COMMENT_REPLY_CONTENT("//div[@class='nested-items-wrp']//div[contains(@class,'gm-head')]//p[contains(text(),'%s')]", "Comment reply content"),

	/** The comment reply like button. */
	COMMENT_REPLY_LIKE_BUTTON(
	        By.xpath("//div[@class='nested-items-wrp']//div[contains(@class,'gm-head')]//div[@class='comment-controls']//span[text()='Like']"),
	        "Comment reply like button"),

	/** The comment reply liked. */
	COMMENT_REPLY_LIKED(By.xpath(
	        "//div[@class='nested-items-wrp']//div[contains(@class,'gm-head')]//div[@class='comment-controls']//span[text()='Like' and @class='active']"),
	        "Comment reply liked"),

	/** The comment reply not liked. */
	COMMENT_REPLY_NOT_LIKED(By.xpath(
	        "//div[@class='nested-items-wrp']//div[contains(@class,'gm-head')]//div[@class='comment-controls']//span[text()='Like' and not(contains(@class,'active'))]"),
	        "Comment reply not liked"),

	/** The comment replies reply button. */
	COMMENT_REPLIES_REPLY_BUTTON(
	        By.xpath("//div[@class='nested-items-wrp']//div[contains(@class,'gm-head')]//div[@class='comment-controls']//span[text()='Reply']"),
	        "Comment replies reply button"),

     /** The inbox post by content. */
     INBOX_POST_BY_CONTENT("//div[contains(@class,'list-item')]//div[@class='liv-right list-item']//span//span//span//span[text()='%s']", "Post text content"),

	/** The comment replies reply active. */
	COMMENT_REPLIES_REPLY_ACTIVE(By.xpath(
	        "//div[@class='nested-items-wrp']//div[contains(@class,'gm-head')]//div[@class='comment-controls']//span[text()='Reply' and @class='active']"),
	        "Comment replies reply active"),

	/** The comment replies reply text area. */
	COMMENT_REPLIES_REPLY_TEXT_AREA(By.xpath("//div[@class='nested-items-wrp']//div[@class='public-DraftStyleDefault-block public-DraftStyleDefault-ltr']"),
	        "Comment replies reply text area"),

	/** The comment replies post reply button. */
	COMMENT_REPLIES_POST_REPLY_BUTTON(
	        By.xpath("//div[@class='nested-items-wrp']//div[contains(@class,'gm-head')]//div[@class='lv-comment']//div[@class='lvc-base']//button"),
	        "Comment replies post reply button"),

	/** The comment reply delete button. */
	COMMENT_REPLY_DELETE_BUTTON(
	        By.xpath("//div[@class='nested-items-wrp']//div[contains(@class,'gm-head')]//div[@class='comment-controls']//span[text()='Delete']"),
	        "Comment reply delete button"),

    // /** The view comment count. */
    // VIEW_COMMENT_COUNT(By.xpath("//div[contains(@class,'gm-item')]//div[@class='vc-itxt']//span[text()='View
    // Comments']//following-sibling::span"), "View comment count"),
    //
    // /** The retweet button. */
    // RETWEET_BUTTON(By.xpath("//div[contains(@class,'gm-item')]//img[@alt='Retweet']//parent::button"),"Retweet
    // button"),
    //
    // /** The delete button. */
    // DELETE_BUTTON(By.xpath("//div[contains(@class,'gm-item')]//img[@alt='Delete']//parent::button"),"Delete
    // button"),
    //
    // /** The like button hover text. */
    // LIKE_BUTTON_HOVER_TEXT(By.xpath("//div[@class='rc-tooltip-content']//span[text()='Like']"),"Like
    // hover text"),
    //
    // /** The link button hover text. */
    // LINK_BUTTON_HOVER_TEXT(By.xpath("//div[@class='rc-tooltip-content']//span[text()='Open
    // Website']"),"Link hover text"),
    //
    // /** The retweet button hover text. */
    // RETWEET_BUTTON_HOVER_TEXT(By.xpath("//div[@class='rc-tooltip-content']//span[text()='Retweet']"),"Retweet
    // hover text"),
    //
    // /** The delete button hover text. */
    // DELETE_BUTTON_HOVER_TEXT(By.xpath("//div[@class='rc-tooltip-content']//span[text()='Delete
    // Published Post']"),"Delete hover text"),

	/** The post text content. */
	POST_TEXT_CONTENT(By.xpath("//div[@class='li-view-main']//div[@class='liv-right list-item']//div[@class='li-base']//p[@class='gm-text']"), "Post text content"),

	/** The post text content field. */
	POST_TEXT_CONTENT_FIELD("//div[@class='li-view-main']//div[@class='liv-right list-item']//div[@class='li-base']//p[@class='gm-text' and contains(text(),'%s')]","Post Text Content  Field"),
	
	/** The post image content. */
	POST_IMAGE_CONTENT(By.xpath("//div[@class='li-view-main']//div[@class='li-base']//div[@class='lv-assets']//li[2]//div[contains(@class,'gma-item')]//img"), "Post image content"),

	/** The message contents. */
	MESSAGE_CONTENTS(By.xpath("//div[@class='li-view-main']//div[contains(@class,'liv-right')]//div[@class='li-base']//div[@class='lv-comment']"), "Message contents"),

	/** The messages contents text area. */
	MESSAGES_CONTENTS_TEXT_AREA("//div[@class='liv-right list-item']//p[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='lv-comment']//div[2]//div[@class='public-DraftEditorPlaceholder-inner']",
	        "Message contents reply area"),

	/** The message contents text area hover. */
	MESSAGE_CONTENTS_TEXT_AREA_HOVER(By.xpath("//div[@class='rc-tooltip-content']//div[@class='rc-tooltip-inner']//div[@class='common-tooltip--wrp']"), "Message contents text area hover"),

	/** The location selector button. */
	LOCATION_SELECTOR_BUTTON(By.xpath("//h3[text()='Location Selector']//following-sibling::div[@class='locAction']//span"), "Location selector button"),

	/** The location selector view. */
	LOCATION_SELECTOR_VIEW(By.xpath("//div[@class='modal-body']//h3[text()='Location Selector']//parent::div//parent::div//div[@class='asm-accord']"), "Location selector view"),

	/** The hubs dropdown. */
	HUBS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='accordion']//span[@class='lca-head' and text()='Hubs']"), "Hubs dropdown"),

	/** The location lists dropdown. */
	LOCATION_LISTS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='accordion']//span[@class='lca-head' and text()='Location Lists']"), "LocationLists dropdown"),

	/** The location selector byname. */
	LOCATION_SELECTOR_BYNAME("//div[contains(@class,'list-item')]//div[@class='lvt-details']//h3[contains(text(),'%s')]","The Location Selector By name"),
	
	/** The location selector dropdown user. */
	LOCATION_SELECTOR_DROPDOWN_USER("//div//ul[@class='hub-list']//span[contains(text(),\"%s\")]", "Location Selecter Dropdown User"),

	
	/** The locations dropdown. */
	LOCATIONS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='accordion']//span[@class='lca-head' and text()='Locations']"), "Locations dropdown"),

	/** The location selector dropdown list. */
	LOCATION_SELECTOR_DROPDOWN_LIST(
	        By.xpath("//div[@class='modal-body']//div[@class='open card-header']//parent::div[@class='accordion-item']//following-sibling::div//ul[@class='hub-list']"),
	        "Location selector dropdown list"),

	/** The location selector search. */
	LOCATION_SELECTOR_SEARCH(By.xpath("//h3[text()='Location Selector']//following-sibling::div//input[@name='Locations']"), "Location selector search"),

	/** The select dropdown list. */
	SELECT_DROPDOWN_LIST(
	        "//div[@class='modal-body']//div[@class='open card-header']//parent::div[@class='accordion-item']//following-sibling::div//ul//li//span[contains(text(),'%s')]",
	        "Select dropdown list"),

	/** The selected dropdown list. */
	SELECTED_DROPDOWN_LIST(
	        "//div[@class='modal-body']//div[@class='open card-header']//parent::div[@class='accordion-item']//following-sibling::div//ul//li//input[@checked]//following-sibling::div//span[contains(text(),'%s')]",
	        "Selected dropdown list"),

	/** The location selector cancel button. */
	LOCATION_SELECTOR_CANCEL_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Cancel']"), "Location selector cancel button"),

	/** The location selector ok button. */
	LOCATION_SELECTOR_OK_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Ok']"), "Location selector ok button"),

	/** The location selector hub tab. */
	LOCATION_SELECTOR_HUB_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Hubs']"), "Location Selecter Hub tab."),

	/** The locator selector name. */
	LOCATOR_SELECTOR_NAME("//span[@class='lcs-name' and @title='%s']","The Location selector Name"),
	
	/** The community tab sandbox. */
	COMMUNITY_TAB_SANDBOX(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Sandbox']"), "Community tab sandbox"),
	
	/** The location selector location tab. */
	LOCATION_SELECTOR_ALL_LOCATION_TAB(By.xpath("//input[@name='selectedLocation']//following-sibling::span[text()='All Locations']"), "The All Locations selector tab."),

	/** The location selector close button. */
	LOCATION_SELECTOR_CLOSE_BUTTON(By.xpath("//img[@class='close-icon']"), "Location Selector Close Button"),


	/** The sortby dropdowns. */
	SORTBY_DROPDOWNS(
	        By.xpath("//div[text()='Sort by']//parent::div//parent::div//div[@class='sortby-list__wrp']//div[@class='ds-dropdown']//following-sibling::div[@class='ds-dropdown']"),
	        "Sortby dropdowns"),

    /**  New Inbox Enums *. */
	/** The write a comment. */
	WRITE_A_COMMENT(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lv-comment']//div[contains(@id,'placeholder-editor-inbox-comment')]"),
	        " Write a comment"),

	/** The write a reply. */
	WRITE_A_REPLY(By.xpath("//div[@class='public-DraftEditorPlaceholder-inner']"),"Write A reply "),
	
	/** The write a comment text. */
	WRITE_A_COMMENT_TEXT(By.xpath("//div[@class='at-mention editor']//div[@class='DraftEditor-root']//div[@class='public-DraftStyleDefault-block public-DraftStyleDefault-ltr']"),
	        "Write the comment"),

	/** The post comment button. */
	POST_COMMENT_BUTTON(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lv-comment']//button[text()='Post Comment']"), "Post comment button"),

	/** The reply sent popup. */
	REPLY_SENT_POPUP(By.xpath("//div//span[text()='Reply sent!']"), "The Reply sent Popup"),

	/** The twitter post pageload withimage. */
	TWITTER_POST_PAGELOAD_WITHIMAGE(By.xpath("//div[@class='css-1dbjc4n r-aqfbo4 r-16y2uox']//ancestor::div[@class='css-1dbjc4n r-18u37iz r-13qz1uu r-417010']"),
	        "The Twitter Pageload with image"),

	/** The twitter post pageload withoutimage. */
	TWITTER_POST_PAGELOAD_WITHOUTIMAGE(
	        "//p[contains(text(),'%s')]//ancestor::div[@class='css-1dbjc4n r-18u37iz r-13qz1uu r-417010']//div[@class='css-1dbjc4n r-aqfbo4 r-16y2uox']",
	        "Twitter Pageload without Image"),
	
	/** The sent reply text. */
	SENT_REPLY_TEXT("//p[contains(text(),'%s')]//parent::div[@class='comment-item']","The Reply Send Text"),
	
	/** The facebook field continue button. */
	FACEBOOK_FIELD_CONTINUE_BUTTON(By.xpath("//input[@value='Continue']"),"The facebook continue Button"),
	
	/** The facebook post description pageload. */
	FACEBOOK_POST_DESCRIPTION_PAGELOAD(By.xpath("//*[@class='a8c37x1j ms05siws l3qrxjdp b7h9ocf4']"),"Facebook pageload"),
	
	/**  Location selector. */ 
	LOCATION_SELECTOR(By.xpath("//section//*[text()='Location Selector']//parent::div//span[@class='lcs-name']") , "Location selector validation"), 

	/**  Creator page. */ 
	CREATOR_DATA(By.xpath("//div[contains(@class,'hubuser-createpost')]") , "Creator page"), 

	/**  Creator page right side data. */ 
	CREATOR_RIGHT_SIDE_DATA(By.xpath("//div[@class='createpost-right-section-new-section']") , "Creator page Right side data"), 

	/**  Commented Posts. */ 
	COMMENTED_POSTS(By.xpath("//span[@class='count-red']//span[@class='cr-txt']") , "Commented posts are displayed"), 

	/**  Success Message Pop up. */ 
	SUCCESS_MESSAGE(By.xpath("//span[@class='success-mess-txt' and text()='You have no posts with unseen engagement during this period.']"), "Engagement status filter"), 

	/**  Facebook icon. */ 
	FACEBOOK_ICON(By.xpath("//img[@src='https://stage-cdn.rallio.com/img/activate-v3/fb-lv.svg']"), "Facebook icon"), 
	 
	/**  All option in engagement status. */ 
	ALL(By.xpath("//input[@name='posts-Engagement Status' and @value='all']"), "All filter in Post Engagement status"), 

	/**  Location selector. */ 
	LOCATION_SELECTOR1(By.xpath("//div[@class='locAction']//div[@class='la-sel-action']") , "Location selector"), 

	/**  Location search option. */ 
	LOCATION_SEARCH(By.xpath("//input[@type='text' and @name='Locations']") , "Location selector Search option"), 

	/**  Location selector - selecting Hub option. */ 
	HUB_SELECTOR(By.xpath("//span[@class='lca-head' and text()='Hubs']") , "Clicking hub selector"), 

	/**  Location selector - Location list option. */ 
	LOCATION_LIST_SELECTOR(By.xpath("//div[@class='card-header']//span[@class='lca-head' and text()='Location Lists']") , "Clicking Location list selector"), 
	
	/**  Location selector - Locations selecting option. */ 
	LOCATIONS_SELECTOR(By.xpath("//div[@class='card-header']//span[@class='lca-head' and text()='Locations']") , "Clicking Locations option in location selector"), 

	/**  Selecting Hub result in Location selector. */ 
	HUB_RESULT_SELECTOR(By.xpath("//span[@class='lcs-name' and text()='Bean Me Up EC_1']") , "Clicking hub result selector"), 

	/**  All Locations in Location selector. */ 
	ALL_LOCATION_OPTION(By.xpath("//div[@class='all-locs']//label[@class='cur-pointer r-flx r-flx-ac']") , "Clicking All location option"), 

	/**  Location selector - close option. */ 
	LOCATION_SELECTOR_CLOSE_OPTION(By.xpath("//div[@class='modal-content']//img[@alt='close']") , "Location selector close option"), 

	/**  Location selector - cancel option. */ 
	LOCATION_SELECTOR_CANCEL_OPTION(By.xpath("//div[@class='modal-content']//button[@class='ac-btn ac-secondary-white ac-outline ac-block' and text()='Cancel']") , "Location selector cancel option"), 
	
	/**   selecting Location list result in location selector. */ 
	LOCATION_LIST_RESULT_SELECTOR(By.xpath("//span[@class='lcs-name' and text()='AutomationList']") , "Clicking Location list result selector"), 

	/**  Selecting location result in location selector. */ 
	LOCATIONS_RESULT_SELECTOR(By.xpath("//span[@class='lcs-name' and text()='Bean Me Up - Automation Location two']") , "Clicking Locations result selector"), 

	/**  Hub content data in list view. */ 
	HUB_CONTENT(By.xpath("//div[@class='liv-right list-item']//div[@class='lvt-details']//h3[text()='Bean Me Up L8 ']") , "Hub content data"), 

	/** The location selector open tab. */
	LOCATION_SELECTOR_OPEN(By.xpath("//div[@class='asm-btn']//parent::div[@class='modal-footer']//preceding-sibling::div[@class='asm-accord']"), "Location Selecter Open."),

	/** The location selector hub tab open. */
	LOCATION_SELECTOR_HUB_TAB_OPEN(By.xpath("//img[contains(@src,'hubs')]//ancestor::div[contains(@class,'collapse show')]"), "Location Selecter Hub Tab Open."),

	/** The location selector locationlist tab. */
	LOCATION_SELECTOR_LOCATIONLIST_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Location Lists']"), "Location Selecter Location List tab."),

	/** The location selector location tab open. */
	LOCATION_SELECTOR_LOCATION_TAB_OPEN(By.xpath("//img[contains(@src,'location')]//ancestor::div[contains(@class,'collapse show')]"), "Location Selecter Location Tab Open"),

	/**  Location list - Location - 1 data. */ 
	LOCATION_LIST_CONTENT1(By.xpath("//div[@class='liv-right list-item']//div[@class='lvt-details']//h3[text()='EC_1 Test Location ']") , "Location list content data"), 

	/**  Location list - Location - 2 data. */ 
	LOCATION_LIST_CONTENT2(By.xpath("//div[@class='liv-right list-item']//div[@class='lvt-details']//h3[text()='Bean Me Up LA Test. ']") , "Location list content data"), 

	/**  Location data. */ 
	LOCATIONS_CONTENT(By.xpath("//div[@class='liv-right list-item']//div[@class='lvt-details']//h3[text()='Automation Location two ']") , "Locations content data"), 

	/** The facebook page email field. */
	FACEBOOK_PAGE_EMAIL_FIELD(By.xpath("//label//input[@name='email']"),"The Facebook Eamil field"),
	
	/** The facebook page password field. */
	FACEBOOK_PAGE_PASSWORD_FIELD(By.xpath("//input[@name='pass']"),"The Facebook password field"),
	
	/** The facebook page content. */
	FACEBOOK_PAGE_CONTENT(By.xpath("//html[@id='facebook']//div[@dir='auto']//div//div//div"),"Facebook Page Content"),
	
	/** The facebook page login field. */
	FACEBOOK_PAGE_LOGIN_FIELD(By.xpath("(//span[text()='Log In'])[2]"),"The Facebook login field"),
	
	/** The facebook postimage describtion. */
	FACEBOOK_POSTIMAGE_DESCRIBTION(By.xpath("//html[@id='facebook']//div[@data-testid='post_message']//p"),"The Facebook Page Post Message"),
	
	/** The facebook postvideo describtion. */
	FACEBOOK_POSTVIDEO_DESCRIBTION(By.xpath("//html[@id='facebook']//div[@dir='auto']"),"Facebook Post Describton"),
	
	/** The month dropdown. */
	MONTH_DROPDOWN(By.xpath("//select[@class='react-datepicker__month-select']"), "Month drop down"),

	/** The year dropdown. */
	YEAR_DROPDOWN(By.xpath("//select[@class='react-datepicker__year-select']"), "Year drop down."),
	
	/** The double digit calendar day. */
	DOUBLE_DIGIT_CALENDAR_DAY("(//div[contains(@class,'react-datepicker') and text()='%s'])[last()]", "Day of the Month"),

	/** The single digit calendar day. */
	SINGLE_DIGIT_CALENDAR_DAY("(//div[contains(@class,'react-datepicker')  and text()='%s'])[1]", "Day of the Month"),
	
	/** The day of the month. */
	DAY_OF_THE_MONTH("//div[contains(@class,'react-datepicker') and text()='%s']", "Day of the Month"),

	
	/** The engagement only unreadtext. */
	ENGAGEMENT_ONLY_UNREADTEXT(By.xpath("//div[@class='form-group']//span[text()='Unread']"),"Only unread text"),
   
	/** The engagement all text. */
	ENGAGEMENT_ALL_TEXT(By.xpath("//input[@name='engagement-Engagement Type']//parent::label[@class='active']//span[text()='All']"),"all text in Enagement"),
	
	/** The date picker. */
    DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]","Date Picker"),
    
    NO_POST_WITH_UNSEEN_ENGAGEMENT(By.xpath("//span[text()='You have no posts with unseen engagement during this period.']"),"No Post With Unseen Engagement"),
    
    /** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),
    
    CONTENTS_LOADING_SYMBOL("//div[@class='loader']//span[@class='info-state']","Contents Loading Symbol"),
	
	/**  Engagement status. */ 
	ENGAGEMENT_STATUS(By.xpath("//section[contains(@class,'filter')]//div[contains(@class,'filter-item')]//h3[text()='Engagement Status']"), "Engagement status filter");

	// /** The post contents. */
	// POST_CONTENTS(By.xpath("//div[@class='grid-masonry']//div[contains(@class,'gm-item')]//span[contains(text(),'RT
	// ')]"), "Post contents"),
	//
	// /** The inbox list content. */
	// INBOX_LIST_CONTENT("//div[contains(@class,'gm-item')]//div[@class='gm-content']//*[contains(text(),'%s')]",
	// "Inbox list content"),
	//
	// /** The post data. */
	// POST_DATA(By.xpath("//div[contains(@class,'gm-item')]//div[@class='gm-content']//span//span//span//span"),
	// "Post data"),
	//
	// /** The post view comments. */
	// POST_VIEW_COMMENTS_BUTTON("//p[contains(text(),'%s')]//ancestor::div[contains(@class,'gm-item')]//div[@class='vc-itxt']//span[1]",
	// "Post view comments"),
	//
	// /** The post view comments count. */
	// POST_VIEW_COMMENTS_COUNT("//p[contains(text(),'%s')]//ancestor::div[contains(@class,'gm-item')]//div[@class='vc-itxt']//span[2]",
	// "Post view comments count"),
	//
	// /** The post reply button. */
	// POST_REPLY_BUTTON("//span[text()='%s']//ancestor::div[contains(@class,'gm-item')]//img[@alt='Reply']//parent::button",
	// "Post reply button"),
	//
	// /** The post like button. */
	// POST_LIKE_BUTTON("//span[text()='%s']//ancestor::div[contains(@class,'gm-item')]//img[@alt='Like']//parent::button",
	// "Post like button"),
	//
	// /** The post link button. */
	// POST_LINK_BUTTON("//span[text()='%s']//ancestor::div[contains(@class,'gm-item')]//img[@alt='Link']//parent::button",
	// "Post link button"),
	//
	// /** The post not liked. */
	// POST_NOT_LIKED("//span[text()='%s']//ancestor::div[contains(@class,'gm-item')]//img[contains(@src,'like-blue.svg')]",
	// "Post not liked"),
	//
	// /** The post liked. */
	// POST_LIKED("//span[text()='%s']//ancestor::div[contains(@class,'gm-item')]//img[contains(@src,'like-blue-a.svg')]",
	// "Post liked"),
	//
	// /** The facebook. */
	// FACEBOOK(By.xpath("//div[contains(@class,'gm-item')]//div[contains(@class,'gmh-left')]//h3[text()='Facebook']"),"Facebook"),
	//
	// /** The facebook icon. */
	// FACEBOOK_ICON(By.xpath("//div[contains(@class,'gm-item')]//div[contains(@class,'gmh-left')]//img[contains(@src,'facebook.svg')]"),"Facebook
	// icon"),
	//
	// /** The facebook page name. */
	// FACEBOOK_PAGE_NAME(By.xpath("//div[contains(@class,'gmi-cnt')]//div[contains(@class,'gm-head')][1]//div//h3[text()]"),"Facebook
	// page name"),
	//
	// /** The facebook post location name. */
	// FACEBOOK_POST_LOCATION_NAME(By.xpath("//div[contains(@class,'gm-item')]//div[contains(@class,'gm-head')][2]//div//h3[text()]"),"Facebook
	// post location name"),
	//
	// /** Twitter post icon. */
	// TWITTER_POST_ICON(By.xpath("//div[@class='gm-item
	// gmi-text']//img[contains(@src,'twitter.svg')]//parent::div//following-sibling::div//h3[text()='Twitter']"),
	// "Twitter post icon"),
	//
	// /** Twitter post like button. */
	// TWITTER_POST_LIKE_BUTTON(By.xpath("//div[@class='gm-item
	// gmi-text']//button//img[contains(@src,'twtLike.svg')]"), "Twitter post
	// like button"),
	//
	// /** Twitter post Retweet button. */
	// TWITTER_POST_RETWEET_BUTTON(By.xpath("//div[@class='gm-item
	// gmi-text']//button//img[contains(@src,'retweet.svg')]"), "Twitter post
	// Retweet button"),
	//
	// /** Twitter post Retweeted. */
	// TWITTER_POST_RETWEETED(By.xpath("//div[@class='gm-item
	// gmi-text']//button//img[contains(@src,'retweet-a.svg')]"), "Twitter post
	// Retweeted"),
	//
	// /** OpenWebsite Twitter page. */
	// OPEN_WEBSITE_TWITTER_PAGE_NAVIGATION(By.xpath("//header[@role='banner']//h1[@role='heading']//a[@aria-label='Twitter']"),
	// "OpenWebsite Twitter page"),
	//
	// /** Instagram post icon. */
	// INSTAGRAM_POST_ICON(By.xpath("//div[@class='gm-item
	// gmi-text']//img[contains(@src,'instagram.svg')]//parent::div//following-sibling::div//h3[text()='Instagram']"),
	// "Instagram post icon"),
	//
	// /** Post page name. */
	// POST_PAGE_NAME(By.xpath("//div[@class='gm-item
	// gmi-text']//div[@class='gm-head'][1]//div//h3[text()]"), "Post page
	// name"),
	//
	// /** Post location name. */
	// POST_LOCATION_NAME(By.xpath("//div[@class='gm-item
	// gmi-text']//div[@class='gm-head'][2]//div//h3[text()]"), "Post location
	// name"),
	//
	// /** Post description. */
	// POST_DESCRIPTION(By.xpath("//div[@class='gm-item
	// gmi-text']//div[@class='gm-content']//span[@width]//span[not(@style)]//span[text()]"),
	// "Post description"),
	//
	// /** Post Open website. */
	// POST_OPEN_WEBSITE(By.xpath("//div[@class='gm-item
	// gmi-text']//button//img[contains(@src,'link.svg')]"), "Post Open
	// website"),
	//

	/** The by locator. */
	private By byLocator;

	/** The xpath. */
	private String xpath;

	/** The description. */
	private String description;

	/**
	 * Instantiates a new community tab inbox page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private CommunityTabInboxPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new community tab inbox page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private CommunityTabInboxPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return byLocator;
	}

	/**
	 * Gets the by xpath.
	 *
	 * @return the by xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}
}

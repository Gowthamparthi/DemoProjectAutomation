package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum CommunityTabSandboxPageEnum.
 */
public enum CommunityTabSandboxPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath(
	        "//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Sandbox']//ancestor::div//section[@class='item-g filter sandbox-filter']//preceding::div//section[@id='main-container-sec']//div[contains(@class,'cisWrap sanbxMain')]"),
	        "The page load"),

	/** The sandbox tab. */
	SANDBOX_TAB(By.xpath("//div[contains(@class,'ra-page')]//header[@class='header']//li[contains(@class,'ripple')]//span[text()='Sandbox']"), "Sandbox tab"),

	/** The sandbox page active. */
	SANDBOX_PAGE_ACTIVE(By.xpath("//div[contains(@class,'sub-nav-tabs')]//span[text()='Sandbox']//parent::li[@class='ripple active']"), "Sandbox page active"),

	/** The peers up to. */
	PEERS_UP_TO(By.xpath("//div[contains(@class,'location-peer-wrp')]//div[text()='What are your peers up to?']"), "What are your peers up to?"),

	/** The locations up to. */
	LOCATIONS_UP_TO(By.xpath("//div[contains(@class,'location-peer-wrp')]//div[text()='What are your locations up to?']"), "What are your locations up to?"),

	/** The sandbox contents. */
	SANDBOX_CONTENTS(By.xpath("//div[contains(@class,'infinite-scroll-component local-ini')]//div[contains(@class,'list-view')]//div[contains(@class,'list-item')]"),
	        "Sandbox contents"),

    // /** The sandbox list content. */
    // SANDBOX_LIST_CONTENT("//div[contains(@class,'gm-item')]//div[@class='gm-content']//span[contains(text(),'%s')]",
    // "Sandbox list content"),

    // /** The locations count. */
    // LOCATIONS_COUNT(By.xpath("//section[contains(@class,'stats')]//span[text()='Locations']//following-sibling::span"),"Locations
    // count"),

    // /** The filters close button. */
    // FILTERS_CLOSE_BUTTON(By.xpath("//div[contains(@class,'stats-assorted
    // ')]//button[@class='btnFilter fltrOpen fltrClose btn
    // btn-primary']"),"Filters close button"),

    // /** The filters open button. */
    // FILTERS_OPEN_BUTTON(By.xpath("//div[contains(@class,'stats-assorted
    // ')]//button[@class='btnFilter fltrOpen btn btn-primary']"),"Filters open
    // button"),

	/** The clear all filter. */
	CLEAR_ALL_FILTER(By.xpath("//div[@class='react-ripples ac-primary-box' and not(contains(@class,'pointer-events-none'))]//button//span[text()='Clear Filter']"), "Clear all filter"),

	/** The clear filter option. */
	CLEAR_FILTER_OPTION(By.xpath("//button//span[text()='Clear Filter']"), "Clear Filter option"),
	
	/** The top performing posts filter. */
	TOP_PERFORMING_POSTS_FILTER(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='filter-item']//label//span[text()='Top Performing Posts']"),
	        "Top performing posts filter"),

	/** The top performing filter selected. */
	TOP_PERFORMING_FILTER_SELECTED(
	        By.xpath("//section[contains(@class,'item-g filter')]//div[@class='filter-item']//span[text()='Top Performing Posts']//parent::label[@class='active']"),
	        "Top performing filter selected"),

	/** The all posts filter. */
	ALL_POSTS_FILTER(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='filter-item']//label//span[text()='All Posts']"), "All posts filter"),

	/** The all posts filter selected. */
	ALL_POSTS_FILTER_SELECTED(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='filter-item']//span[text()='All Posts']//parent::label[@class='active']"),
	        "All posts filter selected"),

	/** The month picker. */
	MONTH_PICKER(By.xpath("//select[@class='react-datepicker__month-select']"), "Month picker"),

	/** The from date. */
	FROM_DATE(By.xpath("//div[contains(@class,'dp-from')]//input[@placeholder='MM/DD/YYYY']"), "From date"),

	/** The from date active. */
	FROM_DATE_ACTIVE(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='dp-item date-end__wrp dp-from']"), "From date active"),

	/** The from date content. */
	FROM_DATE_CONTENT(By.xpath("//div[contains(@class,'dp-from')]//div[@class='react-datepicker__input-container']//input"), "From date content"),

	/** The select from date. */
	SELECT_FROM_DATE("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]", "Select from date"),

	/** The select from date with month. */
	SELECT_FROM_DATE_WITH_MONTH(
	        "//section[contains(@class,'filter')]//div[contains(@class,'dp-item dp-from')]//div[2]//div[@aria-disabled='false' and  contains(@aria-label,'%s')]",
	        "Select from date with month"),

	/** The from date previous month. */
	FROM_DATE_PREVIOUS_MONTH(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='react-datepicker']//button[@aria-label='Previous Month']"),
	        "From date previous month button"),

	/** The from date next month. */
	FROM_DATE_NEXT_MONTH(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='react-datepicker']//button[@aria-label='Next Month']"),
	        "From date next month button"),

	/** The post comment date time. */
	POST_COMMENT_DATE_TIME(By.xpath("//div[@class='lvt-brief']//following-sibling::span[@class='lvt-txt']"),
	        "Post comment date and time"),
	
	/** The select date from calendar. */
	SELECT_DATE_FROM_CALENDAR(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week']//div[@aria-disabled='false']"), "Select date from calendar"),

	/** The calendar displayed. */
	CALENDAR_DISPLAYED(By.xpath("//div[@class='react-datepicker__month']"), "Calendar displayed"),

	/** The select last date. */
	SELECT_LAST_DATE(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week'][3]//div[@aria-disabled='false'][last()]"), "Select last date"),

	/** The to date. */
	TO_DATE(By.xpath("//div[contains(@class,'dp-to')]//input[@placeholder='Most Recent']"), "To date"),

	/** The to date active. */
	TO_DATE_ACTIVE(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='dp-item dp-to active']"), "To date active"),

	/** The to date content. */
	TO_DATE_CONTENT(By.xpath("//div[contains(@class,'dp-to')]//div[@class='react-datepicker__input-container']//input"), "To date content"),

	/** The to date content from calendar. */
	TO_DATE_CONTENT_FROM_CALENDAR(By.xpath("//section[contains(@class,'filter')]//div[contains(@class,'dp-item dp-to')]//div[contains(@class,'today react-datepicker')]"), "To date content from calendar"),
	
	/** The to date previous month. */
	TO_DATE_PREVIOUS_MONTH(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='react-datepicker']//button[@aria-label='Previous Month']"),
	        "To date previous month button"),

	/** The to date next month. */
	TO_DATE_NEXT_MONTH(By.xpath("//button[contains(@class,'datepicker__navigation--next')]"), "To date next month button"),

	/** The select to date. */
	SELECT_TO_DATE("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]", "Select to date"),

	/** The select to date with month. */
	SELECT_TO_DATE_WITH_MONTH("//section[contains(@class,'filter')]//div[contains(@class,'dp-item date-end__wrp dp-to')]//div[2]//div[@aria-disabled='false' and  contains(@aria-label,'%s')]",
	        "Select to date with month"),

	
	/** The platform filter. */
	PLATFORM_FILTER(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='filter-item']//h3[text()='Platform']"), "Platform filter"),

	/** The all filter button. */
	ALL_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'all-platform.svg')]//parent::button"),
	        "All filter button"),

	/** The all filter selected. */
	ALL_FILTER_SELECTED(
	        By.xpath(
	                "//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'all-platform.svg')]//parent::button[contains(@class,'active')]"),
	        "All filter selected"),

	/** The facebook filter button. */
	FACEBOOK_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'fb-platform')]//parent::button"),
	        "Facebook filter button"),

	/** The facebook filter selected. */
	FACEBOOK_FILTER_SELECTED(
	        By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'fb-platform')]//parent::button[contains(@class,'active')]"),
	        "Facebook filter selected"),

	/** The twitter filter button. */
	TWITTER_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'twitter-platform')]//parent::button"),
	        "Twitter filter button"),

	/** The twitter filter selected. */
	TWITTER_FILTER_SELECTED(
	        By.xpath(
	                "//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'twitter-platform')]//parent::button[contains(@class,'active')]"),
	        "Twitter filter selected"),

	/** The linkedin filter button. */
	LINKEDIN_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'linkedin-platform')]//parent::button"),
	        "LinkedIn filter button"),

	/** The linkedin filter selected. */
	LINKEDIN_FILTER_SELECTED(By
	        .xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'linkedin-platform')]//parent::button[contains(@class,'active')]"),
	        "LinkedIn filter selected"),

	/** The instagram filter button. */
	INSTAGRAM_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'instagram-platform')]//parent::button"),
	        "Instagram filter button"),

	/** The instagram filter selected. */
	INSTAGRAM_FILTER_SELECTED(By.xpath(
	        "//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'instagram-platform')]//parent::button[contains(@class,'active')]"),
	        "Instagram filter selected"),

	/** The engagement all filter. */
	ENGAGEMENT_ALL_FILTER(By.xpath("//section[contains(@class,'item-g filter')]//h3[text()='Engagement']//parent::div[@class='filter-item']//span[text()='All']"),
	        "Engegement all filter"),

	/** The engagement all filter selected. */
	ENGAGEMENT_ALL_FILTER_SELECTED(
	        By.xpath("//section[contains(@class,'item-g filter')]//h3[text()='Engagement']//parent::div[@class='filter-item']//span[text()='All']//parent::label[@class='active']"),
	        "Engegement all filter selected"),

	/** The like filter. */
	LIKE_FILTER(By.xpath("//section[contains(@class,'item-g filter')]//h3[text()='Engagement']//parent::div[@class='filter-item']//span[text()='Like / Favorite']"), "Like filter"),

	/** The like filter active. */
	LIKE_FILTER_ACTIVE(By.xpath(
	        "//section[contains(@class,'item-g filter')]//h3[text()='Engagement']//parent::div[@class='filter-item']//span[text()='Like / Favorite']//parent::label[@class='active']"),
	        "Like filter active"),

	/** The comment filter. */
	COMMENT_FILTER(By.xpath("//section[contains(@class,'item-g filter')]//h3[text()='Engagement']//parent::div[@class='filter-item']//span[text()='Comment / Reply']"),
	        "Comment filter"),

	/** The comment filter active. */
	COMMENT_FILTER_ACTIVE(By.xpath(
	        "//section[contains(@class,'item-g filter')]//h3[text()='Engagement']//parent::div[@class='filter-item']//span[text()='Comment / Reply']//parent::label[@class='active']"),
	        "Comment filter active"),

	/** The post filter. */
	POST_FILTER(By.xpath("//section[contains(@class,'item-g filter')]//h3[text()='Engagement']//parent::div[@class='filter-item']//span[text()='Post']"), "Post filter"),

	/** The post filter active. */
	POST_FILTER_ACTIVE(
	        By.xpath(
	                "//section[contains(@class,'item-g filter')]//h3[text()='Engagement']//parent::div[@class='filter-item']//span[text()='Post']//parent::label[@class='active']"),
	        "Post filter active"),

	/** The message filter. */
	MESSAGE_FILTER(By.xpath("//section[contains(@class,'item-g filter')]//h3[text()='Engagement']//parent::div[@class='filter-item']//span[text()='Message']"), "Message filter"),

	/** The message filter active. */
	MESSAGE_FILTER_ACTIVE(By.xpath(
	        "//section[contains(@class,'item-g filter')]//h3[text()='Engagement']//parent::div[@class='filter-item']//span[text()='Message']//parent::label[@class='active']"),
	        "Message filter active"),

    // /** The select from platform filter. */
    // SELECT_FROM_PLATFORM_FILTER("//div[@class='form-group
    // fg-dropdown']//select[not(@name='All Locations')]//option[text()='%s']",
    // "Select from platform filter"),

	/** The peers filter. */
	PEERS_FILTER(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='filter-item fltr-drp']//h3[text()='Peers']"), "Peers filter"),

	/** The peers filter dropdown. */
	PEERS_FILTER_DROPDOWN(By.xpath("//section[contains(@class,'item-g filter')]//h3[text()='Peers']//parent::div//div//button"), "Peers filter dropdown"),

	/** The peers filter current location. */
	PEERS_FILTER_CURRENT_LOCATION(By.xpath("//section[contains(@class,'item-g filter')]//h3[text()='Peers']//parent::div//div//button//span"), "Peers filter current location"),

	/** The select from peers filter. */
	SELECT_FROM_PEERS_FILTER("//div[@id='locations-dropdown-sandbox']//div[contains(@class,'rs-drp__menu-list')]//div[contains(text(),'%s')]", "Select from peers filter"),

    // /** The peers filter list. */
    // PEERS_FILTER_LIST(By.xpath("//h3[text()='Peers']//parent::div//following-sibling::div//select//option[not(text()='All
    // Locations')]"),"Peers filter list"),

	/** The peers filter searchbox. */
	PEERS_FILTER_SEARCHBOX(By.xpath("//div[contains(@class,'rs-drp__value-container')]//input"), "peers filter search box"),

    // /** The search box. */
    // SEARCH_BOX(By.xpath("//div[@class='react-tags__search-input']//input"),
    // "Search box"),
    //
    // /** The search result. */
    // SEARCH_RESULT("//div[contains(@class,'gm-item')]//div[@class='gm-content']//span[contains(text(),'%s')]","Search
    // result"),

	/** The locations filter. */
	LOCATIONS_FILTER(By.xpath("//h3[text()='Location Selector']//parent::div[contains(@class,'filter-item')]"), "Locations filter"),

	/** The location dropdown. */
	LOCATION_DROPDOWN(By.xpath("//section[contains(@class,'item-g filter')]//h3[text()='Location Selector']//parent::div//div//span"), "Location dropdown"),

	/** The current location. */
	CURRENT_LOCATION(By.xpath("//section[contains(@class,'item-g filter')]//h3[text()='Location Selector']//parent::div//div//span"), "Current location"),

	/** The location dropdown searchtab. */
	LOCATION_DROPDOWN_SEARCHTAB(By.xpath("//div[@id='account-switcher-dropdown']//div//div"), "Search tab of locatio selection"),

	/** The locations filter modal. */
	LOCATIONS_FILTER_MODAL(By.xpath("//div[@class='modal-content']//div[@class='modal-body']"), "Locations filter modal"),

	/** The locations dropdown button. */
	LOCATIONS_DROPDOWN_BUTTON(By.xpath("//div[@class='accordion-item']//span[text()='Locations']"), "Locations dropdown button"),

	/** The locations list. */
	LOCATIONS_LIST(By.xpath("//div[text()='Locations']//ancestor::div[contains(@class,'card')]//div[contains(@class,'collapse show')]"), "Locations list"),

	/** The location. */
	LOCATION(By.xpath("//ul[@class='hub-list']//li//span[text()='Testing Location']"), "Location"),

	/** The prod location. */
	PROD_LOCATION(By.xpath("//ul[@class='hub-list']//li//span[text()='Alex Kiss - 148 - Sylvania, OH']"), "Prod location"),

	/** The cancel button. */
	CANCEL_BUTTON(By.xpath("//div[contains(@class,'modal-footer')]//button[text()='Cancel']"), "Cancel button"),

	/** The ok button. */
	OK_BUTTON(By.xpath("//div[contains(@class,'modal-footer')]//button[text()='Ok']"), "Ok button"),

	/** The engagement filter. */
	ENGAGEMENT_FILTER(By.xpath("//section[contains(@class,'filter')]//div[@class='filter-item']//h3[text()='Engagement']"), "Engagement filter"),

	/** The total stats count. */
	TOTAL_STATS_COUNT(By.xpath("//div[contains(@class,'total-count')]//span[text()='TOTALS']//parent::div//span[@class='mod-count']//div"), "Total stats count"),

	/** The facebook stats count. */
	FACEBOOK_STATS_COUNT(By.xpath("//div[contains(@class,'fb-sc')]//img[@alt='Facebook']//parent::div//preceding-sibling::div//span[2]//div"), "Facebook stats count"),

	/** The twitter stats count. */
	X_FORMATED_TWITTER_STATS_COUNT(By.xpath("//div[contains(@class,'ttr-sc')]//span[text()='X']//following::span[text()='(Formerly Twitter)']//following::span[1][@class='platform-count']//div"), "Twitter stats count"),

	/** The instagram stats count. */
	INSTAGRAM_STATS_COUNT(By.xpath("//div[contains(@class,'insta-sc')]//img[@alt='Instagram']//parent::div//preceding-sibling::div//span[2]//div"), "Instagram stats count"),

	/** The linkedin stats count. */
	LINKEDIN_STATS_COUNT(By.xpath("//div[contains(@class,'lkdin-sc')]//img[@alt='LinkedIn']//parent::div//preceding-sibling::div//span[2]//div"), "LinkedIn stats count"),

	/** The facebook stats highlighted. */
	FACEBOOK_STATS_HIGHLIGHTED(By.xpath("//div[contains(@class,'fb-sc') and contains(@class,'active')]"), "Facebook stats highlighted"),

	/** The twitter stats highlighted. */
	TWITTER_STATS_HIGHLIGHTED(By.xpath("//div[contains(@class,'ttr-sc') and contains(@class,'active')]"), "Twitter stats highlighted"),

	/** The instagram stats highlighted. */
	INSTAGRAM_STATS_HIGHLIGHTED(By.xpath("//div[contains(@class,'insta-sc') and contains(@class,'active')]"), "Instagram stats highlighted"),

	/** The linkedin stats highlighted. */
	LINKEDIN_STATS_HIGHLIGHTED(By.xpath("//div[contains(@class,'lkdin-sc') and contains(@class,'active')]"), "Linkedin stats highlighted"),

	/** The create post button. */
	CREATE_POST_BUTTON(By.xpath("//div[contains(@class,'stats community-stat')]//span[text()='CREATE POST']"), "Create post button"),

	/** The content list. */
	CONTENT_LIST("//div[@class='list-view']//div[@class='list-item  gmi-text']//div[@class='li-base']//span//span//span//span[contains(text(),'%s')]", "Sandbox contents list"),

	/** The footer. */
	FOOTER(By.xpath("//div[contains(@class,'list-view')]//div[contains(@class,'list-item')][last()]"), "Footer"),

	/** The no data to show. */
	NO_DATA_TO_SHOW(By.xpath("//div[@class='content-g']//div[@class='no-data']//span[text()='No data to show']"), "No data to show"),

	/** The facebook contents. */
	FACEBOOK_CONTENTS(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset platform-icon']//img[contains(@src,'fb-lv.svg')]"),
	        "Facebook contents"),

	/** The twitter contents. */
	TWITTER_CONTENTS(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset platform-icon']//img[contains(@src,'twitter-lv.svg')]"),
	        "Twitter contents"),

	/** The linked in contents. */
	LINKED_IN_CONTENTS(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset platform-icon']//img[contains(@src,'linkedin-lv.svg')]"),
	        "Linked In contents"),

	/** The instagram contents. */
	INSTAGRAM_CONTENTS(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset platform-icon']//img[contains(@src,'instagram-lv.svg')]"),
	        "Instagram contents"),

	/** The post location. */
	POST_LOCATION(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//h3"), "Post location"),

    // /** The bala location. */
    // BALA_LOCATION(By.xpath("//div[@class='masonry-grid']//div[contains(@class,'gm-item')]//div[@class='gm-head']//h3[text()='Bala
    // Location ']"),"Bala location"),

	/** The bean me up la test. */
	BEAN_ME_UP_LA_TEST(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//h3[contains(text(),'Bean Me Up LA Test ')]"),
	        "Bean me up la test"),

	/** The pushpa location. */
	PUSHPA_LOCATION(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//h3[text()='Pushpa Location ']"), "Pushpa location"),

    // /** The social test location. */
    // SOCIAL_TEST_LOCATION(By.xpath("//div[@class='masonry-grid']//div[contains(@class,'gm-item')]//div[@class='gm-head']//h3[text()='Social
    // Test Location ']"),"Social test location"),
    //
    // /** The bean me up l8. */
    // BEAN_ME_UP_L8(By.xpath("//div[@class='masonry-grid']//div[contains(@class,'gm-item')]//div[@class='gm-head']//h3[text()='Bean
    // Me Up L8 ']"),"Bean Me Up L8"),
    //
	/** The ec 1 test location. */
	EC_1_TEST_LOCATION(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//h3[text()='EC_1 Test Location ']"), "EC1 test location"),

	/** The automation location one. */
	AUTOMATION_LOCATION_ONE(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//h3[contains(text(),'Automation Location one ')]"),
	        "Automation location one"),

	/** The test location one. */
	TEST_LOCATION_ONE(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//h3[contains(text(),'Test location 1  ')]"),
	        "Test location one"),

	/** The bean me up l11. */
	BEAN_ME_UP_L11(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//h3[contains(text(),'Bean Me Up L11 ')]"), "Bean me up L11"),

	/** The bean me up l2. */
	BEAN_ME_UP_L2(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//h3[contains(text(),'Bean Me Up L2 ')]"), "Bean me up L2"),

    // /** The bean me up l4. */
    // BEAN_ME_UP_L4(By.xpath("//div[@class='masonry-grid']//div[contains(@class,'gm-item')]//div[@class='gm-head']//h3[text()='Bean
    // Me Up L4 ']"),"Bean me up L4"),
    //
    // /** The bean me up l5. */
    // BEAN_ME_UP_L5(By.xpath("//div[@class='masonry-grid']//div[contains(@class,'gm-item')]//div[@class='gm-head']//h3[text()='Bean
    // Me Up L5 ']"),"Bean me up L5"),

	/** The social media icon. */
	POST_SOCIAL_MEDIA_ICON(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset platform-icon']//img",
	        "Post social media icon"),

	/** The social media icon. */
	SOCIAL_MEDIA_ICON(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset platform-icon']//img"), "Social media icon"),

	/** The post profile icon. */
	POST_PROFILE_ICON(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset brand-icon']//img",
	        "Post profile icon"),

	/** The profile icon. */
	PROFILE_ICON(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset brand-icon']//img"), "Profile icon"),

	/** The location name. */
	POST_LOCATION_NAME("//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//h3",
	        "Post location name"),

	/** The location name. */
	LOCATION_NAME(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//h3"), "Location name"),

	/** The posted using facebook icon. */
	POSTED_USING_FACEBOOK_ICON(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//div//img[contains(@src,'fb-lv.svg')]",
	        "Posted using facebook icon"),

	/** The posted from facebook. */
	POSTED_FROM_FACEBOOK(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//div//img[contains(@src,'fb-lv.svg')]"),
	        "Posted from facebook"),

	/** The posted using facebook hover text. */
	POSTED_USING_FACEBOOK_HOVER_TEXT(By.xpath("//div[@class='rc-tooltip-content']//div//div//span[text()='This content was posted from Facebook']"),
	        "Posted using facebook hover text"),

	/** The posted using twitter icon. */
	POSTED_USING_TWITTER_ICON(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//div//img[contains(@src,'twitter-lv.svg')]",
	        "Posted using twitter icon"),

	/** The posted from twitter. */
	POSTED_FROM_TWITTER(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//div//img[contains(@src,'twitter-lv.svg')]"),
	        "Posted from twitter"),

	/** The posted using twitter hover text. */
	POSTED_USING_TWITTER_HOVER_TEXT(By.xpath("//div[@class='rc-tooltip-content']//div//div//span[text()='This content was posted from Twitter']"),
	        "Posted using twitter hover text"),

	/** The posted using instagram icon. */
	POSTED_USING_INSTAGRAM_ICON(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//div//img[contains(@src,'instagram-lv.svg')]",
	        "Posted using instagram icon"),

	/** The posted from instagram. */
	POSTED_FROM_INSTAGRAM(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//div//img[contains(@src,'instagram-lv.svg')]"),
	        "Posted from instagram"),

	/** The posted using instagram hover text. */
	POSTED_USING_INSTAGRAM_HOVER_TEXT(By.xpath("//div[@class='rc-tooltip-content']//div//div//span[text()='This content was posted from Instagram']"),
	        "Posted using Instagram hover text"),

	/** The posted using linkedin icon. */
	POSTED_USING_LINKEDIN_ICON(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//div//img[contains(@src,'linkedin-lv.svg')]",
	        "Posted using LinkedIn icon"),

	/** The posted from linkedin. */
	POSTED_FROM_LINKEDIN(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//div//img[contains(@src,'linkedin-lv.svg')]"),
	        "Posted from linkedIn"),

	/** The posted using rallio logo. */
	POSTED_USING_RALLIO_LOGO(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//div//img[contains(@src,'logo.svg')]",
	        "Posted using Rallio logo"),

	/** The posted from rallio. */
	POSTED_FROM_RALLIO(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//div//img[contains(@src,'logo.svg')]"), "Posted from rallio"),

	/** The posted using rallio hover text. */
	POSTED_USING_RALLIO_HOVER_TEXT(By.xpath("//div[@class='rc-tooltip-content']//div//div//span[text()='This content was posted from the Rallio Platform']"),
	        "Posted using Rallio hover text"),

	/** The posted date time. */
	POSTED_DATE_TIME(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//div//span[@class='lvt-txt'][2]",
	        "Posted date time"),

	/** The date time. */
	DATE_TIME(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//div//span[@class='lvt-txt'][2]"), "Date time"),

	/** The three dots button. */
	THREE_DOTS_BUTTON(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='drop-items dropdown']//button",
	        "Three dots button"),

	/** The three dots. */
	THREE_DOTS(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='drop-items dropdown']//button"), "Three dots"),

	/** The link button. */
	LINK_BUTTON(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='drop-items show dropdown']//a//span[text()='Link to Post']"), "link button"),
	
	/** The more option. */
	MORE_OPTION(By.xpath("//button[@id='dropitems-more-options']//div[@class='more-dots-horizontal']//img[@alt='More']"), "The Post Content More Option"),

	/** The delete button. */
	DELETE_BUTTON(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='drop-items show dropdown']//a//span[text()='Delete']"), "Delete button"),

	/** The delete alert delete button. */
	DELETE_ALERT_DELETE_BUTTON(By.xpath("//div[text()='Are you sure you want to delete this post?']//ancestor::div[@class='modal-content']//button[text()='Delete']"),
	        "Delete alert delete button"),

	/** The delete alert cancel button. */
	DELETE_ALERT_CANCEL_BUTTON(By.xpath("//div[text()='Are you sure you want to delete this post?']//ancestor::div[@class='modal-content']//button[text()='Cancel']"),
	        "Delete alert cancel button"),

	/** The post text content. */
	POST_TEXT_CONTENT(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-base']//p"), "Post text content"),

	/** The post image content. */
	POST_IMAGE_CONTENT(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lv-assets']//li[2]//div[@class='gma-item']//img"), "Post image content"),

    // /** The reply button. */
    // REPLY_BUTTON(By.xpath("//div[contains(@class,'gm-item')]//div[contains(@class,'gm-head')]//img[@alt='Reply']//parent::button"),"Reply
    // button"),
    //
    // /** The replied. */
    // REPLIED(By.xpath("//div[contains(@class,'gm-item')]//div[contains(@class,'gm-head')]//img[contains(@src,'reply-blue-a.svg')]"),"Replied"),

	/** The like button. */
	POST_LIKE_BUTTON("//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//span[text()='Like']", "Post like button"),

	/** The like button. */
	LIKE_BUTTON(By.xpath("//div[@class='li-base']//div[@class='vc-item']//span[text()='Like']"), "Like button"),

	/** The reuse button. */
	POST_REUSE_BUTTON("//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//span[text()='Reuse']", "Post reuse button"),

	/** The reuse button. */
	REUSE_BUTTON(By.xpath("//div[@class='li-base']//div[@class='vc-item']//span[text()='Reuse']"), "Reuse button"),

	/** The write a comment. */
	WRITE_A_COMMENT(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lv-comment']//div[contains(@id,'placeholder-editor-sandbox-comment')]"), " Write a comment"),

	/** The write a comment text. */
	WRITE_A_COMMENT_TEXT(By.xpath("//div[contains(@class,'list-item')]//ancestor::div//div[@class='public-DraftStyleDefault-block public-DraftStyleDefault-ltr']"),"Write the comment"),
	
	/** The post comment button. */
	POST_COMMENT_BUTTON(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lv-comment']//button[text()='Post Comment']"), "Post comment button"),

	/** The facebook post not liked. */
	FACEBOOK_POST_NOT_LIKED("//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'fb-like.svg')]",
	        "Facebook post not liked"),

	/** The fb post not liked. */
	FB_POST_NOT_LIKED(By.xpath("//div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'fb-like.svg')]"), "FB post not liked"),

	/** The facebook post liked. */
	FACEBOOK_POST_LIKED("//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'fb-like-a.svg')]",
	        "Facebook post liked"),

	/** The fb post liked. */
	FB_POST_LIKED(By.xpath("//div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'fb-like-a.svg')]"), "FB post liked"),

	/** The facebook post like count. */
	FACEBOOK_POST_LIKE_COUNT(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Reactions']//preceding-sibling::span",
	        "Facebook post like count"),

	/** The fb post like count. */
	FB_POST_LIKE_COUNT(By.xpath("//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Reactions']//preceding-sibling::span"), "FB post like count"),

	/** The facebook post share count. */
	FACEBOOK_POST_SHARE_COUNT(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Shares']//preceding-sibling::span",
	        "Facebook post share count"),

	/** The fb post share count. */
	FB_POST_SHARE_COUNT(By.xpath("//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Shares']//preceding-sibling::span"), "FB post share count"),

	/** The facebook post comments count. */
	FACEBOOK_POST_COMMENTS_COUNT(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Comments']//preceding-sibling::span",
	        "Facebook post comments count"),

	/** The fb post comments count. */
	FB_POST_COMMENTS_COUNT(By.xpath("//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Comments']//preceding-sibling::span"),
	        "FB post comments count"),

	/** The facebook post clicks count. */
	FACEBOOK_POST_CLICKS_COUNT(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Clicks']//preceding-sibling::span",
	        "facebook post clicks count"),

	/** The fb post clicks count. */
	FB_POST_CLICKS_COUNT(By.xpath("//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Clicks']//preceding-sibling::span"), "FB post clicks count"),

	FB_POST_CLICKS_FIELD("//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='%s']//preceding-sibling::span", "FB post clicks field"),

	/** The twitter post not liked. */
	TWITTER_POST_NOT_LIKED
			(By.xpath("//div[@class='list-item']//div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'twitter-like.svg')]"),
	        "Twitter post not liked"),
	
	/** The twitter post liked. */
	TWITTER_POST_LIKED(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'twitter-like-a.svg') and @alt='Like']"),
	        "Twitter post liked"),
	
	/** The reply sent message. */
	REPLY_SENT_MESSAGE(By.xpath("//span[contains(text(),'Reply sent!')]"), "Reply sent message"),

	/** The twitter post like count. */
	TWITTER_POST_LIKE_COUNT(
	        By.xpath("//div[@class='list-item']//ancestor::div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Favorites']//preceding-sibling::span"),
	        "Twitter post like count"),

	/** The twitter post retweet count. */
	TWITTER_POST_RETWEET_COUNT(
	        By.xpath("//div[@class='list-item']//ancestor::div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Retweets']//preceding-sibling::span"),
	        "Twitter retweet count"),

    // /** The twitter post search result. */
    // TWITTER_POST_SEARCH_RESULT("//div[contains(@class,'gm-item')]//div[@class='gm-content']//span//span//span//span[contains(text(),'%s')]","Twitter
    // post search result"),

    // /** The like button hover text. */
    // LIKE_BUTTON_HOVER_TEXT(By.xpath("//div[@class='rc-tooltip-content']//span[text()='Like']"),"Like
    // hover text"),
    //
    // /** The link button hover text. */
    // LINK_BUTTON_HOVER_TEXT(By.xpath("//div[@class='rc-tooltip-content']//span[text()='Open
    // Website']"),"Link hover text"),
    //
    // /** The reply button hover text. */
    // REPLY_BUTTON_HOVER_TEXT(By.xpath("//div[@class='rc-tooltip-content']//span[text()='Reply']"),"Reply
    // button hover text"),

	/** The instagram post like count. */
	INSTAGRAM_POST_LIKE_COUNT(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Likes']//preceding-sibling::span",
	        "Instagram post like count"),

	/** The instagram like count. */
	INSTAGRAM_LIKE_COUNT(By.xpath("//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Likes']//preceding-sibling::span"), "Instagram like count"),

	/** The instagram post comments count. */
	INSTAGRAM_POST_COMMENTS_COUNT(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Comments']//preceding-sibling::span",
	        "Instagram post comments count"),

	/** The instagram comments count. */
	INSTAGRAM_COMMENTS_COUNT(By.xpath("//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Comments']//preceding-sibling::span"),
	        "Instagram comments count"),

	/** The linkedin post like count. */
	LINKEDIN_POST_LIKE_COUNT(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Likes']//preceding-sibling::span",
	        "LinkedIn post like count"),

	/** The li post like count. */
	LI_POST_LIKE_COUNT(By.xpath("//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Likes']//preceding-sibling::span"), "LI post like count"),

	/** The linkedin post comment count. */
	LINKEDIN_POST_COMMENT_COUNT(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Comments']//preceding-sibling::span",
	        "LinkedIn post comment count"),

	/** The li post comment count. */
	LI_POST_COMMENT_COUNT(By.xpath("//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Comments']//preceding-sibling::span"),
	        "LI post comment count"),

	/** The linkedin post not liked. */
	LINKEDIN_POST_NOT_LIKED(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'linkedin-like.svg')]",
	        "LinkedIn post not liked"),

	/** The li post not liked. */
	LI_POST_NOT_LIKED(By.xpath("//div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'linkedin-like.svg')]"), "LI post not liked"),

	/** The linkedin post liked. */
	LINKEDIN_POST_LIKED(
	        "//div[@class='sm-content']//span[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'linkedin-like-a.svg')]",
	        "LinkedIn post liked"),

	/** The li post liked. */
	LI_POST_LIKED(By.xpath("//div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'linkedin-like-a.svg')]"), "LI post liked"),

	/** The facebook post zero likes. */
	FACEBOOK_POST_ZERO_LIKE(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Reactions']//preceding-sibling::span[text()='0']"),
	        "Facebook post zero like"),

	/** The facebook post zero share. */
	FACEBOOK_POST_ZERO_SHARE(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Shares']//preceding-sibling::span[text()='0']"),
	        "Facebook post zero share"),

	/** The facebook post zero comment. */
	FACEBOOK_POST_ZERO_COMMENT(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Comments']//preceding-sibling::span[text()='0']"),
	        "Facebook post zero comment"),

	/** The facebook post zero click. */
	FACEBOOK_POST_ZERO_CLICK(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Clicks']//preceding-sibling::span[text()='0']"),
	        "Facebook post zero click"),

	/** The twitter post zero likes. */
	TWITTER_POST_ZERO_LIKE(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Favorites']//preceding-sibling::span[text()='0']"),
	        "Twitter post zero likes"),

	/** The twitter post zero retweet. */
	TWITTER_POST_ZERO_RETWEET(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Retweets']//preceding-sibling::span[text()='0']"),
	        "Twitter post zero retweet"),

	/** The linkedin post zero like. */
	LINKEDIN_POST_ZERO_LIKE(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Likes']//preceding-sibling::span[text()='0']"),
	        "LinkedIn post zero like"),

	/** The linkedin post zero comment. */
	LINKEDIN_POST_ZERO_COMMENT(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Comments']//preceding-sibling::span[text()='0']"),
	        "LonkedIn post zero comment"),

	/** The instagram post zero like. */
	INSTAGRAM_POST_ZERO_LIKE(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Likes']//preceding-sibling::span[text()='0']"),
	        "Instagram post zero like"),

	/** The instagram post zero comment. */
	INSTAGRAM_POST_ZERO_COMMENT(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Comments']//preceding-sibling::span[text()='0']"),
	        "Instagram post zero comment"),

	/** The facebook post non zero like. */
	FACEBOOK_POST_NON_ZERO_LIKE(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Reactions']//preceding-sibling::span[not(contains(text(),'0'))]"),
	        "Facebook post non zero like"),

	/** The facebook post nonzero share. */
	FACEBOOK_POST_NON_ZERO_SHARE(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Shares']//preceding-sibling::span[not(contains(text(),'0'))]"),
	        "facebook post non zero share"),

	/** The facebook post nonzro comment. */
	FACEBOOK_POST_NON_ZERO_COMMENT(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Comments']//preceding-sibling::span[not(contains(text(),'0'))]"),
	        "Facebook post non zero comment"),

	/** The facebookpost nonzero click. */
	FACEBOOK_POST_NON_ZERO_CLICK(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Clicks']//preceding-sibling::span[not(contains(text(),'0'))]"),
	        "facebook post non zero click"),

	/** The twitter post nonzero like. */
	TWITTER_POST_NON_ZERO_LIKE(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Favorites']//preceding-sibling::span[not(contains(text(),'0'))]"),
	        "Twitter post non zero like"),

	/** The twitter post nonzero retweet. */
	TWITTER_POST_NON_ZERO_RETWEET(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Retweets']//preceding-sibling::span[not(contains(text(),'0'))]"),
	        "Twitter post non zero retweet"),

	/** The linkedin post nonzero like. */
	LINKEDIN_POST_NON_ZERO_LIKE(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Likes']//preceding-sibling::span[not(contains(text(),'0'))]"),
	        "Linkedin post non zero like"),

	/** The linkedin post nonzero comment. */
	LINKEDIN_POST_NON_ZERO_COMMENT(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Comments']//preceding-sibling::span[not(contains(text(),'0'))]"),
	        "LinkedIn post non zero comment"),

	LINKEDIN_DETAILVIEW_POST_REPLY_TEXT("//*[contains(@class,'comment flex grow-1 items-stretch')]//div[contains(@class,'attributed-text-segment-list__container')]//p[contains(text(),'%s')]","Linkedin Detailview Post Reply Text"),

	LINKEDIN_REPLY_BUTTON(By.xpath("//span[contains(text(),'Reply')]"),"Linkedin Reply Button"),
	/** The instagram post nonzero like. */
	INSTAGRAM_POST_NON_ZERO_LIKE(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Likes']//preceding-sibling::span[not(contains(text(),'0'))]"),
	        "Instagram post non zero like"),

	/** The instagram post nonzero comment. */
	INSTAGRAM_POST_NON_ZERO_COMMENT(By.xpath(
	        "//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lvc']//div[@class='lvci-cnt']//span[text()='Comments']//preceding-sibling::span[not(contains(text(),'0'))]"),
	        "Instagram post non zero comment"),
	
	/** The location selector button. */
	LOCATION_SELECTOR_BUTTON(By.xpath("//h3[text()='Location Selector']//following-sibling::div[@class='locAction']//span"), "Location selector button"),

	/** The location selector view. */
	LOCATION_SELECTOR_VIEW(By.xpath("//div[@class='modal-body']//h3[text()='Location Selector']//parent::div//parent::div//div[@class='asm-accord']"), "Location selector view"),

	/** The hubs dropdown. */
	HUBS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='accordion']//span[@class='lca-head' and text()='Hubs']"), "Hubs dropdown"),

	/** The location lists dropdown. */
	LOCATION_LISTS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='accordion']//span[@class='lca-head' and text()='Location Lists']"),
	        "LocationLists dropdown"),

	/** The locations dropdown. */
	LOCATIONS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='accordion']//span[@class='lca-head' and text()='Locations']"), "Locations dropdown"),

	/** The location selector dropdown list. */
	LOCATION_SELECTOR_DROPDOWN_LIST(By.xpath("//div[@class='modal-body']//div[@class='open card-header']//parent::div[@class='accordion-item']//following-sibling::div//ul[@class='hub-list']"),
	        "Location selector dropdown list"),

	/** The location selector search. */
	LOCATION_SELECTOR_SEARCH(By.xpath("//h3[text()='Location Selector']//following-sibling::div//input[@name='Locations']"), "Location selector search"),

	/** The select dropdown list. */
	SELECT_DROPDOWN_LIST("//div[@class='modal-body']//div[@class='open card-header']//parent::div[@class='accordion-item']//following-sibling::div//ul//li//span[contains(text(),'%s')]",
	        "Select dropdown list"),

	/** The selected dropdown list. */
	SELECTED_DROPDOWN_LIST(
	        "//div[@class='modal-body']//div[@class='open card-header']//parent::div[@class='accordion-item']//following-sibling::div//ul//li//input[@checked]//following-sibling::div//span[contains(text(),'%s')]",
	        "Selected dropdown list"),

	/** The location selector cancel button. */
	LOCATION_SELECTOR_CANCEL_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Cancel']"), "Location selector cancel button"),

	/** The location selector ok button. */
	LOCATION_SELECTOR_OK_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Ok']"), "Location selector ok button"),

	/** The sortby dropdowns. */
	SORTBY_DROPDOWNS(
	        By.xpath("//div[text()='Sort by']//parent::div//parent::div//div[@class='sortby-list__wrp']//div[@class='ds-dropdown']//following-sibling::div[@class='ds-dropdown']"),
	        "Sortby dropdowns"),
	
	/** The retweet count. */
	RETWEET_COUNT(By.xpath("//span[text()='Retweets']//parent::div//span[@class='lvc-count']"), "The Retweet Count "),

	/** The favourites count. */
	FAVOURITES_COUNT(By.xpath("//span[text()='Favorites']//parent::div//span[@class='lvc-count']"), "Favourite Count"),

	/** The profile icon hover tooltip. */
	PROFILE_ICON_HOVER_TOOLTIP(By.xpath("//div[@class='common-tooltip--wrp' and text()='This content was posted from Twitter']"),
	        "Twitter icon hover ,This content was posted from Twitter"),

	/** The rallio profile icon hover. */
	RALLIO_PROFILE_ICON_HOVER(By.xpath("//div[@class='common-tooltip--wrp' and text()='This content was posted from the Rallio Platform']"),"The Rallio profile icon hover in tooltip"),
	
	/** The twitter icon hover. */
	TWITTER_ICON_HOVER(By.xpath("//div[contains(@class,'list-item')]//div[@class='lvt-brief']//span//following-sibling::img[@class='pu-asset lvtb-icon']"), "The Profile Icon Hover Tool Tip"),
	
	/** The reply sent popup. */
	REPLY_SENT_POPUP(By.xpath("//div//span[text()='Reply sent!']"), "The Reply sent Popup"),
	
	/** The facebook pageload. */
	FACEBOOK_PAGELOAD_WITHOUTIMAGE(By.xpath("//u[text()='Facebook']//parent::i[@class='fb_logo img sp_Awgqz7K4lHq sx_55d19b']//ancestor::div//div[@id='contentCol']"), "The Facebook Pageload without Pageload"),
	
	/** The facebook pageload withimage. */
	FACEBOOK_PAGELOAD_WITHIMAGE("//div[@role='complementary']//ancestor::div[@class='du4w35lb l9j0dhe7 cbu4d94t j83agx80']//div[@class='a8nywdso j7796vcc rz4wbd8a l29c1vbm']//span[contains(text(),'%s')]","The facebook load with image"),
	
	/** The what are your peers upto. */
	WHAT_ARE_YOUR_PEERS_UPTO(By.xpath("//div[@class='location-peer-wrp sandboxlist-wrp']//div[text()='What are your peers up to?']"), "What are your peers upto"),
	
	/** The sandbox post by content. */
	SANDBOX_POST_BY_CONTENT(By.xpath("//div[contains(@class,'list-item')]//div[@class='sm-content']//span//span//span//span[text()='%s']"), "SandBox Post By Text"),
	
	/**  Creator page. */ 
	CREATOR_DATA(By.xpath("//div[contains(@class,'hubuser-createpost')]") , "Creator page"), 

	/**  Creator page right side data. */ 
	CREATOR_RIGHT_SIDE_DATA(By.xpath("//div[@class='createpost-right-section-new-section']") , "Creator page Right side data"), 

	/**  Commented Posts. */ 
	COMMENTED_POSTS(By.xpath("//span[@class='count-red']//span[@class='cr-txt']") , "Commented posts are displayed"), 

	/**  Success Message Pop up. */ 
	SUCCESS_MESSAGE(By.xpath("//span[@class='success-mess-txt' and text()='You have no posts with unseen engagement during this period.']"), "Engagement status filter"), 

	/**  Facebook icon. */ 
	FACEBOOK_ICON(By.xpath("//img[@src='https://stage-cdn.rallio.com/img/activate-v3/fb-lv.svg']"), "Facebook icon"), 
	
	/**  Twitter symbol. */ 
	TWITTER_ICON(By.xpath("//div[@class='list-view san-list-view__main sbMain']//div[@class='li-top']//div[@class='round-asset platform-icon']//img[contains(@src,'twitter-lv.svg')]") , "Twitter symbol"), 
	
	/**  Twitter profile image. */ 
	TWITTER_PROFILE_IMAGE(By.xpath("//div[@class='list-item']//div[@class='li-top']//div[@class='round-asset brand-icon']//img[@alt='sandbox Asset Item']") , "Twitter Profile image"), 
	
	/**  Twitter posted using text. */ 
	TWITTER_POSTED_TEXT(By.xpath("//div[@class='lvt-brief']//span[@class='lvt-txt' and text()='Posted using:']") , "Twitter Posted using text: "), 
	
	/**  Posted using twitter icon. */ 
	POSTED_USING_TWITTER_SYMBOL(By.xpath("//div[@class='lvt-brief']//img[@src='https://stage-cdn.rallio.com/img/activate-v3/twitter-lv.svg']") , "Posted using twitter icon"), 
	
	/**  Twitter Like icon. */ 
	TWITTER_LIKE_ICON(By.xpath("//div[@class='li-base']//div[@class='vc-item']//img[@src='https://stage-cdn.rallio.com/img/activate-v3/twitter-like.svg']//following-sibling::span[@class='vc-txt' and text()='Like']") , "Twitter like icon"), 
	
	/**  Asset Validation. */ 
	ASSET_VALIDATION(By.xpath("//div[@class='lv-assets']//div[@class='carousel-root']") , "Asset validation"), 
	
	/**  Delete success message. */ 
	DELETE_SUCCESS_MESSAGE(By.xpath("//div[@class='Toastify__toast-container Toastify__toast-container--top-center']//span[@class='success-mess-txt' and text()='Done!']") , "Asset validation"),
	
	/**  Engagement status. */ 
	ENGAGEMENT_STATUS(By.xpath("//section[contains(@class,'filter')]//div[contains(@class,'filter-item')]//h3[text()='Engagement Status']"), "Engagement status filter"),
	
	/** The post description text area. */
	POST_DESCRIPTION(By.xpath("//div[contains(@class,'list-item')]//div[@class='sm-content']//span//span//span//span"), "Post Description textarea"),
	
	/** The text area from twitter page */
	TWITTER_POST_DESCRIPTION(By.xpath("//div[@class='css-1dbjc4n r-16y2uox r-1wbh5a2 r-1ny4l3l']//div[@class='css-1dbjc4n']//div[@data-testid='tweetText']//span"), "Post description from twitter page"),
	
	/** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),
	
	/** The month dropdown. */
	MONTH_DROPDOWN(By.xpath("//select[@class='react-datepicker__month-select']"), "Month drop down"),

	/** The year dropdown. */
	YEAR_DROPDOWN(By.xpath("//select[@class='react-datepicker__year-select']"), "Year drop down."),

	/** The location selector. */
	LOCATION_SELECTOR(By.xpath("//section//*[text()='Location Selector']//parent::div//span[@class='lcs-name']"), "Location Selecter."),

	/** The location selector search tab. */
	LOCATION_SELECTOR_SEARCH_TAB(By.xpath("//div[@class='asm-lf']//input[@placeholder = 'Search']"), "Location Selecter Search Tab"),

	/** The location selector locationlist tab. */
	LOCATION_SELECTOR_LOCATIONLIST_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Location Lists']"), "Location Selecter Location List tab."),

	/** The location selector location tab open. */
	LOCATION_SELECTOR_LOCATION_TAB_OPEN(By.xpath("//img[contains(@src,'location')]//ancestor::div[contains(@class,'collapse show')]"), "Location Selecter Location Tab Open"),

	/** The locator selector name. */
	LOCATOR_SELECTOR_NAME("//span[@class='lcs-name' and @title='%s']","The Location selector Name"),
	
	/** The location selector location tab. */
	LOCATION_SELECTOR_ALL_LOCATION_TAB(By.xpath("//input[@name='selectedLocation']//following-sibling::span[text()='All Locations']"), "The All Locations selector tab."),

	/** The location selector close button. */
	LOCATION_SELECTOR_CLOSE_BUTTON(By.xpath("//img[@class='close-icon']"), "Location Selector Close Button"),

	/** The location selector open tab. */
	LOCATION_SELECTOR_OPEN(By.xpath("//div[@class='asm-btn']//parent::div[@class='modal-footer']//preceding-sibling::div[@class='asm-accord']"), "Location Selecter Open."),

	LIST_OF_LOCATIONS(By.xpath(
			"//div[contains(@class,'collapse show')]//img[contains(@src,'location') and not(contains(@src,'Lists'))]"),
			"List of Locations"),
	
	/** The location selector byname. */
	LOCATION_SELECTOR_BYNAME("//div[contains(@class,'list-item')]//div[@class='lvt-details']//h3[contains(text(),'%s')]","The Location Selector By name"),
	
	/** The location selector hub tab. */
	LOCATION_SELECTOR_HUB_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Hubs']"), "Location Selecter Hub tab."),

	/** The location selector hub tab open. */
	LOCATION_SELECTOR_HUB_TAB_OPEN(By.xpath("//img[contains(@src,'hubs')]//ancestor::div[contains(@class,'collapse show')]"), "Location Selecter Hub Tab Open."),

	/** The location selector dropdown user. */
	LOCATION_SELECTOR_DROPDOWN_USER("//div//ul[@class='hub-list']//span[contains(text(),\"%s\")]", "Location Selecter Dropdown User"),
	
	LOCATION_SELECTOR_LOCATION_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Locations']"),
			"Location Selecter Location tab."),

	LINKEDIN_POST_LIKE_ICON_IS_ACTIVE("//*[contains(@class,'comment flex grow-1 items-stretch')]//div[contains(@class,'attributed-text-segment-list__container')]//p[contains(text(),'%s')]//preceding::div//img[@data-reaction-type='LIKE']","Linkedin post like icon is active"),

	FACEBOOK_POST_LIKE_ICON_IS_ACTIVE("//div[text()='%s']//preceding::div//img[@role='presentation']","Facebook post like icon is active"),

	/** The locations selector count. */
	LOCATIONS_SELECTOR_COUNT(By.xpath("//div[@class='locAction']//span[@class='lca-sel-label bl-count']"),"The Location selector Count");
	

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new community tab sandbox page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private CommunityTabSandboxPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new community tab sandbox page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private CommunityTabSandboxPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

public enum RevvTabSettingsOptInPageEnum {

    PAGE_LOAD_OPT_IN(By.xpath("//div[contains(@class,'sub-nav-tabs')]//span[text()='Settings']//parent::li[contains(@class,'active')]//following::div[@class='mobile-active active nav-item' and text()='Opt-in']//ancestor::div//div[contains(@class,'non-psp-settings__container')]"),"PAGE_LOAD"),

    CUSTOMER_OPT_IN_YES_BUTTON(By.xpath("//div[text()='Customer Opt-In']//parent::div//following-sibling::div//div[text()='Require customers to opt in first']//parent::div//div//label[text()='Yes']//preceding-sibling::input"),"CUSTOMER_OPT_IN_YES_BUTTON"),

    CUSTOMER_OPT_IN_NO_BUTTON(By.xpath("//div[text()='Customer Opt-In']//parent::div//following-sibling::div//div[text()='Require customers to opt in first']//parent::div//div//label[text()='No']//preceding-sibling::input"),"CUSTOMER_OPT_IN_NO_BUTTON"),

    CUSTOMER_OPT_IN_NOTE_TEXT_OPT_IN_LAW_OPTION(By.xpath("//div[text()='Customer Opt-In']//parent::div//following-sibling::div//div[@class='settings-note__mark' and text()=' Unless your customers have previously gone through an opt-in process with their mobile device for this particular list, providing an opt-in message is required by law. See for more details:']"),"CUSTOMER_OPT_IN_NOTE_TEXT"),

    CUSTOMER_OPT_IN_NOTE_OPT_IN_LAW_OPTION(By.xpath("//div[text()='Customer Opt-In']//parent::div//following-sibling::div//div[@class='settings-note__mark']//a[text()='Opt in Laws']"),"CUSTOMER_OPT_IN_NOTE_OPT_IN_LAW_OPTION"),

    EDIT_SMS_OPT_INS_DESCRIPTION(By.xpath("//div[text()='Edit Sms Opt-Ins']//parent::div//following-sibling::div//p[text()='Edit the original opt-in text message a customer receives.']//parent::div//p[text()='For messaging law & best practices, review this document:']"),"EDIT_SMS_OPT_INS_DESCRIPTION"),

    EDIT_SMS_OPT_INS_SMS_GUIDLINES_OPTION(By.xpath("//div[text()='Edit Sms Opt-Ins']//parent::div//following-sibling::div//p//a[text()='SMS Guidelines']"),"EDIT_SMS_OPT_INS_SMS_GUIDLINES_OPTION"),

    EDIT_SMS_OPT_INS_TEXT_AREA(By.xpath("//div[text()='Edit Sms Opt-Ins']//parent::div//following-sibling::div//textarea"),"EDIT_SMS_OPT_INS_TEXT_AREA"),

    EDIT_SMS_OPT_INS_NOTE_SECTION(By.xpath("//div[text()='Edit Sms Opt-Ins']//parent::div//following-sibling::div//p[text()='Edit the original opt-in text message a customer receives.']//parent::div//p[text()='For messaging law & best practices, review this document:']"),"EDIT_SMS_OPT_INS_NOTE_SECTION"),

	SEND_SERVERY_BUTTON(By.xpath("//span[text()='Send Survey']"),"send servery button"),

	NOTE_SECTION_BUSINESS_NAME(By.xpath("//div[text()='Edit Sms Opt-Ins']//ancestor::div[contains(@class,'settings__card')]//div[@class='note-mark__title']//b[text()='@' and text()='businessname']//parent::div[contains(text(),\"will insert your business name into the text (required).\")]"),"@businessname will insert your business name into the text (required)."),

	NOTE_SECTION_LOCATION_NAME(By.xpath("//div[text()='Edit Sms Opt-Ins']//ancestor::div[contains(@class,'settings__card')]//div[@class='note-mark__title']//b[text()='@' and text()='locationname']//parent::div[contains(text(),\"will insert your location name into the text.\")]"),"@locationname will insert your location name into the text."),

	NOTE_SECTION_EMPLOYEE_FIRST_NAME(By.xpath("//div[text()='Edit Sms Opt-Ins']//ancestor::div[contains(@class,'settings__card')]//div[@class='note-mark__title']//b[text()='@' and text()='employeefirstname']//parent::div[contains(text(),\"will insert the employee's first name into the text.\")]"),"@employeefirstname will insert the employee's first name into the text."),

	NOTE_SECTION_EMPLOYEE_LAST_NAME(By.xpath("//div[text()='Edit Sms Opt-Ins']//ancestor::div[contains(@class,'settings__card')]//div[@class='note-mark__title']//b[text()='@' and text()='employeelastname']//parent::div[contains(text(),\"will insert the employee's last name into the text.\")]"),"@employeelastname will insert the employee's last name into the text."),

	NOTE_SECTION_CUSTOMER_FIRST_NAME(By.xpath("//div[text()='Edit Sms Opt-Ins']//ancestor::div[contains(@class,'settings__card')]//div[@class='note-mark__title']//b[text()='@' and text()='customerfirstname']//parent::div[contains(text(),\"will insert the customer's first name into the text.\")]"),"@customerfirstname will insert the customer's first name into the text."),

	NOTE_SECTION_CUSTOMER_LAST_NAME(By.xpath("//div[text()='Edit Sms Opt-Ins']//ancestor::div[contains(@class,'settings__card')]//div[@class='note-mark__title']//b[text()='@' and text()='customerlastname']//parent::div[contains(text(),\"will insert the customer's last name into the text.\")]"),"@customerlastname will insert the customer's last name into the text."),

	NOTE_SECTION_MSG_DATA_RATES_TEXT(By.xpath("//div[text()='Edit Sms Opt-Ins']//parent::div//following-sibling::div//strong[text()='Note:']//following::p[contains(text(),\"Msg & Data rates may apply. Reply HELP for help, STOP to cancel\")]"),"\"Msg & Data rates may apply. Reply HELP for help, STOP to cancel\" will be added to the end of the text."),

	NOTE_SECTION_LEAVE_BLANK_TEXT(By.xpath("//div[text()='Edit Sms Opt-Ins']//parent::div//following-sibling::div//strong[text()='Note:']//following::p[contains(text(),\"Leave blank for default message.\")]"),"Leave blank for default message."),

	EDIT_SMS_OPT_INS_PREVIEW_BUTTON(By.xpath("//div[text()='Edit Sms Opt-Ins']//parent::div//following-sibling::div//button[text()='Preview']"),"EDIT_SMS_OPT_INS_PREVIEW_BUTTON");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a RevvTabSettingsOptInPageEnum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private RevvTabSettingsOptInPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a RevvTabSettingsOptInPageEnum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private RevvTabSettingsOptInPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
	
	
	
	
	
}

package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum DirectoryListingsPageEnum.
 */
public enum DirectoryListingsProfilePageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Profile']//ancestor::div//section[contains(@class,'item-g notification-cnt dl-filter-notify')]//preceding::div//section[@id='main-container-sec']//div[@class='content-g']//div[contains(@class,'dl-container dl-container__main dir-list-main')]"),
	        "Page load"),

	/** The bussiness details button. */
	BUSSINESS_DETAILS_BUTTON(By.xpath("//div[contains(@class,'stepper-holder')]//h5[text()='Business Details']"),
	        "Bussiness details button"),

	/** The bussiness details active. */
	BUSSINESS_DETAILS_ACTIVE(
	        By.xpath("//div[contains(@class,'stepper-holder')]//h5[text()='Business Details']//parent::div[contains(@class,'step active')]"),
	        "Bussiness details active"),

	/** The store info. */
	STORE_INFO(By.xpath("//div[contains(@class,'dl-business-details')]//div[@class='content-left-section']//h3[text()='Store Info']"), "Store info"),

	/** The listing name. */
	LISTING_NAME(By.xpath("//div[contains(@class,'dl-business-details')]//div[contains(@class,'content-right-section')]//span[text()='Listing Name']//parent::div//input"),
	        "Listing name"),

	/** The store code. */
	STORE_CODE(By.xpath("//div[contains(@class,'dl-business-details')]//div[contains(@class,'content-right-section')]//span[text()='Store Code']//parent::div//input"),
	        "Store code"),

	/** The year of incorporation. */
	YEAR_OF_INCORPORATION(
	        By.xpath("//div[contains(@class,'dl-business-details')]//div[contains(@class,'content-right-section')]//span[text()='Year of Incorporation']//parent::div//input"),
	        "Year of incorporation"),

	/** The description. */
	DESCRIPTION(By.xpath("//div[contains(@class,'dl-business-details')]//div[contains(@class,'content-right-section')]//span//parent::div//textarea[text()]"), "Description box"),

	/** The address. */
	ADDRESS(By.xpath("//div[contains(@class,'dl-business-details')]//div[@class='content-left-section']//h3[text()='Address']"), "Address"),

	/** The address textbox. */
	ADDRESS_TEXTBOX(By.xpath("//div[contains(@class,'address')]//div[contains(@class,'content-right-section')]//span[text()='Address']//parent::div//input[@type='text']"),
	        "address textbox"),

	/** The hide my address. */
	HIDE_MY_ADDRESS(By.xpath("//div[contains(@class,'address')]//div[contains(@class,'content-right-section')]//span[text()=' Hide my address?']"), "Hide my address"),

	/** The hide my address. */
	HIDE_MY_ADDRESS_CHECKBOX(By.xpath("//div[contains(@class,'address')]//div[contains(@class,'content-right-section')]//span[text()=' Hide my address?']//parent::div//input"),
	        "Hide my address"),

	/** The city. */
	CITY(By.xpath("//div[contains(@class,'address')]//div[contains(@class,'content-right-section')]//span[text()='City']//parent::div//input"), "City textbox"),

	/** The state province. */
	STATE_PROVINCE(By.xpath("//div[contains(@class,'address')]//div[contains(@class,'content-right-section')]//span[text()='State/Province']//parent::div//input"),
	        "State/Province"),

	/** The zip code. */
	ZIP_CODE(By.xpath("//div[contains(@class,'address')]//div[contains(@class,'content-right-section')]//span[text()='Zip / Postal Code']//parent::div//input"), "Zip code"),

	/** The country. */
	COUNTRY_DROPDOWN_BUTTON(
	        By.xpath(
	                "//div[contains(@class,'address')]//div[contains(@class,'content-right-section')]//span[text()='Country']//parent::div//div[contains(@id,'country-dropdown')]"),
	        "Country"),

	LATITUDE_TEXTBOX(By.xpath("//div[contains(@class,'form-group form-field-item')]//input[@name='latitude']"),"Latitude TextBox"),

	LOGITUDE_TEXTBOX(By.xpath("//div[contains(@class,'form-group form-field-item')]//input[@name='longitude']"),"Longitude TextBox"),

	/** The argentina. */
	ARGENTINA(By.xpath("//div[contains(@class,'address')]//div[contains(@id,'country-dropdown')]//div[contains(@class,'menu-list')]//div[text()='Argentina']"), "Argentina"),

	/** The australia. */
	AUSTRALIA(By.xpath("//div[contains(@class,'address')]//div[contains(@id,'country-dropdown')]//div[contains(@class,'menu-list')]//div[text()='Australia']"), "Australia"),

	/** The aruba. */
	ARUBA(By.xpath("//div[contains(@class,'address')]//div[contains(@id,'country-dropdown')]//div[contains(@class,'menu-list')]//div[text()='Aruba']"), "Aruba"),

	/** The belgium. */
	BELGIUM(By.xpath("//div[contains(@class,'address')]//div[contains(@id,'country-dropdown')]//div[contains(@class,'menu-list')]//div[text()='Belgium']"), "Belgium"),

	/** The brazil. */
	BRAZIL(By.xpath("//div[contains(@class,'address')]//div[contains(@id,'country-dropdown')]//div[contains(@class,'menu-list')]//div[text()='Brazil']"), "Brazil"),

	/** The canada. */
	CANADA(By.xpath("//div[contains(@class,'address')]//div[contains(@id,'country-dropdown')]//div[contains(@class,'menu-list')]//div[text()='Canada']"), "Canada"),

	/** The uk. */
	UK(By.xpath("//div[contains(@class,'address')]//div[contains(@id,'country-dropdown')]//div[contains(@class,'menu-list')]//div[text()='United Kingdom']"), "UK"),

	/** The india. */
	INDIA(By.xpath("//div[contains(@class,'address')]//div[contains(@id,'country-dropdown')]//div[contains(@class,'menu-list')]//div[text()='India']"), "India"),

	/** The selected country. */
	SELECTED_COUNTRY(By.xpath("//div[contains(@class,'address')]//div[contains(@id,'country-dropdown')]//div//div//div"), "Selected country"),

	/** The phone number. */
	PHONE_NUMBER(By.xpath("//div[contains(@class,'address')]//div[contains(@class,'content-right-section')]//span[text()='Phone Number']//parent::div//input"), "Phone number"),

	/** The latitude. */
	LATITUDE(By.xpath("//div[contains(@class,'address')]//div[contains(@class,'content-right-section')]//span[contains(text(),'Longitude ')]"), "Latitude"),

	/** The longitude. */
	LONGITUDE(By.xpath("//div[contains(@class,'address')]//div[contains(@class,'content-right-section')]//span[contains(text(),'Latitude ')]"), "Longitude"),

	/** The address cancel button. */
	ADDRESS_CANCEL_BUTTON(By.xpath("//div[contains(@class,'address-wrp')]//div[contains(@class,'content-right-section')]//parent::div//following-sibling::div//button[text()='Cancel']"), "Address cancel button"),

	/** The address publish button. */
	ADDRESS_PUBLISH_BUTTON(By.xpath("//div[contains(@class,'address-wrp')]//div[contains(@class,'content-right-section')]//parent::div//following-sibling::div//button[text()='Publish']"), "Address publish button"),

	/** The category. */
	CATEGORY(By.xpath("//div[contains(@class,'dl-business-details')]//div[@class='content-left-section']//h3[text()='Category']"), "Category"),

	/** The category dropdown. */
	CATEGORY_DROPDOWN(By
	        .xpath("//div[contains(@class,'category')]//div[contains(@class,'content-right-section')]//span[text()='Category']//parent::div//div[contains(@id,'category-select')]//div//div"),
	        "Category Dropdown"),

	RENDERSEO_CATEGORY_DROPDOWN(By.xpath("//div[contains(@class,'category')]//div[contains(@class,'content-right-section')]//div//div[@id='dl-store-details-category-select']"),"RENDERSEO CATEGORY DROPDOWN"),
	
	/** The category dropdown byname. */
	CATEGORY_DROPDOWN_BYNAME("//div[@class='cs-select__menu-list css-11unzgr']//div[text()='%s']", "Category Dropdown by Name"),

	/** The category dropdown name. */
	CATEGORY_DROPDOWN_NAME("//div[contains(@class,'cs-select__control')]//div[contains(@class,'cs-select__single-value') and text()='%s']", "Category Dropdown Name"),

	/** The category cancel button. */
	CATEGORY_CANCEL_BUTTON(By.xpath("//div[contains(@class,'category')]//div[contains(@class,'content-right-section')]//parent::div//following-sibling::div//button[text()='Cancel']"), "Category cancel button"),

	/** The category publish button. */
	CATEGORY_PUBLISH_BUTTON(By.xpath("//div[contains(@class,'category')]//div[contains(@class,'content-right-section')]//parent::div//following-sibling::div//button[text()='Publish']"),
	        "Category publish button"),

	/** The primary category. */
	PRIMARY_CATEGORY_DROPDOWN(By.xpath(
	        "//div[contains(@class,'category')]//div[contains(@class,'content-right-section')]//span[text()='Primary Category']//parent::div//div[contains(@id,'category-select')]"),
	        "Primary category dowpdown"),

	/** The airports. */
	PRIMARY_AIRPORTS(By.xpath("//div[contains(@class,'category')]//div[contains(@id,'category-select')]//div[contains(@class,'menu-list')]//div[text()='Airports']"), "Airports"),

	/** The doctors. */
	DOCTORS(By.xpath("//div[contains(@class,'category')]//div[contains(@id,'category-select')]//div[contains(@class,'menu-list')]//div[text()='Doctors']"), "Doctors"),

	/** The fertility. */
	FERTILITY(By.xpath("//div[contains(@class,'category')]//div[contains(@id,'category-select')]//div[contains(@class,'menu-list')]//div[text()='Fertility']"), "Fertility"),

	/** The bartenders. */
	BARTENDERS(By.xpath("//div[contains(@class,'category')]//div[contains(@id,'category-select')]//div[contains(@class,'menu-list')]//div[text()='Bartenders']"), "Bartenders"),

	/** The boating. */
	BOATING(By.xpath("//div[contains(@class,'category')]//div[contains(@id,'category-select')]//div[contains(@class,'menu-list')]//div[text()='Boating']"), "Boating"),

	/** The cafes. */
	CAFES(By.xpath("//div[contains(@class,'category')]//div[contains(@id,'category-select')]//div[contains(@class,'menu-list')]//div[text()='Cafes']"), "Cafes"),

	/** The guitar store. */
	GUITAR_STORE(By.xpath("//div[contains(@class,'category')]//div[contains(@id,'category-select')]//div[contains(@class,'menu-list')]//div[text()='Guitar Store']"),
	        "Guitar store"),

	/** The musicians. */
	MUSICIANS(By.xpath("//div[contains(@class,'category')]//div[contains(@id,'category-select')]//div[contains(@class,'menu-list')]//div[text()='Musicians']"), "Musicians"),

	/** The yoga. */
	YOGA(By.xpath("//div[contains(@class,'category')]//div[contains(@id,'category-select')]//div[contains(@class,'menu-list')]//div[text()='Yoga']"), "Yoga"),

	/** The zoos. */
	ZOOS(By.xpath("//div[contains(@class,'category')]//div[contains(@id,'category-select')]//div[contains(@class,'menu-list')]//div[text()='Zoos']"), "Zoos"),

	/** The primary category selected. */
	PRIMARY_CATEGORY_CONTENT(
	        By.xpath("//div[contains(@class,'category')]//span[text()='Primary Category']//preceding-sibling::div[contains(@id,'category-select')]//div//div//div[text()]"),
	        "Primary category content"),

	/** The category content. */
	CATEGORY_CONTENT(By.xpath("//div[contains(@class,'category')]//span[text()='Category']//preceding-sibling::div[contains(@id,'category-select')]//div//div//div[text()]"),
	        "Category content"),

	/** The additional categories. */
	ADDITIONAL_CATEGORIES_DROPDOWN(By.xpath("//div[contains(@class,'category')]//div[contains(@class,'desc-wrp')]//div[contains(@class,'search-wrapper')]//input"),
	        "Additional categories"),

	/** The acupuncture. */
	ACUPUNCTURE(By.xpath(
	        "//div[contains(@class,'category')]//div[contains(@class,'content-right-section')]//div[contains(@class,'custom-menu-container')]//ul//li[text()='Acupuncture']"),
	        "Acupunture"),

	/** The airports. */
	AIRPORTS(
	        By.xpath("//div[contains(@class,'category')]//div[contains(@class,'content-right-section')]//div[contains(@class,'custom-menu-container')]//ul//li[text()='Airports']"),
	        "Airport"),

	/** The antiques. */
	ANTIQUES(
	        By.xpath("//div[contains(@class,'category')]//div[contains(@class,'content-right-section')]//div[contains(@class,'custom-menu-container')]//ul//li[text()='Antiques']"),
	        "Antiques"),

	/** The burgers. */
	BURGERS(By.xpath("//div[contains(@class,'category')]//div[contains(@class,'content-right-section')]//div[contains(@class,'custom-menu-container')]//ul//li[text()='Burgers']"),
	        "Burgers"),

	/** The dentists. */
	DENTISTS(
	        By.xpath("//div[contains(@class,'category')]//div[contains(@class,'content-right-section')]//div[contains(@class,'custom-menu-container')]//ul//li[text()='Dentists']"),
	        "Dentists"),

	/** The selected additional category. */
	SELECTED_ADDITIONAL_CATEGORY(
	        By.xpath("//div[contains(@class,'category')]//div[contains(@class,'content-right-section')]//div[contains(@class,'search-wrapper')]//span[text()]"),
	        "Selected additional category"),

	/** The tagline. */
	TAGLINE(By.xpath("//div[contains(@class,'category')]//div[contains(@class,'desc-wrp')]//span[text()='Tagline']//parent::div//input"), "Tagline"),

	/** The payment methods. */
	PAYMENT_METHODS(By.xpath("//div[contains(@class,'dl-business-details')]//div[@class='content-left-section']//h3[text()='Payment Methods']"), "Payment methods"),

	/** The master card. */
	MASTER_CARD(By.xpath("//div[contains(@class,'payment')]//label[text()='Mastercard']//preceding-sibling::img[contains(@src,'master')]"), "Master card"),

	/** The master card checkbox. */
	MASTER_CARD_CHECKBOX(By.xpath("//div[contains(@class,'payment')]//label[text()='Mastercard']//parent::div//label[contains(@class,'checkbox')]//input"), "Mastercard checkbox"),

	/** The master card selected. */
	MASTER_CARD_SELECTED(
	        By.xpath("//div[contains(@class,'payment')]//label[text()='Mastercard']//ancestor::div[contains(@class,'payment-btn active')]//label[contains(@class,'checkbox')]//input"),
	        "Master card selected"),

	/** The visa card. */
	VISA_CARD(By.xpath("//div[contains(@class,'payment')]//label[text()='Visa']//preceding-sibling::img[contains(@src,'visa')]"), "Visa card"),

	/** The visa card checkbox. */
	VISA_CARD_CHECKBOX(By.xpath("//div[contains(@class,'payment')]//label[text()='Visa']//parent::div//label[contains(@class,'checkbox')]//input"), "Visa card checkbox"),

	/** The visa card selected. */
	VISA_CARD_SELECTED(By.xpath("//div[contains(@class,'payment')]//label[text()='Visa']//ancestor::div[contains(@class,'payment-btn active')]//label[contains(@class,'checkbox')]//input"),
	        "Visa card selected"),

	/** The amex card. */
	AMEX_CARD(By.xpath("//div[contains(@class,'payment')]//label[text()='Amex']//preceding-sibling::img[contains(@src,'amex')]"), "Amex card"),

	/** The amex card checkbox. */
	AMEX_CARD_CHECKBOX(By.xpath("//div[contains(@class,'payment')]//label[text()='Amex']//ancestor::div[@class='payment-btn cur-pointer']//label//input"), "Amex card checkbox"),

	/** The amex card selected. */
	AMEX_CARD_SELECTED(By.xpath("//div[contains(@class,'payment')]//label[text()='Amex']//ancestor::div[contains(@class,'payment-btn active')]//label//input"), "Amex card selected"),

	/** The cash. */
	CASH(By.xpath("//div[contains(@class,'payment')]//label[text()='Cash']//parent::div//img[contains(@src,'cash.svg')]"), "Cash"),

	/** The cash checkbox. */
	CASH_CHECKBOX(By.xpath("//div[contains(@class,'payment')]//label[text()='Cash']//parent::div//label[contains(@class,'checkbox')]"), "Cash checkbox"),

	/** The cash selected. */
	CASH_SELECTED(By.xpath("//div[contains(@class,'payment')]//label[text()='Cash']//ancestor::div[contains(@class,'payment-btn active')]//label[contains(@class,'checkbox')]"),
	        "Cash selected"),

	/** The cheque. */
	CHEQUE(By.xpath("//img[contains(@src,'cheque')]"), "Cheque"),

	/** The cheque checkbox. */
	CHEQUE_CHECKBOX(By.xpath("//div[contains(@class,'payment')]//label[text()='Crypto']//ancestor::div[@class='payment-btn cur-pointer']//label//input"), "Cheque checkbox"),

	/** The cheque selected. */
	CHEQUE_SELECTED(By.xpath("//div[contains(@class,'payment')]//label[text()='Cheque']//ancestor::div[contains(@class,'payment-btn active')]//label//input"), "Cheque selected"),

	/** The checks card. */
	CHECKS_CARD(By.xpath("//div[contains(@class,'payment')]//label[text()='Checks']//preceding-sibling::img[contains(@src,'amex')]"), "Amex card"),

	/** The checks card checkbox. */
	CHECKS_CARD_CHECKBOX(By.xpath("//div[contains(@class,'payment')]//label[text()='Checks']//ancestor::div[@class='payment-btn cur-pointer']//label//input"), "Checks card checkbox"),

	/** The checks card selected. */
	CHECKS_CARD_SELECTED(By.xpath("//div[contains(@class,'payment')]//label[text()='Checks']//ancestor::div[contains(@class,'payment-btn active')]//label//input"), "Checks card selected"),

	/** The credit cards selected. */
	CREDIT_CARDS_SELECTED(By.xpath("//div[contains(@class,'payment')]//label[text()='Credit Cards']//ancestor::div[contains(@class,'payment-btn active')]//label//input"),
	        "Credit card selected"),

	/** The credit cards checkbox. */
	CREDIT_CARDS_CHECKBOX(By.xpath("//div[contains(@class,'payment')]//label[text()='Credit Cards']//ancestor::div[@class='payment-btn cur-pointer']//label//input"), "Checks card checkbox"),

	/** The china union pay selected. */
	CHINA_UNION_PAY_SELECTED(By.xpath("//div[contains(@class,'payment')]//label[text()='China Union Pay']//ancestor::div[contains(@class,'payment-btn active')]//label//input"),
	        "CHINA_UNION_PAY selected"),

	/** The china union pay checkbox. */
	CHINA_UNION_PAY_CHECKBOX(By.xpath("//div[contains(@class,'payment')]//label[text()='China Union Pay']//ancestor::div[@class='payment-btn cur-pointer']//label//input"),
	        "CHINA_UNION_PAY checkbox"),

	/** The dinners club selected. */
	DINNERS_CLUB_SELECTED(By.xpath("//div[contains(@class,'payment')]//label[text()='Diners Club']//ancestor::div[contains(@class,'payment-btn active')]//label//input"),
	        "Diners Club selected"),

	/** The dinners club checkbox. */
	DINNERS_CLUB_CHECKBOX(By.xpath("//div[contains(@class,'payment')]//label[text()='Diners Club']//ancestor::div[@class='payment-btn cur-pointer']//label//input"), "Diners Club checkbox"),

	/** The jcb selected. */
	JCB_SELECTED(By.xpath("//div[contains(@class,'payment')]//label[text()='JCB']//ancestor::div[contains(@class,'payment-btn active')]//label//input"), "JCB selected"),

	/** The jcb checkbox. */
	JCB_CHECKBOX(By.xpath("//div[contains(@class,'payment')]//label[text()='JCB']//ancestor::div[@class='payment-btn cur-pointer']//label//input"), "JCB checkbox"),

	/** The debit cards selected. */
	DEBIT_CARDS_SELECTED(By.xpath("//div[contains(@class,'payment')]//label[text()='Debit Cards']//ancestor::div[contains(@class,'payment-btn active')]//label//input"),
	        "Debit Cards selected"),

	/** The debit cards checkbox. */
	DEBIT_CARDS_CHECKBOX(By.xpath("//div[contains(@class,'payment')]//label[text()='Debit Cards']//ancestor::div[@class='payment-btn cur-pointer']//label//input"), "Debit Cards checkbox"),

	/** The meal coupun selected. */
	MEAL_COUPUN_SELECTED(By.xpath("//div[contains(@class,'payment')]//label[text()='Meal Coupon']//ancestor::div[contains(@class,'payment-btn active')]//label//input"),
	        " Meal Coupon selected"),

	/** The meal coupun checkbox. */
	MEAL_COUPUN_CHECKBOX(By.xpath("//div[contains(@class,'payment')]//label[text()='Meal Coupon']//ancestor::div[@class='payment-btn cur-pointer']//label//input"), "Meal Coupon checkbox"),

	/** The nfc mobile payments selected. */
	NFC_MOBILE_PAYMENTS_SELECTED(By.xpath("//div[contains(@class,'payment')]//label[text()='NFC Mobile Payments']//ancestor::div[contains(@class,'payment-btn active')]//label//input"),
	        "NFC Mobile Payments selected"),

	/** The nfc mobile payments checkbox. */
	NFC_MOBILE_PAYMENTS_CHECKBOX(By.xpath("//div[contains(@class,'payment')]//label[text()='NFC Mobile Payments']//ancestor::div[@class='payment-btn cur-pointer']//label//input"),
	        "NFC Mobile Payments checkbox"),

	/** The google pay selected. */
	GOOGLE_PAY_SELECTED(By.xpath("//div[contains(@class,'payment')]//label[text()='Google Pay (Tez)']//ancestor::div[contains(@class,'payment-btn active')]//label//input"),
	        "Google Pay (Tez) selected"),

	/** The google pay checkbox. */
	GOOGLE_PAY_CHECKBOX(By.xpath("//div[contains(@class,'payment')]//label[text()='Google Pay (Tez)']//ancestor::div[@class='payment-btn cur-pointer']//label//input"),
	        "Google Pay (Tez) checkbox"),

	/** The cheque. */
	CRYPTO(By.xpath("//div[contains(@class,'payment')]//label[text()='Crypto']//ancestor::div[@class='payment-btn cur-pointer']//img[contains(@src,'crypto')]"), "Crypto"),

	/** The cheque checkbox. */
	CRYPTO_CHECKBOX(By.xpath("//div[contains(@class,'payment')]//label[text()='Cheque']//ancestor::div[@class='payment-btn cur-pointer']//label//input"), "Crypto Checkbox"),

	/** The cheque selected. */
	CRYPTO_CHECKBOX_SELECTED(By.xpath("//div[contains(@class,'payment')]//label[text()='Crypto']//ancestor::div[contains(@class,'payment-btn active')]//label//input"),
	        "Crypto Checkbox Selected"),

	/** The payment cancel button. */
	PAYMENT_CANCEL_BUTTON(By.xpath("//h3[contains(text(),'Payment Methods')]//ancestor::div[@class='content-full-wrp']//following::button[text()='Cancel']"),
	        "Payment cancel button"),

	/** The payment publish button. */
	PAYMENT_PUBLISH_BUTTON(By.xpath("//h3[contains(text(),'Payment Methods')]//ancestor::div[@class='content-full-wrp']//following::button[text()='Publish']"),
	        "Payment publish button"),

	/** The urls. */
	URLS(By.xpath("//div[contains(@class,'dl-business-details')]//div[@class='content-left-section']//h3[text()='URLs']"), "Urls"),

	/** The website url. */
	WEBSITE_URL(By.xpath("//div[contains(@class,'urls')]//div[contains(@class,'content-right-section')]//span[text()='Website URL']//parent::div//input"), "Website url"),
	
	/** The Appointment url. */
	APPOINTMENT_URL(By.xpath("//div[contains(@class,'urls')]//div[contains(@class,'content-right-section')]//span[text()='Appointment URL']//parent::div//input"), "Appointment url"),

	/** The facebook url. */
	FACEBOOK_URL(By.xpath("//div[contains(@class,'urls')]//div[contains(@class,'content-right-section')]//span[text()='Facebook URL']//parent::div//input"), "Facebbok url"),

	/** The twitter url. */
	X_FORMERLY_TWITTER_URL(By.xpath("//div[contains(@class,'urls')]//div[contains(@class,'content-right-section')]//span[text()='X (Formerly Twitter) URL']//parent::div//input"), "Twitter url"),

	/** The linked in url. */
	LINKED_IN_URL(By.xpath("//div[contains(@class,'urls')]//div[contains(@class,'content-right-section')]//span[text()='Linkedin URL']//parent::div//input"), "Linkedin url"),

	/** The publish all button. */
	PUBLISH_ALL_BUTTON(By.xpath("//div[contains(@class,'mainContent')]//div[contains(@class,'d-flex')]//button[text()='Publish All']"), "Publish all button"),

	/** The saved message text. */
	SAVED_MESSAGE_TEXT(By.xpath("//span[text()='Saved!']"), "Saved message text"),

	/** The next button. */
	NEXT_BUTTON(By.xpath("//div[@class='btn-wrp']//div//button[text()='Next']"), "Next button"),

	/** The hours of operation button. */
	HOURS_OF_OPERATION_BUTTON(By.xpath("//div[contains(@class,'stepper-holder')]//div[contains(@class,'step')]//img[@alt='hour-of-operations']//parent::div//following-sibling::h5[text()='Hours of Operation']"),
	        "Hours of operation"),

	/** The hours of operation timeholder row. */
	HOURS_OF_OPERATION_TIMEHOLDER_ROW(By.xpath("//div[@class='card-bg bh-hours']//div[@class='dl-sh']//div[@class='time-holder-row']"), "Howers Of Operation TimeeHolder Row"),

	/** The hours of operation active. */
	HOURS_OF_OPERATION_ACTIVE(By.xpath("//div[contains(@class,'stepper-holder')]//h5[text()='Hours of Operation']//parent::div[contains(@class,'active')]"),
	        "Hours of opeartion active"),

	/** The operation hours. */
	OPERATION_HOURS(By.xpath("//div[@class='flex-item-sm']//div[@class='section-header']//h5[text()='Operation Hours']"), "Operation hours"),

	/** The operation hours edit. */
	OPERATION_HOURS_EDIT(By.xpath("//div[@class='flex-item-sm']//h5[text()='Operation Hours']//parent::div//span[text()='Edit']"), "Operation hours edit"),

	/** The operation hours list. */
	OPERATION_HOURS_LIST(By.xpath("//div[@class='flex-item-sm']//div[@class='section-header']//h5[text()='Operation Hours']//ancestor::div[@class='card-bg']"),
	        "Operation hours list"),

	/** The monday open hour. */
	MONDAY_OPEN_HOUR(By.xpath("//span[text()='Monday']//ancestor::div[@class='time-holder-row']//div[contains(@class,'time-section')]//span"), "Monday open hour"),

	/** The tuesday open hour. */
	TUESDAY_OPEN_HOUR(By.xpath("//span[text()='Tuesday']//ancestor::div[@class='time-holder-row']//div[contains(@class,'time-section')]//span"), "Tuesday open hour"),

	/** The friday open hour. */
	FRIDAY_OPEN_HOUR(By.xpath("//span[text()='Friday']//ancestor::div[@class='time-holder-row']//div[contains(@class,'time-section')]//span"), "Friday open hour"),

	/** The sunday open hour. */
	SUNDAY_OPEN_HOUR(By.xpath("//span[text()='Sunday']//ancestor::div[@class='time-holder-row']//div[contains(@class,'time-section')]//span"), "Sunday open hour"),

	/** The special hours. */
	SPECIAL_HOURS(By.xpath("//div[@class='flex-item-sm']//h5[text()='Special Hours']"), "Special hour"),

	/** The special hours edit. */
	SPECIAL_HOURS_EDIT(By.xpath("//div[@class='flex-item-sm']//h5[text()='Special Hours']//parent::div//span[text()='Edit']"), "Special hours edit"),

	/** The special hours content. */
	SPECIAL_HOURS_CONTENT(By.xpath("//div[contains(@class,'dl-container')]//div[@class='card-bg special-hour-card']//div[@class='sh-card']"), "Special hours content"),

	/** The back button. */
	BACK_BUTTON(By.xpath("//div[contains(@class,'dl-container')]//div[contains(@class,'btn-wrp')]//button[text()='Back']"), "Back button"),

	/** The publish button. */
	PUBLISH_BUTTON(By.xpath("//div[contains(@class,'dl-container')]//div[contains(@class,'btn-wrp')]//button[text()='Publish']"), "Publish button"),

	/** The hours of operation next button. */
	HOURS_OF_OPERATION_NEXT_BUTTON(By.xpath("//div[contains(@class,'dl-container')]//div[@class='btn-wrp']//button[text()='Next']"), "Hours of operation next button"),

	/** The photos button. */
	PHOTOS_BUTTON(By.xpath("//div[contains(@class,'stepper-holder')]//div[contains(@class,'step')]//h5[text()='Photos']"), "Photos button"),

	/** The photos active. */
	PHOTOS_ACTIVE(By.xpath("//div[contains(@class,'stepper-holder')]//h5[text()='Photos']//parent::div[contains(@class,'step active')]"), "Photos active"),

	/** The logo photo. */
	LOGO_PHOTO(By.xpath("//div[@class='dl-business-details--container']//h3[text()='Logo Photo']"), "Logo photo"),

	/** The logo photo upload. */
	LOGO_PHOTO_UPLOAD(By.xpath(
	        "//h3[text()='Logo Photo']//ancestor::div[@class='dl-business-details--container']//p[text()='Drag & Drop your files here to upload']//preceding-sibling::img//parent::div[@class='upload-image']"),
	        "Logo photo upload"),

	/** The image holder. */
	LOGO_PHOTO_IMAGE_HOLDER(By.xpath("//h3[text()='Logo Photo']//ancestor::div[@class='dl-business-details--container']//div[@class='logo-uploader']//img"),
	        "Logo Photo Image holder"),

	/** The logo photo delete. */
	LOGO_PHOTO_DELETE(By.xpath("//h3[text()='Logo Photo']//ancestor::div[@class='dl-business-details--container']//div[@class='image-holder']//div//span"), "Logo photo delete"),

	/** The cover photo. */
	COVER_PHOTO(By.xpath("//div[@class='dl-business-details--container']//h3[text()='Cover Photo']"), "Cover photo"),

	/** The cover photo upload. */
	COVER_PHOTO_UPLOAD(By.xpath("//h3[text()='Cover Photo']//parent::div//following::div//div//div[@class='cover-uploader']//div[@class='upload-image']"), "Cover photo upload"),

	/** The cover photo image holder. */
	COVER_PHOTO_IMAGE_HOLDER(
	        By.xpath("//h3[text()='Cover Photo']//parent::div//following::div//div//div[@class='cover-uploader']//div[@class='upload-image']//img[contains(@src,'upload-icon')]"),
	        "Cover photo image holder"),

	/** The cover photo delete. */
	COVER_PHOTO_DELETE(By.xpath("//h3[text()='Cover Photo']//ancestor::div[@class='dl-business-details--container']//div[@class='image-holder']//div//span"), "Cover photo delete"),

	/** The additional photo. */
	ADDITIONAL_PHOTO(By.xpath("//div[@class='dl-business-details--container']//h3[text()='Additional Photo']"), "Additional photo"),

	/** The additional photo upload. */
	ADDITIONAL_PHOTO_UPLOAD(By.xpath(
	        "//h3[text()='Additional Photo']//ancestor::div[@class='dl-business-details--container']//p[text()='Drag & Drop your files here to upload']//preceding-sibling::img//parent::div[@class='upload-image']"),
	        "Additional photo upload"),

	/** The additional photo image holder. */
	ADDITIONAL_PHOTO_IMAGE_HOLDER(By.xpath(
	        "//h3[text()='Additional Photo']//ancestor::div[@class='dl-business-details--container']//p[text()='Drag & Drop your files here to upload']//preceding-sibling::img//parent::div[@class='upload-image']//img[contains(@src,'upload-icon')]"),
	        "Additional photo image holder"),

	/** The additional photo delete. */
	ADDITIONAL_PHOTO_DELETE(By.xpath("//h3[text()='Additional Photo']//ancestor::div[@class='dl-business-details--container']//div[@class='image-holder']//div//span"),
	        "Additional photo delete"),

	/** The notification content. */
	NOTIFICATION_CONTENT(By.xpath("//section[contains(@class,'item-g notification-cnt')] "), "Notification content"),

	/** The notification content items. */
	NOTIFICATION_CONTENT_ITEMS(
	        By.xpath("//section[contains(@class,'item-g notification-cnt')]//p[text()='Reach out to ']//strong[text()='Have questions?']//following-sibling::a[text()='support@rallio.com']"),
	        "Notification content items"),

	/** The photos back button. */
	PHOTOS_BACK_BUTTON(By.xpath("//div//button[text()='Back']"), "Photos back button"),

	/** The photos publish button. */
	PHOTOS_PUBLISH_BUTTON(By.xpath("//div//button[text()='Publish']"), "Photos publish button"),

	/** Brand Hub Location name. */
	BRAND_HUB_LOCATION_NAME(By.xpath("//div[@class='brand-profile h-assorted']//div[@class='ds-dropdown']//button//span[1]"), "Brand Hub Location name"),

	/** Brand Hub Location dropdown. */
	BRAND_HUB_LOCATION_DROPDOWN(By.xpath("//div[@class='brand-profile h-assorted']//div[@class='ds-dropdown']//div[contains(@class,'ds-menu')]"), "Brand Hub Location dropdown"),

	/** Brand Hub Location dropdown search. */
	BRAND_HUB_LOCATION_DROPDOWN_SEARCH(By.xpath("//div[@class='ds-drp-indicator']//parent::div//preceding-sibling::div//input"), "Brand Hub Location dropdown search"),

	/** Select account from dropdown. */
	SELECT_ACCOUNT_FROM_DROPDOWN("//div[@class='brand-profile h-assorted']//div[@class='ds-dropdown']//div[@class='ds-menu']//div[contains(@id,'react-select') and text()='%s']",
	        "Select account from dropdown"),

	/** The listed locations of user. */
	LISTED_LOCATIONS_OF_USER(By.xpath("//div[@class='rs-drp__menu-list css-11unzgr']/div[contains(@class,'as-item location-icon-wraps rs-drp__option css-yt9ioa-option')]"),
	        "Brand Hub Location dropdown search"),

	/** The directory listings tab. */
	DIRECTORY_LISTINGS_TAB(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Directory Listings']"), "Directory listings tab"),

	/** The directory listings tab profile. */
	DIRECTORY_LISTINGS_TAB_PROFILE(By.xpath("//div[contains(@class,'sub-nav')]//span[contains(text(),'Profile')]"), "Directory listings tab profile"),

	/** The field input name. */
	FIELD_INPUT_NAME("//input[@value='%s']", "The Field By Name"),

	/** The store info cancel button. */
	STORE_INFO_CANCEL_BUTTON(By.xpath("//h3[contains(text(),'Store Info')]//ancestor::div[@class='content-full-wrp']//following::button[text()='Cancel']"),
	        "The Store Info Cancel Button"),
	/** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),
	
	/** The edit cancel button. */
	EDIT_CANCEL_BUTTON(By.xpath("//div[@class='modal-dialog modal-dialog-centered']//div[@class='modal-content']//img[@alt='close']"), "Edit Cancel button"),

	/** The profile icon. */
	PROFILE_ICON(By.xpath("//button[@id='dropitems-profile-items']"), "Profile icon"),

	/** Profile icon dropdown. */
	PROFILE_ICON_DROPDOWN(By.xpath("//button[@id='dropitems-profile-items']//following-sibling::div[@class='dropdown-menu show']"), "Profile icon dropdown"),

	/** The dropdown logout. */
	DROPDOWN_LOGOUT(By.xpath("//div[@class='dropdown-menu show']//a[text()='Logout']"), "Dropdown logOut"),

	/**Special hours - remove option */
	SPECIAL_HOURS_REMOVE_OPTION(By.xpath("//div[@class='card-bg bh-hours']//div[@class='action-btn cur-pointer']//img[@alt='remove']"), "Special hours - remove option"),
	
	
	/**Special hours - save button */
	SPECIAL_HOURS_SAVE_BUTTON(By.xpath("//div[contains(@class,'react-ripples ripple')]//button[@type='button' and text()='Save']"), "special hours - save button"),
	
	/** The listings tab. */
	LISTINGS_TAB(By.xpath("//span[@class='sub-nav-item-txt' and text()='Listings']"), "Listings tab"),

	/**Special hours - click on current date  */
	SPECIAL_HOURS_CURRENT_DATE(By.xpath("//div[@class='react-datepicker-wrapper']//input[@placeholder='Date']"), "special hours - click on current date"),
	
	/**Date picker - previous month button  */
	DATE_PICKER_PREVIOUS_BUTTON(By.xpath("//div[@class='react-datepicker']//button[@aria-label='Previous Month']"), "Date picker - previous month button"),
	
	/**Date picker - previous month button  */
	SPECIAL_HOURS_DATE(By.xpath("//div[@class='react-datepicker__week']//div[contains(@class,'react-datepicker__day react-datepicker__day--028')]"), "Date picker - previous month button"),
	
	/** special hours invalid date validation message  */
	SPECIAL_HOURS_VALIDATION_MESSAGE(By.xpath("//div[@class='card-bg bh-hours']//div[@class='error-txt-login' and text()=\"Date must start after today's date! Please select a valid date to continue.\"]"), "special hours invalid date validation message "),
	
	/**Date picker - next month button  */
	DATE_PICKER_NEXT_BUTTON(By.xpath("//div[@class='react-datepicker']//button[@aria-label='Next Month']"), "Date picker - previous next button"),
	
	/** Add Special Hours. */
	ADD_SPECIAL_HOURS(By.xpath("//div[@class='card-bg bh-hours']//button[@type='button' and text()='Add Special Hours']"), "Special hours - Add special hours button");
	
	
	
	
	/** The by locator. */
	/* The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new directory listings page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private DirectoryListingsProfilePageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new directory listings page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private DirectoryListingsProfilePageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

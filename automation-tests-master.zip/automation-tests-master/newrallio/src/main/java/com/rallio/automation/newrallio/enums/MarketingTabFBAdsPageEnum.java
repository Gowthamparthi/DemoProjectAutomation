package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum MarketingTabFBAdsPageEnum.
 */
public enum MarketingTabFBAdsPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath(
			"//li[@class='ripple active']//span[text()='FB Ads']//ancestor::div[@class='head-menu']//following-sibling::main//div[contains(@class,'mrktng-fb-ads')]"),
			"Page load"),

	/** The facebook ad account. */
	FACEBOOK_AD_ACCOUNT(By.xpath(
			"//main//div[contains(@class,'mainContent')]//img[contains(@src,'fb-lv.svg')]//ancestor::div[@class='rel-head-label']//span[text()='Facebook Ad Account']"),
			"Facebook Ad account"),

	/** The facebook icon. */
	FACEBOOK_ICON(By.xpath("//div[@class='rel-icons']//img[contains(@src,'fb-lv.svg')]"), "Facebook Icon"),

	/** The facebook ads description. */
	FACEBOOK_ADS_DESCRIPTION(By.xpath("//div[@class='right-section-wrp']//div[@class='r-profile-details-notify']"),
			"Facebook Ads Description"),
	
	FACEBOOK_ADS_DESCRIPTION_IMAGE(By.xpath("//div[@class='fba-item']//img"),
			"Facebook Ads Description Image"),

	/** The account name. */
	ACCOUNT_NAME(By.xpath(
			"//main//div[contains(@class,'mainContent')]//div[@class='scl-details']//span[text()='Account Name']//following-sibling::span"),
			"Account name"),

	/** The account username. */
	ACCOUNT_USERNAME(By.xpath("//div[@class='scl-details']//div[@class='scld-item'][1]//span[@class='scld-value']"),
			"Account UserName"),

	/** The account id. */
	ACCOUNT_ID(By.xpath(
			"//main//div[contains(@class,'mainContent')]//div[@class='scl-details']//span[text()='Account ID']//following-sibling::span"),
			"Account ID"),

	/** The account id value. */
	ACCOUNT_ID_VALUE(By.xpath("//div[@class='scl-details']//div[@class='scld-item'][2]//span[@class='scld-value']"),
			"Account-ID Value"),

	/** The connect now button. */
	CONNECT_NOW_BUTTON(By.xpath("//button[contains(text(),'Connect Now')]"),
			"Connect now button"),

	/** The disconnect button. */
	DISCONNECT_BUTTON(By.xpath(
			"//button[text()='Disconnect']"),
			"Disconnect button"),

	/** The disconnect alert. */
	DISCONNECT_ALERT(
			By.xpath("//div[@class='modal-content']//div[@class='modal-body']//div[@class='modal-message-wraps']"),
			"Disconnect alert"),

	/** The disconnect alert cancel button. */
	DISCONNECT_ALERT_CANCEL_BUTTON(
			By.xpath("//div[@class='modal-content']//div[@class='modal-footer']//button[text()='Cancel']"),
			"Disconnect alert cancel button"),

	/** The disconnect alert ok button. */
	DISCONNECT_ALERT_OK_BUTTON(
			By.xpath("//div[@class='modal-content']//div[@class='modal-footer']//button[text()='Ok']"),
			"Disconnect alert ok button"),

	/** The change account button. */
	CHANGE_ACCOUNT_BUTTON(By.xpath(
			"//button[text()='Change Account']"),
			"Change account button"),

	/** The continue as button. */
	CONTINUE_AS_BUTTON(By.xpath("//div[@role='button']//span[contains(text(),'Continue as ')]"), "Continue as button"),

	/** The log in button. */
	LOG_IN_BUTTON(By.xpath("//body[contains(@class,'login_page')]//div[@id='buttons']//input"), "Log In Button"),

	/** The connect now button. */
	FB_ADS_CONNECT_NOW_BUTTON(By.xpath("//h3[text()='Please select an Ad Account']//ancestor::div[@class='modal-content']//div[@class='modal-footer']//button[text()='Connect Now']"),
			"Connect now button"),

	/** The accounts. */
	FB_AD_ACCOUNTS(By.xpath(
			"//h3[text()='Please select an Ad Account']//ancestor::div[@class='modal-content']//div[@class='modal-body']//div[@class='aps-main']//div[contains(@class,'aps-item')]"),
			"Accounts"),

	/** The account selected. */
	FB_AD_ACCOUNT_SELECTED(By.xpath(
			"//h3[text()='Please select an Ad Account']//ancestor::div[@class='modal-content']//div[@class='modal-body']//div[@class='aps-main']//div[contains(@class,'active')]"),
			"Account selected"),

	/** The facebook continue button for already logged in. */
	FACEBOOK_CONTINUE_BUTTON_FOR_ALREADY_LOGGED_IN(By.xpath("//div[@id='content']//div[@class='popup_buttons_area']//label//input[@value='Continue']"), "The facebook continue button for already logged in."),

	/** The email id. */
	EMAIL_ID(By.xpath("//body[contains(@class,'login_page')]//div[@class='clearfix form_row'][1]//input"), "Input Email"),

	/** The password. */
	PASSWORD(By.xpath("//body[contains(@class,'login_page')]//div[@class='clearfix form_row'][2]//input"), "Input Password"),

    FACEBOOK_CONTINUE_AS_BUTTON(By.xpath("//div[contains(@aria-label,'Continue as ')]"),"Continue As Button"),

	;

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new marketing tab FB ads page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private MarketingTabFBAdsPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new marketing tab FB ads page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private MarketingTabFBAdsPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

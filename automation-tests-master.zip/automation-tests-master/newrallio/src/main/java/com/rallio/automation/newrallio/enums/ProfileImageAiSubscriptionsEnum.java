package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum AiSubscribtionEnum.
 */
public enum ProfileImageAiSubscriptionsEnum {

	PAGE_LOAD(By.xpath(
			"//div[@class='modal-header']//div[@class='rai-sub-top']//ancestor::div//div[@class='modal-body']//div[@class='resuseTable adptTable']"),
			"Profile Image Ai Subsriptions Pageload"),

	RALLIO_SUBSCRIPTIONS(By.xpath("//div[@class='modal-header']//div[@class='rai-sub-top']//h2[text()='Rallio Subscriptions']"),"Rallio Subscriptions Text"),
	
	ADD_NEW_SUBSCRIPTIONS_BUTTON(By.xpath("//div[@class='modal-header']//div[@class='rai-sub-top']//button//span[text()='Add New Subscriptions']"),"Add New Subcriptions button"),
	
	SUBSCRIPTIONS_TYPE(By.xpath("//div[@class='modal-body']//table//th//span[text()='Subscription Type']"),"Subscription Type"),
	
	PLAN(By.xpath("//div[@class='modal-body']//table//th//span[text()='Plan']"),"Plan"),
	
	PURCHASE_DATE_WITH_DOWN_ARROW(By.xpath("//div[@class='modal-body']//table//th//span[text()='Purchase Date']//following-sibling::img[@class='sort-cus ']"),"Purchase Date with Down Arrow"),
	
	PURCHASE_DATE_WITH_UP_ARROW(By.xpath("//div[@class='modal-body']//table//th//span[text()='Purchase Date']//following-sibling::img[@class='sort-cus sort-icon__rotate']"),"Purchase Date with Up Arrow"),

	RENEWAL_STATS(By.xpath("//div[@class='modal-body']//table//th//span[text()='Renewal Status']"),"Renewal Stats"),
	
	LOCATIONS(By.xpath("//div[@class='modal-body']//table//th//span[text()='# Locations']"),"#Locations"),
	
	AMOUNT(By.xpath("//div[@class='modal-body']//table//th//span[text()='Amount']"),"Amount"),
	
	AI_SUBSRIPTIONS_DETAILVIEW_CLOSE(By.xpath("//div[@class='modal-content']//div[@class='mod__close--icon']//img[@alt='cancel']"),"AI Subscriptions Close"),
	
	YOUR_PAYMENT_TEXT(By.xpath("//div[@class='modal-body']//p[contains(text(),'Your payments will be charged against the credit card')]"),"Ai Subscriptions Your Payments text"),
	
	SUBSCRIPTIONS_TABLE_VIEW(By.xpath("//table[@class='responsiveTable table']//td[@class='ads-item ']//parent::tr"),"Subscriptions Tableview"),
	
	NO_DATA_TO_FOUND(By.xpath("//td[text()=' No Data to show']//parent::tr"),"No Data To Found"),
	
	
	//Post Page AI Detailview Video page
	AI_OPTION_DETAILVIEW_VIDEO_PAGELOAD(By.xpath("//div[@class='modal-content']//div[@class='ai-sub-home']//div[@class='ai-promo-video']//following-sibling::div[@class='ral-aip-main']//ancestor::div[@class='modal-content']"),"Ai Subscription Detailview Pageload"),
	
	AI_DETAILVIEW_VIDEO_SECTION(By.xpath("//div[@class='modal-content']//div[@class='ai-sub-home']//div[@class='video-section']//div//video"),"AI Video Section"),
	
	RALLIO_AI_PRICING_AND_PLAN_TEXT(By.xpath("//div[@class='modal-content']//div[@class='ral-aip-main']//h2[text()='Rallio AI Pricing & Plans']"),"Rallio AI Pricing & Plans Text"),
	
	RALLIO_AI_PRICING_DESCRIPTION(By.xpath("//div[@class='modal-content']//div[@class='ral-aip-main']//h2[text()='Rallio AI Pricing & Plans']//following-sibling::p[contains(text(),'Jump in and experience how simple, easy,')]"),"Ai Pricing Description"),
	
	MONTHLY_PERLOCATION_CONTENT(By.xpath("//div[@class='modal-content']//div[@class='ral-aip-main']//div[@class='raip-item raip-monthly']//h4[text()='Monthly']//following-sibling::p[text()='Per location']//parent::div"),"Monthly Per Location Content"),
	
	MONTHLY_SUBSCRIPTIONS_PRICE_AMOUNT(By.xpath("//div[@class='modal-content']//div[@class='ral-aip-main']//div[@class='raipm-price-main']//span[text()='$']//following-sibling::span[text()='29']//following-sibling::span[text()='/mo']"),"Monthly Subscriptions Price amount"),
	
	MONTHLY_SUBSCRIPTIONS_TRY_FOR_FREE_BUTTON(By.xpath("//div[@class='raip-item raip-monthly']//span[text()='7 days Free Trial']//parent::div//following-sibling::button//span[text()='Try for free now']"),"Monthly Subscriptions Try For Free button"),
	
	YEARLY_PERLOCATION_CONTENT(By.xpath("//div[@class='modal-content']//div[@class='ral-aip-main']//div[@class='raip-item raip-yearly']//h4[text()='Yearly']//following-sibling::p[text()='Per location']//parent::div"),"Yearly Per Location Content"),
	
	YEARLY_SUBSCRIPTION_PRICE_AMOUNT(By.xpath("//div[@class='modal-content']//div[@class='raip-mid']//div[@class='raipm-price-main']//span[text()='$']//following-sibling::span[text()='24']//following-sibling::span[text()='/mo']//parent::div//parent::div//span[@class='raipm-monthly' and text()='Billed Annually']//span[text()='$288']"),"Yearly Subscriptions Price Amount "),
	
	YEARLY_SUBSCRIPTIONS_TRY_FOR_FREE_BUTTON(By.xpath("//div[@class='raip-item raip-yearly']//span[text()='7 days Free Trial']//parent::div//following-sibling::button//span[text()='Try for free now']"),"Yearly Subscriptions Try For Free button"),
	
	;

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new ai subscribtion enum.
	 *
	 * @param byLocator   the by locator
	 * @param description the description
	 */
	private ProfileImageAiSubscriptionsEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new ai subscribtion enum.
	 *
	 * @param xpath       the xpath
	 * @param description the description
	 */
	private ProfileImageAiSubscriptionsEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}

}

package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

public enum RevvTabLocationsPageEnum {

    /**
     * The page load.
     */
    PAGE_LOAD(By.xpath(
            "//li//span[text()='Locations']//ancestor::div//section[@id='main-container-sec']//div[contains(@class,'non-psp-leaderboard-table')]"),
            " Revv Locations Page Load"),

    /**
     * The ranking table heading.
     */
    RANKING_TABLE_HEADING(By.xpath(
            "//tbody//tr//td//div[@class='leader__rank']//ancestor::div[contains(@class,'infinite-scroll-component')]//table//tr//th//div[text()='Ranking']"),
            "Ranking Heading"),

    /**
     * The surveys sent button.
     */
    SURVEYS_SENT_BUTTON(By.xpath(
            "//table[@class='responsiveTable table']//th//div[text()='Surveys Sent']"),
            "Surveys Sent Button"),

    /**
     * The surveys cancelled button.
     */
    SURVEYS_CANCELLED_BUTTON(By.xpath(
            "//table[@class='responsiveTable table']//th//div[text()='Surveys Cancelled']"),
            "Surveys Cancelled Button"),

    /**
     * The surveys completed button.
     */
    SURVEYS_COMPLETED_BUTTON(By.xpath(
            "//table[@class='responsiveTable table']//th//div[text()='Surveys Completed']"),
            "Surveys Completed Button"),

    /**
     * The aggred to review button.
     */
    AGGRED_TO_REVIEW_BUTTON(By.xpath(
            "//table[@class='responsiveTable table']//th//div[text()='Agreed to Review']"),
            "Agreed To Review Button"),

    /**
     * The average rating button.
     */
    AVERAGE_RATING_BUTTON(By.xpath(
            "//table[@class='responsiveTable table']//th//div[text()='Average Rating']"),
            "Average Rating Button"),

    /**
     * The customers button.
     */
    CUSTOMERS_BUTTON(By.xpath("//table[@class='responsiveTable table']//th//div[text()='Customers']"), "Customers Button"),

    /**
     * The send survey button.
     */
    SEND_SURVEY_BUTTON(By.xpath("//section[contains(@class,'item-g filter')]//button//span[text()='Send Survey']"),
            "Send Survey Button"),

    /**
     * The download csv button.
     */
    DOWNLOAD_CSV_BUTTON(By.xpath("//section[contains(@class,'item-g filter')]//button//span[text()='Download CSV']"),
            "Download Csv Button"),

    /**
     * The download done message.
     */
    DOWNLOAD_DONE_MESSAGE(By.xpath("//span[@class='success-mess-txt' and text()='Done!']"), "The Download Done"),

    /**
     * The clear filter inactive.
     */
    CLEAR_FILTER_INACTIVE(By.xpath(
            "//section[contains(@class,'item-g filter')]//div[@class='react-ripples ac-primary-box  pointer-events-none']//button//span[text()='Clear Filter']"),
            "Clear Filter InActive"),

    /**
     * The clear filter active.
     */
    CLEAR_FILTER_ACTIVE(By.xpath(
            "//section[contains(@class,'item-g filter')]//div[@class='react-ripples ac-primary-box']//button//span[text()='Clear Filter']"),
            "Clear Filter Active"),

    /**
     * The social filter inactive.
     */
    SOCIAL_FILTER_INACTIVE(By.xpath(
            "//section[contains(@class,'item-g filter')]//div[@class='form-group']//label[not(@class='active')]//input//following-sibling::span[text()='Social']"),
            "Social Filter InActive"),

    /**
     * The social filter active.
     */
    SOCIAL_FILTER_ACTIVE(By.xpath(
            "//section[contains(@class,'item-g filter')]//div[@class='form-group']//label[@class='active']//input//following-sibling::span[text()='Social']"),
            "Social Filter Active"),

    /**
     * The revv location filter inactive.
     */
    REVV_LOCATION_FILTER_INACTIVE(By.xpath(
            "//section[contains(@class,'item-g filter')]//div[@class='form-group']//label[not(@class='active')]//input//following-sibling::span[text()='Revv Locations']"),
            "Revv Location Filter Inactive"),

    /**
     * The revv location filter active.
     */
    REVV_LOCATION_FILTER_ACTIVE(By.xpath(
            "//section[contains(@class,'item-g filter')]//div[@class='form-group']//label[@class='active']//input//following-sibling::span[text()='Revv Locations']"),
            "Revv Loactions Filter Active"),

    /**
     * The revv employees filter inactive.
     */
    REVV_EMPLOYEES_FILTER_INACTIVE(By.xpath(
            "//section[contains(@class,'item-g filter')]//div[@class='form-group']//label[not(@class='active')]//input//following-sibling::span[text()='Revv Employees']"),
            "Revv Employees Filter In Active"),

    /**
     * The revv employees filter active.
     */
    REVV_EMPLOYEES_FILTER_ACTIVE(By.xpath(
            "//section[contains(@class,'item-g filter')]//div[@class='form-group']//label[@class='active']//input//following-sibling::span[text()='Revv Employees']"),
            "Revv Employees Filter Active"),

    /**
     * The from date.
     */
    FROM_DATE(By.xpath(
            "//div[@class='react-datepicker-wrapper']//div[@class='react-datepicker__input-container']//input[@placeholder='MM/DD/YYYY']"),
            "From Date"),

    /**
     * The to date.
     */
    TO_DATE(By.xpath(
            "//div[@class='react-datepicker-wrapper']//div[@class='react-datepicker__input-container']//input[@placeholder='Most Recent']"),
            "To Date"),

    /**
     * The location selector.
     */
    LOCATION_SELECTOR(By.xpath(
            "//div[@class='filter-item fltr-drp']//h3[text()='Location Selector']//following-sibling::div//span[@class='la-sel-action']"),
            "Location Selector"),

    /**
     * The customers total count.
     */
    CUSTOMERS_TOTAL_COUNT(By.xpath(
            "//div[text()='Customers']//ancestor::table//tbody//tr[@class='revv-total-row ']//td[2]"),
            "Customers Total count"),

    /**
     * The surveys sent total count.
     */
    SURVEYS_SENT_TOTAL_COUNT(By.xpath(
            "//div[text()='Surveys Sent']//ancestor::table//tbody//tr[@class='revv-total-row ']//td[3]"),
            "Surveys Sent Total Count"),

    /**
     * The surveys cancelled total count.
     */
    SURVEYS_CANCELLED_TOTAL_COUNT(By.xpath(
            "//div[text()='Surveys Cancelled']//ancestor::table//tbody//tr[@class='revv-total-row ']//td[4]"),
            "Surveys Cancelled Total Count"),

    /**
     * The surveys completed total count.
     */
    SURVEYS_COMPLETED_TOTAL_COUNT(By.xpath(
            "//div[text()='Surveys Completed']//ancestor::table//tbody//tr[@class='revv-total-row ']//td[5]"),
            "Surveys Completed Total Count"),

    /**
     * The agreed to review total count.
     */
    AGREED_TO_REVIEW_TOTAL_COUNT(By.xpath(
            "//div[text()='Average Rating']//ancestor::table//tbody//tr[@class='revv-total-row ']//td[6]"),
            "Agreed To Review Total Count"),

    /**
     * The average rating total count.
     */
    AVERAGE_RATING_TOTAL_COUNT(By.xpath(
            "//div[text()='Average Rating']//ancestor::table//tbody//tr[@class='revv-total-row ']//td[7]"),
            "Average Rating Toal Count"),

    /**
     * The surveys sent down arrow.
     */
    SURVEYS_SENT_DOWN_ARROW(
            By.xpath("//table//tr//th//div[text()='Surveys Sent']//following-sibling::img[@class='sort-icon rotate']"),
            "Surveys Sent Down Arrow"),

    /**
     * The surveys sent up arrow.
     */
    SURVEYS_SENT_UP_ARROW(
            By.xpath("//table//tr//th//div[text()='Surveys Sent']//following-sibling::img[@class='sort-icon ']"),
            "Surveys Sent Up Arrow"),

    /**
     * The customers down arrow.
     */
    CUSTOMERS_DOWN_ARROW(
            By.xpath("//table//tr//th//div[text()='Customers']//following-sibling::img[@class='sort-icon rotate']"),
            "Customers Down Arrow"),

    /**
     * The customers up arrow.
     */
    CUSTOMERS_UP_ARROW(
            By.xpath("//table//tr//th//div[text()='Customers']//following-sibling::img[@class='sort-icon ']"),
            "Customers Up Arrow"),

    /**
     * The surveys cancelled down arrow.
     */
    SURVEYS_CANCELLED_DOWN_ARROW(By.xpath(
            "//table//tr//th//div[text()='Surveys Cancelled']//following-sibling::img[@class='sort-icon rotate']"),
            "Survey Cancelled Down Arrow"),

    /**
     * The surveys cancelled up arrow.
     */
    SURVEYS_CANCELLED_UP_ARROW(
            By.xpath("//table//tr//th//div[text()='Surveys Cancelled']//following-sibling::img[@class='sort-icon ']"),
            "Surveys Cancelled Up Arrow"),

    /**
     * The surveys completed down arrow.
     */
    SURVEYS_COMPLETED_DOWN_ARROW(By.xpath(
            "//table//tr//th//div[text()='Surveys Completed']//following-sibling::img[@class='sort-icon rotate']"),
            "Surveys Completed Down Arrow"),

    /**
     * The surveys completed up arrow.
     */
    SURVEYS_COMPLETED_UP_ARROW(
            By.xpath("//table//tr//th//div[text()='Surveys Completed']//following-sibling::img[@class='sort-icon ']"),
            "Surveys Completed Up Arrow"),

    /**
     * The agreed to review down arrow.
     */
    AGREED_TO_REVIEW_DOWN_ARROW(By.xpath(
            "//table//tr//th//div[text()='Agreed to Review']//following-sibling::img[@class='sort-icon rotate']"),
            "Agreed To Review Down Arrow"),

    /**
     * The agreed to review up arrow.
     */
    AGREED_TO_REVIEW_UP_ARROW(
            By.xpath("//table//tr//th//div[text()='Agreed to Review']//following-sibling::img[@class='sort-icon ']"),
            "Agreed To Review Up Arrow"),

    /**
     * The average rating down arrow.
     */
    AVERAGE_RATING_DOWN_ARROW(
            By.xpath(
                    "//table//tr//th//div[text()='Average Rating']//following-sibling::img[@class='sort-icon rotate']"),
            "Average Rating Down Arrow"),

    /**
     * The average rating up arrow.
     */
    AVERAGE_RATING_UP_ARROW(
            By.xpath("//table//tr//th//div[text()='Average Rating']//following-sibling::img[@class='sort-icon ']"),
            "Average Rating Up Arrow"),

    TABLE_ROW_LOCATIONS_COUNT(
            By.xpath("//div[@class='tot__row--title']//following-sibling::div[@class='tot__row--subtitle']"),
            "Table row Locations Count"),

    /**
     * The table firstrow highest value field.
     */
    TABLE_FIRSTROW_VALUE_FIELD(
            "//div[text()='%s']//preceding::th//ancestor::thead//following-sibling::tbody[2]//tr[1]//td[@class='sort-active ' and text()='%s']",
            " First Row Value"),

    /**
     * The average rating highest row value.
     */
    AVERAGE_RATING_HIGHEST_ROW_COUNT(
            "//table//tr[2]//td//div[text()='%s']//parent::div//parent::div//following-sibling::div//img//following-sibling::span",
            "Average Rating Higher Value"),

    /**
     * The average rating lowest row value.
     */
    AVERAGE_RATING_LOWEST_ROW_COUNT(
            "//table//tr[3]//td//div[text()='%s']//parent::div//parent::div//following-sibling::div//img//following-sibling::span",
            "Average Rating Lower Row Value"),

    /**
     * The average rating highest row field.
     */
    AVERAGE_RATING_FIRSTROW_FIELD(
            "//table//tbody//following-sibling::tbody//tr//td[7]//span[text()='%s']",
            "Average Rating First Row Field"),

    /**
     * The table heading.
     */
    TABLE_RANKING_LIST(By.xpath("//div[text()='Ranking']//parent::div//parent::th//following-sibling::th"),
            "Table heading"),

    /**
     * The table total count list.
     */
    TABLE_TOTAL_COUNT_LIST(By.xpath("//div[text()='Totals']//parent::td//following-sibling::td"), "Table Total List"),

    /**
     * The table users count list.
     */
    TABLE_USERS_COUNT_LIST("//span[text()='%s']//parent::div//parent::div//parent::td//following-sibling::td",
            "Table Users Count list"),

    TABLE_USERS_COUNT_VALUE(By.xpath("//tr//div[@class='leader__rank']//img//following-sibling::span"),
            "Table Count User Value"),

    /**
     * The table list count.
     */
    TABLE_LIST_COUNT(
            By.xpath("//span[@class='customer-name text-dotted']//parent::div//parent::div//parent::td//parent::tr"),
            "Table List Count"),

    /**
     * The footer.
     */
    FOOTER(By.xpath("//div[@class='content-g']//tbody//tr[not(text()='Total')][last()]"), "Footer for List"),

    /**
     * The user surveys sent count.
     */
    USER_SURVEYS_SENT_COUNT(
            "//span[@title='%s']//parent::div//parent::div//parent::td//following-sibling::td//div[text()='Surveys Sent']//parent::div//parent::div//parent::td",
            "Users Surveys Sent Count"),

    /**
     * The date picker.
     */
    DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]",
            "Date Picker"),

    /**
     * The month dropdown.
     */
    MONTH_DROPDOWN(By.xpath("//select[@class='react-datepicker__month-select']"), "Month drop down"),

    /**
     * The year dropdown.
     */
    YEAR_DROPDOWN(By.xpath("//select[@class='react-datepicker__year-select']"), "Year drop down."),

    /**
     * The location one surveys sent count.
     */
    LOCATION_ONE_SURVEYS_SENT_COUNT(By.xpath(
            "//span[text()='Location one Automation']//parent::div//parent::div//parent::td//parent::tr//following-sibling::td//div[text()='Surveys Sent']//parent::div//parent::div//parent::td"),
            "Location One Surveys Sent Count"),

    /**
     * The location one surveys cancelled count.
     */
    LOCATION_ONE_SURVEYS_CANCELLED_COUNT(By.xpath(
            "//span[text()='Location one Automation']//parent::div//parent::div//parent::td//parent::tr//following-sibling::td//div[text()='Surveys Cancelled']//parent::div//parent::div//parent::td"),
            "Location One Surveys Cancelled Count"),

    /**
     * The average rating count field.
     */
    AVERAGE_RATING_COUNT_FIELD(
            "//span[text()='%s']//parent::div//parent::div//parent::td//parent::tr//following-sibling::td//div[text()='Average Rating']//parent::div//parent::div//parent::td",
            "AverageRating Count"),

    /**
     * The previous month.
     */
    PREVIOUS_MONTH_PICKER(By.xpath("//button[contains(@class,'datepicker__navigation--previous')]"), "Previous month."),

    /**
     * The next month.
     */
    NEXT_MONTH_PICKER(By.xpath("//button[contains(@class,'datepicker__navigation--next')]"), "Next month."),

    /**
     * The table location name field.
     */
    TABLE_LOCATION_NAME_FIELD(
            "//span[@class='customer-name text-dotted' and text()='%s']//parent::div//parent::div//parent::td//following-sibling::td",
            "Table Location Field"),

    /** Location Selector *. */
    /**
     * The location selector search tab.
     */
    LOCATION_SELECTOR_SEARCH_TAB(By.xpath("//div[@class='non-psp-loc-search']//input[@placeholder='Search']"),
            "Location Selector Search Tab"),

    /**
     * The location select from dropdown.
     */
    LOCATION_SELECT_FROM_DROPDOWN(
            "//div[@class='accordion-collapse collapse show']//li//span[@class='lbl ' and text()='%s']",
            "Locationn select from dropdown"),

    /**
     * The location list dropdown.
     */
    LOCATION_LIST_DROPDOWN(By.xpath(
            "//div[@class='accordion-collapse collapse show']//div[@class='overflow-hidden accordion-body']//ul"),
            "Location List Dropdown"),

    /**
     * The location selector ok button.
     */
    LOCATION_SELECTOR_OK_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Ok']"), "Location Selector Ok"),

    /**
     * The location selector cancel button.
     */
    LOCATION_SELECTOR_CANCEL_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Cancel']"),
            "Location Selector Cancel Button"),

    /**
     * The all location button.
     */
    ALL_LOCATION_BUTTON(By.xpath("//div[@class=' cur-pointer all-selection' and text()='All Locations']"),
            "All Location Button"),

    /**
     * The all location active.
     */
    ALL_LOCATION_ACTIVE(By.xpath("//div[@class='active cur-pointer all-selection' and text()='All Locations']"),
            "All Location Selector Actives"),

    /**
     * The location button.
     */
    LOCATION_BUTTON(By.xpath(
            "//div[@class='modal-body']//div[@class='accordion']//button[@class='accordion-button collapsed' and text()='Locations  ']"),
            "Location Button"),

    /**
     * The location selector all option.
     */
    LOCATION_SELECTOR_ALL_OPTION(By.xpath(
            "//div[@class='filter-item fltr-drp']//h3[text()='Location Selector']//following-sibling::div[@class='locAction']//span[text()='All']"),
            "Location Selector ALl Option"),

    /**
     * The number of row count.
     */
    NUMBER_OF_ROW_COUNT(
            "//div[text()='%s']//ancestor::thead//following-sibling::tbody//following-sibling::tbody//td[@class='sort-active ' and text()]",
            "Number Of Row Count"),

    CUSTOMER_COLUMN_LIST(By.xpath("//div[text()='Customers']//ancestor::table//tbody//following-sibling::tbody//tr//td[2]"), "Customer Column List"),

    SURVEY_SENT_COLUMN_LIST(By.xpath("//div[text()='Surveys Sent']//ancestor::table//tbody//following-sibling::tbody//tr//td[3]"), "Surevys Sent Column List"),

    SURVEY_CANCELLED_COLUMN_LIST(By.xpath("//div[text()='Surveys Cancelled']//ancestor::table//tbody//following-sibling::tbody//tr//td[4]"), "Surveys Cancelled Column List"),

    SURVEY_COMPLETED_COLUMN_LIST(By.xpath("//div[text()='Surveys Completed']//ancestor::table//tbody//following-sibling::tbody//tr//td[5]"), "Surveys Completed Column List"),

    AGREED_TO_REVIEW_COLUMN_LIST(By.xpath("//div[text()='Agreed to Review']//ancestor::table//tbody//following-sibling::tbody//tr//td[6]"), "Agree To review Column List"),

    AVERAGE_RATING_COLUMN_LIST(By.xpath("//div[text()='Average Rating']//ancestor::table//tbody//following-sibling::tbody//tr//td[7]//div//span[text()]"), "Average Rating Coloumn List"),

    AVERAGERATING_COLUMN_LIST("//div[text()='%s']//ancestor::thead//following-sibling::tbody//following-sibling::tbody//td[@class='sort-active ']//div//span[text()]", "Average Rating"),

    BRAND_AVERAGE_RATING_COLUMN_LIST(By.xpath("//div[text()='Average Rating']//ancestor::table//tbody//following-sibling::tbody//tr//td[6]//div//span[text()]"), "Average Rating Coloumn List"),

    REVV_LOCATION_SURVEYS_SENT_TOTAL_COUNT(By.xpath("//div[text()='Surveys Sent']//ancestor::table//tbody//tr[@class='revv-total-row ']//td[2]"), "Surveys Sent Total Count"),

    /**
     * The surveys cancelled total count.
     */
    REVV_LOCATION_SURVEYS_CANCELLED_TOTAL_COUNT(By.xpath(
            "//div[text()='Surveys Cancelled']//ancestor::table//tbody//tr[@class='revv-total-row ']//td[3]"),
            "Surveys Cancelled Total Count"),

    /**
     * The surveys completed total count.
     */
    REVV_LOCATION_SURVEYS_COMPLETED_TOTAL_COUNT(By.xpath(
            "//div[text()='Surveys Completed']//ancestor::table//tbody//tr[@class='revv-total-row ']//td[4]"),
            "Surveys Completed Total Count"),

    /**
     * The agreed to review total count.
     */
    REVV_LOCATION_AGREED_TO_REVIEW_TOTAL_COUNT(By.xpath(
            "//div[text()='Average Rating']//ancestor::table//tbody//tr[@class='revv-total-row ']//td[5]"),
            "Agreed To Review Total Count"),

    /**
     * The average rating total count.
     */
    REVV_LOCATION_AVERAGE_RATING_TOTAL_COUNT(By.xpath("//div[text()='Average Rating']//ancestor::table//tbody//tr[@class='revv-total-row ']//td[6]"),
            "Average Rating Toal Count"),

    REVV_LOCATION_SURVEY_SENT_COLUMN_LIST(By.xpath("//div[text()='Surveys Sent']//ancestor::table//tbody//following-sibling::tbody//tr//td[2]"), "Surevys Sent Column List"),

    REVV_LOCATION_SURVEY_CANCELLED_COLUMN_LIST(By.xpath("//div[text()='Surveys Cancelled']//ancestor::table//tbody//following-sibling::tbody//tr//td[3]"), "Surveys Cancelled Column List"),

    REVV_LOCATION_SURVEY_COMPLETED_COLUMN_LIST(By.xpath("//div[text()='Surveys Completed']//ancestor::table//tbody//following-sibling::tbody//tr//td[4]"), "Surveys Completed Column List"),

    REVV_LOCATION_AGREED_TO_REVIEW_COLUMN_LIST(By.xpath("//div[text()='Agreed to Review']//ancestor::table//tbody//following-sibling::tbody//tr//td[5]"), "Agree To review Column List"),

    REVV_LOCATION_AVERAGE_RATING_COLUMN_LIST(By.xpath("//div[text()='Average Rating']//ancestor::table//tbody//following-sibling::tbody//tr//td[6]"), "Average Rating Coloumn List"),

    REVV_LOCATION_AVERAGE_RATING_ACTIVE_COLUMN_LIST(By.xpath("//div[text()='Average Rating']//ancestor::table//tbody//following-sibling::tbody//tr//td[6]//img[contains(@src,'star.svg')]//following-sibling::span[text()]"), "Average Rating Coloumn Active List"),


    ;

    /**
     * The description.
     */
    private String xpath, description;

    /**
     * The by locator.
     */
    private By byLocator;

    /**
     * Instantiates a RevvTabLocationsPageEnum.
     *
     * @param byLocator   the by locator
     * @param description the description
     */
    private RevvTabLocationsPageEnum(By byLocator, String description) {

        this.byLocator = byLocator;
        this.description = description;
    }

    /**
     * Instantiates a RevvTabLocationsPageEnum.
     *
     * @param xpath       the xpath
     * @param description the description
     */
    private RevvTabLocationsPageEnum(String xpath, String description) {

        this.xpath = xpath;
        this.description = description;
    }

    /**
     * Gets the by locator.
     *
     * @return the by locator
     */
    public By getByLocator() {

        return this.byLocator;
    }

    /**
     * Gets the xpath.
     *
     * @return the xpath
     */
    public String getXpath() {

        return xpath;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {

        return this.description;
    }
}

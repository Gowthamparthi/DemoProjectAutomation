package com.rallio.automation.newrallio.business;

import com.rallio.automation.common.enums.*;
import com.rallio.automation.core.manager.*;
import com.rallio.automation.newrallio.enums.*;
import com.rallio.automation.newrallio.pages.*;
import org.openqa.selenium.support.*;

public class ContentSchedulerPageLogic {

    private static ContentSchedulerPageLogic contentSchedulerPageLogic = null;

    private static ContentTabSchedulerPage  contentTabSchedulerPage= PageFactory.initElements(DriverManager.getDriver(), ContentTabSchedulerPage.class);


    /**
     * Creates the instance.
     *
     * @return the ContentCreatorPage
     */
    public final static ContentSchedulerPageLogic createInstance() {

        if (contentSchedulerPageLogic == null) {
            contentSchedulerPageLogic = new ContentSchedulerPageLogic();
        }
        return contentSchedulerPageLogic;
    }

    public String addSchedulerTimeAndSource(int mins, String sourceListName, String alreadyAddedTime) {

        if (alreadyAddedTime != null) {
            contentTabSchedulerPage.clickElementWithHover(ContentTabSchedulerPageEnum.SCHEDULER_HIGHLIGHTED_DAY_WITH_TIME, alreadyAddedTime);
        }
        String addedTime = contentTabSchedulerPage.addingSchedulerTime(mins,sourceListName);

        return addedTime;
    }

    public String scheduleTimeOnSchedulerUpdate(int mins, String alreadyAddedTime) {

        if (alreadyAddedTime != null) {
            contentTabSchedulerPage.clickElementWithHover(ContentTabSchedulerPageEnum.SCHEDULER_HIGHLIGHTED_DAY_WITH_TIME, alreadyAddedTime);
        }
        String addedTime = contentTabSchedulerPage.scheduleTimeOnSchedulerUpdate(mins);

        return addedTime;
    }

    public String upateSchedulerTimeAndSource(int mins, String sourceListName, String alreadyAddedTime) {

        if (alreadyAddedTime != null) {
            contentTabSchedulerPage.clickElementWithHover(ContentTabSchedulerPageEnum.SCHEDULER_HIGHLIGHTED_DAY_WITH_TIME, alreadyAddedTime);
        }
        String addedTime = contentTabSchedulerPage.scheduleTimeOnSchedulerUpdate(mins);
        contentTabSchedulerPage.clickElementWithHover(ContentTabSchedulerPageEnum.SCHEDULER_HIGHLIGHTED_DAY_WITH_TIME, addedTime);
        contentTabSchedulerPage.updatescheduleSourceAndDate(sourceListName);

        return addedTime;
    }


   public void deleteCreatedScheduler(String addedTime){
       contentTabSchedulerPage.clickElementWithHover(ContentTabSchedulerPageEnum.SCHEDULER_HIGHLIGHTED_DAY_WITH_TIME, addedTime);
       contentTabSchedulerPage.scheduleTimeDelete(addedTime);
   }

   public boolean schedulerInDiableState(String addedTime){
       return contentTabSchedulerPage.shortDisplayed(Timeout.FIVE_SEC, ContentTabSchedulerPageEnum.SCHEDULER_HIGHLIGHTED_DAY_WITH_TIME_DISABLE, addedTime);
   }

}

package com.rallio.automation.newrallio.business;

import com.rallio.automation.core.manager.*;
import com.rallio.automation.newrallio.pages.*;
import org.openqa.selenium.support.*;

public class ContentSupplierLogic {

    private static ContentSupplierLogic contentSupplierLogic = null;

    private ContentTabPostsPage contentTabPostsPage= PageFactory.initElements(DriverManager.getDriver(),ContentTabPostsPage.class);

    private ContentSupplierPage contentSupplierPage= PageFactory.initElements(DriverManager.getDriver(),ContentSupplierPage.class);

    private ContentSupplierLogic() {

    }

    /**
     * Creates the instance.
     *
     * @return the ContentMediaPage
     */
    public final static ContentSupplierLogic createInstance() {

        if (contentSupplierLogic == null) {
            contentSupplierLogic = new ContentSupplierLogic();
        }
        return contentSupplierLogic;
    }

    public boolean openContentSupplierSelectorAndSelectList(String name){

        boolean listselected = contentSupplierPage.openContentSupplierSelectorAndSelectList(name);

        return listselected;
    }



}

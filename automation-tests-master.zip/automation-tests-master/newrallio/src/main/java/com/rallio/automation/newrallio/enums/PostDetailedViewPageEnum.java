package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum PostDetailedViewPageEnum.
 */
public enum PostDetailedViewPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//div[contains(@class,'post-detailed__main')]//div[@class='post__white--box pt-details']"),
			"The page load"),

	ACTIVE_IMAGE_OR_VIDEOSECTION(By.xpath("//button[@class='nav-link active']//ancestor::div[@class='post__white--box pt-details']//div[@class='fade tab-pane active show']//div[@class='lv-assets']"),"Active Image Section"),


	/** Details tab. */
	DETAILS_TAB(By.xpath("//button[@id='social-ed-tabs-tab-details']"), "Details tab"),

	/** PostName. */
	POST_NAME(By.xpath(
			"//div[@class='post__white--box pt-details']//div[@class='fade tab-pane active show']//p[@class='post-message']"),
			"PostName"),

	SOCIAL_MEDIA_ICON(By.xpath("//div[@class='icon-tabs']//*[local-name()='ul' and contains(@class,'nav-tabs')]"),
			"Social media Icon"),

	PROFILE_PICTURE(By.xpath("//div[@class='fade tab-pane active show']//div[@class='round-asset']//span[@class='round__asset--txt']"), "Profile Picture"),

	LOCATION_NAME(By.xpath("//div[@class='fade tab-pane active show']//h3[@class='user__info--title']"), "Location Name"),

	DATE_AND_TIME_POSTED(By.xpath(
			"//div[@class='fade tab-pane active show']//div[@class='li-top g-10']//div[@class='user__sub--title']//span//following-sibling::span[@class='lvt-txt']"),
			"Date And Time Posted"),

	IMAGES_OR_VIDEO(By.xpath("//div[@class='fade tab-pane active show']//div[@class='lv-assets']"), "Images Or Video"),

	POST_LINK(By.xpath("//div[@class='li-base msg-wrapper']//a"), "Post Link"),

	PREVIOUS_BUTTON(By.xpath("//div[@class='media-features']//button//span[text()='Previous']"), "Previous Button"),

	NEXT_BUTTON(By.xpath("//div[@class='media-features']//button//span[text()='Next']"), "Previous Button"),

	EDIT_POST_BUTTON(By.xpath("//button[@class='ac-btn ac-primary size-sm r-ml2' and text()='Edit Post']"),
			"EDIT Post Button"),

	/** Package id. */
	PACKAGE_ID(By.xpath("//div[contains(@class,'wb-f-main')]//div[@class='wbf-inputs']//span[@class='wbfi-txt']"),
			"Package id"),

	/** Status. */
	STATUS(By.xpath(
			"//div[@class='wbf-item']//span[@class='wbf-label' and text()='Status']//parent::div//following-sibling::div//span[text()]"),
			"Status"),

	SCHEDULED_STATUS(By.xpath("//div[@class='wbf-item']//span[@class='wbf-label' and text()='Scheduled']//parent::div//following-sibling::div//span[text()]"),"Scheduled Status"),
	
	TAGS_FIELD(By.xpath("//div[@class='wbf-item']//span[@class='wbf-label' and text()='Tags']"),"Tags Field"),
	
	/** Created on. */
	CREATED_ON(By.xpath(
			"//div[@class='wbf-item']//span[@class='wbf-label' and text()='Created on']//parent::div//following-sibling::div//span[text()]"),
			"Created on"),

	CREATED_BY(By.xpath(
			"//div[@class='wbf-item']//span[@class='wbf-label' and text()='Created by']//parent::div//following-sibling::div//span[text()]"),
			"Created BY"),

	/** Tags. */
	TAGS("//div[@id='pd-tabs-tabpane-details']//div[@class='adcl-item']//h3[text()='Tags']//parent::div//following-sibling::div//span[text()='%s']",
			"Tags"),

	POST_TAGS_FIELD("//div[contains(@class,'post-detailed__main')]//div[@class='wb-fields']//span[@class='wbft-txt fav-tags' and text()='%s']","Tags Field"),

	/** Internal notes tab. */
	INTERNAL_NOTES_TAB(By.xpath("//button[@id='social-ed-tabs-tab-comments']"), "Internal notes tab"),

	/** Add internal notes. */
	ADD_INTERNAL_NOTES(
			By.xpath("//div[contains(@class,'post-detailed__main')]//textarea[@placeholder='Add Internal Note']"),
			"Add internal notes"),

	/** The internal note send button. */
	INTERNAL_NOTE_SEND_BUTTON(By.xpath(
			"//div[contains(@class,'post-detailed__main')]//textarea[@placeholder='Add Internal Note']//preceding-sibling::button"),
			"InternalNote send button"),

	/** Added internal notes. */
	ADDED_INTERNAL_NOTES(
			"//div[contains(@class,'post-detailed__main')]//div[@class='cmi']//textarea[@placeholder='Internal Notes' and text()='%s']",
			"Added internal notes"),

	/** The detailedview close button. */
	DETAILEDVIEW_CLOSE_BUTTON(
			By.xpath("//div[contains(@class,'post-detailed')]//div//img[contains(@src,'xmark.svg') and @alt='close']"),
			"DetailedView close button"),

	/** The previous post button. */
	PREVIOUS_POST_BUTTON(By.xpath(
			"//div[contains(@class,'post-detailed__main')]//div[contains(@class,'post__white--box')]//button//span[text()='Previous']"),
			"Previous post button"),

	/** The next post button. */
	NEXT_POST_BUTTON(By.xpath(
			"//div[contains(@class,'post-detailed__main')]//div[contains(@class,'post__white--box')]//button//span[text()='Next']"),
			"Next post button"),

	/** Delete button. */
	DELETE_BUTTON(By.xpath("//div[contains(@class,'btn-ac--wrp')]//button[text()='Delete']"), "Delete button"),

	/** Delete alert cancel button. */
	DELETE_ALERT_CANCEL_BUTTON(By.xpath("//div[@class='modal-btn-grp-wraps']//button[text()='Cancel']"),
			"Delete alert cancel button"),

	/** Delete alert delete button. */
	DELETE_ALERT_DELETE_BUTTON(By.xpath("//div[@class='modal-btn-grp-wraps']//button[text()='Delete']"),
			"Delete alert delete button"),

	/** Edit button. */
	EDIT_BUTTON(By.xpath("//div[contains(@class,'btn-ac--wrp')]//button[text()='Edit/Schedule Post' or text()='Edit']"),
			"Edit button"),

	DISABLE_SCHEDULE_BUTTON(By.xpath("//div[contains(@class,'btn-ac--wrp')]//button[contains(@class,'ac-btn ac-primary size-sm button-opacity ') and text()='Schedule']"),"Disable Schedule Button"),
	
	/** The schedule button. */
	SCHEDULE_BUTTON(By.xpath("//div[contains(@class,'btn-ac--wrp')]//button[text()='Schedule']"), "Schedule button"),

	SCHEULE_DETAILVIEW(By.xpath(
			"//div[@class='modal-content']//div[@class='modal-body']//div[@class='react-datepicker']//following-sibling::div[@class='react-datepicker__input-time-container']"),
			"Schedule Detalview"),

	DATE_PICKER(
			"//div[contains(@class,'react-datepicker__day react-datepicker__day') and not(contains(@class,'react-datepicker__day--disabled')) and text()='%s']",
			"Schedule Current Date"),

	/** The next month. */
	NEXT_MONTH_PICKER(By.xpath("//button[contains(@class,'datepicker__navigation--next')]"), "Next month."),

	SCHEDULE_POST_BUTTON(By.xpath("//div[@class='react-ripples ac-primary-box']//button[text()='Schedule post']"),
			"Schedule Post Button"),

	INACTIVE_SCHEDLE_BUTTON(
			By.xpath("//button[@class='ac-btn ac-primary size-sm button-opacity r-ml2' and text()='Schedule']"),
			"Inactive Schedule Button"),

	SCHEDULE_SUCCESS_POPUP(
			By.xpath("//span[text()='We’ve scheduled your post and saved it in your database for later use']"),
			"SCHEDULE SUCCESS POPUP"),

	/** The copy button. */
	COPY_BUTTON(By.xpath("//div[contains(@class,'btn-ac--wrp')]//button[text()='Copy']"), "Copy button"),

	CANCEL_AND_PENDING_APPROVAL_BUTTON(
			By.xpath("//button[@class='ac-btn ac-primary size-sm r-ml2' and text()='Cancel Pending Approval']"),
			"Cancel And Pending Approval"),

	/** The awaiting approval instagram button. */
	AWAITING_APPROVAL_INSTAGRAM_BUTTON(
			By.xpath("//li[@class='nav-item']//button[@id='detailed-tabs-tab-instagram' and text()='instagram']"),
			"The Awaiting Approval Instagram Button"),

	/** The awaiting approval linkedin button. */
	AWAITING_APPROVAL_LINKEDIN_BUTTON(
			By.xpath("//li[@class='nav-item']//button[@id='detailed-tabs-tab-linkedin' and text()='linkedin']"),
			"The Awaiting Approval Linkedin Button "),

	/** The awaiting approval facebook button. */
	AWAITING_APPROVAL_FACEBOOK_BUTTON(
			By.xpath("//li[@class='nav-item']//button[@id='detailed-tabs-tab-facebook' and text()='facebook']"),
			"The Awaiting Approval facebook Button"),

	/** The awaiting approval twitter button. */
	AWAITING_APPROVAL_TWITTER_BUTTON(
			By.xpath("//li[@class='nav-item']//button[@id='detailed-tabs-tab-twitter' and text()='twitter']"),
			"The Awaiting Approval twitter Button"),

	AWAITING_APPROVAL_STATUS(By.xpath(
			"//div[@class='pd-field-group']//span[text()='Status']//parent::div//parent::div//div[@class='wbf-inputs']//img[contains(@src,'pending-filled.svg')]//parent::div//following-sibling::span[text()='Awaiting Approval']"),
			"Status OF Awaiting Approval"),

	/** The awaiting approval ai generated status. */
	AWAITING_APPROVAL_AI_GENERATED_STATUS(By.xpath(
			"//div[@class='pd-field-group']//span[text()='Status']//parent::div//parent::div//div[@class='wbf-inputs']//img[contains(@src,'pending-filled.svg')]//parent::div//following-sibling::span[text()='Awaiting Approval - AI Generated']"),
			"Status OF Awaiting AI Generated"),

	/** The ai autogenerated content status. */
	AI_AUTOGENERATED_CONTENT_STATUS(By.xpath(
			"//div[@class='pd-field-group']//span[text()='Created by']//parent::div//following-sibling::div//span[text()='AI AutoGeneratedContent']"),
			"Ai Autogenerated Content Status"),

	/** The ai descriptions with tags. */
	AI_DESCRIPTIONS_WITH_TAGS(By.xpath("//div[@class='li-base msg-wrapper']//span[@class='hngfxw3']//span"),
			"Ai Descriptions with Tags"),

	/** The detailview image. */
	DETAILVIEW_IMAGE(By.xpath(
			"//p[text()]//parent::div//ancestor::div[@class='fade tab-pane active show']//div[@class='lv-assets']//div[@class='slider-wrapper axis-horizontal']"),
			"Detail View Image"),

	DRAFT_STATUS(By.xpath("//div[@class='wbf-item']//following-sibling::span[text()='Draft']"), "Draft Status"),

	APPROVED_STATUS(By.xpath("//div[@class='wbf-item']//following-sibling::span[text()='Approved & Unused']"),
			"Approved Status"),

	APPROVED_AND_UNUSED_STATUS(By.xpath("//div[@class='wbf-item']//following-sibling::span[text()='Approved & Unused']"),
			"Approved and unused Status"),

	SAVE_BUTTON(By.xpath("//button[contains(@class,'ac-btn ac-primary') and text()='Save']"), "Save Button"),

	REJECT_BUTTON(By.xpath("//button[contains(@class,'ac-btn ac-danger size-sm') and text()='Reject']"),
			"Reject Button"),

	POST_REJECTED_POPUP(By.xpath("//span[text()='Post Rejected']"), "Post Rejected Popups"),

	/** The awaiting approval locationcontent filter. */
	AWAITING_APPROVAL_LOCATIONCONTENT_FILTER(By.xpath(
			"//input[@name='status-Status']//following-sibling::span[text()='Awaiting Approval (Location Content)']"),
			"AwaitingApproval LocationContent filter"),

	SCHEDULE_ALERT_MESSAGE(By.xpath("//div[@class='modal-message-wraps-text']"), "Schedule Alert Message"),

	SCHEDULE_ALERT_MESSAGE_OK_BUTTON(By.xpath("//div[@class='react-ripples ac-primary-box']//button[text()='OK']"),
			"SCHEDULE_ALERT_MESSAGE_OK_BUTTON"),

	SYNDICATE_BUTTON(By.xpath("//div[@class='react-ripples csv-ripple']//button[text()='Syndicate']"),
			"Syndicate Button"),

	POST_LAST_SYNDICTAED_SECTION(
			By.xpath("//span[@class='wbf-label' and text()='Last Syndicated']//parent::div[@class='wbf-label-main']"),
			"Last Syndicated Section"),

	POST_LAST_SYNDICATED_SECTION_DATE(By.xpath(
			"//span[@class='wbf-label' and text()='Last Syndicated']//following::div[@class='wbfi-items flex-wrap']//span[@class='wbfi-txt me-2']"),
			"Last Syndicated Section Date"),

	POST_LAST_SYNDICATED_SECTION_LOCATION_LIST(By.xpath(
			"//span[@class='wbf-label' and text()='Last Syndicated']//following::div[@class='wbfi-items flex-wrap']//span[contains(@class,'wbfi-txt')]"),
			"Last Syndicate Section Location List"),

	POST_DETAILVIEW_LAST_SYNDICATED_LIST(By.xpath("//span[@class='wbf-label' and text()='Last Syndicated']//following::div[@class='wbfi-items flex-wrap']//span[contains(@class,'wbfi-txt') and not(@class='wbfi-txt me-2')]"),"POST_DETAILVIEW_LAST_SYNDICATED_LIST"),

	POST_LAST_SYNDICATED_SECTION_LOCATION(
			"//span[@class='wbf-label' and text()='Last Syndicated']//following::div[@class='wbfi-items flex-wrap']//span[@class='wbfi-txt blue-text cur-pointer' and text()='%s']",
			"LAST_SYNDICATED_SECTION_LOCATION"),

	/** The approve button. */
	APPROVE_BUTTON(By.xpath("//div[contains(@class,'btn-ac--wrp')]//button[text()='Approve']"), "Approve button"),
	// **POST Published History**//

	PUBLISHING_HISTORY_SEARCH(By.xpath("//div[@class='dpp-status dp-search-active']//div[@class='react-tags__search-input']//input"),"Publishing History Search"),

	PUBLISHING_HISTORY_BUTTON(
			By.xpath("//button[@id='social-ed-tabs-tab-publish_status' and contains(text(),'Publishing Histor')]"),
			"Publishing history Button"),

	PUBLISHING_HISTORY_TABLE(By.xpath("//div[@id='social-ed-tabs-tabpane-publish_status']//table[contains(@class,'table-cmn--skeleton responsiveTable')]"),
			"Publishing history table"),

	PUBLISHING_HISTORY_SOCIAL_MEDIA_ICONS(By.xpath(
			"//table[@class='table-cmn--skeleton responsiveTable if-scroll-inactive table']//th//div[contains(@class,'dp-icons')]//img[@class='social-media']"),
			"Publishing History Post Social Media Icons"),

	PUBLISHING_HISTORY_POST_STATUS_FIELD("//span[text()]//parent::td//following-sibling::td//span//img[contains(@src,'%s')]", "Publishing History Post Status"),

	PUBLISHING_HISTORY_POST_STATUS_GREEN(By.xpath("//span[@class='dps-note']//parent::td//following-sibling::td//span//img[contains(@src,'active-green.svg')]"),
			"Publishing History Post Status Green"),

	PUBLISHING_HISTORY_POST_STATUS_GREY(By.xpath(
			"//span[text()]//parent::td//following-sibling::td//span//img[contains(@src,'deactive-grey.svg')]"),
			"Publishing History Post Status Grey"),

	PUBLISHING_HISTORY_POST_WARNING_STATUS(By.xpath("//span[text()]//parent::td//following-sibling::td//span//img[contains(@src,'warning.svg')]"),"PUBLISHING_HISTORY_POST_WARNING_STATUS"),

	PUBLISHING_HISTORY_POST_STATUS_YELLOW(By.xpath("//span[text()]//parent::td//following-sibling::td//span//img[contains(@src,'yellowCircle.svg')]"),
			"Publishing History Post Status Yellow"),

	PUBLISHING_HISTORY_YELLOW_STATUS_PLATFORM("(//span[@class='dps-note']//parent::td//following-sibling::td//span//img[contains(@src,'yellowCircle.svg')])[%s]","Publishing history - Yellow Status Platform"),

	PUBLISHING_HISTORY_BEFORE_STATUS_GREEN_TOOLTIP(
			By.xpath("//div[@class='rc-tooltip-inner']//div[text()='The post is scheduled. ']"),
			"Publishing History Before Status Green Tooltip"),

	PUBLISHING_HISTORY_REJECTED_UNAPPROVED_STATUS_TOOLTIP(By.xpath("//div[@class='common-tooltip--wrp' and text()='The post was rejected or is awaiting approval. ']"),"PUBLISHING_HISTORY_REJECTED_UNAPPROVED_STATUS_TOOLTIP"),

	PUBLISHING_HISTORY_GREEN_STATUS_WITH_LOCATION("//div[text()='%s']//parent::div//ancestor::td[@class='psw-td-data psw-loc-td sort-active ']//following-sibling::td//img[@alt='active-green']","Publishing History Green Status With Location"),

	PUBLISHING_HISTORY_AFTER_STATUS_GREEN_TOOLTIP(
			By.xpath("//div[@class='common-tooltip--wrp' and contains(text(),'Post published successfully')]"),
			"Publishing History After Status"),

	PUBLISHING_HISTORY_TWITTER_GREY_STATUS(
			By.xpath("//img[@alt='Twitter']//ancestor::table//tbody//td[4]//img[@alt='deactive-grey']"),
			"Publishing History Twitter Grey Status"),

	PUBLISHING_HISTORY_LINKEDIN_GREY_STATUS(
			By.xpath("//img[@alt='LinkedIn']//ancestor::table//tbody//td[5]//img[@alt='deactive-grey']"),
			"Publishing History Linkedin Grey Status"),

	PUBLISHING_HISTORY_GOOGLEPLUS_GREY_STATUS(
			By.xpath("//img[@alt='GooglePlus']//ancestor::table//tbody//td[6]//img[@alt='deactive-grey']"),
			"Publishing History GooglePlus Grey Status"),

	PUBLISHING_HISTORY_INSTAGRAM_GREY_STATUS(
			By.xpath("//img[@alt='Instagram']//ancestor::table//tbody//td[7]//img[@alt='deactive-grey']"),
			"Publishing History Instagram Grey Status"),

	PUBLISHING_HISTORY_TWITTER_GREY_TOOLTIP(
			By.xpath("//div[@class='common-tooltip--wrp' and contains(text(),'Location not connected to X (Formerly Twitter)')]"),
			"Publishing History Twitter Grey ToolTip"),

	PUBLISHING_HISTORY_LINKEDIN_GREY_TOOLTIP(
			By.xpath("//div[@class='common-tooltip--wrp' and contains(text(),'LinkedIn not enabled for this post.')]"),
			"Publishing History Linkedin Grey ToolTip"),

	PUBLISHING_HISTORY_GOOGLEPLUS_GREY_TOOLTIP(
			By.xpath("//div[@class='common-tooltip--wrp' and contains(text(),'Location not connected to Google.')]"),
			"Publishing History Googleplus Grey ToolTip"),

	PUBLISHING_HISTORY_INSTAGRAM_GREY_TOOLTIP(
			By.xpath("//div[@class='common-tooltip--wrp' and contains(text(),'Instagram not enabled for this post.')]"),
			"Publishing History Instagram Grey ToolTip"),
	
	/** Publishing history - Location, date and time . */
	PUBLISHING_HISTORY_HEADER_LOCATION_DATE_AND_TIME(By.xpath(
			"//table[contains(@class,'table-cmn--skeleton')]//div[@class='dp-fc-head-top']//span[@class='fc-head-item' and contains(text(),'Location')]//parent::div//parent::div//span[@class='dp-subHead' and text()='Date and Time']"),
			"Publishing history - Location, date and time ."),
	
	/** Publishing history - Notes */
	PUBLISHING_HISTORY_HEADER_NOTE(By.xpath(
			"//table[contains(@class,'table-cmn--skeleton')]//th[@class='psw-th-head psw-note-th']//span[@class='fc-head-item' and contains(text(),'Note')]"),
			"Publishing history - Note"),
	
	/** Publishing history - Facebook icon */
	PUBLISHING_HISTORY_FACEBOOK_ICON(By.xpath(
			"//table[contains(@class,'table-cmn--skeleton responsiveTable')]//th//div[contains(@class,'dp-icons')]//img[@class='social-media' and @alt='Facebook']"),
			"Publishing history - Facebook icon"),
	
	/** Publishing history - Twitter icon */
	PUBLISHING_HISTORY_TWITTER_ICON(By.xpath(
			"//table[contains(@class,'table-cmn--skeleton responsiveTable')]//th//div[contains(@class,'dp-icons')]//img[@class='social-media' and @alt='Twitter']"),
			"Publishing history - Twitter icon"),
	
	/** Publishing history - Linkedin icon */
	PUBLISHING_HISTORY_LINKEDIN_ICON(By.xpath(
			"//table[contains(@class,'table-cmn--skeleton responsiveTable')]//th//div[contains(@class,'dp-icons')]//img[@class='social-media' and @alt='LinkedIn']"),
			"Publishing history - Linkedin icon"),
	
	/** Publishing history - Google icon */
	PUBLISHING_HISTORY_GOOGLE_ICON(By.xpath(
			"//table[contains(@class,'table-cmn--skeleton responsiveTable')]//th//div[contains(@class,'dp-icons')]//img[@class='social-media' and @alt='GooglePlus']"),
			"Publishing history - Google icon"),
	
	/** Publishing history - Instagram icon */
	PUBLISHING_HISTORY_INSTAGRAM_ICON(By.xpath(
			"//table[contains(@class,'table-cmn--skeleton responsiveTable')]//th//div[contains(@class,'dp-icons')]//img[@class='social-media' and @alt='Instagram']"),
			"Publishing history - Instagram icon"),
	
	/** Publishing history - No data to show */
	PUBLISHING_HISTORY_NO_TABLE_DATA(By.xpath(
			"//table[contains(@class,'table-cmn--skeleton')]//tbody//td[@class='text-center' and text()=' No Data to show']"),
			"Publishing history - No data to show"),
	
	/** Publishing history - Location, date and time in table view*/
	PUBLISHING_HISTORY_LOCATION_DATE_AND_TIME_AT_TABLE(By.xpath(
			"//table[contains(@class,'table-cmn--skeleton')]//td[contains(@class,'psw-td-data')]//div[@class='loc-right']//div[@class='loc-name']"),
			"Publishing history - Location, date and time in table view"),
	
	/** Publishing history - Note in table view*/
	PUBLISHING_HISTORY_NOTE_AT_TABLE(By.xpath(
			"//table[contains(@class,'table-cmn--skeleton')]//td[@class='psw-td-data psw-note-td ']//span"),
			"Publishing history - Note in table view"),
	
	/** Publishing history - search option*/
	PUBLISHING_HISTORY_SEARCH_OPTION(By.xpath(
			"//div[@class='dpp-status dp-search-active']//div[@class='react-tags__search']//input[@type='text']"),
			"Publishing history - search option"),

	POST_NAME_FIELD("//div[@class='li-base msg-wrapper']//p[contains(text(),\"%s\")]","Post Name "),

	POST_DETAILVIEW_NAME("//div[@class='li-base msg-wrapper']//p[contains(@title,\"%s\")]","Post Name "),

	/** Publishing history - Location, date and time sort option*/
	PUBLISHING_HISTORY_LOCATION_DATE_AND_TIME_SORT_OPTION(By.xpath(
			"//table[contains(@class,'table-cmn--skeleton')]//div[@class='dp-fc-head-top']//img[@alt='Sort']"),
			"Publishing history - Location, date and time sort option"),

	SOURCE_FIELD("//span[@class='wbf-label' and text()='Source']//parent::div[@class='wbf-label-main']//following-sibling::div//span[@class='wbfi-txt' and text()='%s']","Source Field"),

	SOURCE(By.xpath("//span[@class='wbf-label' and text()='Source']//parent::div[@class='wbf-label-main']//following-sibling::div//span[@class='wbfi-txt']"),"Source"),

	POST_DETAILVIEW_AVAILABILITY_ACTIVE("//span[text()='Availability']//parent::div//following-sibling::div//label[contains(@class,'active')]//input[@class='option-input radio']//following-sibling::span[text()='%s']","Post Detail View Availability Active"),

	POST_DETAILVIEW_AVAILABILITY_INACTIVE("//span[text()='Availability']//parent::div//following-sibling::div//label[contains(@class,'in-active')]//input[@class='option-input radio']//following-sibling::span[text()='%s']","Post Detail View Availability Active"),

	POST_DETAILVIEW_CUSTOM_START_DATE(By.xpath("//span[text()='Custom']//ancestor::div[@class='wbf-inputs']//span[@class='fltlabels start' and text()='Start Date']//parent::div//input[contains(@class,'fltr-from-date')]"),"Post Detailview Custom Start Date"),

	POST_DETAILVIEW_CUSTOM_END_DATE(By.xpath("//span[text()='Custom']//ancestor::div[@class='wbf-inputs']//span[@class='fltlabels end' and text()='End Date']//parent::div//input[contains(@class,'fltr-from-date')]"),"Post Detailview Custom End Date"),

    POST_DETAILVIEW_ALWAYS_AVAILABLE(By.xpath("//span[text()='Availability']//parent::div//parent::div//span[text()='Always Available']"),"Post Detailview Always Available"),

	POST_DETAILVIEW_AVAILABILITY_DATE(By.xpath("//span[text()='Availability']//parent::div//parent::div//span[@class='wbfi-txt']"),"Post Detailview Availability Date"),

	POST_DETAILVIEW_AVAILABLITY_DATE_FIELD("//span[text()='Availability']//parent::div//parent::div//span[@class='wbfi-txt' and text()='%s']","Date Availability Field"),

	PUBLISHING_HISTORY_GREEN_STATUS_PLATFORM("(//span[@class='dps-note']//parent::td//following-sibling::td//span//img[contains(@src,'active-green.svg')])[%s]","Publishing history - Green Status Platform"),

	POST_DETAILVIEW_PLATFORM_INUSE(By.xpath("//div[contains(@class,'mg-detailed post-detailed')]//li[@class='nav-item']//button[@class='nav-link' and contains(@aria-controls,'detailed-tabs-tabpane')]"),"Post Detailview Platform In Use"),

	POST_DETAILVIEW_PLATFORM_INUSE_FIELD("(//div[contains(@class,'mg-detailed post-detailed')]//li[@class='nav-item']//button[@class='nav-link' and contains(@aria-controls,'detailed-tabs-tabpane')])[%s]","Post Detailview Platform In Use"),

	;

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new post detailed view page enum.
	 *
	 * @param byLocator   the by locator
	 * @param description the description
	 */
	private PostDetailedViewPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new post detailed view page enum.
	 *
	 * @param xpath       the xpath
	 * @param description the description
	 */
	private PostDetailedViewPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

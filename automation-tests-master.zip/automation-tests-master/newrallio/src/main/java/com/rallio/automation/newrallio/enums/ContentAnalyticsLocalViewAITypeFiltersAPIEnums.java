package com.rallio.automation.newrallio.enums;

public enum ContentAnalyticsLocalViewAITypeFiltersAPIEnums {

	SOCIAL_MEDIA_AI_TYPE_TOTAL_POSTS_API("Domain_Name/activate_local_api/enduser_%s_post_stat_rows?ancestor_franchisor_id=%s&content_id=&per=100&by[key]=posted_at&by[direction]=desc&date_range[]=%s&date_range[]=%s&page=1&include_totals=1&parent_%s_post_id=", "SOCIAL_MEDIA_AI_TYPE_POSTS_API"),
	
	SOCIAL_MEDIA_AI_TYPE_TOTAL_REELS_POSTS_API("Domain_Name/activate_local_api/enduser_%s_post_stat_rows?ancestor_franchisor_id=%s&content_id=&per=100&by[key]=posted_at&by[direction]=desc&date_range[]=%s&date_range[]=%s&page=1&include_totals=1&reels=1&parent_%s_post_id=", "SOCIAL_MEDIA_AI_TYPE_TOTAL_REELS_POSTS_API"),

	SOCIAL_MEDIA_AI_TYPE_TOTAL_TAGS_POSTS_API("Domain_Name/activate_local_api/enduser_%s_post_stat_rows?ancestor_franchisor_id=%s&content_id=&per=100&by[key]=posted_at&by[direction]=desc&date_range[]=%s&date_range[]=%s&page=1&include_totals=1&tag_list=1&parent_%s_post_id=", "SOCIAL_MEDIA_AI_TYPE_TOTAL_TAGS_POSTS_API"),
	
	SOCIAL_MEDIA_AI_TYPE_POSTS_FILTER_API("Domain_Name/activate_local_api/enduser_%s_post_stat_rows?ancestor_franchisor_id=%s&content_id=&per=100&by[key]=posted_at&by[direction]=desc&date_range[]=%s&date_range[]=%s&page=1&include_totals=1&ai_post=%s&parent_%s_post_id=", "SOCIAL_MEDIA_AI_TYPE_POSTS_API"),

	SOCIAL_MEDIA_AI_TYPE_TAGS_POSTS_FILTER_API("Domain_Name/activate_local_api/enduser_%s_post_stat_rows?ancestor_franchisor_id=%s&content_id=&per=100&by[key]=posted_at&by[direction]=desc&date_range[]=%s&date_range[]=%s&page=1&include_totals=1&tag_list=1&ai_post=%s&parent_%s_post_id=", "SOCIAL_MEDIA_AI_TYPE_TAGS_POSTS_FILTER_API"),

	SOCIAL_MEDIA_AI_TYPE_REELS_POSTS_FILTER_API("Domain_Name/activate_local_api/enduser_%s_post_stat_rows?ancestor_franchisor_id=%s&content_id=&per=100&by[key]=posted_at&by[direction]=desc&date_range[]=%s&date_range[]=%s&page=2&include_totals=1&reels=1&ai_post=%s&parent_%s_post_id=", "SOCIAL_MEDIA_AI_TYPE_REELS_POSTS_FILTER_API"),

	
	FACEBOOK_AI_TYPE_TOTAL_POSTS_API("Domain_Name/activate_local_api/enduser_facebook_post_stat_rows?ancestor_franchisor_id=2&content_id=&per=100&by[key]=posted_at&by[direction]=desc&date_range[]=1679423400&date_range[]=1679509799&page=1&include_totals=1&parent_facebook_post_id=", "FACEBOOK_AI_TYPE_TOTAL_POSTS_API"),
	
	FACEBOOK_AI_TYPE_AI_POSTS_API("Domain_Name/activate_local_api/enduser_facebook_post_stat_rows?ancestor_franchisor_id=2&content_id=&per=100&by[key]=posted_at&by[direction]=desc&date_range[]=1679423400&date_range[]=1679509799&page=1&include_totals=1&ai_post=1&parent_facebook_post_id=", "FACEBOOK_AI_TYPE_AI_POSTS_API"),

	FACEBOOK_AI_TYPE_NON_AI_POSTS_API("Domain_Name/activate_local_api/enduser_facebook_post_stat_rows?ancestor_franchisor_id=2&content_id=&per=100&by[key]=posted_at&by[direction]=desc&date_range[]=1679423400&date_range[]=1679509799&page=1&include_totals=1&ai_post=0&parent_facebook_post_id=", "FACEBOOK_AI_TYPE_NON_AI_POSTS_API"),

	INSTAGRAM_AI_TYPE_TOTAL_POSTS_API("Domain_Name/activate_local_api/enduser_instagram_post_stat_rows?ancestor_franchisor_id=2&content_id=&per=100&by[key]=posted_at&by[direction]=desc&date_range[]=1679423400&date_range[]=1679509799&page=1&include_totals=1&parent_facebook_post_id=", "INSTAGRAM_AI_TYPE_TOTAL_POSTS_API"),
	
	INSTAGRAM_AI_TYPE_AI_POSTS_API("Domain_Name/activate_local_api/enduser_instagram_post_stat_rows?ancestor_franchisor_id=2&content_id=&per=100&by[key]=posted_at&by[direction]=desc&date_range[]=1679423400&date_range[]=1679509799&page=1&include_totals=1&ai_post=1&parent_facebook_post_id=", "INSTAGRAM_AI_TYPE_AI_POSTS_API"),

	INSTAGRAM_AI_TYPE_NON_AI_POSTS_API("Domain_Name/activate_local_api/enduser_instagram_post_stat_rows?ancestor_franchisor_id=2&content_id=&per=100&by[key]=posted_at&by[direction]=desc&date_range[]=1679423400&date_range[]=1679509799&page=1&include_totals=1&ai_post=0&parent_facebook_post_id=", "INSTAGRAM_AI_TYPE_NON_AI_POSTS_API"),

	LINKEDIN_AI_TYPE_TOTAL_POSTS_API("Domain_Name/activate_local_api/enduser_linkedin_post_stat_rows?ancestor_franchisor_id=2&content_id=&per=100&by[key]=posted_at&by[direction]=desc&date_range[]=1679423400&date_range[]=1679509799&page=1&include_totals=1&parent_facebook_post_id=", "LINKEDIN_AI_TYPE_TOTAL_POSTS_API"),
	
	LINKEDIN_AI_TYPE_AI_POSTS_API("Domain_Name/activate_local_api/enduser_linkedin_post_stat_rows?ancestor_franchisor_id=2&content_id=&per=100&by[key]=posted_at&by[direction]=desc&date_range[]=1679423400&date_range[]=1679509799&page=1&include_totals=1&ai_post=1&parent_facebook_post_id=", "LINKEDIN_AI_TYPE_AI_POSTS_API"),

	LINKEDIN_AI_TYPE_NON_AI_POSTS_API("Domain_Name/activate_local_api/enduser_linkedin_post_stat_rows?ancestor_franchisor_id=2&content_id=&per=100&by[key]=posted_at&by[direction]=desc&date_range[]=1679423400&date_range[]=1679509799&page=1&include_totals=1&ai_post=0&parent_facebook_post_id=", "LINKEDIN_AI_TYPE_NON_AI_POSTS_API");

	
	
	private String api;

	private String description;



	private ContentAnalyticsLocalViewAITypeFiltersAPIEnums(String api, String description) {

		this.api = api;
		this.description = description;

	}
	
	
	public String getAPI() {

		return api;
	}


	public String getDescription() {

		return description;
	}
	
}

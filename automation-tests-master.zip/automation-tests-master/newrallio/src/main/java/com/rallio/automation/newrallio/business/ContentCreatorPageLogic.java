package com.rallio.automation.newrallio.business;

import com.rallio.automation.common.enums.*;
import com.rallio.automation.common.util.*;
import com.rallio.automation.core.manager.*;
import com.rallio.automation.newrallio.enums.*;
import com.rallio.automation.newrallio.pages.*;
import org.openqa.selenium.support.*;
import org.testng.*;

import static com.rallio.automation.common.manager.ConfigManager.*;

public class ContentCreatorPageLogic {

    private static ContentCreatorPageLogic contentCreatorPageLogic = null;

    private static CreatePostPage createPostPage = PageFactory.initElements(DriverManager.getDriver(), CreatePostPage.class);

    private ContentCreatorPageLogic() {

    }

    /**
     * Creates the instance.
     *
     * @return the ContentCreatorPage
     */
    public final static ContentCreatorPageLogic createInstance() {

        if (contentCreatorPageLogic == null) {
            contentCreatorPageLogic = new ContentCreatorPageLogic();
        }
        return contentCreatorPageLogic;
    }

    public void creatPost(PlatformEngagementFilterEnum platform, String text) {

        switch (platform) {
            case ALL:
                createPostPage.addPostContentInAllPlatform(text);
                break;
            case FACEBOOK:
                createPostPage.addPostContent(CreatePostPageEnum.FACEBOOK_TAB, text);
                createPostPage.addImage(CreatePostPageEnum.MY_IMAGES_TAB, "", getValue("imageforPost"));
                break;
            case INSTAGRAM:
                createPostPage.addPostContentInFacebookWithInsta(text);
                break;
        }
    }

    public void creatPost(PlatformEngagementFilterEnum platform, CreatePostType type, String mediaType, String text) {

        createPostPage.addImageVideoTagLinkCoupon(type, mediaType);
        switch (platform) {
            case ALL:
                createPostPage.addPostContentInAllPlatform(text);
                break;
            case FACEBOOK:
                createPostPage.addPostContent(CreatePostPageEnum.FACEBOOK_TAB, text);
                break;
        }
    }

    public void creatPostwithInternalTag(PlatformEngagementFilterEnum platform, String postText, String tag) {
        creatPost(platform, postText);
        createPostPage.addInternalTags(tag);
    }

    public void publishingType(String postName, CreatePostType postType) {
        switch (postType) {
            case POST_NOW:
                createPostPage.createPost(postName, CreatePostType.POST_NOW);
                break;
        }
    }

    public void publishingBrandSchedule(CreatePostPageEnum type, String date, String time, String location) {

        switch (type) {
            case ALL_LOCATIONS_OPTION:
                createPostPage.clickElement(CreatePostPageEnum.ALL_LOCATIONS_OPTION);
                createPostPage.schedulePostByDateAndTime(date, time);
                Assert.assertTrue(createPostPage.isDisplayed(CreatePostPageEnum.POST_SAVED_SUCCESS_MESSAGE));
                break;
            case SPECIFIC_LOCATIONS_OPTION:
                if (location != null) {
                    createPostPage.selectSpecificLocationDateAndTime(location, date, time);
                    createPostPage.clickElement(CreatePostPageEnum.BRAND_SCHEDULE_SECTION_SCHEDULE_BUTTON);
                    Assert.assertTrue(createPostPage.isDisplayed(CreatePostPageEnum.POST_SAVED_SUCCESS_MESSAGE));
                }
                break;
        }

    }

    public void syndicateContentSupplierPost(CreatePostPageEnum locationType, String locationName) {
        createPostPage.syndicateContentSuppliers(locationType, locationName);

    }

    public void schedulePostWithDateAndTime(String time, String date) {

        createPostPage.clickCreatePostPageElement(CreatePostPageEnum.SCHEDULE_POST_BUTTON);
        createPostPage.schedulePostWithDateAndTime(time, date);
    }

    public void addAllLocalizeContentToPost(CreatePostType type, String mediaName, String postName) {

        creatPost(PlatformEngagementFilterEnum.FACEBOOK, type, mediaName, postName);
        createPostPage.clickCreatePostPageElement(CreatePostPageEnum.LOCALIZE_POST_BUTTON);
        createPostPage.addAllLocalizePost();
        createPostPage.copyPostContentByPlatform(CreatePostPageEnum.INSTAGRAM_TAB, CreatePostPageEnum.ADD_CONTENT_FROM_FACEBOOK, postName);
        createPostPage.copyPostContent(CreatePostPageEnum.LINKEDIN_TAB, CreatePostPageEnum.ADD_CONTENT_FROM_DROPDOWN_FACEBOOK, postName);
        createPostPage.copyPostContent(CreatePostPageEnum.TIK_TOK_TAB, CreatePostPageEnum.ADD_CONTENT_FROM_DROPDOWN_FACEBOOK, postName);

    }

}



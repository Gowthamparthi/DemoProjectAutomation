package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum NowTechSignInPageEnum.
 */
public enum NowTechSignInPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//section[contains(@class,'login-section')]//form[@id='kt_login_signin_form']//img[contains(@src,'membertek-media')]"), "The page load"),

	/** The email address field. */
	EMAIL_ADDRESS_FIELD(By.xpath("//label[text()='Username']//following-sibling::input"), "Email Address field"),

	/** The password field. */
	PASSWORD_FIELD(By.xpath("//label[text()='Password']//following-sibling::input"), "Password field"),

	/** The continue button. */
	CONTINUE_BUTTON(By.xpath("//button[text()='Continue >>']"), "Continue button"),

	/** The accept button. */
	ACCEPT_BUTTON(By.xpath("//button[text()='Accept']"), "Accept button");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new now tech sign in page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private NowTechSignInPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new now tech sign in page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private NowTechSignInPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

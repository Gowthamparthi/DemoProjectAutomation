/*
 * 
 */
package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum DirectoryListingsOperationHoursEnum.
 */
public enum DirectoryListingsOperationHoursEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//div[@class='modal-content']//div[@class='card-bg bh-hours']"), "Page load"),

	/** The operation hours dropdown. */
	OPERATION_HOURS_DROPDOWN(By.xpath("//span[text()='Monday']//ancestor::div[@class='dis-flex-bhr']//select"), "Operation hours dropdown"),

	/** The start time. */
	START_TIME(By.xpath("//div[@class='dfa bhr-flex-md']//div[@class='time-holder-row']//div[@class='time-section']//div[@class='time-label'][1]"), "Start time"),

	/** The start time content. */
	START_TIME_CONTENT(By.xpath("//div[@class='dfa bhr-flex-md']//div[@class='time-holder-row']//div[@class='time-section']//div[@class='time-label'][1]//input"),
	        "Start time content"),

	/** The start time list. */
	START_TIME_LIST(By.xpath("//div[@class='dfa bhr-flex-md']//div[@class='time-label'][1]//div[@class='react-datepicker__time-container ']"), "Start time list"),

	/** The select from time. */
	SELECT_FROM_START_TIME("//div[@class='dfa bhr-flex-md']//div[@class='time-label'][1]//div[@class='react-datepicker__time-container ']//ul//li[text()='%s']",
	        "Select from time"),

	/** The start time error message. */
	START_TIME_ERROR_MESSAGE(By.xpath("//div[@class='modal-body']//div[text()='Start time can not be after end time! Please select a valid time to continue.']"),
	        "Start time error message"),

	/** The second start time. */
	SECOND_START_TIME(By.xpath("//div[@class='bh-row--wrp']//div[@class='dfa']//div[@class='time-section']//div[@class='time-label'][1]//div"), "Second start time"),

	/** The second start time list. */
	SECOND_START_TIME_LIST(By.xpath("//div[@class='dfa']//div[@class='time-label'][1]//div[@class='react-datepicker__time-container ']"), "Second start time list"),

	/** The select from second start time. */
	SELECT_FROM_SECOND_START_TIME("//div[@class='dfa']//div[@class='time-label'][1]//div[@class='react-datepicker__time-container ']//ul//li[text()='%s']",
	        "Select from second start time"),

	/** The end time. */
	END_TIME(By.xpath("//div[@class='dfa bhr-flex-md']//div[@class='time-holder-row']//div[@class='time-section']//div[@class='time-label'][2]"), "End time"),

	/** The end time content. */
	END_TIME_CONTENT(By.xpath("//div[@class='dfa bhr-flex-md']//div[@class='time-holder-row']//div[@class='time-section']//div[@class='time-label'][2]//input"),
	        "End time content"),

	/** The end time list. */
	END_TIME_LIST(By.xpath("//div[@class='dfa bhr-flex-md']//div[@class='time-label'][2]//div[@class='react-datepicker__time-container ']"), "End time list"),

	/** The select from end time. */
	SELECT_FROM_END_TIME("//div[@class='dfa bhr-flex-md']//div[@class='time-label'][2]//div[@class='react-datepicker__time-container ']//ul//li[text()='%s']",
	        "Select from end time"),

	/** The end time error message. */
	END_TIME_ERROR_MESSAGE(By.xpath("//div[@class='modal-body']//div[text()='End time can not be before start time! Please select a valid time to continue.']"),
	        "End time error message"),

	/** The second end time. */
	SECOND_END_TIME(By.xpath("//div[@class='bh-row--wrp']//div[@class='dfa']//div[@class='time-section']//div[@class='time-label'][2]//div"), "Second end time"),
	
	/** The operation hours edit. */
	OPERATION_HOURS_EDIT(
			By.xpath("//div[@class='flex-item-sm']//h5[text()='Operation Hours']//parent::div//span[text()='Edit']"),
			"Operation hours edit"),

	/** The second end time list. */
	SECOND_END_TIME_LIST(By.xpath("//div[@class='dfa']//div[@class='time-label'][2]//div[@class='react-datepicker__time-container ']"), "Second end time list"),

	/** The select from second end time. */
	SELECT_FROM_SECOND_END_TIME("//div[@class='dfa']//div[@class='time-label'][2]//div[@class='react-datepicker__time-container ']//ul//li[text()='%s']",
	        "Select from second end time"),

	/** The second time label error. */
	SECOND_TIME_LABEL_ERROR(By.xpath("//div[@class='modal-body']//div[text()='Second time slot must start after first time slot! Please select a valid time to continue.']"),
	        "Second time label error"),
	
	/** The second time label remove. */
	SECOND_TIME_LABEL_REMOVE(By.xpath("//div[@class='dfa']//div[@class='action-btn cur-pointer']//img[@alt='remove']"),"Second time label remove"),

	/** The add new button. */
	ADD_NEW_BUTTON(By.xpath("//div[@class='dis-flex-bhr']//div[@class='bhr-flex-xs']//img[@alt='add-new']"), "Add new button"),

	/** The apply for all days. */
	APPLY_FOR_ALL_DAYS(By.xpath("//div[@class='dis-flex-bhr']//div[@class='bhr-flex-xs']//button[text()='Apply for all days']"), "Apply for all days"),

	/** The save button. */
	SAVE_BUTTON(By.xpath("//div[@class='modal-body']//div[@class='card-bg bh-hours']//div[contains(@class,'d-flex')]//button[text()='Save']"), "Save button"),

	/** The close. */
	CLOSE(By.xpath("//div[@class='modal-body']//div[@class='card-bg bh-hours']//div[@class='section-header']//img[@alt='close-modal']"), "Close");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new directory listings operation hours enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private DirectoryListingsOperationHoursEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new directory listings operation hours enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private DirectoryListingsOperationHoursEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

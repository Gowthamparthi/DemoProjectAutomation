package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum FacebookPageEnum.
 */
public enum FacebookPageEnum {

	/** The pageload. */
	PAGE_LOAD(By.xpath("//body//a[@aria-label='Facebook']//ancestor::div[@class='x9f619 x1n2onr6 x1ja2u2z']"), "Page Load"),
	
	/** The social media name. */
	SOCIAL_MEDIA_NAME(By.xpath("//div[@class='tr9rh885']//h2//span[@dir='auto'][1]//span[text()]"),"Social media name"),
	
	/** The email id. */
	EMAIL_ID(By.xpath("//body[contains(@class,'login_page')]//div[@class='clearfix form_row'][1]//input"), "Input Email"),

	/** The password. */
	PASSWORD(By.xpath("//body[contains(@class,'login_page')]//div[@class='clearfix form_row'][2]//input"), "Input Password"),

	/** The facebook password section for already logged in. */
	FACEBOOK_PASSWORD_FOR_ALREADY_LOGGED_IN(By.xpath("//div[@class='popup_content_area']//td//input[@type='password']"), " The facebook password section for already logged in"),

	/** The log in button. */
	LOG_IN_BUTTON(By.xpath("//body[contains(@class,'login_page')]//div[@id='buttons']//input"), "Log In Button"),

	/** The home page button. */
	HOME_PAGE_BUTTON(By.xpath("//div[@aria-label='Facebook']//a[@aria-label='Home']//parent::div"), "Home page button"),

	/** The home page load. */
	HOME_PAGE_LOAD(By.xpath("//div[@data-pagelet='root']//h1[text()='Home']"), "Home page load"),

	/** The page content. */
	POST_CONTENT("//div[@class='x1yztbdb x1n2onr6 xh8yej3 x1ja2u2z']//div[contains(text(),'%s')]",
			"Page content"),

	LIKE_BUTTON("//div[contains(text(),'%s')]//ancestor::div[@class='x1n2onr6 x1ja2u2z']//div[@aria-label='Like']//span[text()='Like']","Like Button"),
	
	LIKE_ACTIVE("//div[contains(text(),'%s')]//ancestor::div[@class='x1n2onr6 x1ja2u2z']//div[@aria-label='Remove Like']//span[text()='Like']","Like Active"),
	
	/** The comment button. */
	COMMENT_BUTTON(
			"//div[contains(text(),'%s')]//ancestor::div//i[@data-visualcompletion='css-img']//parent::div//parent::div//span[text()='Comment']",
			"Comment button"),

	REPLY_COMMENT_POPUP_TEXT(By.xpath("//div[contains(@aria-label,'Click to add comment suggestion to comment composer')]//div//span[text()]"),"Reply Comment PoUp Text"),
	
	REPLIED_TEXT_IN_COMMAND_BOX(By.xpath("//p[@class='xdj266r x11i5rnm xat24cr x1mh8g0r xdpxx8g']"),"REPLIED_TEXT_IN_COMMAND_BOX"),
	
	WRITE_COMMAND_TEXT(By.xpath("//div[@class='x78zum5 x13a6bvl']//div[contains(@class,'xi81zsa')]"),"Write a command"),

	WRITE_COMMAND_FIELD(By.xpath("//p[@class='xdj266r x11i5rnm xat24cr x1mh8g0r']"),"Write Command Field"),
	
	COMMENT_SEND_BUTTON(By.xpath("//div[@aria-label='Comment']"),"Comment Send Button"),
	
	COMMENT_CREATED(By.xpath("(//div[@class='x1y1aw1k xn6708d xwib8y2 x1ye3gou'])[1]"),"comment Created"),
	
	POST_SHARE_BUTTON(By.xpath("//span[@class='x193iq5w xeuugli x13faqbe x1vvkbs x1xmvt09 x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x xudqn12 x3x7a5m x6prxxf xvq8zen x1s688f xi81zsa' and text()='Share']"),"Share Post Button"),
	
	POST_SHARE_DETAILVIEW_SHARE_NOW(By.xpath("//div[@class='x6s0dn4 x78zum5 x15zctf7 x1qughib xh8yej3']//div[@aria-label='Share now']"),"POST_SHARE_DETAILVIEW_SHARE_NOW"),
	
	SHARED_TO_YOUR_PROFILE_POPUP(By.xpath("//span[text()='Shared to your profile']"),"SHARED_TO_YOUR_PROFILE_POPUP"),
	
	POST_SHARE_DETAILVIEW(By.xpath("//div[@class='xvq8zen x19f6ikt']"),"POST_SHARE_DETAILVIEW"),

	SHARE_TEXT_FIELD(By.xpath("//div[@class='xvq8zen x19f6ikt']//p[@class='xdj266r x11i5rnm xat24cr x1mh8g0r x16tdsg8']"),"Share Text Field"),

	/** The comment count. */
	COMMENT_COUNT(
			"//div[text()='%s']//ancestor::div[contains(@class,'sjgh65i0')]//span[contains(text(),'comment')]",
			"Comment count"),

	/** The click. */
	CLICK(By.xpath(
			"//div[@class='iqfcb0g7 tojvnm2t a6sixzi8 k5wvi7nf q3lfd5jv pk4s997a bipmatt0 cebpdrjk qowsmv63 owwhemhu dp1hu0rb dhp61c6y l9j0dhe7 iyyx5f41 a8s20v7p']"),
			"Click"),
	
	/** The messages page load. */
	MESSAGES_PAGE_LOAD(By.xpath("//div[text()='You must log in to continue.']"),"Messages page load"),
	
	/** The messages email id. */
	MESSAGES_EMAIL_ID(By.xpath("//div[@class='_5jb4']//input[@name='email']"),"Messages email id"),
	
	/** The messages password. */
	MESSAGES_PASSWORD(By.xpath("//div[@class='_5jb5']//input[@name='pass']"),"messages password"),
	
	/** The messages social media name. */
	MESSAGES_SOCIAL_MEDIA_NAME(By.xpath("//div//span[text()='Lio']"),"Messages Social media name"),
	
	/** The messages login button. */
	MESSAGES_LOGIN_BUTTON(By.xpath(" //button[@id='loginbutton']"),"Messages login button"),
	
	/** The messages account button. */
	MESSAGES_ACCOUNT_BUTTON(By.xpath("//div[@aria-label='Account' and @role='button']"),"Messages account button"),
	
	/** The messages logout button. */
	MESSAGES_LOGOUT_BUTTON(By.xpath("//div[@aria-label='Account' and @role='dialog']//span[contains(text(),'Log Out')]"),"Messages log out"),
	
	/** The messages facebook logo. */
	MESSAGES_FACEBOOK_LOGO(By.xpath("//img[contains(@class,'fb_logo') and @alt='Facebook']"),"Messages facebook logo"),
	
	/** The navigation panel. */
	NAVIGATION_PANEL(By.xpath("//div[@aria-label='Facebook' and @role='navigation']"),"Navigation panel"),
	
	/** The post comment. */
	POST_COMMENT_FIELD(By.xpath("//*[local-name()='form' and @role='presentation']//parent::div//div[@class='x78zum5 x13a6bvl']//div[@role='textbox']"),"Post comment"),
	
	/** The images post pageload. */
	IMAGES_POST_PAGELOAD(By.xpath("//div[contains(@class,'bp9cbjyn ')]//a[@aria-label='Facebook']"),"Images post page load"),
	
	/** The images post emailid. */
	IMAGES_POST_EMAILID(By.xpath("//form[@id='login_form']//input[@name='email']"),"Images post email id"),
	
	/** The images post password. */
	IMAGES_POST_PASSWORD(By.xpath("//form[@id='login_form']//input[@name='pass']"),"images post password"),
	
	/** The facebook link email. */
	FACEBOOK_LINK_EMAIL(By.xpath("//html[@id='facebook']//input[@name='email']"),"Facebook login field"),
	
	FACEBOOK_CLOSE_BUTTON(By.xpath("//div[@aria-label='Close']"),"FACEBOOK_CLOSE_BUTTON"),
	
	/** The facebook link password. */
	FACEBOOK_LINK_PASSWORD(By.xpath("//html[@id='facebook']//input[@name='pass']"),"Facebook password login"),
	
	FACEBOOK_LOGIN_BUTTON_ELEMENT(By.xpath("(//*[contains(text(),'Log In')])[2]"),"Log In Button Element"),
	
	/** The facebook link login button. */
	FACEBOOK_LINK_LOGIN_BUTTON(By.xpath("//*[contains(text(),'Forgotten account?')]//ancestor::div[@class='x9f619 x1n2onr6 x1ja2u2z x2lah0s x13a6bvl x6s0dn4 xozqiw3 x1q0g3np x1pi30zi x1swvt13 xexx8yu xcud41i x139jcc6 x4cne27 xifccgj x1s85apg x3holdf']//*[contains(text(),'Log in')]"),"Facebook login button"),
	
	FACEBOOK_LOGIN_BUTTON(By.xpath("//div[contains(@aria-label,'Accessible login button')]//span[text()='Log in']"),"Facebbok Login Button"),

	FACEBOOK_POPUP_EMAIL_FIELD(By.xpath("(//input[@name='email'])[2]"),"FACEBOOK_EMAIL_POPUP_FIELD"),

	FACEBOOK_POPUP_PASS_FIELD(By.xpath("(//input[@name='pass'])[2]"),"FACEBOOK_PASS_POPUP_FIELD"),

	FACEBOOK_POPUP_LOGIN_BUTTON(By.xpath("//div[@class='x1c436fg']//span[text()='Log in']"),"FACEBOOK_POPO_LOGIN_BUTTON"),


	FOOTER(By.xpath("//div[@class='x78zum5 xdt5ytf'][last()]"),"fotter"),
	
	/** The images post login button. */
	IMAGES_POST_LOGIN_BUTTON(By.xpath("//form[@id='login_form']//div[contains(@class,'r0h9k63k')]//div[@aria-label='Accessible login button']//span[text()='Log In']"),"Images post login button"),

	/** The continue as button. */
	CONTINUE_AS_BUTTON(By.xpath("//div[@role='button']//span[contains(text(),'Continue as ')]"), "Continue as button"),

	FB_LOGIN(By.xpath("//input[@data-testid='royal_login_button']"),"FaceBook Login"),

	FACEBOOK_AUTOMATION_TESTING_BUTTON(By.xpath("(//*[text()='Automation Testing'])[1]"),"Facebook Automation Testing Button"),

	FACEBOOK_VIEWPAGE_BUTTON(By.xpath("//span[text()='Facebook']//ancestor::div[contains(@class,'csp-item')]//div[contains(@class,'csp-action')]//button[text()='View page']"),
			"Facebook view page button"),

	FACEBOOK_LOG_IN(By.xpath("//button[@type='submit']"),"Log In button"),

	FACEBOOK_LOGIN(By.xpath("(//span[text()='Log in'])[2]"),"FACEBOOK_LOGIN"),

	//Story Validation

	FACEBOOK_PROFILE_PICTURE(By.xpath("//div[@class='x1rg5ohu x1n2onr6 x3ajldb x1ja2u2z']//*[local-name()='svg' and @aria-label='Coffee And Tea']"),"Facebook profile picture"),//div[@class='x1rg5ohu x1n2onr6 x3ajldb x1ja2u2z']//*[local-name()='svg' and @aria-label='Coffee And Tea']

	FACEBOOK_PROFILE_VIEW_STORY(By.xpath("//div[@class='x78zum5 xdt5ytf x1iyjqo2 x1n2onr6']//span[text()='View story']"),"Facebook Profile View Story"),

	FACEBOOK_VIEW_STORY_PAGELOAD(By.xpath("//div[@class='__fb-light-mode x1n2onr6 x1vjfegm']//div[@class='x1iyjqo2 x1n2onr6']"),"Facebook view story page load"),

    FACEBOOK_VIEW_STORY_PAGE("//div[@class='xw2csxc x1odjw0f']//span[text()='%s']","Facebook view story page"),

	FACEBOOK_VIEW_STORY_PAGE_WITH_TIME("//div[@class='xw2csxc x1odjw0f']//span[text()='%s']//following::div[@class='x1iorvi4 x4uap5 xjkvuk6 xkhd6sd']//span[text()]","Facebook view story page with time"),

    STORY_NEXT_BUCKET_BUTTON(By.xpath("//div[@aria-label='Next bucket']"),"Story Next Bucket Button"),

	STORY_NEXT_BUTTON(By.xpath("//div[@aria-label='Next card']"),"Story Next Button"),

	STORY_WITH_IMAGE("//div[@class='x5yr21d x1n2onr6 xh8yej3']//img[@alt='%s']","Story with image"),

	STORY_WITH_VIDEO(By.xpath("//div[@class='x6s0dn4 x78zum5 xdt5ytf x5yr21d xl56j7k x1n2onr6']//*[local-name()='video' and @class='x1lliihq x5yr21d xh8yej3']"),""),

	STORY_PREVIOUS_BUTTON(By.xpath("//div[@aria-label='Previous card']"),"STORY_PREVIOUS_BUTTON"),

	REELS_POST_FIELD("//span[text()='Reels']//ancestor::div[@class='x78zum5 x5yr21d xl56j7k x1n2onr6 xh8yej3']//div[text()='%s']","REELS_POST_FIELD"),

	;


	/** The by locator. */
	private By byLocator;

	/** The xpath. */
	private String xpath;

	/** The description. */
	private String description;

	/**
	 * Instantiates a new facebook page enum.
	 *
	 * @param byLocator   the by locator
	 * @param description the description
	 */
	private FacebookPageEnum(By byLocator, String description) {
		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new facebook page enum.
	 *
	 * @param xpath       the xpath
	 * @param description the description
	 */
	private FacebookPageEnum(String xpath, String description) {
		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return byLocator;
	}

	/**
	 * Gets the by xpath.
	 *
	 * @return the by xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}
}

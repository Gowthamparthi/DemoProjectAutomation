package com.rallio.automation.newrallio.business;

import com.rallio.automation.common.enums.*;
import com.rallio.automation.common.util.*;
import com.rallio.automation.core.manager.*;
import com.rallio.automation.newrallio.enums.*;
import com.rallio.automation.newrallio.pages.*;
import org.openqa.selenium.support.*;
import org.testng.*;

import java.io.*;

import static com.rallio.automation.common.manager.ConfigManager.*;

public class ContentMediaPageLogic {

    private static ContentMediaPageLogic contentMediaPageLogic = null;

    private static ContentTabMediaGalleryPage contentTabMediaGalleryPage = PageFactory.initElements(DriverManager.getDriver(), ContentTabMediaGalleryPage.class);

    private static MediaDetailedViewPage mediaDetailedViewPage = PageFactory.initElements(DriverManager.getDriver(), MediaDetailedViewPage.class);


    private ContentMediaPageLogic() {

    }

    /**
     * Creates the instance.
     *
     * @return the ContentCreatorPage
     */
    public final static ContentMediaPageLogic createInstance() {

        if (contentMediaPageLogic == null) {
            contentMediaPageLogic = new ContentMediaPageLogic();
        }
        return contentMediaPageLogic;
    }

    public void mediaUploadImageAndVideoAndDelete(String imagePath, String imageName) {

        contentTabMediaGalleryPage.uploadMediaFile(imagePath);
        contentTabMediaGalleryPage.deleteMediaWithoutDetailView(imageName);
    }

    public void uploadMediaAsLockPost(String path) {

        File imageFile = new File(path);
        String imagePath = imageFile.getAbsolutePath();
        contentTabMediaGalleryPage.uploadMediawithLockOption(imagePath);
    }

    public void uploadMediaWithoutADD(String... filePaths) {
        for (String path : filePaths) {
            File imageFile = new File(path);
            String imagePath = imageFile.getAbsolutePath();
            if (contentTabMediaGalleryPage.isDisplayed(Timeout.THREE_SEC, ContentTabMediaGalleryPageEnum.MEDIA_LIST)) {
                contentTabMediaGalleryPage.fillFields(ContentTabMediaGalleryPageEnum.UPLOAD_FILE, imagePath);
                Assert.assertTrue(contentTabMediaGalleryPage.isDisplayed(Timeout.THREE_SEC, ContentTabMediaGalleryPageEnum.UPLOAD_SECTION_IMAGE_NAME));
            } else {
                contentTabMediaGalleryPage.fillFields(ContentTabMediaGalleryPageEnum.UPLOAD_SECTION_UPLOAD_FILE, imagePath);
                PageUtil.waitUntilPageLoad(DriverManager.getDriver(), Timeout.THREE_SEC);
            }
        }
        Assert.assertTrue(contentTabMediaGalleryPage.isDisplayed(ContentTabMediaGalleryPageEnum.MEDIA_ADD_BUTTON));
    }

    public void uploadTwoImageWithLockCustomDateandMediaReleaseSignature(int datecount, String signatureName, String... imagepath) {

        contentMediaPageLogic.uploadMediaWithoutADD(imagepath[0], imagepath[1]);
        contentTabMediaGalleryPage.selectLockEditingWithCustomDate(datecount);
        contentTabMediaGalleryPage.addNameAndSignature(signatureName);
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.MEDIA_ADD_BUTTON);
        Assert.assertTrue(contentTabMediaGalleryPage.isDisplayed(ContentTabMediaGalleryPageEnum.MEDIA_ASSETS_ADDED_SUCCESSFULLY_POPUP));
    }


    public MediaDetailedViewPage mediaDetailViewImageLockPost(String name1, String name2, String locationName) {

        MediaDetailedViewPage mediaDetailedViewPage=PageFactory.initElements(DriverManager.getDriver(), MediaDetailedViewPage.class);
        Assert.assertTrue(mediaDetailedViewPage.checkLockPostDetailview(name1, name2));
        String lastSyndicated = contentTabMediaGalleryPage.getTextFromLocator(ContentTabMediaGalleryPageEnum.MEDIA_LAST_SYNDIACTE_DATE);
        Assert.assertTrue(lastSyndicated.contains(DateUtil.getCurrentDate("MMMM d'th', yyyy")));
        Assert.assertTrue(lastSyndicated.contains(locationName));
        return mediaDetailedViewPage;
    }

    public ContentTabMediaGalleryPage mediaDetailviewWaterMarkEditImageEditingDisable(String imageName) {

        LogUtil.log("Check Media Detailview WaterMark, Edit, ImageEditing Button Disable ",LogLevel.LOW);
        ContentTabMediaGalleryPage contentTabMediaGalleryPage = PageFactory.initElements(DriverManager.getDriver(), ContentTabMediaGalleryPage.class);
        Assert.assertTrue(contentTabMediaGalleryPage.isPageLoad());
        contentTabMediaGalleryPage.navigateToMediaDetailedViewPage(imageName);
        Assert.assertTrue(contentTabMediaGalleryPage.isDisplayed(ContentTabMediaGalleryPageEnum.WATERMARK_DISABLE_BUTTON),"Watermark Disable Button not found");
        Assert.assertTrue(contentTabMediaGalleryPage.isDisplayed(ContentTabMediaGalleryPageEnum.EDIT_DISABLE_BUTTON),"Edit Disable Button not found");
        Assert.assertTrue(mediaDetailedViewPage.isDisplayed(MediaDetailedViewPageEnum.IMAGE_EDITING_NOT_ALLOWED),"Image editing not allowed");
        Assert.assertTrue(!mediaDetailedViewPage.isDisplayed(Timeout.FIVE_SEC,MediaDetailedViewPageEnum.PROVIDED_BY),"Provided By not found");
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.IMAGEVIEW_CANCEL_BUTTON);
        return contentTabMediaGalleryPage;
    }

    public ContentTabMediaGalleryPage mediaDetailviewWaterMarkEditEnableEditingDisable(String imageName) {

        LogUtil.log("Check Media Detailview WaterMark and Edit Enable,ImageEditing Button Disable ",LogLevel.LOW);
        ContentTabMediaGalleryPage contentTabMediaGalleryPage = PageFactory.initElements(DriverManager.getDriver(), ContentTabMediaGalleryPage.class);
        Assert.assertTrue(contentTabMediaGalleryPage.isPageLoad());
        contentTabMediaGalleryPage.navigateToMediaDetailedViewPage(imageName);
        Assert.assertTrue(contentTabMediaGalleryPage.isDisplayed(ContentTabMediaGalleryPageEnum.WATERMARK_ENABLE_BUTTON),"Watermark Enable Button not found");
        Assert.assertTrue(contentTabMediaGalleryPage.isDisplayed(ContentTabMediaGalleryPageEnum.EDIT_ENABLE_BUTTON),"Edit Enable Button not found");
        Assert.assertTrue(mediaDetailedViewPage.isDisplayed(MediaDetailedViewPageEnum.IMAGE_EDITING_NOT_ALLOWED),"Image editing not allowed");
        Assert.assertTrue(mediaDetailedViewPage.isDisplayed(Timeout.FIVE_SEC,MediaDetailedViewPageEnum.PROVIDED_BY),"Provided By not found");
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.IMAGEVIEW_CANCEL_BUTTON);
        return contentTabMediaGalleryPage;
    }

    public ContentTabMediaGalleryPage mediaDetailviewWaterMarkEditImageEditingEnable(String imageName) {

        LogUtil.log("Check Media Detailview WaterMark, Edit Enable, ImageEditing Button Enable ",LogLevel.LOW);
        ContentTabMediaGalleryPage contentTabMediaGalleryPage = PageFactory.initElements(DriverManager.getDriver(), ContentTabMediaGalleryPage.class);
        Assert.assertTrue(contentTabMediaGalleryPage.isPageLoad());;
        contentTabMediaGalleryPage.navigateToMediaDetailedViewPage(imageName);
        Assert.assertTrue(contentTabMediaGalleryPage.isDisplayed(ContentTabMediaGalleryPageEnum.WATERMARK_ENABLE_BUTTON),"Watermark Enable Button not found");
        Assert.assertTrue(contentTabMediaGalleryPage.isDisplayed(ContentTabMediaGalleryPageEnum.EDIT_ENABLE_BUTTON),"Edit Enable Button not found");
        Assert.assertTrue(mediaDetailedViewPage.isDisplayed(MediaDetailedViewPageEnum.IMAGE_EDITING_ALLOWED),"Image editing not allowed");
        Assert.assertTrue(!mediaDetailedViewPage.isDisplayed(Timeout.FIVE_SEC,MediaDetailedViewPageEnum.PROVIDED_BY),"Provided By not found");
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.IMAGEVIEW_CANCEL_BUTTON);
        return contentTabMediaGalleryPage;
    }

    public void allowALLOthersEditImage(String imageName) {

        Assert.assertTrue(contentTabMediaGalleryPage.isPageLoad());
        contentTabMediaGalleryPage.navigateToMediaDetailedViewPage(imageName);
        if (mediaDetailedViewPage.isDisplayed(MediaDetailedViewPageEnum.ALL_OTHERS_TO_EDIT_OPTION_INACTIVE)) {
            mediaDetailedViewPage.clickMediaDetailsViewPageElement(MediaDetailedViewPageEnum.ALL_OTHERS_TO_EDIT_OPTION_INACTIVE);
            Assert.assertTrue(mediaDetailedViewPage.isDisplayed(MediaDetailedViewPageEnum.ALL_OTHERS_TO_EDIT_OPTION_ACTIVE));
            mediaDetailedViewPage.clickMediaDetailsViewPageElement(MediaDetailedViewPageEnum.SAVE_ALL_BUTTON);
            Assert.assertTrue(contentTabMediaGalleryPage.isDisplayed(ContentTabMediaGalleryPageEnum.MEDIA_UPDATED_SUCCESSFULLY));
        }
        Assert.assertTrue(mediaDetailedViewPage.isDisplayed(MediaDetailedViewPageEnum.ALL_OTHERS_TO_EDIT_OPTION_ACTIVE));

    }

    public ContentTabMediaGalleryPage validateDownloadReleaseImage(String imageName) {

        LogUtil.log("Validate Download Realease Image",LogLevel.LOW);
        ContentTabMediaGalleryPage contentTabMediaGalleryPage = PageFactory.initElements(DriverManager.getDriver(), ContentTabMediaGalleryPage.class);
        contentTabMediaGalleryPage.moveToElement(ContentTabMediaGalleryPageEnum.COMMON_MEDIA_BY_NAME, imageName);
        Assert.assertTrue(contentTabMediaGalleryPage.isDisplayed(ContentTabMediaGalleryPageEnum.MEDIA_DOWNLOAD_RELEASE_BUTTON, imageName));
        contentTabMediaGalleryPage.moveToElement(ContentTabMediaGalleryPageEnum.MEDIA_DOWNLOAD_RELEASE_BUTTON, imageName);
        Assert.assertTrue(contentTabMediaGalleryPage.isDisplayed(ContentTabMediaGalleryPageEnum.HOVER_MESSAGE, "Download Release"));
        return contentTabMediaGalleryPage;
    }

    public void validateEveryOneElseLockImageCustomDateActive(String imageName) {

        LogUtil.log("validate Everyone Else Lock Image Custom Date Active",LogLevel.LOW);
        contentTabMediaGalleryPage.navigateToMediaDetailedViewPage(imageName);
        Assert.assertTrue(mediaDetailedViewPage.isDisplayed(MediaDetailedViewPageEnum.AVAILABILTY_ACTIVE_SECTION, "Available for Everyone Else"));
        Assert.assertTrue(mediaDetailedViewPage.isDisplayed(MediaDetailedViewPageEnum.IMAGE_EDITING_ACTIVE_SECTION, "Lock Image from Editing"));
        String selectedDate = mediaDetailedViewPage.getAttributeValue(MediaDetailedViewPageEnum.EXPIRATION_SELECTED_DATE, "value");
        Assert.assertTrue(selectedDate.equals(DateUtil.getNextDate("MMM d, YYY", 0)));
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.IMAGEVIEW_CANCEL_BUTTON);
    }

    public void validateHubNameDisplayAndProvidedByDisable(String imageName, ContentTabMediaGalleryPageEnum contentTabMediaGalleryPageEnum) {

        LogUtil.log("validate Hub Name Detailview having Provided By Disable",LogLevel.LOW);
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(contentTabMediaGalleryPageEnum);
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.CONTENT_SUPPLIER_FILTER);
        contentTabMediaGalleryPage.navigateToMediaDetailedViewPage(imageName);
        Assert.assertTrue(mediaDetailedViewPage.checkHubNameDisplayAndProvidedByDisable());
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.IMAGEVIEW_CANCEL_BUTTON);
    }

    public void validateMediaDetailviewSyndicatedVideoAndDoc(NewRallioHomePage newRallioHomePage, String imageName, ContentTabMediaGalleryPageEnum contentTabMediaGalleryPageEnum) {

        LogUtil.log("validate Media Detail view Syndicated Video And Doc",LogLevel.LOW);
        newRallioHomePage.navigateToContentTabMediaGalleryPage();
        contentMediaPageLogic.validateHubNameDisplayAndProvidedByDisable(imageName, contentTabMediaGalleryPageEnum);
        newRallioHomePage.selectAccount(getValue("switchDreamLocation"));
        contentMediaPageLogic.validateHubNameDisplayAndProvidedByDisable(imageName, contentTabMediaGalleryPageEnum);
        newRallioHomePage.selectAccount(getValue("worldTravelLocation"));
        Assert.assertTrue(contentTabMediaGalleryPage.isDisplayed(ContentTabMediaGalleryPageEnum.MEDIA_LIST));
        newRallioHomePage.selectAccount(getValue("qaaTestLocation"));
        newRallioHomePage.navigateToContentTabMediaGalleryPage();
        contentMediaPageLogic.validateHubNameDisplayAndProvidedByDisable(imageName, contentTabMediaGalleryPageEnum);

    }

    public ContentTabMediaGalleryPage validateDocumentLastSyndicatedLocationandHubLocation(String docName) {

        LogUtil.log("validate Media Detail view Syndicated Video And Doc",LogLevel.LOW);
        ContentTabMediaGalleryPage contentTabMediaGalleryPage = PageFactory.initElements(DriverManager.getDriver(), ContentTabMediaGalleryPage.class);
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.DOCUMENTS_FILTER);
        contentTabMediaGalleryPage.navigateToMediaDetailedViewPage(docName);
        String lastSyndicatedLoc2 = contentTabMediaGalleryPage.getTextFromLocator(ContentTabMediaGalleryPageEnum.MEDIA_LAST_SYNDIACTE_DATE);
        Assert.assertTrue(lastSyndicatedLoc2.contains(DateUtil.getCurrentDate("MMMM d")) && lastSyndicatedLoc2.contains(getValue("locationSelector.hubone")));
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.MEDIA_LAST_SYNDICATED_SECTION_LOCATION, getValue("locationSelector.hubone"));
        PageUtil.waitUntilPageLoad(DriverManager.getDriver(), Timeout.FIVE_SEC);
        String switcherLocation = contentTabMediaGalleryPage.getTextFromLocator(ContentTabMediaGalleryPageEnum.ACCOUNT_SWITCHER_LOCATION);
        Assert.assertEquals(switcherLocation, getValue("locationSelector.hubone"));
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.DOCUMENTS_FILTER);
        PageUtil.waitUntilPageLoad(DriverManager.getDriver(), Timeout.FIVE_SEC);
        Assert.assertTrue(contentTabMediaGalleryPage.isDisplayed(ContentTabMediaGalleryPageEnum.COMMON_MEDIA_BY_NAME, docName));
        contentTabMediaGalleryPage.navigateToMediaDetailedViewPage(docName);
        Assert.assertTrue(mediaDetailedViewPage.isDisplayed(MediaDetailedViewPageEnum.HUB_BY_NAME, getValue("contentWiritterLocation")));
        mediaDetailedViewPage.clickMediaDetailsViewPageElement(MediaDetailedViewPageEnum.HUB_BY_NAME, getValue("contentWiritterLocation"));
        PageUtil.waitUntilPageLoad(DriverManager.getDriver(), Timeout.FIVE_SEC);
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.DOCUMENTS_FILTER);
        contentTabMediaGalleryPage.deleteMediaWithoutDetailView(docName);

        return contentTabMediaGalleryPage;
    }

    public ContentTabMediaGalleryPage validateBrandAndLocationSourecFilter(NewRallioHomePage newRallioHomePage) {

        LogUtil.log("Sum of Source Filter Validation", LogLevel.LOW);
        ContentTabMediaGalleryPage contentTabMediaGalleryPage = PageFactory.initElements(DriverManager.getDriver(), ContentTabMediaGalleryPage.class);
        int allFilterCount = Integer.parseInt(contentTabMediaGalleryPage.getTextFromLocator(ContentTabMediaGalleryPageEnum.MEDIA_SOURCE_ALL_FILTER).replaceAll("[^0-9]", ""));
        int sumofsourcefilter = contentTabMediaGalleryPage.sumofSourceFilter();
        Assert.assertEquals(allFilterCount, sumofsourcefilter);
        LogUtil.log("Content Supplier Selector Validation", LogLevel.LOW);
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.CONTENT_SUPPLIER_FILTER);
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.AL_CONTENT_SUPPLIERS_TAB);
        Assert.assertTrue(contentTabMediaGalleryPage.validateContentSupplierTabDetailviewContents());
        contentTabMediaGalleryPage.navigateContentSupplierTabSelectList(getValue("contentSuppliersLocation1"));
        String commonMeidaName = contentTabMediaGalleryPage.getTextFromLocator(ContentTabMediaGalleryPageEnum.COMMON_MEDIA);
        contentTabMediaGalleryPage.navigateToMediaDetailedViewPage(commonMeidaName);
        Assert.assertTrue(mediaDetailedViewPage.isDisplayed(MediaDetailedViewPageEnum.HUB_BY_NAME, getValue("contentSuppliersLocation1")));
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.IMAGEVIEW_CANCEL_BUTTON);
        Assert.assertTrue(contentTabMediaGalleryPage.isDisplayed(ContentTabMediaGalleryPageEnum.PAGE_LOAD));
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.MEDIA_PAGE_CS_SELCTOR_FIELD, getValue("contentSuppliersLocation1"));
        Assert.assertTrue(contentTabMediaGalleryPage.navigateContentSupplierTabSelectList("All Content Suppliers"));
        Assert.assertTrue(contentTabMediaGalleryPage.validateContentSelectorClose());
        LogUtil.log("Content Supplier Selector Navigate to List and Feed Page", LogLevel.LOW);
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.CONTENT_SUPPLIER_FILTER);
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.AL_CONTENT_SUPPLIERS_TAB);
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.FEED_ENROLL_LINK);
        Assert.assertTrue(newRallioHomePage.isDisplayed(NewRallioHomePageEnum.TEAM_MANAGEMENT_TAB_LISTS_AND_FEEDS) || newRallioHomePage.isDisplayed(NewRallioHomePageEnum.FEED_TAB));
        DriverManager.getDriver().navigate().back();
        LogUtil.log("Validate Media Detailview Brand Or Location", LogLevel.LOW);
        Assert.assertTrue(contentTabMediaGalleryPage.isDisplayed(ContentTabMediaGalleryPageEnum.PAGE_LOAD));
        contentTabMediaGalleryPage.navigateToSourceFilter(ContentTabMediaGalleryPageEnum.BRAND_MEDIA_FILTER, MediaDetailedViewPageEnum.BRAND_LOCATION);
        contentTabMediaGalleryPage.navigateToSourceFilter(ContentTabMediaGalleryPageEnum.LOCATION_MEDIA_FILTER, MediaDetailedViewPageEnum.HUB_NAME, MediaDetailedViewPageEnum.LOCATION);
        contentTabMediaGalleryPage.clickContentTabMediaGalleryPageElement(ContentTabMediaGalleryPageEnum.MEDIA_SOURCE_ALL_FILTER);
        Assert.assertTrue(contentTabMediaGalleryPage.isDisplayed(ContentTabMediaGalleryPageEnum.MEDIA_SOURCE_ALL_FILTER_ACTIVE));
        return contentTabMediaGalleryPage;
    }

}
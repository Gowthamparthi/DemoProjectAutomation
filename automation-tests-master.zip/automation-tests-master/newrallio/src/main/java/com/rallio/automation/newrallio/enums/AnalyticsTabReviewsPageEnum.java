package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum AnalyticsTabReviewsPageEnum.
 */
public enum AnalyticsTabReviewsPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath(
			"//li[@class='ripple active']//span[text()='Reviews']//following::section[@class='item-g filter ra-filter-sec anlFilter']//ancestor::div//div[@class='g-centre']//div[contains(@class,'review-an-container')]"),
			"Page load"),
	
	/** The page graph. */
	PAGE_GRAPH(By.xpath(
			"//main//div[contains(@class,'review')]//div[@class='ra-card ']//*[contains(@class,'highcharts-xaxis-labels')]"),
			"PAGE GRAPH"),

	/** The no data to show. */
	NO_DATA_TO_SHOW(By.xpath("//div[@class='ra-card ']//*[contains(text(),'No data found!')]"),
			"No data to show"),

	/** The newreviews countvalue. */
	NEWREVIEWS_COUNTVALUE(By.xpath(
			"//span[(text()='New Reviews')]//parent::div//div[@class='an-stat--b1']//span[@class='big-number-text']"),
			"NewReviews Count Value"),

	/** The new reviews tile text. */
	NEW_REVIEWS_TILE_TEXT(
			By.xpath("//div[contains(@class,'stats-level-02')]//div//span[text()='New Reviews']"),
			"NewReviews Tile Text."),

	/** The newreviews deltavalue. */
	NEWREVIEWS_DELTAVALUE(By.xpath(
			"//span[(text()='New Reviews')]//parent::div//div[@class='an-stat--b1']//span[@class='delta-small-text']"),
			"NewReviews Delta Value"),

	/** The newreviews brandavg value as location. */
	NEWREVIEWS_BRANDAVG_VALUE_AS_LOCATION(By.xpath(
			"//span[text()='New Reviews']//parent::div//div//span[text()='Brand Average']//parent::div//span[@class='small-title-text']"),
			"NewReviews Brand Average Value_Location"),

	/** The newreviews brandavg value. */
	NEWREVIEWS_BRANDAVG_VALUE(By.xpath(
			"//span[(text()='New Reviews')]//parent::div[@class='chart-module-top']//following-sibling::div[@class='brand-hub__wrp']//span[text()='Average']//parent::div//div//div//span[text()='Brand']//following-sibling::span"),
			"NewReviews Brand Average Value"),

	/** The newreviews hubavg value. */
	NEWREVIEWS_HUBAVG_VALUE(By.xpath(
			"//span[(text()='New Reviews')]//parent::div[@class='chart-module-top']//following-sibling::div[@class='brand-hub__wrp']//span[text()='Average']//parent::div//div//div//span[text()='Hub']//following-sibling::span"),
			"NewReviews Hub Average Value"),

	/** The newreviews tilegraph. */
	NEWREVIEWS_TILEGRAPH(By.xpath(
			"//span[(text()='New Reviews')]//parent::div[@class='chart-module-top']//following-sibling::div[@class='chart-container ']//div[contains(@class,'chart-details')]"),
			"NewReviews Tile graph"),
	
	/** The newreviews hub ratingbar. */
	NEWREVIEWS_HUB_RATINGBAR(By.xpath(
			"//span[(text()='New Reviews')]//parent::div[@class='chart-module-top']//following-sibling::div[@class='hub-chart__container ']//div[contains(@class,'avg-ratings__bar')]"),
			"NewReviews Tile Rating bar"),

	/** The average rating tile text. */
	AVERAGE_RATING_TILE_TEXT(
			By.xpath("//div[contains(@class,'stats-level-02')]//div//span[text()='Average Rating']"),
			"Average Rating Tile Text"),

	/** The average rating countvalue. */
	AVERAGE_RATING_COUNTVALUE(By.xpath(
			"//span[(text()='Average Rating')]//parent::div//div[@class='an-stat--b1']//span[@class='big-number-text']"),
			"AverageRating Count Value"),
	
	/** The average rating deltavalue. */
	AVERAGE_RATING_DELTAVALUE(By.xpath(
			"//span[(text()='Average Rating')]//parent::div//div[@class='an-stat--b1']//span[@class='delta-small-text']"),
			"AverageRating Delta Value"),

	/** The average rating brandavg value as location. */
	AVERAGE_RATING_BRANDAVG_VALUE_AS_LOCATION(By.xpath(
			"//span[text()='Average Rating']//parent::div//div//span[text()='Brand Average']//parent::div//span[@class='small-title-text']"),
			"Average Rating Brand Average Value_Location"),

	/** The average rating brandavg value. */
	AVERAGE_RATING_BRANDAVG_VALUE(By.xpath(
			"//span[(text()='Average Rating')]//parent::div[@class='chart-module-top']//following-sibling::div[@class='brand-hub__wrp']//span[text()='Average']//parent::div//div//div//span[text()='Brand']//following-sibling::span"),
			"AverageRating Brand Average Value"),

	/** The average rating hubavg value. */
	AVERAGE_RATING_HUBAVG_VALUE(By.xpath(
			"//span[(text()='Average Rating')]//parent::div[@class='chart-module-top']//following-sibling::div[@class='brand-hub__wrp']//span[text()='Average']//parent::div//div//div//span[text()='Hub']//following-sibling::span"),
			"AverageRating Brand Average Value"),

	/** The average rating tilegraph.*/
	AVERAGE_RATING_TILEGRAPH(By.xpath(
			"//span[(text()='Average Rating')]//parent::div[@class='chart-module-top']//following-sibling::div[@class='chart-container ']//div[contains(@class,'avg-ratings__bar')]//div//div[contains(@id,'highcharts')]"),
			"Average rating tile graph"),
	
	/** The average rating hub ratingbar. */
	AVERAGE_RATING_HUB_RATINGBAR(By.xpath(
			"//span[(text()='Average Rating')]//parent::div[@class='chart-module-top']//following-sibling::div[@class='hub-chart__container ']//div[contains(@class,'avg-ratings__bar')]"),
			"Average Rating tile rating bar"),

	/** The average rating new reviews charts. */
	AVERAGE_RATING_NEW_REVIEWS_CHARTS(By.xpath("//span[text()='Average Rating']//ancestor::div[contains(@class,'stats review-an__stats')]//following-sibling::div[contains(@class,'flex-item-xs lpx')]//img[@alt='indicator']"),"Average Rating new Reviews chart"),
	
	/** The average rating data. */
	AVERAGE_RATING_DATA(By.xpath("//div[@class='review-an-container']//div[contains(@class,'flex-item-xs')]//div[contains(@class,'profile-tbl-wrp resuseTable platform-review__tbl ')]"),"Average Rating Data"),
	
	/** The average rating y axis data. */
	AVERAGE_RATING_Y_AXIS_DATA(By.xpath("//div[@class='highcharts-axis-labels highcharts-yaxis-labels']//span"),"Average Rating Y axis Data"),
	
	/** The average rating x axis data. */
	AVERAGE_RATING_X_AXIS_DATA(By.xpath("//*[local-name()='g' and @class='highcharts-axis-labels highcharts-xaxis-labels']//*[local-name()='text']"),"Average Rating X axis Data"),
	
	/** The average rating facebook data. */
	AVERAGE_RATING_FACEBOOK_DATA(By.xpath("//h3[text()='Average Rating from New Reviews']//parent::div[@class='tf-left-col']//div[@class='active-tile list-group-item']//span[text()='Facebook']//parent::div//following-sibling::div[@class='delta-wrp']//span"),"Average Rating Facebook Data"),
	
	/** The average rating google data. */
	AVERAGE_RATING_GOOGLE_DATA(By.xpath("//h3[text()='Average Rating from New Reviews']//parent::div[@class='tf-left-col']//div[@class='active-tile list-group-item']//span[text()='Google']//parent::div//following-sibling::div[@class='delta-wrp']//span"),"Average Rating Google Data"),
	
	/** The AVERAG E RATIN G YEL ps DATA. */
	AVERAGE_RATING_YELPs_DATA(By.xpath("//h3[text()='Average Rating from New Reviews']//parent::div[@class='tf-left-col']//div[@class='active-tile list-group-item']//span[text()='Yelp']//parent::div//following-sibling::div[@class='delta-wrp']//span"),"Average Rating Yelp Data"),
	
	/** The average rating donut chart star rating. */
	AVERAGE_RATING_DONUT_CHART_STAR_RATING(By.xpath("//div[@class='legend-wrp']//img//following-sibling::span[@class='start-lbl']"),"AVERAGE_RATING_DONUT_CHART_STAR_RATING"),
	
	/** The average rating donut chart star rating with percentage. */
	AVERAGE_RATING_DONUT_CHART_STAR_RATING_WITH_PERCENTAGE(By.xpath("//div[@class='legend-wrp']//img//following-sibling::span[@class='start-lbl']//following-sibling::span[@class='percent-lbl' and text()]"),"AVERAGE_RATING_DONUT_CHART_STAR_RATING_WITH_PERCENTAGE"),
	
    /** The average rating brand average button. */
    AVERAGE_RATING_BRAND_AVERAGE_BUTTON(By.xpath("//*[local-name()='g' and contains(@class,'highcharts-legend-item highcharts-spline-series')]//*[local-name()='text' and text()='Brand Average']"),"Brand Average Button"),
	
	/** The average rating hub average button. */
	AVERAGE_RATING_HUB_AVERAGE_BUTTON(By.xpath("//*[local-name()='g' and contains(@class,'highcharts-legend-item highcharts-spline-series')]//*[local-name()='text' and text()='Hub Average']"),"Hub-Brand Average Button"),
	
	/** The average rating brand average inactive. */
	AVERAGE_RATING_BRAND_AVERAGE_INACTIVE(By.xpath("//*[local-name()='g' and contains(@class,'highcharts-legend-item-hidden')]//*[local-name()='text' and text()='Brand Average']"),"Brand Average Inactive"),
	
	/** The average rating hub average inactive. */
	AVERAGE_RATING_HUB_AVERAGE_INACTIVE(By.xpath("//*[local-name()='g' and contains(@class,'highcharts-legend-item-hidden')]//*[local-name()='text' and text()='Hub Average']"),"Hub-Brand Average Inactive"),
	
	DETAILVIEW_CHART(By.xpath("//div[contains(@class,'flex-item-xs')]//div[@class='highcharts-container ']"),"Detailview Chart"),
	
	TABLE_DATA(By.xpath("//div[contains(@class,'flex-item-xs')]//div[contains(@class,'profile-tbl-wrp resuseTable platform-review__tbl')]"),"Table Data"),
	
	/** The percent replied tile text. */
	PERCENT_REPLIED_TILE_TEXT(
			By.xpath("//div[contains(@class,'stats-level-02')]//div//span[text()='Percent Replied']"),
			"Percent Replied Tile Text."),
	
	/** The percentreplied countvalue. */
	PERCENTREPLIED_COUNTVALUE(By.xpath(
			"//span[(text()='Percent Replied')]//parent::div//div[@class='an-stat--b1']//span[@class='big-number-text']"),
			"PercentReplied Count Value"),
	
	/** The percentreplied deltavalue. */
	PERCENTREPLIED_DELTAVALUE(By.xpath(
			"//span[(text()='Percent Replied')]//parent::div//div[@class='an-stat--b1']//span[@class='delta-small-text']"),
			"PercentReplied Delta Value"),

	/** The percentreplied brandavg value as location. */
	PERCENTREPLIED_BRANDAVG_VALUE_AS_LOCATION(By.xpath(
			"//span[text()='Percent Replied']//parent::div//div//span[text()='Brand Average']//parent::div//span[@class='small-title-text']"),
			"PercentReplied Brand Average Value_Location"),

	/** The percentreplied brandavg value. */
	PERCENTREPLIED_BRANDAVG_VALUE(By.xpath(
			"//span[(text()='Percent Replied')]//parent::div[@class='chart-module-top']//following-sibling::div[@class='brand-hub__wrp']//span[text()='Average']//parent::div//div//div//span[text()='Brand']//following-sibling::span"),
			"PercentReplied Brand Average Value"),

	/** The percentreplied hubavg value. */
	PERCENTREPLIED_HUBAVG_VALUE(By.xpath(
			"//span[(text()='Percent Replied')]//parent::div[@class='chart-module-top']//following-sibling::div[@class='brand-hub__wrp']//span[text()='Average']//parent::div//div//div//span[text()='Hub']//following-sibling::span"),
			"PercentReplied Hub Average Value"),

	/** The percentreplied tilegraph. */
	PERCENTREPLIED_TILEGRAPH(By.xpath(
			"//span[(text()='Percent Replied')]//parent::div[@class='chart-module-top']//following-sibling::div[@class='chart-container ']//div//div[contains(@id,'highcharts')]"),
			"PercentReplied Tile graph"),
	
	/** The percentreplied hub tile graph. */
	PERCENTREPLIED_HUB_TILE_GRAPH(By.xpath(
			"//span[(text()='Percent Replied')]//parent::div[@class='chart-module-top']//following-sibling::div[@class='hub-chart__container ']"),
			"PercentReplied hub-Tile grapth"),

	VIEW_IN_NUMBER(By.xpath("//div[@class='replies-btn--wrp']//button[text()='View in Number']"),"View In Number"),
	
	VIEW_IN_PERCENTAGE(By.xpath("//div[@class='replies-btn--wrp']//button[text()='View in Percentage']"),"View In Percentage"),
	
	TOTALS_TABLE_DATA(By.xpath("//td[text()]//ancestor::div[@class='review-an-container']//div[contains(@class,'flex-item-xs')]//div[@class='profile-tbl-wrp resuseTable platform-review__tbl ']"),"Total Table Data"),
	
	TABLE(By.xpath("//td//ancestor::div[@class='review-an-container']//div[contains(@class,'flex-item-xs')]//div[@class='profile-tbl-wrp resuseTable platform-review__tbl ']"),"Table"),
	
	X_AXIS_DATA(By.xpath("//*[local-name()='g' and @class='highcharts-axis-labels highcharts-xaxis-labels']//*[local-name()='text']"),"X-axis Data"),
	
	Y_AXIS_DATA(By.xpath("//div[@class='highcharts-axis-labels highcharts-yaxis-labels']//span"),"Y-Axis Data"),
	
	FACEBOOK_DATA_VALUE(By.xpath("//h3//parent::div[@class='tf-left-col']//div[@class='active-tile list-group-item']//span[text()='Facebook']//parent::div//following-sibling::div[@class='delta-wrp']//span"),"Facebook Data"),
	
	GOOGLE_DATA_VALUE(By.xpath("//h3//parent::div[@class='tf-left-col']//div[@class='active-tile list-group-item']//span[text()='Google']//parent::div//following-sibling::div[@class='delta-wrp']//span")," Google Data"),
	
    YELP_DATA_VALUE(By.xpath("//h3//parent::div[@class='tf-left-col']//div[@class='active-tile list-group-item']//span[text()='Yelp']//parent::div//following-sibling::div[@class='delta-wrp']//span"),"Rating Yelp Data"),

    PERCENTAGE_OF_TOTAL_REVIEW_REPLIES(By.xpath("//*[local-name()='g' and contains(@class,'highcharts-label highcharts-data-label highcharts-data-label-color')]//*[local-name()='text'] "),"PERCENTAGE_TOTAL_REVIEW_REPLIES"),
    
    BRAND_AVERAGE_BUTTON(By.xpath("//*[local-name()='g' and contains(@class,'highcharts-legend-item highcharts-spline-series')]//*[local-name()='text' and text()='Brand Average']"),"Brand Average Button"),
	
	HUB_AVERAGE_BUTTON(By.xpath("//*[local-name()='g' and contains(@class,'highcharts-legend-item highcharts-spline-series')]//*[local-name()='text' and text()='Hub Average']"),"Hub-Brand Average Button"),
	
	BRAND_AVERAGE_INACTIVE(By.xpath("//*[local-name()='g' and contains(@class,'highcharts-legend-item-hidden')]//*[local-name()='text' and text()='Brand Average']"),"Brand Average Inactive"),
	
	HUB_AVERAGE_INACTIVE(By.xpath("//*[local-name()='g' and contains(@class,'highcharts-legend-item-hidden')]//*[local-name()='text' and text()='Hub Average']"),"Hub-Brand Average Inactive"),
	
    
	/** The response time tile text. */
	RESPONSE_TIME_TILE_TEXT(
			By.xpath("//div[contains(@class,'stats-level-02')]//div//span[text()='Response Time']"),
			"Response Time Tile Text."),

	/** The responsetime countvalue. */
	RESPONSETIME_COUNTVALUE(By.xpath(
			"//span[(text()='Response Time')]//parent::div//div[@class='an-stat--b1']//span[@class='big-number-text']"),
			"Response time  Count Value"),
	
	/** The responsetime deltavalue. */
	RESPONSETIME_DELTAVALUE(By.xpath(
			"//span[(text()='Response Time')]//parent::div//div[@class='an-stat--b1']//span[@class='delta-small-text']"),
			"PercentReplied Delta Value"),

	/** The responsetime brandavg value as location. */
	RESPONSETIME_BRANDAVG_VALUE_AS_LOCATION(By.xpath(
			"//span[text()='Response Time']//parent::div//div//span[text()='Brand Average']//parent::div//span[@class='small-title-text']"),
			"Response time Brand Average Value_Location"),

	/** The responsetime brandavg value. */
	RESPONSETIME_BRANDAVG_VALUE(By.xpath(
			"//span[(text()='Response Time')]//parent::div[@class='chart-module-top']//following-sibling::div[@class='brand-hub__wrp']//span[text()='Average']//parent::div//div//div//span[text()='Brand']//following-sibling::span"),
			"Response time Brand Average Value"),

	/** The responsetime hubavg value. */
	RESPONSETIME_HUBAVG_VALUE(By.xpath(
			"//span[(text()='Response Time')]//parent::div[@class='chart-module-top']//following-sibling::div[@class='brand-hub__wrp']//span[text()='Average']//parent::div//div//div//span[text()='Hub']//following-sibling::span"),
			"Response time Hub Average Value"),

	/** The responsetime tilegraph. */
	RESPONSETIME_TILEGRAPH(By.xpath(
			"//span[(text()='Response Time')]//parent::div[@class='chart-module-top']//following-sibling::div[@class='chart-container ']//div//div[contains(@id,'highcharts')]"),
			"Response time Tile grapth"),
	
	/** The response time hub tile graph. */
	RESPONSE_TIME_HUB_TILE_GRAPH(By.xpath(
			"//span[(text()='Response Time')]//parent::div[@class='chart-module-top']//following-sibling::div[@class='hub-chart__container ']"),
			"Response time hub-Tile grapth"),

	/** The keywords tile. */
	KEYWORDS_TILE(By.xpath("//div[@class='review-an-container']//div[contains(@class,'stats-item')][5]"),
			"Keywords Tile"),

	KEYWORDS_CHART_TILE(By.xpath("//div[@class='review-an-container']//div[contains(@class,'stats-item')]//div[@class='chart-container keyword-chart']"),"Keyword Chart Tile"),

	KEYWORDS_CHART_ACTIVE(By.xpath("//img[@class='an-chart--indicator keywords']"),"Keywords Chart Active"),

	/** The keywords tile text. */
	KEYWORDS_TILE_TEXT(By.xpath("//div[contains(@class,'stats-level-02')]//div//span[text()='Keywords']"),
			"Keywords Tile Text."),

	/** The keywords countvalue. */
	KEYWORDS_COUNTVALUE(By.xpath(
			"//span[(text()='Keywords')]//parent::div//div[@class='an-stat--b1']//span[@class='big-number-text']"),
			"Keywords Count Value"),

	/** The keywords tilegraph info. */
	KEYWORDS_TILEGRAPH_INFO(By.xpath(
			"//div[@class='chart-container keyword-chart']//div//span[text()='Positive']//following-sibling::span[text()='Neutral']//following-sibling::span[text()='Negative']"),
			"Keywords with (+)ve,(-)ve,Neutral"),

	/** The keywords flex. */
	KEYWORDS_CHART_HEADLINE_BY_NAME("//div[contains(@class,'rewards-details-tab')]//li//span[text()='coffee']",
			"KEYWORDS_CHART_HEADLINE_BY_NAME"),
	
	/** The keywords flex. */
	KEYWORDS_CHART(
			By.xpath("//div[contains(@class,'flex-item')]//div[contains(@class,'ra-card over-view-chart')]"),
			"KEYWORDS_CHART"),
	
	KEYWORDS_FLEX(
			By.xpath("//div[@class='ra-card kwrds']//span[text()='All Keywords']"),
			"Keywords Flex"),

	/** The keywords flex words. */
	KEYWORDS_FLEX_WORDS(By.xpath(
			"//*[@class='highcharts-series-group']//*[@class='highcharts-series highcharts-series-0 highcharts-wordcloud-series highcharts-tracker']//*[contains(text(),'')]"),
			"Keywords Flex Words"),

	/** The keywords flex words field. */
	KEYWORDS_FLEX_WORDS_FIELD("//*[@class='highcharts-series-group']//*[contains(@class,'highcharts-series highcharts-series-0 highcharts-wordcloud-series highcharts-tracker')]//*[contains(text(),'%s')]","KeyWords Flex Words Field"),
	
	/** The keywords table with headlines. */
	KEYWORDS_TABLE_WITH_HEADLINES(By.xpath(
			"//table//th//div[text()='Keywords']//following::th//div[text()='Used']//following::th//div[text()='Neutral']//following::th/div[text()='Negative']//following::th//div[text()='% of Reviews']"),
			"Keywords Table with headlines"),

	/** The keywords table words. */
	KEYWORDS_TABLE_WORDS(By.xpath("//div[contains(@class,'resuseTable')]//table//tbody"), "Keywords Table Words"),

	/** The review management tile. */
	REVIEW_MANAGEMENT_TILE(By.xpath("//span[contains(text(),'Review Management')]//parent::div"),
			"Review Management Tile"),
	
	REPUTATION_REVIEWS_PAGE(By.xpath(
			"//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Reviews']//ancestor::div[@id='root']"),"REPUTATION_REVIEWS_PAGE"),

	/** The no of reviews text. */
	NO_OF_REVIEWS_TEXT(By.xpath("//span[contains(text(),'Number of New Reviews') and @class='highcharts-title']"),
			"No Of Reviews Text"),

	/** The brand avg with toggle. */
	BRAND_AVG_WITH_TOGGLE(By.xpath(
			"//div[contains(@class,'ra-card')]//*[text()='Brand Average']"),
			"Brand Avg With toggle"),

	/** The hub avg with toggle. */
	HUB_AVG_WITH_TOGGLE(By.xpath(
			"//div[contains(@class,'ra-card')]//*[text()='Hub Average']"),
			"Hub Avg With toggle"),

	/** The line chart. */
	LINE_CHART(By.xpath("//div[contains(@class,'ra-card')]//div[@class='highcharts-container ']//*[@class='highcharts-root']"), "Line Chart"),

	/** The line chart x axis labels. */
	LINE_CHART_X_AXIS_LABELS(
			By.xpath("//*[@class='highcharts-root']//*[@class='highcharts-axis-labels highcharts-xaxis-labels']//*"),
			"Line Chart X-axis labels"),
	
	/** The table view. */
	TABLE_VIEW(By.xpath(
			"//div[contains(@class,'profile-tbl')]//table"),
			"Table View"),

	/** The new reviews text. */
	NEW_REVIEWS_TEXT(By.xpath("//div[@class='tf-col-holder card-body']//div//h3[text()='New Reviews']"),
			"NewReviews Text"),

	/** The google icon text. */
	GOOGLE_ICON_TEXT(By
			.xpath("//span[@class='google-txt']//parent::div[@class='tf-header']//img[contains(@src,'google-lv.svg')]"),
			"Google Icon-Text"),

	/** The google value. */
	GOOGLE_VALUE(By.xpath(
			"//div//h3[text()='New Reviews']//parent::div//*[text()='Google']//parent::div//parent::div[contains(@class,'active')]//div//span[contains(@class,'total-count')]"),
			"Google New Reviews Value"),
	
	/** The yelp value. */
	YELP_VALUE(By.xpath(
			"//div//h3[text()='New Reviews']//parent::div//*[text()='Yelp']//parent::div//parent::div[contains(@class,'active')]//div//span[contains(@class,'total-count')]"),
			"Yelp new Reviews Value"),
	
	/** The google disconnect state. */
	GOOGLE_DISCONNECT_STATE(By
			.xpath("//div[not(contains(@class,'active'))]//div//span[text()='Google']"),
			"Google disconnect state"),
	
	/** The facebook disconnect state. */
	FACEBOOK_DISCONNECT_STATE(By
			.xpath("//div[not(contains(@class,'active'))]//div//span[text()='Google']"),
			"Google disconnect state"),
	
	/** The yelp disconnect state. */
	YELP_DISCONNECT_STATE(By
			.xpath("//div[not(contains(@class,'active'))]//div//span[text()='Yelp']"),
			"Yelp disconnect state"),

	/** The facebook icon text. */
	FACEBOOK_ICON_TEXT(
			By.xpath("//span[@class='fb-txt']//parent::div[@class='tf-header']//img[contains(@src,'fb-lv.svg')]"),
			"Facebook Icon-Text"),

	/** The facebook value. */
	FACEBOOK_VALUE(By.xpath(
			"//div//h3[text()='New Reviews']//parent::div//*[text()='Facebook']//parent::div//parent::div[contains(@class,'active')]//div//span[contains(@class,'total-count')]"),
			"Facebook New reviews Value"),

	/** The percentage of new reviews byplatform text. */
	PERCENTAGE_OF_NEW_REVIEWS_BYPLATFORM_TEXT(
			By.xpath("//div[@class='tf-right-col']//h3[text()='Percentage of New Reviews by Platform']"),
			"Percentage of New Reviews By Platform"),

	/** The donut chart. */
	DONUT_CHART(By.xpath(
			"//*[@class='highcharts-series-group']//*[@class='highcharts-series highcharts-series-0 highcharts-pie-series highcharts-tracker']"),
			"Donut Chart"),

	/** The download csv. */
	DOWNLOAD_CSV(By.xpath("//span[text()='Download CSV']//parent::button[contains(@class,'primary ac-block csv')]"),
			"Download CSV"),

	/** The clear filter. */
	CLEAR_FILTER(By.xpath("//div[@class='filter-item clear-filter']//div//button//span[text()='Clear Filter']//parent::button"),
			"Clear Filter"),

	/** The clear filter disable. */
	CLEAR_FILTER_BUTTON_DISABLED(By.xpath("//div[contains(@class,'pointer-events-none')]//span[text()='Clear Filter']//parent::button"), "Clear Filter Button Disabled"),
	
	/** The clear filter button active. */
	CLEAR_FILTER_BUTTON_ACTIVE(By.xpath("//div[not(@class='react-ripples ac-primary-box')]//span[text()='Clear Filter']//parent::button"), "Clear Filter Button Active"),

	/** The from date. */
	FROM_DATE(By.xpath("//div[contains(@class,'dp-from')]//input"), "From Date"),

	/** The to date. */
	TO_DATE(By.xpath("//div[contains(@class,'dp-to')]//input"), "To Date"),

	/** The previous month. */
	PREVIOUS_MONTH(By.xpath("//button[contains(@class,'navigation--previous')]"), "Previous month."),

	/** The next month. */
	NEXT_MONTH(By.xpath("//button[contains(@class,'navigation--next')]"), "Next month."),

	/** The all platform. */
	ALL_PLATFORM(By.xpath("//div//button[contains(@class,'roundedbtn btn btn-link active')]//img[contains(@alt,'Platform')]"),
			"All Platform Active State"),

	/** The all platform in active. */
	ALL_PLATFORM_INACTIVE(By.xpath("//div[@class='fltr-imc selectsocial']//button[@class='roundedbtn btn btn-link']//img[contains(@src,'all-platform')]"),
			"All Platform In-Active mode"),

	/** The all platform active. */
	ALL_PLATFORM_ACTIVE(By.xpath("//div[@class='fltr-imc selectsocial']//button[contains(@class,'link active')]//img[contains(@src,'all-platform')]"),"All platform active"),
	
	/** The facebook platform active. */
	FACEBOOK_PLATFORM_ACTIVE(
			By.xpath("//div//button[contains(@class,'active')]//img[contains(@src,'fb-platform.svg')]"),
			"Facebook platform Active"),

	FACEBOOK_PLATFORM(By.xpath("//div//button//img[contains(@src,'fb-platform.svg')]"),"Facebook Plaform"),

	/** The facebook platform in active. */
	FACEBOOK_PLATFORM_INACTIVE(
			By.xpath("//button[not(contains(@class,'active'))]//img[contains(@src,'fb-platform.svg')]"),
			"Facebook Platform In-Active mode"),

	/** The table firstrow facebook data. */
	TABLE_FIRSTROW_FACEBOOK_DATA(By.xpath("//tbody//tr//td[1]//div//img[contains(@src,'fb-lv.svg')]"),
			"Table First Row facebook data"),

	/** The google platform. */
	GOOGLE_PLATFORM_ACTIVE(
			By.xpath("//button[contains(@class,'active')]//img[contains(@src,'google-platform.svg')]"),
			"Google Platform Active"),

	/** The google platform in active. */
	GOOGLE_PLATFORM_INACTIVE(
			By.xpath("//button[not(contains(@class,'active'))]//img[contains(@src,'google-platform.svg')]"),
			"Google Platform Inactive"),

	/** The table firstrow google data. */
	TABLE_FIRSTROW_GOOGLE_DATA(By.xpath("//tbody//tr//td[1]//div//img[contains(@src,'google')]"),
			"Table First Row Google data"),

	/** The yelp platform active. */
	YELP_PLATFORM_ACTIVE(By.xpath("//button[contains(@class,'active')]//img[contains(@src,'yelp-platform.svg')]"),
			"Yelp Platform Active"),

	YELP_PLATFORM_FILTER(By.xpath("//button//img[contains(@src,'yelp-platform.svg')]"),"Yelp Platform Filter"),


			/** The google platform in active. */
	YELP_PLATFORM_INACTIVE(
			By.xpath("//button[not(contains(@class,'active'))]//img[contains(@src,'yelp-platform.svg')]"),
			"Yelp Platform_InActive"),

	KEYWORD_DETAILVIEW_YELP_PLATFORM_INACTIVE(By.xpath("//div[@id='reviews-list-ifs']//following::button[not(contains(@class,'active'))]//img[contains(@src,'yelp-platform.svg')]"),"KEYWORD_DETAILVIEW_YELP_PLATFORM Inactive"),

	/** The table firstrow google data. */
	TABLE_FIRSTROW_YELP_DATA(By.xpath("//tbody//tr//td[1]//div//img[contains(@src,'yelp')]"),
			"Table First Row Yelp data"),

	/** The month dropdown. */
	MONTH_DROPDOWN(By.xpath("//select[@class='react-datepicker__month-select']"), "Month drop down"),

	/** The calendar. */
	CALENDAR(By.xpath("//div[@class='react-datepicker__month-container']"), "Calendar"),
	
	/** The active day. */
	ACTIVE_DAY(By.xpath(
			"//div[contains(@class,'react-datepicker__day react-datepicker__day--031 react-datepicker__day--selected')]"),
			"Active day of the month"),

	/** The year dropdown. */
	YEAR_DROPDOWN(By.xpath("//select[@class='react-datepicker__year-select']"), "Year drop down."),

	// LOCATION SELECTOR'S LOCATORS ENUMS :
	// =======================================

	/** The locations filter modal. */

	/** The location selector. */
	LOCATION_SELECTOR(By.xpath("//div[@class='locAction']//span[@class='lcs-name']"), "Location Selecter."),

	LOCATION_SELECTOR_ALL_LOCATION_OPTION(By.xpath("//label//input[@class='option-input radio']//following-sibling::span[text()='All Locations']"), "Location Selector All Location Option."),

	/** The location selector cancel button. */
	LOCATION_SELECTOR_SELECTED_NAME(
	        "//div[@class='locAction']//ancestor::div[@class='lsl-counts-wrap']//span[text()='%s']//following-sibling::span[@class='lca-sel-label bl-count']",
	        "Location Selector Selected Name"),
	
	/** The location selector open. */
	LOCATION_SELECTOR_PAGE(By.xpath(
			"//div[@class='asm-btn']//parent::div[@class='modal-footer']//preceding-sibling::div[@class='asm-accord']"),
			"Location Selecter Page"),

	/** The location selector hub tab. */
	LOCATION_SELECTOR_HUB_TAB(By.xpath("//div[@class='accordion']//div//div//span[text()='Hubs']"),
			"Location Selecter Hub tab"),

	/** The location selector hub tab open. */
	LOCATION_SELECTOR_HUB_TAB_OPEN(
			By.xpath("//div[contains(@class,'collapse show')]//ul[@class='hub-list']"),
			"Location Selecter Hub Tab Open"),

	/** The location selector location tab. */
	LOCATION_SELECTOR_LOCATION_TAB(By.xpath("//div[@class='card']//div//span[text()='Locations']"), "Location Selecter Location tab"),

	/** The location selector locationlist tab. */
	LOCATION_SELECTOR_LOCATIONLIST_TAB(By.xpath("//div[@class='accordion']//*[text()='Location Lists']"),
			"Location Selecter Location List tab"),
	
	/** The location selector locationlist tab open. */
	LOCATION_SELECTOR_LOCATIONLIST_TAB_OPEN(By.xpath("//div[contains(@class,'collapse show')]//img[contains(@src,'locationLists')]"),
			"Location Selecter Location List tab Open"),

	/** The location selector location tab open. */
	LOCATION_SELECTOR_LOCATION_TAB_OPEN(
			By.xpath("//div[contains(@class,'collapse show')]//img[contains(@src,'location') and not(contains(@src,'Lists'))]"),
			"Location Selecter Location Tab Open"),
	
	/** The location selector dropdown user. */
	LOCATION_SELECTOR_DROPDOWN_USER("//div//ul[@class='hub-list']//span[contains(text(),\"%s\")]",
			"Location Selecter Dropdown User"),
	
	/** The list of hubs. */
	LIST_OF_HUBS(By.xpath(
			"//div[contains(@class,'collapse show')]//ul[@class='hub-list']//img[contains(@src,'hubs-grey')]"),
			"List of Hubs"),

	/** The list of locations. */
	LIST_OF_LOCATIONS(By.xpath(
			"//div[contains(@class,'collapse show')]//img[contains(@src,'location') and not(contains(@src,'Lists'))]"),
			"List of Locations"),

	/** The list of locationlist. */
	LIST_OF_LOCATIONLIST(By.xpath(
			"//div[contains(@class,'collapse show')]//img[contains(@src,'locationLists')]"),
			"List of Location list"),

	// LOCATION_SELECTOR_CHOOSE_HUB(By.xpath("//div[@class='card']//div[@class='collapse
	// show']//ul[@class='hub-list']//li//label//span[text()='']"), "Location
	// Selecter Hub Tab Open."),

	// LOCATION_SELECTOR_ACTIVE_HUB(By.xpath("//div[@class='card']//div[@class='collapse
	// show']//ul[@class='hub-list']//li//label//span[contains(@class,'active') and
	// text()='Alvarado']"), "Location Selecter Hub Tab Open."),

	/** The location selector ok button. */
	LOCATION_SELECTOR_OK_BUTTON(By.xpath("//div[@class='asm-btn']//div//button[text()='Ok']"),
			"Location Selecter Ok Button"),

	/** The location selector search tab. */
	LOCATION_SELECTOR_SEARCH_TAB(By.xpath("//div[@class='asm-lf']//input[@placeholder = 'Search']"),
			"Location Selecter Search Tab"),

	/** The location selector cancel button. */
	LOCATION_SELECTOR_CANCEL_BUTTON(By.xpath("//div[@class='asm-btn']//div//button[text()='Cancel']"),
			"Location Selector Cancel Button"),

	/** The facebook data. */
	FACEBOOK_DATA(By.xpath("//div[@class='active-tile list-group-item']//span[text()='Facebook']"),"The facebook data page loaded"),
	
	/** The location selector close button. */
	LOCATION_SELECTOR_CLOSE_BUTTON(By.xpath("//img[@class='close-icon']"), "Location Selector Close Button"),
	
	/** The reviews list. */
	REVIEWS_LIST(By.xpath("//div[@class='list-item animate__animated animate__fadeIn reputation-wrp']"),"Reviews list"),
	
	/** The positive green letters. */
	POSITIVE_GREEN_LETTERS(By.xpath("//*[@class='highcharts-series-group']//*[local-name()='text' and @fill='#21D184']"),"Positive Green Letters"),
	
	/** The negative red letters. */
	NEGATIVE_RED_LETTERS(By.xpath("//*[@class='highcharts-series-group']//*[local-name()='text' and @fill='#FF5C5C']"),"Negative Red Letters"),
	
	/** The neutral grey letters. */
	NEUTRAL_GREY_LETTERS(By.xpath("//*[@class='highcharts-series-group']//*[local-name()='text' and @fill='#00000066']"),"Neutral Grey Letters"),
	
	/** The keywords letters text. */
	KEYWORDS_LETTERS_TEXT("//span[contains(text(),'%s')]","Letters Text"),
	
	/** The keywords letters detailview header text. */
	KEYWORDS_LETTERS_DETAILVIEW_HEADER_TEXT(By.xpath("//div[@class='header-item__wrp']//span"),"Letters Detail View header text"),
	
	/** The keywords letters detailview close. */
	KEYWORDS_LETTERS_DETAILVIEW_CLOSE(By.xpath("//div[@class='header-item__wrp']//span//following-sibling::img[@alt='close']"),"Letters DetailView close button"),
	
	/** The keywords review posts no data to show. */
	KEYWORDS_REVIEW_POSTS_NO_DATA_TO_SHOW(By.xpath("//span[text()='No data to show']"),"KEYWORDS_REVIEW_POSTS_NO_DATA_TO_SHOW"),

	/** The table keyword field. */
	TABLE_KEYWORD_FIELD("//td//div[text()='Keyword']//following-sibling::div[text()='%s']","Table KeyWord"),
	
	/** The total keyword rows. */
	TOTAL_KEYWORD_ROWS("//th[@class='cur-pointer active']//div[text()='%s']//ancestor::table//tbody//following-sibling::tbody//tr//td[@class='active ']//div[text()]","Total Keyword Rows"),

	NEUTRAL_TOTAL_COUNT("//th[contains(@class,'cur-pointer')]//div[text()='%s']//ancestor::table//tbody//td//div[@class='neutral-col total-txt']","Neutral Total Count"),

	/** The keywords table keywordheading. */
	KEYWORDS_TABLE_KEYWORDHEADING(By.xpath("//div[contains(@class,'resuseTable')]//table//th//div[text()='Keywords']"),"Keyword table heading"),
	
	/** The keywords table heading. */
	KEYWORDS_TABLE_HEADING(By.xpath("//table//th//div[text()='Keywords']//following::th"),"Keyword table heading"),
	
	/** The individual keyword header. */
	INDIVIDUAL_KEYWORD_HEADER("//table//thead//th//div[text()='Keywords']//following::th//div[text()='%s']","Individual Keyword header"),
	
	/** The keywords down arrow. */
	KEYWORDS_DOWN_ARROW("//table//tr//th//div[text()='%s']//img[@class='sort-icon ']","KeyWords Downarrow"),
	
	/** The keywords up arrow. */
	KEYWORDS_UP_ARROW("//table//tr//th//div[text()='%s']//img[@class='sort-icon sort-icon__rotate']","Keywords Up Arrow"),
	
	/** The keywords table first row value. */
	KEYWORDS_TABLE_FIRST_ROW_VALUE("//th[@class='cur-pointer active']//div[text()='%s']//ancestor::table//tbody//following-sibling::tbody//tr[1]//td[@class='active ']//div[text()]","KEYWORDS_TABLE_FIRST_ROW_HIGHEST_VALUE"),

	NEGATIVE_FIRST_ROW_VALUE("//table//th//div[text()='%s']//ancestor::table//tbody[2]//tr[1]//td[5]","Location Negative First Row Value"),

	POSITIVE_FIRST_ROW_VALUE("//table//th//div[text()='%s']//ancestor::table//tbody[2]//tr[1]//td[3]","Location Positive First Row Value"),

	NEUTRAL_FIRST_ROW_VALUE("//table//th//div[text()='%s']//ancestor::table//tbody[2]//tr[1]//td[4]","Location Neutral First Row Value"),

	/** The keywords first row value. */
	KEYWORDS_FIRST_ROW_VALUE("//th[@class='cur-pointer active']//div[text()='%s']//ancestor::table//tbody//following-sibling::tbody//tr//td[@class='active ']//div[text()='%s']","Keywords First Row Value"),
	
	/** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),
	
	/** The keywords table values. */
	KEYWORDS_TABLE_VALUES(By.xpath("//div[text()='Keywords']//ancestor::table//tbody//following-sibling::tbody//tr//td[@class='active ']//div[text()]"),"Keywords Text List"),
	
	/** The keywords table text list. */
	KEYWORDS_TABLE_TEXT_LIST(By.xpath("//th[@class='cur-pointer active']//div[text()='Keywords']//ancestor::table//tbody//following-sibling::tbody//tr//td[@class='active ']//div[text()]"),"Keywords Text List"),
	
	//Operational Categories
	/** The Operational categories. */
	ADD_NEW_CATEGORY_BUTTON(By.xpath("//section[contains(@class,'item-g filter ra')]//button[contains(@class,'ac-btn ac-primary-light')]//span[text()='Add New Category']"),"Add new category button"),
	
	/** The Operational categories. */
	OPERATIONAL_CATEGORY(By.xpath("//div[contains(@class,'filter-item filter-item')]//div[@class='fts']//parent::div//div[@class='imtc ef-edit']//h3[text()='Operational Categories']"),"Operational category"),
	
	/** The Operational categories - category name. */
	OPERATIONAL_CATEGORY_NAME(By.xpath("//div[contains(@class,'sec-main__content')]//div[@class='ra-card sec-conn__wrp']//input[@name='name']"),"Operational category name"),
	
	/** The Operational categories - Description. */
	OPERATIONAL_CATEGORY_DESCRIPTION(By.xpath("//div[contains(@class,'sec-main__content')]//div[@class='form-group form-field-item kc-dsrn ']//textarea[@class='form-control']"),"Operational category description"),
	
	/** The Operational categories - Available keywords. */
	OPERATIONAL_CATEGORY_AVAILABLE_KEYWORDS(By.xpath("//div[contains(@class,'sec-main__content')]//div[@class='cas-item cas-left flex-fill']//h3[@class='glbl__title--txt' and text()='Available Keywords']"),"Operational category available keywords"),
	
	/** The Operational categories - Available keywords count value. */
	OPERATIONAL_CATEGORY_AVAILABLE_KEYWORDS_COUNT(By.xpath("//div[contains(@class,'sec-main__content')]//div[@class='cas-item cas-left flex-fill']//h3[@class='glbl__title--txt' and text()='Available Keywords']//span"),"Operational category available keywords count value"),

	/** The Operational categories - Available keywords search option */
	OPERATIONAL_CATEGORY_AVAILABLE_KEYWORDS_SEARCH_OPTION(By.xpath("//div[contains(@class,'sec-main__content')]//h3[@class='glbl__title--txt' and text()='Available Keywords']//parent::div//input[@placeholder='Search']"),"Operational category available keywords count value"),
	
	/** The Operational categories - Available keywords list */
	OPERATIONAL_CATEGORY_AVAILABLE_KEYWORDS_LIST(By.xpath("//div[contains(@class,'sec-main__content')]//h3[@class='glbl__title--txt' and text()='Available Keywords']//parent::div//div//div[@class='casb']//div[@class='ar-wrap']"),"Operational category available keywords list"),
	
	/** The Operational categories - Selected keywords list */
	OPERATIONAL_CATEGORY_SELECTED_KEYWORDS(By.xpath("//div[contains(@class,'sec-main__content')]//div[@class='cas-item cas-left flex-fill']//h3[@class='glbl__title--txt' and text()='Selected Keywords']"),"Operational category Selected keywords"),
	
	/** The Operational categories - Available keywords count value. */
	OPERATIONAL_CATEGORY_SELECTED_KEYWORDS_COUNT(By.xpath("//div[contains(@class,'sec-main__content')]//div[@class='cas-item cas-left flex-fill']//h3[@class='glbl__title--txt' and text()='Selected Keywords']//span"),"Operational category selected keywords count value"),

	/** The Operational categories - Selected keywords search option */
	OPERATIONAL_CATEGORY_SELECTED_KEYWORDS_SEARCH_OPTION(By.xpath("//div[contains(@class,'sec-main__content')]//h3[@class='glbl__title--txt' and text()='Selected Keywords']//parent::div//input[@placeholder='Search']"),"Operational category selected keywords count value"),
	
	/** The Operational categories - Selected keywords list */
	OPERATIONAL_CATEGORY_SELECTED_KEYWORDS_LIST(By.xpath("//div[contains(@class,'sec-main__content')]//h3[@class='glbl__title--txt' and text()='Selected Keywords']//parent::div//div//div[@class='casb']"),"Operational category available keywords list"),
	
	/** The Operational categories - Close option */
	OPERATIONAL_CATEGORY_CLOSE_OPTION(By.xpath("//div[@class='modal-content']//div[contains(@class,'mod__close')]//img[@alt='close']"),"Operational category close option"),
	
	/** The Operational categories - Save button */
	OPERATIONAL_CATEGORY_SAVE_BUTTON(By.xpath("//div[@class='modal-body']//div[contains(@class,'react-ripples')]//button[@type='submit' and text()='Save']"),"Operational category save button"),
	
	/** The Operational categories - Keyword */
	TABLE_LIST_KEYWORD(By.xpath("//table[@class='responsiveTable table']//tbody[2]//tr//td//div[text()]"),"Operational category Keyword"),
	
	/** The Operational categories - Keyword */
	TABLE_LIST_EDITED_KEYWORD(By.xpath("//table[@class='responsiveTable table']//tbody[2]//tr//td//div[text()]"),"Operational category edited Keyword"),
	
	/** The Operational categories - Selected keywords count value. */
	OPERATIONAL_CATEGORY_SELECTED_KEYWORD_COUNT(By.xpath("//div[contains(@class,'sec-main__content')]//div[@class='cas-item cas-left flex-fill']//h3[@class='glbl__title--txt' and text()='Selected Keywords']//span[text()='(1)']"),"Operational category selected keywords count value increamented"),
	
	/** The Operational categories - success Message */
	OPERATIONAL_CATEGORY_SUCCESS_MESSAGE(By.xpath("//div[contains(@class,'Toastify__toast')]//span[@class='success-mess-txt' and text()='Category added successfully!']"),"Operational category success message"),
	
	/** The Operational categories - updated success Message */
	OPERATIONAL_CATEGORY_UPDATED_SUCCESS_MESSAGE(By.xpath("//div[contains(@class,'Toastify__toast')]//span[@class='success-mess-txt' and text()='Category updated successfully!']"),"The Operational categories - updated success Message"),
	
	/** The Operational categories - Delete success Message */
	OPERATIONAL_CATEGORY_DELETE_SUCCESS_MESSAGE(By.xpath("//div[contains(@class,'Toastify__toast')]//span[@class='success-mess-txt' and text()='Category deleted successfully!']"),"The Operational categories - Delete success Message "),
	
	/** The Operational categories -  */
	NEW_OPERATIONAL_CATEGORY("//div[contains(@class,'filter-item filter')]//div[@class='fts']//span[@class='fav-tags '][text()='%s']","New Operational category"),
	
	/** Table list keyword on selecting category */
	TABLE_LIST_KEYWORD_ON_SELECTING_CATEGORY(By.xpath("//table[@class='responsiveTable table']//tbody[2]//tr//td//div[text()]"),"Table list keyword on selecting category"),
	
	/** Line chart keyword on selecting category */
	LINE_CHART_KEYWORD_ON_SELECTING_CATEGORY(By.xpath("//*[local-name()='g' and @class='highcharts-series-group']//*[local-name()='text']"),"Line chart keyword on selecting category"),

	/** Selecting available keywords */
	SELECTING_AVAILABLE_KEYWORDS("//div[@class='ar-wrap']//span[text()='%s']//parent::div//input[@type='checkbox']",
			"Selecting available keywords"),

	/** The start date at date picker*/
	DATE_PICKER("//div[@class='react-datepicker']//div[contains(@class,'react-datepicker__day react') and not( contains(@class,'react-datepicker__day--disabled'))  and text()='%s']",
			"The start date at date picker"),
	
	/** The Operational categories - Location view's line chart  */
	NEW_OPERATIONAL_CATEGORY_LINE_CHART("//div[@class='header-item__wrp']//li[@title='%s']","New Operational category- Location view's line chart"),
	
	/** The Operational categories - line chart */
	NEW_OPERATIONAL_CATEGORY_LINE_CHART_ALL_OPTION(By.xpath("//div[@class='header-item__wrp']//span[@class='sub-nav-item-txt' and text()='All']"),"The Operational categories - line chart"),
	
	/** Line chart category name  */
	LINE_CHART_CATEGORY_NAME("//div[contains(@class,'ra-card over')]//span[@class='categoryPropValue']//span[2][@title='%s']","Line chart - category name"),
	
	/** Operational categories line chart */
	OPERATIONAL_CATEGORY_LINE_CHART(By.xpath("//div[@class='review-an-container']//div[@class='an-reviews-highlights lpx']"),"Operational categories line chart in location view "),
	
	/** Operational categories Edit option */
	OPERATIONAL_CATEGORY_EDIT_OPTION(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='imtc ef-edit']//span[@class='cf-values' and text()='Edit']"),"Operational categories Edit option "),
	
	/** Operational categories Individual Edit option */
	OPERATIONAL_CATEGORY_INDIVIDUAL_EDIT_OPTION("//li[@class='ripple active']//span[@class='sub-nav-item-txt' and text()='%s']","Operational categories Individual Edit option "),
	
	/** Operational categories remove keyword option */
	OPERATIONAL_CATEGORY_REMOVE_KEYWORD(By.xpath("//div[contains(@class,'cas-tree tree')]//div[@class='react-ripples ac-primary-box']//button[@class='kc-remove']"),"Operational categories Edit option "),
	
	/** Operational categories delete button */
	OPERATIONAL_CATEGORY_DELETE_BUTTON(By.xpath("//div[contains(@class,'react-ripples')]//button[@class='ac-btn ac-primary ac-block kc-del' and text()='Delete']"),"Operational categories delete button"),
	
	/** Operational categories delete modal delete button */
	OPERATIONAL_CATEGORY_DELETE_MODAL_DELETE_BUTTON(By.xpath("//div[@class='modal-content']//button[@class='modal-btn-action-itm modal-delete-btn' and text()='Delete']"),"Operational categories delete modal delete button"),
	
	/** Brand Hub Location dropdown. */
	BRAND_HUB_LOCATION_DROPDOWN(By.xpath("//div[@class='brand-profile h-assorted']//div[@class='ds-dropdown']"), "Brand Hub Location dropdown"),

	/** Brand Hub Location name. */
	BRAND_HUB_LOCATION_NAME(By.xpath("//div[@class='ds-dropdown']//parent::div//button//span"), "Brand Hub Location name"),
	
	/** Brand Hub Location dropdown search. */
	BRAND_HUB_LOCATION_DROPDOWN_SEARCH(By.xpath("//div[@class='ds-drp-indicator']//parent::div//preceding-sibling::div//input"), "Brand Hub Location dropdown search"),

	/** Select account from dropdown. */
	SELECT_ACCOUNT_FROM_DROPDOWN("//div[@class='brand-profile h-assorted']//div[@class='ds-dropdown']//div[@class='ds-menu']//div[contains(@id,'react-select') and text()='%s']",
	        "Select account from dropdown"),
	
	/** The selected account name. */
	SELECTED_ACCOUNT_NAME("//div[@class='ds-dropdown']//button//span[@class='css-19r5em7' and text()='%s']","Selected Account From Dropdown Name"),
	
	/** Operational category compulsary description field alert */
	OPERATIONAL_CATEGORY_COMPULSARY_FIELD_DESCRIPTION_ALERT(By.xpath("//div[contains(@class,'sec-main__content')]//div[contains(@class,'orm-group form')]//span[@class='fltlabels fltlabels-error-text' and text()='Description']"), "Operational category compulsary description field alert"),
	
	/** Operational category compulsary field name alert */
	OPERATIONAL_CATEGORY_COMPULSARY_FIELD_NAME_ALERT(By.xpath("//div[contains(@class,'sec-main__content')]//div[contains(@class,'orm-group form')]//span[@class='fltlabels fltlabels-error-text' and text()='Category Name']"), "Operational category compulsary name field alert"),
	
	/** All option in operational category*/
	OPERATIONAL_CATEGORY_ALL_OPTION(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='fts']//span[contains(@class,'fav-tags ') and text()='All']"), "All option in operational category"),
	
	/** Location selector - selecting the location*/
	LOCATION_SELECTOR_SELECTING_LOCATION(By.xpath("//div[@class='accordion-collapse collapse show']//span[@class='lcs-name']"), "All option in operational category"),
	
	/** Location selector - All location option*/
	LOCATION_SELECTOR_ALL_LOCATION(By.xpath("//div[@class='locAction']//span[@class='lcs-name' and text()='All Locations']"), "Location selector - All location option"),
	
	/** Download csv success message*/
	DOWNLOAD_CSV_SUCCESS_MESSAGE(By.xpath("//div[@class='Toastify__toast-body']//span[@class='success-mess-txt' and text()='Done!']"), "Download csv success message"),
	
	/** Keyword Detail view*/
	KEYWORD_DETAIL_VIEW_FACEBOOK_REVIEW(By.xpath("//div[contains(@class,'list-item animate')]//img[contains(@src,'fb-lv.svg')]"), "Keyword Detail view - Facebook review"),
	
	/** Keyword Detail view*/
	KEYWORD_DETAIL_VIEW_LOCATION_VALIDATION(By.xpath("//div[contains(@class,'list-item animate')]//div[@class='lvt-details']//span[contains(text(),'Bean Me Down LA')]"), "Keyword Detail view"),
	
	/** The new reviews count value. */
	NEW_REVIEWS_COUNT_VALUE("//span[(text()='New Reviews')]//parent::div//div[@class='an-stat--b1']//span[@class='big-number-text' and text()='%s']",
			"new reviews count value"),

	ALL_KEYWORDS_LETTERS_DETAILVIEW_REVIEWS(By.xpath("//div[@class='list-view review-list__main']//div[@class='lv-assets']//p[text()]"),"ALL_KEYWORDS_LETTERS_DETAILVIEW_REVIEWS"),

	ALL_KEYWORDS_DETAILVIEW_REVIEW_RECOMMENDS_TEXT(By.xpath("//div[@class='list-view review-list__main']//div[@class='pu-item']//following-sibling::span[1][contains(text(),'recommends')]"),"All Keywords Detailview Review Recommends text"),

	ALL_KEYWORDS_DETAILVIEW_REVIEW_FIVE_STAR(By.xpath("//div[contains(@class,'list-item animate')]//div//span[@class='sr-item five-star']"),"All Keywords Detail view Review 5 Star"),

	ALL_KEYWORDS_DETAILVIEW_REVIEW_ONE_STAR(By.xpath("//div[contains(@class,'list-item animate')]//div//span[@class='sr-item one-star']"),"All Keywords Detail view Review 1 Star"),

	ALL_KEYWORDS_DETAILVIEW_REVIEW_TWO_STAR(By.xpath("//div[contains(@class,'list-item animate')]//div//span[@class='sr-item two-star']"),"All Keywords Detail view Review 2 Star"),


	ALL_KEYWORDS_DETAILVIEW_REVIEW_NOT_RECOMMENDS_TEXT(By.xpath("//div[@class='list-view review-list__main']//div[@class='pu-item']//following-sibling::span[1][contains(text(),'does not recommend')]"),"ALL_KEYWORDS_DETAILVIEW_REVIEW_NOT_RECOMMENDS_TEXT"),

	RECOMMENDED_RATING_ACTIVE(By.xpath("//label[@class='checkbox-item active rnrbgwrap']//div[@class='star-social-rec rnr-bg']//span[text()='Recommended']"),"Recommended Rating Active"),

	NOT_RECOMMENDED_RATING_ACTIVE(By.xpath("//label[@class='checkbox-item active rnrbgwrap']//div[@class='star-social-rec rnr-bg']//span[text()='Not Recommended']"),"Not Recommended Active"),

	ONE_STAR_RATING_ACTIVE(By.xpath("//label[@class='checkbox-item active ']//span//following-sibling::span[text()='1 Star']"),"One Star Rating Rating"),

	TWO_STA_RATING_ACTIVE(By.xpath("//label[@class='checkbox-item active ']//span//following-sibling::span[text()='2 Stars']"),"Two Star Rating"),

	THREE_STAR_RATING_ACTIVE(By.xpath("//label[@class='checkbox-item active ']//span//following-sibling::span[text()='3 Stars']"),"Three Star Rating Active"),

	FOUR_STAR_RATING_ACTIVE(By.xpath("//label[@class='checkbox-item active ']//span//following-sibling::span[text()='4 Stars']"),"Four Star rating"),

	FIVE_STAR_RATING_ACTIVE(By.xpath("//label[@class='checkbox-item active ']//span//following-sibling::span[text()='5 Stars']"),"Five Star Rating"),

	;
	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new analytics tab reviews page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private AnalyticsTabReviewsPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}
	/**
	 * Instantiates a new analytics tab reviews page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private AnalyticsTabReviewsPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return byLocator;
	}

	/**
	 * Gets the by xpath.
	 *
	 * @return the by xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}
}

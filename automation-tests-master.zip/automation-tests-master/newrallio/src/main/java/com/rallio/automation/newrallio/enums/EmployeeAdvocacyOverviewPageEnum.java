package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum EmployeeAdvocacyLeaderboardPageEnum.
 */
public enum EmployeeAdvocacyOverviewPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Overview']//ancestor::div//section[contains(@class,'item-g filter adv-ov-filter')]//preceding::div//section[@id='main-container-sec']//div[@class='content-g']//div[contains(@class,'adv-overview adv-overview_main emp__adv--over mbl-head--margin')]"), "Page Load For overview Page"),

	/** The total advocates. */
	TOTAL_ADVOCATES(By.xpath("//div[@class='fcs-top']/span[contains(text(),'Total Advocates')]"), "Total advocates"),

	/** The total advocates i button. */
	TOTAL_ADVOCATES_I_BUTTON(By.xpath("//span[text()='Total Advocates']//parent::div//img[contains(@src,'information-grey.svg')]"), "Total advocates i button"),

	/** The total advocates count value. */
	TOTAL_ADVOCATES_COUNT_VALUE(By.xpath("//div[@class='fc-stats']/span[@class='fcs-count']"), "Total Advocates count number"),

	/** The advocates active tab. */
	ADVOCATES_ACTIVE_TAB(By.xpath("//div[@class='fcs-top ']/span[contains(text(),'Active')]"), "Active Tab."),

	/** The advocates active count value. */
	ADVOCATES_ACTIVE_COUNT_VALUE(By.xpath("//span[@class='fcs-count r-mt0 count-variant-sm']"), "Active count number"),

	/** The active count delta icon. */
	ACTIVE_COUNT_DELTA_ICON(By.xpath("//div[@class='count-range']//img[contains(@src,'cr')]"), "Active Delta icon."),

	/** The active count percentage value. */
	ACTIVE_COUNT_PERCENTAGE_VALUE(By.xpath("//span[@class='cr-p-num']"), "Active Percent value."),

	/** The advocates inactive tab. */
	ADVOCATES_INACTIVE_TAB(By.xpath("//div[@class='fc-stats']//span[text()='Inactive']"), "Advocates inactive tab"),

	/** The advocates inactive count value. */
	ADVOCATES_INACTIVE_COUNT_VALUE(By.xpath("//div[@class='fc-stats']//span[text()='Inactive']//parent::div//following-sibling::span[contains(@class,'count-variant')]"), "Advocates Inactive count number"),

	/** The human image. */
	HUMAN_IMAGE(By.xpath("//div[@class='fc-right']/div[@class='fill-character']"), "Human image"),
	
	/** The human image for active. */
	ACTIVE_HUMAN_IMAGE(By.xpath("//div[@class='fill-character']//*[@width='104'][2]"), "Active Human Image"),

	/** The human image for inactive. */
	INACTIVE_HUMAN_IMAGE(By.xpath("(//div[@class='fill-character']//*[@width='104'][1])[2]"),
			"Inactive Human Image"),

	/** The inactive human image tooltip.*/
	INACTIVE_HUMAN_IMAGE_TOOLTIP(
			By.xpath("//div[contains(@class,'tooltip-content')]//span[text()='Advocates with no recent activity']"),
			"Inactive Human Image Tooltip Text"),
    
	/** The active human image tooltip. */
	ACTIVE_HUMAN_IMAGE_TOOLTIP(
			By.xpath("//div[contains(@class,'tooltip-content')]//span[text()='Advocates who have been actively creating/uploading media assets and posts.']"),
			"Active Human Image Tooltip Text"),
	
	/** The total advocates i button tooltip. */
	TOTAL_ADVOCATES_I_BUTTON_TOOLTIP(By.xpath("//div[contains(@class,'tooltip-content')]//div[text()='Total advocates that have been sent an invite']"),
			"Total Advocates I Button Tooltip text"),

	/** The compared to last period. */
	COMPARED_TO_LAST_PERIOD(By.xpath("//span[contains(text(),'Compared to last period')]"), "Compared to last period."),

	/** The media assets. */
	MEDIA_ASSETS(By.xpath("//div[@class='rlg-item rlgt-right']"), "Media assets"),
	
	/** The image assets. */
	IMAGE_ASSETS(By.xpath("//span[@class='mar-head' and contains(text(),'Image Assets')]"), "Image assets"),
	
	/** The image assets tooltip. */
	IMAGE_ASSETS_TOOLTIP(By.xpath("//div[contains(@class,'tooltip-content')]//div[text()=' Total image assets uploaded by employees']"), "Image assets tooltip text"),
	
	/** The image asset totalcount. */
	IMAGE_ASSET_TOTALCOUNT(By.xpath("//div[@class='mar-big']/span[2]"), "Image assets total count."),
	
	/** The image asset unusedcount. */
	IMAGE_ASSET_UNUSEDCOUNT(By.xpath("//div[@class='mar-big']/span[contains(text(),'Image Assets')]//parent::div//parent::div/div[2]/span[2]"), "Image assets unused Count"),
	
	/** The used image assets tooltip. */
	USED_IMAGE_ASSETS_TOOLTIP(By.xpath(
			"//div[contains(@class,'tooltip-content')]//div[text()='Total image assets from employees that are already used in posts']"),
			"Used Image assets tooltip text"),

	/** The unused image assets tooltip. */
	UNUSED_IMAGE_ASSETS_TOOLTIP(By.xpath(
			"//div[contains(@class,'tooltip-content')]//div[text()='Total image assets from employees that are not yet used in posts']"),
			"UnUsed Image assets tooltip text"),

	/** The image asset usedcount. */
	IMAGE_ASSET_USEDCOUNT(By.xpath("//div[@class='mar-big']/span[contains(text(),'Image Assets')]//parent::div//parent::div/div[3]/span[2]"), "Image assets used Count"),
	
	/** The image asset used tooltip. */
	IMAGE_ASSET_USED_TOOLTIP(By.xpath(
			"//div[@class='mar-big']/span[contains(text(),'Image Assets')]//parent::div//parent::div/div[3]/span[2]"),
			"Image assets used tooltip"),

	/** The video assets. */
	VIDEO_ASSETS(By.xpath("//span[@class='mar-head' and contains(text(),'Video Assets')]"), "Video assets"),
	
	/** The video assets tooltip. */
	VIDEO_ASSETS_TOOLTIP(By.xpath(
			"//div[contains(@class,'tooltip-content')]//div[text()=' Total video assets uploaded by employees']"),
			"Video assets tooltip text"),
	
	/** The video asset totalcount. */
	VIDEO_ASSET_TOTALCOUNT(By.xpath("//div[@class='mar-big mar-pb']/span[2]"), "Video assets total count."),

	/** The video asset unusedcount. */
	VIDEO_ASSET_UNUSEDCOUNT(By.xpath("//div[@class='mar-big mar-pb']/span[contains(text(),'Video Assets')]//parent::div//parent::div/div[2]/span[2]"), "Video assets unused Count"),
	
	/** The unused video assets tooltip. */
	UNUSED_VIDEO_ASSETS_TOOLTIP(By.xpath(
			"//div[contains(@class,'tooltip-content')]//div[text()='Total video assets from employees that are not yet used in posts']"),
			"UnUsed Video assets tooltip text"),
	/** The video asset usedcount. */
	VIDEO_ASSET_USEDCOUNT(By.xpath("//div[@class='mar-big mar-pb']/span[contains(text(),'Video Assets')]//parent::div//parent::div/div[3]/span[2]"), "Video assets used Count"),
	
	/** The used video assets tooltip. */
	USED_VIDEO_ASSETS_TOOLTIP(By.xpath(
			"//div[contains(@class,'tooltip-content')]//div[text()='Total video assets from employees that are already used in posts']"),
			"Used Video assets tooltip text"),
	
	/** The posts. */
	POSTS(By.xpath("//h3[text()='Posts']//parent::div[contains(@class,'rlgb-left')]"), "Posts tab."),

	/** The donut chart. */
	DONUT_CHART(By.xpath("//div[@class='donutChart']//div[@class='dcMain']"), "Donut chart."),

	/** The total posts. */
	TOTAL_POSTS_TEXT(By.xpath("//div[@class='highcharts-label highcharts-data-label highcharts-data-label-color-0 highcharts-tracker']//span"), "Total posts text"),
	
	/** The total posts tooltip message. */
	TOTAL_POSTS_TOOLTIP_MESSAGE(By.xpath("//*[contains(text(),'Total posts created for this location by all')]"), "Total posts Tooltip text"),
	
	BRAND_USER_TOTAL_POSTS_TOOLTIP_MESSAGE(By.xpath("//*[contains(text(),'Total posts created by all users')]"), "Total posts Tooltip text"),
	
	/** The branduser total posts tooltip message. */
	BRANDUSER_TOTAL_POSTS_TOOLTIP_MESSAGE(
			By.xpath("//*[text()='Total posts created by all users']"),
			"Brand user Total posts Tooltip text"),
	
	/** The total posts text by hover. */
	TOTAL_POSTS_TEXT_BY_HOVER(By.xpath("//*[text()='Total posts created for this location by all users']"), "Total posts Tooltip message"),

	/** The total posts text by hoverbrand. */
	TOTAL_POSTS_TEXT_BY_HOVERBRAND(By.xpath("//*[text()='Total posts created by all users']"),"Total posts Tooltip message"),
	
	/** The total posts i symbol. */
	TOTAL_POSTS_I_SYMBOL(By.xpath("//div[contains(@class,'highcharts-data-label')]//div//span//div//img[contains(@src,'information')]"), "total Posts i symbol."),

	/** The total posts count value. */
	TOTAL_POSTS_COUNT_VALUE(By.xpath("//div[contains(@class,'highcharts-data-label')]//div//span//div//span[@class='donut-lbl__value']"), "Total posts count value."),

	/** The used posts. */
	USED_POSTS_TEXT(By.xpath("//div[@class='donutChart']//*[contains(text(),'Used Posts')]"), "Used posts Text"),
	
	/** The used posts tooltip message. */
	USED_POSTS_TOOLTIP_MESSAGE(By.xpath("//*[text()='Scheduled posts, yet to be published']"), "Used posts Tooltip text"),
	
	/** The used posts text by hover. */
	USED_POSTS_TEXT_BY_HOVER(By.xpath("//*[text()='Scheduled posts, yet to be published']"), "Used posts Text by Hover"),
	////div[contains(@class,'highcharts-series-hover')]//div//div[2]
	
	/** The used posts with count value. */
	USED_POSTS_WITH_COUNT_VALUE(By.xpath("//div[contains(@class,'highcharts-series-1')]//div//span//span//img[@class='donut-chart-info-ico']//following-sibling::span[@class='donut-lbl__value']"), "Used Posts count value."),

	/** The used posts with i symbol. */
	USED_POSTS_WITH_I_SYMBOL(By.xpath("//div[contains(@class,'highcharts-series-1')]//div//span//span//img"), "Used Posts i symbol."),

	/** The published posts. */
	PUBLISHED_POSTS(By.xpath("//img[contains(@class,'donut-chart-info') ]//parent::span[contains(@data-title,'The number of posts published')]"), "Published posts"),
	
	/** The published posts text. */
	PUBLISHED_POSTS_TEXT(By.xpath(
			"//div[@class='donutChart']//*[contains(text(),'Published')]"),
			"Published posts Text"),
	
	/** The published posts tooltip text. */
	PUBLISHED_POSTS_TOOLTIP_TEXT(By.xpath(
			"//*[text()='Total published posts for this location']"),
			"Published posts Tooltip text"),
	
	/** The branduser published posts tooltip text. */
	BRANDUSER_PUBLISHED_POSTS_TOOLTIP_TEXT(By.xpath(
			"//*[text()='Total published posts']"),
			"Brand user Published posts Tooltip text"),

	/** The published posts text by hover. */
	PUBLISHED_POSTS_TEXT_BY_HOVER(
			By.xpath("//*[text()='Total published posts for this location']"),
			"Published posts Text by hover"),

	/** The published posts text by hoverbrand. */
	PUBLISHED_POSTS_TEXT_BY_HOVERBRAND(By.xpath("//*[text()='Total published posts']"),"The Published Posts Text By hover"),
	
	/** The published posts with count value. */
	PUBLISHED_POSTS_WITH_COUNT_VALUE(By.xpath("//div[contains(@class,'highcharts-series-2')]//div//span//span//img[@class='donut-chart-info-ico']//following-sibling::span[@class='donut-lbl__value p_post']"),
	        "Published Posts count value."),

	/** The published posts with i value. */
	PUBLISHED_POSTS_WITH_I_VALUE(By.xpath("//div[contains(@class,'highcharts-series-2')]//div//span//span//img"), "Published Posts i symbol."),

	/**The total post tab. */
	TOTAL_POST_TAB(By.xpath("//div[contains(@class,'chartTabs ea-tabs')]//li//span[text()='Total Posts']"), "Total posts result tab"),
	
	/** The total post tab active.*/
	TOTAL_POST_TAB_ACTIVE(By.xpath("//div[contains(@class,'chartTabs ea-tabs')]//li[contains(@class,'active')]//span[text()='Total Posts']"),
			"Total posts result tab Active"),
	
	/** The used post tab. */
	USED_POST_TAB(By.xpath("//div[contains(@class,'chartTabs ea-tabs')]//span[text()='Used Posts']"), "USED posts tab"),
	
	/** The used post tab active. */
	USED_POST_TAB_ACTIVE(By.xpath(
			"//div[contains(@class,'chartTabs ea-tabs')]//li[contains(@class,'active')]//span[text()='Used Posts']"),"USED posts tab Active"),
	
	USED_POST_TAB_ACTIVE_PROD(By.xpath("//button[contains(@id,'Monthly-posts-chart-tab-usedPostsResult') and contains(@class,'nav-link active')]"),
			"Used posts result tab Active PROD"),

	/** The published post tab. */
	PUBLISHED_POST_TAB(By.xpath("//div[contains(@class,'chartTabs ea-tabs')]//span[text()='Published Posts']"), "Published posts result tab"),
	
	/** The published post tab active. */
	PUBLISHED_POST_TAB_ACTIVE(By.xpath(
			"//div[contains(@class,'chartTabs ea-tabs')]//li[contains(@class,'active')]//span[text()='Published Posts']"),
			"Published posts tab Active"),
	
	/** The line chart. */
	LINE_CHART(By.xpath("//div[@class='areachart']//div[@class='highcharts-container ']//*[@class='highcharts-root']"), "Line chart"),

	/** The facebook icon. */
	// div[@id='highcharts-9c9f7s4-168']/div[@class='highcharts-legend']/div/div/div[contains(@class,'highcharts-legend-item')]/span/div[@class='legend-img
	// ']/img[contains(@src,'fb.svg')]
	FACEBOOK_ICON(By.xpath("//div[@class='legend-img ']/img[contains(@src,'fb.svg')]"), "Facebook chart"),

	/** The twitter. */
	// div[@id='highcharts-9c9f7s4-168']/div[@class='highcharts-legend']/div/div/div[contains(@class,'highcharts-legend-item')]/span/div[@class='legend-img
	// ']/img[contains(@src,'twitter.svg')]
	TWITTER(By.xpath("//div[@class='legend-img ']/img[contains(@src,'twitter.svg')]"), "Twitter chart"),

	/** The instagram icon. */
	//// div[@id='highcharts-9c9f7s4-168']/div[@class='highcharts-legend']/div/div/div[contains(@class,'highcharts-legend-item')]/span/div[@class='legend-img
	//// ']/img[contains(@src,'insta.svg')]
	INSTAGRAM_ICON(By.xpath("//div[contains(@class,'legend-img')]/img[contains(@src,'insta.svg')]"), "Instagram icon"),

	/** The linked in. */
	// div[@id='highcharts-9c9f7s4-168']/div[@class='highcharts-legend']/div/div/div[contains(@class,'highcharts-legend-item')]/span/div[@class='legend-img
	// ']/img[contains(@src,'linkedin.svg')]
	LINKED_IN(By.xpath("//div[@class='legend-img ']/img[contains(@src,'linkedin.svg')]"), "LinkedIn icon"),

	DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]","Date Picker"),

	/** The recent post. */
	RECENT_POST(By.xpath("//div[@class='lvt-details']/h3[contains(text(),'Recent')]//parent::div//span[text()='Posts']"), "Recent Post"),

	/** The recent post list. */
	RECENT_POST_LIST(By.xpath("//div[@class='liv-right list-item']"), "Recent Post List"),
	
	/** The firstpost username. */
	RECENTPOST_USERNAME(By.xpath("//div[@class='liv-right list-item']//div[@class='li-top']//div[@class='lvt-details']//h3"), "Recent Post List"),

	/** The footer. */
	FOOTER(By.xpath("//div[@class='li-view-main'][last()]"), "Post List Footer."),

	/** The previous month. */
	PREVIOUS_MONTH(By.xpath("//button[contains(@class,'navigation--previous')]"), "Previous month."),

	/** The next month. */
	NEXT_MONTH(By.xpath("//button[contains(@class,'navigation--next')]"), "Next month."),

	/** The clear filter button. */
	CLEAR_FILTER_BUTTON_DISABLED(By.xpath("//div[@class='filter-item clear-filter']//div[contains(@class,'pointer-events-none')]//button//span[text()='Clear Filter']//parent::button"), "Clear Filter Button disable"),
	
	/** The clear filter button active. */
	CLEAR_FILTER_BUTTON_ACTIVE(By.xpath("//div[@class='filter-item clear-filter']//div[not(contains(@class,'pointer-events-none'))]//button//span[text()='Clear Filter']//parent::button"), "Clear Filter Button Active"),


	/** The from date. */
	FROM_DATE(By.xpath("//div[contains(@class,'dp-from')]//input"), "From date"),

	/** The from date field. */
	FROM_DATE_FIELD(By.xpath("//section[contains(@class,'filter')]//div[@class='dp-item dp-from active']"), "From date Field."),

	/** The to date. */
	TO_DATE(By.xpath("//div[contains(@class,'dp-to')]//input"), "To date"),

	/** The to date field. */
	TO_DATE_FIELD(By.xpath("//div[@class='dp-item dp-to active']/div/div/input"), "To date"),

	/** The month dropdown. */
	MONTH_DROPDOWN(By.xpath("//select[@class='react-datepicker__month-select']"), "Month drop down"),

	/** The year dropdown. */
	YEAR_DROPDOWN(By.xpath("//select[@class='react-datepicker__year-select']"), "Year drop down."),

	/** The calendar. */
	CALENDAR(By.xpath("//div[@class='react-datepicker__month-container']"), "Calendar"),

	/** The admin radio button. */
	ADMIN_RADIO_BUTTON(By.xpath("//input[@value='admin' and @class='option-input radio']"), "Admin Radio Button."),

	/** The login type admin. */
	LOGIN_TYPE_ADMIN(By.xpath("//input[@value='admin']//following-sibling::span[contains(text(),'Admin')]"), "LoginType Admin"),

	/** The enter email. */
	ENTER_EMAIL(By.xpath("//div[@class='addnewuser-modal-content']/div/input[@name='email']"), "Enter email id"),

	/** The continue button. */
	CONTINUE_BUTTON(By.xpath("//button[@class='ac-btn ac-primary ac-block ' and text()='Continue']"), "continue button."),

	/** The enter mobile number. */
	ENTER_MOBILE_NUMBER(By.xpath("//input[@name='mobile_phone']"), "Enter Mobile number"),
	/** The enter firstname. */
	ENTER_FIRSTNAME(By.xpath("//input[@name='first_name']"), "First Name"),
	/** The enter lastname. */
	ENTER_LASTNAME(By.xpath("//input[@name='last_name']"), "Last Name"),
	/** The confirm button. */
	CONFIRM_BUTTON(By.xpath("//button[@class='ac-btn ac-primary ac-block ' and text()='Confirm']"), "confirm button"),
	
	USER_CREATED_POPUP(By.xpath("//span[@class='success-mess-txt' and text()='Done!']"), "USER_CREATED_POPUP"),
	
	USER_REMOVED_POPUP(By.xpath("//span[@class='success-mess-txt' and text()='Removed!']"), "USER_REMOVED_POPUP"),

	/** The add new. */
	ADD_NEW(By.xpath("//button[@class='ac-btn ac-primary add-new' and contains(text(),'Add New')]"), "Add New button"),

	/** The profile icon. */
	PROFILE_ICON(By.xpath("//button[@id='dropitems-profile-items']"), "Profile icon"),

	/** The profile icon dropdown. */
	PROFILE_ICON_DROPDOWN(By.xpath("//button[@id='dropitems-profile-items']//following-sibling::div[@class='dropdown-menu show']"), "Profile icon dropdown"),

	/** The dropdown logout. */
	DROPDOWN_LOGOUT(By.xpath("//div[@class='dropdown-menu show']//a[text()='Logout']"), "Dropdown logOut"),

	/** The post publisher. */
	POST_PUBLISHER(By.xpath("//div[@class='dropdown-menu show']//a[text()='Logout']"), "Post Publisher's name"),

	/** The bean me up. */
	BEAN_ME_UP(By.xpath("//div[@class='ds-dropdown']/button/span[1]"), "Location Bar"),

	/** The brand hub location name. */
	BRAND_HUB_LOCATION_NAME(By.xpath("//div[@class='brand-profile h-assorted']//div[@class='ds-dropdown']//button//span[1]"), "Brand Hub Location name"),

	/** Brand Hub Location dropdown. */
	BRAND_HUB_LOCATION_DROPDOWN(By.xpath("//div[@class='brand-profile h-assorted']//div[@class='ds-dropdown']//div[contains(@class,'ds-menu')]"), "Brand Hub Location dropdown"),

	/** Brand Hub Location dropdown search. */
	BRAND_HUB_LOCATION_DROPDOWN_SEARCH(By.xpath("//div[@class='ds-drp-indicator']//parent::div//preceding-sibling::div//input"), "Brand Hub Location dropdown search"),

	/** The select account from dropdown. */
	SELECT_ACCOUNT_FROM_DROPDOWN("//div[@class='brand-profile h-assorted']//div[@class='ds-dropdown']//div[@class='ds-menu']//div[contains(@id,'react-select') and text()='%s']",
	        "Select account from dropdown"),

	/** The listed locations of user. */
	LISTED_LOCATIONS_OF_USER(By.xpath("//div[@class='rs-drp__menu-list css-11unzgr']/div[contains(@class,'as-item location-icon-wraps rs-drp__option css-yt9ioa-option')]"),
	        "Brand Hub Location dropdown search"),

	/** The available locations. */
	AVAILABLE_FIRST_LOCATIONS(By.xpath("//div[@class='rs-drp__menu-list css-11unzgr']/div[contains(@class,'as-item location-icon-wraps rs-drp__option css-yt9ioa-option')][1]"),
	        "Brand Hub Location dropdown first location account."),

	/** The locations filter. */
	LOCATIONS_FILTER(By.xpath("//div[@class='ds-dropdown']//button"), "Locations filter"),

	/** The location dropdown. */
	LOCATION_DROPDOWN(By.xpath("//div[contains(@class,'rs-drp__menu-list')]"), "Location dropdown"),

	/** The current location. */
	CURRENT_LOCATION(By.xpath("//div[@class='ds-dropdown']//parent::div//button//span"), "Current location"),

	/** The location dropdown searchtab. */
	LOCATION_DROPDOWN_SEARCHTAB(By.xpath("//div[@id='account-switcher-dropdown']//div[contains(@class,'drp__value-container')]"), "Search tab of location selection"),

	/** The locations filter modal. */
	LOCATIONS_FILTER_MODAL(By.xpath("//div[@class='modal-content']//div[@class='modal-body']"), "Locations filter modal"),

	/** The location. */
	LOCATION_TAB(By.xpath("//div[@class='card']//button//div[contains(text(),'Locations')]"), "Location Tab"),
	
	/** The locationslist. */
	LOCATIONSLIST(By.xpath("//ul[@class='hub-list']//label"), "Location List"),

	/** The cancel button. */
	CANCEL_BUTTON(By.xpath("//div[contains(@class,'modal-footer')]//button[text()='Cancel']"), "Cancel button"),

	/** The ok button. */
	OK_BUTTON(By.xpath("//div[contains(@class,'modal-footer')]//button[text()='Ok']"), "Ok button"),

	/** The tool tip. */
	TOOL_TIP(By.xpath("//div[contains(@class,'chart-tooltip-wrp')]//span[@data-z-index]"), "Tool tip"),

	/** The tool tip date. */
	TOOL_TIP_DATE(By.xpath("//div[contains(@class,'chart-tooltip-wrp')]//span[@data-z-index]//span[contains(@class,'ra-tooltip-date')]"), "Tool tip date"),

	/** The location selector. */
	LOCATION_SELECTOR(By.xpath("//section//*[text()='Location Selector']//parent::div//span[@class='lcs-name']"), "Location Selecter."),

	/** The location selector open. */
	LOCATION_SELECTOR_OPEN(By.xpath(
			"//div[@class='asm-btn']//parent::div[@class='modal-footer']//preceding-sibling::div[@class='asm-accord']"),
			"Location Selecter Open."),
	
	/** The location selector dropdown user. */
	LOCATION_SELECTOR_DROPDOWN_USER("//div//ul[@class='hub-list']//span[contains(text(),'%s')]",
			"Location Selecter Dropdown User"),

	/** The location selector location tab. */
	LOCATION_SELECTOR_LOCATION_TAB(By.xpath("//div[@class='card']//div//span[text()='Locations']"),
			"Location Selecter Location tab."),
	
	/** The location selector location tab open. */
	LOCATION_SELECTOR_LOCATIONS_LIST(
			By.xpath("//div[contains(@class,'collapse show')]//img[contains(@src,'location') and not(contains(@src,'Lists'))]"),
			"Location Selecter Location list Tab Open"),
	
	/** The location selector locationlist tab. */
	LOCATION_SELECTOR_LOCATIONLIST_TAB(By.xpath("//div[@class='accordion']//div//button//div[text()='Locations']"),
			"Location Selecter Location tab."),
	
	/** The location selector ok button. */
	LOCATION_SELECTOR_OK_BUTTON(By.xpath("//div[@class='asm-btn']//div//button[text()='Ok']"),
			"Location Selecter Ok Button"),

	/** The location selector search tab. */
	LOCATION_SELECTOR_SEARCH_TAB(By.xpath("//div[@class='asm-lf']//input[@placeholder = 'Search']"),
			"Location Selecter Search Tab"),
	
	/** The list of locations. */
	LIST_OF_LOCATIONS(By.xpath(
			"//div[contains(@class,'collapse show')]//img[contains(@src,'location') and not(contains(@src,'Lists'))]"),
			"List of Locations"),


	/** The location selector cancel button. */
	LOCATION_SELECTOR_CANCEL_BUTTON(By.xpath("//div[@class='asm-btn']//div//button[text()='Cancel']"),
			"Location Selector Cancel Button"),

	/** The location selector close button. */
	LOCATION_SELECTOR_CLOSE_BUTTON(By.xpath("//img[@class='close-icon']"), "Location Selector Close Button"),

	Y_AXIS_CHART_GRID(By.xpath("//div[@class='g-centre']//div[@class='rlgb-right']//*[local-name()='path' and @class='highcharts-grid-line']"),"Y Axis Chart Grid"),

	FACEBOOK_Y_AXIS_COUNT(By.xpath("//span[text()='Facebook']//parent::div//following-sibling::div//span[@class='single-value']"),"Facebook Y axis Count"),

	INSTAGRAM_Y_AXIS_COUNT(By.xpath("//span[text()='Instagram']//parent::div//following-sibling::div//span[@class='single-value']"),"Instagram Y axis Count"),

	LINKEDIN_Y_AXIS_COUNT(By.xpath("//span[text()='LinkedIn']//parent::div//following-sibling::div//span[@class='single-value']"),"LinkedIn Y axis Count"),

	POST_LIST_BY_NAME("//div[@class='liv-right list-item']//div[@class='li-base']//p[contains(text(),'%s')]","Post List By Name"),

	/** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new employee advocacy leaderboard page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private EmployeeAdvocacyOverviewPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new employee advocacy leaderboard page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private EmployeeAdvocacyOverviewPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

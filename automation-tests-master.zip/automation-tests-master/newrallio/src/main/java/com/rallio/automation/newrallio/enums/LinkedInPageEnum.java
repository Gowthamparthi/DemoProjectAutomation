package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum LinkedInPageEnum.
 */
public enum LinkedInPageEnum {
	
	
	/** The page load. */
	PAGE_LOAD(By.xpath("//icon[contains(@class,'nav-logo')]"),"Page load"),
	
	/** The front page signin. */
	FRONT_PAGE_SIGNIN(By.xpath("//div[@class='nav__cta-container']//a[text()='Sign in']"),"front page sign in"),
	
	/** The email input. */
	EMAIL_ID(By.xpath("//div[contains(@class,'form__input')]//input[@id='username']"),"Email id"),
	
	/** The password. */
	PASSWORD(By.xpath("//div[contains(@class,'form__input')]//input[@id='password']"),"Password"),
	
	/** The signin button. */
	SIGNIN_BUTTON(By.xpath("//div[contains(@class,'login__form_action_container ')]//button[text()='Sign in']"),"Signin button");
	
	
	
	
	/** The by locator. */
	private By byLocator;

	/** The xpath. */
	private String xpath;

	/** The description. */
	private String description;
	
	
	/**
	 * Instantiates a new linked in page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private LinkedInPageEnum(By byLocator, String description) {
		
		this.byLocator = byLocator;
		this.description = description;
	}
	
	
	/**
	 * Instantiates a new linked in page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private LinkedInPageEnum(String xpath, String description) {
		
		this.xpath = xpath;
		this.description = description;
	}
	
	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return byLocator;
	}

	/**
	 * Gets the by xpath.
	 *
	 * @return the by xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}
}

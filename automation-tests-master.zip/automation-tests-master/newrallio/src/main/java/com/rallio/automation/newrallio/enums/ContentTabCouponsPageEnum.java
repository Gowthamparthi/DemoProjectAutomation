package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum ContentTabCouponsPageEnum.
 */
public enum ContentTabCouponsPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath(
			"//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Coupons']//ancestor::div//section[@class='item-g filter coupon-filter ']//preceding::div//section[@id='main-container-sec']//div[contains(@class,'content__coupons--wrp mbl-head--margin')]"),
			"Page load"),

	/** The coupons list. */
	COUPONS_LIST(By.xpath("//div[contains(@class,'coupon-card')]"), "Coupons list"),

	COUPON_BY_NAME("//div[@class='coupon-details']//h5//a[contains(text(),'%s')]//ancestor::div[@class='coupon-content ']","Coupon By Name"),

	/** The active coupons list. */
	ACTIVE_COUPONS_LIST(By.xpath(
			"//div[contains(@class,'coupon-card')]//div[contains(@class,'coupon-status')]//span[contains(text(),'ACTIVE')]"),
			"Active coupons list"),

	/** The inactive coupons list. */
	INACTIVE_COUPONS_LIST(By.xpath(
			"//div[contains(@class,'coupon-card')]//div[contains(@class,'coupon-status')]//span[contains(text(),'INACTIVE')]"),
			"Inactive coupons list"),

	/** The coupon detail view. */
	COUPON_DETAIL_VIEW(
			By.xpath("//h5[contains(text(),'Coupon Name')]//ancestor::section[contains(@class,'container-g')]"),
			"Coupon detail view"),

	/** The coupon name. */
	COUPON_NAME(By.xpath("//h5[contains(text(),'Coupon Name')]"), "Coupon name"),

	/** The coupon image. */
	COUPON_IMAGE(By.xpath("//div[contains(@class,'coupon-content')]//div[contains(@class,'alert-avatar')]//img"),
			"Coupon image"),

	/** The coupon content. */
	COUPON_CONTENT(By.xpath("//div[contains(@class,'coupon-details')]//h5//a"), "Coupon Name"),

	/** The coupon status copy content. */
	COUPON_STATUS_COPY_CONTENT(By.xpath("//div[contains(@class,'coupon-details')]//p"), "Coupon Status Copy Content"),

	/** The all coupons button. */
	ALL_COUPONS_BUTTON(By.xpath("//div[contains(@class,'coupon-details')]//h5//span"), "All Coupons Button"),

	/** The no data found. */
	NO_DATA_FOUND(By.xpath("//tr[@class='ndt-wrap']//td[text()='No Data Found.']"), "No Data Found"),

	/** The coupon id. */
	COUPON_ID(By.xpath("//div[contains(@class,'coupon-details')]//h5//span"), "Coupon ID"),

	/** The coupon link. */
	COUPON_LINK(By.xpath("//div[contains(@class,'coupon-details')]//span[contains(text(),'http')]"), "Coupon link"),

	/** The coupon prev button. */
	COUPON_PREV_BUTTON(By.xpath("//div[contains(@class,'coupon-prev')]//span[contains(text(),'Previous')]"),
			"Coupon previous button"),

	/** The coupon next button. */
	COUPON_NEXT_BUTTON(By.xpath("//div[contains(@class,'coupon-next')]//span[contains(text(),'Next')]"),
			"Coupon next button"),

	/** The coupon status. */
	COUPON_STATUS(By.xpath("//span[text()='Status']//parent::div//div//span"), "Coupon status"),

	/** The coupon start date. */
	COUPON_START_DATE(By.xpath("//span[text()='Start Date']//following-sibling::span"), "Coupon start date"),

	/** The coupon expires on. */
	COUPON_EXPIRES_ON(By.xpath("//span[text()='Expires on']//following-sibling::span"), "Coupo expires on"),

	/** The coupon view. */
	COUPON_VIEW(By.xpath("//span[text()='View']//following-sibling::span"), "Coupon view"),

	/** The coupon quantity. */
	COUPON_QUANTITY(By.xpath("(//div//div[contains(@class,'coupon-info')]//div//span[contains(text(),'Quantity')]//following::span)[1]"), "Coupon quantity"),

	/** The detailed view coupon quantity. */
	DETAILED_VIEW_COUPON_QUANTITY(By.xpath(
			"//div[@class='card-bg expand-details']//div//div[@class='coupon-info-r-col']//div[5]//span[1][text()='Quantity']//following::span[@class='cinfo-value']"),
			"Detailed View Coupon quantity"),

	/** The coupon offercopy. */
	COUPON_OFFERCOPY(By.xpath("//span[text()='Offer Copy']//parent::div//input"), "Coupon offer Copy"),

	/** The coupon desclaimercopy. */
	COUPON_DESCLAIMERCOPY(By.xpath("//span[text()='Disclaimer Copy']//parent::div//input"), "Coupon desclaimer copy"),

	/** The my devices. */
	MY_DEVICES(By.xpath("//div[@class='ac-upload-link']//input"), "Coupon My Devices button"),

	/** The choose image from library. */
	CHOOSE_IMAGE_FROM_LIBRARY(By.xpath("//div[@class='upload']//parent::a//span[text()='My Devices']"),
			"Choose Image from Library"),

	/** The image library searchtab. */
	IMAGE_LIBRARY_SEARCHTAB(By.xpath("//div[contains(@class,'search-input')]//input"), "Image library Search Tab"),

	/** The image library first item. */
	IMAGE_LIBRARY_FIRST_ITEM(By.xpath("//div[@class='masonry-grid']//div[1]//div[@class='m-item']"),
			"Image library First item"),

	/** The image library add button. */
	IMAGE_LIBRARY_ADD_BUTTON(By.xpath("//button[text()='Add']"), "Image library Add button"),

	/** The image library first item name. */
	IMAGE_LIBRARY_FIRST_ITEM_NAME(By.xpath("(//div[@class='masonry-grid']//div[1]//div//span)[1]"),
			"Image library First item Name"),

	/** The coupon fromdate. */
	COUPON_FROMDATE(By.xpath("//div[@class='ac-form-row']//div[@class='form-group deatefilter-sec-wrp'][1]//input"),
			"Coupon fromDate"),

	/** The coupon enddate. */
	COUPON_ENDDATE(By.xpath("//div[@class='ac-form-row']//div[@class='form-group deatefilter-sec-wrp'][2]//input"),
			"Coupon toDate"),

	/** The coupon saved popup. */
	COUPON_SAVED_POPUP(By.xpath("//span[@class='success-mess-txt' and text()='Saved!']"), "Coupon Saved! Popup"),

	/** The coupon deleted popup. */
	COUPON_DELETED_POPUP(By.xpath("//span[@class='success-mess-txt' and text()='Deleted!']"), "Coupon Deleted! Popup"),

	/** The coupon calendar nextmonth picker. */
	COUPON_CALENDAR_NEXTMONTH_PICKER(By.xpath("//span[text()='Disclaimer Copy']//parent::div//input"),
			"Coupon Calendar next Month Picker"),

	/** The coupon close button. */
	COUPON_CLOSE_BUTTON(By.xpath("//div[contains(@class,'coupon-alert-close')]//img"), "Coupon close button"),

	/** The coupon delete. */
	COUPON_DELETE(By.xpath("//button[text()='Delete']"), "Coupon delete"),

	/** The coupon delete conformation modal delete button. */
	COUPON_DELETE_CONFORMATION_MODAL_DELETE_BUTTON(By.xpath("(//button[text()='Delete'])[2]"),
			"Coupon Conformation Delete button"),

	/** The coupon delete conformation modal cancel button. */
	COUPON_DELETE_CONFORMATION_MODAL_CANCEL_BUTTON(By.xpath("//button[text()='Cancel']"),
			"Coupon Conformation Cancel button"),

	/** The coupon delete conformation modal. */
	COUPON_DELETE_CONFORMATION_MODAL(By.xpath(
			"//button[text()='Delete']//preceding-sibling::button[text()='Cancel']//ancestor::div[@class='modal-footer']//preceding-sibling::div[@class='modal-body']//div[text()='Are you sure?']//parent::div//parent::div[@class='modal-body']"),
			"Coupon Delete Conformation modal"),

	/** The coupon edit. */
	COUPON_EDIT(By.xpath("//button[text()='Edit Coupon']"), "Coupon edit"),

	/** The coupon details. */
	COUPON_DETAILS(By.xpath("//button[text()='Coupon Details']"), "Coupon details"),

	/** The download coupon. */
	DOWNLOAD_COUPON(By.xpath("//button[text()='Download Coupon Codes']"), "Download coupon"),

	/** The new coupon button. */
	NEW_COUPON_BUTTON(By.xpath("//button[contains(text(),'New Coupon')]"), "New coupon button"),

	/** The all filter. */
	ALL_FILTER(By.xpath("//span[contains(text(),'All')]"), "All filter"),

	/** The all filter selected. */
	ALL_FILTER_SELECTED(By.xpath("//span[contains(text(),'All')]//parent::label[contains(@class,'active')]"),
			"All filter selected"),

	/** The active filter. */
	ACTIVE_FILTER(By.xpath("//div[contains(@class,'coupons-fillter')]//span[contains(text(),'Active')]"), "Active filter"),

	/** The active filter selected. */
	ACTIVE_FILTER_SELECTED(By.xpath("//span[contains(text(),'Active')]//parent::label[contains(@class,'active')]"),
			"Active filter selected"),

	/** The inactive filter. */
	INACTIVE_FILTER(By.xpath("//div[contains(@class,'coupons-fillter')]//span[contains(text(),'Inactive')]"), "Inactive filter"),

	/** The inactive filter selected. */
	INACTIVE_FILTER_SELECTED(By.xpath("//span[contains(text(),'Inactive')]//parent::label[contains(@class,'active')]"),
			"Inactive filter selected"),

	/** The new coupon modal. */
	NEW_COUPON_MODAL(By.xpath("//h5[text()='New Coupon']//ancestor::div[contains(@class,'modal-body')]"),
			"New coupon modal"),

	/** The modal coupon name input. */
	MODAL_COUPON_NAME_INPUT(By.xpath("//span[text()='Coupon Name']//preceding-sibling::input[@name='couponName']"),
			"Modal coupon name input"),

	/** The modal quality of coupons input. */
	MODAL_QUALITY_OF_COUPONS_INPUT(
			By.xpath("//span[text()='Quantity of Coupons']//preceding-sibling::input[@name='quantityOfCoupons']"),
			"Quality of coupon"),

	/** The modal start date. */
	MODAL_START_DATE(By.xpath("//span[text()='Start Date']//parent::div//input"), "Modal start date"),

	/** The modal expiration date. */
	MODAL_EXPIRATION_DATE(By.xpath("//span[text()='Expiration Date']//parent::div//input"), "Modal expiration date"),

	/** The modal upload image. */
	MODAL_UPLOAD_IMAGE(By.xpath("//div[@class='ac-upload-link']"), "modal uploaded image"),
	
	MODAL_UPLOAD_IMAGE_DRAG_AND_DROP(By.xpath("//div[contains(@class,'coupons-modal')]//div[@class='ac-upload-image']"), "modal uploaded image drag and drop"),
	
	MODEL_UPLOADED_IMAGE(By.xpath("//div[@class='m-item']//div[@class='m-ast-itm m-ast-img']"), "model uploaded image"),

	/** The modal form copy input. */
	MODAL_FORM_COPY_INPUT(By.xpath("//span[text()='Offer Copy']//preceding-sibling::input"), "Modal form copy input"),

	/** The modal disclaimer copy input. */
	MODAL_DISCLAIMER_COPY_INPUT(By.xpath("//span[text()='Disclaimer Copy']//preceding-sibling::input"),
			"Modal disclaimer copy input"),

	/** The modal close button. */
	MODAL_CLOSE_BUTTON(By.xpath("//div[contains(@class,'close')]//img"), "Modal close button"),

	/** The modal go back button. */
	MODAL_GO_BACK_BUTTON(By.xpath("//span[text()='Go Back']"), "Modal go back button"),

	/** The listview active coupon active text. */
	LISTVIEW_ACTIVE_COUPON_ACTIVE_TEXT(
			By.xpath("//div[@class='card-bg coupon-card ']//div//div[@class='coupon-status coupon-active']//span[text()='ACTIVE']"),
			"List view Active coupon Active text"),

	/** The listview active coupon image. */
	LISTVIEW_ACTIVE_COUPON_IMAGE(
			By.xpath("//div[@class='card-bg coupon-card '][1]//div[@class='coupon-content ']//img"),
			"List view Active coupon image"),

	/** The listview active coupon name. */
	LISTVIEW_ACTIVE_COUPON_NAME(
			By.xpath("//div[@class='card-bg coupon-card '][1]//div[@class='coupon-details']//h5//a"),
			"List view Active coupon name"),

	/** The listview active coupon id. */
	LISTVIEW_ACTIVE_COUPON_ID(
			By.xpath("//div[@class='card-bg coupon-card '][1]//div[@class='coupon-details']//h5//span"),
			"List view Active coupon ID"),

	/** The listview active coupon id by name. */
	LISTVIEW_ACTIVE_COUPON_ID_BY_NAME(
			"//div[@class='card-bg coupon-card '][1]//div[@class='coupon-details']//h5//a[text()='%s']//following-sibling::span",
			"List view Active coupon ID"),

	/** The listview active coupon link. */
	LISTVIEW_ACTIVE_COUPON_LINK(
			By.xpath("(//div[@class='card-bg coupon-card '][1]//div[@class='coupon-details']//span)[2]"),
			"List view Active coupon Link"),

	/** The listview active coupon description. */
	LISTVIEW_ACTIVE_COUPON_DESCRIPTION(
			By.xpath("//div[@class='card-bg coupon-card '][1]//div[@class='coupon-details']//p"),
			"List view Active coupon description"),

	/** The listview active coupon claimed with value. */
	LISTVIEW_ACTIVE_COUPON_CLAIMED_WITH_VALUE(
			By.xpath("//div[@class='card-bg coupon-card '][1]//div//div[@class='sh-date-holder']//div//span"),
			"List view Active coupon claimed with value"),

	/** The listview active coupon valid from date. */
	LISTVIEW_ACTIVE_COUPON_VALID_FROM_DATE(By.xpath(
			"(//div[@class='card-bg coupon-card '][1]//div[@class='coupan-card-right']//h5[text()='Valid Through']//parent::div//div[@class='valid thru']//following-sibling::div//h5//span)[1]"),
			"List view In-Active coupon from date"),

	/** The listview active coupon valid to date. */
	LISTVIEW_ACTIVE_COUPON_VALID_TO_DATE(By.xpath(
			"(//div[@class='card-bg coupon-card '][1]//div[@class='coupan-card-right']//h5[text()='Valid Through']//parent::div//div[@class='valid thru']//following-sibling::div//h5//span)[2]"),
			"List view In-Active coupon To date"),

	/** The listview inactive coupon text. */
	LISTVIEW_INACTIVE_COUPON_TEXT(By.xpath(
			"//div[@class='coupon-status coupon-inactive']//span[text()=' INACTIVE']"),
			"List view In-Active coupon text"),

	/** The listview inactive coupon image. */
	LISTVIEW_INACTIVE_COUPON_IMAGE(By.xpath(
			"//div[@class='coupan-card-left']//div[@class='coupon-status coupon-inactive']//span[text()=' INACTIVE']//parent::div//parent::div//div[@class='coupon-content ']//img"),
			"List view In-Active coupon image"),

	/** The listview inactive coupon name. */
	LISTVIEW_INACTIVE_COUPON_NAME(
			By.xpath("//div[@class='coupon-status coupon-inactive']//span[text()=' INACTIVE']//parent::div//following-sibling::div//h5//a"),
			"List view In-Active coupon name"),

	/** The listview inactive coupon id. */
	LISTVIEW_INACTIVE_COUPON_ID(
			By.xpath(
					"//div[@class='coupon-status coupon-inactive']//span[text()=' INACTIVE']//parent::div//following-sibling::div//h5//span"),
			"List view In-Active coupon ID"),

	/** The listview inactive coupon link. */
	LISTVIEW_INACTIVE_COUPON_LINK(By
			.xpath("(//div[@class='coupon-status coupon-inactive']//span[text()=' INACTIVE']//parent::div//following-sibling::div//span)[2]"),
			"List view In-Active coupon Link"),

	/** The listview inactive coupon description. */
	LISTVIEW_INACTIVE_COUPON_DESCRIPTION(
			By.xpath("//div[@class='coupon-status coupon-inactive']//span[text()=' INACTIVE']//parent::div//following-sibling::div//p"),
			"List view In-Active coupon description"),

	/** The listview inactive coupon claimed with value. */
	LISTVIEW_INACTIVE_COUPON_CLAIMED_WITH_VALUE(By.xpath(
			"//div[@class='coupon-status coupon-inactive']//span[text()=' INACTIVE']//parent::div//parent::div//following-sibling::div//span[text()='Claimed']//parent::div//span[@class='sh-date']"),
			"List view In-Active coupon claimed with value"),

	/** The listview inactive coupon valid from date. */
	LISTVIEW_INACTIVE_COUPON_VALID_FROM_DATE(By.xpath(
			"//div[@class='coupon-status coupon-inactive']//span[text()=' INACTIVE']//parent::div//parent::div//following-sibling::div[@class='coupan-card-right']//div[@class='valid-dates']//h5[1]"),
			"List view Active coupon from date"),

	/** The listview inactive coupon valid to date. */
	LISTVIEW_INACTIVE_COUPON_VALID_TO_DATE(By.xpath(
			"//div[@class='coupon-status coupon-inactive']//span[text()=' INACTIVE']//parent::div//parent::div//following-sibling::div[@class='coupan-card-right']//div[@class='valid-dates']//h5[2]"),
			"List view Active coupon To date"),

	/** The modal save button. */
	MODAL_SAVE_BUTTON(By.xpath("//button//span[text()='Save']"), "Modal save button"),

	/** The coupon month dropdown. */
	COUPON_MONTH_DROPDOWN(By.xpath("//select[@class='react-datepicker__month-select']"), "Month drop down"),

	/** The year dropdown. */
	COUPON_YEAR_DROPDOWN(By.xpath("//select[@class='react-datepicker__year-select']"), "Year drop down."),

	/** The coupon details table. */
	// Coupon details checking
	COUPON_DETAILS_TABLE(By.xpath(
			"//th[text()='Location']//following::th[text()='Spend']//following::th[text()='Views']//following::th[text()='Claimed']//following::th['Redeemed']//following::th[text()='Revenue']//following::th[text()='ROI']//parent::tr//ancestor::div[@class='coupon-table']"),
			"Coupon details Table"),

	/** The table total locations. */
	TABLE_TOTAL_LOCATIONS(
			By.xpath("//div[@class='loc-total-holder']//strong[text()='Totals']//following::div[@class='loc-totals']"),
			"Coupon details Table"),

	/** The table date range. */
	TABLE_DATE_RANGE(By.xpath("//span[@class='loc-total-timestamp']"), "Coupon details Table date Range"),

	/** The table spend value. */
	TABLE_SPEND_VALUE(By.xpath("//div[@class='coupon-table']//tr[1]//td//div[text()='Spend']"),
			"Coupon details Table date Range"),

	/** The table views value. */
	TABLE_VIEWS_VALUE(By.xpath("//div[@class='coupon-table']//tr[1]//td//div[text()='Views']"),
			"Coupon details Table views value"),

	/** The table claimed value. */
	TABLE_CLAIMED_VALUE(By.xpath("//div[@class='coupon-table']//tr[1]//td//div[text()='Claimed']"),
			"Coupon details Table claimed Value"),

	/** The table redeemed value. */
	TABLE_REDEEMED_VALUE(By.xpath("//div[@class='coupon-table']//tr[1]//td//div[text()='Redeemed']"),
			"Coupon details Table Redeemed value"),

	/** The table revenue. */
	TABLE_REVENUE(By.xpath("//div[@class='coupon-table']//tr[1]//td//div[text()='Revenue']"),
			"Coupon details Table Revenue"),

	/** The table roi. */
	TABLE_ROI(By.xpath("//div[@class='coupon-table']//tr[1]//td//div[text()='ROI']"), "Coupon details Table ROI Value"),

	FOOTER(By.xpath("//div[contains(@class,'card-bg coupon-card')][last()]"),"Footer"),
	
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),

	/** The calendar. */
	CALENDAR(By.xpath("//div[@class='react-datepicker__month-container']"), "Calendar");

	/** The by locator. */
	private By byLocator;

	/** The xpath. */
	private String xpath;

	/** The description. */
	private String description;

	/**
	 * Instantiates a new content tab coupons page enum.
	 *
	 * @param byLocator   the by locator
	 * @param description the description
	 */
	private ContentTabCouponsPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new content tab coupons page enum.
	 *
	 * @param xpath       the xpath
	 * @param description the description
	 */
	private ContentTabCouponsPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return byLocator;
	}

	/**
	 * Gets the by xpath.
	 *
	 * @return the by xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}
}

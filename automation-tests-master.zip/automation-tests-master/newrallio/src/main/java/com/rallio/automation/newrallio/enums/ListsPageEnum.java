package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum ListsPageEnum.
 */
public enum ListsPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath(
	        "//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Lists & Feeds']//ancestor::div//section[contains(@class,'item-g filter tmListFilterMain')]//preceding::div//section[@id='main-container-sec']//div[@class='content-g']//div[contains(@class,'resuseTable')]"),
	        "Page load"),

	/** The table lists. */
	TABLE_LISTS(By.xpath("//table//tbody//tr[@class=' cur-pointer']"), "Table lists"),

	/** The List name header. */
	NAME_HEADER(By.xpath("//th//div[text()='Name']"), "Name header"),

	AUTOMATED_CONTENT_SCHEDULER_HEADER(By.xpath("//th//div[text()='Automated Content Scheduler']"), "Automated Content Scheduler"),

	MAKE_PUBLIC_HEADER(By.xpath("//th//div[text()='Make Public']"),"Make Public Header"),

	ENROLLMENT_COUNT_HEADER(By.xpath("//table//th//div[text()='Enrollment Count']"),"Enrollment Count Header"),

	ENROLLMENT_COUNT_LIST("//table//th//div[text()='Enrollment Count']//ancestor::table//tbody//span[@class='lfsName' and text()='%s']//parent::div//parent::td//parent::tr//td[2]//div[text()='%s']","Enrollment List Count"),

	/** The create list button. */
	CREATE_LIST_BUTTON(By.xpath("//button//span[text()='Create A New List']"), "Create A New List button"),

	/** The create new list header. */
	CREATE_NEW_LIST_HEADER(By.xpath("//h2[text()='Create a New Lists']"), "Create new list header"),

	/** The definie list element header. */
	DEFINIE_LIST_ELEMENT_HEADER(By.xpath("//span[@class='nlf-count-id' and text()='1']//parent::span//following::span[text()='Define List Elements']"),"Definie List Element Header"),

	NAME_OF_THE_LIST_HEADER(By.xpath("//div[@class='bs-cnl dle-ff']//span[text()='Name of the List']"),"Name of the List Header"),

	NAME_OF_LIST_SEARCH_FIELD(By.xpath("//div[@class='bs-cnl dle-ff']//input[@name='name']"),"Name of List Search Field"),
	DEFINE_LIST_NEXT_BUTTON(By.xpath("//div[@class='right-button-section nlfActions']//button[text()='Next']"),"Define List Next Button"),

	DEFINE_HUBS_AND_LOCATION(By.xpath("//span[@class='nlf-count-id' and text()='2']//parent::span//following::span[text()='Define Hubs and Locations']"),"Define Hubs And Location Header"),

	CREAT_NEW_LIST_CLOSE_ICON(By.xpath("//div[@class='modal-content']//div[@class='mod__close--icon']"),"Creat New List Close Icon"),

	/** The my lists page. */
	MY_LISTS_PAGE(By.xpath("//div[@class='modal-body']//h2[text()='My Lists']"), "My Lists page"),

	/** The my lists page back button. */
	MY_LISTS_PAGE_BACK_BUTTON(By.xpath("//div[@class='back-nav']//img[@alt='Back']"), "MyLists page Back button"),

	/** The mylists download csv button. */
	MYLISTS_DOWNLOAD_CSV_BUTTON(By.xpath("//button//span[text()='Download CSV']"), "MyLists download CSV button"),

	/** The download csv message. */
	DOWNLOAD_CSV_MESSAGE(By.xpath("//span[@class='success-mess-txt' and text()='Download started']"), "Download CSV message"),

	/** The list name edit input. */
	LIST_NAME_EDIT_INPUT(By.xpath("//div[@class='bs-cnl dle-ff']//span[@class='fltlabels' and text()='Name of the List']//parent::div//input[@name='name']"), "ListName edit input"),

	/** The delete button. */
	DELETE_BUTTON(By.xpath("//tbody//tr[1]//td[4]//img[@alt='Delete']"), "Delete button"),

	/** The list view delete button. */
	LIST_VIEW_DELETE_BUTTON("//td[@title='%s']//parent::div//parent::td//parent::tr//td[4]//button//img", "ListView delete button"),

	WTH_LIST_DELETE_BUTTON(By.xpath("//div//parent::td//parent::tr//td[4]//button//img"),"WTHBrand List Delete Button"),

	WTH_LIST_VIEW_DELETE_BUTTON("//div[text()='%s']//parent::td//parent::tr//td[4]//button//img", "WTH ListView delete button"),

	/** The mylists delete button. */
	MYLISTS_DELETE_BUTTON(By.xpath("//button//span[text()='Delete this list']"), "MyLists delete button"),

	/** The delete alert box. */
	DELETE_ALERT_BOX(By.xpath(
	        "//div[@class='modal-body']//div[text()='Are you sure?']//parent::div//parent::div//following-sibling::div//button[text()='Cancel']//following-sibling::button[text()='Delete']"),
	        "Delete alert box"),

	/** The delete alert cancel button. */
	DELETE_ALERT_CANCEL_BUTTON(By.xpath("//div[@class='delete__btn--wrp']//button[text()='Cancel']"), "Delete alert cancel button"),

	/** The delete alert delete button. */
	DELETE_ALERT_DELETE_BUTTON(By.xpath("//div[@class='delete__btn--wrp']//button[text()='Delete']"), "Delete alert delete button"),

	/** The deleted alert. */
	DELETED_ALERT(By.xpath("//span[@class='success-mess-txt' and text()='Deleted!']"), "Deleted alert"),

	/** The save button. */
	SAVE_BUTTON(By.xpath("//button//span[text()='Save']"), "Save button"),

	/** The save button active. */
	SAVE_BUTTON_ACTIVE(By.xpath("//button[not(contains(@class,'disabled'))]//span[text()='Save']"), "Save button active"),

	/** The saved alert. */
	SAVED_ALERT(By.xpath("//span[@class='success-mess-txt' and text()='Saved!']"), "Saved alert"),

	/** The saved list. */
	SAVED_LIST("//tbody//td[contains(@title,'%s')]//parent::td//parent::tr", "Saved list"),

	/** The public feed in list type **/
	MAKE_PUBLIC_SWITCH_IN_LIST_TYPE("//th//div[text()='Make Public']//ancestor::table//tbody//tr//span[text()='%s']//parent::div//parent::td//following-sibling::td[2]//div[@class='form-switch']//input","The Public feed in list type"),

	ENROLL_SWITCH("//th//div[text()='Enroll']//ancestor::table//tbody//tr//span[text()='%s']//parent::div//parent::td//following-sibling::td//div[@class='form-switch']//input","ENROLL FEED PUBLIC SWITCH"),

	/** The available. */
	AVAILABLE(By.xpath("//h3[text()='Available']//span"), "Available"),

	/** The available section search. */
	AVAILABLE_SECTION_SEARCH(By.xpath("//h3[text()='Available']//following-sibling::div[@class='cas-tree tree-add']//input[@placeholder='Search']"), "Available section search"),

	/** The available no data to show. */
	AVAILABLE_NO_DATA_TO_SHOW(By.xpath("//div[contains(@class,'available-card')]//span[text()='No data to show']"), "Available no data to show"),

	/** The available locations. */
	AVAILABLE_LOCATIONS(By.xpath("//div[contains(@class,'available-card')]//ul"), "Available locations"),

	/** The selected. */
	SELECTED(By.xpath("//h3[text()='Selected']//span"), "Selected"),

	/** The selected section search. */
	SELECTED_SECTION_SEARCH(By.xpath("//h3[text()='Selected']//following-sibling::div[@class='cas-tree tree-add']//input[@placeholder='Search']"), "Selected section search"),

	/** The locations count on Selected. */
	LOCATIONS_COUNT_ON_SELECTED(By.xpath("//div[contains(@class,'create-as')]//h3[text()='Selected']//span"), "Locations count on Selected"),

	/** The selected locations. */
	SELECTED_LOCATIONS(By.xpath("//div[contains(@class,'selected-card')]//ul"), "Selected Locations"),

	/** The select available location. */
	SELECT_AVAILABLE_LOCATION("//span[contains(text(),'%s')]//parent::span//preceding-sibling::span[@class='rc-tree-checkbox']", "Select Available location"),

	/** The select available activelocation. */
	SELECT_AVAILABLE_ACTIVELOCATION("//span[contains(text(),'%s')]//parent::span//preceding-sibling::span[@class='rc-tree-checkbox rc-tree-checkbox-checked']","Select Active Location"),
	
	/** The selected available location. */
	SELECTED_AVAILABLE_LOCATION("//span[text()='%s']//parent::span//preceding-sibling::span[contains(@class,'rc-tree-checkbox rc-tree-checkbox')]", "Selected Available location"),

	/** The selected last available location. */
	SELECTED_LAST_AVAILABLE_LOCATION("//span[text()='%s']//parent::span//preceding-sibling::span[@class='rc-tree-checkbox rc-tree-checkbox-checked']","Selected Last Available Location"),
	
	/** The selected no data to show. */
	SELECTED_NO_DATA_TO_SHOW(By.xpath("//div[contains(@class,'selected-card')]//span[text()='No data to show']"), "Selected no data to show"),

	/** The locations in selected section. */
	LOCATIONS_IN_SELECTED_SECTION("//h3[text()='Selected']//following-sibling::div//span[@class='rc-tree-title' and contains(text(),'%s')]", "Locations in Selected section"),

	/** The selected location count. */
	SELECTED_LOCATION_COUNT(By.xpath("//h3[@class='glbl__title--txt' and text()='Selected']//span[text()]"),"Selected Location Count"),
	
	FOOTER(By.xpath("//table//tbody//tr[@class=' cur-pointer'][last()]"),"Footer"),

	/** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"), "Back to Top button"),
	SELECTED_LOCATION_SUB_LIST(By.xpath("//span[@class='rc-tree-node-content-wrapper rc-tree-node-content-wrapper-normal']//span[2][@class='rc-tree-title']"),"Selected Locations Sub List"),

	FEED_TAB(By.xpath("//div//ul//li//span[text()='Feed']"),"Feed Tab"),

	CREATE_LIST_DETAILVIEW_NAME_LIST(By.xpath("//input[@name='name']"),"Create Name List New"),

	CREATE_LIST_DETAILVIEW_NAME_OF_LIST(By.xpath("//span[text()='Name of the List']//parent::div//input[@name='name']"),"CREATE_LIST_DETAILVIEW_NAME_OF_LIST"),

	CREATE_LIST_DETAILVIEW_SELECT_TYPE_DROPDOWN(By.xpath("(//span[text()='Select Type']//parent::div//div[contains(@class,'glbl__dropdown__value-container')]//following-sibling::div)[2]"),"Selcet Type Dropdown"),

	CREATE_LIST_DETAILVIEW_SELECT_TYPE(By.xpath("//span[text()='Select Type']//parent::div//div[@class='glbl__dropdown__control css-s68f6i-control']//div[@class='glbl__dropdown__single-value css-qc6sy-singleValue' and text()]"),"Create List Detailview Select Type"),

	CREATE_LIST_DETAILVIEW_SELECT_CONTENT_SOURCE_DROPDOWN(By.xpath("//span[text()='Select Content Source(s)']//parent::div//div[contains(@class,'glbl__dropdown__value-container')]//following-sibling::div[contains(@class,'glbl__dropdown__indicators')]"),"Selcet Type Dropdown"),

	CREATE_LIST_DETAILVIEW_SELECTING_CONTENT_SOURCE_DROPDOWN("//div[contains(@class,'glbl__dropdown__menu')]//*[contains(text(),'%s')]","Selcet Type Dropdown"),

	CREATE_LIST_DETAILVIEW_SELECTED_SOURCE("//div[@class='glbl__dropdown__single-value css-qc6sy-singleValue' and text()='%s']","Create List Detailview Selected Source"),

	CREATE_LIST_DETAILVIEW_SELECT_TAGS(By.xpath("//span[text()='Select Tags to filter content (Optional)']//parent::div//div[@class='react-tags__search']//input"),"CREAT_LIST_DETAILVIEW_SELECT_TAGS"),

	CREATE_LIST_DETAILVIE_SELECTED_TAG("//span[@class='list-expanded-tag-text' and text()='%s']","Create List Detailview Selected Tag"),

	CREATE_LIST_DETAILVIEW_REMOVING_TAG(By.xpath("//div[@class='list-expanded-tag-item']//span[@class='list-expanded-tag-remove']"),"Create List Detailview Removing Tag"),

	CREATE_LIST_DEATILVIEW_SELECT_DROPDOWN_VIEW(By.xpath("//div[@class='glbl__dropdown__menu css-ik6y5r']"),"CREATE_LIST_DEATILVIEW_SELECT_DROPDOWN_VIEW"),

	CREATE_LIST_DETAILVIEW_SELCET_DROPDOWN("//div[@class='glbl__dropdown__menu css-ik6y5r']//*[text()='%s']","CREATE_LIST_DETAILVIEW_SELCET_STANDARD"),

	LIST_TYPE_PRIVATE_ACCOUNT_LIST_WITH_SWITCH("//tbody//td[@title='%s']//following-sibling::td//div[text()='Private Account List']//parent::td//following-sibling::td[2]//div[@class='form-switch']","List Type Private Account List"),

	LIST_TYPE_PUBLIC_ACCOUNT_LIST_WITH_SWITCH("//th//div[text()='Public Feed']//ancestor::table//tbody//td[@title='%s']//parent::tr//td[3]//div[@class='form-switch']//input[@id='custom-switch-make-public' and not(@checked)]","List Type Public Account Switch"),

	LIST_TYPE_PUBLIC_ACCOUNT_LIST_WITH_SWITCH_ACTIVE("//th//div[text()='Public Feed']//ancestor::table//tbody//td[@title='%s']//parent::tr//td[3]//div[@class='form-switch']//input[@id='custom-switch-make-public' and @checked]","List  Public Switch Active"),

	LIST_TYPE_ENROLL_SWITCH_ACTIVE("//th//div[text()='Enroll']//ancestor::table//tbody//td[@title='%s']//parent::tr//td[2]//div[@class='form-switch']//input[@id='custom-switch-make-public' and @checked]","List  Enroll Switch Active"),

	LIST_TYPE_ENROLL_SWITCH_INACTIVE("//th//div[text()='Enroll']//ancestor::table//tbody//td[@title='%s']//parent::tr//td[2]//div[@class='form-switch']//input[@id='custom-switch-make-public']","List  Enroll Switch InActive"),

	LIST_TYPE_CONTENT_SUPPLIER_LIST_WITH_SWITCH("//th//div[text()='Automated Content Scheduler']//ancestor::table//tbody//td[@title='%s']//parent::tr//td[2]//div[@class='form-switch']//input[@id='custom-switch-make-public' and not(@checked)]","List Type Content Supplier Account Switch"),

	LIST_TYPE_CONTENT_SUPPLIER_LIST_WITH_SWITCH_ACTIVE("//th//div[text()='Automated Content Scheduler']//ancestor::table//tbody//td[@title='%s']//parent::tr//td[2]//div[@class='form-switch']//input[@id='custom-switch-make-public' and @checked]","List  Content Supplier Switch Active"),

	LIST_TYPE_ALL_FILTER(By.xpath("//input[@name='feed_type-List Type']//parent::label//span[text()='All']"),"List Type All Filter"),

	LIST_TYPE_STANDARD_FILTER(By.xpath("//input[@name='feed_type-List Type']//parent::label//span[text()='Standard']"),"List Type Standard Filter"),

	LIST_TYPE_AUTOMATED_CONTENT_SCHEDULER_FILTER(By.xpath("//input[@name='feed_type-List Type']//parent::label//span[text()='Automated Content Scheduler']"),"List Type Standaed Filter"),

	AVAILABLE_POST_COUNT(By.xpath("//h3[text()='Available Posts']//parent::div//div[@class='apc-count']"),"Available Post Count"),

	FEED_SAVE_BUTTON(By.xpath("//button[@class='ac-btn ac-primary size-sm' and text()='Save']"),"Feed Save Button"),

	START_FRESH_CALENDAR_BUTTON(By.xpath("//span[text()='Start a fresh calendar']"),"Start Fresh Calendar"),

	SAVED_POPUP(By.xpath("//span[@class='success-mess-txt' and text()='Saved']"),"SAVED Popup"),


	/** The create list page back button. */
	CREATE_LIST_PAGE_BACK_BUTTON(By.xpath("//div[@class='back-nav']//img[@alt='Back']"), "CreateList page Back button");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new lists page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private ListsPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new lists page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private ListsPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

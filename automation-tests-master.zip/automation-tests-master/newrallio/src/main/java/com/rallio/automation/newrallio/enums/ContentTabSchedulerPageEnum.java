package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

public enum ContentTabSchedulerPageEnum {

    PAGE_LOAD(By.xpath("//li[@class='ripple active']//span[text()='Scheduler']//ancestor::div//div[@class='g-centre']//div[@class='cfs-main cfs-cs']//div[@class='view-fullcalendarnew-wrp-section']"),"Scheduler Page Load"),

    SCHEDULER_SELECT_DAY_COL("//table//div[@class='fc-timegrid-cols']//td[@data-date='%s']","Schedular Select Day With Time"),

    SCHEDULER_HIGHLIGHTED_DAY_WITH_TIME("//div[@class='creator-schedule-section-wrp blue-bg ']//div[@class='time-stamp' and text()='%s']","Scheduler Highlighted Day with Time"),

    SCHEDULER_WITH_HIGHLIGTED(By.xpath("//div[@class='creator-schedule-section-wrp blue-bg ']//div[@class='time-stamp']"),"SCHEDULER_WITH_HIGHLIGTED"),

    SCHEDULER_HIGHLIGHTED_DAY_WITH_LIST("//div[@class='creator-schedule-section-wrp blue-bg ']//p[@class='post-content cals-title' and contains(text(),'%s')]","SCHEDULER_HIGHLIGHTED_DAY_WITH_LIST"),

    SCHEDULER_HIGHLIGHTED_DAY_WITH_TIME_DISABLE("//div[@class='creator-schedule-section-wrp blue-bg disable-opacity']//div[text()='%s']","SCHEDULER_HIGHLIGHTED_DAY_WITH_Time_DISABLE"),

    SCHEDULER_START_DATE(By.xpath("//input[@name='start_date']"),"Scheduler Start Date"),

    SCHEDULER_END_DATE(By.xpath("//input[@name='end_date']"),"Scheduler End Date"),

    DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]","Date Picker"),

    YOU_CANNOT_MODIFY_POPUP(By.xpath("//span[text()='You cannot modify this schedule because it was created by a brand-level user.']"),"YOU_CANNOT_MODIFY_POPUP"),

    SCHEDULER_CONTENT_SOURCECHECK("//div[@class='sourceLcc']//*[text()='%s']","Scheduler Content Source Check Loctaion and Tag"),

    SCHEDULER_CREATED_SUCCESSFULLY(By.xpath("//span[text()='Schedule created successfully. Eligible posts will be scheduled shortly!']"),"SCHEDULER_CREATED_SUCCESSFULLY"),

    SCHEDULER_DELETED_SUCCESSFULLY(By.xpath("//span[text()='Scheduled slot deleted successfully!']"),"SCHEDULER_DELETED_SUCCESSFULLY"),

    SCHEDULER_UPDATED_SUCCESSFULLY(By.xpath("//span[text()='Schedule updated successfully. Eligible posts will be scheduled shortly!']"),"Scheduler Updated Successfully" ),

    SCHEDULER_DETAILVIEW_EIGHT_AM_AT_TOP(By.xpath("//tr[17]//td[@data-time='08:00:00' and @class='fc-timegrid-slot fc-timegrid-slot-lane']"),"Eight Am AT Top"),

    SCHEDULER_DETAILVIEW(By.xpath("//div[@class='wf-card glbl__modal--card card']//div[@class='wf-schedule']"),"SCHEDULER_DETAILVIEW"),

    NEW_CUSTOM_SCHEDULE_TEXT_TIME(By.xpath("//div[@class='static_label h5']//span[text()='Time']"),"NEW_CUSTOM_SCHEDULE_TEXT_TIME"),

    NEW_CUSTOM_SCHEDULE_TIME_INPUT_HOURS(By.xpath("//div[@class='crt-item crt-top btn-group-toggle btn-group']//input[@name='hours' and @value='slotHours']//following-sibling::label//input[@name='hour']"),"Time In Hours"),

    NEW_CUSTOM_SCHEDULE_TIME_INPUT_MINUTE(By.xpath("//div[@class='tgb-item']//input[@name='minutes' and @value='slotMinutes']//following-sibling::label//input[@name='minute']"),"Time Input In Minute"),

    NEW_CUSTOM_SCHEDULE_TIME_INPUT_AM(By.xpath("//div[@class='crt-item crt-base']//div[@class='switch6']//span[text()='AM']"),"NEW_CUSTOM_SCHEDULE_TIME_INPUT_AM"),

    NEW_CUSTOM_SCHEDULE_TIME_INPUT_PM(By.xpath("//div[@class='crt-item crt-base']//div[@class='switch6']//span[text()='PM']"),"NEW_CUSTOM_SCHEDULE_TIME_INPUT_PM"),

    NEW_CUSTOM_SCHEDULE_SOURCE_DROPDOWN_BUTTON(By.xpath("//span[text()='Source ' and text()='(Optional)']//ancestor::div[@class='selectSchedulerSC']//div[@id='boost-duration-dropdown']//parent::div//div[@class='glbl__dropdown__control css-s68f6i-control']//div[contains(@class,'glbl__dropdown__single-value css-qc6sy-singleValue')]"),"Loc Source Dropdown Button"),

    NEW_CUSTOM_SCHEDULE_BRAND_SOURCE_DROPDOWN_BUTTON(By.xpath("//span[text()='Source ']//ancestor::div[@class='selectSchedulerSC']//div[@id='boost-duration-dropdown']//parent::div//div[@class='glbl__dropdown__control css-s68f6i-control']//div[contains(@class,'glbl__dropdown__single-value css-qc6sy-singleValue')]"),"Source Dropdown Button"),

    NEW_CUSTOM_SCHEDULER_DETAILVIEW_SELECT_SOURCE("//div[@class='glbl__dropdown__menu css-ik6y5r']//*[text()='%s']","NEW_CUSTOM_SCHEDULER_DETAILVIEW_SELECT_SOURCE"),

    NEW_CUSTOM_SCHEDULER_DETAILVIEW_SELECTED_SOURCE("//div[@class='glbl__dropdown__single-value css-qc6sy-singleValue' and text()='%s']","Scheduler Detailview Selcted Source"),

    NEW_CUSTOM_SCHEDULER_CONTENT_SUPPLIER_SOURCE(By.xpath("//div[@class='glbl__dropdown__single-value css-qc6sy-singleValue' and text()='Content Supplier']"),"New Custom Scheduler Detailview Content Supplier Source"),

    NEW_CUSTOM_SCHEDULE_DURATION_ONCE(By.xpath("//span[text()='Duration']//ancestor::div[@class='when-fields duration-rb-btns']//div[@class='wf-right-options']//input[@class='option-input radio' and @value='once']"),"NEW_CUSTOM_SCHEDULE_DURATION_ONCE"),

    NEW_CUSTOM_SCHEDULE_DURATION_START_AND_END_DATE(By.xpath("//span[text()='Duration']//ancestor::div[@class='when-fields duration-rb-btns']//div[@class='wf-right-options']//input[@class='option-input radio' and @value='end_date']//following-sibling::span"),"NEW_CUSTOM_SCHEDULE_DURATION_END_DATE"),

    NEW_CUSTOM_SCHEDULE_DURATION_ONGOING(By.xpath("//span[text()='Duration']//ancestor::div[@class='when-fields duration-rb-btns']//div[@class='wf-right-options']//input[@class='option-input radio' and @value='ongoing']"),"NEW_CUSTOM_SCHEDULE_DURATION_ONGOING"),

    NEW_CUSTOM_SCHEDULE_CANCEL_BUTTON(By.xpath("//button[contains(@class,'ac-btn ac-secondary')]//span[text()='Cancel']"),"Cancel Button"),

    NEW_CUSTOM_SCHEDULER_ADD_BUTTON(By.xpath("//button[@type='submit']//span[text()='Add']"),"NEW_CUSTOM_SCHEDULER_ADD_BUTTON"),

    NEW_CUSTOM_SCHEDULER_UPDATE_BUTTON(By.xpath("//button[@type='submit']//span[text()='Update']"),"NEW_CUSTOM_SCHEDULER_UPDATE_BUTTON"),

    NEW_CUSTOM_SCHEDULER_DELETE_BUTTON(By.xpath("//button[@class='ac-btn ac-danger ac-outline size-xs']//span[text()='Delete']"),"NEW_CUSTOM_SCHEDULER_DELETE_BUTTON"),

    DELETE_DETAILVIEW_SELECT_REMOVE_ALL(By.xpath("//div[text()='Remove all currently scheduled posts associated with this list']"),"Delete Detailview Select Remove All"),

    DETAILVIEW_DELETE_BUTTON(By.xpath("//button[@class='ac-btn ac-danger ac-block' and text()='Delete']"),"Detailview Delete Button"),
    ;
    /** The by locator. */
    private By byLocator;

    /** The description. */
    private String xpath, description;

    /**
     * Instantiates a new content tab Scheduler page enum.
     *
     * @param byLocator the by locator
     * @param description the description
     */
    private ContentTabSchedulerPageEnum(By byLocator, String description) {

        this.byLocator = byLocator;
        this.description = description;
    }

    /**
     * Instantiates a new content tab Scheduler page enum.
     *
     * @param xpath the xpath
     * @param description the description
     */
    private ContentTabSchedulerPageEnum(String xpath, String description) {

        this.xpath = xpath;
        this.description = description;
    }

    /**
     * Gets the by locator.
     *
     * @return the by locator
     */
    public By getByLocator() {

        return this.byLocator;
    }

    /**
     * Gets the xpath.
     *
     * @return the xpath
     */
    public String getXpath() {

        return xpath;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {

        return this.description;
    }
}


package com.rallio.automation.newrallio.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum CreatePostType.
 */
public enum CreatePostType {

	/** The post now. */
	POST_NOW,

	/** The save to database. */
	SAVE_TO_DATABASE,

	/** The update saved post. */
	UPDATE_SAVED_POST,

	/** The scheduled post. */
	SCHEDULED_POST,
	
	/** The scheduled post now. */
	SCHEDULED_POST_NOW,

	/** The send for approval. */
	SEND_FOR_APPROVAL,

	/** The image post. */
	IMAGE_POST,

	/** The save as draft. */
	SAVE_AS_DRAFT,
	
	/** The syndicate. */
	SYNDICATE,

	/** The save as ready. */
	SAVE_AS_READY,

	/** The ai option. */
	AI_OPTION,

	/** The link post. */
	LINK_POST,

	/** The coupon post. */
	COUPON_POST,

	/** The video post. */
	VIDEO_POST;





}

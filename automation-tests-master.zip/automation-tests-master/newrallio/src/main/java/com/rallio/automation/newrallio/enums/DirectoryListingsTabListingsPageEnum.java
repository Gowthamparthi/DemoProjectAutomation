package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum DirectoryListingsTabListingsPageEnum.
 */
public enum DirectoryListingsTabListingsPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath(
			"//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Listings']//ancestor::div//section[contains(@class,'item-g filter ra-filter-sec anlFilter')]//preceding::div//section[@id='main-container-sec']//div[@class='content-g']"),
			"Page load"),

	/** The view my listing. */
	VIEW_MY_LISTING(By.xpath("//div[@class='dl-title-platform' and text()='View My Listing']"), "View my listing"),

	/** The loaded listings content. */
	LOADED_LISTINGS_CONTENT(By.xpath("//section[contains(@id,'main-container-sec')]//div[@class='white-box']"),
			"Loaded Listings Info"),

	/** The no of listings. */
	NO_OF_LISTINGS(By.xpath("//div[@class='white-box']//div//div[@class='flex-item-sm']"), "No Of Listings."),

	/** The all filter button. */
	ALL_FILTER_BUTTON(By.xpath(
			"//section[contains(@class,'item-g filter')]//div//label//input//following-sibling::span[text()='All']"),
			"All filter button"),

	/** The all filter button active. */
	ALL_FILTER_BUTTON_ACTIVE(By.xpath(
			"//section[contains(@class,'item-g filter')]//div//label[@class='active']//input//following-sibling::span[text()='All']"),
			"All filter button Active"),

	/** The connected filter button. */
	CONNECTED_FILTER_BUTTON(By.xpath("//section[contains(@class,'item-g filter')]//div//div//label//input//following-sibling::span[text()='Connected']"),
			"Connected filter button"),

	/** The connection pending button. */
	CONNECTION_PENDING_BUTTON(By.xpath("//span[text()='Connection pending']//parent::label//input"),
			"Connection pending button"),

	/** The require action button. */
	REQUIRE_ACTION_BUTTON(By.xpath("//span[text()='Require Action']//parent::label//input"),
			"Require action button"),

	/** The connected accounts list. */
	CONNECTED_ACCOUNTS_LIST(By.xpath("//img[contains(@src,'connected.svg')]"), "Connected Accounts list"),

	/** The connection pending accounts list. */
	CONNECTION_PENDING_ACCOUNTS_LIST(By.xpath("//img[contains(@src,'check-circle.svg')]"),
			"Connection Pending Accounts List"),

	/** The require action accounts list. */
	REQUIRE_ACTION_ACCOUNTS_LIST(By.xpath("//img[contains(@src,'require-action.svg')]"),
			"Require Action Accounts List");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new directory listings tab listings page enum.
	 *
	 * @param byLocator   the by locator
	 * @param description the description
	 */
	private DirectoryListingsTabListingsPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new directory listings tab listings page enum.
	 *
	 * @param xpath       the xpath
	 * @param description the description
	 */
	private DirectoryListingsTabListingsPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

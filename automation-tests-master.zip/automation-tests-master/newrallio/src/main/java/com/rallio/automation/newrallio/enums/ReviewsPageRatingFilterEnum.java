package com.rallio.automation.newrallio.enums;


// TODO: Auto-generated Javadoc
/**
 * The Enum ReviewsPageRatingFilterEnum.
 */
public enum ReviewsPageRatingFilterEnum {
	
	/** The any star. */
	ANY_STAR,
	
	/** The one star. */
	ONE_STAR,
	
	/** The two star. */
	TWO_STAR,
	
	/** The three star. */
	THREE_STAR,
	
	/** The four star. */
	FOUR_STAR,
	
	/** The five star. */
	FIVE_STAR,
	
	/** The recommended. */
	RECOMMENDED,
	
	/** The not recommended. */
	NOT_RECOMMENDED;
}

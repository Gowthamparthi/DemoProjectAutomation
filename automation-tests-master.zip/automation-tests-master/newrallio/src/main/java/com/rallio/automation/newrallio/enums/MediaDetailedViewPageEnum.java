package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum MediaDetailsPageEnum.
 */
public enum MediaDetailedViewPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//div[contains(@class,'mg-list-view')]//div[contains(@class,'mg-detailed')]"), "Media detials page load"),

	/** The delete button. */
	DELETE_BUTTON(By.xpath("//div[contains(@class,'btn-wrp-separate')]//button[text()='Delete']"), "Delete Button"),

	/** Media Delete alertbox. */
	MEDIA_DELETE_ALERTBOX(By.xpath("//div[text()='Are you sure?']"), "Media Delete alertbox"),

	/** Delete alert cancel button. */
	DELETE_ALERT_CANCEL_BUTTON(By.xpath("//div[contains(@class,'delete')]//button[contains(@class,'ac-btn ac-secondary-white ac-outline') and text()='Cancel']"), "Delete alert cancel button"),

	/** Delete alert delete button. */
	DELETE_ALERT_DELETE_BUTTON(By.xpath("//div[contains(@class,'delete')]//button[contains(@class,'ac-danger ac-btn') and text()='Delete']"), "Delete alert delete button"),

	/** Media deleted message. */
	MEDIA_DELETED_MESSAGE(By.xpath("//span[text()='Asset deleted']"), "Media deleted message"),
	
	/** The cancel button. */
	CANCEL_BUTTON(By.xpath("//div[contains(@class,'btn-wrp-separate')]//button[text()='Cancel']"), "Cancel Button"),

	/** Save All button. */
	SAVE_ALL_BUTTON(By.xpath("//div[contains(@class,'btn-wrp-separate')]//button[text()='Save All']"), "Save All Button"),

    // TAGS_UPLOADED(By.xpath("//div[@class='selectize-input items not-full
    // has-options has-items']//div"), "Tags uploaded"),

    // UPLOADED_BY(By.xpath("//h5[text()='Provided
    // by:']//following-sibling::span"), "Uploaded By"),

	/** The location. */
	LOCATION(By.xpath("//div[@class='wbf-item']//span[@class='wbf-label' and text()='Location']//parent::div//following-sibling::div[contains(@class,'wbf-inputs')]"), "Location"),

	HUB_LOCATION(By.xpath("//div[@class='wbf-item']//span[@class='wbf-label' and text()='Hub']//parent::div//following-sibling::div[contains(@class,'wbf-inputs')]"),"Hub location"),

	HUB_LOCATION_VIEW(By.xpath("//div[@class='wbf-item']//span[@class='wbf-label' and text()='Hub']"),"Hub Location"),

	BRAND_LOCATION(By.xpath("//div[@class='wbf-item']//span[@class='wbf-label' and text()='Brand']//parent::div//following-sibling::div[contains(@class,'wbf-inputs')]"),"Brand Loccation"),
	
	/** The uploaded on. */
	UPLOADED_ON(By.xpath("//div[@class='wbf-item']//span[text()='Uploaded on']//parent::div//following-sibling::div[@class='wbf-inputs ']"), "Uploaded on"),

	/** The AI Generated */
	AI_GENERATED(By.xpath("//div[@class='wbf-item']//span[text()='AI generated']//parent::div//following-sibling::div[@class='wbf-inputs ']"), "The AI Generated"),


	/** The media name. */
	MEDIA_NAME(By.xpath("//div[@class='rel-icons']//following-sibling::input[@name='fileName']"), "Media Name"),

	/** The close button at media name. */
	CLOSE_BUTTON_AT_MEDIA_NAME(By.xpath("//input[@name='fileName']//ancestor::div[contains(@class,'rel-head-label')]//following-sibling::div//img[@alt='Close']"),
	        "Close button at mediaName"),

	/** Times used. */
	TIMES_USED(By.xpath("//div[@class='wbf-item']//span[text()='Times used']//parent::div//following-sibling::div[@class='wbf-inputs ']"), "Times used"),

	/** The provided by. */
	PROVIDED_BY(By.xpath("//div[@class='wbf-item']//span[text()='Provided by']//parent::div//following-sibling::div[contains(@class,'wbf-inputs')]"), "Provided By"),

	PROVIDEDBY_BY_NAME("//div[@class='wbf-item']//span[text()='Provided by']//parent::div//following-sibling::div[contains(text(),'%s')]", "PROVIDEDBY_BY_NAME"),

	SOURCE(By.xpath("//div[@class='srnItem']//span[contains(text(),'')]"), "SOURCE"),

	BRAND_BY_NAME("//div[@class='wbf-item']//span[text()='Brand']//parent::div//following-sibling::div[contains(text(),'%s')]","BRAND_BY_NAME"),

	SOURCE_BY_NAME("//span[contains(text(),'%s')]", "SOURCE_BY_NAME"),

	HUB_BY_NAME("//div[@class='wbf-item']//span[text()='Hub']//parent::div//following-sibling::div[contains(text(),'%s')]","Hub By Name"),

	/** The approved. */
	APPROVED(By.xpath("//div[@class='wbf-item']//span[text()='Approved']//parent::div//following-sibling::div[@class='wbf-inputs ']"), "Approved"),

	/** Tags field. */
	TAGS_FIELD(By.xpath("//input[@aria-label='Add Tags']"), "Tags field"),

	TAGS_SAVE_BUTTON(By.xpath("//button[@class='ac-btn ac-primary size-xs' and text()='Save']"),"Tags Save button"),
	
	/** The select tags. */
	SELECT_TAGS("//input[@aria-label='Add Tags']//parent::div//following-sibling::div[@class='react-tags__suggestions']//*[text()='%s']", "Select tags"),

	/** Saved tags. */
	SAVED_TAGS("//div[@class='list-expanded-tag-item']//span[text()='%s']", "Saved Tags"),

	/** Tags remove button. */
	TAGS_REMOVE_BUTTON(By.xpath("//div[@class='list-expanded-tag-item']//span[@class='list-expanded-tag-remove']"), "Tags remove button"),

	REMOVE_TAGS("//div[@class='list-expanded-tag-item']//span[text()='%s']//following-sibling::span[@class='list-expanded-tag-remove']","Remove tags"),

	/** Internal notes. */
	USER_DESCRIPTION(By.xpath("//div[@class='wb-label']//div[text()='User Description']//parent::div//following-sibling::div//div[@class='if-main if-h']//textarea[@class='internal-notes']"), "Internal notes"),

	/** The AI Description */
	AI_DESCRIPTION(By.xpath("//div[@class='wb-label']//div[text()='AI Description']//parent::div//following-sibling::div//p"), "The AI Description"),


	/** The previous button. */
	PREVIOUS_BUTTON(By.xpath("//button[not(@disabled)]//span[text()='Previous']"), "Previous button"),

	/** The next button. */
	NEXT_BUTTON(By.xpath("//div[contains(@class,'scl-controls slide-controls')]//span[text()='Next']"), "Next button"),

	/** The crop. */
	CROP(By.xpath("//div//img"), "Crop"),

	/** The rotation. */
	ROTATION(By.xpath("//div//img"), "Rotation"),

	/** The rotate button. */
	ROTATE_BUTTON(By.xpath("//div//img"), "Rotate button"),

	/** The rotated media. */
	ROTATED_MEDIA(By.xpath("//div[contains(@class,'big-asset')]//img[contains(@src,'https://res.cloudinary.com/ralliohq/a_90/q_auto')]"), "Rotated media"),

	/** The filter. */
	FILTER(By.xpath("//div[@class='fi-icons']//following-sibling::span[text()='Filter']"), "Filter"),

	/** The watermark. */
	WATERMARK(By.xpath("//div[@class='fi-icons']//following-sibling::span[text()='Watermark']"), "Watermark"),

	/** The Edit. */
	EDIT_BUTTON(By.xpath("//div[@class='fi-icons']//following-sibling::span[text()='Edit']"), "Watermark"),


	WATERMARK_SECTION_SAVE_BUTTON(By.xpath("//div[@data-test='MainCanvasActionBar']//button//div[text()='Save']"), "Watermark section save button"),

	ASSET_UPDATED_MESSAGE(By.xpath("//span[text()='Asset updated successfully']"), "Asset updated message"),
	
	CLONE(By.xpath("//div[@class='fi-icons']//following-sibling::span[text()='Clone']"), "Clone"),
	
	CLONE_SECTION_SAVE_BUTTON(By.xpath("//div[@class='cloneHead']//following-sibling::div//button[text()='Save']"), "Clone section save button"),
	
	CLONED_SUCCESS_MESSAGE(By.xpath("//span[text()='Asset cloned successfully!']"), "Cloned success message"),
	
	/** The media crop view. */
	MEDIA_CROP_VIEW(By.xpath("//div//img"), "Media Crop View"),

	/** Cropped image. */
	CROPPED_IMAGE(By.xpath(""), "Cropped image"),

	/** The apply button. */
	APPLY_BUTTON(By.xpath("//div//img"), "Apply button"),
	//div[@class='fi-icons']//following-sibling::span[text()='Apply']
	
	/** The discard button. */
	DISCARD_BUTTON(By.xpath("//div//img"), "Discard button"),
	//div[@class='fi-icons']//following-sibling::span[text()='Discard']
	
	/** The internal notes section save button. */
	INTERNAL_NOTES_SECTION_SAVE_BUTTON(By.xpath("//div[contains(@class,'post__white--box int-note')]//button[text()='Save']"), "InternalNotes section save button"),

	/** The internal notes section cancel button. */
	INTERNAL_NOTES_SECTION_CANCEL_BUTTON(By.xpath("//div[contains(@class,'post__white--box int-note')]//button[text()='Cancel']"), "InternalNotes section cancel button"),


	/** Internal notes */
	INTERNAL_NOTES_TEXT("//div[@class='wb-label']//div[text()='User Description']//parent::div//following-sibling::div//div[@class='if-main if-h']//textarea[@class='internal-notes' and text()='%s']", "Internal notes"),

	/** The tags section save button. */
	TAGS_SECTION_SAVE_BUTTON(By.xpath("//div[contains(@class,'post__white--box tags')]//button[text()='Save']"), "Tags section save button"),

	/** The tags section cancel button. */
	TAGS_SECTION_CANCEL_BUTTON(By.xpath("//div[contains(@class,'post__white--box tags')]//button[text()='Cancel']"), "Tags section cancel button"),

	/** The image section. */
	IMAGE_SECTION(By.xpath("//div[contains(@class,'post__white--box post-img')]//div[contains(@class,'big-asset')]//img"), "Image section"),

	/** The video section. */
	VIDEO_SECTION(By.xpath("//div[contains(@class,'white--box post-img')]//div[contains(@class,'gma-video')]"), "Video section"),

	/** The image section save button. */
	IMAGE_SECTION_SAVE_BUTTON(By.xpath("//div//img"), "Image section save button"),
	//div[@class='white-box post-img']//button[text()='Save']
	
	/** The image section cancel button. */
	IMAGE_SECTION_CANCEL_BUTTON(By.xpath("//div//img"), "Image section cancel button"),
	//div[@class='white-box post-img']//button[text()='Cancel']
	
	DETAILEDVIDEO_INACTIVE_PREVIOUS_BUTTON(By.xpath("//button[@class='primeblueaction cmn-blue-btn sc-prev pointer-events-none btn btn-primary']//span[text()='Previous']"),"Previous Button Inactive"),
	
	DETAILEDVIDEO_NEXT_BUTTON(By.xpath("//button[@class='primeblueaction cmn-blue-btn sc-next btn btn-primary']//span[text()='Next']"),"Next Button"),
	
	/** The media updated message. */
	MEDIA_UPDATED_MESSAGE(By.xpath(" "), "Media updated message"),

	/** The location. */
	HUB_NAME(By.xpath("//div[@class='wbf-item']//span[@class='wbf-label' and text()='Hub']//parent::div//following-sibling::div[contains(@class,'wbf-inputs')]"), "Location"),
	
	/** The detail view - media name */
	DETAIL_VIEW_MEDIA_NAME(By.xpath("//div[contains(@class,'mainContent animate__animated')]//div[contains(@class,'rel-head')]//input[@name='fileName']"), "The detail view - media name"),
	
	/** The detail view - description area */
	DETAIL_VIEW_DESCRIPTION_BOX(By.xpath("//div[contains(@class,'mainContent animate__animated')]//div[@class='input-fields']//textarea[@class='internal-notes']"), " The detail view - description area"),

	/** The available for everyoneelse button. */
	AVAILABLE_FOR_EVERYONEELSE_BUTTON(By.xpath("//label//input//following-sibling::span[text()='Available for Everyone Else']"),"Available For EveryOne Else button"),

	/** The avaliable for personal use. */
	AVAILABLE_FOR_PERSONAL_USE_BUTTON(By.xpath("//label//input//following-sibling::span[text()='Available for Personal Use Only']"),"Available For personal use button"),

	AVAILABILTY_ACTIVE_SECTION("//div[text()='Availability']//ancestor::div[@class='post__white--box int-note']//label[contains(@class,'active')]//span[text()='%s']","AVAILABILTY_ACTIVE_SECTION"),

	IMAGE_EDITING_ACTIVE_SECTION("//div[text()='Image Editing']//ancestor::div[@class='post__white--box int-note']//label[contains(@class,'active')]//span[text()='%s']","AVAILABILTY_ACTIVE_SECTION"),

	IMAGE_EDITING_INACTIVE_SECTION("//div[text()='Image Editing']//ancestor::div[@class='post__white--box int-note']//label//span[text()='%s']","Image Editing Section Inactive"),

	/** The Expiration - Always available button */
	EXPIRATION_ALWAYS_AVAILABLE_BUTTON(By.xpath("//label//span[text()='Always Available']//parent::label//input[@type='radio']"),"Expiration - Always available button"),

	/** The Expiration - Custom button */
	EXPIRATION_CUSTOM_BUTTON(By.xpath("//label//span[text()='Custom']//parent::label//input[@type='radio']"),"Expiration - Custom button"),

	EXPIRATION_SELECTED_DATE(By.xpath("//div[text()='Expiration']//ancestor::div//div[@class='mExpBase']//div[@class='react-datepicker-wrapper']//input"),"Expiration selected date"),

	/** The Expiration - Custom datepicker button */
	EXPIRATION_CUSTOM_DATEPICKER_BUTTON(By.xpath("//div[contains(@class,'Expiration')]//div[contains(@class,'react-datepicker')]//input[@class='fltr-date-item fltr-from-date']")," The Expiration - Custom datepicker button"),

	/** Selecting current date in date picker */
	SELECT_CURRENT_DATE_IN_DATE_PICKER(By.xpath("//div[@class='react-datepicker']//div[@class='react-datepicker__week']//div[contains(@class,'keyboard-selected')]"),"Selecting current date in date picker"),

	/** Expiration selected custom date */
	EXPIRATION_SELECTED_CUSTOM_DATE(By.xpath("//div[contains(@class,'Expiration')]//div[@class='react-datepicker-wrapper']//input[@class='fltr-date-item fltr-from-date']"),"Expiration selected custom date"),

	IMAGE_EDITING_NOT_ALLOWED(By.xpath("//span[text()='Image Editing']//parent::div//following-sibling::div[text()='Not Allowed']"),"Image editing not allowed"),

	IMAGE_EDITING_ALLOWED(By.xpath("//span[text()='Image Editing']//parent::div//following-sibling::div[text()='Allowed']"),"Image editing allowed"),

	ALL_OTHERS_TO_EDIT_OPTION_INACTIVE(By.xpath("//span[text()='Allow Others to Edit Image']//parent::label//input"),"All Others To Edit Option"),

	ALL_OTHERS_TO_EDIT_OPTION_ACTIVE(By.xpath("//span[text()='Allow Others to Edit Image']//parent::label[contains(@class,'active')]//input"),"All Others To Edit Option Active"),


	DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]","Date Picker"),

	;
	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new media details page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private MediaDetailedViewPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new media detailed view page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private MediaDetailedViewPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the bylocator.
	 *
	 * @return the bylocator
	 */
	public By getBylocator() {

		return byLocator;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}
}

package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum InboxPostReplyPageEnum.
 */
public enum InboxPostReplyPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//div[@class='pmisorMain']//div[@class='pmisorCnt']"), "Page load"),

	/** Facebook post icon. */
	FACEBOOK_POST_ICON(By.xpath("//div[@class='pmisorCnt']//div[@class='gm-item']//img[contains(@src,'facebook.svg')]//parent::div//following-sibling::div//h3[text()='Facebook']"),
	        "Facebook post icon"),

	/** Post page name. */
	POST_PAGE_NAME(By.xpath("//div[@class='pmisorCnt']//div[@class='gm-item']//div[@class='gm-head'][1]//div//h3[text()]"), "Post page name"),

	/** Post location name. */
	POST_LOCATION_NAME(By.xpath("//div[@class='pmisorCnt']//div[@class='gm-item']//div[@class='gm-head'][2]//div//h3[text()]"), "Post location name"),

	/** Post description. */
	POST_DESCRIPTION(By.xpath("//div[@class='pmisorCnt']//div[@class='gm-item']//div[@class='gm-content']//span[@width]//span[not(@style)]//span[text()]"), "Post description"),

	/** Post Open website. */
	POST_OPEN_WEBSITE(By.xpath("//div[@class='pmisorCnt']//div[@class='gm-item']//button//img[contains(@src,'link.svg')]"), "Post Open website"),

	/** Facebook post like button. */
	FACEBOOK_POST_LIKE_BUTTON("//div[@class='pmisorCnt']//div[@class='gm-item']//button//img[contains(@src,'like-mg.svg')]", "Facebook Post like button"),

	/** Facebook post liked. */
	FACEBOOK_POST_LIKED("//div[@class='pmisorCnt']//div[@class='gm-item']//button//img[contains(@src,'like-a-mg.svg')]", "Facebook Post liked"),

	/** Post delete button. */
	POST_DELETE_BUTTON(By.xpath("//div[@class='pmisorCnt']//div[@class='gm-item']//button//img[contains(@src,'delete.svg')]"), "Post delete button"),

	/** Reply text area. */
	REPLY_TEXT_AREA(By.xpath("//div[@class='pmisorCnt']//textarea[@id='inbox-internalNotes']"), "Reply text area"),

	/** Send reply button. */
	SEND_REPLY_BUTTON(By.xpath("//div[@class='pmisorCnt']//button[text()='Send Reply']"), "Send reply button"),

	/** Cancel button. */
	CANCEL_BUTTON(By.xpath("//div[@class='pmisorCnt']//button[text()='Cancel']"), "Cancel button");

	/** The by locator. */
	private By byLocator;

	/** The xpath. */
	private String xpath;

	/** The description. */
	private String description;

	/**
	 * Instantiates a new inbox post reply page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private InboxPostReplyPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new inbox post reply page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private InboxPostReplyPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return byLocator;
	}

	/**
	 * Gets the by xpath.
	 *
	 * @return the by xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}
}

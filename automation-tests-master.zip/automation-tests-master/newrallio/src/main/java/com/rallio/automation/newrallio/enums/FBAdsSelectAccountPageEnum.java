package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum FBAdsSelectAccountPageEnum.
 */
public enum FBAdsSelectAccountPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//h3[text()='Please select an Ad Account']//ancestor::div[@class='modal-content']"), "Page load"),

	/** The cancel button. */
	CANCEL_BUTTON(By.xpath("//h3[text()='Please select an Ad Account']//ancestor::div[@class='modal-content']//div[@class='modal-footer']//button[text()='Cancel']"),
	        "Cancel button"),

	/** The connect now button. */
	CONNECT_NOW_BUTTON(By.xpath("//h3[text()='Please select an Ad Account']//ancestor::div[@class='modal-content']//div[@class='modal-footer']//button[text()='Connect Now']"),
	        "Connect now button"),

	/** The accounts. */
	ACCOUNTS(By.xpath(
	        "//h3[text()='Please select an Ad Account']//ancestor::div[@class='modal-content']//div[@class='modal-body']//div[@class='aps-main']//div[contains(@class,'aps-item')]"),
	        "Accounts"),

	/** The account selected. */
	ACCOUNT_SELECTED(By.xpath(
	        "//h3[text()='Please select an Ad Account']//ancestor::div[@class='modal-content']//div[@class='modal-body']//div[@class='aps-main']//div[contains(@class,'active')]"),
	        "Account selected"),

	/** The close button. */
	CLOSE_BUTTON(By.xpath("//h3[text()='Please select an Ad Account']//ancestor::div[@class='modal-content']//button//span[text()='Close']//preceding-sibling::span"),
	        "Close button");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new FB ads select account page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private FBAdsSelectAccountPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new FB ads select account page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private FBAdsSelectAccountPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

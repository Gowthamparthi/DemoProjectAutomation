package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum ContentTabCampaignPageEnum.
 */
public enum ContentTabCampaignPageEnum {

	/** The footer. */
	PAGE_LOAD(By.xpath(
			"//div[contains(@class,'campaignStatsOnly')]//following-sibling::div[contains(@class,'search')]//following::div//div[@id='campaigns-ifs']"),
			"Footer"),

	/** The search field. */
	SEARCH_FIELD(By.xpath(
			"//div[contains(@class,'campaignStatsOnly')]//following-sibling::div[contains(@class,'search')]//input[@placeholder='Search campaign']"),
			"SEARCH_FIELD"),

	/** The no data to show. */
	NO_DATA_TO_SHOW(By.xpath("//span[text()='No data to show']"), "NO_DATA_TO_SHOW"),

	/** The campaigns. */
	CAMPAIGNS(By.xpath("//div[contains(@class,'coupon-card')]"), "CAMPAIGNS"),

	CAMPAIGN_PROFILE_IMAGE(By.xpath("//div[@class='coupon-content ']//img[@alt='Post Image']"),"CAMPAIGN_PROFILE_IMAGE"),

	CAMPAIGN_PROFILE_IMAGE_BY_NAME("//div[@class='coupon-details']//span[contains(text(),'%s')]//ancestor::div[@class='coupon__inner--content ']//img[@alt='Post Image']","CAMPAIGN_PROFILE_IMAGE_BY_NAME"),

	CAMPAIGN_PROFILE_IMAGE_WITH_LIST("//div[@class='coupon-details']//span[contains(text(),'%s')]//ancestor::div//div[@class='campaign__det--list']//div[contains(@class,'pls post-list__main')]//div//div[contains(@class,'m-item')]","Campaign Profile Image with List"),
	
	/** The campaign tile stats count. */
	CAMPAIGN_TILE_STATS_COUNT(By.xpath(
			"//div[contains(@class,'campaignStatsOnly')]//span[text()='Campaigns']//parent::div//span[@class='mod-count']//div"),
			"CAMPAING_TILE_STATS_COUNT"),

	/** The active campaigns tile green image. */
	ACTIVE_CAMPAIGNS_TILE_GREEN_IMAGE(By.xpath(
			"//div[contains(@class,'campaignStatsOnly')]//span[text()='Active Campaigns']//parent::div//following-sibling::div//img[contains(@src,'campaign-active-green.svg')]"),
			"ACTIVE_CAMPAIGNS_TILE_STATS_COUNT"),

	/** The active campaigns tile stats count. */
	ACTIVE_CAMPAIGNS_TILE_STATS_COUNT(By.xpath(
			"//div[contains(@class,'campaignStatsOnly')]//span[text()='Active Campaigns']//parent::div//span//div"),
			"ACTIVE_CAMPAIGNS_TILE_GREEN_IMAGE"),

	/** The inactive campaigns tile stats count. */
	INACTIVE_CAMPAIGNS_TILE_STATS_COUNT(By.xpath(
			"//div[contains(@class,'campaignStatsOnly')]//span[text()='Inactive Campaigns']//parent::div//span//div"),
			"INACTIVE_CAMPAIGNS_TILE_STATS_COUNT"),

	/** The inactive campaigns tile grey image. */
	INACTIVE_CAMPAIGNS_TILE_GREY_IMAGE(By.xpath(
			"//div[contains(@class,'campaignStatsOnly')]//span[text()='Inactive Campaigns']//parent::div//following-sibling::div//img[contains(@src,'campaign-inactive-grey.svg')]"),
			"INACTIVE_CAMPAIGNS_TILE_GREY_IMAGE"),

	/** The available campaigns tile stats count. */
	AVAILABLE_CAMPAIGNS_TILE_STATS_COUNT(By.xpath(
			"//div[contains(@class,'campaignStatsOnly')]//span[text()='Available Campaigns']//parent::div//span//div"),
			"AVAILABLE_CAMPAIGNS_TILE_STATS_COUNT"),

	/** The available campaigns tile blue image. */
	AVAILABLE_CAMPAIGNS_TILE_BLUE_IMAGE(By.xpath(
			"//div[contains(@class,'campaignStatsOnly')]//span[text()='Available Campaigns']//parent::div//following-sibling::div//img[contains(@src,'campaign-available-blue.svg')]"),
			"AVAILABLE_CAMPAIGNS_TILE_BLUE_IMAGE"),

	/** The create campaign button. */
	CREATE_CAMPAIGN_BUTTON(By.xpath("//div[contains(@class,'campaignStatsOnly')]//div//span[text()='CREATE CAMPAIGN']"),
			"CREATE_CAMPAIGN_BUTTON"),

	/** The available campaigns. */
	AVAILABLE_CAMPAIGNS(By.xpath(
			"//div[contains(@class,'coupon-card')]//div[contains(@class,'campaign-available')]//span[text()='AVAILABLE']"),
			"AVAILABLE_CAMPAIGNS"),

	/** The active campaigns. */
	ACTIVE_CAMPAIGNS(By.xpath(
			"//div[contains(@class,'coupon-card')]//div[contains(@class,'campaign-active')]//span[text()='ACTIVE']"),
			"ACTIVE_CAMPAIGNS"),

	/** The inactive campaigns. */
	INACTIVE_CAMPAIGNS(By.xpath(
			"//div[contains(@class,'coupon-card')]//div[contains(@class,'campaign-inactive')]//span[text()='INACTIVE']"),
			"INACTIVE_CAMPAIGNS"),

	/** The campaign name by position. */
	CAMPAIGN_NAME_BY_POSITION(
			"//div[contains(@class,'coupon-card')][%s]//div[contains(@class,'coupon-content ')]//div//span",
			"ACTIVE_CAMPAIGNS"),

	/** The campaign date by name. */
	CAMPAIGN_DATE_BY_NAME(
			"//div[contains(@class,'coupon-card')]//div[contains(@class,'coupon-content')]//span[text()='%s']//parent::div//following-sibling::div[@class='camp-date']",
			"CAMPAIGN_DATE_BY_NAME"),

	/** The campaign used count by name. */
	CAMPAIGN_USED_COUNT_BY_NAME(
			"//h5//span[text()='admin campaign']//ancestor::div[@class='coupan-card-left']//following-sibling::div[@class='coupan-card-right']//div[@class='ci-usage']//span[@class='ci-value']",
			"CAMPAIGN_USED_COUNT_BY_NAME"),

	/** The campaign availability status by name. */
	CAMPAIGN_AVAILABILITY_STATUS_BY_NAME(
			"//span[contains(text(),'%s')]//ancestor::div[contains(@class,'coupan-card-left')]//following-sibling::div[@class='coupan-card-right']//div[@class='ci-avail']//span[@class='ci-value']",
			"CAMPAIGN_AVAILABILITY_STATUS_BY_NAME"),

	CAMPAIGN_LIST_NAME(By.xpath(
			"//div[contains(@class,'coupon-content')]//div[@class='coupon-details']//span[@class='ccd-head' and text()]"),
			"Campaign List Name"),

	/** The campaign by name. */
	CAMPAIGN_BY_NAME("//div[contains(@class,'coupon-card')]//span[contains(text(),'%s')]",
			"CAMPAIGN_AVAILABILITY_STATUS_BY_NAME"),

	CAMPAIGN_BY_NAME_PREFIX("//div[contains(@class,'coupon-card')]//span[contains(text(),'%s')]",
			"CAMPAIGN_AVAILABILITY_STATUS_BY_NAME_PREFIX"),

	INACTIVE_STATUS_CAMPAIGN_NAME("//span[@class='status__card--txt' and text()='INACTIVE']//ancestor::div[contains(@class,'coupon-card')]//span[contains(text(),'%s')]","IACTIVE STATUS CAMAPAIGN"),
	
	/** The clear filter button. */
	CLEAR_FILTER_BUTTON(By.xpath("//span[text()='Clear Filter']//parent::button"),"CLEAR_FILTER_BUTTON"),

	/** The source all filter. */
	SOURCE_ALL_FILTER(By.xpath("//h3[text()='Source']//parent::div//label//input[@value='all']"), "SOURCE_ALL_FILTER"),

	/** The source all filter active. */
	SOURCE_ALL_FILTER_ACTIVE(
			By.xpath("//h3[text()='Source']//parent::div//label[@class='active']//input[@value='all']"),
			"SOURCE_ALL_FILTER_ACTIVE"),

	/** The source brand filter. */
	SOURCE_BRAND_FILTER(By.xpath("//h3[text()='Source']//parent::div//label//input[@value='brand']"),
			"SOURCE_BRAND_FILTER"),

	/** The source brand filter active. */
	SOURCE_BRAND_FILTER_ACTIVE(
			By.xpath("//h3[text()='Source']//parent::div//label[@class='active']//input[@value='brand']"),
			"SOURCE_BRAND_FILTER_ACTIVE"),

	/** The source location filter. */
	SOURCE_LOCATION_FILTER(By.xpath("//h3[text()='Source']//parent::div//label//input[@value='location']"),
			"SOURCE_LOCATION_FILTER"),

	/** The source location filter active. */
	SOURCE_LOCATION_FILTER_ACTIVE(
			By.xpath("//h3[text()='Source']//parent::div//label[@class='active']//input[@value='location']"),
			"SOURCE_LOCATION_FILTER_ACTIVE"),

	/** The status all campaigns filter. */
	STATUS_ALL_CAMPAIGNS_FILTER(By.xpath("//h3[text()='Status']//parent::div//label//input[@value='all']"),
			"STATUS_ALL_CAMPAIGNS_FILTER"),

	/** The status all campaigns filter active. */
	STATUS_ALL_CAMPAIGNS_FILTER_ACTIVE(
			By.xpath("//h3[text()='Status']//parent::div//label[@class='active']//input[@value='all']"),
			"STATUS_ALL_CAMPAIGNS_FILTER_ACTIVE"),

	/** The status active campaigns filter. */
	STATUS_ACTIVE_CAMPAIGNS_FILTER(By.xpath("//h3[text()='Status']//parent::div//label//input[@value='active']"),
			"STATUS_ACTIVE_CAMPAIGNS_FILTER"),

	/** The status inactive campaigns filter. */
	STATUS_INACTIVE_CAMPAIGNS_FILTER(By.xpath("//h3[text()='Status']//parent::div//label//input[@value='inactive']"),
			"STATUS_INACTIVE_CAMPAIGNS_FILTER"),

	/** The status available campaigns filter. */
	STATUS_AVAILABLE_CAMPAIGNS_FILTER(By.xpath("//h3[text()='Status']//parent::div//label//input[@value='available']"),
			"STATUS_AVAILABLE_CAMPAIGNS_FILTER"),

	/** The status available campaigns filter active. */
	STATUS_AVAILABLE_CAMPAIGNS_FILTER_ACTIVE(
			By.xpath("//h3[text()='Status']//parent::div//label[@class='active']//input[@value='available']"),
			"STATUS_AVAILABLE_CAMPAIGNS_FILTER_ACTIVE"),

	/** The campaign edit button. */
	CAMPAIGN_EDIT_BUTTON(By.xpath("//button//span[text()='Edit']"), "CAMPAIGN_EDIT_BUTTON"),

	/** The campaign edit button by name. */
	CAMPAIGN_EDIT_BUTTON_BY_NAME(
			"//span[contains(text(),'%s')]//ancestor::div[contains(@class,'card-bg coupon-card')]//div[@class='cpnItem']//button//span[text()='Edit']",
			"CAMPAIGN_EDIT_BUTTON_BY_NAME"),

	/** The edit campaign page. */
	EDIT_CAMPAIGN_PAGE(By.xpath("//div[contains(@class,'modal-body')]//h2[text()='Edit Campaign']"),
			"EDIT_CAMPAIGN_PAGE"),

	/** The edit campaign page name field.*/
	EDIT_CAMPAIGN_PAGE_NAME_FIELD(By.xpath("//div[@class='form-group']//input[@name='name']"), "EDIT_CAMPAIGN_PAGE_NAME_FIELD"),

	/** The edit campaign page description field. */
	EDIT_CAMPAIGN_PAGE_DESCRIPTION_FIELD(
			By.xpath("//h2[text()='Edit Campaign']//parent::div//textarea[@id='campaign-description']"),
			"EDIT_CAMPAIGN_PAGE_DESCRIPTION_FIELD"),

	/** The edit campaign page availability expires on button. */
	EDIT_CAMPAIGN_PAGE_AVAILABILITY_EXPIRES_ON_BUTTON(
			By.xpath("//span[text()='Expires On']//parent::label//input[@name='availability']"),
			"EDIT_CAMPAIGN_PAGEAVAILABILITY_EXPIRES_ON_BUTTON"),
	
	/** The edit campaign page availability expires on button active. */
	EDIT_CAMPAIGN_PAGE_AVAILABILITY_EXPIRES_ON_BUTTON_ACTIVE(
			By.xpath("//span[text()='Expires On']//parent::label[@class='active']//input[@name='availability']"),
			"EDIT_CAMPAIGN_PAGE_AVAILABILITY_EXPIRES_ON_BUTTON_ACTIVE"),

	/** The edit campaign page availability ongoing button. */
	EDIT_CAMPAIGN_PAGE_AVAILABILITY_ONGOING_BUTTON(
			By.xpath("//span[text()='Ongoing']//parent::label//input[@name='availability']"),
			"EDIT_CAMPAIGN_PAGEAVAILABILITY_ONGOING_BUTTON"),

	/** The edit campaign page availability ongoing button active. */
	EDIT_CAMPAIGN_PAGE_AVAILABILITY_ONGOING_BUTTON_ACTIVE(
			By.xpath("//span[text()='Ongoing']//parent::label[@class='active']//input[@name='availability']"),
			"EDIT_CAMPAIGN_PAGE_AVAILABILITY_ONGOING_BUTTON_ACTIVE"),

	/** The edit campaign page cancel button. */
	EDIT_CAMPAIGN_PAGE_CANCEL_BUTTON(
			By.xpath("//h2[text()='Edit Campaign']//parent::div//span[text()='Cancel']//parent::button"),
			"EDIT_CAMPAIGN_PAGE_CANCEL_BUTTON"),

	/** The edit campaign page campaign updated popup. */
	EDIT_CAMPAIGN_PAGE_CAMPAIGN_UPDATED_POPUP(By.xpath("//span[text()='Campaign updated successfully!']"),
			"EDIT_CAMPAIGN_PAGE_CAMPAIGN_UPDATED_POPUP"),

	/** The edit campaign page save button. */
	EDIT_CAMPAIGN_PAGE_SAVE_BUTTON(
			By.xpath("//h2[text()='Edit Campaign']//parent::div//span[text()='Save']//parent::button"),
			"EDIT_CAMPAIGN_PAGE_SAVE_BUTTON"),

	/** The edit campaign page calendar button. */
	EDIT_CAMPAIGN_PAGE_CALENDAR_BUTTON(
			By.xpath("//div[@class='ccea-datePicker']//div[@class='react-datepicker__input-container']"),
			"EDIT_CAMPAIGN_PAGE_CALENDAR_BUTTON"),

	/** The edit campaign page calendar next month navigation. */
	EDIT_CAMPAIGN_PAGE_CALENDAR_NEXT_MONTH_NAVIGATION(
			By.xpath("//button[contains(@class,'react-datepicker__navigation--next')]"),
			"EDIT_CAMPAIGN_PAGE_CALENDAR_NEXT_MONTH_NAVIGATION"),

	/** The edit campaign page calendar previous month navigation. */
	EDIT_CAMPAIGN_PAGE_CALENDAR_PREVIOUS_MONTH_NAVIGATION(
			By.xpath("//button[contains(@class,'react-datepicker__navigation--previous')]"),
			"EDIT_CAMPAIGN_PAGE_CALENDAR_PREVIOUS_MONTH_NAVIGATION"),

	/** The edit campaign page calendar select day button. */
	EDIT_CAMPAIGN_PAGE_CALENDAR_SELECT_DAY_BUTTON(
			"//div[contains(@class,'react-datepicker__day react-datepicker__day') and text()='%s']",
			"EDIT_CAMPAIGN_PAGE_CALENDAR_DAY_BUTTON"),

	/** The edit campaign page calendar input field. */
	EDIT_CAMPAIGN_PAGE_CALENDAR_INPUT_FIELD(
			By.xpath("//div[@class='ccea-datePicker']//div[@class='react-datepicker__input-container']//input"),
			"EDIT_CAMPAIGN_PAGE_CALENDAR_BUTTON"),

	/** The edit campaign page calendar close button. */
	EDIT_CAMPAIGN_PAGE_CALENDAR_CLOSE_BUTTON(
			By.xpath("//div[@class='ccea-datePicker']//button[@class='react-datepicker__close-icon']"),
			"EDIT_CAMPAIGN_PAGE_CALENDAR_CLOSE_BUTTON"),

	/** The month dropdown. */
	MONTH_DROPDOWN(By.xpath("//select[@class='react-datepicker__month-select']"), "Month drop down"),

	YEAR_DROPDOWN(By.xpath("//select[@class='react-datepicker__year-select']"), "Year drop down."),

	PREVIOUS_MONTH(By.xpath("//button[contains(@class,'navigation--previous')]"), "Previous month."),

	/** The next month. */
	NEXT_MONTH(By.xpath("//button[contains(@class,'navigation--next')]"), "Next month."),
	
	CAMPAIGN_POST_WITH_DESCRIPTION(By.xpath("//div[@class='coupon-content ']//div[@class='coupon-details']//div[@class='coupon__details--head']//following::p[text()]"),"Campaign post with Description"),
	
	/** The campaign grid view posts. */
	// Edit Campaign Elements
	CAMPAIGN_GRID_VIEW_POSTS(By.xpath("//div[contains(@class,'pls post-list')]//div[@class='drag-item']"),
			"CAMPAIGN_POSTS"),

	/** The campaign grid view view posts button. */
	CAMPAIGN_GRID_VIEW_VIEW_POSTS_BUTTON(By.xpath("//span[text()='View Post']//parent::button"),
			"CAMPAIGN_GRID_VIEW_VIEW_POSTS_BUTTON"),

	/** The campaign view view schedules button. */
	CAMPAIGN_VIEW_VIEW_SCHEDULES_BUTTON(By.xpath("//button//span[text()='View Schedules']"), "VIEW_SCHEDULES_BUTTON"),

	/** The campaign view schedule posts table. */
	CAMPAIGN_VIEW_SCHEDULE_POSTS_TABLE(By.xpath("//div[@class='campaign-schedule-table']//tbody//tr"),
			"CAMPAIGN_SCHEDULE_POSTS_TABLE"),

	/** The campaign schedule posts stop button. */
	CAMPAIGN_SCHEDULE_POSTS_STOP_BUTTON(
			By.xpath("//div[@class='campaign-schedule-table']//tbody//tr//button//span[text()='Stop']"),
			"CAMPAIGN_SCHEDULE_POSTS_STOP_BUTTON"),

	CMAPAIGN_DETAILVIEW_STOP_CAMPAIGN_BUTTON(By.xpath("//button[@class='ac-btn ac-secondary ac-block ac-danger stopCmpgn']//span[text()='Stop Campaign']"),"Stop Campaign Button"),

	STOP_CAMPAIGN_DETAILVIEW_TOP_BUTTON(By.xpath("//button[@class='modal-btn-action-itm modal-delete-btn' and text()='Stop']"),"STOP_CAMPAIGN_DETAILVIEW_TOP_BUTTON"),

	CAMPAIGN_SCHEDULE_POSTS_EDIT_BUTTON(
			By.xpath("//div[@class='campaign-schedule-table']//tbody//tr//button//span[text()='Edit']"),
			"CAMPAIGN_SCHEDULE_POSTS_EDIT_BUTTON"),

	/** The campaign view stop campaign conformation section. */
	CAMPAIGN_VIEW_STOP_CAMPAIGN_CONFORMATION_SECTION(
			By.xpath("//*[text()='Are you sure you want to stop this campaign schedule?']"),
			"CAMPAIGN_VIEW_STOP_CAMPAIGN_CONFORMATION_SECTION"),

	/** The stop campaign conformation section yes button. */
	STOP_CAMPAIGN_CONFORMATION_SECTION_YES_BUTTON(By.xpath(
			"//*[text()='Are you sure you want to stop this campaign schedule?']//parent::div//parent::div//following-sibling::div//button[text()='Yes']"),
			"STOP_CAMPAIGN_CONFORMATION_SECTION_YES_BUTTON"),

	/** The stop campaign conformation section no button. */
	STOP_CAMPAIGN_CONFORMATION_SECTION_NO_BUTTON(By.xpath(
			"//*[text()='Are you sure you want to stop this campaign schedule?']//parent::div//parent::div//following-sibling::div//button[text()='No']"),
			"STOP_CAMPAIGN_CONFORMATION_SECTION_NO_BUTTON"),

	/** The capaign stop done popup. */
	CAPAIGN_STOP_DONE_POPUP(By.xpath("//span[text()='Done!']"), "CAPAIGN_STOP_DONE_POPUP"),

	/** The create campaign view. */
	// Create Campaign Elements
	CREATE_CAMPAIGN_VIEW(By.xpath("//h2[text()='Create New Campaign']"), "CREATE_CAMPAIGN_VIEW"),

	/** The create campaign page. */
	CREATE_CAMPAIGN_PAGE(By.xpath("//div[contains(@class,'modal-body')]//h2[text()='Create New Campaign']"),
			"CREATE_CAMPAIGN_PAGE"),

	/** The create campaign view name field. */
	CREATE_CAMPAIGN_VIEW_NAME_FIELD(By.xpath("//h2[text()='Create New Campaign']//parent::div//input[@name='name']"),
			"CREATE_CAMPAIGN_VIEW_NAME_FIELD"),

	/** The create campaign view name field error. */
	CREATE_CAMPAIGN_VIEW_NAME_FIELD_ERROR(By.xpath(
			"//h2[text()='Create New Campaign']//parent::div//div[@class='cceb-field erroritem']//input[@name='name']"),
			"CREATE_CAMPAIGN_VIEW_NAME_FIELD"),

	/** The create campaign view description field. */
	CREATE_CAMPAIGN_VIEW_DESCRIPTION_FIELD(
			By.xpath("//h2[text()='Create New Campaign']//parent::div//textarea[@id='campaign-description']"),
			"CREATE_CAMPAIGN_VIEW_DESCRIPTION_FIELD"),

	/** The create campaign view availability expires on button. */
	CREATE_CAMPAIGN_VIEW_AVAILABILITY_EXPIRES_ON_BUTTON(
			By.xpath("//span[text()='Expires On']//parent::label[@class='active']//input[@name='availability']"),
			"CREATE_CAMPAIGN_VIEW_AVAILABILITY_EXPIRES_ON_BUTTON"),

	/** The create campaign view availability expires on button active. */
	CREATE_CAMPAIGN_VIEW_AVAILABILITY_EXPIRES_ON_BUTTON_ACTIVE(
			By.xpath("//span[text()='Expires On']//parent::label[@class='active']//input[@name='availability']"),
			"CREATE_CAMPAIGN_VIEW_AVAILABILITY_EXPIRES_ON_BUTTON_ACTIVE"),

	/** The create campaign view availability ongoing button. */
	CREATE_CAMPAIGN_VIEW_AVAILABILITY_ONGOING_BUTTON(
			By.xpath("//span[text()='Ongoing']//parent::label//input[@name='availability']"),
			"CREATE_CAMPAIGN_VIEW_AVAILABILITY_ONGOING_BUTTON"),

	/** The create campaign view availability ongoing button active. */
	CREATE_CAMPAIGN_VIEW_AVAILABILITY_ONGOING_BUTTON_ACTIVE(
			By.xpath("//span[text()='Ongoing']//parent::label[@class='active']//input[@name='availability']"),
			"CREATE_CAMPAIGN_VIEW_AVAILABILITY_ONGOING_BUTTON_ACTIVE"),

	/** The create campaign view cancel button. */
	CREATE_CAMPAIGN_VIEW_CANCEL_BUTTON(
			By.xpath("//h2[text()='Create New Campaign']//parent::div//parent::form//button//span[text()='Cancel']"),
			"CREATE_CAMPAIGN_VIEW_CANCEL_BUTTON"),

	/** The create campaign view campaign updated popup. */
	CREATE_CAMPAIGN_VIEW_CAMPAIGN_UPDATED_POPUP(By.xpath("//span[text()='Campaign updated successfully!']"),
			"CREATE_CAMPAIGN_VIEW_CAMPAIGN_UPDATED_POPUP"),

	/** The create campaign view save button. */
	CREATE_CAMPAIGN_VIEW_SAVE_BUTTON(
			By.xpath("//h2[text()='Create New Campaign']//parent::div//parent::form//button//span[text()='Save']"),
			"CREATE_CAMPAIGN_VIEW_SAVE_BUTTON"),

	/** The create campaign view calendar button. */
	CREATE_CAMPAIGN_VIEW_CALENDAR_BUTTON(
			By.xpath("//div[@class='react-datepicker-wrapper']//div[@class='react-datepicker__input-container']"),
			"CREATE_CAMPAIGN_VIEW_CALENDAR_BUTTON"),

	/** The create campaign view calendar button error. */
	CREATE_CAMPAIGN_VIEW_CALENDAR_BUTTON_ERROR(By.xpath("//div[@class='ccea-datePicker erroritem']"),
			"CREATE_CAMPAIGN_VIEW_CALENDAR_BUTTON_ERROR"),

	/** The create campaign view calendar next month navigation. */
	CREATE_CAMPAIGN_VIEW_CALENDAR_NEXT_MONTH_NAVIGATION(
			By.xpath("//button[contains(@class,'react-datepicker__navigation--next')]"),
			"CREATE_CAMPAIGN_VIEW_CALENDAR_NEXT_MONTH_NAVIGATION"),

	/** The create campaign view calendar previous month navigation. */
	CREATE_CAMPAIGN_VIEW_CALENDAR_PREVIOUS_MONTH_NAVIGATION(
			By.xpath("//button[contains(@class,'react-datepicker__navigation--previous')]"),
			"CREATE_CAMPAIGN_VIEW_CALENDAR_PREVIOUS_MONTH_NAVIGATION"),
	
	CREATE_CAMPAIGN_VIEW_CALENDAR_SELECT_DAY_BUTTON(
			"//div[not(contains(@class,'react-datepicker__day--outside-month')) and contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]",
			"CREATE_CAMPAIGN_VIEW_CALENDAR_SELECT_DAY_BUTTON"),

	/** The create campaign view calendar input field. */
	CREATE_CAMPAIGN_VIEW_CALENDAR_INPUT_FIELD(
			By.xpath("//div[@class='ccea-datePicker']//div[@class='react-datepicker__input-container']//input"),
			"CREATE_CAMPAIGN_VIEW_CALENDAR_INPUT_FIELD"),

	/** The create campaign view calendar close button. */
	CREATE_CAMPAIGN_VIEW_CALENDAR_CLOSE_BUTTON(
			By.xpath("//div[@class='ccea-datePicker']//button[@class='react-datepicker__close-icon']"),
			"CREATE_CAMPAIGN_VIEW_CALENDAR_CLOSE_BUTTON"),

	/** The create campaign view created popup. */
	CREATE_CAMPAIGN_VIEW_CREATED_POPUP(By.xpath("//span[text()='Campaign added successfully!']"),
			"CREATE_CAMPAIGN_VIEW_CREATED_POPUP"),

	/** The create campaign view close icon. */
	CREATE_CAMPAIGN_VIEW_CLOSE_ICON(By.xpath("//img[@class='mod__close--img']"), "CREATE_CAMPAIGN_VIEW_CLOSE_ICON"),

	/** The schedule and start campaign. */
	// Right Side Section Buttons.
	SCHEDULE_AND_START_CAMPAIGN(By.xpath("//button//span[text()='Schedule and Start']"), "SCHEDULE_AND_START_CAMPAIGN"),

	/** The delete campaign. */
	DELETE_CAMPAIGN(By.xpath("//span[text()='Delete Campaign']//parent::button"), "DELETE_CAMPAIGN"),

	/** The delete campaign conformation page. */
	DELETE_CAMPAIGN_CONFORMATION_PAGE(
			By.xpath("//div[contains(text(),'Are you sure you want to delete this campaign?')]"),
			"DELETE_CAMPAIGN_CONFORMATION_PAGE"),

	/** The delete campaign conformation delete button. */
	DELETE_CAMPAIGN_CONFORMATION_DELETE_BUTTON(By.xpath("//button[text()='Delete']"), "DELETE_CAMPAIGN"),

	/** The delete campaign conformation cancel button. */
	DELETE_CAMPAIGN_CONFORMATION_CANCEL_BUTTON(By.xpath("//button[text()='Cancel']"), "DELETE_CAMPAIGN"),

	/** The campaign expanded view deletted popup. */
	CAMPAIGN_EXPANDED_VIEW_DELETTED_POPUP(By.xpath("//span[text()='Campaign deleted successfully!']"),
			"CAMPAIGN_EXPANDED_VIEW_DELETTED_POPUP"),

	/** The schedule campaign view. */
	// Schedule Capaign
	SCHEDULE_CAMPAIGN_VIEW(By.xpath("//h3[contains(text(),'Start Campaign')]//parent::form"), "SCHEDULE_CAMPAIGN_VIEW"),

	/** The schedule campaign view close option. */
	SCHEDULE_CAMPAIGN_VIEW_CLOSE_OPTION(By.xpath("//h3[contains(text(),'Start Campaign')]//parent::form"),
			"SCHEDULE_CAMPAIGN_VIEW_CLOSE_OPTION"),

	/** The schedule campaign view by campaign name. */
	SCHEDULE_CAMPAIGN_VIEW_BY_CAMPAIGN_NAME("//h3[contains(text(),'%s')]//parent::form",
			"SCHEDULE_CAMPAIGN_VIEW_BY_CAMPAIGN_NAME"),

	/** The schedule campaign view set end date button. */
	SCHEDULE_CAMPAIGN_VIEW_SET_END_DATE_BUTTON(By.xpath("//button//span[text()='Schedule and Start']"),
			"SCHEDULE_CAMPAIGN_VIEW_SET_END_DATE"),

	/** The schedule campaign view set ongoing button. */
	SCHEDULE_CAMPAIGN_VIEW_SET_ONGOING_BUTTON(By.xpath("//button//span[text()='Schedule and Start']"),
			"SCHEDULE_CAMPAIGN_VIEW_SET_END_DATE"),

	/** The schedule campaign view calendar button. */
	SCHEDULE_CAMPAIGN_VIEW_CALENDAR_BUTTON(By.xpath("//div[@class='wdt-item da-date']//input[@name='end_date']"),
			"CREATE_CAMPAIGN_VIEW_CALENDAR_BUTTON"),

	/** The schedule campaign view calendar next month navigation. */
	SCHEDULE_CAMPAIGN_VIEW_CALENDAR_NEXT_MONTH_NAVIGATION(
			By.xpath("//button[contains(@class,'react-datepicker__navigation--next')]"),
			"CREATE_CAMPAIGN_VIEW_CALENDAR_NEXT_MONTH_NAVIGATION"),

	/** The schedule campaign view calendar previous month navigation. */
	SCHEDULE_CAMPAIGN_VIEW_CALENDAR_PREVIOUS_MONTH_NAVIGATION(
			By.xpath("//button[contains(@class,'react-datepicker__navigation--previous')]"),
			"CREATE_CAMPAIGN_VIEW_CALENDAR_PREVIOUS_MONTH_NAVIGATION"),

	/** The schedule campaign view calendar select day button. */
	SCHEDULE_CAMPAIGN_VIEW_CALENDAR_SELECT_DAY_BUTTON(
			"//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]",
			"CREATE_CAMPAIGN_VIEW_CALENDAR_SELECT_DAY_BUTTON"),

	/** The schedule campaign view calendar last enable day. */
	SCHEDULE_CAMPAIGN_VIEW_CALENDAR_LAST_ENABLE_DAY(
			By.xpath("//div[contains(@class,'week')][last()]//div[not(contains(@class,'disabled'))][last()]"),
			"SCHEDULE_CAMPAIGN_VIEW_CALENDAR_LAST_ENABLE_DAY"),

	/** The schedule campaign view calendar input field. */
	SCHEDULE_CAMPAIGN_VIEW_CALENDAR_INPUT_FIELD(
			By.xpath("//div[@class='ccea-datePicker']//div[@class='react-datepicker__input-container']//input"),
			"SCHEDULE_CAMPAIGN_VIEW_CALENDAR_INPUT_FIELD"),

	/** The schedule campaign view calendar close button. */
	SCHEDULE_CAMPAIGN_VIEW_CALENDAR_CLOSE_BUTTON(By.xpath("//div[@class='mod__close--icon']//img[@alt='close']"),
			"SCHEDULE_CAMPAIGN_VIEW_CALENDAR_CLOSE_BUTTON"),
	
	SCHEDULE_CAMPAIGN_VIEW_ALL_LOCATIONS(By.xpath("//div[@class='form-check']//label[text()='All Locations']"),
			"SCHEDULE_CAMPAIGN_VIEW_ALL_LOCATIONS"),
	
	SCHEDULE_CAMPAIGN_VIEW_CORPORATE_ONLY(By.xpath("//div[@class='form-check']//label[text()='Corporate Only']"),
			"SCHEDULE_CAMPAIGN_VIEW_CORPORATE_ONLY"),
	
	SCHEDULE_CAMPAIGN_VIEW_SPECIFIC_LOCATIONS(By.xpath("//div[@class='form-check']//label[text()='Specific Locations/Lists']"),
			"SCHEDULE_CAMPAIGN_VIEW_SPECIFIC_LOCATIONS"),
	
	SCHEDULE_CAMPAIGN_VIEW_SELECT_LOCATIONS_BUTTON(By.xpath("//div[contains(@id,'specific_locations_or_lists')]//button[@class='h-btn css-1e2j28g' and @type='button']//span[text()='Select Locations']"),"SCHEDULE_CAMPAIGN_VIEW_SELECT_LOCATIONS_BUTTON"),
	
	SCHEDULE_CAMPAIGN_VIEW_SEARCH_LOCATIONS(By.xpath("//div[@class='rs-drp__input-container css-ackcql']//input[@class='rs-drp__input']"),
			"SCHEDULE_CAMPAIGN_VIEW_SEARCH_LOCATIONS"),
	
	SCHEDULE_CAMPAIGN_VIEW_SEARCH_LOCATIONS_DROPDOWN(By.xpath("(//span[text()='Select Locations'])[3]"),
			"SCHEDULE_CAMPAIGN_VIEW_SEARCH_LOCATIONS_DROPDOWN"),
	
	SCHEDULE_CAMPAIGN_VIEW_SEARCH_RESULTS("//div[contains(@class,'rs-drp__option') and contains(text(),'%s')]",
			"SCHEDULE_CAMPAIGN_VIEW_SEARCH_RESULT"),

	/** The schedule day hour input. */
	SCHEDULE_DAY_HOUR_INPUT(By.xpath(
			"//div[@class='wf-schedule']//div[@class='wfs-row whs-open']//label[@for='campaign-ws-hour']//input"),
			"Schedule day hour input"),

	/** The schedule day minute input. */
	SCHEDULE_DAY_MINUTE_INPUT(By.xpath(
			"//div[@class='wf-schedule']//div[@class='wfs-row whs-open']//label[@for='campaign-ws-minute']//input"),
			"Schedule day minute input"),

	/** The schedule campaign am session. */
	SCHEDULE_CAMPAIGN_AM_SESSION(By.xpath("//span[text()='AM']"), "Schedule Campaign AM Session"),

	/** The schedule campaign pm session. */
	SCHEDULE_CAMPAIGN_PM_SESSION(By.xpath("//span[text()='PM']"), "Schedule Campaign PM Session"),

	/** The schedule day row cancel button. */
	SCHEDULE_DAY_ROW_CANCEL_BUTTON(
			By.xpath("//div[@class='wf-schedule']//div[@class='wfs-row whs-open']//button//span[text()='Cancel']"),
			"Schedule day row cancel button"),

	/** The schedule campaign view scheduled week time. */
	SCHEDULE_CAMPAIGN_VIEW_SCHEDULED_WEEK_TIME(By.xpath("//div[@class='tg-item']"),
			"SCHEDULE_CAMPAIGN_VIEW_SCHEDULED_WEEK_TIME"),

	/** The schedule day row add button. */
	SCHEDULE_DAY_ROW_ADD_BUTTON(
			By.xpath("//div[@class='wf-schedule']//div[@class='wfs-row whs-open']//button//span[text()='Add']"),
			"Schedule day row add button"),

	/** The schedule campaign view calendar header month year. */
	SCHEDULE_CAMPAIGN_VIEW_CALENDAR_HEADER_MONTH_YEAR(
			By.xpath("//div[@class='datime-picker']//div[contains(@class,'react-datepicker__current-month')]"),
			"Calendar Header Month and Year"),

	/** The schedule campaign view calendar day of the month. */
	SCHEDULE_CAMPAIGN_VIEW_CALENDAR_DAY_OF_THE_MONTH(
			"//div[contains(@class,'react-datepicker__day react-datepicker__day--%s')]", "Calendar Day Of The Month"),

	//div[@class='wf-schedule']//span[text()='%s']
	/** The schedule campaign view calendar week days. */
	SCHEDULE_CAMPAIGN_VIEW_CALENDAR_WEEK_DAYS("//span[text()='%s']//parent::div//parent::div[@class='wfs-row']//div[@class='af-add-btn']//img[@alt='Add']",
			"SCHEDULE_CAMPAIGN_VIEW_CALENDAR_WEEK_DAYS"),

	/** The schedule campaign view calendar week days add plus. */
	SCHEDULE_CAMPAIGN_VIEW_CALENDAR_WEEK_DAYS_ADD_PLUS(
			"//span[text()='%s']//parent::div//following-sibling::div//button//div[@class='af-add-btn']",
			"SCHEDULE_CAMPAIGN_VIEW_CALENDAR_WEEK_DAYS"),

	/** The schedule campain view number of post count. */
	SCHEDULE_CAMPAIN_VIEW_NUMBER_OF_POST_COUNT(By.xpath("//h3[text()='Total number of campaign post per week:']//span"),
			"the Number of post Coun"),

	/** The schedule campain view start campaign button. */
	SCHEDULE_CAMPAIN_VIEW_START_CAMPAIGN_BUTTON(By.xpath("//span[text()='Start Campaign']//parent::button"),
			"SCHEDULE_CAMPAIN_VIEW_START_CAMPAIGN_BUTTON"),

	/** The schedule campain view start campaign success popup. */
	SCHEDULE_CAMPAIN_VIEW_START_CAMPAIGN_SUCCESS_POPUP(By.xpath("//span[text()='Done!']"),
			"SCHEDULE_CAMPAIN_VIEW_START_CAMPAIGN_SUCCESS_POPUP"),

	/** The campaign expanded view. */
	CAMPAIGN_EXPANDED_VIEW(By.xpath(
			"//section[contains(@class,'camp__detailed--view')]//div[@class='coupon-content ']"),
			"CAMPAIGN_EXPANDED_VIEW"),

	CAMPAIGN_EXPAND_VIEW_ADD_POST_COUNT(
			By.xpath("//div[@class='coupon-content ']//div[@class='coupon-details']//span[@class='ccd-count']//span"),
			"CAMPAIGN_EXPAND_VIEW_ADD_POST_COUNT"),
	
	CAMPAIGN_POST_COUNT(
			By.xpath("//div[@class='coupon-content ']//div[@class='coupon-details']//span[@class='ccd-count']//span"),
			"CAMPAIGN_POST_COUNT"),
	
	CAMPAIGN_BY_POST_COUNT("//div[@class='coupon-content ']//div[@class='coupon-details']//span[@class='ccd-count']//span[text()='%s']",
			"CAMPAIGN_BY_POST_COUNT"),
	
	CAMPAIGN_WITH_POSTS(
			By.xpath("//div[@class='coupon-details']//p//ancestor::div[contains(@class,'coupon-card')]"),
			"CAMPAIGN_WITH_POSTS"),

	/** The campaign expanded view by campaign name. */
	CAMPAIGN_EXPANDED_VIEW_BY_CAMPAIGN_NAME(
			"//section[contains(@class,'camp__detailed--view')]//div[@class='coupon__details--head']//span[contains(text(),'%s')]",
			"CAMPAIGN_EXPANDED_VIEW_BY_CAMPAIGN_NAME"),
	
	CAMPAIGN_EXPANDED_VIEW_CAMPAIGN_NAME(By.xpath(
			"//section[contains(@class,'camp__detailed--view')]//div[@class='coupon__details--head']//span[@class='ccd-head']"),
			"CAMPAIGN_EXPANDED_VIEW_CAMPAIGN_NAME"),
	
	CAMPAIGN_EXPANDED_VIEW_CREATION_DATE(By.xpath("//section[contains(@class,'coupon-expandview')]//div[@class='coupon-details']//div[@class='camp-date']"),"CAMPAIGN_EXPANDED_VIEW_CREATION_DATE"),

	CAMPAIGN_EXPANDED_VIEW_CAMPAIGN_DESCRIPTION(By.xpath(
			"//section[contains(@class,'camp__detailed--view')]//div[@class='coupon-content ']//p"),
			"CAMPAIGN_EXPANDED_VIEW_CAMPAIGN_DESCRIPTION"),
	
	CAPAIGN_EXPANDED_VIEW_AVAILABILITY(By.xpath(
			"//section[contains(@class,'camp__detailed--view')]//div[@class='coupan-card-right']//span[text()='Availability']//following-sibling::span"),
			"CAPAIGN_EXPANDED_VIEW_AVAILABILITY"),
	
	CAMPAIGN_EXPANDED_VIEW_PROFILE_IMAGE_BY_NAME("//span[text()='%s']//parent::h5//parent::div//preceding-sibling::div//img[@alt='Post Image']","CAMPAIGN_EXPANDED_VIEW_PROFILE_IMAGE_BY_NAME"),

	/** The campaign expanded view without posts. */
	CAMPAIGN_EXPANDED_VIEW_WITHOUT_POSTS(By.xpath("//section[contains(@class,'coupon-expandview')]"),
			"CAMPAIGN_EXPANDED_VIEW_WITHOUT_POSTS"),

	/** The campaign expanded view no data to show. */
	CAMPAIGN_EXPANDED_VIEW_NO_DATA_TO_SHOW(
			By.xpath("//div[contains(@class,'addpost-section')]//span[text()='No data to show']"),
			"CAMPAIGN_EXPANDED_VIEW_NO_DATA_TO_SHOW"),
	
	CAMPAIGN_EXPANDED_VIEW_SCHEDULE_STATUS_COMPLETED_NO_DATA_TO_SHOW(
			By.xpath("//div[contains(@class,'campaign-schedule-table')]//tbody//tr//td[text()='No Data Found.']"),
			"CAMPAIGN_EXPANDED_VIEW_SCHEDULE_STATUS_COMPLETED_NO_DATA_TO_SHOW"),

	/** The campaign expanded view post items. */
	CAMPAIGN_EXPANDED_VIEW_POST_ITEMS(
			By.xpath("//div[contains(@class,'pls post-list')]//div[contains(@class,'m-item')]"),
			"CAMPAIGN_EXPANDED_VIEW_POST_ITEMS"),

	/** The campaign expanded view edit button. */
	CAMPAIGN_EXPANDED_VIEW_EDIT_BUTTON(By.xpath("//div[@class='cpnItem']//button[@class='btn btn-primary']//span[text()='Edit']"),
			"CAMPAIGN_EXPANDED_VIEW_EDIT_BUTTON"),
	
	CAMPAIGN_EXPANDED_VIEW_PROFILE_IMAGE(By.xpath("//div[@class='coupon-content ']//img[@alt='Post Image']"),"CAMPAIGN_EXPANDED_VIEW_PROFILE_IMAGE"),

	/** The schedule status all filter. */
	SCHEDULE_STATUS_ALL_FILTER(By.xpath("//h3[text()='Schedule Status']//parent::div//label//input[@value='all']"),
			"SOURCE_ALL_FILTER"),

	/** The schedule status all filter active. */
	SCHEDULE_STATUS_ALL_FILTER_ACTIVE(
			By.xpath("//h3[text()='Schedule Status']//parent::div//label[@class='active']//input[@value='all']"),
			"SOURCE_ALL_FILTER"),

	/** The schedule status ongoing filter. */
	SCHEDULE_STATUS_ONGOING_FILTER(By.xpath("//h3[text()='Schedule Status']//parent::div//input[@value='ongoing']"),
			"SCHEDULE_STATUS_ONGOING_FILTER"),

	/** The schedule status ongoing filter active. */
	SCHEDULE_STATUS_ONGOING_FILTER_ACTIVE(
			By.xpath("//h3[text()='Schedule Status']//parent::div//label[@class='active']//input[@value='ongoing']"),
			"SOURCE_ALL_FILTER_ACTIVE"),

	/** The schedule status ongoing filter contents. */
	SCHEDULE_STATUS_ONGOING_FILTER_CONTENTS(
			By.xpath("//div[contains(@class,'campaign-schedule-table')]//tbody//tr//td[3]//span[text()='Ongoing']"),
			"SCHEDULE_STATUS_COMPLETED_FILTER_ACTIVE"),

	/** The schedule status completed filter. */
	SCHEDULE_STATUS_COMPLETED_FILTER(
			By.xpath("//h3[text()='Schedule Status']//parent::div//label//input[@value='completed']"),
			"SCHEDULE_STATUS_COMPLETED_FILTER"),

	/** The schedule status completed filter active. */
	SCHEDULE_STATUS_COMPLETED_FILTER_ACTIVE(
			By.xpath("//h3[text()='Schedule Status']//parent::div//label[@class='active']//input[@value='completed']"),
			"SCHEDULE_STATUS_COMPLETED_FILTER_ACTIVE"),

	/** The schedule status completed filter contents. */
	SCHEDULE_STATUS_COMPLETED_FILTER_CONTENTS(
			By.xpath("//div[contains(@class,'campaign-schedule-table')]//tbody//tr//td//div[text()='Completed']"),
			"SCHEDULE_STATUS_COMPLETED_FILTER_CONTENTS"),

	/** The campaign expanded view create post button. */
	// Create Post enums.
	CAMPAIGN_EXPANDED_VIEW_CREATE_POST_BUTTON(
			By.xpath("//span[text()='Create Post']//parent::button[contains(@class,'cp-blue-btn')]"),
			"CAMPAIGN_EXPANDED_VIEW_CREATE_POST_BUTTON"),

	/** The campaign expanded view create post page. */
	CAMPAIGN_EXPANDED_VIEW_CREATE_POST_PAGE(
			By.xpath("//div[contains(@class,'createpost-wrp-new-section')]//div[@class='addpost-section-main-wrp']"),
			"CAMPAIGN_EXPANDED_VIEW_CREATE_POST_PAGE"),

	CAMPAIGN_EXPANDED_VIEW_CREATE_POST_DONE_BUTTON(
			By.xpath("//div[@class='apch-right']//button[contains(@class,'gnrc-btn blue-gnr')]//span[text()='Done']"),
			"Camapaign Expand View Creat Post Done button"),

	/** The create post page post description text area. */
	CREATE_POST_PAGE_POST_DESCRIPTION_TEXT_AREA(
			By.xpath("//div[@class='DraftEditor-editorContainer']//span//parent::div//parent::div"),
			"Post Description textarea"),

	/** The campaign expanded view done button. */
	CAMPAIGN_EXPANDED_VIEW_DONE_BUTTON(
			By.xpath("//span[text()='Create Post']//parent::button[contains(@class,'cp-blue-btn')]"),
			"CAMPAIGN_EXPANDED_VIEW_DONE_BUTTON"),

	/** The campaign expanded view close button. */
	CAMPAIGN_EXPANDED_VIEW_CLOSE_BUTTON(
			By.xpath("//section[contains(@class,'camp__detailed--view')]//div//img[@alt='Close']"),
			"CAMPAIGN_EXPANDED_VIEW_CLOSE_BUTTON"),

	/** The post assigned to campaign popup. */
	POST_ASSIGNED_TO_CAMPAIGN_POPUP(By.xpath("//span[text()='Post assigned to campaign']"),
			"POST_ASSIGNED_TO_CAMPAIGN_POPUP"),

	/** The campaign expanded view create post page close option. */
	CAMPAIGN_EXPANDED_VIEW_CREATE_POST_PAGE_CLOSE_OPTION(By.xpath("//div[contains(@class,'close--icon')]//img[@alt='close']"),
			"CAMPAIGN_EXPANDED_VIEW_CREATE_POST_PAGE_CLOSE_OPTION"),

	/** The campaign expanded view post by text. */
	CAMPAIGN_EXPANDED_VIEW_POST_BY_TEXT(
			"//div[contains(@class,'m-item')]//div[@class='mi-front']//div[@class='msg-wrapper']//p[contains(text(),'%s')]",
			"CAMPAIGN_EXPANDED_VIEW_POST_BY_TEXT"),
	
	CAMPAIGN_EXPANDED_VIEW_REARRANGE_POST_IN_SEQUENCE_TEXT(By.xpath("//span[text()='Rearrange your posts in a sequence you want to publish']"),
			"CAMPAIGN_EXPANDED_VIEW_REARRANGE_POST_IN_SEQUENCE_TEXT"),

	/** The campaign expanded view add post button. */
	CAMPAIGN_EXPANDED_VIEW_ADD_POST_BUTTON(By.xpath("//span[text()='Add Post']//parent::button"),
			"CAMPAIGN_EXPANDED_VIEW_ADD_POST_BUTTON"),

	CAMPAIGN_EXPAND_VIEW_REMOVE_POST_BUTTON(By.xpath(
			"//div[@class='scl-controls cmp-crt-post']//button[@class='gnrc-btn blue-gnr remove-btn']//span[text()='Remove Post']"),
			"Campaign Expand View Remove Post Button"),

	CAMPAIGN_EXPAND_VIEW_REMOVE_POST_ALERT(By.xpath(
			"//div[contains(@class,'modal-dialog-centered')]//div[@class='modal-content']//div[@class='modal-body']"),
			"Camapaign Expand view Remove Post Alert"),

	CAMPAIGN_EXPAND_VIEW_REMOVE_POST_CANCEL_BUTTON(
			By.xpath("//div[@class='modal-btn-grp-wraps']//button[text()='Cancel']"),
			"CAMPAIGN_EXPAND_VIEW_POST_REMOVE_CANCEL_BUTTON"),

	CAMPAIGN_EXPAND_VIEW_REMOVE_POST_REMOVE_BUTTON(
			By.xpath("//div[@class='modal-btn-grp-wraps']//button[text()='Remove']"),
			"CAMPAIGN_EXPAND_VIEW_REMOVE_POST_REMOVE_BUTTON"),

	CAMAPAIGN_EXPAND_VIEW_REMOVE_POST_POPUP(
			By.xpath("//span[@class='success-mess-txt' and text()='Post have been removed from this campaign']"),
			"CAMAPAIGN EXPAND VIEW REMOVE POST POPUP"),

	ACTIVE_CAMPAIGNS_TILE_GREEN_IMAGE_BY_NAME(
			"//div[contains(@class,'coupon-card')]//div[contains(@class,'campaign-active')]//span[text()='ACTIVE']//parent::div//following-sibling::div//h5//span[contains(text(),'%s')]",
			"Active Campaigns Tile Green By Campaign Name"),

	CAMAPAIGN_EXPANDED_VIEW_USES_COUNT(
			By.xpath("//div[@class='coupan-card-right']//div[@class='ci-usage']//span[@class='ci-value']"),
			"Uses Count"),

	CAMAPAIGN_EXPANDED_VIEW_TABLE_STARTED_BY_USER(
			"//th//span[text()='Started By']//ancestor::table//tbody//div//span[@class='adl-top' and contains(text(),'%s')]",
			"Campaign Expand View Table Started By User"),
	
	CAMAPAIGN_EXPANDED_VIEW_TABLE_STARTED_BY_USER_NAME(By.xpath(
			"//th//span[text()='Started By']//ancestor::table//tbody//div//span[@class='adl-top']"),
			"CAMAPAIGN_EXPANDED_VIEW_TABLE_STARTED_BY_USER_NAME"),

	CAMAPAIGN_EXPANDED_VIEW_TABLE_STARTED_BY_USER_START_DATE(By.xpath(
			"//th//span[text()='Started By']//ancestor::table//tbody//div//span[@class='adl-base']"),
			"Campaign Expand View Table Started By User Starts Date"),

	CAMPAIGN_EXPANDED_VIEW_TABLE_ENDS_ON_DATE(
			"//span[text()='Ends On']//parent::div//parent::td//span[@class='ad-cnt' and contains(text(),'%s')]",
			"Campaign Expand View Table Ends On"),
	
	CAMPAIGN_EXPANDED_VIEW_TABLE_ENDS_ON_DATE_VALUE(By.xpath(
			"//span[text()='Ends On']//parent::div//parent::td//span[@class='ad-cnt']"),
			"CAMPAIGN_EXPANDED_VIEW_TABLE_ENDS_ON_DATE_VALUE"),

	CAMPAIGN_EXPANDED_VIEW_TABLE_NUMBER_OF_POST_PER_WEEk(
			"//span[text()='Number of post per week']//parent::div//parent::td//span[@class='ad-cnt' and contains(text(),'%s')]",
			"CAMPAIGN_EXPANDED_VIEW_TABLE_NUMBER_OF_POST_PER_WEEk"),
	
	CAMPAIGN_EXPANDED_VIEW_TABLE_NUMBER_OF_POST_PER_WEEK_VALUE(By.xpath(
			"//span[text()='Number of post per week']//parent::div//parent::td//span[@class='ad-cnt']"),
			"CAMPAIGN_EXPANDED_VIEW_TABLE_NUMBER_OF_POST_PER_WEEK_VALUE"),

	CAMPAIGN_EXPANDED_VIEW_TABLE_STOP_ACTION(By.xpath(
			"//span[text()='Action']//parent::div//parent::td//div[@class='cpnItem']//button[@class='gnrc-btn red-gnr ac-btn']//span[text()='Stop']"),
			"Campaign Expand View Table Action Stop"),

	CAMPAIGN_EXAPAND_VIEW_TABLE_VIEW_BUTTON(By.xpath("//div[@class='campaign-schedule-table']//table//td//div[@class='cpnItem']//button[contains(@class,'btn btn-primary')]//span[text()='View']"),"CAMPAIGN_EXAPAND_VIEW_TABLE_VIEW_BUTTON"),
	
	CAMPAIGN_EXAPAND_VIEW_TABLE_EDIT_BUTTON(By.xpath("//div[@class='cpnItem']//button[contains(@class,'gnrc-btn blue-lined')]//span[text()='Edit']"),"CAMPAIGN_EXAPAND_VIEW_TABLE_EDIT_BUTTON"),
	
	
	CAMPAIGN_EXPAND_VIEW_TABLE_ACTIVE_USER(
			"//span[@class='adsi-sign active']//parent::td//following-sibling::td//span[@class='adl-top' and text()='%s']",
			"CAMPAIGN_EXPAND_VIEW_TABLE_ACTIVE_USER"),

	/** The previous month. */
	PREVIOUS_MONTH_PICKER(
			By.xpath("//div[@class='react-datepicker']//button[contains(@class,'datepicker__navigation--previous')]"),
			"Previous month."),

	/** The next month. */
	NEXT_MONTH_PICKER(
			By.xpath("//div[@class='react-datepicker']//button[contains(@class,'datepicker__navigation--next')]"),
			"Next month."),

	/** The campaign expanded view add post page. */
	CAMPAIGN_EXPANDED_VIEW_ADD_POST_PAGE(
			By.xpath("//div[contains(@class,'addpost-section')]//div[contains(@id,'post-list')]"),
			"CAMPAIGN_EXPANDED_VIEW_ADD_POST_PAGE"),

	ADD_POST_PAGE_POST_DESCRIPTION(By.xpath("//div[@class='mi-hover postlist-view-tooltipwrp post-new-list--wrp']//ancestor::div[@class='m-item mi-compact']//following::div[@class='msg-wrapper']//p[text()]"),"Ad Post Post Description"),
	
	/** The add post page specific date range button. */
	ADD_POST_PAGE_SPECIFIC_DATE_RANGE_BUTTON(By.xpath("//span[text()='Specific date range']//parent::label//input"),
			"ADD_POST_PAGE_SPECIFIC_DATE_RANGE_BUTTON"),

	/** The add post page calendar select day button. */
	ADD_POST_PAGE_CALENDAR_SELECT_DAY_BUTTON(
			"//div[contains(@class,'react-datepicker__day react-datepicker__day') and text()='%s']",
			"EDIT_CAMPAIGN_PAGE_CALENDAR_DAY_BUTTON"),

	/** The add post page from date button. */
	ADD_POST_PAGE_FROM_DATE_BUTTON(By.xpath(
			"//div[contains(@class, 'dp-from')]//input"),
			"ADD_POST_PAGE_FROM_DATE_BUTTON"),

	/** The add post page from date input field. */
	ADD_POST_PAGE_FROM_DATE_INPUT_FIELD(By.xpath("(//div[@class='react-datepicker__input-container'])[1]//input"),
			"ADD_POST_PAGE_FROM_DATE_INPUT_FIELD"),

	/** The add post page to date button. */
	ADD_POST_PAGE_TO_DATE_BUTTON(
			By.xpath(
					"//div[contains(@class, 'dp-to')]//input"),
			"ADD_POST_PAGE_TO_DATE_BUTTON"),

	/** The add post page to date input field. */
	ADD_POST_PAGE_TO_DATE_INPUT_FIELD(By.xpath("(//div[@class='react-datepicker__input-container'])[2]//input"),
			"ADD_POST_PAGE_TO_DATE_INPUT_FIELD"),
	
	ADD_POST_PAGE_VIEW(By.xpath("//div[contains(@id,'post-list')]//div[contains(@class,'m-item')]"),
			"ADD_POST_PAGE_VIEW"),
	
	ADD_POST_PAGE_POST_DATE(By.xpath(
			"//div[@class='addpost-section-main-wrp']//div[contains(@id,'post-list')]//div[contains(@class,'m-item')]//span[@class='sub-dtls']"),
			"ADD_POST_PAGE_POST_DATE"),

	/** The add post page search tag input field. */
	ADD_POST_PAGE_SEARCH_TAG_INPUT_FIELD(By.xpath("//input[@placeholder='Search tags']"),
			"ADD_POST_PAGE_SEARCH_TAG_INPUT_FIELD"),

	/** The add post page search tag suggessions. */
	ADD_POST_PAGE_SEARCH_TAG_SUGGESSIONS(By.xpath("//span[@class='fav-tags']"),
			"ADD_POST_PAGE_SEARCH_TAG_SUGGESSIONS"),

	/** The add post page favourite tag by text. */
	ADD_POST_PAGE_FAVOURITE_TAG_BY_TEXT("//span[@class='fav-tags' and text()='%s']",
			"ADD_POST_PAGE_FAVOURITE_TAG_BY_TEXT"),
	
	ADD_POST_PAGE_POST_BY_POSTNAME(
			"//div[@class='msg-wrapper']//p[contains(text(),'%s')]//ancestor::div//div[contains(@id,'post-list')]//div[contains(@class,'m-item')]",
			"ADD_POST_PAGE_POST_BY_POSTNAME"),	
	
	ADD_POST_PAGE_SEARCHED_TAG("//span[contains(@class,'selected-tag-name') and text()='%s']",
			"ADD_POST_PAGE_SEARCHED_TAG"),

	/** The add post page favourite tag by text active. */
	ADD_POST_PAGE_FAVOURITE_TAG_BY_TEXT_ACTIVE("//span[@class='fav-tags active' and text()='%s']",
			"ADD_POST_PAGE_FAVOURITE_TAG_BY_TEXT_ACTIVE"),

	/** The add post page posts. */
	ADD_POST_PAGE_POSTS(By.xpath("//div[contains(@class,'addpost-section')]//div[contains(@id,'post-list')]"),
			"ADD_POST_PAGE_POSTS"),

	/** The add post page image posts. */
	ADD_POST_PAGE_IMAGE_POSTS(By.xpath("//div[contains(@class,'m-item')]//div[@class='m-ast']//img[@alt='Post Image']"),
			"ADD_POST_PAGE_IMAGE_POSTS"),
	
	ADD_POST_PAGE_CALENDAR_CURRENT_DAY(By.xpath("//div[contains(@class,'react-datepicker__day--today')]"),
			"ADD_POST_PAGE_CALENDAR_CURRENT_DAY"),

	CAMPAIGN_EXPANDED_VIEW_POST_ITEM_NAMES(
			By.xpath("//div[contains(@class,'pls post-list')]//div[contains(@class,'m-item')]//p"),
			"CAMPAIGN_EXPANDED_VIEW_POST_ITEM_NAMES"),

	CAMPAIGN_EXPANDED_VIEW_POST_ITEM_ONE(
			By.xpath("(//div[contains(@class,'pls post-list')]//div[contains(@class,'m-item')])[1]//p"),
			"CAMPAIGN_EXPANDED_VIEW_POST_ITEM_ONE"),
	
	CAMPAIGN_EXPANDED_VIEW_POST_ITEM_EXPAND_ICON(
			By.xpath("(//div[contains(@class,'pls post-list')]//div[contains(@class,'m-item')])[1]//img[contains(@src,'expand')]"),
			"CAMPAIGN_EXPANDED_VIEW_POST_ITEM_EXPAND_ICON"),

	CAMPAIGN_EXPANDED_VIEW_POST_ITEM_TWO(
			By.xpath("(//div[contains(@class,'pls post-list')]//div[contains(@class,'m-item')])[2]//p"),
			"CAMPAIGN_EXPANDED_VIEW_POST_ITEM_TWO"),
	
	CAMPAIGN_EXPANDED_VIEW_POST_BY_POSITION("(//div[contains(@class,'pls post-list')]//div[contains(@class,'m-item')])[%s]",
			"CAMPAIGN_EXPANDED_VIEW_POST_BY_POSITION"),

	CAMPAIGN_EXPANDED_VIEW_POST_ITEM_NAME_BY_INDEX(
			"(//div[contains(@class,'pls post-list')]//div[contains(@class,'m-item')])[%s]//p",
			"CAMPAIGN_EXPANDED_VIEW_POST_ITEM_NAME_BY_INDEX"),

	/** The add post page link posts. */
	ADD_POST_PAGE_LINK_POSTS(By.xpath("//div[contains(@class,'m-item')]//div//p[contains(@title,'a href')]"),
			"ADD_POST_PAGE_LINK_POSTS"),

	/** The add post page image posts text. */
	ADD_POST_PAGE_IMAGE_POSTS_TEXT(By.xpath(
			"//div[contains(@class,'m-item')]//div[@class='m-ast']//img[@alt='Post Image']//parent::div//preceding-sibling::div//p"),
			"ADD_POST_PAGE_IMAGE_POSTS_TEXT"),

	/** The add post page image posts text by position. */
	ADD_POST_PAGE_IMAGE_POSTS_TEXT_BY_POSITION(
			"(//div[contains(@class,'m-item')]//div[@class='m-ast']//img[@alt='Post Image'])[%s]//parent::div//preceding-sibling::div//p",
			"ADD_POST_PAGE_IMAGE_POSTS_TEXT_BY_POSITION"),

	/** The add post page search field. */
	ADD_POST_PAGE_SEARCH_FIELD(By.xpath("//div[@class='react-tags__search-input']//input[@placeholder='Search text']"),
			"ADD_POST_PAGE_SEARCH_FIELD"),

	ADD_POST_LIST(By.xpath("//div[@class='infinite-scroll-component local-ini']//div[@class='content-post__list pls post-list__main lpx vpy-20']"),"Add Post List"),
	
	ADD_UNSELECT_POST_LIST(By.xpath(
			"//div[contains(@class,'pls post-list__main')]//div[contains(@class,'m-item mi-compact')]//button[contains(@class,'gnrc-btn white-gnr') and not(@class='gnrc-btn white-gnr ac-btn button-opacity')]"),
			"ADD_UNSELECT_POST_LIST"),

	/** The add post page post select button. */
	ADD_POST_PAGE_POST_SELECT_BUTTON(By.xpath(
			"//div[contains(@id,'post-list')]//div[contains(@class,'m-item')]//button[contains(@class,'gnrc-btn white-gnr') and not(@class='gnrc-btn white-gnr ac-btn button-opacity')]//span[text()='Select']"),
			"ADD_POST_PAGE_POST_SELECT_BUTTON"),

	/** The add post page post select button. */
	ADD_POST_PAGE_POST_SELECT_BUTTON_BY_POSTNMAE(
			"//div[@class='msg-wrapper']//p[contains(text(),'%s')]//ancestor::div//div[contains(@id,'post-list')]//div[contains(@class,'m-item')]//span[text()='Select']",
			"ADD_POST_PAGE_POST_SELECT_BUTTON"),

	/** The add post page search post field. */
	ADD_POST_PAGE_SEARCH_POST_FIELD(
			By.xpath("//div[contains(@id,'post-list')]//div[contains(@class,'m-item')]//span[text()='Selected']"),
			"ADD_POST_PAGE_POST_SELECT_BUTTON"),

	/** The add post page image post. */
	ADD_POST_PAGE_IMAGE_POST(By.xpath(
			"//div[contains(@id,'post-list')]//div[contains(@class,'m-item')]//img[@alt='Post Image']//parent::div//preceding-sibling::div//p"),
			"ADD_POST_PAGE_IMAGE_POST"),

	/** The add post page image post date. */
	ADD_POST_PAGE_IMAGE_POST_DATE(By.xpath(
			"//div[contains(@id,'post-list')]//div[contains(@class,'m-item')]//img[@alt='Post Image']//parent::div//preceding-sibling::div//span[@class='sub-dtls']"),
			"ADD_POST_PAGE_IMAGE_POST_DATE"),

	/** The add post page post selected button. */
	ADD_POST_PAGE_POST_SELECTED_BUTTON(
			By.xpath("//div[contains(@id,'post-list')]//div[contains(@class,'m-item')]//span[text()='Selected']"),
			"ADD_POST_PAGE_POST_SELECTED_BUTTON"),

	/** The add post page done button. */
	ADD_POST_PAGE_DONE_BUTTON(By.xpath("//span[text()='Done']//parent::button"), "ADD_POST_PAGE_DONE_BUTTON"),

	/** The add post page clear button. */
	ADD_POST_PAGE_CLEAR_BUTTON(By.xpath("//span[text()='Clear Filter']//parent::button"), "ADD_POST_PAGE_CLEAR_BUTTON"),

	/** The post added to campaign popup. */
	POST_ADDED_TO_CAMPAIGN_POPUP(By.xpath("//span[@class='success-mess-txt' and text()='Post added to this campaign']"),
			"POST_ADDED_TO_CAMPAIGN_POPUP"),

	/** The add post page all platform button. */
	ADD_POST_PAGE_ALL_PLATFORM_BUTTON(
			By.xpath("//div[@class='filter-item']//img[contains(@src,'all')]//parent::button"),
			"ADD_POST_PAGE_ALL_PLATFORM_BUTTON"),

	/** The add post page facebook button. */
	ADD_POST_PAGE_FACEBOOK_BUTTON(
			By.xpath("//div[@class='filter-item']//img[contains(@src,'fb-platform')]//parent::button"),
			"ADD_POST_PAGE_FACEBOOK_BUTTON"),

	/** The add post page facebook filter contents. */
	ADD_POST_PAGE_FACEBOOK_FILTER_CONTENTS(By.xpath(
			"(//div[contains(@class,'m-item')]//div[@class='mif-head']//div[@class='mifh-top']//img[contains(@src,'fb-platform')]//parent::button)[4]"),
			"ADD_POST_PAGE_FACEBOOK_FILTER_CONTENTS"),

	/** The add post page instagram button. */
	ADD_POST_PAGE_INSTAGRAM_BUTTON(
			By.xpath("//div[@class='filter-item']//img[contains(@src,'instagram')]//parent::button"),
			"ADD_POST_PAGE_INSTAGRAM_BUTTON"),

	/** The add post page instagram filter contents. */
	ADD_POST_PAGE_INSTAGRAM_FILTER_CONTENTS(By.xpath(
			"(//div[contains(@class,'m-item')]//div[@class='mif-head']//div[@class='mifh-top']//img[contains(@src,'instagram-platform')]//parent::button)[2]"),
			"ADD_POST_PAGE_INSTAGRAM_BUTTON"),

	/** The add post page twitter button. */
	ADD_POST_PAGE_TWITTER_BUTTON(By.xpath("//div[@class='filter-item']//img[contains(@src,'twitter')]//parent::button"),
			"ADD_POST_PAGE_TWITTER_BUTTON"),

	/** The add post page twitter filter contents. */
	ADD_POST_PAGE_TWITTER_FILTER_CONTENTS(By.xpath(
			"(//div[contains(@class,'m-item')]//div[@class='mif-head']//div[@class='mifh-top']//img[contains(@src,'twitter-platform')]//parent::button)[3]"),
			"ADD_POST_PAGE_TWITTER_BUTTON"),

	/** The add post page linkedin button. */
	ADD_POST_PAGE_LINKEDIN_BUTTON(
			By.xpath("//div[@class='filter-item']//img[contains(@src,'linkedin')]//parent::button"),
			"ADD_POST_PAGE_LINKEDIN_BUTTON"),

	/** The add post page linkedin filter contents. */
	ADD_POST_PAGE_LINKEDIN_FILTER_CONTENTS(By.xpath(
			"(//div[contains(@class,'m-item')]//div[@class='mif-head']//div[@class='mifh-top']//img[contains(@src,'linkedin-platform')]//parent::button)[3]"),
			"ADD_POST_PAGE_LINKEDIN_BUTTON"),

	/** The add post page usage all filter button. */
	ADD_POST_PAGE_USAGE_ALL_FILTER_BUTTON(By.xpath(
			"//h3[text()='Usage']//parent::div[@class='filter-item']//input[@name='usage-Usage' and @value='all']"),
			"ADD_POST_PAGE_USAGE_ALL_FILTER_BUTTON"),

	/** The add post page usage used filter button. */
	ADD_POST_PAGE_USAGE_USED_FILTER_BUTTON(By.xpath(
			"//h3[text()='Usage']//parent::div[@class='filter-item']//input[@name='usage-Usage' and @value='1']"),
			"ADD_POST_PAGE_USAGE_USED_FILTER_BUTTON"),
	
	ADD_POST_PAGE_USAGE_USED_FILTER_TEXT(By.xpath(
			"//h3[text()='Usage']//parent::div[@class='filter-item']//input[@name='usage-Usage' and @value='1']//parent::label//span"),
			"ADD_POST_PAGE_USAGE_USED_FILTER_TEXT"),

	/** The add post page usage unused filter button. */
	ADD_POST_PAGE_USAGE_UNUSED_FILTER_BUTTON(By.xpath(
			"//h3[text()='Usage']//parent::div[@class='filter-item']//input[@name='usage-Usage' and @value='0']"),
			"ADD_POST_PAGE_USAGE_UNUSED_FILTER_BUTTON"),
	
	ADD_POST_PAGE_USAGE_UNUSED_FILTER_TEXT(By.xpath(
			"//h3[text()='Usage']//parent::div[@class='filter-item']//input[@name='usage-Usage' and @value='0']//parent::label//span"),
			"ADD_POST_PAGE_USAGE_UNUSED_FILTER_TEXT"),

	/** The add post page post type image filter button. */
	ADD_POST_PAGE_POST_TYPE_IMAGE_FILTER_BUTTON(
			By.xpath("//h3[text()='Post Type']//parent::div[@class='filter-item']//input[@value='has_photo']"),
			"ADD_POST_PAGE_POST_TYPE_IMAGE_FILTER_BUTTON"),

	/** The add post page post type link filter button. */
	ADD_POST_PAGE_POST_TYPE_LINK_FILTER_BUTTON(
			By.xpath("//h3[text()='Post Type']//parent::div[@class='filter-item']//input[@value='has_link']"),
			"ADD_POST_PAGE_POST_TYPE_LINK_FILTER_BUTTON"),

	/** The add post page post type copy filter button. */
	ADD_POST_PAGE_POST_TYPE_COPY_FILTER_BUTTON(
			By.xpath("//h3[text()='Post Type']//parent::div[@class='filter-item']//input[@value='has_copy']"),
			"ADD_POST_PAGE_POST_TYPE_COPY_FILTER_BUTTON"),

	/** The campaign expanded view add post page close option. */
	CAMPAIGN_EXPANDED_VIEW_ADD_POST_PAGE_CLOSE_OPTION(By.xpath("//div[contains(@class,'header__close--icon')]//img[contains(@src,'close')]"),
			"CAMPAIGN_EXPANDED_VIEW_ADD_POST_PAGE_CLOSE_OPTION"),

	/** The campaign expanded view close option. */
	CAMPAIGN_EXPANDED_VIEW_CLOSE_OPTION(
			By.xpath("//section[contains(@class,'coupon-expandview')]//div[@class='coupon-alert-close']"),
			"CAMPAIGN_EXPANDED_VIEW_CLOSE_OPTION"),

	/** The campaign expanded view post sequence updated popup. */
	CAMPAIGN_EXPANDED_VIEW_POST_SEQUENCE_UPDATED_POPUP(By.xpath("//span[text()='Posts sequence updated']"),
			"CAMPAIGN_EXPANDED_VIEW_POST_SEQUENCE_UPDATED_POPUP"),

	/** The footer campaign. */
	FOOTER_CAMPAIGN(By.xpath("//div[contains(@class,'coupon-card')][last()]"), "FOOTER_CAMPAIGNS"),

	/** The create campaign view calendar month and year text. */
	// **New Enums**/
	CREATE_CAMPAIGN_VIEW_CALENDAR_MONTH_AND_YEAR_TEXT(
			"//div[@class='react-datepicker__month-container']//div[@class='react-datepicker__current-month' and contains(text(),'%s')]",
			"CREATE_CAMPAIGN_VIEW_CALENDAR_MONTH_AND_YEAR_TEXT"),

	/** The post description. */
	POST_DESCRIPTION(By.xpath("//div[contains(@class,'m-item ')]//div[@class='mi-front']//p[@title]"),
			"Post description"),

	// ***Creator***/
	/** The add new content button. */
	ADD_NEW_CONTENT_BUTTON(
			By.xpath("//div[@class='social-section-copy-wrp']//span[contains(text(),'Add New Content')]"),
			"Add Newcontent button"),

	/** The post description text area. */
	POST_DESCRIPTION_TEXT_AREA(By.xpath("//div[@class='DraftEditor-editorContainer']//span//parent::div//parent::div"),
			"Post Description textarea"),

	/** The post description field. */
	POST_DESCRIPTION_FIELD("//div[@class='DraftEditor-editorContainer']//span//span[contains(text(),'%s')]",
			"Post Text Area Field"),

	/** The add images to post button. */
	ADD_IMAGES_TO_POST_BUTTON(By.xpath("//div[@class='add-to-post']//div[@class='mic add-img']//img"),
			"Add Images to post button"),

	/** My Images tab. */
	MY_IMAGES_TAB(By.xpath("//div[@class='modal-body']//button[@id='add-tabs-tab-my_images']"), "My Images tab"),

	/** Search image in My Images tab. */
	SEARCH_IMAGE_IN_MY_IMAGES_TAB(
			By.xpath("//div[@id='add-tabs-tabpane-my_images']//div[@class='react-tags__search']//input"),
			"Search image in My Images tab"),

	/** Search result in My Images tab. */
	SEARCH_RESULT_IN_MY_IMAGES_TAB(
			"//div[@id='add-tabs-tabpane-my_images']//div[contains(@class,'m-item')]//div[@title='%s']",
			"Search result in My Images tab"),

	/** Use image button. */
	USE_IMAGE_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Use Image' and not(@disabled)]"),
			"Use Image button"),

	/** Uploaded image in CreatePost section. */
	UPLOADED_IMAGE_IN_CREATEPOST_SECTION(By.xpath(
			"//div[@class='card-bg active']//div[contains(@class,'image-roll-holder')]//div[@class='img-thumb']//img"),
			"Uploaded image in CreatePost section"),
	/** The facebook tab. */
	FACEBOOK_TAB(By.xpath("//ul[@role='tablist']//button[text()='Facebook' and contains(@class,'nav-link')]"),
			"Facebook Tab"),

	/** The facebook tab active. */
	FACEBOOK_TAB_ACTIVE(
			By.xpath("//li[@class='nav-item']//button[text()='Facebook' and contains(@class,'nav-link active')]"),
			"Facebook Tab active"),

	/** The twitter tab. */
	TWITTER_TAB(By.xpath("//ul[@role='tablist']//button[text()='Twitter' and contains(@class,'nav-link')]"),
			"Twitter Tab"),

	/** The twitter tab active. */
	TWITTER_TAB_ACTIVE(
			By.xpath("//li[@class='nav-item']//button[text()='Twitter' and contains(@class,'nav-link active')]"),
			"Twitter Tab active"),

	/** The instagram tab. */
	INSTAGRAM_TAB(By.xpath("//ul[@role='tablist']//button[text()='Instagram' and contains(@class,'nav-link')]"),
			"Instagram Tab"),

	/** The instagram tab active. */
	INSTAGRAM_TAB_ACTIVE(
			By.xpath("//li[@class='nav-item']//button[text()='Instagram' and contains(@class,'nav-link active')]"),
			"Instagram Tab active"),

	/** The linkedin tab active. */
	LINKEDIN_TAB_ACTIVE(
			By.xpath("//li[@class='nav-item']//button[text()='Linkedin' and contains(@class,'nav-link active')]"),
			"LinkedIn Tab active"),

	/** The instagram tab active. */

	/** The linkedin tab. */
	LINKEDIN_TAB(By.xpath("//ul[@role='tablist']//button[text()='Linkedin' and contains(@class,'nav-link')]"),
			"LinkedIn Tab"),

	/** The linkedin tab active. */

	GOOGLE_TAB(By.xpath("//ul[@role='tablist']//button[text()='Google' and contains(@class,'nav-link')]"),
			"Google tab"),

	/** The google tab active. */
	GOOGLE_TAB_ACTIVE(By.xpath("//nav[@role='tablist']//a[text()='Google' and contains(@class,'nav-link active')]"),
			"Google tab active"),

	/** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),
	
	;

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new content tab calendar page enum.
	 *
	 * @param byLocator   the by locator
	 * @param description the description
	 */
	private ContentTabCampaignPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new content tab calendar page enum.
	 *
	 * @param xpath       the xpath
	 * @param description the description
	 */
	private ContentTabCampaignPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}

}

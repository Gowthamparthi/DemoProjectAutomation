package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum FacebookPageWithImageEnum.
 */
public enum FacebookPageWithImageEnum {

	/** The pageload with image. */
	PAGE_LOAD(By.xpath("//div[@id='pagelet_bluebar']//u[text()='Facebook']"),
			"Page load with image"),
	
	/** The social media name. */
	SOCIAL_MEDIA_NAME(By.xpath("//div[@class='tr9rh885']//span[text()='Aximsoft Instagram']"),"Social media name"),
	
	/** The email id with image. */
	EMAIL_ID(By.xpath("//form[@id='login_form']//input[contains(@class,'login_form_input_box') and @name='email']"), "Email Id with image page"),

	/** The password with image. */
	PASSWORD(By.xpath("//form[@id='login_form']//input[contains(@class,'login_form_input_box') and @name='pass']"), "Password with image page"),

	/** The log in button with image. */
	LOG_IN_BUTTON(By.xpath("//form[@id='login_form']//input[@value='Log In']"),
			"Log In button with image page"),

	/** The home page button. */
	HOME_PAGE_BUTTON(By.xpath("//div[@role='navigation']//a[@aria-label='Home']"), "Home page button"),

	/** The home page load. */
	HOME_PAGE_LOAD(By.xpath("//div[@data-pagelet='root']//h1[text()='Home']"), "Home Page Load"),

	/** The page content. */
	PAGE_CONTENT("//div[contains(@data-pagelet,'page')]//div[text()='%s']", "Page content"),

	/** The comment button. */
	COMMENT_BUTTON("//div[text()='%s']//ancestor::div[contains(@class,'sjgh65i0')]//div[@aria-label='Leave a comment']",
			"Comment button"),

	/** The write a comment. */
	WRITE_A_COMMENT(
			"//div[text()='%s']//ancestor::div[contains(@class,'sjgh65i0')]//div[@aria-label='Write a comment']",
			"Write a comment field"),

	/** The comment count. */
	COMMENT_COUNT(
			"//div[text()='%s']//ancestor::div[contains(@class,'sjgh65i0')]//span[contains(text(),'comment')]",
			"Comment count"),
	
	/** The not now button. */
	NOT_NOW_BUTTON(By.xpath("//div//a[text()='Not Now']"),"Not now button");

	/** The by locator. */
	private By byLocator;

	/** The xpath. */
	private String xpath;

	/** The description. */
	private String description;

	/**
	 * Instantiates a new facebook page with image enum.
	 *
	 * @param bylocator   the bylocator
	 * @param description the description
	 */
	private FacebookPageWithImageEnum(By bylocator, String description) {
		this.byLocator = bylocator;
		this.description = description;
	}

	/**
	 * Instantiates a new facebook page with image enum.
	 *
	 * @param xpath       the xpath
	 * @param description the description
	 */
	private FacebookPageWithImageEnum(String xpath, String description) {
		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}
}

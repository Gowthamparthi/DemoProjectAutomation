package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum NewRallioSignInPageEnum.
 */
public enum NewRallioSignInPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//img[contains(@src,'rallio.com/img/activate-v3/login') or contains(@src,'rall.io/img/activate-v3/login')]//ancestor::div[@class='login-section lgn']//div[@class='login-elements']//h2[@class='welcome-text']"), "Page load for Sign In Page"),

	/** The renderseo page load. */
	RENDERSEO_PAGE_LOAD(By.xpath("//img[contains(@src,'rall.io/img/renderseo/login')]//ancestor::div[@class='login-section lgn']//div[@class='login-elements']//h2[@class='welcome-text']"), "RenderSeo pageLoad"),
	
	/** The ralio logo. */
	RALIO_LOGO(By.xpath("//div[@class='login-logo']//img[@alt='logo']"), "Ralio Logo"),
	
	/** The renderseo logo. */
	RENDERSEO_LOGO(By.xpath("//div[@class='login-logo']//img[@alt='logo']"), "RenderSeo Logo"),

	/** The welcome text. */
	WELCOME_TEXT(By.xpath("//h2[@class='welcome-text' and text()='Welcome to ']//span[text()='Rallio']//parent::h2"), "Welcome text"),

	/** The renderseo welcome text. */
	RENDERSEO_WELCOME_TEXT(By.xpath("//h2[@class='welcome-text' and text()='Welcome to ']//span[text()='RenderSEO']//parent::h2"), "RenderSeo Welcome text"),

	/** The email address.  */
	EMAIL_ADDRESS(By.xpath("//input[@name='loginInputEmail']"), "Email Addresss"),

	/** The password. */
	PASSWORD(By.xpath("//input[@name='loginInputPassword']"), "Password"),

	VERIFY_PASSWORD(By.xpath("//input[@name='verifyEmailPassword']"),"Verify Password"),

	PASSWORD_AGAIN(By.xpath("//input[@name='loginInputPasswordAgain']"),"Password Again"),

	CONTINUE_BUTTON(By.xpath("//button[@class='ac-btn ac-primary ac-block' and text()='CONTINUE']"),"Continue Button"),

	/** The remember me text. */
	REMEMBER_ME_TEXT(By.xpath("//span[text()='Remember me']"), "Remember Me Text"),

	/** The remember me checkbox. */
	REMEMBER_ME_CHECKBOX(By.xpath("//span[text()='Remember me']//preceding-sibling::input"), "Remember me Checkbox"),

	/** The forget password. */
	FORGET_PASSWORD(By.xpath("//div[@class='forgotpassword-txt']//a"), "Forget Password"),

	/** The sign in button. */
	SIGN_IN_BUTTON(By.xpath("//button[contains(@class,'ac-btn ac-primary') and text()='SIGN IN']"), "Sign In Button"),

	/** Powered by Rallio. */
	POWERED_BY_RALLIO(By.xpath("//div[@class='login-footer-wrp']//span[text()='Powered by']//parent::div//img[@alt='logo']"), "Powered by Rallio"),
	
	/** The powered by renderseo. */
	POWERED_BY_RENDERSEO(By.xpath("//div[@class='login-footer-wrp']//span[text()='Powered by']//parent::div//img[@alt='logo']"), "Powered by RenderSeo"),
	
	/** The invalid message. */
	INVALID_MESSAGE(By.xpath("//span[text()='Invalid Email Address or Password']"), "Invalid message"),
	
	/** The invalid passwordFormat message. */
	INVALID_PASSWORD_FORMAT_MESSAGE(By.xpath("//span[text()='Password should be minimum 8 characters']"), "Invalid passwordFormat message"),
	
	/** The ai subscribtion video play. */
	AI_SUBSCRIBTION_VIDEO_PLAY(By.xpath(
			"//div[@role='tooltip']//div[@class='aicoach-body']//div[@class='aicoach-cnt']//div[@class='ai-coach-video']"),
			"AI Subscribtion Video Play"),

	/** The ai video donot show me checkbox. */
	AI_VIDEO_DONOT_SHOW_ME_CHECKBOX(By.xpath(
			"//div[@class='aicoach-body']//label[@class='checkbox-item']//span[@class='checkbox-hover']//input[@name='localizePost']"),
			"AI Subscribtion Video Check Box"),

	PASSWORD_UPDATED_SUCCESSFULLY(By.xpath("//span[text()='Password updated successfully.']"),"Password Updated Successfully"),

	SSO_REDIRECTION_EMAIL_ADDRESS(By.xpath("//div[@class='login-page']//form[@class='login-form']//input[@name='username']"), "Email Addresss"),

	SSO_REDIRECTION_PASSWORD(By.xpath("//div[@class='login-page']//form[@class='login-form']//input[@name='password']"), "Password"),

	SSO_REDIRECTION_LOGIN_BUTTON(By.xpath("//div[@class='login-page']//form[@class='login-form']//button[text()='login']"), "Login button"),
	;

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new new rallio sign in page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private NewRallioSignInPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new new rallio sign in page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private NewRallioSignInPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum RevvSSPageEnum.
 */
public enum RevvSSPageEnum {

	/** The page load. */
	REVV_PAGE_LOAD(By.xpath(
	        "//span[text()='Revv']//ancestor::div//div[contains(@class,'revvssomainsectionwrp')]//div[@class='small-trans-box']//following::div[@class='rallioplatform revv']"),
	        "The Revv page load is done"),

	/** The revv management tab. */
	REVV_MANAGEMENT_TAB(By.xpath("//div[@class='react-ripples']//li[@class='nav-item animate__animated animate__fadeInLeft']//span[text()='Revv']"), "Revv Management Tab Page"),

	/** The connectnow button. */
	CONNECTNOW_BUTTON(By.xpath("//div[@class='small-trans-box']//span[text()='Connect now']"), "Connect now button click"),

	/** The connect now email input. */
	CONNECT_NOW_EMAIL_FIELD(By.xpath("//input[@name='email']"), "The connect now tab email input"),

	/** The connect now password field. */
	CONNECT_NOW_PASSWORD_FIELD(By.xpath("//input[@name='password']"), "The connect now tab password input"),

	/** The connect now login button. */
	CONNECT_NOW_LOGIN_BUTTON(By.xpath("//div[@class='rlTop']//button//span[text()='Login']"), "The click the login button"),

	/** The revv tab login cancel. */
	REVV_TAB_LOGIN_CANCEL(By.xpath("//div[@class='modal-content']//img[@alt='Close']"), "The Revv Tab login cancel button"),

    /** The Revv Page contents. */

	/** The Already Revv Member. */
	ALREADY_REVV_MEMBER(By.xpath("//*[text()='Already a ' and text()=' member?']//span[text()='Revv']"), "The Already Revv memeber is display"),

	/** The increase montly review. */
	INCREASE_MONTLY_REVIEW(By.xpath("//div[@class='right-section-main']//h3[contains(text(),'Increase in Monthly Review per Location')]"),
	        "The Increase Monthly Review is displayed"),

	/** The two image in revvpage. */
	TWO_IMAGES_IN_REVVPAGE(By.xpath("//div[@class='right-section-main']//div[@class='slider-img-bg']//img[@alt='Location']"), "The two image is displayed"),

	/** The bean meup revv. */
		TRAVEL_LEADERS_NETWORK_REVV(By.xpath("//div[@class='rallioplatform revv']//h3[contains(text(),'Travel Leaders Network' ) and text()=' + ']//span[text()='Revv']"), "The Travel Leaders Network"),

	/** The bean meup coffee revv. */
	BEAN_MEUP_COFFEE_REVV(By.xpath("//div[@class='rallioplatform revv']//h3[text()='Bean Me Up Coffee' and text()=' + ']//span[text()='Revv']"), "The Bean me up coffee Revv"),

	/** The disconnect button. */
	DISCONNECT_BUTTON(By.xpath("//div[contains(@class,'small-trans-box')]//button//span[text()='Disconnect']"), "The click the Disconnect Button"),

	/** The disconnect now notification. */
	DISCONNECT_NOW_NOTIFICATION(
	        By.xpath("//div[contains(@class,'notification')]//div[@class='csp-action']//button[text()='Cancel']//following::div//button[text()='Disconnect Now']"),
	        "The Disconnect Now Notification display"),

	/** The disconnect cancel button. */
	DISCONNECT_CANCEL_BUTTON(By.xpath("//div[@class='csp-action']//div//button[text()='Cancel']"), "The disconnect cancel button"),

	/** The disconnect now button. */
	DISCONNECT_NOW_BUTTON(By.xpath("//div[@class='csp-action']//div//button[text()='Disconnect Now']"), "The disconnect button click"),

	/** The disconnect now pageload. */
	DISCONNECT_NOW_PAGELOAD(By.xpath(
	        "//li[@class='ripple active']//ancestor::div//div[@class='revvssomainsectionwrp']//div[contains(@class,'small-trans-box')]//following-sibling::div[@class='white-cntnr redirect-revv']"),
	        "The Diconnect now page load"),

	/** The open revv in new tab. */
	OPEN_REVV_IN_NEW_TAB(By.xpath("//button//span//a[text()='Open Revv in New Tab']"), "The Open Revv Tab "),

	/** The schedule demo button. */
	SCHEDULE_DEMO_BUTTON(By.xpath("//button//span[text()='Schedule a demo']"), "The Schedule Demo button"),

	/** The revv new tap pageload. */
	REVV_NEW_TAP_PAGELOAD(By.xpath(
	        "//div[@class='desktop-display']//ancestor::div//div[@class='mg-top-row rlc-post-stats row']//following-sibling::div[@class='list flex-start survey-tble-wrpper']"),
	        "The Revv New tab pageload"),

	/** The revv new tap more options. */
	REVV_NEW_TAP_MORE_OPTIONS(By.xpath("//div[contains(@class,'header-content list nowrap space-between full-width ')]//div[@id='menu-trigger']"), "The Revv New tab more Options"),

	/** The revv tab logout button. */
	REVV_TAB_LOGOUT_BUTTON(By.xpath("//button//span[@class='config-btn set-btns']//following-sibling::span[text()='LOGOUT']"), "The Revv Tab logout Button"),

	/** The dashboard pageload. */
	DASHBOARD_PAGELOAD(By.xpath("//div[@class='small-clean-popup menu-open']"), "The Dasboard page is Display"),

	/** The connect now login pageload. */
	REVV_NEWTAB_EMAIL_LOGIN_PAGELOAD(By.xpath("//div[@id='ember7']//form//button[@id='ember20']//following-sibling::a[contains(text(),' Forgot your password?')]"),
	        "The Connect now email PageLoad"),

	/** The revv connect now email pageload. */
	REVV_INVALIDEMAIL_PAGELOAD(By.xpath("//div[@class='revv-login']//div//img[@alt='REVV Logo']//following::div[@class='rl-body']//span[text()='Invalid Email or password.']"),
	        "The Invalid Email or Password dispaly"),

	/** The revv scheduledemo name field. */
	REVV_SCHEDULEDEMO_NAME_FIELD(By.xpath("//input[@name='name'  and @class='form-control']"), "The name input in Schedule demo page"),

	/** The revv scheduledemo company field. */
	REVV_SCHEDULEDEMO_COMPANY_FIELD(By.xpath("//input[@name='company']"), "The company name input in Schedule demo page"),

	/** The revv scheduledemo email field. */
	REVV_SCHEDULEDEMO_EMAIL_FIELD(By.xpath("//input[@name='email'  and @class='form-control']"), "The email input in Schedule demo page"),

	/** The revv scheduledemo phonenumber field. */
	REVV_SCHEDULEDEMO_PHONENUMBER_FIELD(By.xpath("//input[@name='phone_number'  and @class='form-control']"), "The phoneNumber input in Schedule demo page"),

	/** The revv scheduledemo numberoflocations field. */
	REVV_SCHEDULEDEMO_NUMBEROFLOCATIONS_FIELD(By.xpath("//input[@name='location_count'  and @class='form-control']"), "The Number Of Locations input in Schedule demo page"),

	/** The revv scheduledemo commentormessage field. */
	REVV_SCHEDULEDEMO_COMMENTORMESSAGE_FIELD(By.xpath("//textarea[@name='comment'  and @class='form-control']"), "The Comment or Message input in Schedule demo page"),

	/** The select radio button by name. */
	SELECT_RADIO_BUTTON_BY_NAME("//span[text()='%s']//ancestor::label//span//input[@name='regarding']", "The click radio button by the name"),

	/** The scheduledemo page submit. */
	SCHEDULEDEMO_PAGE_SUBMIT(By.xpath("//div[@class='modal-btn-grp-wraps ap-actions']//button[@type='submit']"), "The click submit button in schedule demo page"),

	/** The scheduleddemo page submit done. */
	SCHEDULEDDEMO_PAGE_SUBMIT_DONE(By.xpath("//div[contains(@class,'Toastify__toast-body')]//span[contains(text(),'Thanks for contacting us! We will be in touch')]"),
	        "The comments or Message submit done"),

	/** The pet supplies revv. */
	PET_SUPPLIES_REVV(By.xpath("//h3[text()='Pet Supplies Plus' and text()=' + ']//span[text()='Revv']"), "The Pet supplies"),

	/** The user location dropdown. */
	USER_LOCATION_DROPDOWN(By.xpath("//button//span[@class='css-19r5em7']"), "The user location Dropdown"),

	/** The user location dropdown byname. */
	USER_LOCATION_DROPDOWN_BYNAME("//button//span[@class='css-19r5em7' and text()='%s']", "The check Dropdown name"),

    /** The Log out enums *. */

	/** The profile icon. */
	PROFILE_ICON(By.xpath("//button[@id='dropitems-profile-items']"), "Profile icon"),

	/** The profile icon dropdown. */
	PROFILE_ICON_DROPDOWN(By.xpath("//button[@id='dropitems-profile-items']//following-sibling::div[@class='dropdown-menu show']"), "Profile icon dropdown"),

	/** The dropdown logout. */
	DROPDOWN_LOGOUT(By.xpath("//div[@class='dropdown-menu show']//a[text()='Logout']"), "Dropdown logOut"),

	/** The dropdown logout. */
	DROPDOWNS_LOGOUT(By.xpath("//div[@class='dropdown-menu show']//a[text()='Logout']"), "Dropdown logOut");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new revv SS page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private RevvSSPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new revv SS page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private RevvSSPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

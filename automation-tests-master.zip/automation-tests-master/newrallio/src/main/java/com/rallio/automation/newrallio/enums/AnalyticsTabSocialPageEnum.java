package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum AnalyticsTabSocialPageEnum.
 */
public enum AnalyticsTabSocialPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath(
	        "//li[@class='ripple active']//span[text()='Social']//following::section[@class='item-g filter ra-filter-sec anlFilter']//ancestor::div//div[@class='g-centre']//div[contains(@class,'mainContent analytics')]"),
	        "Page load"),

	/** The followers stats count. */
	FOLLOWERS_STATS_COUNT(By.xpath("//div[contains(@class,'an-stat--card')]//span[text()='Followers']//following-sibling::div//span[@class='big-number-text']//div"),
	        "Followers stats count"),

	/** The engagement stats count. */
	ENGAGEMENT_STATS_COUNT(
	        By.xpath("//div[contains(@class,'an-stat--card')]//span[text()='Avg Daily Post Engagement']//following-sibling::div//span[@class='big-number-text']//div"),
	        "Engagement stats count"),

	/** The publishedposts stats count. */
	PUBLISHEDPOSTS_STATS_COUNT(By.xpath("//div[contains(@class,'an-stat--card')]//span[text()='Published Posts']//following-sibling::div//span[@class='big-number-text']//div"),
	        "PublishedPosts stats count"),

	
	/** The followers rank value. */
	FOLLOWERS_RANK_VALUE(By.xpath(
	        "//div[contains(@class,'an-stat--card')]//span[text()='Followers']//parent::div//following-sibling::div//div[@class='rank-value']"),
	        "FOLLOWERS_RANK_VALUE"),

	/** The engagement stats ranking.*/
	ENGAGEMENT_RANK_VALUE(By.xpath(
	        "//div[contains(@class,'an-stat--card')]//span[text()='Avg Daily Post Engagement']//parent::div//following-sibling::div//div[@class='rank-value']"),
	        "ENGAGEMENT_RANK_VALUE"),

	/** The publishedposts stats ranking. */
	PUBLISHEDPOSTS_RANK_VALUE(By.xpath(
	        "//div[contains(@class,'an-stat--card')]//span[text()='Published Posts']//parent::div//following-sibling::div//div[@class='rank-value']"),
	        "PUBLISHEDPOSTS_RANK_VALUE"),

	/** The followers stats ranking. */
	FOLLOWERS_STATS_RANKING(By.xpath(
	        "//div[contains(@class,'an-stat--card')]//span[text()='Followers']//parent::div//following-sibling::div//div[@class='rank-value']//following-sibling::div[@class='delta-wrp']//span"),
	        "Followers stats ranking"),

	/** The engagement stats ranking. */
	ENGAGEMENT_STATS_RANKING(By.xpath(
	        "//div[contains(@class,'an-stat--card')]//span[text()='Avg Daily Post Engagement']//parent::div//following-sibling::div//div[@class='rank-value']//following-sibling::div[@class='delta-wrp']"),
	        "Engagement stats ranking"),

	/** The publishedposts stats ranking. */
	PUBLISHEDPOSTS_STATS_RANKING(By.xpath(
	        "//div[contains(@class,'an-stat--card')]//span[text()='Published Posts']//parent::div//following-sibling::div//div[@class='rank-value']//following-sibling::div[@class='delta-wrp']"),
	        "PublishedPosts stats ranking"),

	/** The followers delta value. */
	FOLLOWERS_DELTA_VALUE(By.xpath("//div[contains(@class,'an-stat--card')]//span[text()='Followers']//following-sibling::div//span[@class='delta-small-text']"),
	        "Followers delta value"),

	/** The engagement delta value. */
	ENGAGEMENT_DELTA_VALUE(By.xpath("//div[contains(@class,'an-stat--card')]//span[text()='Avg Daily Post Engagement']//following-sibling::div//span[@class='delta-small-text']"),
	        "Engagement delta value"),

	/** The publishedposts delta value. */
	PUBLISHEDPOSTS_DELTA_VALUE(By.xpath("//div[contains(@class,'an-stat--card')]//span[text()='Published Posts']//following-sibling::div//span[@class='delta-small-text']"),
	        "PublishedPosts delta value"),

	/** The followers brand average. */
	FOLLOWERS_BRAND_AVERAGE(
	        By.xpath("//div[contains(@class,'an-stat--card')]//span[text()='Followers']//following-sibling::div//span[text()='Brand Average']//following-sibling::span"),
	        "Followers brand average"),

	/** The engagement brand average. */
	ENGAGEMENT_BRAND_AVERAGE(By.xpath(
	        "//div[contains(@class,'an-stat--card')]//span[text()='Avg Daily Post Engagement']//following-sibling::div//span[text()='Brand Average']//following-sibling::span"),
	        "Engagement brand average"),

	/** The publishedposts brand average. */
	PUBLISHEDPOSTS_BRAND_AVERAGE(
	        By.xpath("//div[contains(@class,'an-stat--card')]//span[text()='Published Posts']//following-sibling::div//span[text()='Brand Average']//following-sibling::span"),
	        "PublishedPosts brand average"),

	/** The followers stats chart. */
	FOLLOWERS_STATS_CHART(By.xpath(
	        "//div[contains(@class,'an-stat--card')]//span[text()='Followers']//parent::div//following-sibling::div//div[@data-highcharts-chart]//div[@class='highcharts-container ']"),
	        "Followers stats CHART"),
	
	FOLLOWERS_CHART_NO_DATA_SHOW(By.xpath(
	        "(//div[contains(@class,'stat--card')])[1]//span[text()='No data to show']"),
	        "FOLLOWERS_STATS_CHART_NO_DATA_SHOW"),

	/** The engagement stats chart. */
	ENGAGEMENT_STATS_CHART(By.xpath(
	        "//div[contains(@class,'an-stat--card')]//span[text()='Avg Daily Post Engagement']//parent::div//following-sibling::div//div[@data-highcharts-chart]//div[@class='highcharts-container ']"),
	        "Engagement stats CHART"),
	
	ENGAGEMENT_CHART_NO_DATA_SHOW(By.xpath(
	        "(//div[contains(@class,'stat--card')])[2]//span[text()='No data to show']"),
	        "ENGAGEMENT_CHART_NO_DATA_SHOW"),

	/** The publishedposts stats chart. */
	PUBLISHEDPOSTS_STATS_CHART(By.xpath(
	        "//div[contains(@class,'an-stat--card')]//span[text()='Published Posts']//parent::div//following-sibling::div//div[@data-highcharts-chart]//div[@class='highcharts-container ']"),
	        "PublishedPosts stats CHART"),
	
	PUBLISHEDPOSTS_NO_DATA_SHOW(By.xpath(
	        "(//div[contains(@class,'stat--card')])[3]//span[text()='No data to show']"),
	        "PUBLISHEDPOSTS_NO_DATA_SHOW"),

	/** The detailed line chart. */
	DETAILED_LINE_CHART(By.xpath("//div[contains(@class,'ra-card')]//div[@class='highcharts-container ']//*[@class='highcharts-plot-background']"), "Detailed line chart"),

	/** The detailed table view. */
	DETAILED_TABLE_VIEW(By.xpath("//div[contains(@class,'profile-tbl-wrp ')]//table//tbody//tr//td"), "Detailed table view"),

	/** The facebook table data. */
	FACEBOOK_TABLE_DATA(By.xpath(
	        "//div[contains(@class,'profile-tbl-wrp')]//table//tbody//tr//td//div[@class='an-social-icon-title']//img[contains(@src,'fb-lv')]//ancestor::tr//td//parent::td//span[@class='value1' and text()]//ancestor::tr//td//parent::td//span[@class='value1' and text()]//ancestor::tr//td//parent::td//span[@class='value1' and text()]"),
	        "Facebook table data"),

	/** The instagram table data. */
	INSTAGRAM_TABLE_DATA(By.xpath(
	        "//div[contains(@class,'profile-tbl-wrp')]//table//tbody//tr//td//div[@class='an-social-icon-title']//img[contains(@src,'insta-t')]//ancestor::tr//td//parent::td//span[@class='value1' and text()]//ancestor::tr//td//parent::td//span[@class='value1' and text()]//ancestor::tr//td//parent::td//span[@class='value1' and text()]"),
	        "Instagram table data"),


	/** The twitter table data. */
	TWITTER_TABLE_DATA(By.xpath(
	        "//div[contains(@class,'profile-tbl-wrp')]//table//tbody//tr//td//div[@class='an-social-icon-title']//img[contains(@src,'twtr-t')]//ancestor::tr//td//parent::td//span[@class='value1' and text()]//ancestor::tr//td//parent::td//span[@class='value1' and text()]//ancestor::tr//td//parent::td//span[@class='value1' and text()]"),
	        "Twitter table data"),

	/** The linkedin table data. */
	LINKEDIN_TABLE_DATA(By.xpath(
	        "//div[contains(@class,'profile-tbl-wrp')]//table//tbody//tr//td//div[@class='an-social-icon-title']//img[contains(@src,'in-t')]//ancestor::tr//td//parent::td//span[@class='value1' and text()]//ancestor::tr//td//parent::td//span[@class='value1' and text()]//ancestor::tr//td//parent::td//span[@class='value1' and text()]"),
	        "Linkedin table data"),

	/** The totals table data. */
	TOTALS_TABLE_DATA(By.xpath(
	        "//div[contains(@class,'profile-tbl-wrp')]//table//tbody//tr//td[text()='Totals']//ancestor::tr//td//parent::td//span[@class='value1' and text()]//ancestor::tr//td//parent::td//span[@class='value1' and text()]//ancestor::tr//td//parent::td//span[@class='value1' and text()]"),
	        "Totals table data"),


	/** The individual facebook table data. */
	INDIVIDUAL_FACEBOOK_TABLE_DATA(By.xpath(
	        "//div[contains(@class,'profile-tbl-wrp')]//table//tbody//tr//td//div[@class='an-social-icon-title']//img[contains(@src,'fb-lv')]//ancestor::tr//td[2]//span[@class='value1' and text()]//ancestor::tr//td[3]//span[@class='value1' and text()]//ancestor::tr//td[4]//span[@class='value1' and text()]"),
	        "Individual Facebook table data"),

	/** The individual instagram table data. */
	INDIVIDUAL_INSTAGRAM_TABLE_DATA(By.xpath(
	        "//div[contains(@class,'profile-tbl-wrp')]//table//tbody//tr//td//div[@class='an-social-icon-title']//img[contains(@src,'insta-t')]//ancestor::tr//td[2]//span[@class='value1' and text()]//ancestor::tr//td[3]//span[@class='value1' and text()]//ancestor::tr//td[4]//span[@class='value1' and text()]"),
	        "Individual Instagram table data"),

	/** The individual twitter table data. */
	INDIVIDUAL_TWITTER_TABLE_DATA(By.xpath(
	        "//div[contains(@class,'profile-tbl-wrp')]//table//tbody//tr//td//div[@class='an-social-icon-title']//img[contains(@src,'twtr-t')]//ancestor::tr//td[2]//span[@class='value1' and text()]//ancestor::tr//td[3]//span[@class='value1' and text()]//ancestor::tr//td[4]//span[@class='value1' and text()]"),
	        "Individual Twitter table data"),

	/** The individual linkedin table data. */
	INDIVIDUAL_LINKEDIN_TABLE_DATA(By.xpath(
	        "//div[contains(@class,'profile-tbl-wrp')]//table//tbody//tr//td//div[@class='an-social-icon-title']//img[contains(@src,'in-t')]//ancestor::tr//td[2]//span[@class='value1' and text()]//ancestor::tr//td[3]//span[@class='value1' and text()]//ancestor::tr//td[4]//span[@class='value1' and text()]"),
	        "Individual Linkedin table data"),

	/** The individual totals table data. */
	INDIVIDUAL_TOTALS_TABLE_DATA(By.xpath(
	        "//div[contains(@class,'profile-tbl-wrp')]//table//tbody//tr//td[text()='Totals']//ancestor::tr//td[2]//span[@class='value1' and text()]//ancestor::tr//td[3]//span[@class='value1' and text()]//ancestor::tr//td[4]//span[@class='value1' and text()]"),
	        "Individual Totals table data"),

	/** The totals average daily post engagement. */
	TOTALS_AVERAGE_DAILY_POST_ENGAGEMENT(By.xpath("//div[contains(@class,'flex-item-xs')]//div[@class='total-follow tfs']//div[@class='tf-col-holder card-body']"),"Total Avg Daily Post Engagement"),
	
	/** The followers tile active. */
	FOLLOWERS_TILE_ACTIVE(By.xpath("//div//img[@class='an-chart--indicator followers']"), "Followers tile active"),

	/** The post engagement tile active. */
	POST_ENGAGEMENT_TILE_ACTIVE(By.xpath("//div//img[@class='an-chart--indicator engagement']"), "PostEnagement tile active"),

	POST_ENGAGEMENT_TILE_COUNT(By.xpath("//span[text()=' Post Engagement']//parent::div[@class='card-content-top']//span[@class='big-number-text']//div[text()]"),"PostEngagement tile"),

	POST_ENGAGEMENT_TOOL_TIP(By.xpath("//div[@class='common-tooltip--wrp']//span[contains(text(),'post engagements.')]"), "PostEngagement tool tip"),

	POST_ENAGEMENT_LINE_CHART(By.xpath("//div[@class='flex-item-xs lpx socail-an--chart']//*[local-name()='g' and @class='highcharts-grid highcharts-xaxis-grid']//*[local-name()='path']"),"PostEngagement Line Chart"),

	POST_ENGAGEMENT_LINE_CHART_TOOL_TIP(By.xpath("//span[@class='ra-tooltip-date']//parent::span//div[@class='tooltip-tile-wrp']"),"PostEngagement Line Chart tool tip"),

	/** The published posts tile active. */
	PUBLISHED_POSTS_TILE_ACTIVE(By.xpath("//div//img[@class='an-chart--indicator posts']"), "PublishedPosts tile active"),

	/** The followers donut chart section. */
	FOLLOWERS_DONUT_CHART_SECTION(By.xpath(
	        "//h3[text()='Percentage of Total Following by Platform']//parent::div//*[local-name()='svg']//*[@class='highcharts-series highcharts-series-0 highcharts-pie-series highcharts-tracker']"),
	        "Followers DonutChart section"),

	/** The post engagement donut chart section. */
	POST_ENGAGEMENT_DONUT_CHART_SECTION(By.xpath(
	        "//h3[text()='Percentage of Total Avg Daily Post Engagement by Platform']//parent::div//*[local-name()='svg']//*[@class='highcharts-series highcharts-series-0 highcharts-pie-series highcharts-tracker']"),
	        "PostEngagement DonutChart section"),

	/** The published posts donut chart section. */
	PUBLISHED_POSTS_DONUT_CHART_SECTION(By.xpath(
	        "//h3[text()='Percentage of Total Published Posts by Platform']//parent::div//*[local-name()='svg']//*[@class='highcharts-series highcharts-series-0 highcharts-pie-series highcharts-tracker']"),
	        "PublishedPosts DonutChart section"),

	/** The donut chart section facebook data. */
	DONUT_CHART_SECTION_FACEBOOK_DATA(By.xpath("//span[text()='Facebook']//parent::div//parent::div[contains(@class,'active')]//span[@class='tf-total-count']"),
	        "DonutChart section facebook data"),

	/** The donut chart section instagram data. */
	DONUT_CHART_SECTION_INSTAGRAM_DATA(By.xpath("//span[text()='Instagram']//parent::div//parent::div[contains(@class,'active')]//span[@class='tf-total-count']"),
	        "DonutChart section instagram data"),

	/** The donut chart section twitter data. */
	DONUT_CHART_SECTION_X_FORMERLY_TWITTER_DATA(By.xpath("//span[text()='X (Formerly Twitter)']//parent::div//parent::div[contains(@class,'active')]//span[@class='tf-total-count']"),
	        "DonutChart section twitter data"),

	/** The donut chart section linkedin data. */
	DONUT_CHART_SECTION_LINKEDIN_DATA(By.xpath("//span[text()='LinkedIn']//parent::div//parent::div[contains(@class,'active')]//span[@class='tf-total-count']"),
	        "DonutChart section linkedin data"),

	/** The clear filter. */
	CLEAR_FILTER(By.xpath("//div[@class='react-ripples ac-primary-box' and not(contains(@class,'pointer-events-none'))]//button//span[text()='Clear Filter']"), "Clear Filter"),

	/** The clear filter option. */
	CLEAR_FILTER_OPTION(By.xpath("//button//span[text()='Clear Filter']"), "Clear Filter option"),

	/** The download csv button. */
	DOWNLOAD_CSV_BUTTON(By.xpath("//button//span[text()='Download CSV']"), "Download CSV button"),

	/** The all filter platform. */
	ALL_FILTER_PLATFORM(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'all-platform')]//parent::button"), "All filter platform"),

	/** The all filter selected. */
	ALL_FILTER_SELECTED(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'all-platform')]//parent::button[contains(@class,'active')]"),
	        "All filter selected"),

	/** The facebook filter button. */
	FACEBOOK_FILTER_BUTTON(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'fb-platform')]//parent::button"),
	        "Facebook filter button"),

	/** The facebook filter selected. */
	FACEBOOK_FILTER_SELECTED(
	        By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'fb-platform')]//parent::button[contains(@class,'active')]"),
	        "Facebook filter selected"),

	/** The twitter filter button. */
	TWITTER_FILTER_BUTTON(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'twitter-platform')]//parent::button"),
	        "Twitter filter button"),

	/** The twitter filter selected. */
	TWITTER_FILTER_SELECTED(
	        By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'twitter-platform')]//parent::button[contains(@class,'active')]"),
	        "Twitter filter selected"),

	/** The linkedin filter button. */
	LINKEDIN_FILTER_BUTTON(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'linkedin-platform')]//parent::button"),
	        "LinkedIn filter button"),

	/** The linkedin filter selected. */
	LINKEDIN_FILTER_SELECTED(
	        By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'linkedin-platform')]//parent::button[contains(@class,'active')]"),
	        "LinkedIn filter selected"),

	/** The instagram filter button. */
	INSTAGRAM_FILTER_BUTTON(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'instagram-platform')]//parent::button"),
	        "Instagram filter button"),

	/** The instagram filter selected. */
	INSTAGRAM_FILTER_SELECTED(
	        By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'instagram-platform')]//parent::button[contains(@class,'active')]"),
	        "Instagram filter selected"),

	/** The google filter button. */
	GOOGLE_FILTER_BUTTON(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'google-platform')]//parent::button"),
	        "Google filter button"),

	/** The google filter selected. */
	GOOGLE_FILTER_SELECTED(
	        By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'google-platform')]//parent::button[contains(@class,'active')]"),
	        "Google filter selected"),

	/** The from date. */
	FROM_DATE(By.xpath("//div[contains(@class,'dp-from')]//input[@placeholder='MM/DD/YYYY']"), "From date"),

	/** The from date active. */
	FROM_DATE_ACTIVE(By.xpath("//section[contains(@class,'filter')]//div[@class='dp-item dp-from active']"), "From date active"),

	/** The from date content. */
	FROM_DATE_CONTENT(By.xpath("//div[contains(@class,'dp-from')]//div[@class='react-datepicker__input-container']//input"), "From date content"),

	/** The select from date. */
	SELECT_FROM_DATE("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]", "Select From date"),

	/** The select from date with month. */
	SELECT_FROM_DATE_WITH_MONTH(
	        "//section[contains(@class,'filter')]//div[contains(@class,'dp-item dp-from')]//div[2]//div[@aria-disabled='false' and  contains(@aria-label,'%s')]",
	        "Select from date with month"),

	/** The from date previous month. */
	FROM_DATE_PREVIOUS_MONTH(By.xpath("//section[contains(@class,'filter')]//div[@class='react-datepicker']//button[@aria-label='Previous Month']"),
	        "From date previous month button"),

	/** The from date next month. */
	FROM_DATE_NEXT_MONTH(By.xpath("//section[contains(@class,'filter')]//div[@class='react-datepicker']//button[@aria-label='Next Month']"),
	        "From date next month button"),

	/** The select date from calendar. */
	SELECT_DATE_FROM_CALENDAR(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week']//div[@aria-disabled='false']"), "Select date from calendar"),

	/** The calendar displayed. */
	CALENDAR_DISPLAYED(By.xpath("//div[@class='react-datepicker__month']"), "Calendar displayed"),

	/** The select last date. */
	SELECT_LAST_DATE(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week'][3]//div[@aria-disabled='false'][last()]"), "Select last date"),

	/** The to date. */
	TO_DATE(By.xpath("//div[contains(@class,'dp-to')]//input[@placeholder='Most Recent']"), "To date"),

	/** The to date active. */
	TO_DATE_ACTIVE(By.xpath("//section[contains(@class,'filter')]//div[@class='dp-item dp-to active']"), "To date active"),

	/** The to date content. */
	TO_DATE_CONTENT(By.xpath("//div[contains(@class,'dp-to')]//div[@class='react-datepicker__input-container']//input"), "To date content"),

	/** The to date previous month. */
	TO_DATE_PREVIOUS_MONTH(By.xpath("//section[contains(@class,'filter')]//div[@class='react-datepicker']//button[@aria-label='Previous Month']"),
	        "To date previous month button"),

	/** The to date next month. */
	TO_DATE_NEXT_MONTH(By.xpath("//section[contains(@class,'filter')]//div[@class='react-datepicker']//button[@aria-label='Next Month']"), "To date next month button"),

	/** The select to date. */
	SELECT_TO_DATE("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]", "Select To date"),

	/** The select to date with month. */
	SELECT_TO_DATE_WITH_MONTH("//section[contains(@class,'filter')]//div[contains(@class,'dp-item dp-to')]//div[2]//div[@aria-disabled='false' and  contains(@aria-label,'%s')]",
	        "Select to date with month"),

	/** The month picker. */
	MONTH_PICKER(By.xpath("//select[@class='react-datepicker__month-select']"), "Month picker"),

	/** The month dropdown. */
	MONTH_DROPDOWN(By.xpath("//select[@class='react-datepicker__month-select']"), "Month drop down"),

	/** The year dropdown. */
	YEAR_DROPDOWN(By.xpath("//select[@class='react-datepicker__year-select']"), "Year drop down."),

	/** The download started message. */
	DOWNLOAD_STARTED_MESSAGE(By.xpath("//span[@class='success-mess-txt' and text()='Download started']"), "Download started message"),

	/** The download done message. */
	DOWNLOAD_DONE_MESSAGE(By.xpath("//span[@class='success-mess-txt' and text()='Done!']"), "The Download Done"),

	/** The location selector button. */
	LOCATION_SELECTOR_BUTTON(By.xpath("//h3[text()='Location Selector']//following-sibling::div[@class='locAction']//span"), "Location selector button"),

	/** The location selector view. */
	LOCATION_SELECTOR_VIEW(By.xpath("//div[@class='modal-body']//h3[text()='Location Selector']//parent::div//parent::div//div[@class='asm-accord']"), "Location selector view"),

	/** The hubs dropdown. */
	HUBS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='accordion-item']//div[@class='card-header']//span[text()='Hubs']"), "Hubs dropdown"),

	/** The location lists dropdown. */
	LOCATION_LISTS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='accordion-item']//div[@class='card-header']//span[text()='Location Lists']"),
	        "LocationLists dropdown"),

	/** The locations dropdown. */
	LOCATIONS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='accordion-item']//div[@class='card-header']//span[text()='Locations']"), "Locations dropdown"),

	/** The location selector dropdown list. */
	LOCATION_SELECTOR_DROPDOWN_LIST(By.xpath("//div[@class='modal-body']//div[@class='open card-header']//parent::div//following-sibling::div//ul[@class='hub-list']"),
	        "Location selector dropdown list"),

	/** The location selector search. */
	LOCATION_SELECTOR_SEARCH(By.xpath("//h3[text()='Location Selector']//following-sibling::div//input[@name='Locations']"), "Location selector search"),

	/** The select dropdown list. */
	SELECT_DROPDOWN_LIST("//div[@class='modal-body']//div[@class='open card-header']//parent::div//following-sibling::div//li//span[contains(text(),'%s')]",
	        "Select dropdown list"),

	/** The selected dropdown list. */
	SELECTED_DROPDOWN_LIST(
	        "//div[@class='modal-body']//div[@class='open card-header']//parent::button//following-sibling::div//ul//li//input[@checked]//following-sibling::span[contains(text(),'%s')]",
	        "Selected dropdown list"),

	/** The location selector cancel button. */
	LOCATION_SELECTOR_CANCEL_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Cancel']"), "Location selector cancel button"),

	/** The location selector ok button. */
	LOCATION_SELECTOR_OK_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Ok']"), "Location selector ok button"),

	/** New Enums*. */

	FOLLOWERS_COUNT_TOOLTIP(By.xpath("//div[@class='rc-tooltip-content']//div[@class='rc-tooltip-inner']//div[@class='common-tooltip--wrp']//span[@class='cust-tooltip-txt']"),
	        "Followers Count ToolTip"),

	/** The followers daterange tooltip. */
	FOLLOWERS_DATERANGE_TOOLTIP(
	        By.xpath("//div[@class='rc-tooltip-content']//div[@class='rc-tooltip-inner']//div[@class='common-tooltip--wrp']//span[@class='cust-tooltip-txt delta']"),
	        "Followers date range ToolTip"),

	/** The engagement daterange count tootlip. */
	ENGAGEMENT_DATERANGE_COUNT_TOOTLIP(By.xpath("//div[@class='rc-tooltip-content']//div[@class='rc-tooltip-inner']//span[@class='cust-tooltip-txt']"),
	        "Engagement Count and Date range"),

	/** The engagement delta count tooltip. */
	ENGAGEMENT_DELTA_COUNT_TOOLTIP(By.xpath("//div[@class='rc-tooltip-content']//div[@class='rc-tooltip-inner']//span[@class='cust-tooltip-txt delta']"),
	        "Engagement Delta Range Count"),

	/** The publishedpost daterange tooltip. */
	PUBLISHEDPOST_DATERANGE_TOOLTIP(
	        By.xpath("//div[@class='rc-tooltip-content']//div[@class='rc-tooltip-inner']//div[@class='common-tooltip--wrp']//span[@class='cust-tooltip-txt']"),
	        "Published Date Range and count"),

	/** The publishedpost delta count tooltip. */
	PUBLISHEDPOST_DELTA_COUNT_TOOLTIP(
	        By.xpath("//div[@class='rc-tooltip-content']//div[@class='rc-tooltip-inner']//div[@class='common-tooltip--wrp']//span[@class='cust-tooltip-txt delta']"),
	        "Published delta Value count"),

	/** The location selector byname. */
	LOCATION_SELECTOR_BYNAME("//div[contains(@class,'list-item')]//div[@class='lvt-details']//h3[contains(text(),'%s')]", "The Location Selector By name"),

	/** The locator selector name. */
	LOCATOR_SELECTOR_NAME("//span[@class='lcs-name' and contains(@title,'%s')]", "The Location selector Name"),

	/** The location selector all location button. */
	LOCATION_SELECTOR_ALL_LOCATION_BUTTON(By.xpath("//div[@class='all-locs']//label//input//following-sibling::span[text()='All Locations']"), "All location button"),

	/** The location selector close button. */
	LOCATION_SELECTOR_CLOSE_BUTTON(By.xpath("//img[@class='close-icon']"), "Location Selector Close Button"),

	/** The double digit calendar day. */
	DOUBLE_DIGIT_CALENDAR_DAY("(//div[contains(@class,'react-datepicker') and text()='%s'])[last()]", "Day of the Month"),

	/** The single digit calendar day. */
	SINGLE_DIGIT_CALENDAR_DAY("(//div[contains(@class,'react-datepicker')  and text()='%s'])[1]", "Day of the Month"),

	/** The day of the month. */
	DAY_OF_THE_MONTH("//div[contains(@class,'react-datepicker') and text()='%s']", "Day of the Month"),

	/** The line chart x axis labels. */
	LINE_CHART_X_AXIS_LABELS(By.xpath("//*[@class='highcharts-root']//*[@class='highcharts-axis-labels highcharts-xaxis-labels']//*"), "Line Chart X-axis labels"),

	/** The previous month. */
	PREVIOUS_MONTH_PICKER(By.xpath("//section[contains(@class,'filter')]//div[@class='react-datepicker']//button[@aria-label='Previous Month']"), "Previous month."),

	/** The next month. */
	NEXT_MONTH_PICKER(By.xpath("//section[contains(@class,'filter')]//div[@class='react-datepicker']//button[@aria-label='Next Month']"), "Next month."),

	/** The followers views delta grey symbol. */
	FOLLOWERS_VIEWS_DELTA_GREY_SYMBOL(By.xpath("//span[contains(text(),'Followers')]//parent::div[@class='card-content-top']//following-sibling::div//img[@alt='an-rating-grey']"),
	        "Followers Delta Grey Symbol"),

	/** The followers views delta green symbol. */
	FOLLOWERS_VIEWS_DELTA_GREEN_SYMBOL(
	        By.xpath("//span[contains(text(),'Followers')]//parent::div[@class='card-content-top']//following-sibling::div//img[@alt='an-ratings-up-green']"),
	        "Followers Delta Green Symbol"),

	/** The followers views delta red symbol. */
	FOLLOWERS_VIEWS_DELTA_RED_SYMBOL(By.xpath("//span[contains(text(),'Followers')]//parent::div[@class='card-content-top']//following-sibling::div//img[@alt='rating-down-red']"),
	        "Followers Delts Red symbol"),

	/** The engagement delta grey symbol. */
	ENGAGEMENT_DELTA_GREY_SYMBOL(
	        By.xpath("//span[contains(text(),'Avg Daily Post Engagement')]//parent::div[@class='card-content-top']//following-sibling::div//img[@alt='an-rating-grey']"),
	        "Avg Daily Post Engagement Delta grey Symbol"),

	/** The engagement delta green symbol. */
	ENGAGEMENT_DELTA_GREEN_SYMBOL(
	        By.xpath("//span[contains(text(),'Avg Daily Post Engagement')]//parent::div[@class='card-content-top']//following-sibling::div//img[@alt='an-ratings-up-green']"),
	        "Avg Daily Post Engagement Delta Green Symbol"),

	/** The engagement delta red symbol. */
	ENGAGEMENT_DELTA_RED_SYMBOL(
	        By.xpath("//span[contains(text(),'Avg Daily Post Engagement')]//parent::div[@class='card-content-top']//following-sibling::div//img[@alt='rating-down-red']"),
	        "Avg Daily Post Engagement Delta Red Symbol"),

	/** The published delta grey symbol. */
	PUBLISHED_DELTA_GREY_SYMBOL(By.xpath("//span[contains(text(),'Published Posts')]//parent::div[@class='card-content-top']//following-sibling::div//img[@alt='an-rating-grey']"),
	        "Published Posts Delta grey Symbol"),

	/** The published delta green symbol. */
	PUBLISHED_DELTA_GREEN_SYMBOL(
	        By.xpath("//span[contains(text(),'Published Posts')]//parent::div[@class='card-content-top']//following-sibling::div//img[@alt='an-ratings-up-green']"),
	        "Published Posts Delta green Symbol"),

	/** The published delta red symbol. */
	PUBLISHED_DELTA_RED_SYMBOL(By.xpath("//span[contains(text(),'Published Posts')]//parent::div[@class='card-content-top']//following-sibling::div//img[@alt='rating-down-red']"),
	        "Published Posts Delta Red Symbol"),

	/** The followers count table view. */
	FOLLOWERS_COUNT_TABLE_VIEW(By.xpath("//div[@class='profile-tbl-wrp resuseTable ']//ancestor::div//tbody//tr[1]//td[8]//div[@class='tbl-delta--wrp']//span[@class='value1']"),
	        "Followers Count In Table View"),

	/** The followers total table value. */
	FOLLOWERS_TOTAL_TABLE_VALUE(
	        By.xpath("//th//span[text()='Followers']//ancestor::table//tbody//td[text()='Totals']//following-sibling::td[1]//div[@class='tbl-delta--wrp']//span[@class='value1'] "),
	        "Followers Total Table Value"),
	
	/** The avg engagement total table value. */
	AVG_ENGAGEMENT_TOTAL_TABLE_VALUE(By.xpath(
	        "//th//span[text()='Avg Daily Post Engagement']//ancestor::table//tbody//td[text()='Totals']//following-sibling::td[2]//div[@class='tbl-delta--wrp']//span[@class='value1'] "),
	        "Avg Published Post Total Table Value"),

	/** The publishedpost total table value. */
	PUBLISHEDPOST_TOTAL_TABLE_VALUE(
	        By.xpath("//th//span[text()='Published Posts']//ancestor::table//tbody//td[text()='Totals']//following-sibling::td[3]//div[@class='tbl-delta--wrp']//span[@class='value1'] "),
	        "Published Post Total table Value"),

	/** The followers facebook table count. */
	FOLLOWERS_FACEBOOK_TABLE_COUNT(By.xpath(
	        "//span[text()='Followers']//ancestor::table//tbody//following-sibling::tbody//tr//span[text()='Facebook']//parent::div//parent::td//following-sibling::td[1]//span[@class='value1']"),
	        "Followers Facebook Table Count"),

	/** The followers instagram table count. */
	FOLLOWERS_INSTAGRAM_TABLE_COUNT(By.xpath(
	        "//span[text()='Followers']//ancestor::table//tbody//following-sibling::tbody//tr//span[text()='Instagram']//parent::div//parent::td//following-sibling::td[1]//span[@class='value1']"),
	        "Followers Instagram Table Count"),

	/** The followers twitter table count. */
	FOLLOWERS_TWITTER_TABLE_COUNT(By.xpath(
	        "//span[text()='Followers']//ancestor::table//tbody//following-sibling::tbody//tr//span[text()='Twitter']//parent::div//parent::td//following-sibling::td[1]//span[@class='value1']"),
	        "Followers Twitter Table count"),

	/** The followers linkedin table count. */
	FOLLOWERS_LINKEDIN_TABLE_COUNT(By.xpath(
	        "//span[text()='Followers']//ancestor::table//tbody//following-sibling::tbody//tr//span[text()='LinkedIn']//parent::div//parent::td//following-sibling::td[1]//span[@class='value1']"),
	        "Followers LinkedIn Table Count"),

	/** The avg postengagement facebook table count. */
	AVG_POSTENGAGEMENT_FACEBOOK_TABLE_COUNT(By.xpath("//th//span[text()='Avg Daily Post Engagement']//ancestor::table//tbody//following-sibling::tbody//tr//span[text()='Facebook']//parent::div//parent::td//following-sibling::td[2]//span[@class='value1']"),"AVg Engagement Facebook Table count"),
	
	/** The avg postengagement instagram table count. */
	AVG_POSTENGAGEMENT_INSTAGRAM_TABLE_COUNT(By.xpath("//th//span[text()='Avg Daily Post Engagement']//ancestor::table//tbody//following-sibling::tbody//tr//span[text()='Instagram']//parent::div//parent::td//following-sibling::td[2]//span[@class='value1']"),"AVg Engagement Instagram Table count"),
	
	/** The avg postengagement twitter table count. */
	AVG_POSTENGAGEMENT_TWITTER_TABLE_COUNT(By.xpath("//th//span[text()='Avg Daily Post Engagement']//ancestor::table//tbody//following-sibling::tbody//tr//span[text()='Twitter']//parent::div//parent::td//following-sibling::td[2]//span[@class='value1']"),"AVg Engagement Twitter Table count"),
	
	/** The avg postengagement linkedin table count. */
	AVG_POSTENGAGEMENT_LINKEDIN_TABLE_COUNT(By.xpath("//th//span[text()='Avg Daily Post Engagement']//ancestor::table//tbody//following-sibling::tbody//tr//span[text()='LinkedIn']//parent::div//parent::td//following-sibling::td[2]//span[@class='value1']"),"Avg Post Engagement linked table count"),

	
	/** The publishedpost facebook table count. */
	PUBLISHEDPOST_FACEBOOK_TABLE_COUNT(By.xpath("//th//span[text()='Published Posts']//ancestor::table//tbody//following-sibling::tbody//tr//span[text()='Facebook']//parent::div//parent::td//following-sibling::td[3]//span[@class='value1']"),"PublishedPost Facebook Table Count"),
	
	/** The publishedpost instagram table count. */
	PUBLISHEDPOST_INSTAGRAM_TABLE_COUNT(By.xpath("//th//span[text()='Published Posts']//ancestor::table//tbody//following-sibling::tbody//tr//span[text()='Instagram']//parent::div//parent::td//following-sibling::td[3]//span[@class='value1']"),"PublishedPost Instagram Table Count"),
	
	/** The publishedpost twitter table count. */
	PUBLISHEDPOST_TWITTER_TABLE_COUNT(By.xpath("//th//span[text()='Published Posts']//ancestor::table//tbody//following-sibling::tbody//tr//span[text()='Twitter']//parent::div//parent::td//following-sibling::td[3]//span[@class='value1']"),"PublishedPost Twitter Table Count"),
	
	/** The publishedpost linkedin table count. */
	PUBLISHEDPOST_LINKEDIN_TABLE_COUNT(By.xpath("//th//span[text()='Published Posts']//ancestor::table//tbody//following-sibling::tbody//tr//span[text()='L']//parent::div//parent::td//following-sibling::td[3]//span[@class='value1']"),"PublishedPost Linkedin Table Count"),
	
	
	/** The followers delta ranking grey symbol. */
	FOLLOWERS_DELTA_RANKING_GREY_SYMBOL(By.xpath("//span[text()='Followers']//ancestor::div[@class='grid-4']//div[@class='ranking']//div[@class='delta-wrp']//img[@alt='an-rating-grey']"),
	        "Followers Delta Grey Symbol"),

	/** The followers delta ranking green symbol. */
	FOLLOWERS_DELTA_RANKING_GREEN_SYMBOL(
	        By.xpath("//span[text()='Followers']//ancestor::div[@class='grid-4']//div[@class='ranking']//div[@class='delta-wrp']//img[@alt='an-ratings-up-green']"),
	        "Followers Delta Green Symbol"),

	/** The followers delta ranking red symbol. */
	FOLLOWERS_DELTA_RANKING_RED_SYMBOL(By.xpath("//span[text()='Followers']//ancestor::div[@class='grid-4']//div[@class='ranking']//div[@class='delta-wrp']//img[@alt='rating-down-red']"),
	        "Followers Delts Red symbol"),
	
	/** The engagement delta ranking grey symbol. */
	ENGAGEMENT_DELTA_RANKING_GREY_SYMBOL(
	        By.xpath("//span[text()='Avg Daily Post Engagement']//ancestor::div[@class='grid-4']//div[@class='ranking']//div[@class='delta-wrp']//img[@alt='an-rating-grey']"),
	        "Avg Daily Post Engagement Delta grey Symbol"),

	/** The engagement delta ranking green symbol. */
	ENGAGEMENT_DELTA_RANKING_GREEN_SYMBOL(
	        By.xpath("//span[text()='Avg Daily Post Engagement']//ancestor::div[@class='grid-4']//div[@class='ranking']//div[@class='delta-wrp']//img[@alt='an-ratings-up-green']"),
	        "Avg Daily Post Engagement Delta Green Symbol"),

	/** The engagement delta ranking red symbol. */
	ENGAGEMENT_DELTA_RANKING_RED_SYMBOL(
	        By.xpath("//span[text()='Avg Daily Post Engagement']//ancestor::div[@class='grid-4']//div[@class='ranking']//div[@class='delta-wrp']//img[@alt='rating-down-red']"),
	        "Avg Daily Post Engagement Delta Red Symbol"),

	/** The published delta ranking grey symbol. */
	PUBLISHED_DELTA_RANKING_GREY_SYMBOL(By.xpath("//span[text()='Published Posts']//ancestor::div[@class='grid-4']//div[@class='ranking']//div[@class='delta-wrp']//img[@alt='an-rating-grey']"),
	        "Published Posts Delta grey Symbol"),

	/** The published delta ranking green symbol. */
	PUBLISHED_DELTA_RANKING_GREEN_SYMBOL(
	        By.xpath("//span[text()='Published Posts']//ancestor::div[@class='grid-4']//div[@class='ranking']//div[@class='delta-wrp']//img[@alt='an-ratings-up-green']"),
	        "Published Posts Delta green Symbol"),

	/** The published delta ranking red symbol. */
	PUBLISHED_DELTA_RANKING_RED_SYMBOL(By.xpath("//span[text()='Published Posts']//ancestor::div[@class='grid-4']//div[@class='ranking']//div[@class='delta-wrp']//img[@alt='rating-down-red']"),
	        "Published Posts Delta Red Symbol"),
	
	/** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back To Top Button"),
	
	  /** The date picker. */
    DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(contains(@class,'outside-month'))]","Date Picker"),
    
    TOTAL_AVG_DAILY_POST_ENGAGEMENTLISTS(By.xpath("//div[@class='tf-left-col']//div[@class='active-tile list-group-item']//span[@class='tf-total-count']"),"Toatl Avg Daily Engagement List"),
    
	/** The table total days. */
	TABLE_TOTAL_DAYS(By.xpath("(//tbody//tr//td[text()='Totals']//following-sibling::td//div[@class='tbl-delta--wrp']//span[@class='value1'])"),"Table Total days");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new analytics tab social page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private AnalyticsTabSocialPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new analytics tab social page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private AnalyticsTabSocialPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return byLocator;
	}

	/**
	 * Gets the by xpath.
	 *
	 * @return the by xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}
}

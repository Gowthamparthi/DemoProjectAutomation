package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum ContentTabProfileImageryPageEnum.
 */
public enum ContentTabProfileImageryPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath(
	        "//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Profile Imagery']//ancestor::div//section[@class='item-g filter profile-imagery-filter']//preceding::div//section[@id='main-container-sec']//div[contains(@class,'profile-imagerylist')]"),
	        "Page load"),
	
	GRID_VIEW_ACTIVE_LOCATIONS(By.xpath(
			"//div[@class='masonry-grid']//div[@class='masonry-grid_column']//div[@class='m-item active']//span"),
			"Grid view Active Locations"),
	
	GRID_VIEW_LOCATION_BY_POSITION("(//div[@class='masonry-grid']//div//div[@class='m-item '])[%s]",
			"Grid view Location By position"),
	
	GRID_VIEW_ACTIVE_LOCATION_BY_POSITION("(//div[@class='masonry-grid']//div[@class='m-item active'])[%s]//div[@class='profile-img']//img",
			"Grid view Active Location By position"),
	
	GRID_VIEW_LOCATION_PROFILE_IMAGE_BY_POSITION("(//div[@class='masonry-grid_column']//div[contains(@class,'m-item')])[%s]//div[@class='profile-img']//img",
			"Grid view Location Profile Image By position"),
	
	GRID_VIEW_LOCATION_COVER_IMAGE_BY_POSITION("(//div[@class='profile-bg'])[%s]//img",
			"Grid view Location cover Image By position"),
	
	UPLOAD_IMAGE_PAGE(By.xpath(
			"//li[@class='nav-item']//button[contains(@id,'add_new_image')]//parent::li//following::li//button[contains(@id,'browse_images')]//ancestor::ul//following::div//div[@class='drag__drop--txt']"),
			"Upload Image page"),
	
	UPLOAD_IMAGE_PAGE_WITHOUT_IMAGES(By.xpath(
			"//li[@class='nav-item']//button[contains(@id,'add_new_image')]//parent::li//following::li//button[contains(@id,'browse_images')]//ancestor::ul//following::div//div[@class='drag__drop--txt']"),
			"Upload Image page Without Images"),
	
	UPLOAD_IMAGE_PAGE_WITH_IMAGE(By.xpath("//div[contains(@class,'assets-upload')]//div[@class='masonry-grid']//div[@class='m-item']//img[1]"),
			"Upload Image page With Image"),
	
	EXPECTED_IMAGE_BY_NAME("//span[text()='%s']//ancestor::div[@class='m-item  active ']",
			"Expected Image By Name"),
	
	UPLOAD_IMAGE_PAGE_CLEAR_BUTTON(By.xpath(
			"//div//button[text()='Clear']"),
			"Upload Image Button Clear Button"),
	
	UPLOADED_IMAGE_CLOSE_BUTTON(By.xpath(
			"//div[@class='masonry-grid']//div[contains(@class,'close')]"),
			"Upload Image Close Button"),
	
	UPLOADED_IMAGE_BACK_BUTTON(By.xpath(
			"//img[@alt = 'profile-img-close']//parent::div[@class='close']"),
			"Upload Image Back Button"),
	
	UPLOAD_IMAGE_PAGE_SEARCH_TAB(By.xpath(
			"//div[@class='react-tags__search-input']//input"),
			"Upload Image page Search Tab"),
	
	UPLOAD_IMAGE_PAGE_IMAGE_UPLOAD_TAB(By.xpath(
			"//div[contains(@id,'add_new_image')]//div//input"),
			"Upload Image Page Image Upload Tab"),
	
	SEARCH_RESULTS_ELEMENT(
			"//div[@class='masonry-grid'][1]//div[@class='m-ast-dtls']//div[@class='mast-prof-txt']//span[text()='%s']",
			"Search Results element"),
	
	UPLOAD_PAGE_BROWSE_BUTTON(By.xpath(
			"//button[@class='ac-btn ac-primary size-sm' and text()='Browse']"),
			"Upload Page browse Button"),
	
	UPLOAD_PAGE_BROWSE_IMAGES_TAB(By.xpath(
			"//button[@id='multi-images-tab-tab-browse_images']"),
			"UPLOAD_PAGE_BROWSE_IMAGES_TAB"),
	
	UPLOAD_PAGE_USE_IMAGE_BUTTON(By.xpath(
			"//div[@class='modal-content']//button[text()='Use Image']"),
			"Upload Page Use Image Button"),
	
	UPLOAD_PAGE_ENSURE_EDITING_PAGE(By.xpath(
			"//div[contains(@class,'modal profile-img-modal imgly-edit')]//div[text()='Would you like to edit this image before uploading it?']"),
			"Upload Page Ensure Editing Page"),
	
	UPLOAD_PAGE_ENSURE_EDITING_PAGE_YES_BUTTON(By.xpath(
			"//div[contains(@class,'modal profile-img-modal imgly-edit')]//parent::div//following::div[@class='modal-footer']//button[text()='Yes']"),
			"Upload Page Ensure Editing Page Yes button"),
	
	UPLOAD_PAGE_ENSURE_EDITING_PAGE_NO_BUTTON(By.xpath(
			"//div[contains(@class,'modal profile-img-modal imgly-edit')]//parent::div//following::div[@class='modal-footer']//button[text()='No']"),
			"Upload Page Ensure Editing Page No button"),
	
	UPLOADING_IMAGE_PIXEL_SIZE_ENSURING_PAGE(By.xpath(
			"//div[@class='sure-text' and text()='Does your image meet these standards and do you want to upload it now?']"),
			"Uploading Image Pixel Size Ensuring Page"),
	
	WATERMARK_EDIT_PAGE(By.xpath("//div[@id='editor']"),"Water Mark Edit Page"),
	
	WATERMARK_EDIT_VINTAGE_EFFECT(By.xpath("//div[@id='editor']//button[@aria-label='Vintage']"),"Water Mark Edit Vintage Effect"),

	WATERMARK_EDIT_VINTAGE_POLAROID_EFFECT(By.xpath("//div[@data-test='CardContainer']//div[@data-test='CategoryItemsContainer']//button[1]//div[text()='Polaroid']"),"Water Mark Edit Vintage-Polaroid Effect"),
	
	WATERMARK_EDIT_SAVE_BUTTON(By.xpath("//div[@id='editor']//button//div[text()='Save']"),"Water Mark Edit Save Button"),

	WATERMARK_EDITED_USAGE_CONFORMATION_PAGE(By.xpath("//div[@class='p-text-modal desc' and contains(text(),'Page profile pictures are square and display at ')]//following::div[@class='sure-text' and text()='Are you sure you want to use this image?']"),"Water Mark Edited usage conformation Page"),
	
	WATERMARK_EDITED_COVER_IMAGE_CONFORMATION_PAGE(By.xpath("//div[@class='p-text-modal desc' and contains(text(),'Cover photos are ')]//parent::div//div[text()='Does your image meet these standards and do you want to upload it now?']"),"WATERMARK_EDITED_COVER_IMAGE_CONFORMATION_PAGE"),

	UPLOAD_IMAGE_CONFORM_BUTTON(By.xpath("//div[@class='modal-footer']//div//button[text()='Confirm']"),"Water Mark Edited usage Conform Page"),
	
	PROFILE_UPDATED_POPUP(By.xpath("//span[text()='Got it! Your profile photo will be changed momenterily.']"),"Profile Updated Popup"),
	
	COVER_IMAGE_UPDATED_POPUP(By.xpath("//span[text()='Got it! Your cover photo will be changed momenterily.']"),"Profile Updated Popup"),

	WATERMARK_EDITED_CANCEL_BUTTON(By.xpath("//div[@class='modal-footer']//div//button[text()='Cancel']"),"Water Mark Edited Cancel button"),
	
	/** The clear all filter. */
	CLEAR_ALL_FILTER(By.xpath("//div[@class='filter-item clear-filter']//div//button"), "Clear all filter"),
	
	CLEAR_FILTER_DISABLED(By.xpath("//div[@class='filter-item clear-filter']//div[contains(@class,'events-none')]//button"), "Clear filter Disabled"),

	/** The platform filter. */
	PLATFORM_FILTER(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='filter-item']//h3[text()='Platform']"), "Platform filter"),

	/** The all filter button. */
	ALL_FILTER_BUTTON(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='fltr-imc selectsocial']//img[@alt='All']//parent::button"), "All filter button"),

	/** The all filter selected. */
	ALL_FILTER_SELECTED(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='fltr-imc selectsocial']//img[@alt='All']//parent::button[contains(@class,'active')]"),
	        "All filter selected"),

	/** The facebook filter button. */
	FACEBOOK_FILTER_BUTTON(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'fb-platform')]//parent::button"),
	        "Facebook filter button"),

	/** The facebook filter selected. */
	FACEBOOK_FILTER_SELECTED(By.xpath(
	        "//section[contains(@class,'item-g filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'fb-platform')]//parent::button[contains(@class,'active')]"),
	        "Facebook filter selected"),

	/** The twitter filter button. */
	TWITTER_FILTER_BUTTON(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'twitter-platform')]//parent::button"),
	        "Twitter filter button"),

	/** The twitter filter selected. */
	TWITTER_FILTER_SELECTED(By.xpath(
	        "//section[contains(@class,'item-g filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'twitter-platform')]//parent::button[contains(@class,'active')]"),
	        "Twitter filter selected"),
	
	TWITTER_PLATFORM_PROFILE_IMAGE(By.xpath(
	        "(//div[@class='profile-img__pos twitter'][1]//div[@class='profile-img']//img)[1]"),
	        "Twitter Platform profile Image"),

	/** The linkedin filter button. */
	LINKEDIN_FILTER_BUTTON(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'linkedin-platform')]//parent::button"),
	        "LinkedIn filter button"),

	/** The linkedin filter selected. */
	LINKEDIN_FILTER_SELECTED(
	        By.xpath("//section[contains(@class,'item-g filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'linkedin')]//parent::button[contains(@class,'active')]"),
	        "LinkedIn filter selected"),

	/** The instagram filter button. */
	INSTAGRAM_FILTER_BUTTON(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'instagram-platform')]//parent::button"),
	        "Instagram filter button"),

	/** The instagram filter selected. */
	INSTAGRAM_FILTER_SELECTED(By.xpath(
	        "//section[contains(@class,'item-g filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'instagram-platform')]//parent::button[contains(@class,'active')]"),
	        "Instagram filter selected"),

	/** The locations filter. */
	LOCATIONS_FILTER(By.xpath("//h3[text()='Locations']//parent::div[contains(@class,'filter-item')]"), "Locations filter"),

	/** The location dropdown. */
	LOCATION_DROPDOWN(By.xpath("//section[contains(@class,'item-g filter')]//h3[text()='Locations']//parent::div//div//span"), "Location dropdown"),

	/** The current location. */
	CURRENT_LOCATION(By.xpath("//section[contains(@class,'item-g filter')]//h3[text()='Locations']//parent::div//div//span"), "Current location"),

	/** The location dropdown searchtab. */
	LOCATION_DROPDOWN_SEARCHTAB(By.xpath("//div[@id='account-switcher-dropdown']//div//div"), "Search tab of locatio selection"),

	/** The locations filter modal. */
	LOCATIONS_FILTER_MODAL(By.xpath("//div[@class='modal-content']//div[@class='modal-body']"), "Locations filter modal"),

	/** The location. */
	LOCATION(By.xpath("//ul[@class='hub-list']//li//span[text()='Automation Location two']"), "Location"),

	/** The prod location. */
	PROD_LOCATION(By.xpath("//ul[@class='hub-list']//li//span[text()='Alex Kiss - 148 - Sylvania, OH']"), "Prod location"),

	/** The cancel button. */
	CANCEL_BUTTON(By.xpath("//div[contains(@class,'modal-footer')]//button[text()='Cancel']"), "Cancel button"),

	/** The ok button. */
	OK_BUTTON(By.xpath("//div[contains(@class,'modal-footer')]//button[text()='Ok']"), "Ok button"),

	/** The select all checkbox. */
	SELECT_ALL_CHECKBOX(By.xpath("//div[contains(@class,'select-all')]"), "Select all check box"),
	
	SELECT_ALL_CHECKBOX_ACTIVE(By.xpath("//span[@class='checkbox-hover']//input[@class='option-input click-wave checkbox active']"), "Select all check box Active"),

	/** The update profile images. */
	UPDATE_PROFILE_IMAGES(By.xpath("//button[contains(@class,'profile-btn ') and contains(text(),'Profile Image')]"), "Update profile images button"),
	
	NO_OF_LOCATIONS_SELECTED(
			"//button[@class='pi-update__btn profile-btn ' and contains(text(),'%s')]",
			"No Of Location Selected"),
	
	/** The update cover images. */
	UPDATE_COVER_IMAGES(By.xpath("//button[contains(@class,'cover-btn ') and contains(text(),'Cover Image')]"), "Update cover images button"),

	/** The contents list. */
	CONTENTS_LIST(By.xpath(
	        "//div[contains(@class,'masonry-list-view-group')]//div[contains(@class,'masonry-grid')]//div[contains(@class,'masonry-grid_column')]//div[contains(@class,'m-item')]"),
	        "Contents list"),
	
	/** The location selector button. */
	LOCATION_SELECTOR_BUTTON(By.xpath("//h3[text()='Location Selector']//following-sibling::div[@class='locAction']//span"), "Location selector button"),

	/** The location selector view. */
	LOCATION_SELECTOR_VIEW(By.xpath("//div[@class='modal-body']//h3[text()='Location Selector']//parent::div//parent::div//div[@class='asm-accord']"), "Location selector view"),

	/** The hubs dropdown. */
	HUBS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='accordion']//div[@class='card-header' and text()='Hubs']//parent::button"), "Hubs dropdown"),

	/** The location lists dropdown. */
	LOCATION_LISTS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='accordion']//div[@class='card-header' and text()='Location Lists']//parent::button"),
	        "LocationLists dropdown"),

	/** The locations dropdown. */
	LOCATIONS_DROPDOWN(By.xpath("//div[@class='card']//div//span[text()='Locations']"), "Locations dropdown"),

	/** The location selector dropdown list. */
	LOCATION_SELECTOR_DROPDOWN_LIST(By.xpath("//div[contains(@class,'collapse show')]//img[contains(@src,'location') and not(contains(@src,'Lists'))]"),
	        "Location selector dropdown list"),

	/** The location selector search. */
	LOCATION_SELECTOR_SEARCH(By.xpath("//h3[text()='Location Selector']//following-sibling::div//input[@name='Locations']"), "Location selector search"),

	/** The select dropdown list. */
	SELECT_DROPDOWN_LIST("//div//ul[@class='hub-list']//span[contains(text(),'%s')]",
	        "Select dropdown list"),

	/** The selected dropdown list. */
	SELECTED_DROPDOWN_LIST(
	        "//input[@name='selectedLocation']//following::div[@class='list-lbl cur-pointer']//span[contains(text(),'%s')]",
	        "Selected dropdown list"),

	/** The location selector cancel button. */
	LOCATION_SELECTOR_CANCEL_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Cancel']"), "Location selector cancel button"),

	/** The location selector ok button. */
	LOCATION_SELECTOR_OK_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Ok']"), "Location selector ok button"),
	
	/** The location selector hub tab. */
	LOCATION_SELECTOR_HUB_TAB(By.xpath("//div[@class='accordion-item']//div//span[text()='Hubs']"),
			"Location Selecter Hub tab."),

	/** The location selector hub tab open. */
	LOCATION_SELECTOR_HUB_TAB_OPEN(
			By.xpath("//div[@class='accordion']//div//div[contains(@class,'collapse show')]//div//ul[@class='hub-list']"),
			"Location Selecter Hub Tab Open."),

	/** The location selector location tab. */
	LOCATION_SELECTOR_LOCATION_TAB(By.xpath("//div[@class='accordion-item']//div//span[text()='Locations']"),
			"Location Selecter Location tab."),

	/** The location selector locationlist tab. */
	LOCATION_SELECTOR_LOCATIONLIST_TAB(By.xpath("//div[@class='accordion-item']//div//span[text()='Location Lists']"),
			"Location Selecter Location List tab."),

	/** The location selector location tab open. */
	LOCATION_SELECTOR_LOCATION_TAB_OPEN(
			By.xpath("//div[@class='accordion']//div[@class='card']//div[@class='collapse show']"),
			"Location Selecter Location Tab Open"),

	/** The list of hubs. */
	LIST_OF_HUBS(By.xpath(
			"//div[@class='card']//div[@class='collapse show']//ul[@class='hub-list']//li//label//span[contains(@class,'list')]"),
			"List of Hubs"),
	
	LIST_OF_LOCATIONS(By.xpath(
			"//div[@class='card']//div[@class='accordion-collapse collapse show']//ul[@class='hub-list']//li//label//span[contains(@class,'list')]"),
			"List of Locations"),
	
	/** The sortby dropdowns. */
	SORTBY_DROPDOWNS(
	        By.xpath("//div[text()='Sort by']//parent::div//parent::div//div[@class='sortby-list__wrp']//div[@class='ds-dropdown']//following-sibling::div[@class='ds-dropdown']"),
	        "Sortby dropdowns"),
	
	GRID_VIEW_LOCATIONS(By.xpath("//div//span[@class='loc-name']"),
			"GRID_VIEW_LOCATION_PREFIX"),
	
	GRID_VIEW_LOCATION_NAME_PREFIX(By.xpath("//span[@class='loc-name']//text()"),
			"GRID_VIEW_LOCATION_PREFIX"),
	
	FACEBOOK_PROFILE_PICTURE("(//*[@preserveAspectRatio='xMidYMid slice'])[1]",
			"FACEBOOK_PROFILE_PICTURE"),
	
	LOCATION_SELECTOR_BUTTON_HUB_COUNT(
			By.xpath("//h3[text()='Location Selector']//following-sibling::div[@class='locAction']//span//following-sibling::span"),
			"LOCATION_SELECTOR_BUTTON_HUB_COUNT"),
	
	LOCATION_SELECTOR_BUTTON_LOCATION_LIST_COUNT(
			By.xpath("//h3[text()='Location Selector']//following-sibling::div[@class='locAction']//span//following-sibling::span"),
			"LOCATION_SELECTOR_BUTTON_LOCATION_LIST_COUNT"),
	
	LOCATION_SELECTOR_LOCATION_LIST_TAB_OPEN(By.xpath("//img[contains(@src,'locationLists')]//ancestor::div[contains(@class,'collapse show')]"),
			"Location Selecter Location List tab Open"),
	
	FOOTER(By.xpath("//div[@class='m-item '][last()]"),"Footer"),
	
	/** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),
	
	GRID_VIEW_LOCATION_NAME_SUFFIX(By.xpath("//span[@class='loc-name']/text()[3]"),
			"GRID_VIEW_LOCATION_SUFFIX");

	/** The by locator.*/
	private By byLocator;

	/** The description.*/
	private String xpath, description;

	/**
	 * Instantiates a new content tab profile imagery page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private ContentTabProfileImageryPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new content tab profile imagery page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private ContentTabProfileImageryPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum ContentTabMediaGalleryPageEnum.
 */
public enum ContentTabMediaGalleryPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//li[@class='ripple active']//span[text()='Media']//ancestor::div//section[@class='item-g filter mg-filter mg-filter__main']//preceding::div[@class='g-centre']//div[@class='grid-infinity mg-list-view']"), "The page load"),

    // IMAGES_STATS_COUNT(By.xpath("//span[@class='sc-head' and
    // text()='Images']//following-sibling::span"), "Images stats count"),

    // VIDEOS_STATS_COUNT(By.xpath("//span[@class='sc-head' and
    // text()='Videos']//following-sibling::span"), "Videos stats count"),

	/** Search box. */
	SEARCH_BOX(By.xpath("//div[contains(@class,'react-tags__search-input')]//input[@placeholder='Search text']"), "Search box"),

	/** Search tag box. */
	SEARCH_TAGS(By.xpath("//div[contains(@class,'react-tags__search-wrapper')]//input[@placeholder='Search tags']"), "Search tag box"),


	/** Search result. */
	SEARCH_RESULT("//div[@class='mast-prof-txt']//span[text()='%s']", "Search result"),

	/** The common media. */
	COMMON_MEDIA(By.xpath("//div[contains(@class,'masonry-list-view-group')]//div[contains(@class,'m-item')]//span[@class='sm-txt-top' and text()]"), "Common media"),

	/** The media uses count. */
	MEDIA_USES_COUNT("//span[@class='sm-txt-top' and text()='%s']//following-sibling::span//span[@class='mlg-count']", "Media uses count"),

	/** The media uses count list. */
	MEDIA_USES_COUNT_LIST(By.xpath("//span[@class='sm-txt-top']//following-sibling::span//span[@class='mlg-count']"), "Media uses count list"),

	/** The media usage filter used count value */
	USAGE_FILTER_USED_COUNT(By.xpath("//label//input[@value='used']//following-sibling::span[@class='labelText' and text()]"), "Media uses count list"),

	/** Media like button. */
	MEDIA_LIKE_BUTTON("//span[@class='sm-txt-top' and text()='%s']//ancestor::div[contains(@class,'m-item')]//img[@alt='Like']", "Media like button"),
	
	/** Media dislike button. */
	MEDIA_DISLIKE_BUTTON("//span[@class='sm-txt-top' and text()='%s']//ancestor::div[contains(@class,'m-item')]//div[@class='lb-btn lb-unlike']//img[@alt='Unlike']", "Media dislike button"),

	/** Media liked. */
	MEDIA_LIKED("", "Media liked"),

	/** Media disliked. */
	MEDIA_DISLIKED("", "Media disliked"),

	/** Media Use button. */
//	MEDIA_USE_BUTTON("//div[@class='m-ast']//following-sibling::div[@class='m-ast-dtls']//div[@class='mast-prof-txt']//span[@class='sm-txt-top' and text()='%s']//ancestor::div[contains(@class,'m-item')]//following-sibling::div[@class='mic-actions']//div//img[@alt='Share']", "Media Use button"),
	MEDIA_USE_BUTTON("//div[@class='mastg-main']//span[@class='sm-txt-top' and text()='%s']//ancestor::div[contains(@class,'m-item')]//div[@class='mic-actions']//img[@alt='Share']", "Media Use button"),

	/** Media delete button. */
	MEDIA_DELETE_BUTTON(By.xpath("//span[@class='sm-txt-top']//ancestor::div[contains(@class,'m-item')]//img[@alt='Delete']"), "Media delete button"),

	/** The media delete button field. */
	MEDIA_DELETE_BUTTON_FIELD("//span[@class='sm-txt-top' and text()='%s']//ancestor::div[contains(@class,'m-item')]//img[@alt='Delete']","MEDIA Delet Button"),
	
	/** Media download button. */
	MEDIA_DOWNLOAD_BUTTON("//div[@class='m-ast']//following-sibling::div[@class='m-ast-dtls']//div[@class='mast-prof-txt']//span[@class='sm-txt-top' and text()='%s']//ancestor::div[contains(@class,'m-item')]//following-sibling::div[@class='mic-actions']//div//img[@alt='Download']", "Media download button"),

	/** Media download release button. */
	MEDIA_DOWNLOAD_RELEASE_BUTTON("//span[@class='sm-txt-top' and text()='%s']//ancestor::div[contains(@class,'m-item')]//img[@alt='Export']", "Media download release button"),

	/** The media detailed view button. *//*
	MEDIA_DETAILED_VIEW_BUTTON("//span[@class='sm-txt-top' and text()='%s']//ancestor::div[contains(@class,'m-item')]//img[@alt='Open Detailed View']", "Media detailedView button"),
*/
	MEDIA_DETAILED_VIEW_BUTTON("//span[@class='sm-txt-top' and text()='%s']//ancestor::div[contains(@class,'m-item')]//img[@alt='Open Detailed View']", "Media detailedView button"),

	/** Media AI button. */
	MEDIA_AI_BUTTON("//div[@class='mastg-main']//span[@class='sm-txt-top' and text()='%s']//ancestor::div[@class='masonry-grid_column']//img[@alt='AI']", "Media AI button"),


	/** The most first media detailed view button. */
	MOST_FIRST_MEDIA_DETAILED_VIEW_BUTTON(By.xpath("//div[@class='mc-expand']//img[@alt='Open Detailed View']"), "MOST_FIRST_MEDIA_DETAILED_VIEW_BUTTON"),

	/** Media Delete alertbox. */
	MEDIA_DELETE_ALERTBOX(By.xpath("//div[text()='Are you sure?']"), "Media Delete alertbox"),

	/** Delete alert cancel button. */
	DELETE_ALERT_CANCEL_BUTTON(By.xpath("//div[contains(@class,'delete')]//button[contains(@class,'ac-btn ac-secondary-white ac-outline') and text()='Cancel']"), "Delete alert cancel button"),

	/** Delete alert delete button. */
	DELETE_ALERT_DELETE_BUTTON(By.xpath("//div[contains(@class,'delete')]//button[contains(@class,'ac-danger ac-btn') and text()='Delete']"), "Delete alert delete button"),

	/** Media deleted message. */
	MEDIA_DELETED_MESSAGE(By.xpath("//span[text()='Asset deleted']"), "Media deleted message"),

	/** The media deletion denied. */
	MEDIA_DELETION_DENIED(By.xpath("//span[text()='You are denied to delete the asset']"), "Media deletion denied"),

	/** Upload file. */
	UPLOAD_FILE(By.xpath("//div[contains(@class,'mediaGallery mg__main')]//input[@type='file']"), "Upload file"),

	UPLOAD_SECTION_UPLOAD_FILE(By.xpath("//div[contains(@class,'mg-upload mg-upload__main')]//input[@type='file']"),"Upload Section Upload File"),

	/** The media upload section. */
	MEDIA_UPLOAD_SECTION(By.xpath("//div[@class='drag__drop--txt']//following-sibling::div//button[text()='Browse']"),
	        "Media upload section"),

	UPLOAD_SECTION_APPLY_SETTING_INDIVIDUALLY(By.xpath("//span[text()='Apply Settings Individually']//parent::label//input"),"APPLY_SETTING_INDIVIDUALLY"),

	UPLOAD_SECTION_IMAGE_LIST(By.xpath("//div[@class='mg-upload__view']//div[@class='masonry-grid']//div[@class='m-item']"),"UPLOAD_SECTION_IMAGE_LIST"),

    UPLOAD_SECTION_EXPIRATION_CUSTOM(By.xpath("//div[text()='Expiration']//parent::div//div[@class='mExpMainRight']//span[text()='Custom']//parent::label//input"),"UPLOAD_SECTION_EXPIRATION_CUSTOM"),

	UPLOAD_SECTION_START_DATE_HERE(By.xpath("//div[text()='Expiration']//parent::div//div[@class='mExpBase']//div[@class='react-datepicker-wrapper']//input"),"Upload Section Start Date Here"),

	UPLOAD_SECTION_IMAGE_NAME(By.xpath("//div[@class='mg-upload__view']//div[@class='masonry-grid']//div[@class='mast-prof-txt']//span[@class='sm-txt-top']"),"Upload Section Image Path"),

	UPLOAD_SECTION_APPLY_SETTING_TABLE_HEADERS("//div[@class='mg-upload__view']//div[@class='msrTable msr-imgactive']//th[text()='%s']","Upload Section Apply Setting Table Headers"),

	SETTING_INDIVIDUAL_SELECTED_DATE(By.xpath("//div//div[@class='mExpBase']//div[@class='react-datepicker-wrapper']//input"),"Setting Individual Selected Date"),

	SETTING_INDIVIDUAL_AVAILABILITY_ACTIVE("//span[contains(@title,'%s')]//ancestor::div[@class='masonry-grid']//parent::td//parent::tr//div[text()='Availability']//parent::td//span[text()='%s']//parent::label[contains(@class,'active')]//input","Availability Active"),

	SETTING_INDIVIDUAL_AVAILABILITY_INACTIVE("//span[contains(@title,'%s')]//ancestor::div[@class='masonry-grid']//parent::td//parent::tr//div[text()='Availability']//parent::td//span[text()='%s']//parent::label//input","Setting Individual Availability Inactive"),

	SETTING_INDIVIDUAL_IMAGE_EDITING_ACTIVE("//span[contains(@title,'%s')]//ancestor::div[@class='masonry-grid']//parent::td//parent::tr//div[text()='Image Editing']//parent::td//span[text()='%s']//parent::label[contains(@class,'active')]//input","Setting Individual Image Editing Active"),

	SETTING_INDIVIDUAL_IMAGE_EDITING_INACTIVE("//span[contains(@title,'%s')]//ancestor::div[@class='masonry-grid']//parent::td//parent::tr//div[text()='Image Editing']//parent::td//span[text()='%s']//parent::label//input","Setting Individual Image Editing Inactive"),

	SETTING_INDIVIDUAL_SELECT_DATE_HERE_BUTTON("//span[contains(@title,'%s')]//ancestor::div[@class='masonry-grid']//parent::td//parent::tr//div[text()='Expiration']//parent::td//span[text()='%s']//ancestor::div[@class='mExpMainRight']//div[@class='react-datepicker__input-container']//input[@placeholder='Select Date here']","Setting Individual Select Date Here Button"),

	SETTING_INDIVIDUAL_ADD_MEDIA_RELEASE_BUTTON("//span[contains(@title,'%s')]//ancestor::div[@class='masonry-grid']//parent::td//parent::tr//div[text()='Media Release']//parent::td//button[text()='Add' and text()=' Media Release']","Setting Individual Add Media Release Button"),

	SETTING_INDIVIDUAL_EXPIRATION_ACTIVE("//span[contains(@title,'%s')]//ancestor::div[@class='masonry-grid']//parent::td//parent::tr//div[text()='Expiration']//parent::td//span[text()='%s']//parent::label[contains(@class,'active')]//input","Setting Individual Expiration Active"),

	SETTING_INDIVIDUAL_EXPIRATION_INACTIVE("//span[contains(@title,'%s')]//ancestor::div[@class='masonry-grid']//parent::td//parent::tr//div[text()='Expiration']//parent::td//span[text()='%s']//parent::label//input","Setting Individual Expiration Inactive"),

	SETTING_INDIVIDUAL_MEDIA_RELEASE_ACTIVE("//span[contains(@title,'%s')]//ancestor::div[@class='masonry-grid']//parent::td//parent::tr//div[text()='Media Release']//parent::td//span[text()='%s']//parent::label[contains(@class,'active')]//input","Setting Individual Media Release Active"),

	SETTING_INDIVIDUAL_MEDIA_RELEASE_INACTIVE("//span[contains(@title,'%s')]//ancestor::div[@class='masonry-grid']//parent::td//parent::tr//div[text()='Media Release']//parent::td//span[text()='%s']//parent::label//input","Setting Individual Media Release Inactive"),

	DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]","Date Picker"),

	ADD_MEDIA_RELEASE_BUTTON(By.xpath("//div[@class='mExpMainRight']//button[text()='Add' and text()=' Media Release']"),"Add Media Release Button"),

	MEDIA_RELEASE_DETAILVIEW_PRINT_NAME(By.xpath("//span[text()='Print Name']//parent::div[@class='form-group form-field-item stf-item']//input"), "Media Release Detail View Print Name"),

	MEDIA_RELEASE_SIGNATURE_UPLOAD_AREA(By.xpath("//html//body//div[5]//div//div//div[3]//div[2]//div//div[2]//div[2]//canvas"), "Signature Upload Area"),

	MEDIA_RELEASE_SIGNATURE_ADD_BUTTON(By.xpath("//div[@class='react-ripples ac-primary-box']//span[text()='Add']"), "Signature Add Button"),

	MEDIA_RELEASE_SIGNATURE_ADDED(By.xpath("//div[@class='modal-content']//div[@class='mr-sign-wrap ']"),"Signature Added"),

	MEDIA_RELEASE_SIGNATURE_DONE_BUTTON(By.xpath("//div[@class='react-ripples ac-primary-box']//span[text()='Done']"), "Signature Done Button"),

	MEDIA_RELEASE_YES_CHECKBOX_ACTIVE(By.xpath("//span[text()='Yes']//parent::label[contains(@class,'active')]//input"),"Media Release Yes Checkbox Active"),

	/** The Drag and drop text. */
	DRAG_AND_DROP_TEXT(By.xpath("//div[@class='drag__drop--txt']//span[text()='Drag & Drop your files here to upload (Select video up to 500 MB)']"),
			"The Drag and drop text."),

	/** The media add button. */
	MEDIA_ADD_BUTTON(By.xpath("//div[contains(@class,'media__browse')]//button[contains(@class,'btn btn-primary') and text()='Add' and not(@disabled)]"), "Media Add button"),


	/** Media added success message. */
	MEDIA_ADDED_SUCCESS_MESSAGE(By.xpath("//span[text()='Asset added successfully!']"), "Media added success message"),

	MEDIA_ASSETS_ADDED_SUCCESSFULLY_POPUP(By.xpath("//span[text()='Assets added successfully!']"),"Media Assets Added Successfully Popup"),

    // FROM_DATE(By.xpath("//div[@class='fltrdt fltrFdate']//input"), "From
    // date"),

    // SELECT_FROM_DATE("//div[@class='fltrdt
    // fltrFdate']//div[contains(@aria-label,'%s') and @aria-disabled='false']",
    // "Select from date"),

    // TO_DATE(By.xpath("//div[@class='fltrdt fltrTdate']//input"), "To date"),

    // SELECT_TO_DATE("//div[@class='fltrdt
    // fltrTdate']//div[contains(@aria-label,'%s') and @aria-disabled='false']",
    // "Select to date"),

    // CALENDAR_PREVIOUS_MONTH_BUTTON(By.xpath("//div[@class='react-datepicker__tab-loop']//button[text()='Previous
    // Month']"), "Calendar previous month button"),

    // CALENDAR_NEXT_MONTH_BUTTON(By.xpath("//div[@class='react-datepicker__tab-loop']//button[text()='Next
    // Month']"), "Calendar next month button"),

    // SELECT_DATE(By.xpath("//div[@class='react-datepicker__week']//div[@aria-disabled='false']"),
    // "Select date"),

	/** Images filter. */
	IMAGES_FILTER(By.xpath("//input[@type='radio']//following-sibling::span[text()='Image']"), "Images filter"),

	/** Videos filter. */
	VIDEOS_FILTER(By.xpath("//input[@type='radio']//following-sibling::span[text()='Video']"), "Videos filter"),

	/** Documents filter. */
	DOCUMENTS_FILTER(By.xpath("//input[@type='radio']//following-sibling::span[text()='Documents']"), "Documents filter"),
	
	/** The selected Documents filter. */
	SELECTED_DOCUMENTS_FILTER(By.xpath("//label[@class='active']//input[@type='radio']//following-sibling::span[text()='Documents']"), "Selected Documents filter"),
	
	/** The usage all filter. */
	USAGE_ALL_FILTER(By.xpath("//input[@name='post_used-Usage']//following-sibling::span[contains(text(),'All')]"), "Usage All filter"),

	/** The usage all filter active. */
	USAGE_ALL_FILTER_ACTIVE(By.xpath("//label[@class='active']//input[@name='post_used-Usage']//following-sibling::span[contains(text(),'All')]"), "USAGE_ALL_FILTER_ACTIVE"),

	/** Used filter. */
	USED_FILTER(By.xpath("//input[@name='post_used-Usage']//following-sibling::span[contains(text(),'Used')]"), "Used filter"),

	/** Unused filter. */
	UNUSED_FILTER(By.xpath("//input[@name='post_used-Usage']//following-sibling::span[contains(text(),'Unused')]"), "Unused filter"),
	
	/** The newly added filter. */
	NEWLY_ADDED_FILTER(By.xpath("//input[@name='post_used']//following-sibling::span[text()='Newly Added']"), "Newly added filter"),

	SOURCE_FILTER_COUNT_LIST(By.xpath("//h3[text()='Source']//parent::div//label//input//following-sibling::span[text()]"),"Source Filter Count List"),

	/** Brand media filter. */
	BRAND_MEDIA_FILTER(By.xpath("//input[@name='source-Source']//following-sibling::span[contains(text(),'Brand')]"), "Brand media filter"),

	BRAND_MEDIA_FILTER_ACTIVE(By.xpath("//label[@class='active']//input[@name='source-Source']//following-sibling::span[contains(text(),'Brand')]"), "Brand media filter"),

	CONTENT_SUPPLIER_FILTER(By.xpath("//div[@class='filter-item']//span[contains(text(),'Content Supplier')]"), "Content Supplier filter"),

	/** The media detailview brandname. */
	MEDIA_DETAILVIEW_BRANDNAME(By.xpath("//span[@class='wbf-label' and text()='Brand']"),"Media Brand Name"),
	
	/** The media detailview location name. */
	MEDIA_DETAILVIEW_LOCATION_NAME(By.xpath("//span[@class='wbf-label' and text()='Location']"),"Media Location Name"),

	/** The media detailview Hub name. */
	MEDIA_DETAILVIEW_HUB_NAME(By.xpath("//span[@class='wbf-label' and text()='Hub']"),"Media Hub Name"),


	/** The uploadedon date. */
	UPLOADEDON_DATE(By.xpath("//span[text()='Uploaded on']//parent::div//following-sibling::div[text()]"),"Uploaded on Date"),
	
	/** Location media filter. */
	LOCATION_MEDIA_FILTER(By.xpath("//input[@name='source-Source']//following-sibling::span[contains(text(),'Location')]"), "Location media filter"),

	LOCATION_MEDIA_FILTER_ACTIVE(By.xpath("//label[@class='active']//input[@name='source-Source']//following-sibling::span[contains(text(),'Location')]"), "Location media filter Active"),

	/** MediaSource All filter. */
	MEDIA_SOURCE_ALL_FILTER(By.xpath("//input[@name='source-Source']//following-sibling::span[contains(text(),'All')]"), "MediaSource All filter"),

	/** The media source all filter active. */
	MEDIA_SOURCE_ALL_FILTER_ACTIVE(By.xpath("//label[@class='active']//input[@name='source-Source']//following-sibling::span[contains(text(),'All')]"), "MEDIA_SOURCE_ALL_FILTER_ACTIVE"),

	/** The modal release all filter. */
	MODAL_RELEASE_ALL_FILTER(By.xpath("//input[@name='media_release-Model Release Form']//following-sibling::span[text()='All']"), "ModalRelease All filter"),

	/** The modal release all filter active. */
	MODAL_RELEASE_ALL_FILTER_ACTIVE(By.xpath("//label[@class='active']//input[@name='media_release-Model Release Form']//following-sibling::span[text()='All']"), "MODAL_RELEASE_ALL_FILTER"),

	/** With model release filter. */
	WITH_MODEL_RELEASE_FILTER(By.xpath("//input[@name='media_release-Model Release Form']//following-sibling::span[text()='With']"), "With model release filter"),

	/** Without model release filter. */
	WITHOUT_MODEL_RELEASE_FILTER(By.xpath("//input[@name='media_release-Model Release Form']//following-sibling::span[text()='Without']"), "Without model release filter"),

	/** Model release Data */
	MODEL_RELEASE_DATA(By.xpath("//div[@class='masonry-grid_column']//div[@class='mic-actions']//div//img[@alt='Export' and @class='mic__export--icon']"), "With model release data"),

	/** Without Model release Data */
	WITHOUT_MODEL_RELEASE_DATA(By.xpath("//div[@class='masonry-grid_column']//div[@class='mic-actions']//div//img[@alt='Export' and @class='events-none pointer-events-none mic__export--icon']"), "Without model release data"),


	/** Clear filter button. */
	CLEAR_FILTER_BUTTON(By.xpath("//div[@class='react-ripples ac-primary-box' and not(contains(@class,'pointer-events-none'))]//button//span[text()='Clear Filter']"),
	        "Clear filter button"),

	/** The clear filter section. */
	CLEAR_FILTER_SECTION(By.xpath("//button//span[text()='Clear Filter']"), "Clear filter section"),

	/** Media list. */
	MEDIA_LIST(By.xpath("//div[@class='infinite-scroll-component local-ini']//div[contains(@class,'m-item')]"), "Media list"),

	/** Image filter items. */
	IMAGE_FILTER_ITEMS(By.xpath("//div[contains(@class,'m-item')]//div[@class='m-ast']//img"), "Image filter items"),

	/** Video filter items. */
	VIDEO_FILTER_ITEMS(By.xpath("//div[contains(@class,'m-item')]//div[@class='m-ast']//div[@class='video-outer-element']"), "Video filter items"),
	
	/** Document filtered items. */
	DOCUMENT_FILTERED_ITEMS(By.xpath("//div[contains(@class,'m-item')]//div[@class='m-ast']//img[contains(@src,list_document)]"), "Document filtered items"),

	/** Newest First filter. */
	NEWEST_FIRST_FILTER(By.xpath("//label//input[@name='sort_by-Sort By' and @value='newest_first']"), "The Newest First filter"),

	/** Oldest First filter. */
	OLDEST_FIRST_FILTER(By.xpath("//label//input[@name='sort_by-Sort By' and @value='oldest_first']"), "The Oldest First filter"),

	/** Alphabetical filter. */
	ALPHABETICAL_FILTER(By.xpath("//label//input[@name='sort_by-Sort By' and @value='alphabetical']"), "The Alphabetical filter"),

	/** Reverse Alphabetical filter. */
	REVERSE_ALPHABETICAL_FILTER(By.xpath("//label//input[@name='sort_by-Sort By' and @value='reverse_alphabetical']"), "The Reverse Alphabetical filter"),

	/** Rating Filter. */
	RATING_ALL_FILTER(By.xpath("//label//input[@name='rating-Rating' and @value='all']"),"Rating All Filter"),
	
	/** The rating liked filter. */
	RATING_LIKED_FILTER(By.xpath("//label//input[@name='rating-Rating' and @value='liked']"),"Rating Liked Filter"),
	
	/** The rating disliked filter. */
	RATING_DISLIKED_FILTER(By.xpath("//label//input[@name='rating-Rating' and @value='disliked']"),"Rating Disliked Filter"),
	
	/** The rating unrated filter. */
	RATING_UNRATED_FILTER(By.xpath("//label//input[@name='rating-Rating' and @value='unrated']"),"Rating Unrated Filter"),

	/** Footer. */
	FOOTER(By.xpath("//div[contains(@class,'m-item')][last()]"), "Footer"),

	/** The no data to show. */
	NO_DATA_TO_SHOW(By.xpath("//div[@class='no-data']//span[text()='No data to show']"), "No data to show"),

	/** The media detailed view saveAll button. */
	MEDIA_DETAILED_VIEW_SAVE_ALL_BUTTON(By.xpath("//div[contains(@class,'btn-wrp-separate')]//button[text()='Save All']"), "MediaDetailedView saveAll button"),

	/** The media detailed view cancel button. */
	MEDIA_DETAILED_VIEW_CANCEL_BUTTON(By.xpath("//div[contains(@class,'btn-wrp-separate')]//button[text()='Cancel']"), "MediaDetailedView cancel button"),

	/** The favourite tags list. */
	FAVOURITE_TAGS_LIST(By.xpath("//h3[text()='Favorite Tags']//parent::div//following-sibling::div[@class='fts']//span"), "Favourite tags list"),

	/** The save all button. */
	SAVE_ALL_BUTTON(By.xpath("//div//button[text()='Save All']"), "The Save All button"),

	/** ***New Enums***. */
	IMAGE_FILTER_CHECKBOX(By.xpath("//span[text()='Image']//ancestor::label[@class='active']//input[@type='radio']"), "The image filter checkbox is active"),

	/** The video filter checkbox. */
	VIDEO_FILTER_CHECKBOX(By.xpath("//span[text()='Video']//ancestor::label[@class='active']//input[@type='radio']"), "The video filter checkbox is active"),

	/** The newly added checkbox. */
	NEWLY_ADDED_CHECKBOX_ACTIVE(By.xpath("//span[contains(text(),'Newly Added')]//ancestor::label[@class='active']//input[@type='radio']"), "The Newly added checkbox is active "),

	/** The newly added usage filter. */
	NEWLY_ADDED_USAGE_FILTER(By.xpath("//input[@name='post_used-Usage']//following-sibling::span[contains(text(),'Newly Added')]"), "The newly added filter "),

	/** The assert owner denied. */
	ASSERT_OWNER_DENIED(By.xpath("//span[text()='The asset owner has locked this content.']"), "The assert owner Denied"),

	/** The image list. */
	IMAGE_LIST(By.xpath("//div[@class='m-ast-dtls']//ancestor::div[contains(@class,'m-item')]"), "The size of image "),

	/** The browse input. */
	BROWSE_INPUT(By.xpath("//div[contains(@class,'mediaGallery mg__main')]//input[@type='file']"), "The click the browse button"),

	/** The watermark button. */
	WATERMARK_BUTTON(By.xpath("//div[contains(@class,'fi-item fi-watermark')]//div[@class='fi-icons']//following-sibling::span[text()='Watermark']"), "The click watermark"),


	/** The watermark pageload. */
	WATERMARK_PAGELOAD(By.xpath("//h1[text()='Watermark']//parent::div[@data-test='ToolControlBar']"),"The watermark pageload"),
	
	/** The watermark transform. */
	WATERMARK_TRANSFORM(
	        By.xpath("//div[@data-test='EditorContainer']//div[@direction='vertical']//li//button[@aria-label='Transform']"),
	        "The click Watermark transform button"),

	/** The transform pageload. */
	TRANSFORM_PAGELOAD(By.xpath("//div[@data-test='ToolControlBar']//h1[text()='Transform']"), "The Transform Pageload"),

	/** The common custom filter. */
	COMMON_CUSTOM_FILTER(By.xpath("//div[@class='sc-ckCjom btEdtF']//h2[text()='Common']//ancestor::div//button[@data-test='Custom']//div[@data-test='CardLabel']"),
	        "The click common custom"),

	/** The common square filter. */
	COMMON_SQUARE_FILTER(By.xpath("(//h2[@data-test='Common']//ancestor::div[@direction='vertical']//div[text()='Custom']//following::button//div[text()='Square'])[1]"),
	        "The common square click"),

	/** The common fourthree filter. */
	COMMON_FOURTHREE_FILTER(By.xpath("//h2[@data-test='Common']//ancestor::div[@direction='vertical']//div[text()='Custom']//following::button//div[text()='4:3']"),
	        "The common ratio 4.3 click"),

	/** The common sixteennine filter. */
	COMMON_SIXTEENNINE_FILTER(By.xpath("//h2[@data-test='Common']//ancestor::div[@direction='vertical']//div[text()='Custom']//following::button//div[text()='16:9']"),
	        "The common ratio 16:9 filter click"),

	/** The common threefour filter. */
	COMMON_THREEFOUR_FILTER(By.xpath("//h2[@data-test='Common']//ancestor::div[@direction='vertical']//div[text()='Custom']//following::button//div[text()='3:4']"),
	        "The common ratio 3:4 filter click"),

	/** The common ninesixteen filter. */
	COMMON_NINESIXTEEN_FILTER(By.xpath("//h2[@data-test='Common']//ancestor::div[@direction='vertical']//div[text()='Custom']//following::button//div[text()='9:16']"),
	        "The common 9:16 filter click"),

	/** The facebook profile filter. */
	FACEBOOK_PROFILE_FILTER(By.xpath("//div[@class='sc-ckCjom btEdtF']//h2[text()='Facebook']//following-sibling::div//button[@data-test='Profile']"), "The facebok profile filter"),

	/** The facebook title filter. */
	FACEBOOK_TITLE_FILTER(By.xpath("//div[@class='sc-ckCjom btEdtF']//h2[text()='Facebook']//following-sibling::div//button[@data-test='Title']"), "The facebook title filter"),

	/** The facebook post filter. */
	FACEBOOK_POST_FILTER(By.xpath("//div[@class='sc-ckCjom btEdtF']//h2[text()='Facebook']//following-sibling::div//button[@data-test='Post']"), "The facebook post filter"),

	/** The instagram landscape filter. */
	INSTAGRAM_LANDSCAPE_FILTER(By.xpath("//div[@class='sc-ckCjom btEdtF']//h2[text()='Instagram']//following-sibling::div//button[@data-test='Landscape']"),
	        "The Instagram landscape filter"),

	/** The instagram potrait filter. */
	INSTAGRAM_POTRAIT_FILTER(By.xpath("//div[@class='sc-ckCjom btEdtF']//h2[text()='Instagram']//following-sibling::div//button[@data-test='Portrait']"),
	        "The instagram portarit filter"),

	/** The instagram square filter. */
	INSTAGRAM_SQUARE_FILTER(By.xpath("//div[@class='sc-ckCjom btEdtF']//h2[text()='Instagram']//following-sibling::div//button[@data-test='Square']"),
	        "The instagram square filter"),

	/** The twitter post filter. */
	TWITTER_POST_FILTER(By.xpath("//div[@class='sc-ckCjom btEdtF']//h2[text()='Twitter']//following-sibling::div//button[@data-test='Post']"), "The Twitter Post filter"),

	/** The twitter profile filter. */
	TWITTER_PROFILE_FILTER(By.xpath("//div[@class='sc-ckCjom btEdtF']//h2[text()='Twitter']//following-sibling::div//button[@data-test='Profile']"), "The twitter Profile filter"),

	/** The Twitter TITL E FILTER. */
	Twitter_TITLE_FILTER(By.xpath("//div[@class='sc-ckCjom btEdtF']//h2[text()='Twitter']//following-sibling::div//button[@data-test='Title']"), "The Twitter title filter"),

	/** The flip horizontal options. */
	FLIP_HORIZONTAL_OPTIONS(By.xpath("//div[@class='sc-ikjQzJ gucvlV']//button[@data-test='Flip Horizontal']"), "The filp horizontal"),

	/** The flip vertical option. */
	FLIP_VERTICAL_OPTION(By.xpath("//div[@class='sc-ikjQzJ gucvlV']//button[@data-test='Flip Vertical']"), "The filp vertical"),

	/** The rotate clockwise options. */
	ROTATE_CLOCKWISE_OPTIONS(By.xpath("//div[@class='sc-ikjQzJ gucvlV']//button[@data-test='Rotate Clockwise']"), "The rotate clockwise"),

	/** The rotate counterclockwise option. */
	ROTATE_COUNTERCLOCKWISE_OPTION(By.xpath("//div[@class='sc-ikjQzJ gucvlV']//button[@data-test='Rotate Counterclockwise']"), "The rotate counter clockwise"),

	/** The reset to default. */
	RESET_TO_DEFAULT(By.xpath("//button[@data-test='Reset to default']//div[text()='Reset to default']"), "The reset to default"),

	/** The image width. */
	IMAGE_WIDTH(By.xpath("//div[@class='sc-lkwKjF iSPNAu draggable' and @style]"), "The Image width"),

	/** The image checkwidth. */
	IMAGE_CHECKWIDTH("//div[@class='sc-lkwKjF iSPNAu draggable' and contains(@style,'%s')]", "The check image width"),

	/** The media updated successfully. */
	MEDIA_UPDATED_SUCCESSFULLY(By.xpath("//span[contains(text(),'Asset updated successfully')]"), "The image is updated successfully"),

	/** The watermark save button. */
	WATERMARK_SAVE_BUTTON(By.xpath("//button[@data-test='MainBarButtonExport']//div[text()='Save']"), "The save button"),

	/** The watermark close button. */
	WATERMARK_CLOSE_BUTTON(By.xpath("//button[@data-test='MainBarButtonClose' and @aria-label='Close']"), "The Watermark close button"),

	/** The watermark filters. */
	WATERMARK_FILTERS(By.xpath("//div[@data-test='EditorContainer']//div[@direction='vertical']//li//button[@aria-label='Filters']"), "The watermark filters"),
	
	/** The filters pageload. */
	FILTERS_PAGELOAD(By.xpath("//h1[text()='Filters']//parent::div[@data-test='ToolControlBar']"), "The Filters Pageload"),

	/** The duotone filter. */
	DUOTONE_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='DuoTone']//div[text()='DuoTone']"), "The duotone filter"),

	/** The duotone pageload. */
	DUOTONE_PAGELOAD(
	        By.xpath("//div[text()='DuoTone']//ancestor::div[@direction='vertical']//button[@data-test='DuoTone']//following-sibling::div[@data-test='CategoryItemsContainer']"),
	        "The duotone pageload"),

	/** The duotone desert filter. */
	DUOTONE_DESERT_FILTER(By.xpath("//button[@data-test='DuoTone']//following-sibling::div//button[@data-test='Desert']"), "The duoTone dessert filter"),

	/** The duotone peach filter. */
	DUOTONE_PEACH_FILTER(By.xpath("//button[@data-test='DuoTone']//following-sibling::div//button[@data-test='Peach']"), "The Duotone Peach"),

	/** The remove filter. */
	REMOVE_FILTER(By.xpath("//button[@data-test='Remove Filter']//div[text()='Remove Filter']"), "The remove filter"),

	/** The bandw filter. */
	BANDW_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='B & W']//div[text()='B & W']"), "The B&W filter"),

	/** The bandw pageload. */
	BANDW_PAGELOAD(By.xpath("//div[text()='B & W']//ancestor::div[@direction='vertical']//button[@data-test='B & W']//following-sibling::div[@data-test='CategoryItemsContainer']"),
	        "The B&W Pageload"),

	/** The bandw greyed filter. */
	BANDW_GREYED_FILTER(By.xpath("//button[@data-test='B & W']//following-sibling::div//button[@data-test='Greyed']"), "The B&W Greyed filter"),

	/** The bandw dusty filter. */
	BANDW_DUSTY_FILTER(By.xpath("//button[@data-test='B & W']//following-sibling::div//button[@data-test='Dusty']"), "The B&W Dusty filter"),

	/** The vintage filter. */
	VINTAGE_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Vintage']//div[text()='Vintage']"), "The vintage filter"),

	/** The vintage pageload. */
	VINTAGE_PAGELOAD(
	        By.xpath("//div[text()='Vintage']//ancestor::div[@direction='vertical']//button[@data-test='Vintage']//following-sibling::div[@data-test='CategoryItemsContainer']"),
	        "The vintage pageload"),

	/** The vintage polaroid filter. */
	VINTAGE_POLAROID_FILTER(By.xpath("//button[@data-test='Vintage']//following-sibling::div//button[@data-test='Polaroid']"), "The polarid filter"),

	/** The vintage snappy filter. */
	VINTAGE_SNAPPY_FILTER(By.xpath("//button[@data-test='Vintage']//following-sibling::div//button[@data-test='Snappy']"), "The snappy filter"),

	/** The smooth filter. */
	SMOOTH_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Smooth']//div[text()='Smooth']"), "The smooth filter"),

	/** The smooth pageload. */
	SMOOTH_PAGELOAD(
	        By.xpath("//div[text()='Smooth']//ancestor::div[@direction='vertical']//button[@data-test='Smooth']//following-sibling::div[@data-test='CategoryItemsContainer']"),
	        "The smooth Pageload"),

	/** The smooth chestnut filter. */
	SMOOTH_CHESTNUT_FILTER(By.xpath("//button[@data-test='Smooth']//following-sibling::div//button[@data-test='Chestnut']"), "The smooth chestnut filter"),

	/** The smooth moss filter. */
	SMOOTH_MOSS_FILTER(By.xpath("//button[@data-test='Smooth']//following-sibling::div//button[@data-test='Moss']"), "The Smooth Moss Filter"),

	/** The cold filter. */
	COLD_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Cold']//div[text()='Cold']"), "The Cold filter"),

	/** The cold pageload. */
	COLD_PAGELOAD(By.xpath("//div[text()='Cold']//ancestor::div[@direction='vertical']//button[@data-test='Cold']//following-sibling::div[@data-test='CategoryItemsContainer']"),
	        "The cold Pageload"),

	/** The cold colla filter. */
	COLD_COLLA_FILTER(By.xpath("//button[@data-test='Cold']//following-sibling::div//button[@data-test='Colla']"), "The Cold Colla Filter"),

	/** The cold kalmen filter. */
	COLD_KALMEN_FILTER(By.xpath("//button[@data-test='Cold']//following-sibling::div//button[@data-test='Kalmen']"), "The Cold Kalmen Filter"),

	/** The warm filter. */
	WARM_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Warm']//div[text()='Warm']"), "The Warm filter"),

	/** The warm pageload. */
	WARM_PAGELOAD(By.xpath("//div[text()='Warm']//ancestor::div[@direction='vertical']//button[@data-test='Warm']//following-sibling::div[@data-test='CategoryItemsContainer']"),
	        "The Warm Pageload"),

	/** The warm golden filter. */
	WARM_GOLDEN_FILTER(By.xpath("//button[@data-test='Warm']//following-sibling::div//button[@data-test='Golden']"), "The Warm Golden Filter"),

	/** The warm pumpkin filter. */
	WARM_PUMPKIN_FILTER(By.xpath("//button[@data-test='Warm']//following-sibling::div//button[@data-test='Pumpkin']"), "The Warm Pumpkin Filter"),

	/** The warm lowfire filter. */
	WARM_LOWFIRE_FILTER(By.xpath("//button[@data-test='Warm']//following-sibling::div//button[@data-test='Low Fire']"), "The Warm low fire filter"),

	/** The legacy filter. */
	LEGACY_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Legacy']//div[text()='Legacy']"), "The Legacy filter"),

	/** The legacy pageload. */
	LEGACY_PAGELOAD(
	        By.xpath("//div[text()='Legacy']//ancestor::div[@direction='vertical']//button[@data-test='Legacy']//following-sibling::div[@data-test='CategoryItemsContainer']"),
	        "The Legacy Pageload"),

	/** The legacy ancient filter. */
	LEGACY_ANCIENT_FILTER(By.xpath("//button[@data-test='Legacy']//following-sibling::div//button[@data-test='Ancient']"), "The legacy Ancient"),

	/** The legacy hicon filter. */
	LEGACY_HICON_FILTER(By.xpath("//button[@data-test='Legacy']//following-sibling::div//button[@data-test='Hicon']"), "The Legacy Hicon"),

	/** The watermark focus. */
	WATERMARK_FOCUS(By.xpath("//div[@data-test='EditorContainer']//div[@direction='vertical']//li//button[@aria-label='Focus']"), "The Watermark focus"),

	/** The focus pageload. */
	FOCUS_PAGELOAD(By.xpath("//h1[text()='Focus']//parent::div[@data-test='ToolControlBar']"), "The Focus Pageload"),

	/** The focus radial filter. */
	FOCUS_RADIAL_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Radial']//div[text()='Radial']"), "The Radial filter"),

	/** The focus mirrored filter. */
	FOCUS_MIRRORED_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Mirrored']//div[text()='Mirrored']"), "The Mirrored filter"),

	/** The focus linear filter. */
	FOCUS_LINEAR_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Linear']//div[text()='Linear']"), "The Linear Filter"),

	/** The focus gaussian filter. */
	FOCUS_GAUSSIAN_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Gaussian']//div[text()='Gaussian']"), "The Gaussian Filter"),

	/** The remove focus. */
	REMOVE_FOCUS(By.xpath("//button[@data-test='Remove Focus']//div[text()='Remove Focus']"), "The remove focus"),

	/** The watermark frames. */
	WATERMARK_FRAMES(By.xpath("//div[@data-test='EditorContainer']//div[@direction='vertical']//li//button[@aria-label='Frames']"), "The Watermark Frames"),

	/** The frames pageload. */
	FRAMES_PAGELOAD(By.xpath("//h1[text()='Frames']//parent::div[@data-test='ToolControlBar']"), "The Frames Pageload"),

	/** The dia frame filter. */
	DIA_FRAME_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Dia']"), "The Dia frames"),

	/** The art decor frame filter. */
	ART_DECOR_FRAME_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Art Decor']"), "The Art Decor Frames"),

	/** The black frame filter. */
	BLACK_FRAME_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Black']"), "The Black Frames"),

	/** The remove frame. */
	REMOVE_FRAME(By.xpath("//button[@data-test='Remove Frame']//div[text()='Remove Frame']"), "The remove frames"),

	/** The watermark overlays. */
	WATERMARK_OVERLAYS(By.xpath("//div[@data-test='EditorContainer']//div[@direction='vertical']//li//button[@aria-label='Overlays']"), "The watermark overlays"),

	/** The overlays pageload. */
	OVERLAYS_PAGELOAD(By.xpath("//h1[text()='Overlays']//parent::div[@data-test='ToolControlBar']"), "The overlays Pageload"),

	/** The library pageload. */
	LIBRARY_PAGELOAD(By.xpath("//h1[text()='Library']//parent::div[@data-test='ToolControlBar']"), "The Library Pageload"),

	/** The overlays golden filter. */
	OVERLAYS_GOLDEN_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Golden']"), "The overlays Golden filter"),

	/** The overlays lightleak filter. */
	OVERLAYS_LIGHTLEAK_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Light Leak 1']"), "The Overlays lightleak filter"),

	/** The overlays vintage filter. */
	OVERLAYS_VINTAGE_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Vintage']"), "The Overlays Vintage filter"),

	/** The overlays painting filter. */
	OVERLAYS_PAINTING_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Painting']"), "The Overlays Painting"),

	/** The overlays hearts filter. */
	OVERLAYS_HEARTS_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Hearts']"), "The Overlays Hearts"),

	/** The overlays rain filter. */
	OVERLAYS_RAIN_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Rain']"),"OverLays-Rain_filter"),
	
	/** The imageview cancel button. */
	IMAGEVIEW_CANCEL_BUTTON(By.xpath("//div[@class='blue__trans--icon cu-pointer']//img[@alt='Close']"), "The Image view close button"),

	/** The watermark text. */
	WATERMARK_TEXT(By.xpath("//div[@data-test='EditorContainer']//div[@direction='vertical']//li//button[@aria-label='Text']"), "The Watermark text"),

	/** The text pageload. */
	TEXT_PAGELOAD(By.xpath("//h1[text()='Text']//parent::div[@data-test='ToolControlBar']"), "The Text Pageload"),

	/** The text edit button. */
	TEXT_EDIT_BUTTON(By.xpath("//div[@class='sc-jTYCaT lgJPic']//button[@data-test='Edit' and @aria-label='Edit']//following::div[text()='Edit']"), "The Text Edit button"),

	/** The text input field. */
	TEXT_INPUT_FIELD(By.xpath("//div[@data-test='Dialog']//div[contains(@class,'sc-gicCDI')]//textarea[@id='photoeditorsdk-TextInput']"), "The text input field"),

	/** The text edit done. */
	TEXT_EDIT_DONE(By.xpath("//div[@type='textEdit']//button[text()='Done']"), "The Text Edit Done"),

	/** The watermark textdesign. */
	WATERMARK_TEXTDESIGN(By.xpath("//div[@data-test='EditorContainer']//div[@direction='vertical']//li//button[@aria-label='Text Design']"), "The watermark Text Design"),

	/** The text design pageload. */
	TEXT_DESIGN_PAGELOAD(By.xpath("//h1[text()='Text Design']//parent::div[@data-test='ToolControlBar']"), "The Text Design Pageload"),

	/** The textdesign blocks filter. */
	TEXTDESIGN_BLOCKS_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Blocks']"), "The Text Design blocks"),

	/** The textdesign rotate filter. */
	TEXTDESIGN_ROTATE_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Rotated']"), "The Text Design Rotate filter"),

	/** The textdesign redcolor. */
	TEXTDESIGN_COLOR(By.xpath("//button[@aria-label='orange']"), "The font orange color Text Design"),

	/** The creator type your post. */
	CREATOR_PAGE_POST_TEXT(By.xpath("//div[@class='fade tab-pane active show']//ancestor::div//div[@class='DraftEditor-editorContainer']//span//parent::div"), "The post text in creator"),

	/** The creator post now button. */
	CREATOR_POST_NOW_BUTTON(By.xpath("//div[@class='action-btn-holder']//button[text()='Post Now']"), "The creator post now button"),

	/** The post now button. */
	POST_NOW_BUTTON(By.xpath("//div[@class='modal-btn-grp-wraps']//button[text()='Post Now']"), "The post now button"),

	/** Content tab mediaGallery. */
	CONTENT_TAB_MEDIA_GALLERY(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Media']"), "Content tab mediaGallery"),

	/** The postsaved notify. */
	POSTSAVED_NOTIFY_LOCATIONUSER(By.xpath("//span[contains(text(),'Got it! Your post is on its way, and we’ve saved it in your database for later use')]"), "The post saved "),

	/** The postsaved notify branduser. */
	POSTSAVED_NOTIFY_BRANDUSER(By.xpath("//span[contains(text(),'You got it! Your post will be sent out momentarily')]"), "The Post Saved"),
	
	/** The post success message. */
	POST_SUCCESS_MESSAGE(By.xpath("//span[@class='success-mess-txt']"),"Posted Success Message"),
	
	/** The content tap post. */
	CONTENT_TAP_POST(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Posts']"), "The content tab post"),

	/** The favourite tags. */
	FAVOURITE_TAGS("//h3[text()='Favorite Tags']//ancestor::div[@class='filter-item filter-item-tag__item']//div//span[text()='%s']", "The Favourite Tags"),

	/** The favourite image view tag. */
	FAVOURITE_IMAGE_VIEW_TAG("//div[@class='list-expanded-tag-item']//span[text()='%s']", "The Favourite image view tag"),

	/** The favourite image view tag. */
	FAVOURITE_IMAGE_VIEW_INACTIVE_TAG("//span[not(@class='fav-tags active') and text()='%s']", "The Favourite image view Inactive tag"),

	/** The common media icon. */
	COMMON_MEDIA_ICON(By.xpath("//div[@class='mast-prof-pic']//img[@alt='MG Profile Picture']"), "The common media Icon"),

	/** The common media image. */
	COMMON_MEDIA_IMAGE(By.xpath("//div[@class='m-ast']//img[@alt='Media Gallery Asset']"), "The common  media Image"),

	/** The common media expand. */
	COMMON_MEDIA_EXPAND(By.xpath("//div[@class='mc-expand']//img[@alt='Open Detailed View']"), "The common media Expand"),

	
	/** The media detailedview imagedeatils. */
	MEDIA_DETAILEDVIEW_IMAGEDEATILS(By.xpath("//div[@class='wb-label']//div[text()='Image Details']"),"Image Details text"),
	
	
	/** The media detailedview videodeatils. */
	MEDIA_DETAILEDVIEW_VIDEODEATILS(By.xpath("//div[@class='wb-label']//div[text()='Video Details']"),"MEDIA_DETAILEDVIEW_IMAGEDEATILS"),
	
	/** The image uploding time. */
	IMAGE_UPLODING_TIME(By.xpath("//span[@class='msc-count-percntge-load' and text()]"), "The image uploading percentage and Time"),

	/** The browse image remove. */
	BROWSE_IMAGE_REMOVE(By.xpath("//div[@class='mast-controls mast-close']//img[@alt='Remove']"), "The Browse Image Remove"),

	/** The browse image cancel. */
	BROWSE_IMAGE_CANCEL(By.xpath("//button[contains(@class,'ac-secondary-white') and text()='Cancel']"), "The Browser Image Cancel"),

	/** Tags field. */
	TAGS_FIELD(By.xpath("//div[@class='react-tags__search-wrapper']//input[@aria-label='Add Tags' and @class='react-tags__search-input']"), "Tags field"),

	/** Internal notes. */
	INTERNAL_NOTES(By.xpath("//div//textarea[@class='internal-notes']"), "Internal notes"),

	/** The common media by name. */
	COMMON_MEDIA_BY_NAME("//div[@class='mastg-main']//span[@class='sm-txt-top' and text()='%s']", "The common media by name"),
	
	//COMMON_MEDIA_BY_NAME("//span[@class='sm-txt-top' and text()='%s']//parent::div//ancestor::div[@class='mast-prime-dtls']//following-sibling::div[@class='mast-controls']//img[@alt='Open Detailed View']","COMMON_MEDIA_BY_NAME"),	
	
	/** The watermark saved filter. */
	WATERMARK_SAVED_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@aria-label='Saved Watermarks']"), "The Watermark Saved filter"),
	
	/** The watermark saved twentysix. */
	WATERMARK_SAVED_LOGO(By.xpath("//div[@data-test='CardContainer']//button[@aria-label='Saved Watermark 1']"), "The Watermark Saved 31 filter"),
	
	/** The watermark saved spritelogo. */
	WATERMARK_SAVED_LOGODRAG(By.xpath("//div[@data-test='Sprite' and contains(@class,'sc-ESujJ bdjAGC draggable')]"), "The Watermark logo"),
	
	/** The filter validate. */
	FILTER_VALIDATE("//button[@data-test='%s' and contains(@class,'sc-dsQDmV clPJik')]", "The Filter change on image"),
	
	/** The focus filter imagechanges. */
	FOCUS_FILTER_IMAGECHANGES(By.xpath("//div[@data-test='Focus' and @class]"), "The focus filter imagechange view"),

	/** The focus filter validate. */
	FOCUS_FILTER_VALIDATE("//div[@data-test='Focus' and @class='%s']", "The validate Filter change on image"),

	/** The post syndicated message. */
	MEDIA_SYNDICATED_MESSAGE(By.xpath("//div[@class='message-sub-text' and text()='This media has been syndicated']"), "Post syndicated message"),
	
	
	/** The media tab. */
	MEDIA_TAB(By.xpath("//li//span[text()='Media']"), "The Media Tab"),

	/** The tooltip status. */
	TOOLTIP_STATUS("//span[text()='%s']//ancestor::div[contains(@class,'m-item')]//div[@class='mic']//img[@alt='Export']", "The tooltip status"),

	/** The media release download success. */
	MEDIA_RELEASE_DOWNLOAD_SUCCESS(By.xpath("//div//span[text()='Model Release Form downloaded successfully!']"), "The Model Release Form downloaded success"),

	/** The posts page load. */
	POSTS_PAGE_LOAD(By.xpath(
	        "//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Posts']//ancestor::div[contains(@class,'header-wrap')]//following-sibling::main//section//div[@class='content-g']"),
	        "The Posts Page load"),

	/** Brand Hub Location name. */
	BRAND_HUB_LOCATION_NAME(By.xpath("//div[@class='ds-dropdown']//parent::div//button//span"), "Brand Hub Location name"),

	/** Brand Hub Location dropdown. */
	BRAND_HUB_LOCATION_DROPDOWN(By.xpath("//div[@class='brand-profile h-assorted']//div[@class='ds-dropdown']//div[contains(@class,'ds-menu')]"), "Brand Hub Location dropdown"),

	/** Select account from dropdown. */
	SELECT_ACCOUNT_FROM_DROPDOWN("//div[@class='brand-profile h-assorted']//div[@class='ds-dropdown']//div[@class='ds-menu']//div[contains(@id,'react-select') and text()='%s']",
	        "Select account from dropdown"),

	/** The unlike active status. */
	UNLIKE_ACTIVE_STATUS("(//span[text()='%s']//ancestor::div[contains(@class,'m-item')]//button[contains(@class,'switch-button-case right')]//img[contains(@src,'dislike-a.svg')])[1]","Unlike actve Status"),
	
	/** The unlike inactive status. */
	UNLIKE_INACTIVE_STATUS("(//span[text()='%s']//ancestor::div[contains(@class,'m-item')]//button[contains(@class,'switch-button-case right')]//img[contains(@src,'dislike-grey.svg')])[1]","Unlike InActive Status"),
	
	/** The like inactive status. */
	LIKE_INACTIVE_STATUS("(//span[text()='%s']//ancestor::div[contains(@class,'m-item')]//button[contains(@class,'switch-button-case left active-case')]//img[contains(@src,'like-grey.svg')])[1]","Like InActive Status"),
	
	/** The like active status. */
	LIKE_ACTIVE_STATUS("(//span[text()='%s']//ancestor::div[contains(@class,'m-item')]//button[contains(@class,'switch-button-case left active-case')]//img[contains(@src,'like-a.svg')])[1]", "Like Active Status"),

	/** The undo button. */
	UNDO_BUTTON(By.xpath("//button[@data-test='MainBarButtonUndo' and @aria-label='Undo']"), "The undo button"),

	/** The undo check text. */
	UNDO_CHECK_TEXT(By.xpath("//div[@data-test='Sprite']"),"The Undo Check Text"),
	
	/** The redo button. */
	REDO_BUTTON(By.xpath("//button[@data-test='MainBarButtonRedo' and @aria-label='Redo']"), "The redo button"),

	/** The redo disable. */
	REDO_DISABLE(By.xpath("//button[@data-test='MainBarButtonRedo' and @disabled]"), "The Redo Disable"),

	/** The undo disable. */
	UNDO_DISABLE(By.xpath("//button[@data-test='MainBarButtonUndo' and @disabled]"),"The Undo Disable"),
	
	/** The zoom level. */
	ZOOM_LEVEL(By.xpath("//span[@data-test='ZoomLevel']"), "The Zoom level"),

	/** The zoom in button. */
	ZOOM_IN_BUTTON(By.xpath("//button[@data-test='Zoom in']"), "The Zoom in Button"),

	/** The zoom out button. */
	ZOOM_OUT_BUTTON(By.xpath("//button[@data-test='MainBarButtonZoom']"), "The Zoom out button"),

	/** The favourite teags edit. */
	FAVOURITE_TEAGS_EDIT(By.xpath("//div[@class='edit-icon-media']//following-sibling::span[@class='cf-values' and text()='Edit']"), "The favourite Tag Edit"),

	/** The EDI T FAVOURIT E TA G AN D CANC el. */
	EDIT_FAVOURITE_TAG_AND_CANCEl(
	        By.xpath("//div[@class='eftMain']//div[contains(@class,'eft-top')]//div[text()='Edit Favorite Tags']//parent::div//div[@class='eft__close--icon']//img[@alt='close']"),
	        "The Edit Favourite Tag And cancel"),

	/** The tags search bar. */
	TAGS_SEARCH_BOX(
			By.xpath("//div[@class='react-tags__search-wrapper']//input[@aria-label='Search tags' and @class='react-tags__search-input']"),
			"The Edit tags search bar"),

	/** The edit favouritetag describtion. */
	EDIT_FAVOURITETAG_DESCRIPTION(By.xpath("//p[@class='glbl__sub--title' and text()]"), "The Edit Tag Describtion"),

	/** The favourite tags withstar. */
	FAVOURITE_TAGS_WITHSTAR("//span[text()='%s']//ancestor::div[@class='eft-items']//span[@class='checkmark fullSelectCheck']", "The Favourite Tags with Star"),

	/** The favourite tags withoutstar. */
	FAVOURITE_TAGS_WITHOUTSTAR("//span[text()='%s']//ancestor::div[@class='eft-items']//span[@class='checkmark']", "The Favourite Tag without star"),

	/** The favouritetag edit searchbox. */
	FAVOURITETAG_EDIT_SEARCHBOX(By.xpath("//div[@class='react-tags__search']//ancestor::div[@class='eftMain']//input[@class='react-tags__search-input']"), "The Favourite Tag Search Box"),

	/** The media image name edit. */
	MEDIA_IMAGE_NAME_EDIT(By.xpath("//div[contains(@class,'rel-head-label')]//input[@class='img-edit glbl__title--txt']"), "The Edit image name"),

	/** The upload watermark button. */
	UPLOAD_WATERMARK_BUTTON(By.xpath("//h1[text()='Watermark']//ancestor::div//div[@class='sc-chKnlQ hmDorT']//button[@data-test='Upload Watermark']//div[text()='Upload Watermark']"),
	        "The upload watermark button"),

	SYNDICATE_BUTTON(By.xpath("//div[contains(@class,'btn-wrp-separate')]//button[@class='ac-btn ac-primary size-sm' and text()='Syndicate']"),"Syndicate button"),
	
	/** The media detailview edit button. */
	MEDIA_DETAILVIEW_EDIT_BUTTON(By.xpath("//div[contains(@class,'fi-item fi-edit')]//span[text()='Edit']"),"Media DetailView Edit Button"),
	
	/** The watermark library. */
	WATERMARK_LIBRARY(By.xpath("//div[@data-test='EditorContainer']//button[@data-test='ToolbarItem' and @aria-label='Library']"), "The watermark Library "),

	/** The watermark adjust. */
	WATERMARK_ADJUST(By.xpath("//div[@data-test='EditorContainer']//button[@data-test='ToolbarItem' and @aria-label='Adjust']"), "The Watermark Adjust"),

	/** The watermark brush. */
	WATERMARK_BRUSH(By.xpath("//div[@data-test='EditorContainer']//button[@data-test='ToolbarItem' and @aria-label='Brush']"), "The Watermark Brush"),

	/** The watermark filter button. */
	WATERMARK_FILTER_BUTTON(By.xpath("//div[@data-test='EditorContainer']//button[@data-test='ToolbarItem' and @aria-label='Watermark']"), "The Watermark filter button"),

	/** The saved watermarks filter. */
	SAVED_WATERMARKS_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Saved Watermarks']//div[text()='Saved Watermarks']"), "The Saved Watermark filter"),

	/** The emoticons watermark filter. */
	EMOTICONS_WATERMARK_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Emoticons']//div[text()='Emoticons']"), "The Emoticons Watermark filter"),

	/** The shapes watermark filter. */
	SHAPES_WATERMARK_FILTER(By.xpath("//div[@data-test='CardContainer']//button[@data-test='Shapes']//div[text()='Shapes']"), "The watermark shapes"),

	/** The emoticons nerd filter. */
	EMOTICONS_NERD_FILTER(By.xpath("//button[@data-test='Emoticons']//following-sibling::div//button[@data-test='Smile']"), "The Emoticons Nerd filter"),

	/** The shapes badge filter. */
	SHAPES_BADGE_FILTER(By.xpath("//button[@data-test='Shapes']//following-sibling::div//button[@data-test='Badge 10']"), "The Shapes badge filter"),

	/** The library santiago filter. */
	LIBRARY_SANTIAGO_FILTER(By.xpath("//div[@data-test='CardContainer']//button//div[text()='Gabriel Santiago']"), "The Library Santiago filter"),

	/** The schedule button. */
	SCHEDULE_BUTTON(By.xpath("//div[@class='action-btn-holder']//button[text()='Schedule']"), "The click the schedule button"),

	/** The schedule post button. */
	SCHEDULE_POST_BUTTON(By.xpath("//div[@class='footer-btn-section']//button[text()='Schedule post']"),"Schedule Post Button"),

	/** The location switcher. */
	LOCATION_SWITCHER(By.xpath("//div[@class='ds-dropdown']//button[@type='button']//span[@class='css-19r5em7']"), "The click location switcher"),

	/** The profile icon loginuser. */
	PROFILE_ICON_LOGINUSER(By.xpath("//div[@class='drop-items ha-item profile-items show dropdown']//ancestor::span[text()]"), "The Login User Name"),

	/** The avaliable for personal use active. */
	AVALIABLE_FOR_PERSONAL_USE_ACTIVE(By.xpath("//label[@class=' active']//input//following-sibling::span[text()='Available for Personal Use Only']"),"Available for personal use Only Active"),
	
	/** The available for everyoneelse active. */
	AVAILABLE_FOR_EVERYONEELSE_ACTIVE(By.xpath("//label[@class='r-ml30 active']//input//following-sibling::span[text()='Available for Everyone Else']"),"Available For EveryOne Else active"),
	
	/** The available for everyoneelse button. */
	AVAILABLE_FOR_EVERYONEELSE_BUTTON(By.xpath("//div[text()='Availability']//ancestor::div[@class='mg-upload__view']//label//input//following-sibling::span[text()='Available for Everyone Else']"),"Available For EveryOne Else button"),

	/** The avaliable for personal use. */
	AVAILABLE_FOR_PERSONAL_USE_BUTTON(By.xpath("//div[text()='Availability']//ancestor::div[@class='mg-upload__view']//label//input//following-sibling::span[text()='Available for Personal Use Only']"),"Available For personal use button"),

	/** The lock image editing button. */
	LOCK_IMAGE_EDITING_BUTTON(By.xpath("//div[text()='Image Editing']//ancestor::div[@class='mg-upload__view']//label//input//following-sibling::span[text()='Lock Image from Editing']"),"Lock ImageEditing Option"),
	
	/** The watermark disable button. */
	WATERMARK_DISABLE_BUTTON(By.xpath("//span[contains(text(),'Watermark')]//ancestor::div[contains(@class,'disabled btn-group') or contains(@class,'btn-group') ]//label[contains(@class,'btn btn-primary') or contains(@class,'disabled btn btn-primary')]//div[contains(@class,'fi-item fi-watermark')]"),"Watermark Disable Buuton"),

	/** The edit disable button. */
	EDIT_DISABLE_BUTTON(By.xpath("//span[contains(text(),'Edit')]//ancestor::div[contains(@class,'disabled btn-group') or contains(@class,'btn-group') ]//label[contains(@class,'btn btn-primary') or contains(@class,'disabled btn btn-primary')]//div[contains(@class,'fi-item fi-edit')]"),"Edit Disable Buuton"),

	WATERMARK_ENABLE_BUTTON(By.xpath("//span[contains(text(),'Watermark')]//ancestor::div[not(contains(@class,'disabled btn-group'))]//label[contains(@class,'btn btn-primary')]//div[contains(@class,'fi-item fi-watermark')]"),"Watermark ENABLE Buuton"),

	/** The edit disable button. */
	EDIT_ENABLE_BUTTON(By.xpath("//span[contains(text(),'Edit')]//ancestor::div[not(contains(@class,'disabled btn-group'))]//label[contains(@class,'btn btn-primary')]//div[contains(@class,'fi-item fi-edit')]"),"Edit ENABLE Buuton"),


	/** The like active. */
    LIKE_ACTIVE(By.xpath("//button[contains(@class,'left active-case')]"),"Like Active"),
	
	/** The dislike active. */
	DISLIKE_ACTIVE(By.xpath("//button[contains(@class,'button-case right')]"),"DisLike Active"),
	
	/** The unrated status. */
	UNRATED_STATUS(By.xpath("//div[contains(@class,'switch-button')]"),"Unrated Filter"),
	
	/** The provided by name. */
	PROVIDED_BY_NAME("//span[text()='Provided by']//following::div[text()='%s']", "The Provided By Name"),

	/** The profile icon. */
	PROFILE_ICON(By.xpath("//button[@id='dropitems-profile-items']"), "Profile icon"),

	/** The profile icon dropdown. */
	PROFILE_ICON_DROPDOWN(By.xpath("//button[@id='dropitems-profile-items']//following-sibling::div[@class='dropdown-menu show']"), "Profile icon dropdown"),

	/** The dropdown logout. */
	DROPDOWN_LOGOUT(By.xpath("//div[@class='dropdown-menu show']//a[text()='Logout']"), "Dropdown logOut"),
	// span[@class='admn-txt ad-name ad-uname']//ancestor::tr[@data-testid='tr'

	
	/** The generate ai image button. */
	//Generate AI -Xpath
	GENERATE_AI_IMAGE_BUTTON(By.xpath("//div[@class='aiGBtn']//parent::div[contains(@class,'aiG-wrap')]//div[@class='aiGTxt']//h5[text()='Generate']//span[text()='AI Images']"),"GENERATE_AI_IMAGE_BUTTON"),
	
	/** The AI modal AI assistant text. */
	//Generate AI -Xpath
	AI_MODAL_SYMBOL(By.xpath("//div[@class='logo-placeholder']//img[@alt='AI Assistant']"),"The AI modal AI symbol"),
	
	/** The generate ai images text. */
	GENERATE_AI_IMAGES_TEXT(By.xpath("//h3[text()='AI Image Editor']"),"GENERATE_AI_IMAGES_TEXT"),

	/** The generate ai images - Start over option */
	GENERATE_AI_IMAGE_START_OVER(By.xpath("//div[@class='flex modal-body']//div[@class='startOver']//span[@class='inline-txt' and text()='Start Over']"),"The generate ai images - Start over option"),

	/** The generate ai images -info icon */
	GENERATE_AI_IMAGE_INFO_ICON(By.xpath("//div[@class='flex modal-body']//div[@class='infoIcon-divWrap']//img[@alt='Best Results From AI Assistant']"),"The generate ai images -info icon "),

	GENERATE_AI_IMAGE_ICON_DETAILVIEW(By.xpath("//div[@class='aia-content aia-right card']//div[@class='aia-right-top']"),"GENERATE_AI_IMAGE_ICON_DETAILVIEW"),

	/** The generate ai images - AI Assistant */
	GENERATE_AI_IMAGE_TEXT(By.xpath("//div[@class='ai-prompt-text']//div[@class='ai-ideas aim-info']//h3"),"The generate ai images - AI Assistant"),


	/** The enterdescriptipon textarea. */
	ENTERDESCRIPTIPON_TEXTAREA(By.xpath("//div[@class='flex modal-body']//textarea"),"Enter Description TextArea"),
	
	/** The select style dropdown. */
	AI_MODAL_VIEW_RECENT_PROMPT(By.xpath("//span[@class='tog-label' and text()='View Recent Prompt ']"),"View recent prompt"),

	/** The AI modal - Image aspect ratio dropdown*/
	AI_MODAL_IMAGE_ASPECT_RATIO_DROPDOWN("//div[@class='iar-wrap']//h3[text()='%s']//parent::div//div[@id='ai-image-aspect-ratio']","The AI modal - Image aspect ratio dropdown"),

	/** The AI modal - Image style ratio dropdown*/
	AI_MODAL_IMAGE_STYLE_RATIO_DROPDOWN("//div[@class='iar-wrap']//h3[text()='%s']//parent::div//div[@id='ai-image-aspect-ratio']","The AI modal - Image style ratio dropdown"),

	/** The AI modal - Image detail ratio dropdown*/
	AI_MODAL_IMAGE_DETAIL_RATIO_DROPDOWN("//div[@class='iar-wrap']//h3[text()='%s']//parent::div//div[@id='ai-image-aspect-ratio']","The AI modal - Image detail ratio dropdown"),


	/** The generate button. */
	GENERATE_BUTTON(By.xpath("//button[contains(@class,'gnrc-btn blue-gnr')]//span[text()='Generate Image!']"),"Generate button"),
	
	/** The generate image detailview close button. */
	GENERATE_IMAGE_DETAILVIEW_CLOSE_BUTTON(By.xpath("//div[@class='mod__close--icon']//img[@class='mod__close--img']"),"Generate Image Detailview Close Button"),
	
	/** The ai type all filter. */
	AI_TYPE_ALL_FILTER(By.xpath("//div[@class='form-group']//input[@name='ai_type-AI Type' and @value='all' ]"),"AI Type All Filter"),
	
	/** The ai assisted filter. */
	AI_ASSISTED_FILTER(By.xpath("//div[@class='form-group']//input[@name='ai_type-AI Type']//following-sibling::span[text()='AI Assisted']"),"AI Assisted Filter"),
	
	/** The ai non assisted filter. */
	AI_NON_ASSISTED_FILTER(By.xpath("//div[@class='form-group']//input[@name='ai_type-AI Type']//following-sibling::span[text()='Non-AI Assisted']"),"AI Non Assisted Filter"),
	
	/** The ai profile image. */
	AI_PROFILE_IMAGE(By.xpath("//div[contains(@class,'masonry-grid')]//div[@class='mastg-main']//div[@class='mast-prof-pic']//img[@alt='MG Profile Picture']"),"Ai Profile Image"),
	
	/** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),

	COMMON_IMAGE_SYNDICATE_FIELD("//span[@class='sm-txt-top' and text()='%s']//ancestor::div[@class='masonry-grid_column']//div[@class='mic-actions']//img[@alt='Syndicate']","Common Image Syndicate Field"),
	
	MEDIA_LAST_SYNDIACTE_DATE(By.xpath("//span[@class='wbf-label' and text()='Last Syndicated']//parent::div//parent::div//following-sibling::div[text()]"),"Media Last Syndicate date"),
	
	MEDIA_LAST_SYNDICATE_LIST_LOCATION(By.xpath("//span[@class='wbf-label' and text()='Last Syndicated']//parent::div//parent::div//following-sibling::div[text()]//span[@class='wbfi-txt blue-text cur-pointer ms-2']"),"MEDIA_LAST_SYNDICATE_LIST_LOCATION"),
	
	MEDIA_LAST_SYNDICATED_SECTION_LOCATION("//span[@class='wbf-label' and text()='Last Syndicated']//following::div//span[@class='wbfi-txt blue-text cur-pointer ms-2' and text()='%s']","MEDIA_LAST_SYNDICATED_SECTION_LOCATION"),
	
	/** Facebook active in creator page */
     FACEBOOK_ACTIVE_IN_CREATOR_PAGE(By.xpath("//div[@class='icon-tabs']//button[@data-rr-ui-event-key='facebook' and text()='Facebook']"), " Facebook active in creator page"),
	
	/** Instagram active in creator page */
	INSTAGRAM_ACTIVE_IN_CREATOR_PAGE(By.xpath("//div[@class='icon-tabs']//button[@data-rr-ui-event-key='instagram' and text()='Instagram']"), " Instagram active in creator page"),
	
	/** Twitter active in creator page */
	TWITTER_ACTIVE_IN_CREATOR_PAGE(By.xpath("//div[@class='icon-tabs']//button[@data-rr-ui-event-key='twitter' and text()='Twitter']"), "Twitter active in creator page"),
	
	/** Linkedin active in creator page */
	LINKEDIN_ACTIVE_IN_CREATOR_PAGE(By.xpath("//div[@class='icon-tabs']//button[@data-rr-ui-event-key='linkedin' and text()='Linkedin']"), "Linkedin active in creator page"),
	
	/** Creator page with media. */
	CREATOR_PAGE_WITH_MEDIA("//div[@class='tab-content']//div[@class='img-thumb']//img[@src='%s']","Creator page with media."),
	
	/** Creator page with video. */
	CREATOR_PAGE_WITH_VIDEO("//div[@class='tab-content']//div[@class='video-outer-element-left-side']//video[contains(@poster,'%s')]","Creator page with media video"),
	
	/** Creator page with media text. */
	CREATOR_PAGE_WITH_MEDIA_TEXT("//div[@class='DraftEditor-editorContainer']//span//span[contains(text(),'%s')]","Creator page with media text"),

	/** Video size exceeding alert */
	VIDEO_SIZE_EXCEEDING_ALERT(By.xpath("//div[@class='Toastify']//div[@role='alert']//span[@class='success-mess-txt' and text()='File size exceeds its maximum limit of 500MB']"), "Video size exceeding alert"),

	MEDIA_EXPIRATION_ALL_FILTER_ACTIVE(By.xpath("//input[@name='active-Media Expiration']//parent::label[@class='active']//span[text()='All']"),"Media Expiration All Filter Active"),
	MEDIA_EXPIRATION_ALL_FILTER(By.xpath("//input[@name='active-Media Expiration']//parent::label//span[text()='All']"),"Media Expiration All Filter Active"),
	MEDIA_EXPIRATION_ACTIVE_FILTER(By.xpath("//input[@name='active-Media Expiration']//parent::label//span[text()='Active']"),"Media Expiration Active Filter"),

	MEDIA_EXPIRATION_EXPIRED_FILTER(By.xpath("//input[@name='active-Media Expiration']//parent::label//span[text()='Expired']"),"Media Expiration Expired Filter"),

	MEDIA_WITH_EXPIRED_IMAGE(By.xpath("//div[@class='campaign-tag media-tag']//span[text()='Expired']"),"Media Image With Expired"),

	IMAGE_WITH_AI_OPTION("//img[@src='%s']//parent::div//parent::div//div[contains(@class,'ai-btn')]//img[@alt='AI']","Image with Ai Option"),

	HOVER_MESSAGE("//div[@class='rc-tooltip-inner']//div[@class='common-tooltip--wrp' and text()='%s']","Hover Message"),

	ACCOUNT_SWITCHER_LOCATION(By.xpath("//div[@class='ds-dropdown']//span[@class='css-19r5em7']"),"ACCOUNT_SWITCHER_LOCATION"),

	AL_CONTENT_SUPPLIERS_TAB(By.xpath("//div[@class='filter-item fltr-drp']//span[@title='All Content Suppliers']"),"AL Content Suppliers Tab"),

	CONTENT_SUPPLIER_SELECTOR_TEXT(By.xpath("//div[@class='modal-body']//h3[text()='Content Supplier Selector']"),"CONTENT_SUPPLIER_SELECTOR_TEXT"),

	CONTENT_SUPPLIER_SELECTOR_SEARCH(By.xpath("//div[@class='modal-body']//h3[text()='Content Supplier Selector']//parent::div//div[@class='asm-lf']//input[@placeholder='Search']"),"Content Supplier Selector Search"),

	ALL_CONTENT_SUPPLIERS_TEXT(By.xpath("//div[@class='asm-accord cssheadLabels']//span[text()='All Content Suppliers']"),"All Content Suppliers Text"),

	LIST_OF_CONTENT_SUPPLIER_SELECTOR(By.xpath("//div[@class='asm-accord cssheadLabels']//div[@class='asm-accord cssSearchList']//ul//li//span[@class='lcs-name']"),"List Of Content Supplier Selector"),

	SELECT_CONTENT_SUPPLIER_LIST("//div[@class='modal-body']//div[@class='asm-accord cssSearchList' or @class='all-locs cssTopLabel']//span[text()='%s']","Content Supplier List"),

	SELECTED_CONTENT_SUPPLIER_LIST("//label[contains(@class,'active')]//span[text()='%s']","Selected Content Supplier List"),

	CONTENT_SELECTOR_DEFAULT_LIST(By.xpath("//label//span[text()='All Content Suppliers']"),"Selected Content Supplier List"),

	FEED_ENROLL_LINK(By.xpath("//div[@class='modal-body']//p[text()='To add or remove Content Suppliers, click here:']//following-sibling::span[text()='Feed-Enroll']"),"FEED_ENROLL_LINK"),

	CONTENT_SUPPLIER_SELECTOR_CANCEL(By.xpath("//div[@class='modal-footer']//div[@class='react-ripples ac-secondary-box edit-ripple__wrp']//button[text()='Cancel']"),"Content Supplier Selector Cancel"),

	CONTENT_SUPPLIER_SELECTOR_OK(By.xpath("//div[@class='modal-footer']//button[@class='ac-btn ac-primary ac-block' and text()='Ok']"),"Content Supplier Selector Ok"),

	CONTENT_SUPPLIER_SELECTOR_CLOSE_ICON(By.xpath("//div[@class='modal-content']//div[@class='mod__close--icon']//img[@class='close-icon']"),"Content Supplier Selector Close Icon"),

	MEDIA_PAGE_CS_SELCTOR_FIELD("//div[@class='filter-item fltr-drp']//div[@class='la-sel-action']//span[@title='%s']","Media Page CS Selctor Field"),

	;


	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new content tab media gallery page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private ContentTabMediaGalleryPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new content tab media gallery page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private ContentTabMediaGalleryPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

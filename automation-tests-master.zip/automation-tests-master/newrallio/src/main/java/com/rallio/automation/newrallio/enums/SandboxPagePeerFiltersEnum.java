package com.rallio.automation.newrallio.enums;


// TODO: Auto-generated Javadoc
/**
 * The Enum SandboxPagePeerFiltersEnum.
 */
public enum SandboxPagePeerFiltersEnum {

	/** The all. */
	ALL("All Locations"),
	
	/** The automation location one. */
	AUTOMATION_LOCATION_ONE("Bean Me Up - Automation Location one"),
	
	/** The automation location two. */
	AUTOMATION_LOCATION_TWO("Automation Location two"),
	
	/** The bala location. */
	BALA_LOCATION("Bean Me Up - Bala Location"),
	
	/** The pushpa location. */
	PUSHPA_LOCATION("Bean Me Up - Pushpa Location"),
	
	/** The test location one. */
	TEST_LOCATION_ONE("Bean Me Up - Test location 1"),
	
	/** The bean me up la. */
	BEAN_ME_UP_LA("Bean Me Up - Bean Me Up LA Test"),
	
	/** The bean me up l2. */
	BEAN_ME_UP_L2("Bean Me Up NC_1 - Bean Me Up L2"),
	
	/** The bean me up l3. */
	BEAN_ME_UP_L3("Bean Me Up NC_2 - Bean Me Up - L3"),
	
	/** The bean me up l5. */
	BEAN_ME_UP_L5("Bean Me Up SC_3 - Bean Me Up L5"),
	
	/** The bean me up l6. */
	BEAN_ME_UP_L6("Bean Me Up SC_3 - Bean Me Up L6"),
	
	/** The bean me up l8. */
	BEAN_ME_UP_L8("Bean Me Up EC_1 - Bean Me Up L8"),
	
	/** The bean me up l11. */
	BEAN_ME_UP_L11("Bean Me Up NC_1 - Bean Me Up L11"),
	
	/** The bean me up l10. */
	BEAN_ME_UP_L10("Bean Me Up - Bean me up L10");
	
	
	/** The value. */
	public String value;
	
	/**
	 * Instantiates a new sandbox page peer filters enum.
	 *
	 * @param value the value
	 */
	private SandboxPagePeerFiltersEnum(String value) {

		this.value = value;
	}
	
	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public String getValue()
	{
		return value;
	}
}

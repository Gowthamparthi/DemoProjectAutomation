package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

public enum AdminLogInsPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath(
	        "//div[@class='modal-content']//div[contains(@class,'main__content')]//div[contains(@class,'manage-admin__stat')]//following::div[contains(@class,'table-global manage-admin_tbl')]"),
	        "Page load"),
	
	/** The no data to show. */
	NO_DATA_TO_SHOW(By.xpath("//div[contains(@class,'main__content')]//div[contains(@class,'no-data')]//span[text()='No data to show']"), "No data to show"),

	/** The heading admin. */
	HEADING_ADMIN (By.xpath("//div[contains(@class,'modal-body')]//div[contains(@class,'sec-header')]//span[contains(text(),'Manage Admin Logins')]"), "Heading"),

	/** The heading employee. */
	HEADING_EMPLOYEE (By.xpath("//div[contains(@class,'modal-body')]//div[contains(@class,'sec-header')]//span[contains(text(),'Manage Employee Logins')]"), "Heading"),

	
	/** The location icon. */
	LOCATION_ICON(By.xpath("//div[contains(@class,'sec-main__content')]//div[contains(@class,'init active-stat')]"), "Location Icon"),

	/** The location name. */
	LOCATION_NAME(By.xpath("//div[contains(@class,'sec-main__content')]//div[contains(@class,'loc')]//div[contains(@class,'lbl')]"), "Location name"),

	/** The add new login button. */
	ADD_NEW_LOGIN_BUTTON(By.xpath("//div[contains(@class,'sec-main__content')]//button[text()='Add New Login']"), "Add new login button"),

	/** The location header. */
	LOCATION_HEADER(By.xpath("//div[contains(@class,'sec-main__content')]//thead//tr"), "Location header"),

	/** The location list. */
	LOCATION_LIST(By.xpath("//div[contains(@class,'sec-main__content')]//tbody//tr"), "Location list"),

	/** The close button. */
	CLOSE_BUTTON(By.xpath("//div[@class='sec-header']//span[@class='title']//following-sibling::img[@alt='Close']"), "Close button"),

	/**The adminLogin page contains data. */
	
	ADMIN_TABLE_DATAS(By.xpath("//table//thead//tr//div[contains(text(),'Name')]//following::th//div[contains(text(),'Email')]//following::th//div[contains(text(),'Phone Number')]//following::th[@class='tool-tip']//following::tbody//div[@class='rel-icons td-more']//img[@alt='More']"),"Admin Login Page Datas");
	

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	private AdminLogInsPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	private AdminLogInsPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

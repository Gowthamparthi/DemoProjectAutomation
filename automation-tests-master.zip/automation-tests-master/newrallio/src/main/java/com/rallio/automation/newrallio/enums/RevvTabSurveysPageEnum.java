package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum RevvDashboardPageEnum.
 */
public enum RevvTabSurveysPageEnum {
	
	/** The page load. */
	PAGE_LOAD(By.xpath("//span[text()='Surveys']//ancestor::div//div[contains(@class,'non-psp-survey-container')]//div[contains(@class,'table-main__skeleton survey-tbl__wrp')]"),"Revv Surveys Page Load"),
	
	//Middile Section :
	
	/** The revv surveys table. */
	REVV_SURVEYS_TABLE(By.xpath("//div[contains(@class,'skeleton survey-tbl')]//th[text()='Customer']//following-sibling::th[text()='Status']//following-sibling::th[text()='Date Completed']//following-sibling::th[text()='Review Status']//following-sibling::th[text()='Rating']//parent::tr//parent::thead//following::tbody//aside//div"),"REVV_SURVEYS_TABLE"),

	/** The revv surveys table users. */
	REVV_SURVEYS_TABLE_USERS(By.xpath("//div[contains(@class,'skeleton survey-tbl')]//div[contains(@class,'user-name')]//span[@class='customer-name']"),"Revv-Surveys Table Users"),
	
	/** The revv surveys table most recent survey date. */
	REVV_SURVEYS_TABLE_MOST_RECENT_SURVEY_DATE(By.xpath("(//th[text()='Date Completed']//ancestor::div[contains(@class,'table-main__skeleton survey-tbl__wrp')]//table//tbody//td[4])[1]"),"REVV_SURVEYS_TABLE_SURVEY_DATE"),

	/** The revv surveys table footer. */
	REVV_SURVEYS_TABLE_FOOTER(By.xpath("(//div[contains(@class,'skeleton survey-tbl')]//tr[last()])[2]"),"Revv-Surveys Table Footer"),
	
	/** The revv surveys search tab. */
	REVV_SURVEYS_SEARCH_TAB(By.xpath("//div[contains(@class,'survey-container')]//div//input[@class='npsp-search-box']"),"REVV_SURVEYS_SEARCH_TAB"),
	
	/** The revv surveys search result by name. */
	REVV_SURVEYS_SEARCH_RESULT_BY_NAME("//div[contains(@class,'skeleton survey-tbl')]//tr[1]//div//span[@class='customer-name' and text()='%s']","REVV_SURVEYS_SEARCH_RESULT_BY_NAME"),

	/** The revv surveys search result by mobile number. */
	REVV_SURVEYS_SEARCH_RESULT_BY_MOBILE_NUMBER("//div[contains(@class,'skeleton survey-tbl')]//div//span[text()='%s' and @class='customer-phone']","REVV_SURVEYS_SEARCH_MOBILE_NUMBER"),

	/** The revv surveys search result by mail id. */
	REVV_SURVEYS_SEARCH_RESULT_BY_MAIL_ID("//div[contains(@class,'skeleton survey-tbl')]//div//span[text()='%s' and @class='customer-email']","REVV_SURVEYS_SEARCH_MAIL_ID"),

	/** The total vist stats count. */
	TOTAL_VIST_STATS_COUNT(By.xpath("//div[contains(@class,'stat-tile total-visit')]//h3[text()='TOTAL VISITS']//following-sibling::div[@class='value']"),"Total Vist Count"),
	
	/** The survey sent stats count. */
	SURVEY_SENT_STATS_COUNT(By.xpath("//div[contains(@class,'stat-tile survey-sent')]//section[@class='img-box']//parent::div//h3[text()='Surveys Sent']//following-sibling::div[@class='value']"),"SURVEY_SENT_STATS_COUNT"),
	
	/** The survey cmpletes stats count. */
	SURVEY_COMPLETED_STATS_COUNT(By.xpath("//div[contains(@class,'stat-tile survey-completed')]//section[@class='img-box']//parent::div//h3[text()='Surveys Completed']//following-sibling::div[@class='value']"),"SURVEY_COMPLETED_STATS_COUNT"),
	
	/** The average rating stats count. */
	AVERAGE_RATING_STATS_COUNT(By.xpath("//div[contains(@class,'tile avg-rating')]//section[@class='img-box']//preceding-sibling::aside//h3[text()='Average Rating']//following-sibling::div"),"AVERAGE_RATING_STATS_COUNT"),

	/** The left a command stats count. */
	LEFT_A_COMMAND_STATS_COUNT(By.xpath("//div[contains(@class,'tile left-comment')]//section[@class='img-box']//preceding-sibling::aside//h3[text()='Left a Comment']//following-sibling::div"),"LEFT_A_COMMAND_STATS_COUNT"),

	/** The agreed to review stats count. */
	AGREED_TO_REVIEW_STATS_COUNT(By.xpath("//div[contains(@class,'stat-tile agreed-to-review')]//section[@class='img-box']//parent::div//h3[text()='Agreed to Review']//following-sibling::div[@class='value']"),"Aggreed To Review Count"),
	
	/** The send survey button. */
	SEND_SURVEY_BUTTON(By.xpath("//section[contains(@class,'filter revv-survey')]//button//span[text()='Send Survey']"),"SEND_SURVEY_BUTTON"),
	
	SEND_SURVEY_MODAL_SECTION(By.xpath("//div[contains(@class,'send-survey__modal')]//div[text()='Send Survey']//parent::div//parent::div//following::div//div[@class='send-survey-modal__form']"),"SEND_SURVEY_MODAL_SECTION"),
	
	SEND_SURVEY_MODAL_SECTION_CLOSE_BUTTON(By.xpath("//img[contains(@src,'modal-close' )and contains(@class,'close')]"),"SEND_SURVEY_MODAL_SECTION_CLOSE_BUTTON"),
	
	SEND_SURVEY_MODAL_EMAIL_FIELD(By.xpath("//div[@class='send-survey-modal__form']//div//input[@name='email']"),"SEND_SURVEY_MODAL_EMAIL_FIELD"),

	SEND_SURVEY_MODAL_USERNAME_FIELD(By.xpath("//div[@class='send-survey-modal__form']//div//input[@name='userName']"),"SEND_SURVEY_MODAL_USERNAME_FIELD"),

	SEND_SURVEY_MODAL_LOCATION_SEARCH_FIELD(By.xpath("//div[@class='send-survey-modal__form']//div//inpuT[@CLASS='dropdown-seach-control form-control']"),"SEND_SURVEY_MODAL_LOCATION_SEARCH_FIELD"),

	SEND_SURVEY_MODAL_LOCATION_DROPDOWN(By.xpath("//div[@class='send-survey-modal__form']//div[contains(@class,'dropdown--menu')]//input"),"SEND_SURVEY_MODAL_LOCATION_DROPDOWN"),

	SEND_SURVEY_MODAL_LOCATION_DROPDOWN_ITEM_BY_NAME("//div[@class='send-survey-modal__form']//div//a[@class='dropdown-item' and text()='%s']","SEND_SURVEY_MODAL_LOCATION_DROPDOWN_ITEM_BY_NAME"),
	
	SEND_SURVEY_MODAL_SEND_BUTTON_DISABLED(By.xpath("//div[@class='send-survey-modal__form']//div[contains(@class,'disabled')]//button[text()='Send Survey']"),"SEND_SURVEY_MODAL_SEND_BUTTON_DISABLED"),

	SEND_SURVEY_MODAL_SEND_LATER_BUTTON(By.xpath("//label[text()='Send Later']//parent::div//input"),"SEND_SURVEY_MODAL_SEND_LATER_BUTTON"),

	SEND_SURVEY_MODAL_SEND_BUTTON_ENABLED(By.xpath("//div[@class='send-survey-modal__form']//div[not(contains(@class,'disabled'))]//button[text()='Send Survey']"),"SEND_SURVEY_MODAL_SEND_BUTTON_ENABLED"),
	
	SURVEYS_SEND_SUCCESSFULLY_DISMISS(By.xpath("//span[text()='Survey sent successfully.']//following::button[text()='DISMISS']"),"SURVEYS_SEND_SUCCESSFULLY_DISMISS"),

	/** The survey sent tile active. */
	SURVEY_SENT_TILE_ACTIVE(By.xpath("//div[contains(@class,'stat-tile survey-sent')]//section[@class='img-box']//parent::div[contains(@class,'stat-tile survey-sent survey cur-pointer active')] "),"SURVEY_SENT_TILE_ACTIVE"),

	/** The survey completed tile active. */
	SURVEY_COMPLETED_TILE_ACTIVE(By.xpath("//div[contains(@class,'stat-tile survey-completed')]//section[@class='img-box']//parent::div[contains(@class,'stat-tile survey-completed cur-pointer active')] "),"SURVEY_SENT_TILE_ACTIVE"),

	/** The survey left a comment tile active. */
	SURVEY_LEFT_A_COMMENT_TILE_ACTIVE(By.xpath("//div[contains(@class,'stat-tile left-comment')]//section[@class='img-box']//parent::div[contains(@class,'stat-tile left-comment cur-pointer active')] "),"SURVEY_SENT_TILE_ACTIVE"),

	/** The agreed to review tile active. */
	AGREED_TO_REVIEW_TILE_ACTIVE(By.xpath("//div[contains(@class,'agreed-to-review')]//section[@class='img-box']//parent::div[contains(@class,'stat-tile agreed-to-review cur-pointer active')] "),"AGREED_TO_REVIEW_TILE_ACTIVE"),

	/** The send queued survey button. */
	SEND_QUEUED_SURVEY_BUTTON(By.xpath("//section[contains(@class,'filter revv-survey')]//button//span[text()='Send Queued Survey']"),"SEND_QUEUED_SURVEY_BUTTON"),

	SEND_QUEUED_SURVEY_CONFIRMATION_MODEL(By.xpath("//section[text()='All surveys \"queued for later\" will be delivered to your customers shortly.']"),"SEND_QUEUED_SURVEY_CONFIRMATION_MODEL"),

	SEND_QUEUED_SURVEY_CONFIRMATION_MODEL_DISMISS_BUTTON(By.xpath("//section[@class='send-queued-modal__card ']//button[text()='Dismiss']"),"SEND_QUEUED_SURVEY_CONFIRMATION_MODEL_DISMISS_BUTTON"),

	SEND_QUEUED_SURVEY_CONFIRMATION_MODEL_CONFIRM_BUTTON(By.xpath("//section[@class='send-queued-modal__card ']//button[text()='Confirm']"),"SEND_QUEUED_SURVEY_CONFIRMATION_MODEL_CONFIRM_BUTTON"),
	
	QUEUED_SURVEY_SUCCESSFULLY_SENT_POPUP(By.xpath("//div[contains(@class,'toast-container')]//span[text()='All unsent surveys will be delivered to your customers shortly.']//following-sibling::button[text()='DISMISS']"),"QUEUED_SURVEY_SUCCESSFULLY_SENT_POPUP"),

	/** The download all time. */
	DOWNLOAD_ALL_TIME(By.xpath("//span[text()='Download All-Time']//parent::button"),"SEND_QUEUED_SURVEY_BUTTON"),

	/** The download filtered. */
	DOWNLOAD_FILTERED(By.xpath("//section[contains(@class,'filter revv-survey')]//button//span[text()='Download Filtered']"),"SEND_QUEUED_SURVEY_BUTTON"),
    
	/** The please download popup with download button. */
	PLEASE_DOWNLOAD_POPUP_WITH_DOWNLOAD_BUTTON(By.xpath("//span[text()='Please click to download the surveys report.']//parent::div//following-sibling::button//span[text()='DOWNLOAD']"),"PLEASE_DOWNLOAD_POPUP_WITH_DOWNLOAD_BUTTON"),

	/** The please download popup with cancel button. */
	PLEASE_DOWNLOAD_POPUP_WITH_CANCEL_BUTTON(By.xpath("//span[text()='Please click to download the surveys report.']//parent::div//following-sibling::img[@class='cur-pointer close']"),"PLEASE_DOWNLOAD_POPUP_WITH_DOWNLOAD_BUTTON"),

	/** The clear filter inactive. */
	CLEAR_FILTER_INACTIVE(By.xpath("//button//span[text()='Clear Filter']"),"Clear Filter Inactive"),
	
	/** The clear filter active. */
	CLEAR_FILTER_ACTIVE(By.xpath("//div[@class='filter-item clear-filter']//div[@class='react-ripples ac-primary-box']//button"),"Clear Filter Button Active"),
	
	/** The from date. */
	FROM_DATE(By.xpath("//div[@class='react-datepicker-wrapper']//div[@class='react-datepicker__input-container']//input[@placeholder='MM/DD/YYYY']"),"From Date"),
	
	/** The to date. */
	TO_DATE(By.xpath("//div[@class='react-datepicker-wrapper']//div[@class='react-datepicker__input-container']//input[@placeholder='Most Recent']"),"To Date"),
	
    /** The date picker with zero. */
    DATE_PICKER_WITH_ZERO("//div[@class='react-datepicker__week']//div[contains(@class,'react-datepicker__day react-datepicker__day--00%s')]","Date with zero"),

	DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]","Date Picker"),

	/** The date picker without zero. */
    DATE_PICKER_WITHOUT_ZERO("//div[@class='react-datepicker__week']//div[contains(@class,'react-datepicker__day react-datepicker__day--0%s')]","Date witout zero"),
    
	/** The month dropdown. */
	MONTH_DROPDOWN(By.xpath("//select[@class='react-datepicker__month-select']"), "Month drop down"),

	/** The year dropdown. */
	YEAR_DROPDOWN(By.xpath("//select[@class='react-datepicker__year-select']"), "Year drop down."),

	/** The previous month. */
	PREVIOUS_MONTH_PICKER(By.xpath("//button[contains(@class,'datepicker__navigation--previous')]"), "Previous month."),

	/** The next month. */
	NEXT_MONTH_PICKER(By.xpath("//button[contains(@class,'datepicker__navigation--next')]"), "Next month."),
	
	/** The double digit calendar day. */
	DOUBLE_DIGIT_CALENDAR_DAY("(//div[contains(@class,'react-datepicker') and text()='%s'])[last()]",
			"Day of the Month"),

	/** The single digit calendar day. */
	SINGLE_DIGIT_CALENDAR_DAY("(//div[contains(@class,'react-datepicker') and text()='%s'])[1]",
			"Day of the Month"),
	
	/** The day of the month. */
	DAY_OF_THE_MONTH("//div[contains(@class,'react-datepicker') and text()='%s']","Day of the Month"),

	/** The location selector. */
	LOCATION_SELECTOR(By.xpath("//div[@class='filter-item fltr-drp']//h3[text()='Location Selector']//following-sibling::div[@class='locAction']//span[text()='All']"),"LOCATION_SELECTOR"),

	/** The all location button. */
	ALL_LOCATION_BUTTON(By.xpath("//div[@class='active cur-pointer all-selection' and text()='All Locations']"),"ALL_LOCATION_BUTTON"),
	
	/** The all location active. */
	ALL_LOCATION_ACTIVE(By.xpath("//div[@class='active cur-pointer all-selection' and text()='All Locations']"),"ALL_LOCATION_ACTIVE"),
	
    /** The location button. */
    LOCATION_BUTTON(By.xpath("//div[@class='modal-body']//div[@class='accordion']//button[@class='accordion-button collapsed' and text()='Locations  ']"),"LOCATION_BUTTON"),
	
    /** The location selector search tab. */
    LOCATION_SELECTOR_SEARCH_TAB(By.xpath("//div[@class='non-psp-loc-search']//input[@placeholder='Search']"),"LOCATION_SELECTOR_SEARCH_TAB"),
    
    /** The location select from dropdown. */
    LOCATION_SELECT_FROM_DROPDOWN("//div[@class='accordion-collapse collapse show']//li//span[@class='lbl ' and text()='%s']","LOCATION_SELECT_FROM_DROPDOWN"),
    
    /** The location list dropdown. */
    LOCATION_LIST_DROPDOWN(By.xpath("//div[@class='accordion-collapse collapse show']//div[@class='overflow-hidden accordion-body']//ul"),"LOCATION_LIST_DROPDOWN"),
    
    /** The location selector ok button. */
    LOCATION_SELECTOR_OK_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Ok']"),"LOCATION_SELECTOR_OK_BUTTON"),
    
    /** The location selector cancel button. */
    LOCATION_SELECTOR_CANCEL_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Cancel']"),"LOCATION_SELECTOR_CANCEL_BUTTON"),
    
	/** The all location active. */
	ANY_STATUS_FILTER_BUTTON(By.xpath("//h3[text()='Status']//parent::div//span[text()='Any status']"),"ANY_STATUS_FILTER_BUTTON"),
	
    /** The location button. */
    SURVEYS_SENT_FILTER_BUTTON(By.xpath("//h3[text()='Status']//parent::div//span[text()='Surveys Sent']"),"SURVEYS_SENT_FILTER_BUTTON"),
	
    /** The location selector search tab. */
    SURVEYS_NOT_SENT_FILTER_BUTTON(By.xpath("//h3[text()='Status']//parent::div//span[text()='Surveys Not Sent']"),"SURVEYS_NOT_SENT_FILTER_BUTTON"),
    
    
    /** The location select from dropdown. */
    SURVEYS_COMPLETED_FILTER_BUTTON(By.xpath("//h3[text()='Status']//parent::div//span[text()='Surveys Completed']"),"SURVEYS_COMPLETED_FILTER_BUTTON"),
    
    /** The agreed to review filter button. */
    AGREED_TO_REVIEW_FILTER_BUTTON(By.xpath("//h3[text()='Status']//parent::div//span[text()='Agreed to Review']"),"AGREED_TO_REVIEW_FILTER_BUTTON"),

    /** The left a command filter button. */
    LEFT_A_COMMAND_FILTER_BUTTON(By.xpath("//h3[text()='Status']//parent::div//span[text()='Left a Comment']"),"LEFT_A_COMMAND_FILTER_BUTTON"),
    
    /** The contact requested filter button. */
    CONTACT_REQUESTED_FILTER_BUTTON(By.xpath("//h3[text()='Status']//parent::div//span[text()='Contact Requested']"),"CONTACT_REQUESTED_FILTER_BUTTON"),
    
    /** The surveys table surveys sent filter contents. */
    SURVEYS_TABLE_SURVEYS_SENT_FILTER_CONTENTS(By.xpath("//div[contains(@class,'table-main__skeleton survey-tbl__wrp')]//th[text()='Status']//following::div[text()='Survey Sent']"),"SURVEYS_SENT_FILTER_CONTENTS"),
    
    /** The surveys table surveys not sent filter contents. */
    SURVEYS_TABLE_SURVEYS_NOT_SENT_FILTER_CONTENTS(By.xpath("//div[contains(@class,'skeleton survey-tbl')]//th[text()='Status']//following::div[text()='Cancelled']"),"SURVEYS_TABLE_SURVEYS_NOT_SENT_FILTER_CONTENTS"),

    SURVEYS_TABLE_SURVEYS_CANNOT_SENT_FILTER_CONTENTS(By.xpath("//th[text()='Status']//ancestor::table//tbody//tr//td[2]//div[text()=\"Can't Send\"]"),"SURVEYS_TABLE_SURVEYS_CANNOT_SENT_FILTER_CONTENTS"),

    /** The surveys table surveys completed filter contents. */
    SURVEYS_TABLE_SURVEYS_COMPLETED_FILTER_CONTENTS(By.xpath("//th[text()='Status']//ancestor::table//tbody//tr//td[2]//div[text()='Survey Completed']"),"SURVEYS_SENT_FILTER_CONTENTS"),

    /** The surveys table surveys agreed to review filter contents. */
    SURVEYS_TABLE_SURVEYS_AGREED_TO_REVIEW_FILTER_CONTENTS(By.xpath("//th[text()='Review Status']//ancestor::table//tbody//tr//td[5]//span[text()='Agreed to Review']"),"SURVEYS_SENT_FILTER_CONTENTS"),

    /** The surveys table left a comment contents. */
    SURVEYS_TABLE_LEFT_A_COMMENT_CONTENTS(By.xpath("//th[text()='Review Status']//ancestor::table//tbody//tr//td[5]//span[text()='Left a comment']"),"SURVEYS_TABLE_LEFT_A_COMMENT_CONTENTS"),

    /** The surveys table contact requested contents. */
    SURVEYS_TABLE_CONTACT_REQUESTED_CONTENTS(By.xpath("//th[text()='Review Status']//ancestor::table//tbody//tr//td[5]//span[text()='Contact Requested']"),"SURVEYS_TABLE_CONTACT_REQUESTED_CONTENTS"),

    /** The surveys table five star rating filter contents. */
    SURVEYS_TABLE_FIVE_STAR_RATING_FILTER_CONTENTS(By.xpath("//div[contains(@class,'skeleton survey-tbl')]//th[text()='Rating']//following::div//span[text()='5']"),"SURVEYS_TABLE_FIVE_STAR_RATING_FILTER_CONTENTS"),

    /** The surveys table four star rating filter contents. */
    SURVEYS_TABLE_FOUR_STAR_RATING_FILTER_CONTENTS(By.xpath("//div[contains(@class,'skeleton survey-tbl')]//th[text()='Rating']//following::div//span[text()='4']"),"SURVEYS_TABLE_FOUR_STAR_RATING_FILTER_CONTENTS"),

    /** The surveys table three star rating filter contents. */
    SURVEYS_TABLE_THREE_STAR_RATING_FILTER_CONTENTS(By.xpath("//div[contains(@class,'skeleton survey-tbl')]//th[text()='Rating']//following::div//span[text()='3']"),"SURVEYS_TABLE_THREE_STAR_RATING_FILTER_CONTENTS"),

    /** The surveys table two star rating filter contents. */
    SURVEYS_TABLE_TWO_STAR_RATING_FILTER_CONTENTS(By.xpath("//div[contains(@class,'skeleton survey-tbl')]//th[text()='Rating']//following::div//span[text()='2']"),"SURVEYS_TABLE_TWO_STAR_RATING_FILTER_CONTENTS"),

    /** The surveys table one star rating filter contents. */
    SURVEYS_TABLE_ONE_STAR_RATING_FILTER_CONTENTS(By.xpath("//div[contains(@class,'skeleton survey-tbl')]//th[text()='Rating']//following::div//span[text()='1']"),"SURVEYS_TABLE_ONE_STAR_RATING_FILTER_CONTENTS"),

    /** The all star filter active. */
    ALL_STAR_FILTER_ACTIVE(By.xpath("//h3[text()='Ratings']//parent::div[@class='filter-item']//label[contains(@class,'active')]//input[@value='all']"),"ALL_STAR_FILTER_ACTIVE"),
    
    /** The location selector cancel button. */
    ALL_STAR_FILTER(By.xpath("//h3[text()='Ratings']//parent::div[@class='filter-item']//input[@value='all']"),"ALL_STAR_FILTER"),
    
    /** The location button. */
    FIVE_STAR_FILTER(By.xpath("//h3[text()='Ratings']//parent::div[@class='filter-item']//span[text()='5 Stars']"),"FIVE_STAR_FILTER"),
	
    /** The location selector search tab. */
    FOUR_STAR_FILTER(By.xpath("//h3[text()='Ratings']//parent::div[@class='filter-item']//span[text()='4 Stars']"),"FOUR_STAR_FILTER"),
    
    /** The location select from dropdown. */
    THREE_STAR_FILTER(By.xpath("//h3[text()='Ratings']//parent::div[@class='filter-item']//span[text()='3 Stars']"),"THREE_STAR_FILTER"),

    /** The two star filter. */
    TWO_STAR_FILTER(By.xpath("//h3[text()='Ratings']//parent::div[@class='filter-item']//span[text()='2 Stars']"),"TWO_STAR_FILTER"),
  
    /** The one star filter. */
    ONE_STAR_FILTER(By.xpath("//h3[text()='Ratings']//parent::div[@class='filter-item']//span[text()='1 Star']"),"ONE_STAR_FILTER"),
  
    SURVEYS_TABLE_RECENTLY_ADDED_USER(By.xpath("(//div[contains(@class,'skeleton survey-tbl')]//div[text()='Customer']//parent::td//aside//span[@class='customer-name'])[1]"),"SURVEYS_TABLE_RECENTLY_ADDED_USER"),

    SURVEYS_TABLE_RECENTLY_ADDED_USER_MOBILE(By.xpath("(//div[contains(@class,'skeleton survey-tbl')]//div[text()='Customer']//parent::td//aside//span[@class='customer-phone'])[1]"),"SURVEYS_TABLE_RECENTLY_ADDED_USER_MOBILE"),
    
    SURVEYS_TABLE_RECENTLY_ADDED_RATING_STATUS(By.xpath("(//div[contains(@class,'skeleton survey-tbl')]//div[text()='Status']//following-sibling::div[text()='Survey Completed'])[1]"),"SURVEYS_TABLE_RECENTLY_ADDED_RATING_STATUS"),

    SURVEYS_TABLE_RECENTLY_ADDED_REVIEW_DATE(By.xpath("(//div[contains(@class,'skeleton survey-tbl')]//div[text()='Date Completed']//following-sibling::span[@class='date'])[1]"),"SURVEYS_TABLE_RECENTLY_ADDED_REVIEW_DATE"),

    SURVEYS_TABLE_RECENTLY_ADDED_REVIEW_STATUS(By.xpath("(//div[contains(@class,'skeleton survey-tbl')]//div[text()='Review Status']//following-sibling::div[@class='rev__stats--wrp'])[1]"),"SURVEYS_TABLE_RECENTLY_ADDED_REVIEW_STATUS"),

    SURVEYS_TABLE_RECENTLY_ADDED_REVIEW_RATING(By.xpath("(//div[contains(@class,'skeleton survey-tbl')]//div[text()='Rating']//parent::td//span)[1]"),"SURVEYS_TABLE_RECENTLY_ADDED_REVIEW_RATING"),
    
	REVV_DASHBOARD_TAB(By.xpath("//li[@class='ripple active']//span[@class='sub-nav-item-txt' and text()='Dashboard']"),"REVV_DASHBOARD_TAB"),
	
	/** The back to top button. */
		BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),

	SELECT_DROPDOWN_LIST("//div[@class='modal-body']//following::li//span[contains(text(),'%s')]",
			"Select dropdown list"),

	LOCATION_SELECTOR_BUTTON(By.xpath("//h3[text()='Location Selector']//following-sibling::div[@class='locAction']//span"), "Location selector button"),


	/** The no data to show. */
    NO_DATA_TO_SHOW(By.xpath("//div[contains(@class,'no-data')]//span[text()='No data to show']"),"NO_DATA_TO_SHOW");
    

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new revv SS page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private RevvTabSurveysPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new revv SS page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private RevvTabSurveysPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}



package com.rallio.automation.newrallio.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum DirectoryListingsOperationTimingsEnum.
 */
public enum DirectoryListingsOperationTimingsEnum {

	/** The one am. */
	ONE_AM("1:00 AM"),

	/** The five am. */
	FIVE_AM("5:00 AM"),

	/** The eight am. */
	EIGHT_AM("8:00 AM"),
	
	/** The nine am. */
	NINE_AM("9:00 AM"),

	/** The twelve pm. */
	TWELVE_PM("12:00 PM"),

	/** The six pm. */
	SIX_PM("6:00 PM"),

	/** The nine pm. */
	NINE_PM("9:00 PM");

	/** The value. */
	private String value;

	/**
	 * Instantiates a new directory listings operation timings enum.
	 *
	 * @param value the value
	 */
	private DirectoryListingsOperationTimingsEnum(String value) {

		this.value = value;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public String getValue() {

		return value;
	}
}

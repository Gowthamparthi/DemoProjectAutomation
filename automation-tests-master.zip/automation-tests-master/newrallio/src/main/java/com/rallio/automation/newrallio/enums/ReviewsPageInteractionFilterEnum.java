package com.rallio.automation.newrallio.enums;


// TODO: Auto-generated Javadoc
/**
 * The Enum ReviewsPageInteractionFilterEnum.
 */
public enum ReviewsPageInteractionFilterEnum {

	/** The show all. */
	SHOW_ALL,
	
	/** The only replied. */
	ONLY_REPLIED,
	
	/** The only not replied. */
	ONLY_NOT_REPLIED;
}

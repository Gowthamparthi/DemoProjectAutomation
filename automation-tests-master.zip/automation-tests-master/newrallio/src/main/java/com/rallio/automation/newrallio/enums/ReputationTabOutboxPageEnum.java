package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum ReputationTabOutboxPageEnum.
 */
public enum ReputationTabOutboxPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath(
	       "//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Outbox']//ancestor::div//section[@class='item-g filter inbox-filter']//preceding::div//section[@id='main-container-sec']//div[@class='mbl-head--margin outboxstat']"),
	        "Page load"),

	/** The total stats count. */
	TOTAL_STATS_COUNT(By.xpath("//div[contains(@class,'total-count')]//span[text()='TOTALS']//parent::div//span[@class='mod-count']//div"), "Total stats count"),

	/** The facebook stats count. */
	FACEBOOK_STATS_COUNT(By.xpath("//div[contains(@class,'fb-sc')]//img[@alt='Facebook']//parent::div//preceding-sibling::div//span[2]//div"), "Facebook stats count"),

	/** The twitter stats count. */
	X_FORMATTED_TWITTER_STATS_COUNT(By.xpath("//div[contains(@class,'ttr-sc')]//span[text()='X']//following-sibling::span[text()='(Formerly Twitter)']//following::span[1][@class='platform-count']//div"), "Twitter stats count"),

	/** The instagram stats count. */
	INSTAGRAM_STATS_COUNT(By.xpath("//div[contains(@class,'insta-sc')]//img[@alt='Instagram']//parent::div//preceding-sibling::div//span[2]//div"), "Instagram stats count"),

	/** The linkedin stats count. */
	LINKEDIN_STATS_COUNT(By.xpath("//div[contains(@class,'lkdin-sc')]//img[@alt='LinkedIn']//parent::div//preceding-sibling::div//span[2]//div"), "Linkedin stats count"),

	/** The facebook stats highlighted. */
	FACEBOOK_STATS_HIGHLIGHTED(By.xpath("//div[contains(@class,'stats-item fb-sc') and contains(@class,'active')]"), "Facebook stats highlighted"),

	/** The twitter stats highlighted. */
	TWITTER_STATS_HIGHLIGHTED(By.xpath("//div[contains(@class,'stats-item ttr-sc') and contains(@class,'active')]"), "Twitter stats highlighted"),

	/** The instagram stats highlighted. */
	INSTAGRAM_STATS_HIGHLIGHTED(By.xpath("//div[contains(@class,'stats-item insta-sc') and contains(@class,'active')]"), "Instagram stats highlighted"),

	/** The linkedin stats highlighted. */
	LINKEDIN_STATS_HIGHLIGHTED(By.xpath("//div[contains(@class,'stats-item lkdin-sc') and contains(@class,'active')]"), "Linkedin stats highlighted"),

	/** The create post button. */
	CREATE_POST_BUTTON(By.xpath("//div[contains(@class,'global-stats-section-wrp')]//span[text()='CREATE POST']"), "Create Post button"),

	/** The clear filter option. */
	CLEAR_FILTER_OPTION(By.xpath("//button//span[text()='Clear Filter']"), "Clear Filter option"),

	/** The clear all filter. */
	CLEAR_ALL_FILTER(By.xpath("//div[@class='react-ripples ac-primary-box' and not(contains(@class,'pointer-events-none'))]//button//span[text()='Clear Filter']"),
	        "Clear All Filter"),

	/** The from date. */
	FROM_DATE(By.xpath("//div[@class='dp-item date-end__wrp dp-from']//div[contains(@class,'react-datepicker__input-container')]//input[@placeholder='MM/DD/YYYY']"), "From date"),

	/** The from date active. */
	FROM_DATE_ACTIVE(By.xpath("//section[contains(@class,'filter')]//div[@class='dp-item dp-from active']"), "From date active"),

	/** The from date content. */
	FROM_DATE_CONTENT(By.xpath("//div[contains(@class,'dp-from')]//div[@class='react-datepicker__input-container']//input"), "From date content"),

	/** The select from date. */
	SELECT_FROM_DATE("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]", "Select From date"),

	/** The select from date with month. */
	SELECT_FROM_DATE_WITH_MONTH(
	        "//section[contains(@class,'filter')]//div[contains(@class,'dp-item dp-from')]//div[2]//div[@aria-disabled='false' and  contains(@aria-label,'%s')]","Select from date with month"),

	/** The from date previous month. */
	FROM_DATE_PREVIOUS_MONTH(By.xpath("//div[@class='react-datepicker']//button[@aria-label='Previous Month']"),
	        "From date previous month button"),

	/** The from date next month. */
	FROM_DATE_NEXT_MONTH(By.xpath("//div[@class='react-datepicker']//button[@aria-label='Next Month']"),
	        "From date next month button"),

	/** The select date from calendar. */
	SELECT_DATE_FROM_CALENDAR(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week']//div[@aria-disabled='false']"), "Select date from calendar"),

	/** The calendar displayed. */
	CALENDAR_DISPLAYED(By.xpath("//div[@class='react-datepicker__month']"), "Calendar displayed"),

	/** The select last date. */
	SELECT_LAST_DATE(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week'][3]//div[@aria-disabled='false'][last()]"), "Select last date"),

	/** The to date. */
	TO_DATE(By.xpath("//div[@class='dp-item date-end__wrp dp-to']//div[contains(@class,'react-datepicker__input-container')]//input[@placeholder='Most Recent']"), "To date"),

	/** The to date content. */
	TO_DATE_CONTENT(By.xpath("//div[contains(@class,'dp-to')]//div[@class='react-datepicker__input-container']//input"), "To date content"),

	/** The to date previous month. */
	TO_DATE_PREVIOUS_MONTH(By.xpath("//section[contains(@class,'filter')]//div[@class='dp-item dp-to active']//div[2]//button[@aria-label='Previous Month']"),
	        "To date previous month button"),

	/** The to date next month. */
	TO_DATE_NEXT_MONTH(By.xpath("//section[contains(@class,'filter')]//div[contains(@class,'dp-to')]//button[@aria-label='Next Month']"), "To date next month button"),

	/** The select to date. */
	SELECT_TO_DATE("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]", "Select To date"),

	/** The select to date with month. */
	SELECT_TO_DATE_WITH_MONTH("//section[contains(@class,'filter')]//div[contains(@class,'dp-to')]//div[@aria-disabled='false' and  contains(@aria-label,'%s')]",
	        "Select to date with month"),

	/** The platform filter. */
	PLATFORM_FILTER(By.xpath("//section[contains(@class,'filter')]//div[@class='filter-item']//h3[text()='Platform']"), "Platform filter"),

	/** The all filter button. */
	ALL_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'all-platform.svg')]//parent::button"),
	        "All filter button"),

	/** The all filter selected. */
	ALL_FILTER_SELECTED(
	        By.xpath(
	                "//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'all-platform.svg')]//parent::button[contains(@class,'active')]"),
	        "All filter selected"),

	/** The facebook filter button. */
	FACEBOOK_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'fb-platform')]//parent::button"),
	        "Facebook filter button"),

	/** The facebook filter selected. */
	FACEBOOK_FILTER_SELECTED(
	        By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'fb-platform')]//parent::button[contains(@class,'active')]"),
	        "Facebook filter selected"),

	/** The twitter filter button. */
	TWITTER_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'twitter-platform')]//parent::button"),
	        "Twitter filter button"),

	/** The twitter filter selected. */
	TWITTER_FILTER_SELECTED(
	        By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'twitter-platform')]//parent::button[contains(@class,'active')]"),
	        "Twitter filter selected"),

	/** The linkedin filter button. */
	LINKEDIN_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'linkedin-platform')]//parent::button"),
	        "LinkedIn filter button"),

	/** The linkedin filter selected. */
	LINKEDIN_FILTER_SELECTED(By
	        .xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'linkedin-platform')]//parent::button[contains(@class,'active')]"),
	        "LinkedIn filter selected"),

	/** The instagram filter button. */
	INSTAGRAM_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'instagram-platform')]//parent::button"),
	        "Instagram filter button"),

	/** The instagram filter selected. */
	INSTAGRAM_FILTER_SELECTED(By.xpath(
	        "//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'instagram-platform')]//parent::button[contains(@class,'active')]"),
	        "Instagram filter selected"),

	/** The engagement filter. */
	ENGAGEMENT_FILTER(By.xpath("//section[contains(@class,'filter')]//div[@class='filter-item']//h3[text()='Engagement Type']"), "Engagement filter"),

	/** The All Engagement filter. */
	ALL_ENGAGEMENT_FILTER(By.xpath(
	        "//section[contains(@class,'filter')]//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='All']"),
	        "All Engagement filter"),

	/** The All Engagement filter active. */
	ALL_ENGAGEMENT_FILTER_ACTIVE(By.xpath(
	        "//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='All']//ancestor::label[@class='active']"),
	        "All Engagement filter active"),

	/** The comment filter. */
	COMMENT_FILTER(By.xpath(
	        "//section[contains(@class,'filter')]//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[contains(text(),'Comment')]"),
	        "Comment filter"),

	/** The comment filter active. */
	COMMENT_FILTER_ACTIVE(By.xpath(
	        "//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[contains(text(),'Comment')]//ancestor::label[@class='active']"),
	        "Comment filter active"),

	/** The message filter. */
	MESSAGE_FILTER(By.xpath(
	        "//section[contains(@class,'filter')]//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='Message']"),
	        "Message filter"),

	/** The message filter active. */
	MESSAGE_FILTER_ACTIVE(By.xpath(
	        "//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='Message']//ancestor::label[@class='active']"),
	        "Message filter active"),

	/** The post filter. */
	POST_FILTER(By.xpath(
	        "//section[contains(@class,'filter')]//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='Post']"),
	        "Post filter"),

	/** The post filter active. */
	POST_FILTER_ACTIVE(By.xpath(
	        "//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='Post']//ancestor::label[@class='active']"),
	        "Post filter active"),

	/** The like filter. */
	LIKE_FILTER(By.xpath(
	        "//section[contains(@class,'filter')]//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[contains(text(),'Like')]"),
	        "Like filter"),
	
	/** The footer. */
	FOOTER(By.xpath("//div[contains(@class,'list-view')]//div[contains(@class,'list-item')][last()]"), "Footer"),

	/** The no data to show. */
	NO_DATA_TO_SHOW(By.xpath("//div[@class='content-g']//div[@class='no-data']//span[text()='No data to show']"), "No data to show"),

	/** The facebook contents. */
	FACEBOOK_CONTENTS(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset platform-icon']//img[contains(@src,'fb-lv.svg')]"),
	        "Facebook contents"),

	/** The twitter contents. */
	TWITTER_CONTENTS(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset platform-icon']//img[contains(@src,'twitter-lv.svg')]"),
	        "Twitter contents"),

	/** The linkedin contents. */
	LINKEDIN_CONTENTS(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset platform-icon']//img[contains(@src,'linkedin-lv.svg')]"),
	        "Linked In contents"),

	/** The instagram contents. */
	INSTAGRAM_CONTENTS(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset platform-icon']//img[contains(@src,'instagram-lv.svg')]"),
	        "Instagram contents"),

	/** The social media icon. */
	SOCIAL_MEDIA_ICON(
	        "//div[@class='list-view']//p[contains(text(),'%s')]//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset platform-icon']//img",
	        "Social media icon"),

	SOCIAL_PLATFORM_ICON(By.xpath("//div[@class='list-view']//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset platform-icon']//img"),"Social Platform Icon"),

	/** The post profile icon. */
	POST_PROFILE_ICON(
	        "//div[@class='list-view']//p[contains(text(),'%s')]//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset brand-icon']//img",
	        "Post profile icon"),

	POST_PROFILE_IMAGE(By.xpath("//div[@class='list-view']//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset brand-icon']//img"),"Post Profile Image"),
	
	/** The location name. */
	LOCATION_NAME("//div[@class='list-view']//p[contains(text(),'%s')]//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//h3",
	        "Location name"),

	POST_LOCATION_NAME(By.xpath("//div[@class='list-view']//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//h3"),"Post Location Name"),
	
	/** The post comment date time. */
	POST_COMMENT_DATE_TIME(By.xpath("//div[@class='lvt-brief']//following-sibling::span[@class='lvt-txt']"),
	        "Post comment date and time"),
	
	/** The posted date time. */
	POSTED_DATE_TIME(
	        "//div[@class='list-view']//p[contains(text(),'%s')]//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//div//span[@class='lvt-txt'][2]",
	        "Posted date time"),
	
    POSTED_POST_DATE_TIME(By.xpath("//div[@class='list-view']//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//div//span[@class='lvt-txt'][2]"),"Posted Post Date And Time"),	
    
    POST_LIKE_BUTTON(By.xpath("//div[@class='list-view']//ancestor::div[@class='li-base']//div[@class='vc-item']//span[text()='Like']"),"Post Like Button"),
    
    POST_MORE_OPTION(By.xpath("//div[@class='list-view']//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='drop-items dropdown']//button"),"More Option"),
    
    // SOCIAL_MEDIA_PROFILE_IMAGE("//div[@class='list-view']//p[contains(text(),'%s')]//ancestor::div[contains(@class,'list-item')]//div[@class='liv-left
    // li-top']//div//img", "Social media profile image"),

    // SOCIAL_MEDIA_PROFILE_NAME("//div[@class='list-view']//p[contains(text(),'%s')]//ancestor::div[contains(@class,'list-item')]//div[@class='liv-left
    // li-top']//div[@class='lvt-details']//h3", "Social media profile name"),

	/** The social media profilename hover text. */
	SOCIAL_MEDIA_PROFILENAME_HOVER_TEXT(By.xpath("//div[@class='rc-tooltip-content']//div[@class='rc-tooltip-inner']//span"), "Profile name hover text"),

	/** The posted something to. */
	POSTED_SOMETHING_TO(
	        "//div[@class='list-view']//p[contains(text(),'%s')]//ancestor::div[contains(@class,'list-item')]//div[@class='liv-left li-top']//div[@class='lvt-brief']//span[text()]",
	        "Posted something to"),

	/** The three dots button. */
	THREE_DOTS_BUTTON(
	        "//div[@class='list-view']//p[contains(text(),'%s')]//ancestor::div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='drop-items dropdown']//button",
	        "Three dots button"),

	/** The link button. */
	LINK_BUTTON(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='drop-items show dropdown']//a//span[text()='Link to Post']"), "Link button"),

	/** The post delete button. */
	POST_DELETE_BUTTON(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='drop-items show dropdown']//a//span[text()='Delete']"),
	        "Post delete button"),

	/** The post delete alert box. */
	POST_DELETE_ALERT_BOX(By.xpath("//div[text()='Are you sure you want to delete this post?']"), "Post delete alert box"),

	/** The delete alert cancel button. */
	DELETE_ALERT_CANCEL_BUTTON(By.xpath("//button[text()='Cancel']"), "Delete alert cancel button"),

	/** The delete alert delete button. */
	DELETE_ALERT_DELETE_BUTTON(By.xpath("//button[text()='Delete']"), "Delete alert delete button"),

	/** The post deleted message. */
	POST_DELETED_MESSAGE(By.xpath("//span[text()='Done!']"), "Post deleted message"),

	/** The outbox page active. */
	OUTBOX_PAGE_ACTIVE(By.xpath("//div[contains(@class,'sub-nav-tabs')]//span[text()='Outbox']//parent::li[@class='ripple active']"), "Outbox page activae"),

	/** The outbox contents. */
	OUTBOX_CONTENTS(By.xpath("//div[contains(@class,'infinite-scroll-component local-ini')]//div[contains(@class,'list-view')]//div[contains(@class,'list-item')]"),
	        "Outbox contents"),

	/** Outbox Posts list. */
	OUTBOX_POSTS_LIST(By.xpath("//div[@id='outbox-list-ifs']//div[@class='list-view']//div[contains(@class,'list-item')]"), "Outbox Posts list"),

	/** The Reuse button. */
	REUSE_BUTTON("//div[@class='list-view']//p[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//span[text()='Reuse']", "Reuse button"),

	/** The reuse button. */
	FACEBOOK_REUSE_BUTTON(By.xpath("//div[@class='li-base']//div[@class='vc-item']//span[text()='Reuse']"), "Reuse button"),
	
	/** The reuse option. */
	REUSE_OPTION(By.xpath("//div[@class='list-view']//div[@class='vc-item']//span[text()='Reuse']"),"Reuse Option"),
	
	/** The like button. */
	LIKE_BUTTON("(//div[@class='list-view']//p[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//span[text()='Like'])[1]", "Like button"),

	LIKE_FIELD(By.xpath("//div//span//ancestor::div[@class='li-base']//div[@class='vc-item']//span[text()='Like']"),"Like Field"),
	
	/** The facebook post not liked. */
	FACEBOOK_POST_NOT_LIKED("//div[@class='list-view']//p[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'fb-like.svg')]","Facebook post liked"),

	FACEBOOK_LIKED_POST("//div[@class='list-view']//p[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'fb-like-a.svg')]","Facebook post liked"),

	/** The facebook post liked. */
	FACEBOOK_POST_LIKED("//div[@class='list-view']//p[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@alt,'Like')]",
	        "Facebook post liked"),

	/** The twitter post not liked. */
	TWITTER_POST_NOT_LIKED(
	        "(//div[@class='list-view']//p[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'twitter-like.svg')])[1]",
	        "Twitter post not liked"),

	/** The twitter post liked. */
	TWITTER_POST_LIKED(
	        "(//div[@class='list-view']//p[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'twitter-like-a.svg')])[1]",
	        "Twitter post liked"),

	/** The instagram post not liked. */
	INSTAGRAM_POST_NOT_LIKED(
	        "//div[@class='list-view']//p[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'instagram-like.svg')]",
	        "Instagram post not liked"),

	/** The instagram post liked. */
	INSTAGRAM_POST_LIKED(
	        "//div[@class='list-view']//p[contains(text(),'%s')]//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'instagram-like-a.svg')]",
	        "Instagram post liked"),

	/** The linkedin post not liked. */
	LINKEDIN_POST_NOT_LIKED(By.xpath("//div[@class='list-view']//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'linkedin-like.svg')]"),"Linkedin Post Not Liked"),
	LINKEDIN_POST_LIKED(By.xpath("//div[@class='list-view']//ancestor::div[@class='li-base']//div[@class='vc-item']//img[contains(@src,'linkedin-like-a.svg')]"),"Linkedin Post Liked"),
	/** The comment only posts. */
	COMMENT_ONLY_POSTS(By.xpath("//div[@class='list-view']//div[@class='list-item animate__animated animate__fadeIn outbox__main']"),
	        "Comment only posts"),

	/** The message contents. */
	MESSAGE_CONTENTS(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lv-assets']"), "Message contents"),

	/** The post text content. */
	POST_TEXT_CONTENT(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-base']//p[text()]"), "Post text content"),

	/** The post text withimage. */
	POST_TEXT_WITHIMAGE(By.xpath("//div[@class='lv-assets']//div[contains(@class,'gma-item')]//img//ancestor::div[contains(@class,'list-item')]//div[@class='sm-content']//span//span//span//span"),"Post Describtion from image"),
	
	/** Created Post. */
	CREATED_POST("//div[contains(@class,'list-item')]//div[@class='sm-content']//span//span//span//span[contains(text(),'%s')]", "Created post"),

	/** The post image content. */
	POST_IMAGE_CONTENT(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lv-assets']//li[2]//div[@class='gma-item']//img"), "Post image content"),

	/** The creator page load. */
	CREATOR_PAGE_LOAD(By.xpath("//span[text()='Creator']//following::section[contains(@class,'item-g filter')]//ancestor::div//section[@id='main-container-sec']//div[@class='addpost-section-main-wrp creator__main--content']"), "Creator pageLoad"),

	/** The month picker. */
	MONTH_PICKER(By.xpath("//select[@class='react-datepicker__month-select']"), "Month picker"),

	/** The date time. */
	DATE_TIME(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//div//span[@class='lvt-txt'][2]"), "Date time"),
	
	/** Outbox page Enums **. */

	ALL_FILTER_OPTION(By.xpath("//label//span[@class='labelText' and text()='All']"),"All Filter Option"),
	
	/** The all filter active. */
	ALL_FILTER_ACTIVE(By.xpath("//label[@class='active']//span[@class='labelText' and text()='All']"),"All filter Active"),
	
	/** The like filter active. */
	LIKE_FILTER_ACTIVE(By.xpath("//label[@class='active']//input[@class='option-input radio' and @value='Like']"), "The Like Filter Active"),

	/** The like filter pageload. */
	LIKE_FAVOURITE_FILTER_PAGELOAD(By.xpath("//div[@class='list-view']//div[contains(@class,'list-item')]//ancestor::div[@class='lvci-cnt']//span[text()='Favorites']"),
	        "The Like/Favourite Pageload"),

	LIKES(By.xpath("//div[@class='list-view']//div[@class='lvci-cnt']//span[@class='lvc-count']//following-sibling::span[text()='Likes']"),"Likes"),
	
	/** The write a comment. */
	WRITE_A_COMMENT(By.xpath(
	        "//div[contains(@class,'list-item')]//ancestor::div//div[@class='public-DraftStyleDefault-block public-DraftStyleDefault-ltr']"),
	        "The Write A comment"),

	WRITE_A_COMMENT_TEXT(By.xpath("//div[contains(@class,'list-item')]//ancestor::div//div[@class='public-DraftStyleDefault-block public-DraftStyleDefault-ltr']"),"Write the comment"),

	/** The post comment button. */
	POST_COMMENT_BUTTON(By.xpath("//div[@class='lvc-base']//button[text()='Post Comment']"), "The Post Comment Button"),

	/** The reply sent popup. */
	REPLY_SENT_POPUP(By.xpath("//div//span[text()='Reply sent!']"), "The Reply sent Popup"),

	/** The more option. */
	MORE_OPTION(By.xpath("//div[@class='list-view']//button[@id='dropitems-more-options']//div[@class='more-dots-horizontal']//img[@alt='More']"), "The Post Content More Option"),

	/** The post delete ok button. */
	POST_DELETE_OK_BUTTON(By.xpath("//div//button[text()='Ok']"), "The Post delete ok button"),

	ALERT_DELETE_BUTTON(By.xpath("//div//button[text()='Delete']"),"Alert Delete Button"),

	/** The facebook pageload. */
	FACEBOOK_PAGELOAD_WITHOUTIMAGE(By.xpath("//u[text()='Facebook']//parent::i[@class='fb_logo img sp_Awgqz7K4lHq sx_55d19b']//ancestor::div//div[@id='contentCol']"), "The Facebook Pageload without Image"),

	/** The facebook pageload withimage. */
	FACEBOOK_PAGELOAD_WITHIMAGE(By.xpath("//div[contains(@class,'rq0escxv l9j0dhe7')]//ancestor::div[@class='l9j0dhe7 buofh1pr j83agx80 bp9cbjyn']"),"The Facebook Pageload with image"),

	FACEBOOK_DETAIL_VIEW_REPLY_TEXT("//*[contains(text(),'%s')]","Facebook Detailview Reply Text"),

	/** The twitter pageload. */
	TWITTER_PAGELOAD(
	        "//span[text()='Tweet']//ancestor::div[@class='css-1dbjc4n r-aqfbo4 r-16y2uox']//div[contains(@class,'css-1dbjc4n r-18u37iz r-15zivkp')]//following::span[contains(text(),'%s')]",
	        "Twitter Page load"),

	/** The linkedin pageload. */
	LINKEDIN_PAGELOAD("//span[text()='LinkedIn']//ancestor::div[@class='share-update-card  main-feed-card public-post']//p[contains(text(),'%s')]", "Linkedin Pageload"),

	LINKEDIN_DETAILVIEW_DISMISS(By.xpath("//div[contains(@class,'contextual-sign-in-modal_screen')]//following::button[@aria-label='Dismiss']"),"LINKEDIN_DETAILVIEW_DISMISS"),

	LINKEDIN_DETAILVIEW_POST_REPLY_TEXT("//*[contains(@class,'comment flex grow-1 items-stretch')]//div[contains(@class,'attributed-text-segment-list__container')]//p[contains(text(),'%s')]","Linkedin Detailview Post Reply Text"),

	/** The profile icon hover tooltip. */
	PROFILE_ICON_HOVER_TOOLTIP(By.xpath("//div[@class='common-tooltip--wrp' and text()='This content was posted from Twitter']"),
	        "Twitter icon hover ,This content was posted from Twitter"),

	/** The rallio profile icon hover. */
	RALLIO_PROFILE_ICON_HOVER(By.xpath("//div[@class='common-tooltip--wrp' and text()='This content was posted from the Rallio Platform']"),"The Rallio profile icon hover in tooltip"),

	LINKEDIN_PROFILE_ICON_HOVER_TOOLTIP(By.xpath("//div[@class='common-tooltip--wrp' and text()='This content was posted from Linkedin']"),"The LinkedIn profile icon hover in tooltip"),

	FACEBOOK_PROFILE_ICON_HOVER_TOOLTIP(By.xpath("//div[@class='common-tooltip--wrp' and text()='This content was posted from Facebook']"),"The Facebook profile icon hover in tooltip"),
	/** The retweet count. */
	RETWEET_COUNT(By.xpath("//span[text()='Retweets']//parent::div//span[@class='lvc-count']"), "The Retweet Count "),

	/** The favourites count. */
	FAVOURITES_COUNT(By.xpath("//span[text()='Favorites']//parent::div//span[@class='lvc-count']"), "Favourite Count"),

	/** The reactions count. */
	REACTIONS_COUNT(By.xpath("//span[text()='Reactions']//parent::div[@class='lvci-cnt']//span[@class='lvc-count']"),"Recation Count"),
	
	/** The comments count. */
	COMMENTS_COUNT(By.xpath("//span[text()='Comments']//parent::div[@class='lvci-cnt']//span[@class='lvc-count']"),"Comments Count"),
	
	SHARES_COUNT(By.xpath("//span[text()='Shares']//parent::div[@class='lvci-cnt']//span[@class='lvc-count']"),"Shares Count"),
	
	/** Location Selector*. */
	
	/**  Location search option. */ 
	LOCATION_SEARCH(By.xpath("//input[@type='text' and @name='Locations']") , "Location selector Search option"), 
	
	/** The location selector. */
	LOCATION_SELECTOR(By.xpath("//section//*[text()='Location Selector']//parent::div//span[@class='lcs-name']"), "Location Selecter."),

	/** The location selector search tab. */
	LOCATION_SELECTOR_SEARCH_TAB(By.xpath("//div[@class='asm-lf']//input[@placeholder = 'Search']"), "Location Selecter Search Tab"),

	/** The location selector locationlist tab. */
	LOCATION_SELECTOR_LOCATIONLIST_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Location Lists']"), "Location Selecter Location List tab."),

	/** The location selector location tab open. */
	LOCATION_SELECTOR_LOCATION_TAB_OPEN(By.xpath("//img[contains(@src,'location')]//ancestor::div[contains(@class,'collapse show')]"), "Location Selecter Location Tab Open"),

	/** The locator selector name. */
	LOCATOR_SELECTOR_NAME("//span[@class='lcs-name' and @title='%s']","The Location selector Name"),
	
	/** The location selector location tab. */
	LOCATION_SELECTOR_ALL_LOCATION_TAB(By.xpath("//input[@name='selectedLocation']//following-sibling::span[text()='All Locations']"), "The All Locations selector tab."),

	/** The location selector ok button. */
	LOCATION_SELECTOR_OK_BUTTON(By.xpath("//div[@class='asm-btn']//div//button[text()='Ok']"), "Location Selecter Ok Button"),

	/** The location selector close button. */
	LOCATION_SELECTOR_CLOSE_BUTTON(By.xpath("//img[@class='close-icon']"), "Location Selector Close Button"),

	/** The location selector cancel button. */
	LOCATION_SELECTOR_CANCEL_BUTTON(By.xpath("//div[@class='asm-btn']//div//button[text()='Cancel']"), "Location Selector Cancel Button"),

	/** The location selector open tab. */
	LOCATION_SELECTOR_OPEN(By.xpath("//div[@class='asm-btn']//parent::div[@class='modal-footer']//preceding-sibling::div[@class='asm-accord']"), "Location Selecter Open."),

	/** The location selector byname. */
	LOCATION_SELECTOR_BYNAME("//div[contains(@class,'list-item')]//div[@class='lvt-details']//h3[contains(text(),'%s')]","The Location Selector By name"),
	
	/** The location selector hub tab. */
	LOCATION_SELECTOR_HUB_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Hubs']"), "Location Selecter Hub tab."),

	/** The location selector hub tab open. */
	LOCATION_SELECTOR_HUB_TAB_OPEN(By.xpath("//img[contains(@src,'hubs')]//ancestor::div[contains(@class,'collapse show')]"), "Location Selecter Hub Tab Open."),

	/** The location selector dropdown user. */
	LOCATION_SELECTOR_DROPDOWN_USER("//div//ul[@class='hub-list']//span[contains(text(),\"%s\")]", "Location Selecter Dropdown User"),

	/** The locations selector count. */
	LOCATIONS_SELECTOR_COUNT(By.xpath("//div[@class='locAction']//span[@class='lca-sel-label bl-count']"),"The Location selector Count"),
	
	/** The locations dropdown. */
	LOCATIONS_DROPDOWN(By.xpath("//div[4][@class='accordion']//span[@class='lca-head' and text()='Locations']"),"The Locations Dropdown"),

	/** The month dropdown. */
	MONTH_DROPDOWN(By.xpath("//select[@class='react-datepicker__month-select']"), "Month drop down"),

	/** The year dropdown. */
	YEAR_DROPDOWN(By.xpath("//select[@class='react-datepicker__year-select']"), "Year drop down."),

	
	/** The instagram username field. */
	INSTAGRAM_USERNAME_FIELD(By.xpath("//span//following-sibling::input[@name='username']"),"The Instagram username"),
	
	/** The instagram password field. */
	INSTAGRAM_PASSWORD_FIELD(By.xpath("//span//following-sibling::input[@name='password']"),"The Instagram password"),
	
	/** The instagram login button. */
	INSTAGRAM_LOGIN_BUTTON(By.xpath("//div//button[@type='submit']//div[text()='Log In']"),"The Instagram Login button"),

	/** The twitter icon hover. */
	POST_SOCIAL_MEDIA_ICON_HOVER(By.xpath("//div[@class='lvt-brief']//span//following-sibling::img[@class='pu-asset lvtb-icon']"), "The Profile Icon Hover"),
	
	/** The date picker. */
    DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]","Date Picker"),
    
	/** The outbox post by text. */
	OUTBOX_POST_BY_TEXT("//div[contains(@class,'list-item')]//div[@class='sm-content']//span//span//span//span[text()='%s']", "Outbox Post By Text"),
	
	PIE_RELOAD(By.xpath("//button[contains(@class,'ac-btn ac-primary-white')]//img[@alt='pie-reload']//following-sibling::span[text()='Reload']"),"Pie Reload"),
	        
	POST_TEXT_FIELD("//div[@class='list-view']//div[@class='list-item animate__animated animate__fadeIn outbox__main']//p[text()='%s']","Post Text Field"),
	
	/** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),

	FACEBOOK_CLOSE_BUTTON(By.xpath("//div[@aria-label='Close']"),"FACEBOOK_CLOSE_BUTTON"),

	/** The tiktok stats count. */
	TIKTOK_STATS_COUNT(By.xpath("//div[contains(@class,'platform-icon')]//img[@alt='TikTok']//parent::div//preceding-sibling::div//span[2]//div"),"TikTok Stats Count"),
	LINKEDIN_POST_LIKE_ICON_IS_ACTIVE("//*[contains(@class,'comment flex grow-1 items-stretch')]//div[contains(@class,'attributed-text-segment-list__container')]//p[contains(text(),'%s')]//preceding::div//img[@data-reaction-type='LIKE']","Linkedin post like icon is active"),
	FACEBOOK_POST_LIKE_ICON_IS_ACTIVE("//div[text()='%s']//preceding::div//img[@role='presentation']","Facebook post like icon is active"),
	REPLY_SENT_MESSAGE(By.xpath("//span[contains(text(),'Reply sent!')]"), "Reply sent message"),

    /** The post by time. */
    POST_BY_TIME(By.xpath("//div[@class='lvt-brief']//following-sibling::span[text()]"),"Post By Time");	
	
	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new reputation tab outbox page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private ReputationTabOutboxPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new reputation tab outbox page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private ReputationTabOutboxPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

public enum RevvTabSettingsSurveysSectionEnum {
	
    PAGE_LOAD_FOR_END_USER(By.xpath("//div[contains(@class,'sub-nav-tabs')]//span[text()='Settings']//parent::li[contains(@class,'active')]//ancestor::div[contains(@class,'head')]//following-sibling::main//div[@class='settings__card']//div[@class='survey-inner__title' and text()='Edit Survey Sms Message']"),"PAGE_LOAD_FOR_END_USER"),

	PAGE_LOAD_SURVEYS_SECTION(By.xpath("//div[contains(@class,'sub-nav-tabs')]//span[text()='Revv']//parent::li[contains(@class,'active')]//following::div[@class='mobile-active active nav-item' and text()='Survey']//ancestor::div//div[contains(@class,'non-psp-settings__container')]"),"PAGE_LOAD"),


    EDIT_SURVEY_SMS_MESSAGE_DESCRIPTION(By.xpath("//div[text()='Edit Survey Sms Message']//parent::div//following-sibling::div//div[text()='This is the actual survey question your customers will receive.']"),"EDIT_SURVEY_SMS_MESSAGE_DESCRIPTION"),
    
    EDIT_SURVEY_SMS_MESSAGE_TEXT_AREA(By.xpath("//div[text()='Edit Survey Sms Message']//parent::div//following-sibling::div//textarea"),"EDIT_SURVEY_SMS_MESSAGE_TEXT_AREA"),

	EDIT_SURVEY_SMS_MESSAGE_NOTE_SECTION(By.xpath("//div[text()='Edit Survey Sms Message']//parent::div//following-sibling::div//strong[text()='Note:']//parent::div//following-sibling::div[text()=' will insert the survey URL into the text (required).']"),"EDIT_SURVEY_SMS_MESSAGE_NOTE_SECTION"),

	EDIT_SURVEY_SMS_MESSAGE_REPLY_STOP_TO_CANCEL(By.xpath("//div[text()='Edit Survey Sms Message']//parent::div//following-sibling::div//strong[text()='Note:']//parent::div//following-sibling::div[text()='\"Reply STOP to cancel.\" will be added to the end of the text.']"),"'Reply STOP to cancel.' will be added to the end of the text."),
	//Note sections
    NOTE_SECTION_SURVEY_LINK("//div[text()='%s']//parent::div//following-sibling::div//strong[text()='Note:']//parent::div//following-sibling::div[text()=' will insert the survey URL into the text (required).']","@surveylink will insert the survey URL into the text (required).\n"),

	NOTE_SECTION_BUSINESS_NAME("//div[text()='%s']//parent::div//following-sibling::div//strong[text()='Note:']//parent::div//following-sibling::div[text()=' will insert your business name into the text (required).']"," @businessname will insert your business name into the text (required)."),

	NOTE_SECTION_LOCATION_NAME("//div[text()='%s']//parent::div//following-sibling::div//strong[text()='Note:']//parent::div//following-sibling::div[text()=' will insert your location name into the text.']"," @locationname will insert your location name into the text."),

	NOTE_SECTION_LEAVE_BLANK_FOR_DEFAULT_MESSAGE("//div[text()='%s']//parent::div//following-sibling::div//strong[text()='Note:']//parent::div//following-sibling::div[text()='Leave blank for default message.']","Leave blank for default message."),

	NOTE_SECTION_EMPLOYEE_FIRST_NAME("//div[text()='%s']//parent::div//following-sibling::div//strong[text()='Note:']//parent::div//following-sibling::div//b[text()='customerfirstname']","@employeefirstname will insert the employee's first name into the text."),

	NOTE_SECTION_EMPLOYEE_LAST_NAME("//div[text()='%s']//parent::div//following-sibling::div//strong[text()='Note:']//parent::div//following-sibling::div//b[text()='customerfirstname']","@employeelastname will insert the employee's last name into the text."),

	NOTE_SECTION_CUSTOMER_FIRST_NAME("//div[text()='%s']//parent::div//following-sibling::div//strong[text()='Note:']//parent::div//following-sibling::div//b[text()='customerfirstname']","@customerfirstname will insert the customer's first name into the text."),

	NOTE_SECTION_CUSTOMER_LAST_NAME("//div[text()='%s']//parent::div//following-sibling::div//strong[text()='Note:']//parent::div//following-sibling::div//b[text()='customerfirstname']","@customerlastname will insert the customer's last name into the text."),

	//Buttons

	EDIT_SURVEY_SMS_MESSAGE_PREVIEW_BUTTON(By.xpath("//div[text()='Edit Survey Sms Message']//parent::div//following-sibling::div[@class='settings-inner__right']//button[text()='Preview']"),"EDIT_SURVEY_SMS_MESSAGE_PREVIEW_BUTTON"),
    
    EDIT_SURVEY_EMAIL_MESSAGE_DESCRIPTION(By.xpath("//div[text()='Edit Survey Email Message (Optional)']//parent::div//following-sibling::div//div[text()='This is the additional text your customers will receive on the survey email.']"),"EDIT_SURVEY_EMAIL_MESSAGE_DESCRIPTION"),
    
    EDIT_SURVEY_EMAIL_MESSAGE_TEXT_AREA(By.xpath("//div[text()='Edit Survey Email Message (Optional)']//parent::div//following-sibling::div//textarea"),"EDIT_SURVEY_EMAIL_MESSAGE_TEXT_AREA"),

    EDIT_SURVEY_EMAIL_MESSAGE_NOTE_SECTION(By.xpath("//div[text()='Edit Survey Email Message (Optional)']//parent::div//following-sibling::div//strong[text()='Note:']//parent::div//following-sibling::div[text()=' will insert the survey URL into the text (required).']"),"EDIT_SURVEY_EMAIL_MESSAGE_NOTE_SECTION"),

    EDIT_SURVEY_EMAIL_MESSAGE_PREVIEW_BUTTON(By.xpath("//div[text()='Edit Survey Email Message (Optional)']//parent::div//following-sibling::div//button[text()='Preview']"),"EDIT_SURVEY_EMAIL_MESSAGE_PREVIEW_BUTTON"),
    
    EDIT_SURVEY_EMAIL_SUBJECT_DESCRIPTION(By.xpath("//div[text()='Edit Survey Email Subject (Optional)']//parent::div//following-sibling::div//div[text()='This is the subject your customers will see on the survey email.']"),"EDIT_SURVEY_EMAIL_SUBJECT_DESCRIPTION"),
    
    EDIT_SURVEY_EMAIL_SUBJECT_TEXT_AREA(By.xpath("//div[text()='Edit Survey Email Subject (Optional)']//parent::div//following-sibling::div//textarea"),"EDIT_SURVEY_EMAIL_SUBJECT_TEXT_AREA"),

    EDIT_SURVEY_EMAIL_SUBJECT_PREVIEW_BUTTON(By.xpath("//div[text()='Edit Survey Email Subject (Optional)']//parent::div//following-sibling::div//button[text()='Preview']"),"EDIT_SURVEY_EMAIL_SUBJECT_PREVIEW_BUTTON"),

    REVV_CONNECTION_DISCONNECT_BUTTON(By.xpath("//section//button//span[text()='Disconnect']"),"REVV_CONNECTION_DISCONNECT_BUTTON"),

	REVV_CONNECTION_USER_NAME(By.xpath("//div[@class='member-dtls']//div[@class='img-holder member-initial-thumb blue']//following-sibling::div//h5"),"REVV_CONNECTION_USER_NAME"),

	REVV_CONNECTION_USER_DATE_TIME(By.xpath("//div[@class='member-dtls']//div[@class='img-holder member-initial-thumb blue']//following-sibling::div//div//span[text()='Revv account connected at ']//following-sibling::span[@class='time-dtls']"),"REVV_CONNECTION_USER_DATE_TIME"),

	SURVEYS_URL(By.xpath("//input[@name='staticLink']"),"Surveys Url"),

	SOCIAL_MEDIA_URL("//div[contains(@class,'settings-modal__grp white-labe')]//input[contains(@name,'%s')]","Social Media Url"),

	DRAG_DROP_AND_BROWSE_BUTTON(By.xpath("//span[@class='text-msg' and text()=\"Drag & Drop your \"and \"review platform logo\" and \" here to upload\"]//following::button"),"Drag Drop"),

	SURVEYS_RATING_WITH_EMOJI("//input[contains(@id,'rating') and @value='%s']//parent::li//img","Surveys rating"),

	TABLE_SURVEYSPAGE_RATING("//tbody//tr//td[6]//img[@alt='review-status']//following-sibling::span[text()='%s']","Table Syrveys Page rating"),

	SEND_BUTTON(By.xpath("//div//input[@type='submit']"),"Send Button"),

	CONFIRM_BUTTON(By.xpath("//button[text()='CONFIRM']"),"Confirm Button"),

	YES_BY_PHONE_BUTTON(By.xpath("//div[@class='user-information--buttons']//button[@value='contact_by_phone']"),"Yes By Phone Button"),

	PHONE_NUMBER_FIELD(By.xpath("//input[@placeholder='(555)-555-5555']"),"Phone Number Field"),

	SEND_FEEDBACK_FIELD(By.xpath("//div//textarea[@name='survey[customer_feedback]']"),"Send feedback Field"),

    SURVEYS_REVIEW_SOCIAL_MEDIA_ICON(By.xpath("//div[@class='customer-survey--social-media']"),"Surveys Review Social Media Icon"),

	CANCEL_BUTTON(By.xpath("//button[text()='Cancel']"),"CANCEL_BUTTON"),
	UPDATE_BUTTON(By.xpath("//button[text()='Update']"),"UPDATE_BUTTON"),

	EDIT_SURVEY_SMS_MESSAGE(By.xpath("//div[text()='Edit Survey Sms Message' and @class='survey-inner__title']"),"EDIT_SURVEY_SMS_MESSAGE"),

	EDIT_SURVEY_EMAIL_SUBJECT_OPTIONAL(By.xpath("//div[text()='Edit Survey Email Subject (Optional)' and @class='survey-inner__title']"),"EDIT_SURVEY_EMAIL_SUBJECT_OPTIONAL"),

	EDIT_SURVEY_EMAIL_SUBJECT_OPTIONAL_DESCRIPTION(By.xpath("//div[text()='Edit Survey Email Subject (Optional)' and @class='survey-inner__title']/../div//following::div[text()='This is the subject your customers will see on the survey email.']"),"This is the subject your customers will see on the survey email."),

	EDIT_SURVEY_EMAIL_SUBJECT_OPTIONAL_TEXT_AREA(By.xpath("//div[text()='Edit Survey Email Subject (Optional)' and @class='survey-inner__title']/../div//following::div[text()='This is the subject your customers will see on the survey email.']//following::textarea[text()='@employeefirstname']"),"EDIT_SURVEY_EMAIL_SUBJECT_OPTIONAL_TEXT_AREA '@employeefirstname'"),

	EDIT_SURVEY_EMAIL_SUBJECT_OPTIONAL_NOTES(By.xpath("//div[text()='Edit Survey Email Subject (Optional)' and @class='survey-inner__title']/../div//following::div[text()='This is the subject your customers will see on the survey email.']//following::textarea[text()='@employeefirstname']//following::div//b"),"EDIT_SURVEY_EMAIL_SUBJECT_OPTIONAL_NOTES '@surveylink will insert the survey URL into the text (required).'"),

	EDIT_SURVEY_QUESTIONS_DESCRIPTION1(By.xpath("//div[@class='settings-inner__right']/div/p[text()='This is the title of the survey customers will see when they land on the survey page.']"),"EDIT_SURVEY_QUESTIONS_DESCRIPTION1"),

	EDIT_SURVEY_QUESTIONS_DESCRIPTION_PERSONALIZED_NAME(By.xpath("//div[@class='settings-inner__right']/div/p[text()='Personalize the survey title with this name: ']"),"EDIT_SURVEY_QUESTIONS_DESCRIPTION_PERSONALIZED_NAME"),

	EDIT_SURVEY_QUESTIONS(By.xpath("//div[text()='Edit Survey Question' and @class='survey-inner__title']"),"EDIT_SURVEY_QUESTIONS"),

	SEND_SURVEY_BUTTON(By.xpath("//span[ text()='Send Survey']"),"SEND_SURVEY_BUTTON"),

	EDIT_SURVEY_QUESTIONS_PREVIEW_BUTTON(By.xpath("//div[text()='Edit Survey Question']//following::button[text()='Preview']"),"EDIT_SURVEY_QUESTIONS_PREVIEW_BUTTON"),

	EDIT_SURVEY_QUESTIONS_RADIO_BUTTON_FIELD("//div[text()='Edit Survey Question']//following::label[contains(text(),'%s')]","EDIT_SURVEY_QUESTIONS_RADIO_BUTTON_FIELD"),

	EDIT_SURVEY_EMAIL_MESSAGE_OPTIONAL(By.xpath("//div[@class='survey-inner__title' and text()='Edit Survey Email Message (Optional)']"),"EDIT_SURVEY_EMAIL_MESSAGE_OPTIONAL");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a RevvTabSettingsSurveysSectionEnum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private RevvTabSettingsSurveysSectionEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a RevvTabSettingsSurveysSectionEnum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private RevvTabSettingsSurveysSectionEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
	
}

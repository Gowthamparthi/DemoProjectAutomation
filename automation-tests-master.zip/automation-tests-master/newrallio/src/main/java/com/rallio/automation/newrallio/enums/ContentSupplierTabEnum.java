package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

public enum ContentSupplierTabEnum {

    PAGE_LOAD(By.xpath("//div[@class='modal-body']//h3[text()='Content Supplier Selector']"),"Content Supplier Detailview"),

    CONTENT_SUPPLIER_SOURCE_FILTER(By.xpath("//span[contains(text(),'Content Supplier')]//parent::label//input"),"Content Supplier Source Filter"),

    CONTENT_SUPPLIER_SELECTOR_TAB(By.xpath("//div[@class='filter-item fltr-drp']//div[@class='lsl-counts-wrap']//span"),"Content Supplier Selector Tab"),

    AL_CONTENT_SUPPLIERS_TAB(By.xpath("//div[@class='filter-item fltr-drp']//span[@title='All Content Suppliers']"),"AL Content Suppliers Tab"),

    CONTENT_SUPPLIER_SELECTOR_TEXT(By.xpath("//div[@class='modal-body']//h3[text()='Content Supplier Selector']"),"CONTENT_SUPPLIER_SELECTOR_TEXT"),

    CONTENT_SUPPLIER_SELECTOR_SEARCH(By.xpath("//div[@class='modal-body']//h3[text()='Content Supplier Selector']//parent::div//div[@class='asm-lf']//input[@placeholder='Search']"),"Content Supplier Selector Search"),

    ALL_CONTENT_SUPPLIERS_TEXT(By.xpath("//div[@class='asm-accord cssheadLabels']//span[text()='All Content Suppliers']"),"All Content Suppliers Text"),

    LIST_OF_CONTENT_SUPPLIER_SELECTOR(By.xpath("//div[@class='asm-accord cssheadLabels']//div[@class='asm-accord cssSearchList']//ul//li//span[@class='lcs-name']"),"List Of Content Supplier Selector"),

    SELECT_CONTENT_SUPPLIER_LIST("//div[@class='modal-body']//div[@class='asm-accord cssSearchList' or @class='all-locs cssTopLabel']//span[text()='%s']","Content Supplier List"),

    SELECTED_CONTENT_SUPPLIER_LIST("//label[contains(@class,'active')]//span[text()='%s']","Selected Content Supplier List"),

    CONTENT_SELECTOR_DEFAULT_LIST(By.xpath("//label//span[text()='All Content Suppliers']"),"Selected Content Supplier List"),

    FEED_ENROLL_LINK(By.xpath("//div[@class='modal-body']//p[text()='To add or remove Content Suppliers, click here:']//following-sibling::span[text()='Feed-Enroll']"),"FEED_ENROLL_LINK"),

    CONTENT_SUPPLIER_SELECTOR_CANCEL(By.xpath("//div[@class='modal-footer']//div[@class='react-ripples ac-secondary-box edit-ripple__wrp']//button[text()='Cancel']"),"Content Supplier Selector Cancel"),

    CONTENT_SUPPLIER_SELECTOR_OK(By.xpath("//div[@class='modal-footer']//button[@class='ac-btn ac-primary ac-block' and text()='Ok']"),"Content Supplier Selector Ok"),

    CONTENT_SUPPLIER_SELECTOR_CLOSE_ICON(By.xpath("//div[@class='modal-content']//div[@class='mod__close--icon']//img[@class='close-icon']"),"Content Supplier Selector Close Icon"),

    HOME_PAGE_CS_SELCTOR_FIELD("//div[@class='filter-item fltr-drp']//div[@class='la-sel-action']//span[@title='%s']","Media Page CS Selctor Field");

    /** The by locator. */
    private By byLocator;

    /** The description. */
    private String xpath, description;

    /**
     * Instantiates a new content tab posts page enum.
     *
     * @param byLocator the by locator
     * @param description the description
     */
    private ContentSupplierTabEnum(By byLocator, String description) {

        this.byLocator = byLocator;
        this.description = description;
    }

    /**
     * Instantiates a new content tab posts page enum.
     *
     * @param xpath the xpath
     * @param description the description
     */
    private ContentSupplierTabEnum(String xpath, String description) {

        this.xpath = xpath;
        this.description = description;
    }

    /**
     * Gets the by locator.
     *
     * @return the by locator
     */
    public By getByLocator() {

        return this.byLocator;
    }

    /**
     * Gets the xpath.
     *
     * @return the xpath
     */
    public String getXpath() {

        return xpath;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {

        return this.description;
    }
}

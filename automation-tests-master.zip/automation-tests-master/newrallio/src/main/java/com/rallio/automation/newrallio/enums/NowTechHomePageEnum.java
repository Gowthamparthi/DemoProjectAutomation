package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum NowTechHomePageEnum.
 */
public enum NowTechHomePageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//img[contains(@src,'membertek-media')]//ancestor::div[@class='header-top']//following-sibling::mat-drawer-container//div[@id='kt_content']"), "The page load"),

	/** The profile icon. */
	PROFILE_ICON(By.xpath("//a[contains(@href,'profile')]//img"), "Profile icon"),

	NOWTECH_LOGO(By.xpath("//img[contains(@src,'membertek-media')]//parent::a//parent::div[@class='logo-container']"), "NowTech logo"),
	
	NOW_SOCIAL_SIDE_TAB(By.xpath("//li[@class='nav-item']//span[contains(@class,'menu-text') and text()='NOW SOCIAL']"), "NowSocial sideTab"),
	
	/** The logout button. */
	LOGOUT_BUTTON(By.xpath("//a//mat-icon[text()='logout']"), "LogOut button"),

	/** The home tab. */
	HOME_TAB(By.xpath("//a[contains(@class,'nav-link') and text()=' HOME ']"), "Home tab"),

	/** The now social tab. */
	NOW_SOCIAL_TAB(By.xpath("//a[contains(@class,'nav-link') and text()=' NOW SOCIAL ']"), "NowSocial tab"),

	NOW_SOCIAL_TAB_FRAME(By.xpath("//div[@id='kt_content']//iframe"), "NowSocial tab frame"),
	
	HAMBURGER_ICON(By.xpath("//div[@class='mobile ham-icon']//input"), "Hamburger icon"),
	
	/** Analytics tab. */
	ANALYTICS_TAB(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Analytics']"), "Analytics tab"),

	/** Analytics tab Leaderboard. */
	ANALYTICS_TAB_LEADERBOARD(By.xpath("//ul[@class='mobilr-nav-menu']//li[text()='Leaderboard']"), "Analytics tab Leaderboard"),

	/** Analytics tab ContentAnalytics. */
	ANALYTICS_TAB_CONTENT_ANALYTICS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Content']"),
	        "Analytics tab ContentAnalytics"),

	/** The analytics tab social analytics. */
	ANALYTICS_TAB_SOCIAL_ANALYTICS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Social']"),
	        "Analytics tab SocialAnalyticsp"),

	/** Analytics tab PageAnalytics. */
	ANALYTICS_TAB_PAGE_ANALYTICS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Page']"),
	        "Analytics tab PageAnalytics"),

	/** Content tab. */
	CONTENT_TAB(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Content']"), "Content tab"),

	/** The content tab creator. */
	CONTENT_TAB_CREATOR(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Creator']"), "Content Tab Creator Page"),

	/** Content tab posts. */
	CONTENT_TAB_POSTS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Posts']"), "Content tab posts"),

	/** Content tab media. */
	CONTENT_TAB_MEDIA(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Media']"), "Content tab media"),

	/** Content tab Calendar. */
	CONTENT_TAB_CALENDAR(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Calendar']"), "Content tab Calendar"),

	/** Content tab FB Ads targetting. */
	CONTENT_TAB_FB_ADS_TARGETTING(By.xpath("//li//h2[text()='Content ']//parent::li//following-sibling::li//div[text()='FB Ads Targeting']"), "Content tab FB Ads targetting"),

	/** Content tab RSS feed. */
	CONTENT_TAB_RSS_FEED(By.xpath("//li//h2[text()='Content ']//parent::li//following-sibling::li//div[text()='RSS Feed']"), "Content tab RSS feed"),

	/** The content tab coupons. */
	CONTENT_TAB_COUPONS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Coupons']"), "Content tab coupons"),

	/** The content tab profile imagery. */
	CONTENT_TAB_PROFILE_IMAGERY(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Profile Imagery']"), "Content tab profile imagery"),

	/** Community tab. */
	COMMUNITY_TAB(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Community']"), "Community tab"),

	/** Community tab inbox. */
	COMMUNITY_TAB_INBOX(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Inbox']"), "Community tab inbox"),

	/** Community tab sandbox. */
	COMMUNITY_TAB_SANDBOX(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Sandbox']"), "Community tab sandbox"),

	/** Settings tab. */
	SETTINGS_TAB(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Settings']"), "Settings tab"),
	
	/** Settings tab Rallio profile. */
	SETTINGS_TAB_RALLIO_PROFILE(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Rallio Profile']"), "Settings tab Rallio profile"),

	/** Settings tab Social Profile. */
	SETTINGS_TAB_SOCIAL_PROFILE(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Social Profiles']"), "Settings tab Social Profile"),

	/** The settings tab fb ads. */
	SETTINGS_TAB_FB_ADS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='FB Ads']"), "settings tab FB Ads"),

	/** The settings tab reviews. */
	SETTINGS_TAB_REVIEWS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Reviews']"), "Settings tab reviews"),

	/** The settings release form. */
	SETTINGS_TAB_RELEASE_FORM(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Release Form']"), "Settings tab release form");
	/** The content tab coupons. */

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new now tech home page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private NowTechHomePageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new now tech home page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private NowTechHomePageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum AnalyticsLeaderboardPageEnum.
 */
public enum AnalyticsLeaderboardPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//li[@class='ripple active']//span[text()='Leaderboard']//ancestor::div//section[@class='item-g filter ra-filter-sec anlFilter']//preceding::table[@class='table-cmn--skeleton responsiveTable table']"), "Page Load For LeaderBoard Page"),

	OPERATIONS_PAGE_LOAD(By.xpath("//li[@class='ripple active']//span[text()='Leaderboard']//ancestor::div//section[@class='item-g filter ra-filter-sec anlFilter']//preceding::div[@class='lb-analytics__tbl new-drpdwn']//table"),"OPERATIONS_PAGE_LOAD"),
	
	/** The table view list. */
	TABLE_VIEW_LIST(By.xpath("//div[contains(@class,'lb-analytics__tbl')]//table//tbody[2]//tr"), "Table view list"),

	CLEAR_FILTER_INACTIVE(By.xpath("//div[@class='react-ripples ac-primary-box  pointer-events-none']//button//span[text()='Clear Filter']"),"Clear Filter Inactive"),
	
	/** The clear filter. */
	CLEAR_FILTER(By.xpath("//div[@class='react-ripples ac-primary-box' and not(contains(@class,'pointer-events-none'))]//button//span[text()='Clear Filter']"), "Clear Filter"),

	BRANDUSER_CLEAR_FILTER(By.xpath("//button[@class='ac-btn ac-primary-light ac-block ac-outline ' and text()='Clear Filter']"), "BrandUser clear filter"),
	
	LEADERBOARD_TYPE_SOCIAL_FILTER(By.xpath("//input[@name='page-Leaderboard Type']//parent::label//span[text()='Social']"),"LeaderboardType Social Filter"),
	
	LEADERBOARD_TYPE_OPERATIONS_FILTER(By.xpath("//input[@name='page-Leaderboard Type']//parent::label//span[text()='Operations']"),"LeaderboardType Operations Filter"),
	
	/** The clear filter option. */
	CLEAR_FILTER_OPTION(By.xpath("//button//span[text()='Clear Filter']"), "Clear Filter option"),

	/** The download csv button. */
	DOWNLOAD_CSV_BUTTON(By.xpath("//button//span[text()='Download CSV']"), "Download CSV button"),

	/** The all filter platform. */
	ALL_FILTER_PLATFORM(By.xpath("//h3[text()='Platform']//parent::div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'all-platform')]//parent::button"), "All filter platform"),

	/** The all filter selected. */
	ALL_FILTER_SELECTED(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'all-platform')]//parent::button[contains(@class,'active')]"),
	        "All filter selected"),

	/** The facebook filter button. */
	FACEBOOK_FILTER_BUTTON(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'fb-platform')]//parent::button"),
	        "Facebook filter button"),

	/** The facebook filter selected. */
	FACEBOOK_FILTER_SELECTED(
	        By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'fb-platform')]//parent::button[contains(@class,'active')]"),
	        "Facebook filter selected"),

	/** The twitter filter button. */
	TWITTER_FILTER_BUTTON(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'twitter-platform')]//parent::button"),
	        "Twitter filter button"),

	/** The twitter filter selected. */
	TWITTER_FILTER_SELECTED(
	        By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'twitter-platform')]//parent::button[contains(@class,'active')]"),
	        "Twitter filter selected"),

	/** The linkedin filter button. */
	LINKEDIN_FILTER_BUTTON(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'linkedin-platform')]//parent::button"),
	        "LinkedIn filter button"),

	/** The linkedin filter selected. */
	LINKEDIN_FILTER_SELECTED(
	        By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'linkedin-platform')]//parent::button[contains(@class,'active')]"),
	        "LinkedIn filter selected"),

	/** The instagram filter button. */
	INSTAGRAM_FILTER_BUTTON(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'instagram-platform')]//parent::button"),
	        "Instagram filter button"),

	/** The instagram filter selected. */
	INSTAGRAM_FILTER_SELECTED(
	        By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'instagram-platform')]//parent::button[contains(@class,'active')]"),
	        "Instagram filter selected"),

	/** The google filter button. */
	GOOGLE_FILTER_BUTTON(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'google-platform')]//parent::button"),
	        "Google filter button"),

	/** The google filter selected. */
	GOOGLE_FILTER_SELECTED(
	        By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']//img[contains(@src,'google-platform')]//parent::button[contains(@class,'active')]"),
	        "Google filter selected"),

	/** The from date. */
	FROM_DATE(By.xpath("//div[contains(@class,'date-picker')]//div[contains(@class,'dp-from')]//input"), "From date"),

	/** The from date active. */
	FROM_DATE_ACTIVE(By.xpath("//section[contains(@class,'filter')]//div[@class='dp-item dp-from active']"), "From date active"),

	/** The from date content. */
	FROM_DATE_CONTENT(By.xpath("//div[contains(@class,'dp-from')]//div[@class='react-datepicker__input-container']//input"), "From date content"),

	/** The select from date. */
	SELECT_FROM_DATE("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]", "Select From date"),

	/** The select from date with month. */
	SELECT_FROM_DATE_WITH_MONTH(
	        "//section[contains(@class,'filter')]//div[contains(@class,'dp-item dp-from')]//div[2]//div[@aria-disabled='false' and  contains(@aria-label,'%s')]",
	        "Select from date with month"),

	/** The from date previous month. */
	FROM_DATE_PREVIOUS_MONTH(By.xpath("//button[contains(@class,'navigation--previous')]"),
	        "From date previous month button"),

	/** The from date next month. */
	FROM_DATE_NEXT_MONTH(By.xpath("//button[contains(@class,'navigation--next')]"),
	        "From date next month button"),

	/** The select date from calendar. */
	SELECT_DATE_FROM_CALENDAR(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week']//div[@aria-disabled='false']"), "Select date from calendar"),

	/** The calendar displayed. */
	CALENDAR_DISPLAYED(By.xpath("//div[@class='react-datepicker__month']"), "Calendar displayed"),

	/** The select last date. */
	SELECT_LAST_DATE(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week'][3]//div[@aria-disabled='false'][last()]"), "Select last date"),

	/** The to date. */
	TO_DATE(By.xpath("//div[contains(@class,'date-picker')]//div[contains(@class,'dp-to')]//input"), "To date"),

	/** The to date active. */
	TO_DATE_ACTIVE(By.xpath("//section[contains(@class,'filter')]//div[@class='dp-item dp-to active']"), "To date active"),

	/** The to date content. */
	TO_DATE_CONTENT(By.xpath("//div[contains(@class,'dp-to')]//div[@class='react-datepicker__input-container']//input"), "To date content"),

	/** The to date previous month. */
	TO_DATE_PREVIOUS_MONTH(By.xpath("//button[contains(@class,'navigation--previous')]"),
	        "To date previous month button"),

	/** The to date next month. */
	TO_DATE_NEXT_MONTH(By.xpath("//section[contains(@class,'filter')]//div[@class='dp-item dp-to active']//div[2]//button[text()='Next Month']"), "To date next month button"),

	/** The select to date. */
	SELECT_TO_DATE("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]", "Select To date"),

	/** The select to date with month. */
	SELECT_TO_DATE_WITH_MONTH("//section[contains(@class,'filter')]//div[contains(@class,'dp-item dp-to')]//div[2]//div[@aria-disabled='false' and  contains(@aria-label,'%s')]",
	        "Select to date with month"),

	/** The month picker. */
	MONTH_PICKER(By.xpath("//select[@class='react-datepicker__month-select']"), "Month picker"),

	/** The totals header. */
	TOTALS_HEADER(By.xpath("//td//span[text()='Totals']"), "Totals header"),

	/** The ranking header. */
	RANKING_HEADER(By.xpath("//th//span[text()='Ranking']"), "Ranking header"),

	/** The followers header. */
	FOLLOWERS_HEADER(By.xpath("//th//span[text()='Followers']"), "Followers header"),

	/** The page views header. */
	PAGE_VIEWS_HEADER(By.xpath("//th//span[text()='Page Views']"), "PageViews header"),

	/** The daily engagement header. */
	DAILY_ENGAGEMENT_HEADER(By.xpath("//th//span[text()='Daily Post']//self::*[text()='Engagement']"), "Daily Engagement header"),

	/** The reviews header. */
	REVIEWS_HEADER(By.xpath("//th//span[text()='Reviews']"), "Reviews header"),

	/** The reputation header. */
	REPUTATION_HEADER(By.xpath("//th//span[text()='Reputation']"), "Reputation header"),

	/** The table list total. */
	TABLE_LIST_TOTAL(By.xpath("//span[text()='Totals']//following-sibling::span[@class='loc-count']"), "Table list total"),

	KEYWORDS_HEADER_TOTALS(By.xpath("//tr[@class='total ']//td//div[@class='delta-wrp']//span"),"KEYWORDS_HEADER_TOTALS"),
	
	KEYWORDS_HEADER_CATEGORY_LIST(By.xpath("//tr//td//div//span[@class='variant-v1']"),"KEYWORDS_HEADER_CATEGORY_LIST"),
	
	/** The followers total. */
	FOLLOWERS_TOTAL(
	        By.xpath("//span[text()='Followers']//ancestor::table//tbody//td[2]//span[@class='t-left__value' and text()]"),
	        "Followers total"),

	/** The page views total. */
	PAGE_VIEWS_TOTAL(
	        By.xpath("//span[text()='Page Views']//ancestor::table//tbody//td[3]//span[@class='t-left__value' and text()]"),
	        "PageViews total"),

	/** The daily engagement total. */
	DAILY_ENGAGEMENT_TOTAL(
	        By.xpath("//span[text()='Daily Post' and text()='Engagement']//ancestor::table//tbody//td[4]//span[@class='t-left__value' and text()]"),
	        "Daily Engagement total"),

	/** The reviews total. */
	REVIEWS_TOTAL(By.xpath("//span[text()='Reviews']//ancestor::table//tbody//td[5]//span[@class='t-left__value' and text()]"),
	        "Reviews total"),

	/** The reputation total. */
	REPUTATION_TOTAL(
	        By.xpath("//span[text()='Reputation']//ancestor::table//tbody//td[6]//span[@class='t-left__value' and text()]"),
	        "Reputation total"),

	/** The ranking list.*/
	RANKING_LIST(By.xpath("//table//tbody/tr//td[1]//span[@class='loc-series ldrCounts']//following-sibling::span"), "Ranking list"),

	RENDERSEO_RANKING_LIST(By.xpath("//table//tbody/tr//td[1]//span[@class='loc-series']//following-sibling::span"),"RenderSeo Ranking List"),

	RANKING_LIST_BY_NAME("//table//tbody//tr//td[1]//span[@class='loc-series']//following-sibling::span[contains(text(),'%s')]","Ranking List By Name"),
	
	RANKING_LIST_WITOUT_MEDAL(By.xpath("//table//tbody//tr//following-sibling::tr[last()]"), "RANKING_LIST_WITOUT_MEDAL"),

	/** The followers counts list. */
	FOLLOWERS_COUNTS_LIST(By.xpath("//span[text()='Followers']//ancestor::table//tbody//following-sibling::tbody//tr//td[2]//span[@class='variant-v1' and text()]"),
	        "Followers counts list"),

	/** The pageviews counts list. */
	PAGEVIEWS_COUNTS_LIST(By.xpath("//span[text()='Page Views']//ancestor::table//tbody//following-sibling::tbody//tr//td[3]//span[@class='variant-v1' and text()]"),
	        "PageViews counts list"),

	/** The daily engagement counts list. */
	DAILY_ENGAGEMENT_COUNTS_LIST(By.xpath("//span[text()='Daily Post' and text()='Engagement']//ancestor::table//tbody//following-sibling::tbody//tr//td[4]//span[@class='variant-v1' and text()]"),
	        "DailyEngagement counts list"),

	/** The reviews counts list. */
	REVIEWS_COUNTS_LIST(By.xpath("//span[text()='Reviews']//ancestor::table//tbody//following-sibling::tbody//tr//td[5]//span[@class='variant-v1' and text()]"), "Reviews counts list"),

	/** The reputation counts list. */
	REPUTATION_COUNTS_LIST(By.xpath("//span[text()='Reputation']//ancestor::table//tbody//following-sibling::tbody//tr//td[6]//span[@class='variant-v1' and text()]"),
	        "Reputation counts list"),

	/** The likes header. */
	LIKES_HEADER(By.xpath("//th//span[text()='Likes']"), "Likes header"),

	/** The engagement header. */
	ENGAGEMENT_HEADER(By.xpath("//th//span[text()='Engagement']"), "Likes header"),

	/** The table view list footer. */
	TABLE_VIEW_LIST_FOOTER(By.xpath("//table//tbody//tr/following-sibling::tr[last()]"), "Table view list footer"),

	/** The list header ascending arrow. */
	LIST_HEADER_ASCENDING_ARROW(By.xpath("//th//span[@class='cur-pointer']//img[@class='sort desc-sorted']"), "List header ascending arrow"),

	/** The list header descending arrow. */
	LIST_HEADER_DESCENDING_ARROW(By.xpath("//th//span[@class='cur-pointer']//img[@class='sort ']"), "List header descending arrow"),

	HIGH_TO_LOW_SORT_OPTION(By.xpath("//nav[@class='custom-dropdown-menu active']//li[text()='High to Low']"), "High to low sort option"),
	
	LOW_TO_HIGH_SORT_OPTION(By.xpath("//nav[@class='custom-dropdown-menu active']//li[text()='Low to High']"), "Low to high sort option"),
	
	DELTA_LOW_TO_HIGH_SORT_OPTION(By.xpath("//nav[@class='custom-dropdown-menu active']//li[text()='Delta Low to High']"), "Delta Low to high sort option"),
	
	DELTA_HIGH_TO_LOW_SORT_OPTION(By.xpath("//nav[@class='custom-dropdown-menu active']//li[text()='Delta High to Low']"), "Delta high to Low sort option"),
	
	/** The download started message. */
	DOWNLOAD_STARTED_MESSAGE(By.xpath("//span[text()='Download started']"), "Download started message"),

	DOWNLOAD_DONE_MESSAGE(By.xpath("//span[@class='success-mess-txt' and text()='Done!']"),"Download Done Message"),
	
	/** The location selector button. */
	LOCATION_SELECTOR_BUTTON(By.xpath("//h3[text()='Location Selector']//parent::div//div[@class='locAction']//span"), "Location selector button"),

	/** The location selector view. */
	LOCATION_SELECTOR_VIEW(By.xpath("//div[@class='modal-body']//h3[text()='Location Selector']//parent::div//parent::div//div[@class='asm-accord']"), "Location selector view"),

	/** The hubs dropdown. */
	HUBS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='accordion']//span[@class='lca-head' and text()='Hubs']"), "Hubs dropdown"),

	/** The location lists dropdown. */
	LOCATION_LISTS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='accordion']//span[@class='lca-head' and text()='Location Lists']"),
	        "LocationLists dropdown"),

	/** The locations dropdown. */
	LOCATIONS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='accordion']//span[@class='lca-head' and text()='Locations']"), "Locations dropdown"),

	/** The location selector dropdown list. */
	LOCATION_SELECTOR_DROPDOWN_LIST(By.xpath("//div[@class='modal-body']//div[@class='open card-header']//parent::div[@class='accordion-item']//following-sibling::div//ul[@class='hub-list']"),
	        "Location selector dropdown list"),

	/** The location selector search. */
	LOCATION_SELECTOR_SEARCH(By.xpath("//h3[text()='Location Selector']//following-sibling::div//input[@name='Locations']"), "Location selector search"),

	/** The select dropdown list. */
	SELECT_DROPDOWN_LIST("//div[@class='modal-body']//div[@class='open card-header']//parent::div[@class='accordion-item']//following-sibling::div//ul//li//span[contains(text(),'%s')]",
	        "Select dropdown list"),

	/** The selected dropdown list. */
	SELECTED_DROPDOWN_LIST(
	        "//div[@class='modal-body']//div[@class='open card-header']//parent::div[@class='accordion-item']//following-sibling::div//ul//li//input[@checked]//following-sibling::div//span[contains(text(),'%s')]",
	        "Selected dropdown list"),

	/** The location selector cancel button. */
	LOCATION_SELECTOR_CANCEL_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Cancel']"), "Location selector cancel button"),

	/** The location selector ok button. */
	LOCATION_SELECTOR_OK_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Ok']"), "Location selector ok button"),

	/** The sortby dropdowns. */
	SORTBY_DROPDOWNS(
	        By.xpath("//div[text()='Sort by']//parent::div//parent::div//div[@class='sortby-list__wrp']//div[@class='ds-dropdown' and @title='Followers']//following-sibling::div[@class='ds-dropdown' and @title='High to Low']"),
	        "Sortby dropdowns"),
	
	LOCATION_SELECTOR_DROPDOWN_USER("//div//ul[@class='hub-list']//span[text()='%s']","LOCATION_SELECTOR_DROPDOWN_USER"),

	LOCATION_SELECTOR_HUB_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Hubs']"),
			"Location Selecter Hub tab."),
	
	LOCATION_SELECTOR_HUB_TAB_OPEN(
			By.xpath("//img[contains(@src,'hubs')]//ancestor::ul"),
			"Location Selecter Hub Tab Open."),
	
	LOCATION_SELECTOR_BUTTON_HUB_COUNT(
			By.xpath("//h3[text()='Location Selector']//following-sibling::div[@class='locAction']//span//following-sibling::span"),
			"LOCATION_SELECTOR_BUTTON_HUB_COUNT"),
	
	LOCATION_SELECTOR_BUTTON_LOCATION_LIST_COUNT(
			By.xpath("//h3[text()='Location Selector']//following-sibling::div[@class='locAction']//span//following-sibling::span"),
			"LOCATION_SELECTOR_BUTTON_LOCATION_LIST_COUNT"),
	
	/** The location selector locationlist tab. */
	LOCATION_SELECTOR_LOCATIONLIST_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Location Lists']"),
			"Location Selecter Location List tab"),
	
	/** The location selector location list tab open. */
	LOCATION_SELECTOR_LOCATION_LIST_TAB_OPEN(By.xpath("//img[contains(@src,'locationLists')]//ancestor::div[contains(@class,'collapse show')]"),
			"Location Selecter Location List tab Open"),
	
	/** The location selector locationlist tab. */
	LOCATION_SELECTOR_LOCATION_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Locations']"),
			"Location Selecter Location List tab"),
	
	/** The location selector location list tab open. */
	LOCATION_SELECTOR_LOCATION_TAB_OPEN(By.xpath("//img[contains(@src,'location')]//ancestor::div[contains(@class,'collapse show')]"),
			"Location Selecter Location tab Open"),
	
	
	MONTH_DROPDOWN(By.xpath("//select[@class='react-datepicker__month-select']"), "Month drop down"),

	YEAR_DROPDOWN(By.xpath("//select[@class='react-datepicker__year-select']"), "Year drop down."),
	
	PAGE_VIEWS_HEADER_HOVER_TEXT(By.xpath("//div[text()='The number of times your social media pages were visited.']"), "PAGE_VIEWS_HEADER_HOVER_TEXT"),

	/** The daily engagement header. */
	DAILY_ENGAGEMENT_HEADER_HOVER_TEXT(By.xpath("//div[text()='Total likes, comments and shares your content receives on average each day during the date range selected.']"), "DAILY_ENGAGEMENT_HEADER_HOVER_TEXT"),

	/** The reviews header. */
	REVIEWS_HEADER_HOVER_TEXT(By.xpath("//div[text()='The number of online reviews people have left for your business.']"), "REVIEWS_HEADER_HOVER_TEXT"),

	/** The reputation header. */
	REPUTATION_HEADER_HOVER_TEXT(By.xpath("//div[text()='Your average reputation score for your reviews on five-star scale.']"), "REPUTATION_HEADER_HOVER_TEXT"),

	 /* The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),
	  
	CONTENTS_LOADING_SYMBOL("//div[@class='loader']//span[@class='info-state']","Contents Loading Symbol"),
	 
	TABLE_VIEW_LOCATION_LIST(By.xpath("//div[contains(@class,'lb-analytics__tbl')]//table//tbody//following-sibling::tbody//tr//td//span[@class='loc-name text-start mw-unset']"), "TABLE_VIEW_LOCATION_LIST"),
	
	
	//**Operation Filter**//
	
	LOCATION_SELECTOR(By.xpath("//div[@class='lsl-counts-wrap']//span[@class='lcs-name']"),"Location Selector"),
	
	ALL_LOCATIONS_SELECTOR_BUTTON(By.xpath("//div[@class='lsl-counts-wrap']//span[text()='All Locations']"),"All Locations Selector Button"),
	
	KEYWORD_CATEGORY_HEADER(By.xpath("//span[@class='text-dotted d-block keyword__lbl' and text()='Keyword Category']"),"Keyword Category"),
	
	KEYWORDS_HEADER(By.xpath("(//span[@class='text-dotted d-block keyword__lbl'])[2]"),"Keywords Header"),
	
	KEYWORDS_HEADER_LIST(By.xpath("//td//div[@class='delta-wrp']//span[@class='variant-v1']"),"Keywords Header List"),
	
	KEYWORDS_HEADER_DELTA_LIST(By.xpath("//div[@class='an-social-icon-title r-flx r-flx-ac cur-pointer']//parent::td//parent::tr//div[@class='delta-wrp']//span[@class='variant-v2']"),"Keywords Header List"),
	
	TOTALS_SUB_KEYWORDS(By.xpath("//td//div//span[@class='t-left__value']"),"Totals Of Sub keywords"),
	
	TOTALS_SUB_DELTAKEYWORDS(By.xpath("(//td//div//span[@class='variant-v2'])[1]"),"Totals Of Sub keywords"),

	TOTAL_DELTA_SYMBOL_WITH_VALUE(By.xpath("(//td//div//span[@class='variant-v2' and text()])[1]"),"Total Delta Symbol with value"),

	/** The date picker. */
    DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]","Date Picker"),
    
    /** The previous month. */
	PREVIOUS_MONTH_PICKER(By.xpath("//div[@class='react-datepicker']//button[contains(@class,'datepicker__navigation--previous')]"), "Previous month."),

	/** The next month. */
	NEXT_MONTH_PICKER(By.xpath("//div[@class='react-datepicker']//button[contains(@class,'datepicker__navigation--next')]"), "Next month."),

    DELTA_GREEN_SYMMBOL(By.xpath("//div[@class='deltaHolder plus-val ']//img[@alt='an-ratings-up-green' and @class='an-stat--indicator ']"),"Delta Green Symbol"),
	
    DELTA_RED_SYMMBOL(By.xpath("//div[@class='deltaHolder minus-val ']//img[@class='an-stat--indicator ' and @alt='rating-down-red']"),"Delta Red Symbol"),
	
    DELTA_GREY_SYMMBOL(By.xpath("//div[@class='deltaHolder value-none ']//img[@alt='an-rating-grey' and @class='an-stat--indicator ']"),"Delta Grey Symbol"),
	
    GOLD_AWARD(By.xpath("//div[@class='an-social-icon-title r-flx r-flx-ac cur-pointer']//div[@class='award']//img[contains(@src,'award-gold.svg') and @alt='award']"),"Gold Award"),
    
    SILVER_AWARD(By.xpath("//div[@class='an-social-icon-title r-flx r-flx-ac cur-pointer']//div[@class='award']//img[contains(@src,'award-silver.svg') and @alt='award']"),"SILVER Award"),
    
    BRONZE_AWARD(By.xpath("//div[@class='an-social-icon-title r-flx r-flx-ac cur-pointer']//div[@class='award']//img[contains(@src,'award-bronze.svg') and @alt='award']"),"Bronze Award"),
    
    GOLD_AWARD_FIELD("//div[@class='an-social-icon-title r-flx r-flx-ac cur-pointer']//div[@class='award']//img[contains(@src,'award-gold.svg') and @alt='award']//following::td//span[text()='%s']","Gold Award"),
    
    SILVER_AWARD_FIELD("//div[@class='an-social-icon-title r-flx r-flx-ac cur-pointer']//div[@class='award']//img[contains(@src,'award-silver.svg') and @alt='award']//following::td//span[text()='%s']","SILVER Award"),
    
    BRONZE_AWARD_FIELD("//div[@class='an-social-icon-title r-flx r-flx-ac cur-pointer']//div[@class='award']//img[contains(@src,'award-bronze.svg') and @alt='award']//following::td//span[text()='%s']","Bronze Award"),
    
    FOOTER(By.xpath("(//table//tbody//tr[contains(@class,'total')]//following-sibling::tr//td[1]//span[@class='loc-name txtoverflow'])[last()]"),"Footer"),
    
	KEYWORD_CATEGORY_LIST(By.xpath("//table//tbody/tr//td[1]//span[@class='loc-series']//following-sibling::span"),"KEYWORD_CATEGORY_LIST");

	
	
	
	
	
	//location selector locators.
	
//	/** The location selector. */
//	LOCATION_SELECTOR(By.xpath("//section//*[text()='Location Selector']//parent::div//span[@class='lcs-name']"), "Location Selecter."),
//
//	/** The location selector dropdown user. */
//	LOCATION_SELECTOR_DROPDOWN_USER("//div//ul[@class='hub-list']//span[text()='%s']",
//			"Location Selecter Dropdown User"),
//	
//	/** The location selector open. */
//	LOCATION_SELECTOR_OPEN(By.xpath(
//			"//div[@class='asm-btn']//parent::div[@class='modal-footer']//preceding-sibling::div[@class='asm-accord']"),
//			"Location Selecter Open."),
//
//	/** The location selector hub tab. */
//	LOCATION_SELECTOR_HUB_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Hubs']"),
//			"Location Selecter Hub tab."),
//
//	/** The location selector hub tab open. */
//	LOCATION_SELECTOR_HUB_TAB_OPEN(
//			By.xpath("//img[contains(@src,'hubs')]//ancestor::div[contains(@class,'collapse show')]"),
//			"Location Selecter Hub Tab Open."),
//
//	/** The location selector location tab. */
//	LOCATION_SELECTOR_LOCATION_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Locations']"),
//			"Location Selecter Location tab."),
//	
//	/** The location selector location tab open. */
//	LOCATION_SELECTOR_LOCATION_TAB_OPEN(
//			By.xpath("//img[contains(@src,'location')]//ancestor::div[contains(@class,'collapse show')]"),
//			"Location Selecter Location Tab Open"),
//
//	/** The location selector locationlist tab. */
//	LOCATION_SELECTOR_LOCATIONLIST_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Location Lists']"),
//			"Location Selecter Location List tab"),
//	
//	/** The location selector location list tab open. */
//	LOCATION_SELECTOR_LOCATION_LIST_TAB_OPEN(By.xpath("//img[contains(@src,'locationLists')]//ancestor::div[contains(@class,'collapse show')]"),
//			"Location Selecter Location List tab Open"),
//
//	/** The list of hubs. */
//	LIST_OF_HUBS(By.xpath(
//			"//img[contains(@src,'hub')]//parent::label//span[@class='lcs-name']"),
//			"List of Hubs"),
//
//	/** The list of locations. */
//	LIST_OF_LOCATIONS(By.xpath(
//			"//div[contains(@class,'collapse show')]//img[contains(@src,'location') and not(contains(@src,'Lists'))]"),
//			"List of Locations"),
//
//	/** The list of locationlist. */
//	LIST_OF_LOCATIONLIST(By.xpath(
//			"//img[contains(@src,'locationLists')]//parent::label//span[@class='lcs-name']"),
//			"List of Location list"),
//	
//	/** The location selector search tab. */
//	LOCATION_SELECTOR_SEARCH_TAB(By.xpath("//div[@class='asm-lf']//input[@placeholder = 'Search']"),
//			"Location Selecter Search Tab");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new analytics leaderboard page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private AnalyticsLeaderboardPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new analytics leaderboard page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private AnalyticsLeaderboardPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

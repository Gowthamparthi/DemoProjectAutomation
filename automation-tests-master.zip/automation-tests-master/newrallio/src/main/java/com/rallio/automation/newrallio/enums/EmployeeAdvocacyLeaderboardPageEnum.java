package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum EmployeeAdvocacyLeaderboardPageEnum.
 */
public enum EmployeeAdvocacyLeaderboardPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Leaderboard']//ancestor::div//section[contains(@class,'item-g filter sandbox-filter')]//preceding::div//section[@id='main-container-sec']//div[@class='content-g']//div[contains(@class,'eadl__main emp-advocacy-leaderboard')]"), "Page Load For LeaderBoard Page"),

	PAGE_LOADER(By.xpath("//div[@class='spin-txt-wrap']//div[@class='loader']//following-sibling::span[@class='spin-txt']"),"Page Loader"),
	
	/** The table view list. */
	TABLE_VIEW_LIST(By.xpath("//div[contains(@class,'emp-advocacy-leaderboard')]//tbody//tr[@class='white-bg-tble ']"), "Table view list"),

	/** The employees filter. */
	EMPLOYEES_FILTER(By.xpath("//input[@name='ranking-Ranking' and @value='employee']//following-sibling::span"), "Employees filter"),

	/** The locations filter. */
	LOCATIONS_FILTER(By.xpath("//input[@name='ranking-Ranking' and @value='location']//following-sibling::span"), "Locations filter"),

	/** MonthToDate filter. */
	MONTH_TO_DATE_FILTER(By.xpath("//input[@name='dateType-']//following-sibling::span[text()='Month-To-Date']"), "MonthToDate filter"),

	/** LastMonth filter. */
	LAST_MONTH_FILTER(By.xpath("//input[@name='dateType-']//following-sibling::span[text()='Last Month']"), "LastMonth filter"),

	/** YearToDate filter. */
	YEAR_TO_DATE_FILTER(By.xpath("//input[@name='dateType-']//following-sibling::span[text()='Year-To-Date']"), "YearToDate filter"),

	/** AllTime filter. */
	ALL_TIME_FILTER(By.xpath("//input[@name='dateType-']//following-sibling::span[text()='All-Time']"), "AllTime filter"),

	/** The specific date range filter. */
	SPECIFIC_DATE_RANGE_FILTER(By.xpath("//input[@name='dateType-']//following-sibling::span[text()='Specific Date Range']"), "Specific dateRange filter"),

	/** The clear filter. */
	CLEAR_FILTER(By.xpath("//div[@class='react-ripples ac-primary-box' and not(contains(@class,'pointer-events-none'))]//button//span[text()='Clear Filter']"), "Clear Filter"),

	/** The clear filter option. */
	CLEAR_FILTER_OPTION(By.xpath("//button//span[text()='Clear Filter']"), "Clear Filter option"),

	/** The download csv button.*/
	DOWNLOAD_CSV_BUTTON(By.xpath("//span[text()='Download CSV']//parent::button//parent::div//button[contains(@class,'ac-btn ac-icon')]"), "Download CSV button"),
	
	DOWNLOAD_CSV_DONE_POPUP(By.xpath("//div[@id='success']//span[text()='Done!']"), "DOWNLOAD_CSV_DONE_POPUP"),

	/** The from date. */
	FROM_DATE(By.xpath("//div[contains(@class,'dp-from')]//div//input"), "From date"),

	/** The from date active. */
	FROM_DATE_ACTIVE(By.xpath("//section[contains(@class,'filter')]//div[@class='dp-item dp-from active']"), "From date active"),

	/** The from date content. */
	FROM_DATE_CONTENT(By.xpath("//div[contains(@class,'dp-from')]//div[@class='react-datepicker__input-container']//input"), "From date content"),

	/** The select from date. */
	SELECT_FROM_DATE("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]", "Select From date"),

	/** The select from date with month. */
	SELECT_FROM_DATE_WITH_MONTH(
	        "//section[contains(@class,'filter')]//div[contains(@class,'dp-item dp-from')]//div[2]//div[@aria-disabled='false' and  contains(@aria-label,'%s')]",
	        "Select from date with month"),

	FROM_DATE_PREVIOUS_MONTH(By.xpath("//button[contains(@class,'navigation--previous')]"),
	        "From date previous month button"),

	/** The from date next month. */
	FROM_DATE_NEXT_MONTH(By.xpath("//button[contains(@class,'navigation--next')]"),
	        "From date next month button"),

	/** The select date from calendar. */
	SELECT_DATE_FROM_CALENDAR(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week']//div[@aria-disabled='false']"), "Select date from calendar"),

	/** The calendar displayed. */
	CALENDAR_DISPLAYED(By.xpath("//div[@class='react-datepicker__month']"), "Calendar displayed"),

	/** The select last date. */
	SELECT_LAST_DATE(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week'][3]//div[@aria-disabled='false'][last()]"), "Select last date"),

	/** The to date. */
	TO_DATE(By.xpath("//div[contains(@class,'dp-to')]//div//input"), "To date"),

	/** The to date active. */
	TO_DATE_ACTIVE(By.xpath("//section[contains(@class,'filter')]//div[@class='dp-item dp-to active']"), "To date active"),

	/** The to date content. */
	TO_DATE_CONTENT(By.xpath("//div[contains(@class,'dp-to')]//div[@class='react-datepicker__input-container']//input"), "To date content"),

	/** The to date previous month. */
	TO_DATE_PREVIOUS_MONTH(By.xpath("//button[contains(@class,'navigation--previous')]"),
	        "To date previous month button"),

	/** The to date next month. */
	TO_DATE_NEXT_MONTH(By.xpath("//button[contains(@class,'navigation--next')]"), "To date next month button"),

	/** The select to date. */
	SELECT_TO_DATE("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]", "Select To date"),

	/** The select to date with month. */
	SELECT_TO_DATE_WITH_MONTH("//section[contains(@class,'filter')]//div[contains(@class,'dp-item dp-to')]//div[2]//div[@aria-disabled='false' and  contains(@aria-label,'%s')]",
	        "Select to date with month"),

	/** The month picker. */
	MONTH_PICKER(By.xpath("//select[@class='react-datepicker__month-select']"), "Month picker"),
	
	YEAR_PICKER(By.xpath("//select[@class='react-datepicker__year-select']"), "Year picker"),

	/** The totals header. */
	TOTALS_HEADER(By.xpath("//td//span[text()='Totals']"), "Totals header"),

	/** The employees header. */
	EMPLOYEES_HEADER(By.xpath("//table[contains(@class,'responsiveTable')]//div[@class='adv-d-flex']//span[text()='Employees']"), "Employees header"),

	/** The locations header. */
	LOCATIONS_HEADER(By.xpath("//th[@data-testid='th' and text()='Locations']"), "Locations header"),

	/** The assets submitted header. */
	ASSETS_SUBMITTED_HEADER(By.xpath("//table[@class='responsiveTable rt-emp table']//div//span[text()='Assets Submitted']"), "The assets submitted header"),

	/** The enagements from assets header. */
	ENAGEMENTS_FROM_ASSETS_HEADER(By.xpath("//th[@data-testid='th']//span[text()='Engagement From Assets']"), "The enagements from assets header"),

	/** The advocacy posts header. */
	ADVOCACY_POSTS_HEADER(By.xpath("//table[@class='responsiveTable rt-emp table']//div//span[text()='Advocacy Posts']"), "The advocacy posts header"),

	/** The score header. */
	SCORE_HEADER(By.xpath("//table[@class='responsiveTable rt-emp table']//div//span[text()='Score']"), "The score header"),

    // SCORE_HEADER_TOOLTIP("", "The score header tooltip"),

	/** The brand rank header. */
	BRAND_RANK_HEADER(By.xpath("//table[@class='responsiveTable rt-emp table']//div//span[text()='Brand Rank']"), "The brand rank header"),

	/** The table list total. */
	TABLE_LIST_TOTAL(By.xpath("//table[contains(@class,'responsiveTable')]//tbody//tr[@class='lb-total ']//span[text()='Totals']//span"), "Table list total"),

	/** The assets submitted total. */
	ASSETS_SUBMITTED_TOTAL(By.xpath("//table[@class='responsiveTable rt-emp table']//span[text()='Assets Submitted']//ancestor::thead//following-sibling::tbody//tr[@class='lb-total ']//span[@class='rp-location-count-item total-txt'][text()]"), "The assets submitted total"),

	/** The enagements from assets total. */
	ENAGEMENTS_FROM_ASSETS_TOTAL(By.xpath("//tr[@class='lb-total']//td[3]//span[contains(@class,'total-txt')]"), "The enagements from assets total"),

	/** The advocacy posts total. */
	ADVOCACY_POSTS_TOTAL(By.xpath("//table[@class='responsiveTable rt-emp table']//span[text()='Advocacy Posts']//ancestor::thead//following-sibling::tbody//tr//td[3]//div//span"), "The advocacy posts total"),

	/** The score total. */
	SCORE_TOTAL(By.xpath("//table[@class='responsiveTable rt-emp table']//span[text()='Score']//ancestor::thead//following-sibling::tbody//tr//td[4]//div//span"), "The score total"),

	/** The brand rank total. */
	BRAND_RANK_TOTAL(By.xpath("//td//span[text()='Brand Rank']//parent::div//parent::div//following-sibling::div//span"), "The brand rank total"),

	/** The employees list. */
	EMPLOYEES_LIST(By.xpath("//div[contains(@class,'emp-advocacy-leaderboard')]//tbody//tr[@class='white-bg-tble ']"), "Employees list"),

	EMPLOYEES_USERNAME(By.xpath("//div[@class='leaderboard-tcb']//div[@class='lb-loc-title username ']"),"Employees UserName"),
	
	LOCATIONS_USERNAME(By.xpath("//div[@class='leaderboard-tcb']//div[contains(@class,'lb-loc-title username ')]"),"Locations UserName"),
	
	EMPLOYEES_USERNAME_FIELD("//div[@class='leaderboard-tcb']//div[@class='lb-loc-title username ' and contains(text(),'%s')]","Employees Username Field"),
	
	/** The locations list. */
	LOCATIONS_LIST(By.xpath("//div[@class='tdBefore' and text()='Locations']//parent::td//parent::tr[@class='white-bg-tble']//td[1]"), "Locations list"),

	/** The assets submitted counts list. */
	ASSETS_SUBMITTED_COUNTS_LIST(By.xpath("//table[@class='responsiveTable rt-emp table']//div//span[text()='Assets Submitted']//ancestor::thead//following-sibling::tbody[2]//tr[@class='white-bg-tble ']//td[2]//span"),
	        "The assets submitted counts list"),

	/** The enagements from assets counts list. */
	ENAGEMENTS_FROM_ASSETS_COUNTS_LIST(
	        By.xpath("//tr[@class='white-bg-tble']//span[text()='Engagement From Assets']//parent::div//parent::div[@class='tdBefore']//following-sibling::span[text()]"),
	        "The enagements from assets counts list"),

	/** The advocacy posts counts list. */
	ADVOCACY_POSTS_COUNTS_LIST(By.xpath("//table[@class='responsiveTable rt-emp table']//div//span[text()='Advocacy Posts']//ancestor::thead//following-sibling::tbody[2]//tr[@class='white-bg-tble ']//td[3]//span"),
	        "The advocacy posts counts list"),

	/** The score counts list. */
	SCORE_COUNTS_LIST(By.xpath("//table[@class='responsiveTable rt-emp table']//div//span[text()='Score']//ancestor::thead//following-sibling::tbody[2]//tr[@class='white-bg-tble ']//td[4]//span"), "The score counts list"),

	/** The brand rank counts list. */
	BRAND_RANK_COUNTS_LIST(By.xpath("//tr[@class='white-bg-tble ']//td[5]//span"),
	        "The brand rank counts list"),
	
	LOCATIONS_ASSETS_SUBMITTED(By.xpath("//thead//th//span[text()='Assets Submitted']//ancestor::table//tbody[2]//td[2]"),"Locations Assests"),

	LOCATIONS_ADVOCACY_POSTS(By.xpath("//thead//th//span[text()='Advocacy Posts']//ancestor::table//tbody[2]//td[3]"),"Locations Advocacy Posts"),
	
	LOCATIONS_SCORE(By.xpath("//thead//th//span[text()='Score']//ancestor::table//tbody[2]//td[4]"),"Locations Score"),
	
	LOCATIONS_BRAND_RANK(By.xpath("//thead//th//span[text()='Brand Rank']//ancestor::table//tbody[2]//td[4]"),"Locations Brand rank"),
	
	/** TableView list footer. */
	TABLE_VIEW_LIST_FOOTER(By.xpath("//tbody//tr[@class='white-bg-tble '][last()]"), "TableView list footer"),

    // EMPLOYEE_PROFILE_PICTURE(By.xpath("//div[@class='table-body']//div[@class='table-row']//li//span[@class='crop']//*[@class
    // or @src]"), "Employee profile picture"),

    // EMPLOYEE_NAME(By.xpath("//div[@class='table-body']//div[@class='table-row']//li//span[@class='name']"),
    // "Employee name"),

    // FOOTER(By.xpath("//footer[@class='powered-by-rallio']"), "Footer");

	/** The list header ascending arrow. */
	LIST_HEADER_ASCENDING_ARROW(By.xpath("//th[@class='sort-active']//div[@class='adv-d-flex']//following-sibling::span[@class='sort-filter-up']"), "List header ascending arrow"),

	/** The list header descending arrow. */
	LIST_HEADER_DESCENDING_ARROW(By.xpath("//th[@class='sort-active']//div[@class='adv-d-flex']//following-sibling::span[@class='sort-filter-down']"), "List header descending arrow"),

	/** The download started message. */
	DOWNLOAD_STARTED_MESSAGE(By.xpath("//span[@class='success-mess-txt' and text()='Download started']"), "Download started message"),

	/** The gold medal list. */
	GOLD_MEDAL_LIST(By.xpath("//div[contains(@class,'initial-status')]//img[contains(@src,'award-gold')]"), "Gold medal list"),

	/** The silver medal list. */
	SILVER_MEDAL_LIST(By.xpath("//div[contains(@class,'initial-status')]//img[contains(@src,'award-silver')]"), "Silver medal list"),

	/** The bronze medal list. */
	BRONZE_MEDAL_LIST(By.xpath("//div[contains(@class,'initial-status')]//img[contains(@src,'award-bronze')]"), "Bronze medal list"),
	
	GOLD_MEDAL_WITH_RANK_ONE(By.xpath("//tr/td[5][span='1']//preceding-sibling::td[4]//div[1]//img[contains(@src,'award-gold')]"), "GOLD_MEDAL_WITH_RANK_ONE"),

	GOLD_MEDAL_RANK(By.xpath("//div[2]//img[contains(@src,'award-gold')]//parent::div//parent::td//following-sibling::td[4]/span[last()]"), "GOLD_MEDAL_RANK"),

	SILVER_MEDAL_RANK(By.xpath("//div[2]//img[contains(@src,'award-silver')]//parent::div//parent::td//following-sibling::td[4]/span[last()]"), "SILVER_MEDAL_RANK"),

	BRONZE_MEDAL_RANK(By.xpath("//div[2]//img[contains(@src,'award-bronze')]//parent::div//parent::td//following-sibling::td[4]/span[last()]"), "BRONZE_MEDAL_RANK"),

	/** The silver medal list. */
	SILVER_MEDAL_WITH_RANK_TWO(By.xpath("//tr/td[5][span='2']//preceding-sibling::td[4]//div[1]//img[contains(@src,'award-silver')]"), "SILVER_MEDAL_WITH_RANK_TWO"),

	/** The bronze medal list. */
	BRONZE_MEDAL_WITH_RANK_THREE(By.xpath("//tr/td[5][span='3']//preceding-sibling::td[4]//div[1]//img[contains(@src,'award-bronze')]"), "BRONZE_MEDAL_WITH_RANK_THREE"),

	/** The brand ranking. */
	BRAND_RANKING("//td//div[@class='tdBefore']//span[text()='Brand Rank']//parent::div//parent::div//following-sibling::span[text()='%s']", "Brand Ranking"),
	
	SCORE_HOVER_ADVOCACY_POST_AND_POINTS(By.xpath("//div[contains(@class,'rc-tooltip custom-tooltip-long-text rc-tooltip-placement-top')]//div[@class='rc-tooltip-inner']//span[text()='Advocacy Posts = ']//span[text()='15 points']"),"Score Hover Advocacy Posts And Points"),
	
	SCORE_HOVER_ASSESTS_SUBMITTED_AND_POINT(By.xpath("//div[contains(@class,'rc-tooltip custom-tooltip-long-text rc-tooltip-placement-top')]//div[@class='rc-tooltip-inner']//span[text()='Assets Submitted = ']//span[text()='1 point']"),"Score Hover Assets Submitted And Points"),
	
	/** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),
	
	/** The month dropdown. */
	MONTH_DROPDOWN(By.xpath("//select[@class='react-datepicker__month-select']"), "Month drop down"),

	/** The year dropdown. */
	YEAR_DROPDOWN(By.xpath("//select[@class='react-datepicker__year-select']"), "Year drop down."),

	GOLD_WITH_SERIAL_NO_ONE(By.xpath("//img[contains(@src,'award-gold.svg')]//parent::div//parent::td//span[text()='1']"),"GOLD_WITH_SERIAL_NO_ONE"),

	GOLD_WITH_SERIAL_NO_TWO(By.xpath("//img[contains(@src,'award-gold.svg')]//parent::div//parent::td//span[text()='2']"),"GOLD_WITH_SERIAL_NO_Two"),

	GOLD_WITH_SERIAL_NO_THREE(By.xpath("//img[contains(@src,'award-gold.svg')]//parent::div//parent::td//span[text()='3']"),"GOLD_WITH_SERIAL_NO_THREE"),

	AWARDS_GOLD(By.xpath("//div/img[contains(@src,'award-gold.svg')]"),"Awards Gold"),

	AWARDS_SILVER(By.xpath("//img[contains(@src,'award-silver.svg')]"),"Awards Silver"),

	BRONZE_WITH_SERIAL_NUMBER_THREE(By.xpath("//img[contains(@src,'award-bronze.svg')]//parent::div//parent::td//span[text()='3']"),"Third Rank with Serial Number Three"),

	NO_MEDALS_WITH_SERIAL_NO_FOUR(By.xpath("//img[contains(@src,'no-award.svg')]//parent::div//parent::td//span[text()='4']"),"NO_MEDALS_WITH_SERIAL_NO_FOUR"),

	SILVER_RANK_WITH_SERIAL_NO_TWO(By.xpath("//img[contains(@src,'award-silver.svg')]//parent::div//parent::td//span[text()='2']"),"SILVER_RANK_WITH_SERIAL_NO_TWO"),

	SILVER_RANK_WITH_SERIAL_NO_THREE(By.xpath("//img[contains(@src,'award-silver.svg')]//parent::div//parent::td//span[text()='3']"),"SILVER_RANK_WITH_SERIAL_NO_THREE");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new employee advocacy leaderboard page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private EmployeeAdvocacyLeaderboardPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new employee advocacy leaderboard page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private EmployeeAdvocacyLeaderboardPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

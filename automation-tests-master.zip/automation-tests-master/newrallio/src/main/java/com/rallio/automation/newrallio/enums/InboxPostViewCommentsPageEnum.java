package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Class InboxPostDetailedViewPageEnum.
 */
public enum InboxPostViewCommentsPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//div[contains(@class,'modal-dialog')]"), "Page load"),

	/** The facebook icon. */
	FACEBOOK_ICON(By.xpath("//div[@class='pmisorLeft']//img[contains(@src,'facebook.svg')]"), "Facebook Icon"),

	/** The facebook. */
	FACEBOOK(By.xpath("//div[@class='pmisorLeft']//h3[text()='Facebook']"), "Facebook"),

	/** The facebook like button. */
	FACEBOOK_LIKE_BUTTON(By.xpath("//div[@class='pmisorLeft']//img[@alt='Like']//parent::button"), "Facebook like button"),

	/** The facebook link button. */
	FACEBOOK_LINK_BUTTON(By.xpath("//div[@class='pmisorLeft']//img[@alt='Link']//parent::button"), "Facebook link button"),

	/** The facebook delete button. */
	FACEBOOK_DELETE_BUTTON(By.xpath("//div[@class='pmisorLeft']//img[@alt='Delete']//parent::button"), "Facebook delete button"),

	/** The facebook page name. */
	FACEBOOK_PAGE_NAME(By.xpath("//div[@class='pmisorLeft']//span[text()='Posted something to']//preceding-sibling::h3[text()='Aximsoft Instagram ']"), "Facebook page name"),

	/** The location name. */
	LOCATION_NAME("//div[@class='pmisorLeft']//h3[contains(text(),'%s')]", "Location name"),

	/** The posted time. */
	POSTED_TIME(By.xpath("//div[@class='pmisorLeft']//span[contains(text(),'PST')]"), "Posted time"),

	/** The media image. */
	MEDIA_IMAGE(By.xpath("//div[@class='pmisorLeft']//li[2]//div[contains(@class,'gma-item')]//img"), "Media image"),

	/** The profile name. */
	PROFILE_NAME(By.xpath("//div[@class='pmisorRight']//div[contains(@class,'gm-head')]//h3"), "Profile name"),

	/** The comment contents. */
	COMMENT_CONTENTS(By.xpath("//div[@class='pmisorRight']//div[@class='pmisorR-cnt']//div[@class='iert-repMain']"), "Comment contents"),

	/** The comment reply button. */
	COMMENT_REPLY_BUTTON(By.xpath("//div[@class='pmisorRight']//div[contains(@class,'iert-replies')]//img[@alt='Reply']//parent::button"), "Comment reply button"),

	/** The comment replied. */
	COMMENT_REPLIED(By.xpath("//div[@class='pmisorRight']//div[contains(@class,'iert-replies')]//img[contains(@src,'reply-a.svg')]"), "Comment replied"),

	/** The comment like button. */
	COMMENT_LIKE_BUTTON(By.xpath("//div[@class='pmisorRight']//div[contains(@class,'iert-replies')]//img[@alt='Like']//parent::button"), "Comment like button"),

	/** The comment liked. */
	COMMENT_LIKED(By.xpath("//div[@class='pmisorRight']//div[contains(@class,'iert-replies')]//img[contains(@src,'like-a-mg.svg')]"), "Comment liked"),

	/** The comment delete button. */
	COMMENT_DELETE_BUTTON(By.xpath("//div[@class='pmisorRight']//div[contains(@class,'iert-replies')]//img[@alt='Delete']//parent::button"), "Comment delete button"),

	/** The comment delete alert box. */
	COMMENT_DELETE_ALERT_BOX(By.xpath("//div[text()='Are you sure you want to delete this comment?']"), "Comment delete alert box"),

	/** The post delete alert box. */
	POST_DELETE_ALERT_BOX(By.xpath("//div[text()='Are you sure you want to delete this post?']"), "Post delete alert box"),
	
	/** The delete alert cancel button. */
	DELETE_ALERT_CANCEL_BUTTON(By.xpath("//button[text()='Cancel']"), "Delete alert cancel button"),

	/** The delete alert delete button. */
	DELETE_ALERT_DELETE_BUTTON(By.xpath("//button[text()='Delete']"), "Delete alert delete button"),

	/** The comment deleted message. */
	COMMENT_DELETED_MESSAGE(By.xpath("//span[text()='Done!']"), "Comment deleted message"),

	/** The post deleted message. */
	POST_DELETED_MESSAGE(By.xpath("//span[text()='Done!']"), "Post deleted message"),
	
	/** The emoji button. */
	EMOJI_BUTTON(By.xpath("//div[@class='pmisorRight']//div[contains(@class,'iert-replies')]//div[@class='ap-emoji']//button"), "Emoji button"),

	/** The text area. */
	TEXT_AREA(By.xpath("//div[@class='pmisorRight']//div[contains(@class,'iert-replies')]//div[@class='ap-big-textarea']//textarea"), "Text area"),

	/** The emoji categories. */
	EMOJI_CATEGORIES(By.xpath("//div[@class='pmisorRight']//div[contains(@class,'iert-replies')]//nav//button"), "Emoji categories"),

	/** The select emoji. */
	SELECT_EMOJI(By.xpath("//div[@class='pmisorRight']//div[@class='ap-emoji']//section//ul//li//button"), "Select emoji"),

	/** The send reply button. */
	SEND_REPLY_BUTTON(By.xpath("//div[@class='pmisorRight']//div[@class='pmsior-action']//button[text()='Send Reply']"), "Send reply button"),

	/** The replies button. */
	REPLIES_BUTTON(By.xpath("//div[@class='pmisorRight']//div[contains(@class,'iert-replies')]//div[contains(@class,'ir-reply-counts')]//span[text()='Replies']"),
	        "Replies button"),

	/** The replies count. */
	REPLIES_COUNT(By.xpath("//div[@class='pmisorRight']//div[contains(@class,'iert-replies')]//div[contains(@class,'ir-reply-counts')]//span[2]"), "Replies count"),

	/** The replies contents. */
	REPLIES_CONTENTS(By.xpath("//div[@class='pmisorRight']//div[contains(@class,'iert-replies')]//div[@class='pmisorRight']//div[@class='iert-repMain']"), "Replies contents"),

	/** The replies profile name. */
	REPLIES_PROFILE_NAME(By.xpath("//div[@class='pmisorRight']//div[@class='pmisorRight']//div[@class='iert-repMain']//h3"), "Replies profile name"),

	/** The replies date time. */
	REPLIES_DATE_TIME(By.xpath("//div[@class='pmisorRight']//div[@class='pmisorRight']//div[@class='iert-repMain']//span[contains(@class,'gdateTime')]"), "Replies date time"),

	/** The replies text. */
	REPLIES_TEXT(By.xpath("//div[@class='pmisorRight']//div[@class='pmisorRight']//div[@class='iert-repMain']//p"), "Replies text"),

	/** The replies reply button. */
	REPLIES_REPLY_BUTTON(By.xpath("//div[@class='pmisorRight']//div[@class='pmisorRight']//div[@class='iert-repMain']//img[@alt='Reply']//parent::button"), "Replies reply button"),

	/** The replies reply textarea. */
	REPLIES_REPLY_TEXTAREA(By.xpath("//div[@class='pmisorRight']//div[@class='pmisorRight']//div[@class='iert-repMain']//div[@class='ap-big-textarea']//textarea"),
	        "Replies reply text area"),

	/** The replies reply emoji button. */
	REPLIES_REPLY_EMOJI_BUTTON(By.xpath("//div[@class='pmisorRight']//div[@class='pmisorRight']//div[@class='iert-repMain']//div[@class='ap-emoji']//button"),
	        "Replies reply emoji button"),

	/** The replies reply emoji categories. */
	REPLIES_REPLY_EMOJI_CATEGORIES(By.xpath("//div[@class='pmisorRight']//div[@class='pmisorRight']//div[@class='iert-repMain']//nav//button"), "Replies reply emoji categories"),

	/** The replies reply select emoji. */
	REPLIES_REPLY_SELECT_EMOJI(By.xpath("//div[@class='pmisorRight']//div[@class='pmisorRight']//div[@class='iert-repMain']//div[@class='ap-emoji']//section//ul//li//button"),
	        "Replies reply select emoji"),

	/** The replies send reply button. */
	REPLIES_SEND_REPLY_BUTTON(
	        By.xpath("//div[@class='pmisorRight']//div[@class='pmisorRight']//div[@class='iert-repMain']//div[@class='pmsior-action']//button[text()='Send Reply']"),
	        "Replies send reply"),

	/** The replied content. */
	REPLIED_CONTENT("//div[@class='pmisorRight']//div[contains(@class,'iert-replies')]//div[@class='pmisorRight']//div[@class='iert-repMain']//p[contains(text(),'%s')]",
	        "Replied content"),

	/** The replies like button. */
	REPLIES_LIKE_BUTTON(By.xpath("//div[@class='pmisorRight']//div[@class='pmisorRight']//div[@class='iert-repMain']//img[@alt='Like']//parent::button"), "Replies like button"),

	/** The replies reply liked. */
	REPLIES_REPLY_LIKED(By.xpath("//div[@class='pmisorRight']//div[@class='pmisorRight']//div[@class='iert-repMain']//img[contains(@src,'like-a-mg.svg')]"), "Replies reply liked"),

	/** The replies delete button. */
	REPLIES_DELETE_BUTTON(By.xpath("//div[@class='pmisorRight']//div[@class='pmisorRight']//div[@class='iert-repMain']//img[@alt='Delete']//parent::button"),
	        "Replies delete button"),

	/** The twitter icon. */
	TWITTER_ICON(By.xpath("//div[@class='pmisorLeft']//img[contains(@src,'twitter.svg')]"), "Twitter Icon"),

	/** The twitter. */
	TWITTER(By.xpath("//div[@class='pmisorLeft']//h3[text()='Twitter']"), "Twitter"),

	/** The twitter like button. */
	TWITTER_LIKE_BUTTON(By.xpath("//div[@class='pmisorLeft']//img[@alt='Like']//parent::button"), "Twitter like button"),

	/** The twitter link button. */
	TWITTER_LINK_BUTTON(By.xpath("//div[@class='pmisorLeft']//img[@alt='Link']//parent::button"), "Twitter link button"),

	/** The twitter delete button. */
	TWITTER_DELETE_BUTTON(By.xpath("//div[@class='pmisorLeft']//img[@alt='Delete']//parent::button"), "Twitter delete button"),

	/** The twitter page name. */
	TWITTER_PAGE_NAME(By.xpath("//div[@class='pmisorLeft']//span[text()='Posted something to']//preceding-sibling::h3[contains(text(),'Aximsoft Test')]"), "Twitter page name"),

	/** The twitter comment liked. */
	TWITTER_COMMENT_LIKED(By.xpath("//div[@class='pmisorRight']//div[contains(@class,'iert-replies')]//img[contains(@src,'twtLike-a.svg')]"), "Twitter comment liked"),

	/** The comment delete post failed. */
	COMMENT_DELETE_FAILED(By.xpath("//span[text()='Delete post failed!']"), "Comment delete post failed"),

	/** Instagram comment like button. */
	INSTAGRAM_COMMENT_LIKE_BUTTON(By.xpath("//div[@class='pmisorRight']//div[contains(@class,'iert-replies')]//img[contains(@src,'instaLike.svg')]"),
	        "Instagram comment like button"),

	/** Instagram comment liked. */
	INSTAGRAM_COMMENT_LIKED(By.xpath("//div[@class='pmisorRight']//div[contains(@class,'iert-replies')]//img[contains(@src,'instaLike-a.svg')]"), "Instagram comment liked"),

	/** Instagram post icon. */
	INSTAGRAM_POST_ICON(By.xpath("//div[@class='pmisorLeft']//img[contains(@src,'instagram.svg')]"), "Instagram post icon"),

	/** Instagram like button. */
	INSTAGRAM_LIKE_BUTTON(By.xpath("//div[@class='pmisorCnt']//div[@class='gm-item']//button//img[contains(@src,'instaLike.svg')]"), "Instagram like button"),

	/** Instagram liked. */
	INSTAGRAM_LIKED(By.xpath("//div[@class='pmisorCnt']//div[@class='gm-item']//button//img[contains(@src,'instaLike-a.svg')]"), "Instagram liked"),

	/** Instagram open website. */
	INSTAGRAM_OPEN_WEBSITE(By.xpath("//div[@class='pmisorCnt']//div[@class='gm-item']//button//img[contains(@src,'link.svg')]"), "Instagram open website"),

	/** OpenWebsite InstagramPage navigation. */
	OPEN_WEBSITE_INSTAGRAM_PAGE_NAVIGATION(By.xpath("//div//img[@alt='Instagram' and contains(@src,'mobile_nav_type_logo')]"), "OpenWebsite InstagramPage navigation"),

	/** Instagram delete button. */
	INSTAGRAM_DELETE_BUTTON(By.xpath("//div[@class='pmisorCnt']//div[@class='gm-item']//button//img[contains(@src,'delete.svg')]"), "Instagram delete button");

	/** The by locator. */
	private By byLocator;

	/** The xpath. */
	private String xpath;

	/** The description. */
	private String description;

	/**
	 * Instantiates a new inbox post detailed view page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private InboxPostViewCommentsPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new inbox post detailed view page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private InboxPostViewCommentsPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return byLocator;
	}

	/**
	 * Gets the by xpath.
	 *
	 * @return the by xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}
}

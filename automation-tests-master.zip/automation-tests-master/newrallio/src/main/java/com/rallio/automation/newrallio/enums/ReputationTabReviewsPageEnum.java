package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum ReputationTabReviewsPageEnum.
 */
public enum ReputationTabReviewsPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath(
			"//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Reviews']//ancestor::div//section[contains(@class,'reputation-review-ftr__main')]//preceding::div//section[@id='main-container-sec']//div"),
			"Page load"),

	/** The reviews contents load. */
	REVIEWS_CONTENTS_LOAD(By.xpath(
			"//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Reviews']//ancestor::div[@id='root']"),"Reviews content load"),

	/** The reviews page active. */
	REVIEWS_PAGE_ACTIVE(By.xpath(
			"//div[contains(@class,'sub-nav-tabs')]//span[text()='Reviews']//parent::li[@class='ripple active']"),
			"Reviews page active"),

	/** The reviews contents. */
	REVIEWS_CONTENTS(By.xpath(
			"//div[contains(@class,'infinite-scroll-component local-ini')]//div[contains(@class,'list-view')]//div[contains(@class,'list-item')]"),
			"Reviews contents"),

	/** The facebook contents. */
	FACEBOOK_CONTENTS(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset platform-icon']//img[contains(@src,'fb-lv.svg')]"),
			"Facebook contents"),

	/** The yelp contents. */
	YELP_CONTENTS(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset platform-icon']//img[contains(@src,'yelp')]"),
			"Yelp contents"),

	/** The google contents. */
	GOOGLE_CONTENTS(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='round-asset platform-icon']//img[contains(@src,'google')]"),
			"Google contents"),

	/** The footer. */
	FOOTER(By.xpath("//div[contains(@class,'list-view')]//div[contains(@class,'list-item')][last()]"), "Footer"),

	/** The no data to show. */
	NO_DATA_TO_SHOW(By.xpath("//div[@class='content-g']//div[@class='no-data']//span[text()='No data to show']"),
			"No data to show"),

	/** The reviews stats count. */
	REVIEWS_STATS_COUNT(By.xpath(
			"//div[contains(@class,'total-count')]//span[text()='TOTALS']//parent::div//span[@class='mod-count']//div"),
			"Reviews stat count"),

	/** The facebook stats count. */
	FACEBOOK_STATS_COUNT(By.xpath(
			"//div[contains(@class,'fb-sc')]//img[@alt='Facebook']//parent::div//preceding-sibling::div//span[2]//div"),
			"Facebook stats count"),

	/** The facebook stats highlighted. */
	FACEBOOK_STATS_HIGHLIGHTED(By.xpath("//div[contains(@class,'stats-item fb-sc') and contains(@class,'active')]"),
			"Facebook stats highlighted"),

	/** The yelp stats count. */
	YELP_STATS_COUNT(By.xpath(
			"//div[contains(@class,'yelp-sc')]//img[@alt='Yelp']//parent::div//preceding-sibling::div//span[2]//div"),
			"Yelp stats count"),

	/** The yelp stats highlighted. */
	YELP_STATS_HIGHLIGHTED(By.xpath("//div[contains(@class,'stats-item yelp') and contains(@class,'active')]"),
			"Yelp stats highlighted"),

	/** The google stats count. */
	GOOGLE_STATS_COUNT(By.xpath(
			"//div[contains(@class,'googleplus-sc')]//img[@alt='Google']//parent::div//preceding-sibling::div//span[2]//div"),
			"Google stats count"),

	/** The google stats highlighted. */
	GOOGLE_STATS_HIGHLIGHTED(By.xpath("//div[contains(@class,'stats-item google') and contains(@class,'active')]"),
			"Google stats highlighted"),

	/** The average rating stats. */
	AVERAGE_RATING_STATS(By.xpath("//span[text()='Avg Rating']//parent::div//span[@class='platform-count']//div"),
			"Avg rating stats Count"),

	/** The average rating no details. */
	AVERAGE_RATING_NO_DETAILS(By
			.xpath("//div[contains(@class,'chart-values')]//div//span[text()='Avg Rating']//parent::div//span[2]//div"),
			"Average rating no details"),

	/** The percentage replied. */
	PERCENTAGE_REPLIED_STATS(By.xpath(
			"//div[contains(@class,'chart-values')]//div[@class='chart-details']//parent::div//preceding-sibling::div//span[text()='% Replied']//parent::div//span[2]//span[1]"),
			"Percentage Replied Status Count"),

	/** The percentage replied na. */
	PERCENTAGE_REPLIED_NA(By.xpath(
			"//div[contains(@class,'chart-values')]//div//span[text()='% Replied']//following-sibling::span[text()='N/A']"),
			"Percentage Replied N/A"),

	/** The review analytics button. */
	REVIEW_ANALYTICS_BUTTON(By.xpath("//div[contains(@class,'featured-itm')]//span[text()='REVIEW ANALYTICS']"),
			"Review analytics button"),

	/** The clear filter. */
	CLEAR_FILTER(By.xpath("//div[@class='filter-item clear-filter']//div//span[text()='Clear Filter']"),
			"Clear filter"),

	CLEAR_FILTER_ACTIVE(By.xpath("//div[@class='filter-item clear-filter']//div[@class='react-ripples ac-primary-box']//span[text()='Clear Filter']"),"Clear Filter Active"),
	
	/** The recentreview date. */
	RECENTREVIEW_DATE(By.xpath(
			"//div[@class='list-view review-list__main']//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//div//span[3]"),
			"Recent Post List"),

	/** The download csv. */
	DOWNLOAD_CSV(By.xpath(
			"//section[contains(@class,'item-g filter')]//button[contains(@class,'csv')]//span[text()='Download CSV']"),
			"Download CSV"),

	/** The download started message. */
	DOWNLOAD_STARTED_MESSAGE(By.xpath("//span[text()='Download started']"), "Download started message"),

	/** The prod clear filter. */
	PROD_CLEAR_FILTER(By.xpath(
			"//section[contains(@class,'filter')]//div[contains(@class,'clear-filter')]//span[text()='Clear Filter']"),
			"Prod clear filter"),

	/** The calendar. */
	CALENDAR(By.xpath("//div[@class='react-datepicker__month-container']"), "Calendar"),

	/** The month picker. */
	MONTH_PICKER(By.xpath("//select[@class='react-datepicker__month-select']"), "Month picker"),

	/** The year picker. */
	YEAR_PICKER(By.xpath("//select[@class='react-datepicker__year-select']"), "Year picker"),

	/** The previous month. */
	PREVIOUS_MONTH(By.xpath("//button[contains(@class,'navigation--previous')]"), "Previous month."),

	/** The next month. */
	NEXT_MONTH(By.xpath("//button[contains(@class,'navigation--next')]"), "Next month."),

	/** The from date. */
	FROM_DATE(By.xpath(
			"//div[contains(@class,'react-datepicker__input-container')]//input"),
			"From date"),

	/** The from date content. */
	FROM_DATE_CONTENT(
			By.xpath("//div[contains(@class,'dp-from')]//div[@class='react-datepicker__input-container']//input"),
			"From date content"),

	/** The select from date. */
	SELECT_FROM_DATE(
			"//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]",
			"Select from date"),

	/** The select from date with month. */
	SELECT_FROM_DATE_WITH_MONTH(
			"//section[contains(@class,'filter')]//div[contains(@class,'dp-item dp-from')]//div[2]//div[@aria-disabled='false' and  contains(@aria-label,'%s')]",
			"Select from date with month"),

	/** The from date previous month. */
	FROM_DATE_PREVIOUS_MONTH(By.xpath(
			"//div[contains(@class,'dp-from')]//button[contains(@class,'navigation--previous')]"),
			"From date previous month button"),

	/** The from date next month. */
	FROM_DATE_NEXT_MONTH(By.xpath(
			"//div[contains(@class,'dp-from')]//button[contains(@class,'navigation--next')]"),
			"From date next month button"),

	/** The select date from calendar. */
	SELECT_DATE_FROM_CALENDAR(By.xpath(
			"//div[@class='react-datepicker__month']//div[@class='react-datepicker__week']//div[@aria-disabled='false']"),
			"Select date from calendar"),

	/** The calendar displayed. */
	CALENDAR_DISPLAYED(By.xpath("//div[@class='react-datepicker__month']"), "Calendar displayed"),

	
	/** The to date. */
	TO_DATE(By.xpath("//div[contains(@class,'dp-to')]//input[@placeholder='Most Recent']"), "To date"),

	/** The to date active. */
	TO_DATE_ACTIVE(By.xpath("//section[contains(@class,'filter')]//div[@class='dp-item dp-to active']"),
			"To date active"),

	/** The to date content. */
	TO_DATE_CONTENT(By.xpath("//div[contains(@class,'dp-to')]//div[@class='react-datepicker__input-container']//input"),
			"To date content"),

	/** The to date previous month. */
	TO_DATE_PREVIOUS_MONTH(By.xpath(
			"//div[contains(@class,'dp-to')]//button[contains(@class,'navigation--previous')]"),
			"To date previous month button"),

	/** The to date next month. */
	TO_DATE_NEXT_MONTH(By.xpath(
			"//div[contains(@class,'dp-to')]//button[contains(@class,'navigation--next')]"),
			"To date next month button"),

	/** The select to date. */
	SELECT_TO_DATE(
			"//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]",
			"Select to date"),

	/** The select to date with month. */
	SELECT_TO_DATE_WITH_MONTH(
			"//section[contains(@class,'filter')]//div[contains(@class,'dp-item dp-to')]//div[2]//div[@aria-disabled='false' and  contains(@aria-label,'%s')]",
			"Select to date with month"),

	/** The platforms filter. */
	PLATFORMS_FILTER(By.xpath("//section[contains(@class,'filter')]//div[@class='filter-item']//h3[text()='Platform']"),
			"Platforms filter"),

	/** The all filter button. */
	ALL_FILTER_BUTTON(By.xpath(
			"//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'all-platform.svg')]//parent::button"),
			"All filter button"),

	/** The all filter selected. */
	ALL_FILTER_SELECTED(By.xpath(
			"//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'all-platform.svg')]//parent::button[contains(@class,'active')]"),
			"All filter selected"),

	/** The facebook filter button. */
	FACEBOOK_FILTER_BUTTON(By.xpath(
			"//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'fb-platform')]//parent::button"),
			"Facebook filter button"),

	/** The facebook filter selected. */
	FACEBOOK_FILTER_SELECTED(By.xpath("//img[contains(@src,'fb-platform')]//parent::button[contains(@class,'active')]"),
			"Facebook filter selected"),

	/** The yelp filter button. */
	YELP_FILTER_BUTTON(By.xpath(
			"//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'yelp-platform')]//parent::button"),
			"Yelp filter button"),

	/** The yelp filter selected. */
	YELP_FILTER_SELECTED(By.xpath("//img[contains(@src,'yelp-platform')]//parent::button[contains(@class,'active')]"),
			"Yelp filter selected"),

	/** The google filter button. */
	GOOGLE_FILTER_BUTTON(By.xpath(
			"//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'google-platform')]//parent::button"),
			"Google filter button"),

	/** The google filter selected. */
	GOOGLE_FILTER_SELECTED(
			By.xpath("//img[contains(@src,'google-platform')]//parent::button[contains(@class,'active')]"),
			"Google filter selected"),

	/** The rating filter. */
	RATING_FILTER(By.xpath("//section[contains(@class,'filter')]//div[@class='filter-item']//h3[text()='Rating']"),
			"Rating filter"),

	/** The any rating. */
	ALL_RATING(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Rating']//ancestor::div[@class='filter-item']//div//label//span//input[@value='all']"),
			"All rating"),

	/** The any rating selected. */
	AlL_RATING_SELECTED(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Rating']//ancestor::div[@class='filter-item']//span[text()='All']//ancestor::label[contains(@class,'active')]"),
			"All rating selected"),

	/** The five star rating. */
	FIVE_STAR_RATING(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Rating']//ancestor::div[@class='filter-item']//div//label//span//input[@value='5']"),
			"Five star rating"),

	/** The five star rating selected. */
	FIVE_STAR_RATING_SELECTED(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Rating']//ancestor::div[@class='filter-item']//span[text()='5 Stars']//ancestor::label[contains(@class,'active')]"),
			"Five star rating selected"),

	/** The five star contents. */
	FIVE_STAR_CONTENTS(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-top']//div[contains(@class,'lvt-brief')]//span[contains(@class,'five-star')]"),
			"Five star contents"),

	/** The four star rating. */
	FOUR_STAR_RATING(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Rating']//ancestor::div[@class='filter-item']//div//label//span//input[@value='4']"),
			"Four star rating"),

	/** The four star rating selected. */
	FOUR_STAR_RATING_SELECTED(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Rating']//ancestor::div[@class='filter-item']//span[text()='4 Stars']//ancestor::label[contains(@class,'active')]"),
			"Four star rating selected"),

	/** The four star contents. */
	FOUR_STAR_CONTENTS(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-top']//div[contains(@class,'lvt-brief')]//span[contains(@class,'four-star')]"),
			"Four star contents"),

	/** The three star rating. */
	THREE_STAR_RATING(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Rating']//ancestor::div[@class='filter-item']//div//label//span//input[@value='3']"),
			"Three star rating"),

	/** The three star rating selected. */
	THREE_STAR_RATING_SELECTED(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Rating']//ancestor::div[@class='filter-item']//span[text()='3 Stars']//ancestor::label[contains(@class,'active')]"),
			"Three star rating selected"),

	/** The three star contents. */
	THREE_STAR_CONTENTS(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-top']//div[contains(@class,'lvt-brief')]//span[contains(@class,'three-star')]"),
			"Three star contents"),

	/** The two star rating. */
	TWO_STAR_RATING(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Rating']//ancestor::div[@class='filter-item']//div//label//span//input[@value='2']"),
			"Two star rating"),

	/** The two star rating selected. */
	TWO_STAR_RATING_SELECTED(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Rating']//ancestor::div[@class='filter-item']//span[text()='2 Stars']//ancestor::label[contains(@class,'active')]"),
			"Two star rating selected"),

	/** The two star contents. */
	TWO_STAR_CONTENTS(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-top']//div[contains(@class,'lvt-brief')]//span[contains(@class,'two-star')]"),
			"Two star contents"),

	/** The one star rating. */
	ONE_STAR_RATING(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Rating']//ancestor::div[@class='filter-item']//div//label//span//input[@value='1']"),
			"One star rating"),

	/** The one star rating selected. */
	ONE_STAR_RATING_SELECTED(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Rating']//ancestor::div[@class='filter-item']//span[text()='1 Star']//ancestor::label[contains(@class,'active')]"),
			"One star rating selected"),

	/** The one star contents. */
	ONE_STAR_CONTENTS(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-top']//div[contains(@class,'lvt-brief')]//span[contains(@class,'one-star')]"),
			"One star contents"),

	/** The recommended filter. */
	RECOMMENDED_FILTER(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Rating']//ancestor::div[@class='filter-item']//span[text()='Recommended']"),
			"Recommended filter"),

	/** The recommended filter selected. */
	RECOMMENDED_FILTER_SELECTED(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Rating']//ancestor::div[@class='filter-item']//div//label[contains(@class,'active')]//div//span[text()='Recommended']"),
			"Recommended filter active"),

	/** The recommended contents. */
	RECOMMENDED_CONTENTS(By.xpath(
			"//span[contains(text(),'recommends')]//parent::div//img[contains(@src,'recommend')]"),
			"Recommended contents"),

	/** The not recommended filter. */
	NOT_RECOMMENDED_FILTER_CSS(By.xpath("css=input[name='not_recommended']"), "Not recommended filter"),

	/** The not recommended filter. */
	NOT_RECOMMENDED_FILTER(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Rating']//ancestor::div[@class='filter-item']//span[text()='Not Recommended']"),
			"Not recommended filter"),

	/** The not recommended filter selected. */
	NOT_RECOMMENDED_FILTER_SELECTED(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Rating']//ancestor::div[@class='filter-item']//div//label[contains(@class,'active')]//div//span[text()='Not Recommended']"),
			"Not recommended filter active"),

	/** The not recommended contents. */
	NOT_RECOMMENDED_CONTENTS(By.xpath(
			"//span[contains(text(),'does not recommend')]//parent::div//img[contains(@src,'recommend-dn')]"),
			"Not recommended contents"),

	/** The interaction filter. */
	INTERACTION_FILTER(
			By.xpath("//section[contains(@class,'filter')]//div[@class='filter-item']//h3[text()='Interaction']"),
			"Interaction filter"),

	/** The show all filter. */
	SHOW_ALL_FILTER(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Interaction']//ancestor::div[@class='filter-item']//span[text()='Show All']"),
			"Show all filter"),

	/** The show all filter selected. */
	SHOW_ALL_FILTER_SELECTED(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Interaction']//ancestor::div[@class='filter-item']//span[text()='Show All']//ancestor::label[@class='active']"),
			"Show all filter selected"),

	/** The only replied to filter. */
	ONLY_REPLIED_TO_FILTER(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Interaction']//ancestor::div[@class='filter-item']//span[text()='Only Replied to']"),
			"Only replied to filter"),

	/** The only replied to filter selected. */
	ONLY_REPLIED_TO_FILTER_SELECTED(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Interaction']//ancestor::div[@class='filter-item']//span[text()='Only Replied to']//ancestor::label[@class='active']"),
			"Only replied to filter selected"),

	/** The only replied to contents. */
	ONLY_REPLIED_TO_CONTENTS(By.xpath(
			"//div[contains(@class,'brand-icon')]//following-sibling::div//ancestor::div[@class='review-notes-top']"),
			"Only replied to contents"),

	/** The only not replied to. */
	ONLY_NOT_REPLIED_TO(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Interaction']//ancestor::div[@class='filter-item']//span[text()='Only Not Replied to']"),
			"Only not replied to"),

	/** The only not replied to filter selected. */
	ONLY_NOT_REPLIED_TO_FILTER_SELECTED(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Interaction']//ancestor::div[@class='filter-item']//span[text()='Only Not Replied to']//ancestor::label[@class='active']"),
			"Only not replied to filter selected"),

	/** The only not replied to contents. */
	ONLY_NOT_REPLIED_TO_CONTENTS(
			By.xpath("//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='review-notes-top']"),
			"Only not replied to contents"),

	/** The status filter. */
	STATUS_FILTER(By.xpath("//section[contains(@class,'filter')]//div[@class='filter-item']//h3[text()='Status']"),
			"Status filter"),

	/** The status show all filter. */
	STATUS_SHOW_ALL_FILTER(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Status']//ancestor::div[@class='filter-item']//span[text()='Show All']"),
			"Status show all"),

	/** The status show all selected. */
	STATUS_SHOW_ALL_SELECTED(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Status']//ancestor::div[@class='filter-item']//span[text()='Show All']//ancestor::label[@class='active']"),
			"Status show all selected"),

	/** The closed filter. */
	CLOSED_FILTER(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Status']//ancestor::div[@class='filter-item']//span[text()='Closed']"),
			"Closed filter"),

	/** The closed filter selected. */
	CLOSED_FILTER_SELECTED(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Status']//ancestor::div[@class='filter-item']//span[text()='Closed']//ancestor::label[@class='active']"),
			"Closed filter selected"),

	/** The closed filter contents. */
	CLOSED_FILTER_CONTENTS(By.xpath("//span[@class='vc-txt' and text()='Review closed']"), "Closed filter contents"),

	/** The open filter. */
	OPEN_FILTER(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Status']//ancestor::div[@class='filter-item']//span[text()='Open']"),
			"Open filter"),

	/** The open filter selected. */
	OPEN_FILTER_SELECTED(By.xpath(
			"//section[contains(@class,'filter')]//h3[text()='Status']//ancestor::div[@class='filter-item']//span[text()='Open']//ancestor::label[@class='active']"),
			"Open filter selected"),

	/** The open filter contents. */
	OPEN_FILTER_CONTENTS(By.xpath("//span[@class='vc-txt' and text()='Mark as \"Closed\"']"), "Open filter contents"),

	/** The social media icon. */
	SOCIAL_MEDIA_ICON(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//img[@alt='Social Media']"),
			"Social media icon"),

	/** The profile name. */
	PROFILE_NAME(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//h3"),
			"Profile name"),

	/** The date time. */
	DATE_TIME(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-top']//div[@class='lvt-details']//span//following-sibling::span"),
			"Date time"),

	/** The stars for review. */
	STARS_FOR_REVIEW(By.xpath(
			"//div[contains(@class,'lvt-details')]//div[contains(@class,'lvt-brief')]//span[contains(@class,'sr-item')][last()]"),
			"Stars for review"),

	/** The more button. */
	MORE_BUTTON(By.xpath("//div[contains(@class,'list-item')]//div[@class='li-top']//span//div//img[@alt='More']"),
			"More button"),

	/** The mark as closed button. */
	MARK_AS_CLOSED_BUTTON(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='vc-item']//img[@alt='Mark as \"Closed\"' and contains(@src,'time-grey.svg')]"),
			"Mark as closed button"),

	/** The review closed button. */
	REVIEW_CLOSED_BUTTON(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='vc-item']//img[@alt='Mark as \"Closed\"' and contains(@src,'time-green.svg')]"),
			"Review closed button"),

	/** The reply button. */
	REPLY_BUTTON(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='vc-item']//img[@alt='Reply']//following-sibling::span[contains(text(),'Reply')]"),
			"Reply button"),

	/** The mark as replied. */
	MARK_AS_REPLIED(By.xpath(
			"//div[contains(@class,'list-item')][1]//div[@class='vc-item']//img[@alt='Handle replied to']//following-sibling::span[contains(text(),'Mark as \"Replied to\"')]"),
			"Recent 'Mark as Replied To'"),

	/** The write a reply. */
	WRITE_A_REPLY(By.xpath(
			"//div[@class='list-item animate__animated animate__fadeIn reputation-wrp']//div[@class='lv-comment']//br//parent::span//parent::div[@class='public-DraftStyleDefault-block public-DraftStyleDefault-ltr']"),
			"Write a reply"),

	WRITE_A_REPLY_CONTENT(By.xpath("//div[contains(@data-editor,'editor-reviews-reply')]//div[@class='public-DraftStyleDefault-block public-DraftStyleDefault-ltr']"),"Write A Reply Content"),

	GO_TO_REVIEW_RESPONDER(By.xpath("//div[@class='modal-body']//div[@class='modal-message-wraps' and text()]//parent::div//ancestor::div[@class='modal-content']//button[text()='Go to AI Review Responder']"),"Go To Review Responder"),

	/** The ai option button. */
	AI_OPTION_BUTTON(By.xpath(
			"//div[@class='lv-comment']//div[contains(@class,'ai-btn ai-creator')]//img[@alt='AI']"),
			"AI Option Button"),
	AI_GENERATED_CAPTIONS(By.xpath("//div[contains(@class,'ai-picks aitc-item')]//p[text()]"),"Ai Generated Captions"),

	AI_GENERATED_CAPTIONS_USE_BUTTON(By.xpath("//div//button[@class='gnrc-btn turquoise']//span[text()='Use']"),"AI Generated Captions Use Button"),

	AI_GENERATED_CAPTIONS_CANCEL_BUTTON(By.xpath("//button[contains(@class,'gnrc-btn trans-gnr ac-btn')]//span[text()='Cancel']"),"AI Generated Captions Cancel Button"),

	/** The first send for approval. */
	FIRST_SEND_FOR_APPROVAL(By.xpath("(//button[text()='Send For Approval'])[1]"), "First Send For Approval"),

	/** The post reply button. */
	POST_REPLY_BUTTON(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lv-comment']//div[@class='lvc-base']//button[text()='Post Reply']"),
			"Post reply button"),
	
	FIRST_DEFAULT_MESSAGE_POST_REPLY_BUTTON("//span[text()='%s']//ancestor::div[@class='lvc-top']//following-sibling::div[@class='lvc-base']//button[text()='Post Reply']",
			"FIRST_DEFAULT_MESSAGE_POST_REPLY_BUTTON"),

	/** The reply sent. */
	REPLY_SENT_MESSAGE(By.xpath("//span[text()='Reply sent!']"), "Reply sent message"),

	/** The reply brand icon. */
	REPLY_BRAND_ICON(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='li-top-internal-notes']//div[contains(@class,'brand-icon')]"),
			"Reply brand icon"),

	/** The reply media name. */
	REPLY_MEDIA_NAME(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='li-top-internal-notes']//div[@class='lvt-details']//h3"),
			"Reply media name"),

	/** The reply date time. */
	REPLY_DATE_TIME(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='li-top-internal-notes']//div[@class='lvt-details']//span//following-sibling::span"),
			"Reply date time"),

	/** The replied content. */
	REPLIED_CONTENT(
			"//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='vcm-details']//p[contains(text(),'%s')]",
			"Replied content"),

	/** The internal notes button. */
	INTERNAL_NOTES_BUTTON(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-base']//img[@alt='Internal Notes']//parent::div[@class='vc-item']//span"),
			"Internal notes button"),

	/** The add internal note. */
	ADD_INTERNAL_NOTE(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lv-comment']//div[@class='lvc-top']//textarea[@placeholder='Add Internal Note']"),
			"Add internal note"),

	/** The post internal note. */
	POST_INTERNAL_NOTE(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='lv-comment']//div[@class='lvc-base']//button[text()='Post Internal Note']"),
			"Post internal note"),

	/** The internal note sent message. */
	INTERNAL_NOTE_SENT_MESSAGE(By.xpath("//span[text()='Internal note sent!']"), "Internal note sent message"),

	/** The internal notes contents. */
	INTERNAL_NOTES_CONTENTS(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='review-notes-top']//div[@class='reviewNote-item']"),
			"Internal notes contents"),

	/** The internal notes brand icon. */
	INTERNAL_NOTES_BRAND_ICON(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='reviewNote-item']//div[@class='internal-notes-list']//div[@class='round-asset brand-icon']//img"),
			"Internal notes brand icon"),

	/** The internal notes location name. */
	INTERNAL_NOTES_LOCATION_NAME(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='reviewNote-item']//div[@class='internal-notes-list']//div[@class='lvt-details']//h3"),
			"Internal notes location name"),

	/** The internal notes date time. */
	INTERNAL_NOTES_DATE_TIME(By.xpath(
			"//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='reviewNote-item']//div[@class='internal-notes-list']//div[@class='lvt-details']//span//following-sibling::span"),
			"Internal notes date time"),

	/** The internal notes content. */
	INTERNAL_NOTES_CONTENT(
			"//div[contains(@class,'list-item')]//div[@class='li-base']//div[@class='reviewNote-item']//div[@class='vcm-details']//p[contains(text(),'%s')]",
			"Internal notes content"),

	/** The post location. */
	POST_LOCATION(By.xpath("//div[contains(@class,'list-item ')]//div[@class='li-top']//div[@class='lvt-details']//h3"),
			"Post location"),

	/** The locations filter. */
	LOCATIONS_FILTER(By.xpath("//h3[text()='Location Selector']//parent::div[contains(@class,'filter-item')]"),
			"Locations filter"),

	/** The location dropdown. */
	LOCATION_DROPDOWN(By.xpath(
			"//div[@class='card']//div//span[text()='Locations']"),
			"Location dropdown"),

	LOCATION_SELECTOR_DROPDOWN_LIST(By.xpath("//div[contains(@class,'collapse show')]//img[contains(@src,'location') and not(contains(@src,'Lists'))]"),
	        "Location selector dropdown list"),
	
	/** The current location. */
	CURRENT_LOCATION(By.xpath(
			"//section[contains(@class,'item-g filter')]//h3[text()='Location Selector']//parent::div//div//span"),
			"Current location"),

	/** The location dropdown searchtab. */
	LOCATION_DROPDOWN_SEARCHTAB(By.xpath("//div[@id='account-switcher-dropdown']//div//div"),
			"Search tab of locatio selection"),

	/** The locations filter modal. */
	LOCATIONS_FILTER_MODAL(By.xpath("//div[@class='modal-content']//div[@class='modal-body']"),
			"Locations filter modal"),

	/** The locations dropdown button. */
	LOCATIONS_DROPDOWN_BUTTON(By.xpath("//div[text()='Locations']//parent::button"), "Locations dropdown button"),

	/** The locations list. */
	LOCATIONS_LIST(By.xpath(
			"//div[text()='Locations']//ancestor::div[contains(@class,'card')]//div[contains(@class,'collapse show')]"),
			"Locations list"),

	/** The location. */
	LOCATION(By.xpath("//ul[@class='hub-list']//li//span[text()='Automation Location two']"), "Location"),

	/** The prod location. */
	PROD_LOCATION(By.xpath("//ul[@class='hub-list']//li//span[text()='Alex Kiss - 148 - Sylvania, OH']"),
			"Prod location"),

	/** The cancel button. */
	CANCEL_BUTTON(By.xpath("//div[contains(@class,'modal-footer')]//button[text()='Cancel']"), "Cancel button"),

	/** The ok button. */
	OK_BUTTON(By.xpath("//div[contains(@class,'modal-footer')]//button[text()='Ok']"), "Ok button"),

	/** The bean me up. */
	BEAN_ME_UP(By.xpath("//div[@class='ds-dropdown']//button"), "Bean Me Up"),

	/** The brand hub location name. */
	BRAND_HUB_LOCATION_NAME(
			By.xpath("//div[@class='brand-profile h-assorted']//div[@class='ds-dropdown']//button//span"),
			"Brand Hub Location name"),

	/** Brand Hub Location dropdown. */
	BRAND_HUB_LOCATION_DROPDOWN(By.xpath(
			"//div[@class='brand-profile h-assorted']//div[@class='ds-dropdown']//div[contains(@class,'ds-menu')]"),
			"Brand Hub Location dropdown"),

	/** Brand Hub Location dropdown search. */
	BRAND_HUB_LOCATION_DROPDOWN_SEARCH_TAB(
			By.xpath("//div[@class='ds-drp-indicator']//parent::div//preceding-sibling::div//input"),
			"Brand Hub Location dropdown search"),

	/** The select account from dropdown. */
	SELECT_ACCOUNT_FROM_DROPDOWN(
			"//div[@class='brand-profile h-assorted']//div[@class='ds-dropdown']//div[@class='ds-menu']//div[contains(@id,'react-select') and text()='%s']",
			"Select account from dropdown"),

	/** The listed locations of user. */
	LISTED_LOCATIONS_OF_USER(By.xpath(
			"//div[@class='rs-drp__menu-list css-11unzgr']/div[contains(@class,'as-item location-icon-wraps rs-drp__option css-yt9ioa-option')]"),
			"Brand Hub Location dropdown search"),

	/** The listed hub of user. */
	LISTED_HUB_OF_USER(
			By.xpath("//div[@class='rs-drp__menu-list css-11unzgr']/div[contains(@class,'as-item admin-icon-wraps')]"),
			"Brand Hub Location dropdown search"),

	/** The first user write reply. */
	FIRST_USER_WRITE_REPLY(By.xpath(
			"(//div[contains(@class,'list-view review-list')]//div[1]//textarea[contains(@placeholder,'Write a reply')])[1]"),
			"First Write Reply"),

	/** The write reply by name with content. */
	WRITE_REPLY_BY_NAME_WITH_CONTENT(
			"//*[contains(text(),'%s')]//ancestor::div[@class='li-top']//following::div[@class='lv-assets']//*[text()='%s']//ancestor::div[@class='li-base']//div[@class='lv-comment']//textarea",
			"Write reply by name with content"),

	/** The send for approval option by name and content. */
	SEND_FOR_APPROVAL_OPTION_BY_NAME_AND_CONTENT(
			"//*[contains(text(),'%s')]//ancestor::div[@class='li-top']//following::div[@class='lv-assets']//*[text()='']//ancestor::div[@class='li-base']//div[@class='lv-comment']//*[text()='Send For Approval']",
			"Send for Approval option by name and content"),

	/** The send for approval approve option by name and content. */
	SEND_FOR_APPROVAL_APPROVE_OPTION_BY_NAME_AND_CONTENT(
			"//*[contains(text(),'%s')]//ancestor::div[@class='li-top']//following::div[@class='lv-assets']//*[text()='%s']//ancestor::div[@class='li-base']//div[@class='lv-comment']//*[text()='Approve']",
			"Approve option by name and content"),

	/** The send for approval reject option by name and content. */
	SEND_FOR_APPROVAL_REJECT_OPTION_BY_NAME_AND_CONTENT(
			"//*[contains(text(),'%s')]//ancestor::div[@class='li-top']//following::div[@class='lv-assets']//*[text()='%s']//ancestor::div[@class='li-base']//div[@class='lv-comment']//*[text()='Reject']",
			"Reject option by name and content"),

	/** The send for approval edit option by name and content. */
	SEND_FOR_APPROVAL_EDIT_OPTION_BY_NAME_AND_CONTENT(
			"//*[contains(text(),'%s')]//ancestor::div[@class='li-top']//following::div[@class='lv-assets']//*[text()='%s']//ancestor::div[@class='li-base']//div[@class='lv-comment']//*[text()='Save']",
			"Edit option by name and content"),

	/** The send for approval save option by name and content. */
	SEND_FOR_APPROVAL_SAVE_OPTION_BY_NAME_AND_CONTENT(
			"//*[contains(text(),'%s')]//ancestor::div[@class='li-top']//following::div[@class='lv-assets']//*[text()='%s']//ancestor::div[@class='li-base']//div[@class='lv-comment']//*[text()='Edit']",
			"Save option by name and content"),

	/** The existing reviews count by name and content. */
	EXISTING_REVIEWS_COUNT_BY_NAME_AND_CONTENT(
			"//*[contains(text(),'%s')]//ancestor::div[@class='li-top']//following::div[@class='lv-assets']//*[text()='%s']//ancestor::div[@class='li-base']//div[@class='vcm-details']",
			"Existing reviews Count By name and content"),

	/** The write reply by name. */
	WRITE_REPLY_BY_NAME(By.xpath(
			"(//div[contains(@class,'list-view review-list')]//div[1]//textarea[contains(@placeholder,'Write a reply')])[1]"),
			"Write reply by name with content"),

	/** The review reject feedback form. */
	REVIEW_REJECT_FEEDBACK_FORM(By.xpath(
			"//div[@class='feedback-txtarea']//div[text()='Feedback']"),
			"Review Reject feedback form"),

	REVIEW_REJECT_FEEDBACK_FIELD_AREA(By.xpath("(//div[@class='public-DraftEditorPlaceholder-root'])[2]"),
			"REVIEW_REJECT_FEEDBACK_FIELD_AREA"),
	
	/** The review reject feedback field. */
	REVIEW_REJECT_FEEDBACK_FIELD(By.xpath("(//div[@class='DraftEditor-editorContainer'])[3]//div[contains(@aria-describedby,'placeholder-editor-reviews-req-reply-reject')]"),
			"Review Reject feedback form Textfield"),

	/** The review reject feedback text field. */
	REVIEW_REJECT_FEEDBACK_TEXT_FIELD(By.xpath("//div[contains(@id,'placeholder-editor-reviews-req-reply-reject')]"),
			"Review Reject feedback Text Field"),

	/** The review reject feedback form cancel. */
	REVIEW_REJECT_FEEDBACK_FORM_CANCEL(
			By.xpath("//div[contains(@class,'reputation__review-reject--modal modal')]//button[text()='Cancel']"),
			"Review Reject feedback Cancel"),

	/** The review reject feedback form reject. */
	REVIEW_REJECT_FEEDBACK_FORM_REJECT(
			By.xpath("//div[contains(@class,'reputation__review-reject--modal modal')]//button[text()='Reject']"),
			"Review Reject feedback Reject"),

	/** The review reject reset field. */
	REVIEW_REJECT_RESET_FIELD(
			By.xpath("//div[contains(@class,'reputation__review-reject--modal modal')]//div[@class='resetIcon']"),
			"Review Reject feedback Reset Option"),

	/** The send for approval option. */
	SEND_FOR_APPROVAL_OPTION(By.xpath(
			"(//div[contains(@class,'list-view review-list')]//div[1]//textarea[contains(@placeholder,'Write a reply')])[1]"),
			"Send for Approval option"),

	/** The send for approval pop up. */
	SEND_FOR_APPROVAL_POP_UP(By.xpath("//div[@role='alert']//span[text()='A reply has been sent for approval']"),
			"Send for Approval"),

	/** The reply has been sent popup. */
	REPLY_HAS_BEEN_SENT_POPUP(By.xpath("//div[@role='alert']//span[text()='A reply has been sent for approval']"),
			"Reply has been Sent for Approval Popup"),

	/** The reply sent popup. */
	REPLY_SENT_POPUP(By.xpath("//div[@role='alert']//span[text()='Reply sent!']"), "Reply Sent Popup"),

	/** The reply reject popup. */
	REPLY_REJECT_POPUP(By.xpath("//div[@role='alert']//span[text()='Reply rejected']"), "Reply Reject Popup"),

	/** The failed to send reply popup. */
	FAILED_TO_SEND_REPLY_POPUP(By.xpath("//div[@role='alert']//span[text()='Reply sent']"),
			"Failed To Send Reply popup"),

	/** The default reply edit option. */
	DEFAULT_REPLY_EDIT_OPTION(By.xpath("//button[contains(@class,'auto lv-prime edit-save-btn')]"),
			"Default Reply Edit Option"),

	/** The send for approval reject option. */
	SEND_FOR_APPROVAL_REJECT_OPTION(By.xpath(
			"(//div[contains(@class,'list-view review-list')]//div[1]//textarea[contains(@placeholder,'Write a reply')])[1]"),
			"Send for Approval Reject option"),

	/** The send for approval approve option. */
	SEND_FOR_APPROVAL_APPROVE_OPTION(By.xpath(
			"(//div[contains(@class,'list-view review-list')]//div[1]//textarea[contains(@placeholder,'Write a reply')])[1]"),
			"Send for Approval Approve option"),

	/** The uploaded reply post. */
	UPLOADED_REPLY_POST(By.xpath("//div[@class='vcm-details']//p[contains(text(),'')]"), "Reply post."),

	/** The most recent review date. */
	MOST_RECENT_REVIEW_DATE_FACEBOOK(
			By.xpath("(//div[contains(@class,'list-view review')]//div[@class='lvt-details']//span[last()])[1]"),
			"MOST_RECENT_REVIEW_DATE_FACEBOOK"),

	MOST_RECENT_REVIEW_DATE_GOOGLE(
			By.xpath("(//div[contains(@class,'list-view review')]//div[@class='lvt-details']//span[3])[1]"),
			"MOST_RECENT_REVIEW_DATE_GOOGLE"),

	MOST_RECENT_REVIEW_DATE_YELP(
			By.xpath("(//div[contains(@class,'list-view review')]//div[@class='lvt-details']//span[3])[1]"),
			"MOST_RECENT_REVIEW_DATE_YELP"),

	/** The most recent uploaded reply post. */
	MOST_RECENT_UPLOADED_REPLY_POST(By.xpath("//div[@class='vcm-details']//p[contains(text(),'')]"),
			"Most Recent Reply post."),

	/** The most recent reply command yelp. */
	MOST_RECENT_REPLY_COMMAND_YELP(
			By.xpath("(//div[contains(@class,'list-item')]//div[@class='li-top']//img[contains(@src,'yelp')])[1]"),
			"Most Recent Reply Command Yelp."),

	/** The yelp review this review has been replied to. */
	YELP_REVIEW_THIS_REVIEW_HAS_BEEN_REPLIED_TO(By.xpath(
			"//div[contains(@class,'list-item')][1]//div[@class='vc-item']//img[@alt='Handle replied to']//following-sibling::span[text()='This Review has been replied to']"),
			"Yelp-This Review has to replied to option"),

	/** The most recent reply command facebook. */
	MOST_RECENT_REPLY_COMMAND_FACEBOOK(
			By.xpath("(//div[contains(@class,'list-item')]//div[@class='li-top']//img[contains(@src,'fb')])[1]"),
			"Most Recent Reply Command Facebook."),

	/** The most recent reply command google. */
	MOST_RECENT_REPLY_COMMAND_GOOGLE(
			By.xpath("(//div[contains(@class,'list-item')]//div[@class='li-top']//img[contains(@src,'google')])[1]"),
			"Most Recent Reply Command Google."),

	/** The profile icon. */
	PROFILE_ICON(By.xpath("//button[@id='dropitems-profile-items']"), "Profile icon"),

	/** Profile icon dropdown. */
	PROFILE_ICON_DROPDOWN(
			By.xpath("//button[@id='dropitems-profile-items']//following-sibling::div[@class='dropdown-menu show']"),
			"Profile icon dropdown"),

	/** The dropdown logout. */
	DROPDOWN_LOGOUT(By.xpath("//div[@class='dropdown-menu show']//a[text()='Logout']"), "Dropdown logOut"),

	/** The location selector. */
	LOCATION_SELECTOR(By.xpath("//section//*[text()='Location Selector']//parent::div//span[@class='lcs-name']"),
			"Location Selecter."),

	/** The location selector open. */
	LOCATION_SELECTOR_OPEN(By.xpath(
			"//div[@class='asm-btn']//parent::div[@class='modal-footer']//preceding-sibling::div[@class='asm-accord']"),
			"Location Selecter Open."),

	/** The location selector hub tab. */
	LOCATION_SELECTOR_HUB_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Hubs']"),
			"Location Selecter Hub tab."),

	/** The location selector hub tab open. */
	LOCATION_SELECTOR_HUB_TAB_OPEN(
			By.xpath("//img[contains(@src,'hubs')]//ancestor::div[contains(@class,'collapse show')]"),
			"Location Selecter Hub Tab Open."),

	/** The location selector location tab. */
	LOCATION_SELECTOR_LOCATION_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Locations']"),
			"Location Selecter Location tab."),

	/** The location selector locationlist tab. */
	LOCATION_SELECTOR_LOCATIONLIST_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Location Lists']"),
			"Location Selecter Location List tab."),

	/** The location selector locationlist tab. */
	LOCATION_SELECTOR_LOCATIONLIST_TAB_OPEN(
			By.xpath("//div[contains(@class,'accordion')]//span[text()='Location Lists']"),
			"Location Selecter Location List tab Open"),

	/** The location selector location tab open. */
	LOCATION_SELECTOR_LOCATION_TAB_OPEN(
			By.xpath("//img[contains(@src,'location')]//ancestor::div[contains(@class,'collapse show')]"),
			"Location Selecter Location Tab Open"),

	/** The location selector dropdown user. */
	LOCATION_SELECTOR_DROPDOWN_USER("//div//ul[@class='hub-list']//span[contains(text(),\"%s\")]",
			"Location Selecter Dropdown User"),

	/** The location selector byname. */
	LOCATION_SELECTOR_BYNAME("//div[contains(@class,'list-item')]//div[@class='lvt-details']//h3[contains(text(),'%s')]","The Location Selector By name"),
	
	/** The list of hubs. */
	LIST_OF_HUBS(By.xpath("//img[contains(@src,'hub')]//parent::label//span[@class='lcs-name']"), "List of Hubs"),

	/** The list of locations. */
	LIST_OF_LOCATIONS(By.xpath(
			"//div[contains(@class,'collapse show')]//img[contains(@src,'location') and not(contains(@src,'Lists'))]"),
			"List of Locations"),

	/** The list of locationlist. */
	LIST_OF_LOCATIONLIST(By.xpath(
			"//div[@class='card']//div[@class='collapse show']//ul[@class='hub-list']//li//label//span[contains(@class,'list')]"),
			"List of Location list"),

	// LOCATION_SELECTOR_CHOOSE_HUB(By.xpath("//div[@class='card']//div[@class='collapse
	// show']//ul[@class='hub-list']//li//label//span[text()='']"), "Location
	// Selecter Hub Tab Open."),

	// LOCATION_SELECTOR_ACTIVE_HUB(By.xpath("//div[@class='card']//div[@class='collapse
	// show']//ul[@class='hub-list']//li//label//span[contains(@class,'active') and
	// text()='Alvarado']"), "Location Selecter Hub Tab Open."),

	/** The location selector ok button. */
	LOCATION_SELECTOR_OK_BUTTON(By.xpath("//div[@class='asm-btn']//div//button[text()='Ok']"),
			"Location Selecter Ok Button"),

	/** The location selector search tab. */
	LOCATION_SELECTOR_SEARCH_TAB(By.xpath("//div[@class='asm-lf']//input[@placeholder = 'Search']"),
			"Location Selecter Search Tab"),

	/** The location selector cancel button. */
	LOCATION_SELECTOR_CANCEL_BUTTON(By.xpath("//div[@class='asm-btn']//div//button[text()='Cancel']"),
			"Location Selector Cancel Button"),

	/** The location selector close button. */
	LOCATION_SELECTOR_CLOSE_BUTTON(By.xpath("//img[@class='close-icon']"), "Location Selector Close Button"),

	/** The recommended reviews text. */
	RECOMMENDED_REVIEWS_TEXT(
			By.xpath("//div[contains(@class,'list-item')]//div[@class='form-control g-se']//span[1]//span"),
			"The Not Recommended Reviews"),

	/** The sortby dropdowns. */
	SORTBY_DROPDOWNS(By.xpath(
			"//div[text()='Sort by']//parent::div//parent::div//div[@class='sortby-list__wrp']//div[@class='ds-dropdown']//following-sibling::div[@class='ds-dropdown']"),
			"Sortby dropdowns"),

	/** The review replytab by post text. */
	REVIEW_REPLYTAB_BY_POST_TEXT(
			"//div[contains(@class,'list-item')]//span[text()='%s']//ancestor::div[@class='lv-assets']//following-sibling::div[@class='lv-comment']//div[contains(@id,'reviews-reply')]",
			"Review Reply By Post Text"),

	/** The post reply button by post text. */
	POST_REPLY_BUTTON_BY_POST_TEXT(
			"//div[contains(@class,'list-item')]//span[text()='%s']//ancestor::div[@class='list-item animate__animated animate__fadeIn reputation-wrp']//div[@class='lvc-base']//button[text()='Post Reply']",
			"Post Reply Button By Post Text"),

	/** The send for approval by post text. */
	SEND_FOR_APPROVAL_BY_POST_TEXT(
			"//div[contains(@class,'list-item')]//span[text()='%s']//ancestor::div[@class='list-item animate__animated animate__fadeIn reputation-wrp']//div[@class='lvc-base']//button[text()='Send For Approval']",
			"Send for Approval By Post Text"),
   
	SEND_FOR_APPROVAL_BUTTON(By.xpath("//div[@class='lvc-base']//button[text()='Send For Approval']"),"Send For Approval button"),
	
	/** The approve post option by post text. */
	APPROVE_POST_OPTION_BY_POST_TEXT(
			"//div[contains(@class,'list-item')]//span[contains(text(),'%s')]//ancestor::div[@class='list-item animate__animated animate__fadeIn reputation-wrp']//div[@class='lvc-base']//button[text()='Approve']",
			"Approve Option By Post Text"),

	/** The internal notes option by posttext. */
	INTERNAL_NOTES_OPTION_BY_POSTTEXT(
			"//span[text()='%s']//ancestor::div[@class='lv-assets']//following-sibling::div//div//span[contains(text(),'Internal Note')]",
			"Internal Notes Option By Post Text"),

	/** The internal notes content with posttext. */
	INTERNAL_NOTES_CONTENT_WITH_POSTTEXT(
			"//span[text()='%s']//ancestor::div[@class='lv-assets']//following-sibling::div//div//span[contains(text(),'Internal Note')]//ancestor::div[@class='vc-controls']//following-sibling::div//p[contains(text(),'%s')]",
			"Internal Notes Option By Post Text"),

	/** The edit review by post text. */
	EDIT_REVIEW_BY_POST_TEXT(
			"//div[contains(@class,'list-item')]//span[text()='%s']//ancestor::div[@class='list-item animate__animated animate__fadeIn reputation-wrp']//div//button[text()='Edit']",
			"Edit Button Of Review"),

	/** The save review by post text. */
	SAVE_REVIEW_BY_POST_TEXT(
			"//div[contains(@class,'list-item')]//span[text()='%s']//ancestor::div[@class='list-item animate__animated animate__fadeIn reputation-wrp']//div//button[text()='Save']",
			"Save Button Of Review"),

	/** The emoji option of post. */
	EMOJI_OPTION_OF_POST(
			"//div[contains(@class,'list-item')]//span[text()='%s']//ancestor::div[@class='list-item animate__animated animate__fadeIn reputation-wrp']//div[contains(@class,'emoji')]",
			"Emoji Icon Of Review"),

	/** The thumbsup emoji option of post. */
	THUMBSUP_EMOJI_OPTION_OF_POST(
			"(//div[contains(@class,'list-item')]//span[text()='%s']//ancestor::div[@class='list-item animate__animated animate__fadeIn reputation-wrp']//div[contains(@class,'emoji')]//button[contains(@aria-label,'thumbsup')])[1]",
			"ThumpsUp Emoji Icon Of Review"),

	/** The reject post option by post text. */
	REJECT_POST_OPTION_BY_POST_TEXT(
			"//div[contains(@class,'list-item')]//span[text()='%s']//ancestor::div[@class='list-item animate__animated animate__fadeIn reputation-wrp']//div[@class='lvc-base']//button[text()='Reject']",
			"Reject Option By Post Text"),

	/** The review reply message count of the post. */
	REVIEW_REPLY_MESSAGE_COUNT_OF_THE_POST(
			"//span[text()='%s')]//ancestor::div[@class='lv-assets']//following-sibling::div//following-sibling::div[@class='review-notes-top']//p",
			"Review Reply Count of the post"),

	/** The review replytab filled with reply message. */
	REVIEW_REPLYTAB_FILLED_WITH_REPLY_MESSAGE(
			By.xpath("//div[@class='lv-comment']//div[@class='DraftEditor-editorContainer']//span[@data-text='true']"),
			"Review Reply Tab Filled with text"),

	/** The review replytab by text. */
	REVIEW_REPLYTAB_BY_TEXT(
			"//div[contains(@class,'list-item')]//ancestor::div//div[@class='public-DraftStyleDefault-block public-DraftStyleDefault-ltr']",
			"Review Reply By Post Text"),

	/** The double digit calendar day. */
	DOUBLE_DIGIT_CALENDAR_DAY("(//div[contains(@class,'react-datepicker') and text()='%s'])[last()]",
			"Day of the Month"),

	/** The single digit calendar day. */
	SINGLE_DIGIT_CALENDAR_DAY("(//div[contains(@class,'react-datepicker') and text()='%s'])[1]", "Day of the Month"),

	/** The date picker. */
    DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]","Date Picker"),
  
	
	LINK_TO_REVIEW_BUTTON(By.xpath("//div[@class='li-top']//div[@class='more-dots-horizontal cur-pointer']//img"),
			"LinkTo Review Button"),

	/** The post text content. */
	POST_TEXT_CONTENT(By.xpath("//div[contains(@class,'list-item')]//p[@class='sm-full-text']"),
			"Post text content"),

	AI_SUBSCRIBTION_VIDEO_PLAY(By.xpath(
			"//div[@role='tooltip']//div[@class='aicoach-body']//div[@class='aicoach-cnt']//div[@class='ai-coach-video']"),
			"AI Subscribtion Video Play"),

	AI_VIDEO_DONOT_SHOW_ME_CHECKBOX(By.xpath(
			"//div[@class='aicoach-body']//label[@class='checkbox-item']//span[@class='checkbox-hover']//input[@name='localizePost']"),
			"AI Subscribtion Video Check Box"),
	
	REVIEW_REPLY_POST_BY_TEXT("//div[@class='vcm-details']//p[contains(text(),'%s')]",
			"REVIEW_REPLY_POST_BY_TEXT"),
	
	RECOMMENTS_CONTENT_WITH_LOCATION(By.xpath("//div[contains(@class,'list-item')]//img[@alt='Recommends']//parent::div[@class='pu-item']//following-sibling::span[contains(text(),'recommends')]"),"RECOMMENTS_CONTENT_WITH_LOCATION"),
	
	RECOMMENTS_LOCATION("//div[@class='lvt-brief multi-lvtxt star-rating-align-review']//span[@class='lvt-txt' and contains(text(),'%s')]","Recomments Location"),
	
	/** The day of the month. */
	DAY_OF_THE_MONTH("//div[contains(@class,'react-datepicker') and text()='%s']","Day of the Month"),
	
	/** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),
	
	CONNECT_PAGE_BUTTON(By.xpath("//h2[text()='Connect your social platforms']//parent::div//button[text()='Connect Now']"),"CONNECT_PAGE_BUTTON"),

	;

	/** The by locator. */
	private By byLocator;

	/** The xpath. */
	private String xpath;

	/** The description. */
	private String description;

	/**
	 * Instantiates a new reputation tab reviews page enum.
	 *
	 * @param byLoactor   the by loactor
	 * @param description the description
	 */
	private ReputationTabReviewsPageEnum(By byLoactor, String description) {

		this.byLocator = byLoactor;
		this.description = description;
	}

	/**
	 * Instantiates a new reputation tab reviews page enum.
	 *
	 * @param xpath       the xpath
	 * @param description the description
	 */
	private ReputationTabReviewsPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}
}

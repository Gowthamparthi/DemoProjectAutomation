package com.rallio.automation.newrallio.enums;

public enum RevvSurveysPageStatusFilterEnum {

	SURVEYS_SENT,
	
	/** The one star. */
	SURVEYS_NOT_SENT,
	
	/** The two star. */
	SURVEYS_COMPLETED,
	
	/** The three star. */
	AGREED_TO_REVIEW,
	
	/** The four star. */
	LEFT_A_COMMENT,
	
	/** The five star. */
	CONTACT_REQUESTED,

	/** The all star. */
	SELECT_ANY_STATUS;
	
}

package com.rallio.automation.newrallio.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum ReviewsPageStatusFilterEnum.
 */
public enum ReviewsPageStatusFilterEnum {
	
	/** The show all. */
	SHOW_ALL,

	/** The closed. */
	CLOSED,
	
	/** Open */
	OPEN;
}

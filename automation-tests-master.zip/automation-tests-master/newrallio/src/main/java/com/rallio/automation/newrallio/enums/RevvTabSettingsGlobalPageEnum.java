package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

public enum RevvTabSettingsGlobalPageEnum {

    /** The no data to show. */
    PAGE_LOAD_GLOBAL(By.xpath("//div[contains(@class,'sub-nav-tabs')]//span[text()='Settings']//parent::li[contains(@class,'active')]//following::div[@class='mobile-active active nav-item' and text()='Global']//ancestor::div//div[contains(@class,'non-psp-settings__container')]"),"PAGE_LOAD"),
    
    //Survey Type Section  
    SURVEY_TYPE_TEXT_CONTENT(By.xpath("//div[text()='Survey Type']//ancestor::div[@class='settings__card']//div[text()='Send survey by Emoji, Numerical, or NPS:']"),"SURVEY_TYPE_TEXT_CONTENT"),

    SURVEY_TYPE_EMOJI_SURVEY_BUTTON(By.xpath("//div[text()='Survey Type']//ancestor::div[@class='settings__card']//label[text()='Emoji Survey']//preceding-sibling::input"),"SURVEY_TYPE_EMOJI_SURVEY_BUTTON"),

    SURVEY_TYPE_NUMERICAL_SURVEY_1_5_BUTTON(By.xpath("//div[text()='Survey Type']//ancestor::div[@class='settings__card']//label[text()='Numerical Survey (1-5)']//preceding-sibling::input"),"SURVEY_TYPE_EMOJI_SURVEY_BUTTON"),

    SURVEY_TYPE_NUMERICAL_SURVEY_1_10_BUTTON(By.xpath("//div[text()='Survey Type']//ancestor::div[@class='settings__card']//label[text()='Numerical Survey (1-10)']//preceding-sibling::input"),"SURVEY_TYPE_EMOJI_SURVEY_BUTTON"),
	
	SURVEY_TYPE_PREVIEW_BUTTON(By.xpath("//div[text()='Survey Type']//ancestor::div[@class='settings__card']//button[text()='Preview']"),"SURVEY_TYPE_PREVIEW_BUTTON"),
		
	//Review Sites
    REVIEW_SITES_TEXT_CONTENT(By.xpath("//div[text()='Review Sites']//ancestor::div[@class='settings__card']//div[@class='right-parg__text' and starts-with(text(),'After a customer')]//following-sibling::div[starts-with(text(),'If you choose')]"),"REVIEW_SITES_TEXT_CONTENT"),

    DISABLE_REVIEW_SITES_BUTTON(By.xpath("//div[text()='Review Sites']//ancestor::div[@class='settings__card']//label[text()='Disable review sites']//preceding-sibling::input"),"DISABLE_REVIEW_SITES_BUTTON"),

    SHOW_ALL_REVIEWS_BUTTON(By.xpath("//div[text()='Review Sites']//ancestor::div[@class='settings__card']//label[text()='Show all review sites']//preceding-sibling::input"),"SHOW_ALL_REVIEWS_BUTTON"),
	
	SELECT_A_REVIEW_SITE_AUTOMATICALLY(By.xpath("//div[text()='Review Sites']//ancestor::div[@class='settings__card']//label[text()='Select a review site automatically']//preceding-sibling::input"),"SELECT_A_REVIEW_SITE_AUTOMATICALLY"),
		
	//WHO WILL BE OFFERED 
    EVERYONE_BUTTON(By.xpath("//div[text()='Who Will Be Offered A Chance To Leave Reviews?']//ancestor::div[@class='settings__card']//label[text()='Everyone']//preceding-sibling::input"),"EVERYONE_BUTTON"),

    ONLY_THOSE_WITH_A_POSITIVE_SURVEY_RESPONSE(By.xpath("//div[text()='Who Will Be Offered A Chance To Leave Reviews?']//ancestor::div[@class='settings__card']//label[text()='Only those with a positive survey response']//preceding-sibling::input"),"ONLY_THOSE_WITH_A_POSITIVE_SURVEY_RESPONSE"),
	
	WHO_WILL_BE_OFFERED_PREVIEW_BUTTON(By.xpath("//div[text()='Who Will Be Offered A Chance To Leave Reviews?']//ancestor::div[@class='settings__card']//button[text()='Preview']"),"WHO_WILL_BE_OFFERED_PREVIEW_BUTTON"),

	FIRST_PRIORITY_FACEBOOK_DROPDOWN(By.xpath("//div[text()='Who Will Be Offered A Chance To Leave Reviews?']//ancestor::div[@class='settings__card']//label[text()='First Priority']//parent::div//input[contains(@class,'dropdown') and @value='Facebook']"),"FIRST_PRIORITY_FACEBOOK_DROPDOWN"),

    SECOND_PRIORITY_YELP_DROPDOWN(By.xpath("//div[text()='Who Will Be Offered A Chance To Leave Reviews?']//ancestor::div[@class='settings__card']//label[text()='Second Priority']//parent::div//input[contains(@class,'dropdown') and @value='Yelp']"),"SECOND_PRIORITY_YELP_DROPDOWN"),
		
	THIRD_PRIORITY_GOOGLE_DROPDOWN(By.xpath("//div[text()='Who Will Be Offered A Chance To Leave Reviews?']//ancestor::div[@class='settings__card']//label[text()='Third Priority']//parent::div//input[contains(@class,'dropdown') and @value='Google']"),"THIRD_PRIORITY_GOOGLE_DROPDOWN"),

	SEND_SURVEY_VIA_TEXT_OR_EMAIL(By.xpath("//div[text()='Survey Delivery Method']//following::div[text()='Send survey via text or email:']"),"Send survey via text or email:"),
	TEXT_ONLY_BUTTON(By.xpath("//div[text()='Survey Delivery Method']//ancestor::div[@class='settings__card']//label[text()='Text Only']//preceding-sibling::input"),"WHO_WILL_BE_OFFERED_PREVIEW_BUTTON"),

	TEXT_PREFERRED(By.xpath("//div[text()='Survey Delivery Method']//ancestor::div[@class='settings__card']//label[text()='Text Preferred']//preceding-sibling::input"),"TEXT_PREFERRED"),

    EMAIL_ONLY_BUTTON(By.xpath("//div[text()='Survey Delivery Method']//ancestor::div[@class='settings__card']//label[text()='Email Only']//preceding-sibling::input"),"EMAIL_ONLY_BUTTON"),
		
	EMAIL_PREFERRED_BUTTON(By.xpath("//div[text()='Survey Delivery Method']//ancestor::div[@class='settings__card']//label[text()='Email Preferred']//preceding-sibling::input"),"EMAIL_PREFERRED_BUTTON"),

	TEXT_AND_EMAIL_BUTTON(By.xpath("//div[text()='Survey Delivery Method']//ancestor::div[@class='settings__card']//label[text()='Text and Email']//preceding-sibling::input"),"TEXT_AND_EMAIL_BUTTON"),

	SURVEY_DELIVERY_METHOD_TEXT_CONTENT(By.xpath("//div[text()='Survey Delivery Method']//ancestor::div[@class='settings__card']//div[@class='settings-note__mark' and starts-with(text(),' Choosing') and text()]"),"SURVEY_DELIVERY_METHOD_TEXT_CONTENT"),

	SURVEY_DELIVERY_METHOD_PREVIEW_BUTTON(By.xpath("//div[text()='Survey Delivery Method']//ancestor::div[@class='settings__card']//button[text()='Preview']"),"SURVEY_DELIVERY_MMETHOD_PREVIEW_BUTTON"),

	//Branding
	UPLOAD_COMPANY_LOGO_BROWSE_BUTTON(By.xpath("//div[text()='Branding']//ancestor::div[@class='settings__card']//div[text()='Upload Company Logo for Email']//parent::div//div[contains(@class,'drag-drop__card')]//span[text()='Drag & Drop your ']//preceding-sibling::img[contains(@src,'blue.svg')]//parent::div//parent::div//button[text()='Browse']"),"UPLOAD_COMPANY_LOGO_BROWSE_BUTTON"),

	BRANDING_UPLOAD_COMPANY_LOGO_FOR_EMAIL_TEXT(By.xpath("//div[text()='Branding']//following::div[text()='Upload Company Logo for Email']"),"Upload Company Logo for Email"),
	UPLOAD_COMPANY_LOGO_INPUT_FIELD(By.xpath("//div[text()='Branding']//ancestor::div[@class='settings__card']//div[text()='Upload Company Logo for Email']//parent::div//div[contains(@class,'drag-drop__card')]//input"),"UPLOAD_COMPANY_LOGO_INPUT_FIELD"),

	//Email White Label
	EMAIL_WHITE_LABEL_INPUT_FIELD(By.xpath("//div[text()='Email Whitelabel']//ancestor::div[contains(@class,'settings__card')]//span[text()='Return Email Address']//preceding-sibling::input"),"EMAIL_WHITE_LABEL_INPUT_FIELD"),

	SEND_SERVERY_BUTTON(By.xpath("//span[text()='Send Survey']"),"send servery button"),
	SURVEY_DELIVERY_DELAY_INPUT_FIELD(By.xpath("//div[text()='Survey Delivery Delay']//following::div[@class='settings-modal__grp']//label[text()='Delivery delay']"),"Survey Delivery Delay and input field of 'Delivery delay'"),
	//Blackout Peroiod
	BLACKOUT_LABEL_INPUT_FIELD(By.xpath("//div[text()='Blackout Period']//ancestor::div[contains(@class,'settings__card')]//div[text()='Your blackout period is the number of days until a customer is able to receive another survey from you.']//following-sibling::div//span[text()='Number of Days']//preceding-sibling::input"),"BLACKOUT_LABEL_INPUT_FIELD");

	
	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a RevvTabSettingsGlobalPageEnum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private RevvTabSettingsGlobalPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates RevvTabSettingsGlobalPageEnum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private RevvTabSettingsGlobalPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
	
	
	
	
	
}

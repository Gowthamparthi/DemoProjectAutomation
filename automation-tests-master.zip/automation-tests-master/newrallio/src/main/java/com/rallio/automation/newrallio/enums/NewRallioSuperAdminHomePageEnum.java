package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum NewRallioSuperAdminHomePageEnum.
 */
public enum NewRallioSuperAdminHomePageEnum {

	/** The superadmin page load. */
	SUPERADMIN_PAGE_LOAD(By.xpath(
	        "//span[text()='Accounts']//ancestor::div[@class='resizing-wrap']//label[@class='checkbox-item']//parent::div[@class='stc-item stc-right']//ancestor::div[contains(@class,'mainContent animate')]"),
	        "The superAdmin page load"),

	/** The search tab. */
	SEARCH_TAB(By.xpath("//div[@class='react-tags__search-input']//input"), "The Search Tab"),

	/** The users tab. */
	USERS_TAB(By.xpath("//li//span[text()='Users']"), "The Admin User Tab click"),

	/** The franchiser tab. */
	FRANCHISER_TAB(By.xpath("//span[@class='sub-nav-item-txt' and text()='Franchisors']"), "Franchiser Tab"),

	ACCOUNTS_TAB(By.xpath("//span[@class='sub-nav-item-txt' and text()='Accounts']"), "Accounts tab"),
	
	/** The user location. */
	USER_LOCATION(By.xpath("//tr//td//div//div//span[contains(text(),'%s')]"), "The Target Location"),

	/** The view location by name. */
	VIEW_LOCATION_BY_NAME(
	        "//span[@class='ad-name' and contains(text(),'%s')]//parent::div//parent::div//parent::td//following-sibling::td[2]//span[text()='View']",
	        "View Location By Name"),
	
	BRAND_LOCATION_DASH_BY_NAME(
	        "//span[@class='ad-name' and contains(text(),'%s')]//parent::div//parent::div//parent::td//following-sibling::td[4]//span[text()='View']",
	        "Brand Location By Name"),

	BRAND_ACCOUNT_DASH_VIEW_ID("//span[@class='ad-name' and contains(text(),'%s')]//parent::div//parent::div//parent::td//following-sibling::td[2]//span[text()='View']","Brand Location Dash View Id"),

	/** The view button. */
	VIEW_BUTTON(By.xpath("//tbody//tr//td//span[@class='admn-txt admn-view' and text()='View']//parent::td"), "The view Button"),
	
	PROFILE_ICON(By.xpath("//button[@id='dropitems-profile-items']"), "Profile icon"),

	/** Brand Hub Location name. */
	BRAND_HUB_LOCATION_NAME(By.xpath("//div[@class='ds-dropdown']//parent::div//button//span"), "Brand Hub Location name"),
	
	/** Brand Hub Location dropdown. */
	BRAND_HUB_LOCATION_DROPDOWN(By.xpath("//div[@class='brand-profile h-assorted']//div[@class='ds-dropdown']//div[contains(@class,'ds-menu')]"), "Brand Hub Location dropdown"),

	/** Brand Hub Location dropdown search. */
	BRAND_HUB_LOCATION_DROPDOWN_SEARCH(By.xpath("//div[@class='ds-drp-indicator']//parent::div//preceding-sibling::div//input"), "Brand Hub Location dropdown search"),

	/** Select account from dropdown. */
	SELECT_ACCOUNT_FROM_DROPDOWN("//div[@class='brand-profile h-assorted']//div[@class='ds-dropdown']//div[@class='ds-menu']//div[contains(@id,'react-select') and text()='%s']",
	        "Select account from dropdown"),
	
	/** The selected account name. */
	SELECTED_ACCOUNT_NAME("//div[@class='ds-dropdown']//button//span[@class='css-19r5em7' and text()='%s']","Selected Account From Dropdown Name"),
	
	/** The ai video donot show me checkbox. */
	AI_VIDEO_DONOT_SHOW_ME_CHECKBOX(By.xpath("//div[@class='aicoach-body']//label[@class='checkbox-item']//span[@class='checkbox-hover']//input[@name='localizePost']"),"AI Subscribtion Video Check Box"),
	
	/** The ai subscribtion video play. */
	AI_SUBSCRIBTION_VIDEO_PLAY(By.xpath("//div[@role='tooltip']//div[@class='aicoach-body']//div[@class='aicoach-cnt']//div[@class='ai-coach-video']"),"AI Subscribtion Video Play"),
	
	
	PROFILE_ICON_DROPDOWN(By.xpath("//button[@id='dropitems-profile-items']//following-sibling::div[@class='dropdown-menu show']"), "Profile icon dropdown"),
	
	DROPDOWN_LOGOUT(By.xpath("//div[@class='dropdown-menu show']//a[text()='Logout']"), "Dropdown logOut");


	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new new rallio home page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private NewRallioSuperAdminHomePageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new new rallio home page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private NewRallioSuperAdminHomePageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

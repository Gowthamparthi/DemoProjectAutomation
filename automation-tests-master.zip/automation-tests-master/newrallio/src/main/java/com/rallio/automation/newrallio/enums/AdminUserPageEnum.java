package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum AdminUserPageEnum.
 */
public enum AdminUserPageEnum {

	/** The page load. */
	PAGE_LOAD(
	        By.xpath("//div[@class='g-centre']//ancestor::div//div[@class='react-tags__search-input']//following::th[text()='Admin?']//ancestor::table[@class='responsiveTable table']"),
	        "The Admin User PageLoad"),

	/** The superadmin page load. */
	ACCOUNTPAGE_PAGELOAD(By.xpath(
	        "//span[text()='Accounts']//ancestor::div[@class='resizing-wrap']//label[@class='checkbox-item']//parent::div[@class='stc-item stc-right']//ancestor::div[contains(@class,'mainContent animate')]"),
	        "The AdminAccounts page load" ),

	/** The users tab. */
	USERS_TAB(By.xpath("//li//span[text()='Users']"), "The Admin User Tab click"),
	
	/** The accounts tab. */
	ACCOUNTS_TAB(By.xpath("//li//span[text()='Accounts']"), "The Admin User Tab click"),
	
	/** The email address. */
	EMAIL_ADDRESS(By.xpath("//input[@name='loginInputEmail']"), "Email Addresss"),

	/** The password. */
	PASSWORD(By.xpath("//input[@name='loginInputPassword']"), "Password"),

	/** The sign in button. */
	SIGN_IN_BUTTON(By.xpath("//button[contains(@class,'ac-btn ac-primary') and text()='SIGN IN']"), "Sign In Button"),

	/** The login homepageload. */
	LOGIN_HOMEPAGELOAD(By.xpath("//div[@class='login-elements']//h2[@class='welcome-text']"), "Page load for Sign In Page"),

	/** The search contents. */
	SEARCH_CONTENTS(By.xpath("//input[@placeholder='Search name, user and company']//parent::div[contains(@class,'react-tags')]"), "The User search by name,user and company"),

	/** The search tab. */
	SEARCH_TAB(By.xpath("//input[@type='text']"), "The Search tab"),

	/** The table email id. */
	TABLE_EMAIL_ID("//span[@title='%s']//ancestor::tr//span[@class='admn-txt admn-email']", "The Table Email"),

	/** The table user name. */
	TABLE_USER_NAME("//td//div[@class='adm-nid']//span[@title='%s']", "The Table Name"),

	/** The table company name. */
	TABLE_COMPANY_NAME("//span[@title= '%s']//ancestor::tr//span[@class='admn-txt admn-company']", "The Table company name"),
	
	TABLE_COMPANY_NAME_FIELD("//tr//span[@class='admn-txt admn-company' and text()='%s']","Table Company Name Field"),

	/** The user page table head. */
	USER_PAGE_TABLE_HEAD(By.xpath(
	        "//th[text()='Name']//ancestor::div[@class='g-centre']//th[text()='User']//following-sibling::th[text()='Company']//following-sibling::th[text()='Admin?']//following-sibling::th[text()='Become']//ancestor::table[@class='responsiveTable table']"),
	        "The User Page Table Headings"),

	/** The admin user tab. */
	ADMIN_USER_TAB(By.xpath("//li//span[text()='Users']"), "The Admin User Tab click"),

	/** The user email byname. */
	USER_EMAIL_BYNAME(By.xpath("//div[@class='adm-nid']//ancestor::div[@class='admn-thumb-right']//span[@title='Test Testuser']"), "Get the User Email by name"),

	/** The user email bynames. */
	USER_EMAIL_BYNAMES("//span[@title='%s']", "Get the User Email by name"),

//	/** The become button false. */
	BECOME_BUTTON_FALSE("(//span[@title='%s']/ancestor::td//following::td[3]//*[text()='false']//following::td//span[text()='Become'])[1]",
	        "The click Become button based on falsename"),

	/** The become button false byemail. */
	BECOME_BUTTON_FALSE_BYEMAIL("(//span[@title='%s']/ancestor::td//following::td[2]//*[text()='false']//following::td//span[text()='Become'])[1]",
	        "The click Become button based on falsename by email"),

	/** The become button true. */
	BECOME_BUTTON_TRUE("(//span[@title='%s']/ancestor::td//following::td[3]//*[text()='true']//following::td//span[text()='Become'])[1]", "The become button based on TrueName"),

	/** The become button byname. */
	BECOME_BUTTON_BYNAME("//span[@title='%s']//ancestor::tr//td[5]//button//span[text()='Become']", "The click the become button by name"),

	/** The confirm account notify. */
	CONFIRM_ACCOUNT_NOTIFY(By.xpath("//span[contains(text(),'You have to confirm your account before ')]"), "The Confirm Account notify"),

	LOGIN_DISABLED_POPUP(By.xpath("//span[@class='success-mess-txt' and text()='This login has been disabled. Please contact support@rallio.com if this is a mistake']"),"Login Disabled"),
	
	/** The dropdown restore sessions. */
	DROPDOWN_RESTORE_SESSIONS(By.xpath("//a[contains(text(),'Restore Session')]"), "The click Restore Session"),

	/** The dropdown by username. */
	DROPDOWN_BY_USERNAME("//div[contains(@class,'profile__modal')]//div[@class='up-short-dtls']//span[@class='upd-email' and text()='%s']", "The Username from Dropdown"),

	/** The dropdown changepassword. */
	DROPDOWN_CHANGEPASSWORD(By.xpath("//a[@role='button' and text()='Change Password']"), "The click Change Password"),

	/** The footer userpage. */
	FOOTER_USERPAGE(By.xpath("//table[@class='responsiveTable table']//tbody//tr[last()]"), "The scroll the table last element"),

	/** The userpage tablesize. */
	USERPAGE_TABLESIZE(By.xpath("//table[@class='responsiveTable table']//tbody//tr//td//div[@class='adm-nid']//div[@class='admn-thumb-right']"), "The Table count"),

	/** The send setup wizard. */
	SEND_SETUP_WIZARD(By.xpath("//span[text()='Send Setup Wizard']"), "The click send setup wizard"),

	/** The posts page load. */
	POSTS_PAGE_LOAD(By.xpath(
	        "//li[@class='ripple active']//span[text()='Posts']//following::section[contains(@class,'item-g filter')]//ancestor::main//section[@id='main-container-sec']//div[@class='g-post postwrap mbl-head--margin']"),
	        "The Posts Page load"),

	/** The teammanagement logins email. */
	TEAMMANAGEMENT_LOGINS_EMAIL("//div[text()='%s']//following-sibling::div[@class='email']", "The email by user name"),

	/** The add new login moreoptions. */
	ADD_NEW_LOGIN_MOREOPTIONS("//table//tbody//td[2]//div//div[2]//div[text()='%s']//ancestor::table//div[@class='rel-icons td-more cur-pointer']//img[@alt='More']",
	        "The click Add new logins more options"),

	/** The add new login deleteoption. */
	ADD_NEW_LOGIN_DELETEOPTION(By.xpath("//span[@class='delete-txt' and text()='Delete']"), "The click the Adnn new login delete option button"),

	/** The add new login delete. */
	ADD_NEW_LOGIN_DELETE(By.xpath("//button[text()='Delete']"),"The click Add new delete  button"),
	
	/** The delete done. */
	DELETE_DONE(By.xpath("//span[text()='Removed!']"),"The click the delete button"),
	
	/** The Adding new Admin email *. */
	ADDING_USER_LOGIN(By.xpath("//div[@class='userlogin-addnewuser-wrp userlogin-addnewuser__main']//following::input[@name='email']"), "The adding new admin login email"),

	/** The user by name. */
	USER_BY_NAME("(//span[@title='%s'])[1]","The click user by name"),
	
	/** The user details paeload. */
	USER_DETAILS_PAELOAD(By.xpath("//div[@class='modal-body']//ancestor::div//h2[text()='User Details']//following::div[@class='addnewuser-modal-content']//following::button//span[text()='Send Setup Wizard']"),"The user Details Pageload"),
	
	/** The user name. */
	USER_NAME("//span[text()='Name']//ancestor::div//input[@title='%s']","The user name display in user details"),

	/** The page load. */
	LOGINS_PAGE_LOAD(By.xpath("//div[@class='ea-on-stat--wrp logins-stat__main']//following::div[@class='infinite-scroll-component__outerdiv']//table[@class=' responsiveTable']"), "Page Load"),
	
	/** The continue button *. */
	USER_LOGIN_CONTINUE_BUTTON(By.xpath("//button[@class='ac-btn ac-primary ac-block ']"), "The admin login continue button"),

	/** The Adding new Admin email *. */
	USER_LOGIN_PHONE_NUMBER(By.xpath("//div//input[@name='mobile_phone']"), "The adding login Mobile-number"),

	/** The admin Login phone number *. */
	USER_LOGIN_FIRST_NAME(By.xpath("//div//input[@name='first_name']"), "The adding login First-name"),

	/** The admin Login Last-name *. */
	USER_LOGIN_LAST_NAME(By.xpath("//div//input[@name='last_name']"), "The adding Last-name"),

	/** The admin login confirm *. */
	USER_LOGIN_CONFIRM(By.xpath("//div//button[@type='submit']"), "The admin login confirm button click"),

	/** The admin added to page done *. */
	USER_ADDED_ON_PAGE(By.xpath("//div[@class='Toastify__toast-body']//div[@class='row']//span[text()='Done!']"), "The admin is added to page is done"),

	/** The admin user edit option. */
	ADMIN_USER_EDIT_OPTION(By.xpath("//div[@class='edit-icon-media']//img[@alt='edit-user-email']"), "The Admin user Edit option click"),

	/** The admin user edit tab. */
	ADMIN_USER_EDIT_TAB(By.xpath("//input[@name='email']"), "The Admin User Edit Tab"),

	/** The user edit save button. */
	USER_EDIT_SAVE_BUTTON(By.xpath("//button[@type='submit' and text()='Save']"), "The User Edit Save button clcik"),

	/** The user edit page close. */
	USER_EDIT_PAGE_CLOSE(By.xpath("//div[@class='card-header--wrp']//img[@alt='close']"), "The User Edit close click"),

	/** The done notify. */
	DONE_NOTIFY(By.xpath("//div[@class='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12']//span[@class='success-mess-txt' and text()='Done!']"), "The User Edit Done is displayed"),

	/** The team management tab. */
	TEAM_MANAGEMENT_TAB(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Team Management']"), "Team Management tab"),

	/** The team management logins add new. */
	TEAM_MANAGEMENT_LOGINS_ADD_NEW(By.xpath("//div//button[text()='Add New']"), "The click the Add new button"),

	/** The profile icon. */
	PROFILE_ICON(By.xpath("//button[@id='dropitems-profile-items']"), "Profile icon"),

	/** My Profile icon. */
	MY_PROFILE_ICON(By.xpath("//div[contains(@class,'drop-items')]//div[@class='dropdown-menu show']//a[@title='My Profile']"), "My Profile option"),


	/** My Profile close option. */
	MY_PROFILE_CLOSE_OPTION(By.xpath("//div[contains(@class,'profile__modal')]//div[@class='mod__close--icon']//img[@alt='close']"), "My Profile close option"),


	/** The profile icon dropdown. */
	PROFILE_ICON_DROPDOWN(By.xpath("//button[@id='dropitems-profile-items']//following-sibling::div[@class='dropdown-menu show']"), "Profile icon dropdown"),

	/** The dropdown logout. */
	DROPDOWN_LOGOUT(By.xpath("//div[@class='dropdown-menu show']//a[text()='Logout']"), "Dropdown logOut"),
    // span[@class='admn-txt ad-name ad-uname']//ancestor::tr[@data-testid='tr']

	/** The current password tab. */
	CURRENT_PASSWORD_TAB(By.xpath("//input[@name='current_password']"), "Current password"),

	/** The new password tab. */
	NEW_PASSWORD_TAB(By.xpath("//input[@name='new_password']"), "New password"),

	/** The conform newpassword tab. */
	CONFORM_NEWPASSWORD_TAB(By.xpath("//input[@name='confirm_password']"), "Conform New password"),

	/** The password saved done. */
	PASSWORD_SAVED_DONE(By.xpath("//div[@class='Toastify__toast-body']//span[text()='Saved']"), "The new password change done"),

	/** The invalid username password. */
	INVALID_USERNAME_PASSWORD(By.xpath("//span[text()='Invalid Email Address or Password']"), "The invalid username and password id diplayed"),

	/** The password page close. */
	PASSWORD_PAGE_CLOSE(By.xpath("//img[@alt='close']"), "Close the password page"),

	/** The save button. */
	PASSWORD_SAVE_BUTTON(By.xpath("//button[contains(@class,'ac-btn ac-primary ac') and text()='Save']"), "Save Button");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new admin user page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private AdminUserPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new admin user page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private AdminUserPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}
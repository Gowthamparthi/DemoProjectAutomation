package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum DirectoryListingsSpecialHoursEnum.
 */
public enum DirectoryListingsSpecialHoursEnum {

	/** The page load. */
	PAGE_LOAD(
	        By.xpath("//div[@class='modal-content']//div//div[@class='card-bg bh-hours']//div//h5[text()='Special Hours']//parent::div//parent::div"),
	        "Page load"),

	/** The add special hours button. */
	ADD_SPECIAL_HOURS_BUTTON(By.xpath("//div[@class='modal-body']//div[@class='section-footer ml-auto']//button[text()='Add Special Hours']"), "Add special hours"),

	/** The save button. */
	SAVE_BUTTON(By.xpath("//div[@class='modal-body']//div[contains(@class,'section-footer')]//button[text()='Save']"), "Save button"),

	/** The close button. */
	CLOSE_BUTTON(By.xpath("//div[@class='modal-content']//img[@class='close-icon']"), "Close button"),

	/** The time holder. */
	TIME_HOLDER(By.xpath("//div[@class='modal-body']//div[@class='time-holder-row']//div[@class='day-box date-only--picker']//following-sibling::select[@class='business-hr-dropdown cur-pointer']"), "Time holder"),

	/** The operation hours dropdown. */
	OPERATION_HOURS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='time-holder-row']//select"), "Operation hours dropdown"),

	/** The start time. */
	START_TIME(By.xpath("//div[@class='modal-body']//div[@class='time-holder-row']//div[@class='time-section']//div[@class='time-label'][1]"), "Start time"),

	/** The end time. */
	END_TIME(By.xpath("//div[@class='modal-body']//div[@class='time-holder-row']//div[@class='time-section']//div[@class='time-label'][2]"), "End time"),

	/** The remove button. */
	REMOVE_BUTTON(By.xpath("//div[@class='modal-body']//div[@class='dfa']//div[@class='action-btn cur-pointer']//img[@alt='remove']"), "Remove button");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new directory listings special hours enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private DirectoryListingsSpecialHoursEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new directory listings special hours enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private DirectoryListingsSpecialHoursEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

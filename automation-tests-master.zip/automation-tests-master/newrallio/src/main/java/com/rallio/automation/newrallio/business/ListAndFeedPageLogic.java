package com.rallio.automation.newrallio.business;

import com.rallio.automation.core.manager.*;
import com.rallio.automation.newrallio.enums.*;
import com.rallio.automation.newrallio.pages.*;
import org.openqa.selenium.support.*;
import org.testng.*;

public class ListAndFeedPageLogic {

    private static ListAndFeedPageLogic listAndFeedPageLogic;

    private static ListsPage listsPage = PageFactory.initElements(DriverManager.getDriver(), ListsPage.class);

    public final static ListAndFeedPageLogic createInstance() {

        if (listAndFeedPageLogic == null) {
            listAndFeedPageLogic = new ListAndFeedPageLogic();
        }
        return listAndFeedPageLogic;
    }

    public void creatListByUsingAutomateContentScheduler(String listName,String switchSource,String listLocation,String tag){

        listsPage.clickListsPageElement(ListsPageEnum.CREATE_LIST_BUTTON);
        Assert.assertTrue(listsPage.isDisplayed(ListsPageEnum.CREATE_LIST_DETAILVIEW_NAME_OF_LIST, ListsPageEnum.CREATE_LIST_DETAILVIEW_SELECT_TYPE_DROPDOWN));
        listsPage.validateCreateListAndSelectAutomateContentScheduler(listName,switchSource,listLocation, tag);
    }

    public void deleteCreatedWTHList(String listName) {
        listsPage.WTHdeleteList(listName);
    }

        public String getRandomListName(){
        return listsPage.getRandomListName();
    }

}

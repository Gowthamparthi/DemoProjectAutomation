package com.rallio.automation.newrallio.business;

import com.rallio.automation.common.enums.*;
import com.rallio.automation.common.util.*;
import com.rallio.automation.core.manager.*;
import com.rallio.automation.newrallio.enums.*;
import com.rallio.automation.newrallio.pages.*;
import org.openqa.selenium.support.*;
import org.testng.*;

import java.util.*;

public class ContentPostPageLogic {

    private static ContentPostPageLogic contentPostPageLogic = null;

    private static ContentTabPostsPage contentTabPostsPage = PageFactory.initElements(DriverManager.getDriver(), ContentTabPostsPage.class);

    private static PostDetailedViewPage postDetailedViewPage = PageFactory.initElements(DriverManager.getDriver(), PostDetailedViewPage.class);

    private ContentPostPageLogic() {

    }

    /**
     * Creates the instance.
     *
     * @return the ContentCreatorPage
     */
    public final static ContentPostPageLogic createInstance() {

        if (contentPostPageLogic == null) {
            contentPostPageLogic = new ContentPostPageLogic();
        }
        return contentPostPageLogic;
    }

    public PostDetailedViewPage validatePublishingHistoryPostPublished(String postName, String status) {

        LogUtil.log("validate Publishing History Post Published",LogLevel.LOW);
        contentTabPostsPage.navigateToPostDetailedView(postName);
        postDetailedViewPage.validatePublishingPostHistroyStatus();
        postDetailedViewPage.isAllElementDisplayed(PostDetailedViewPageEnum.PUBLISHING_HISTORY_POST_STATUS_FIELD, status);
        return  postDetailedViewPage;
    }

    public void validatePostWithLocalizeContent(String postName, List<String> rallioProfileInput){

        LogUtil.log("validate Publishing History Post Published",LogLevel.LOW);
        contentTabPostsPage.navigateToPostDetailedView(postName);
        postDetailedViewPage.validateLocalizePostDetailView(postName,rallioProfileInput);

    }

    public void validatePublishedHistoryGreenStatus(String postName,String postStatus){

        LogUtil.log("validate Publishing History Green Status",LogLevel.LOW);
        contentTabPostsPage.navigateToPostDetailedView(postName);
        postDetailedViewPage.validatePublishedGreenStatusPlatform(postStatus);
    }

    public void validatePostDetailviewPublishHistoryStatus(String postName, String postStatus, PostDetailedViewPageEnum... postDetailedViewPageEnum){

        LogUtil.log("validate PostDetailview PublishHistory Status",LogLevel.LOW);
        contentTabPostsPage.navigateToPostDetailedView(postName);
        postDetailedViewPage.validatePublishHistoryStatus(postDetailedViewPageEnum[0],postDetailedViewPageEnum[1],postStatus);
    }

    public PostDetailedViewPage navigatePublishHistoryPlatform(PostDetailedViewPageEnum postDetailedViewPageEnum,String value,String Status,String postName) {

        LogUtil.log("Publishing History Validation",LogLevel.LOW);
        contentTabPostsPage.navigateToPostDetailedView(postName);
        postDetailedViewPage.validatePublishedGreenStatusPlatform(Status);
        postDetailedViewPage.moveToElement(postDetailedViewPageEnum, value);
        postDetailedViewPage.clickPostDetailedViewPageElement(postDetailedViewPageEnum, value);
        return  postDetailedViewPage;
    }

    public boolean postAwaitingApprovaltoApprove(String postName){

        LogUtil.log("Post Awaiting Approval to Approve the Post",LogLevel.LOW);
        contentTabPostsPage.clickContentTabPostsPageElement(ContentTabPostsPageEnum.AWAITING_APPROVAL_LOCATIONCONTENT_FILTER);
        contentTabPostsPage.navigateToPostDetailedView(postName);
        postDetailedViewPage.moveToElement(PostDetailedViewPageEnum.APPROVE_BUTTON);
        postDetailedViewPage.clickPostDetailedViewPageElement(PostDetailedViewPageEnum.APPROVE_BUTTON);
        boolean isDisplayed =contentTabPostsPage.isDisplayed(ContentTabPostsPageEnum.POST_DETAILEDVIEW_APPROVED_STATUS);
        return isDisplayed;
    }


}

package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum AnalyticsTabPageAnalyticsEnum.
 */
public enum AnalyticsTabPageAnalyticsEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//li[@class='ripple active']//span[text()='Page']//following::section[@class='item-g filter ra-filter-sec anlFilter']//ancestor::div//div[@class='g-centre']//div[contains(@class,'profile-an-container leaderboard-an-container')]"), "Page load"),

	PAGE_GRAPH(By.xpath(
			"//main//div[contains(@class,'page')]//div[@class='pa-card']//*[contains(@class,'highcharts-xaxis-labels')]"),
			"PAGE GRAPH"),
	
	/** The analytics tab. */
	ANALYTICS_TAB(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Analytics']"), "Analytics tab"),

	/** The analytics tab page analytics. */
	ANALYTICS_TAB_PAGE_ANALYTICS(By.xpath(
			"//div[contains(@class,'sub-nav-tabs animate')]//ul//li//span[@class='sub-nav-item-txt' and contains(text(),'Page')]"),
			"Analytics tab PageAnalytics"),

	/** The no data to show. */
	NO_DATA_TO_SHOW(By.xpath(
			"//div[@class='pa-stats']//div[contains(@class,'no-data nd-text-only')]//span[text()='No data to show']"),
			"No data to show"),
	
	TILE_NO_DATA_TO_SHOW(By.xpath(
			"//span[contains(text(),'Button Clicks')]//parent::div[@class='card-content-top']//following-sibling::div[contains(@class,'stats rcharts')]//span"),
			"TILE_NO_DATA_TO_SHOW"),
	
	/** The last post date. */
	LAST_POST_DATE(By
			.xpath("//div[contains(@class,'list-item')][last()]//div//div//div[contains(@class,'lvt-brief')]//span[2]"),
			"Last Post date in the list"),

	/** The profile views card. */
	// Card Section
	PROFILE_VIEWS_CARD(By.xpath("//div[contains(@class,'global-stats-section')]//span[contains(@class,'stats-title-text') and text()='Profile Views']"),
			"Profile-Views Card"),

	/** The profile views selected indigating arrow. */
	PROFILE_VIEWS_SELECTED_INDIGATING_ARROW(By.xpath("//img[@class='an-chart--indicator profile_views']"),
			"Profile-Views tile Selected Indigating Arrow"),

	/** The profile views count. */
	PROFILE_VIEWS_COUNT(By
			.xpath("//span[contains(text(),'Profile Views')]//parent::div[@class='card-content-top']//div//span//div"),
			"Profile-Views Count"),

	/** The profile views delta value. */
	PROFILE_VIEWS_DELTA_VALUE(By.xpath(
			"//span[contains(text(),'Profile Views')]//parent::div//div//img//following-sibling::span[@class='delta-small-text']"),
			"Profile-Views Delta Value"),

	/** The delta red symbol profile views. */
	PROFILE_VIEWS_DELTA_RED_SYMBOL_TOTALCOUNT(By.xpath(
			"//span[contains(text(),'Profile Views')]//parent::div[@class='card-content-top']//div//img[contains(@src,'rating-down-red.svg')]"),
			"Delta Red symbol"),

	/** The delta green symbol profile views. */
	PROFILE_VIEWS_DELTA_GREEN_SYMBOL_TOTALCOUNT(By.xpath(
			"//span[contains(text(),'Profile Views')]//parent::div[@class='card-content-top']//div//img[contains(@src,'rating-down-green.svg')]"),
			"Delta Green Symbol"),

	/** The delta red symbol profile views. */
	PROFILE_VIEWS_DELTA_RED_SYMBOL_RANKCOUNT(By.xpath(
			"//span[contains(text(),'Profile Views')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div//img[contains(@src,'Red')]"),
			"Profile Views Delta Red symbol of rank value"),

	/** The delta green symbol profile views. */
	PROFILE_VIEWS_DELTA_GREEN_SYMBOL_RANKCOUNT(By.xpath(
			"//span[contains(text(),'Profile Views')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div//img[contains(@src,'green')]"),
			"Profile Views Delta Green Symbol of Rank Value"),

	/** The profile views delta grey symbol rankcount. */
	PROFILE_VIEWS_DELTA_GREY_SYMBOL_RANKCOUNT(By.xpath(
			"//span[contains(text(),'Profile Views')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div//img[contains(@src,'grey')]"),
			"Profile Views Delta Grey Symbol of Rank Value"),

	/** The profile view brand average. */
	PROFILE_VIEW_BRAND_AVERAGE(By.xpath(
			"//span[contains(text(),'Profile Views')]//parent::div//div//img//parent::div//following-sibling::div//span[contains(text(),'Brand Average')]"),
			"Profile-Views Brand Average"),

	/** The profile view brand average value. */
	PROFILE_VIEW_BRAND_AVERAGE_VALUE(By.xpath(
			"//span[contains(text(),'Profile Views')]//parent::div//div//img//parent::div//following-sibling::div//span[contains(text(),'Brand Average')]//following-sibling::span[text()]"),
			"Profile-Views Brand Average Value"),

	/** The profile view rank value. */
	PROFILE_VIEW_RANK_VALUE(By.xpath(
			"//span[contains(text(),'Profile Views')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div[@class='rank-value']"),
			"Profile-Views Rank Value"),

	/** The profile view ranking delta value. */
	PROFILE_VIEW_RANKING_DELTA_VALUE(By.xpath(
			"//span[contains(text(),'Profile Views')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div[@class='delta-wrp']//span"),
			"Profile-Views Delta Value"),

	/** The profile view chart representation. */
	PROFILE_VIEW_CHART_REPRESENTATION(By.xpath(
			"//span[contains(text(),'Profile Views')]//parent::div[@class='card-content-top']//following-sibling::div[contains(@class,'stats rcharts')]//div//div[@class='highcharts-container ']"),
			"Profile-Views Chart Representation"),
	
	PROFILE_VIEWS_CHART_NO_DATA(By.xpath(
			"//span[contains(text(),'Profile Views')]//parent::div[@class='card-content-top']//following-sibling::div//*[text()='No data to show']"),
			"PROFILE_VIEWS_CHART_NO_DATA"),

	/** The website clicks card. */
	WEBSITE_CLICKS_CARD(By.xpath("//div[contains(@class,'global-stats-section')]//span[contains(@class,'stats-title-text') and text()='Website Clicks']"),
			"Website_Clicks Card"),

	/** The website clicks selected indigating arrow. */
	WEBSITE_CLICKS_SELECTED_INDIGATING_ARROW(By.xpath("//img[@class='an-chart--indicator website_visits']"),
			"Website Visits tile Selected Indigating Arrow"),

	/** The website clicks count. */
	WEBSITE_CLICKS_COUNT(By.xpath(
			"//span[contains(text(),'Website Clicks')]//parent::div[@class='card-content-top']//div//span//div"),
			"Website_Clicks Count"),

	/** The website clicks delta value. */
	WEBSITE_CLICKS_DELTA_VALUE(By.xpath(
			"//span[contains(text(),'Website Clicks')]//parent::div//div//img//following-sibling::span[@class='delta-small-text']"),
			"Website_Clicks Delta Value"),

	/** The website clicks brand average. */
	WEBSITE_CLICKS_BRAND_AVERAGE(By.xpath(
			"//span[contains(text(),'Website Clicks')]//parent::div//div//img//parent::div//following-sibling::div//span[contains(text(),'Brand Average')]"),
			"Website_Clicks Brand Average"),

	/** The website clicks brand average value. */
	WEBSITE_CLICKS_BRAND_AVERAGE_VALUE(By.xpath(
			"//span[contains(text(),'Website Clicks')]//parent::div//div//img//parent::div//following-sibling::div//span[contains(text(),'Brand Average')]//following-sibling::span[text()]"),
			"Website_Clicks Brand Average value"),

	/** The website clicks rank value. */
	WEBSITE_CLICKS_RANK_VALUE(By.xpath(
			"//span[contains(text(),'Website Clicks')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div[@class='rank-value']"),
			"Website_Clicks Rank Value"),

	/** The website clicks ranking delta value. */
	WEBSITE_CLICKS_RANKING_DELTA_VALUE(By.xpath(
			"//span[contains(text(),'Website Clicks')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div[@class='delta-wrp']//span"),
			"Website_Clicks Delta Value"),

	/** The website clicks chart representation. */
	WEBSITE_CLICKS_CHART_REPRESENTATION(By.xpath(
			"//span[contains(text(),'Website Clicks')]//parent::div[@class='card-content-top']//following-sibling::div[contains(@class,'stats rcharts')]//div//div[@class='highcharts-container ']"),
			"Website_Clicks Chart Representation"),
	
	WEBSITE_CLICKS_CHART_NO_DATA(By.xpath(
			"//span[contains(text(),'Website Clicks')]//parent::div[@class='card-content-top']//following-sibling::div//*[text()='No data to show']"),
			"Website_Clicks Chart Representation"),

	/** The delta red symbol profile views. */
	WEBSITE_CLICKS_DELTA_RED_SYMBOL_TOTALCOUNT(By.xpath(
			"//span[contains(text(),'Website Clicks')]//parent::div[@class='card-content-top']//div//img[contains(@src,'rating-down-red.svg')]"),
			"Website Clicks Delta Red symbol"),

	/** The delta green symbol profile views. */
	WEBSITE_CLICKS_DELTA_GREEN_SYMBOL_TOTALCOUNT(By.xpath(
			"//span[contains(text(),'Website Clicks')]//parent::div[@class='card-content-top']//div//img[contains(@src,'rating-down-green.svg')]"),
			"Website Clicks Delta Green Symbol"),

	/** The delta red symbol profile views. */
	WEBSITE_CLICKS_DELTA_RED_SYMBOL_RANKCOUNT(By.xpath(
			"//span[contains(text(),'Website Clicks')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div//img[contains(@src,'Red')]"),
			"Website Clicks Delta Red symbol of rank value"),

	/** The delta green symbol profile views. */
	WEBSITE_CLICKS_DELTA_GREEN_SYMBOL_RANKCOUNT(By.xpath(
			"//span[contains(text(),'Website Clicks')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div//img[contains(@src,'green')]"),
			"website Clicks Delta Green Symbol of Rank value"),

	/** The website clicks delta grey symbol rankcount. */
	WEBSITE_CLICKS_DELTA_GREY_SYMBOL_RANKCOUNT(By.xpath(
			"//span[contains(text(),'Website Clicks')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div//img[contains(@src,'grey')]"),
			"Website Clicks Delta Grey Symbol of Rank Value"),

	/** The phone calls card. */
	PHONE_CALLS_CARD(By.xpath("//div[contains(@class,'global-stats-section')]//span[contains(@class,'stats-title-text') and text()='Phone Calls']"),
			"Phone call Card"),

	/** The phone calls selected indigating arrow. */
	PHONE_CALLS_SELECTED_INDIGATING_ARROW(By.xpath("//img[@class='an-chart--indicator phone_calls']"),
			"Phone Calls tile Selected Indigating Arrow"),

	/** The phone calls count. */
	PHONE_CALLS_COUNT(
			By.xpath("//span[contains(text(),'Phone Calls')]//parent::div[@class='card-content-top']//div//span//div"),
			"Phone_Call Count"),

	/** The phone calls delta value. */
	PHONE_CALLS_DELTA_VALUE(By.xpath(
			"//span[contains(text(),'Phone Calls')]//parent::div//div//img//following-sibling::span[@class='delta-small-text']"),
			"Phone_Call delta value"),

	/** The phone calls brand average. */
	PHONE_CALLS_BRAND_AVERAGE(By.xpath(
			"//span[contains(text(),'Phone Calls')]//parent::div//div//img//parent::div//following-sibling::div//span[contains(text(),'Brand Average')]"),
			"Phone_Call Brand Average"),

	/** The phone calls brand average value. */
	PHONE_CALLS_BRAND_AVERAGE_VALUE(By.xpath(
			"//span[contains(text(),'Phone Calls')]//parent::div//div//img//parent::div//following-sibling::div//span[contains(text(),'Brand Average')]//following-sibling::span[text()]"),
			"Phone_Call Brand Average Value"),

	/** The phone calls rank value. */
	PHONE_CALLS_RANK_VALUE(By.xpath(
			"//span[contains(text(),'Phone Calls')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div[@class='rank-value']"),
			"Phone_Call Rank Value"),

	/** The phone calls ranking delta value. */
	PHONE_CALLS_RANKING_DELTA_VALUE(By.xpath(
			"//span[contains(text(),'Phone Calls')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div[@class='delta-wrp']//span"),
			"Phone_Call Delta Value"),

	/** The phone calls chart representation. */
	PHONE_CALLS_CHART_REPRESENTATION(By.xpath(
			"//span[contains(text(),'Phone Calls')]//parent::div[@class='card-content-top']//following-sibling::div[contains(@class,'stats rcharts')]//div//div[@class='highcharts-container ']"),
			"Phone_Call chart Representation"),
	
	PHONE_CALLS_CHART_NO_DATA(By.xpath(
			"//span[contains(text(),'Phone Calls')]//parent::div[@class='card-content-top']//following-sibling::div//*[text()='No data to show']"),
			"PHONE_CALLS_CHART_NO_DATA"),

	/** The phone calls delta red symbol totalcount. */
	PHONE_CALLS_DELTA_RED_SYMBOL_TOTALCOUNT(By.xpath(
			"//span[contains(text(),'Phone Calls')]//parent::div[@class='card-content-top']//div//img[contains(@src,'rating-down-red.svg')]"),
			"Phone Calls Delta Red symbol"),

	/** The delta green symbol profile views. */
	PHONE_CALLS_DELTA_GREEN_SYMBOL_TOTALCOUNT(By.xpath(
			"//span[contains(text(),'Phone Calls')]//parent::div[@class='card-content-top']//div//img[contains(@src,'rating-down-green.svg')]"),
			"Phone Calls Delta Green Symbol"),

	/** The delta red symbol profile views. */
	PHONE_CALLS_DELTA_RED_SYMBOL_RANKCOUNT(By.xpath(
			"//span[contains(text(),'Phone Calls')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div//img[contains(@src,'red')]"),
			"Phone Calls Delta Red symbol of rank value"),

	/** The delta green symbol profile views. */
	PHONE_CALLS_DELTA_GREEN_SYMBOL_RANKCOUNT(By.xpath(
			"//span[contains(text(),'Phone Calls')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div//img[contains(@src,'green')]"),
			"Phone Calls Delta Green Symbol of Rank value"),

	/** The phone calls delta grey symbol rankcount. */
	PHONE_CALLS_DELTA_GREY_SYMBOL_RANKCOUNT(By.xpath(
			"//span[contains(text(),'Phone Calls')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div//img[contains(@src,'grey')]"),
			"Phone Calls Delta Grey Symbol of Rank Value"),

	/** The directions requests card. */
	DIRECTIONS_REQUESTS_CARD(By.xpath("//div[contains(@class,'global-stats-section')]//span[contains(@class,'stats-title-text') and text()='Direction Requests']"),
			"Direction requests Card"),

	/** The directions requests selected indigating arrow. */
	DIRECTIONS_REQUESTS_SELECTED_INDIGATING_ARROW(By.xpath("//img[@class='an-chart--indicator direction_requests']"),
			"Direction Request tile Selected Indigating Arrow"),

	/** The directions requests count. */
	DIRECTIONS_REQUESTS_COUNT(By.xpath(
			"//span[contains(text(),'Direction Requests')]//parent::div[@class='card-content-top']//div//span//div"),
			"Direction_Requests Count"),

	/** The directions requests delta value. */
	DIRECTIONS_REQUESTS_DELTA_VALUE(By.xpath(
			"//span[contains(text(),'Direction Requests')]//parent::div//div//img//following-sibling::span[@class='delta-small-text']"),
			"Direction_Requests Delta value"),

	/** The directions requests brand average. */
	DIRECTIONS_REQUESTS_BRAND_AVERAGE(By.xpath(
			"//span[contains(text(),'Direction Requests')]//parent::div//div//img//parent::div//following-sibling::div//span[contains(text(),'Brand Average')]"),
			"Direction_Requests Brand Average"),

	/** The directions requests brand average value. */
	DIRECTIONS_REQUESTS_BRAND_AVERAGE_VALUE(By.xpath(
			"//span[contains(text(),'Direction Requests')]//parent::div//div//img//parent::div//following-sibling::div//span[contains(text(),'Brand Average')]//following-sibling::span[text()]"),
			"Direction_Requests Brand Average Value"),

	/** The directions requests rank value. */
	DIRECTIONS_REQUESTS_RANK_VALUE(By.xpath(
			"//span[contains(text(),'Direction Requests')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div[@class='rank-value']"),
			"Direction_Requests Rank Value"),

	/** The directions requests ranking delta value. */
	DIRECTIONS_REQUESTS_RANKING_DELTA_VALUE(By.xpath(
			"//span[contains(text(),'Direction Requests')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div[@class='delta-wrp']//span"),
			"Direction_Requests Ranking DeltaValue"),

	/** The directions requests delta red symbol totalcount. */
	DIRECTIONS_REQUESTS_DELTA_RED_SYMBOL_TOTALCOUNT(By.xpath(
			"//span[contains(text(),'Direction Requests')]//parent::div[@class='card-content-top']//div//img[contains(@src,'rating-down-red.svg')]"),
			"Direction_Requests Delta Red symbol of Total value"),

	/** The delta green symbol profile views. */
	DIRECTIONS_REQUESTS_DELTA_GREEN_SYMBOL_TOTALCOUNT(By.xpath(
			"//span[contains(text(),'Direction Requests')]//parent::div[@class='card-content-top']//div//img[contains(@src,'rating-down-green.svg')]"),
			"Direction_Requests Delta Green Symbol of Total value"),

	/** The directions requests delta grey symbol rankcount. */
	DIRECTIONS_REQUESTS_DELTA_GREY_SYMBOL_RANKCOUNT(By.xpath(
			"//span[contains(text(),'Direction Requests')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div//img[contains(@src,'grey')]"),
			"Direction Requests Delta Grey Symbol of Rank Value"),

	/** The delta red symbol profile views. */
	DIRECTIONS_REQUESTS_DELTA_RED_SYMBOL_RANKCOUNT(By.xpath(
			"//span[contains(text(),'Direction Requests')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div//img[contains(@src,'red')]"),
			"Direction_Requests Delta Red symbol of Rank value"),

	/** The delta green symbol profile views. */
	DIRECTIONS_REQUESTS_DELTA_GREEN_SYMBOL_RANKCOUNT(By.xpath(
			"//span[contains(text(),'Direction Requests')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div//img[contains(@src,'green')]"),
			"Direction_Requests Delta Green Symbol of Rank value"),

	/** The directions requests chart representation. */
	DIRECTIONS_REQUESTS_CHART_REPRESENTATION(By.xpath(
			"//span[contains(text(),'Direction Requests')]//parent::div[@class='card-content-top']//following-sibling::div[contains(@class,'stats rcharts')]//div//div[@class='highcharts-container ']"),
			"Direction_Requests chart Representation"),
	
	DIRECTIONS_REQUESTS_CHART_NO_DATA(By.xpath(
			"//span[contains(text(),'Direction Requests')]//parent::div[@class='card-content-top']//following-sibling::div//*[text()='No data to show']"),
			"DIRECTIONS_REQUESTS_CHART_NO_DATA"),

	/** The button clicks card. */
	BUTTON_CLICKS_CARD(By.xpath("//div[contains(@class,'global-stats-section')]//span[contains(@class,'stats-title-text') and text()='Button Clicks']"),
			"Button_Click card"),

	/** The button clicks selected indigating arrow. */
	BUTTON_CLICKS_SELECTED_INDIGATING_ARROW(By.xpath("//img[@class='an-chart--indicator button_clicks']"),
			"Button Clicks tile Selected Indigating Arrow"),

	/** The button clicks count. */
	BUTTON_CLICKS_COUNT(By
			.xpath("//span[contains(text(),'Button Clicks')]//parent::div[@class='card-content-top']//div//span//div"),
			"Button_click_Count"),

	/** The button clicks delta value. */
	BUTTON_CLICKS_DELTA_VALUE(By.xpath(
			"//span[contains(text(),'Button Clicks')]//parent::div//div//img//following-sibling::span[@class='delta-small-text']"),
			"Button_click_DeltaValue"),

	/** The button clicks brand average. */
	BUTTON_CLICKS_BRAND_AVERAGE(By.xpath(
			"//span[contains(text(),'Button Clicks')]//parent::div//div//img//parent::div//following-sibling::div//span[contains(text(),'Brand Average')]"),
			"Button_click_BrandAverage"),

	/** The button clicks brand average value. */
	BUTTON_CLICKS_BRAND_AVERAGE_VALUE(By.xpath(
			"//span[contains(text(),'Button Clicks')]//parent::div//div//img//parent::div//following-sibling::div//span[contains(text(),'Brand Average')]//following-sibling::span[text()]"),
			"Button_click_Brand_AverageValue"),

	/** The button clicks rank value. */
	BUTTON_CLICKS_RANK_VALUE(By.xpath(
			"//span[contains(text(),'Button Clicks')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div[@class='rank-value']"),
			"Button_click_RankValue"),

	/** The button clicks ranking delta value. */
	BUTTON_CLICKS_RANKING_DELTA_VALUE(By.xpath(
			"//span[contains(text(),'Button Clicks')]//parent::div[@class='card-content-top']//following-sibling::div[@class='ranking']//div[@class='rank-value__wrp']//div[@class='delta-wrp']//span"),
			"Button_click_Ranking DeltaValue"),

	/** The button clicks chart representation. */
	BUTTON_CLICKS_CHART_REPRESENTATION(By.xpath(
			"//span[contains(text(),'Button Clicks')]//parent::div[@class='card-content-top']//following-sibling::div[contains(@class,'stats rcharts')]//div//div[@class='highcharts-container ']"),
			"Button_click Chart Representation"),
	
	BUTTON_CLICKS_CHART_NO_DATA(By.xpath(
			"//span[contains(text(),'Button Clicks')]//parent::div[@class='card-content-top']//following-sibling::div//*[text()='No data to show']"),
			"BUTTON_CLICKS_CHART_NO_DATA"),

	/** The line chart. */
	// Table View Elements
	LINE_CHART(By.xpath("//div[@class='pa-card']"), "line Chart"),

	/** The line chart x axis labels. */
	LINE_CHART_X_AXIS_LABELS(
			By.xpath("//*[@class='highcharts-root']//*[@class='highcharts-axis-labels highcharts-xaxis-labels']//*"),
			"Line Chart X-axis labels"),

	/** The line chart brand average value. */
	LINE_CHART_BRAND_AVERAGE_CURVE(
			By.xpath("//*[contains(@class,'highcharts-series highcharts-series')]"),
			"line Chart Brand Average line"),

	/** The line chart brand average button. */
	LINE_CHART_BRAND_AVERAGE_BUTTON(By.xpath(
			"//*[@class='highcharts-legend-item highcharts-spline-series highcharts-color-undefined highcharts-series-1']//*[contains(text(),'Brand Average')]"),
			"line Chart Brand Average Button"),

	/** The table profiles column. */
	TABLE_PROFILES_COLUMN(By.xpath("//table//thead//tr//th//span[contains(text(),'Profiles')]"), "Table_Profiles Column"),

	/** The table profile view column. */
	TABLE_PROFILE_VIEWS_COLUMN(By.xpath("//table//thead//tr//th//span[contains(text(),'Profile Views')]"),
			"Table_ProfileViews Column"),

	/** The table website clicks column. */
	TABLE_WEBSITE_VISITS_COLUMN(By.xpath("//table//thead//tr//th//span[contains(text(),'Website Visits')]"),
			"Table_WebsiteVisits_Column"),

	/** The table phone calls column. */
	TABLE_PHONE_CALLS_COLUMN(By.xpath("//table//thead//tr//th//span[contains(text(),'Phone Calls')]"),
			"Table_PhoneCalls_Column"),

	/** The table direction requests column. */
	TABLE_DIRECTION_REQUESTS_COLUMN(By.xpath("//table//thead//tr//th//span[contains(text(),'Direction Requests')]"),
			"Table_DirectionRequests_column"),

	/** The table button clicks column. */
	TABLE_BUTTON_CLICKS_COLUMN(By.xpath("//table//thead//tr//th//span[contains(text(),'Button Clicks')]"),
			"Table_ButtonClicks_column"),
	/** The table. */
	TABLE(By.xpath("//div[@class='profile-tbl-wrp resuseTable  profile__tbl--page']"), "Table"),

	/** The table data. */
	TABLE_DATA(By.xpath("//div[contains(@class,'profile-tbl-wrp')]//tbody"), "Table Data"),

	// This is a table of a tile which is selected(Like Profile views, Website
	// Visits,Phone Calls,Direction Requests,Button Clicks)
	/** The table of tile first column. */
	TABLE_OF_TILE_FIRST_COLUMN(By.xpath("//div[contains(@class,'profile-tbl-wrp')]//thead//tr[1]//th[1]"),
			"Table of Tile First Column Day1"),

	PROFILES_TOTALS_TABLE_DATA(By.xpath("//td[text()='Totals']//parent::tr//td//div[@class='tbl-delta--wrp']//span[@class='value1']"),"PROFILES_TOTALS_TABLE_DATA"),
	
	PROFILE_GOOGLE_TABLE_DATA(By.xpath("//img[contains(@src,'google')]//parent::div//parent::div[@class='an-social-icon-title']//parent::td//following-sibling::td//div[@class='tbl-delta--wrp']//span[@class='value1']"),"PROFILE_GOOGLE_TABLE_DATA"),
	
	PROFILE_FACEBOOK_TABLE_DATE(By.xpath("//img[contains(@src,'fb-lv.svg')]//parent::div//parent::div[@class='an-social-icon-title']//parent::td//following-sibling::td//div[@class='tbl-delta--wrp']//span[@class='value1']"),"PROFILE_Facebook_TABLE_DATA"),
	
	/** The table of tile second column. */
	TABLE_OF_TILE_SECOND_COLUMN(By.xpath("//div[contains(@class,'profile-tbl-wrp')]//thead//tr[1]//th[2]"),
			"Table of Tile Second Column Day2"),

	/** The table of tile third column. */
	TABLE_OF_TILE_THIRD_COLUMN(By.xpath("//div[@class='profile-tbl-wrp ']//thead//tr[1]//th[3]"),
			"Table of Tile Third Column Day3"),

	/** The table of tile fourth column. */
	TABLE_OF_TILE_FOURTH_COLUMN(By.xpath("//div[@class='profile-tbl-wrp ']//thead//tr[1]//th[4]"),
			"Table of Tile Fourth Column Day4"),

	/** The table of tile fifth column. */
	TABLE_OF_TILE_FIFTH_COLUMN(By.xpath("//div[@class='profile-tbl-wrp ']//thead//tr[1]//th[5]"),
			"Table of Tile Fifth Column Day5"),

	/** The table of tile sixth column. */
	TABLE_OF_TILE_SIXTH_COLUMN(By.xpath("//div[@class='profile-tbl-wrp ']//thead//tr[1]//th[6]"),
			"Table of Tile Sixth Column Day6"),

	/** The table of tile seventh column. */
	TABLE_OF_TILE_SEVENTH_COLUMN(By.xpath("//div[@class='profile-tbl-wrp ']//thead//tr[1]//th[7]"),
			"Table of Tile Seventh Column Day7"),

	/** The total profile views. */
	// Total Profile Views Contents
	DONUT_CHART(By.xpath(
			"//*[@class='highcharts-series-group']//*[@class='highcharts-series highcharts-series-0 highcharts-pie-series highcharts-tracker']"),
			"Total Profile Views Pie-Chart"),

	/** The total profile views. */
	TOTAL_PROFILE_VIEWS(By.xpath("//div[@class='tf-col-holder card-body']"), "Total Profile Views"),

	/** The total profile views count. */
	TABLE_TOTAL_PROFILE_VIEWS_COUNT(By.xpath("//span[text()='Profile Views']//ancestor::table//tbody//tr[@class='total ']//td[2]//div//span[@class='value1']"),
			"Total Profile Views Count Value"),

	/** The table total website visits count. */
	TABLE_TOTAL_WEBSITE_VISITS_COUNT(By.xpath("//span[text()='Website Visits']//ancestor::table//tbody//tr[@class='total ']//td[3]//div//span[@class='value1']"),
			"Total Profile Views Count Value"),

	/** The table total phonecall count. */
	TABLE_TOTAL_PHONECALL_COUNT(By.xpath("//span[text()='Phone Calls']//ancestor::table//tbody//tr[@class='total ']//td[4]//div//span[@class='value1']"),
			"Total Profile Views Count Value"),

	/** The table total direction requests count. */
	TABLE_TOTAL_DIRECTION_REQUESTS_COUNT(By.xpath("//span[text()='Direction Requests']//ancestor::table//tbody//tr[@class='total ']//td[5]//div//span[@class='value1']"),
			"Total Profile Views Count Value"),

	/** The table total button clicks count. */
	TABLE_TOTAL_BUTTON_CLICKS_COUNT(By.xpath("//span[text()='Button Clicks']//ancestor::table//tbody//tr[@class='total ']//td[6]//div//span[@class='value1']"),
			"Total Profile Views Count Value"),

	/** The total profile views google icon. */
	TOTAL_PROFILE_VIEWS_FACEBOOK_ICON(
			By.xpath("//div[@class='active-tile list-group-item']//div//div//img[contains(@src,'fb-lv.svg')]"),
			"Total Profile Views Facebook Icon"),

	TOTAL_PROFILE_VIEWS_FACEBOOK_ICON_INACTIVE(
			By.xpath("//div[@class='list-group-item']//div//div//img[contains(@src,'fb-lv.svg')]"),
			"Total Profile Views Facebook Icon INActive"),
	
	/** The total profile views google text. */
	TOTAL_PROFILE_VIEWS_FACEBOOK_TEXT(By.xpath("//span[contains(text(),'Facebook') and @class = 'txt-fb']"),
			"Total Profile Views Facebook Text"),

	TOTAL_PROFILE_VIEWS_FACEBOOK_TEXT_INACTIVE(By.xpath("//div[@class='list-group-item']//span[contains(text(),'Facebook') and @class = 'txt-fb']"),
			"Total Profile Views Facebook Text"),
	
	/** The total profile views count value. */
	TOTAL_PROFILE_VIEWS_FACEBOOK_COUNT_VALUE(By.xpath(
			"//span[contains(text(),'Facebook')]//parent::div[@class='tf-header']//following-sibling::div//span[@class='tf-total-count']"),
			"Total Profile Views Facebook Count Value"),

	/** The total profile views delta value. */
	TOTAL_PROFILE_VIEWS_FACEBOOK_DELTA_VALUE(By.xpath(
			"//span[contains(text(),'Facebook')]//parent::div[@class='tf-header']//following-sibling::div//span[@class='delta-small-text']"),
			"Total Profile Views Facebook Delta Value"),
	
	TOTAL_PROFILE_VIEWS_FACEBOOK_COUNT_VALUE_INACTIVE(By.xpath(
			"//span[contains(text(),'Facebook')]//parent::div[@class='tf-header']//parent::div[@class='list-group-item']//following-sibling::div//span[@class='tf-total-count']"),
			"Total Profile Views Facebook Count Value Inactive"),

	/** The total profile views delta value. */
	TOTAL_PROFILE_VIEWS_FACEBOOK_DELTA_VALUE_INACTIVE(By.xpath(
			"//span[contains(text(),'Facebook')]//parent::div[@class='tf-header']//parent::div[@class='list-group-item']//div//span[@class='delta-small-text']"),
			"Total Profile Views Facebook Delta Value INactive"),

	
	/** The total profile views google icon. */
	TOTAL_PROFILE_VIEWS_GOOGLE_ICON(
			By.xpath("//div[@class='active-tile list-group-item']//div//div//img[contains(@src,'google-lv.svg')]"),
			"Total Profile Views Google Icon"),

	/** The total profile views google text. */
	TOTAL_PROFILE_VIEWS_GOOGLE_TEXT(By.xpath("//span[contains(text(),'Google') and @class = 'txt-li']"),
			"Total Profile Views Google Text"),

	/** The total profile views count value. */
	TOTAL_PROFILE_VIEWS_GOOGLE_COUNT_VALUE(By.xpath(
			"//span[contains(text(),'Google')]//parent::div[@class='tf-header']//following-sibling::div//span[@class='tf-total-count']"),
			"Total Profile Views Google Count Value"),

	/** The total profile views delta value. */
	TOTAL_PROFILE_VIEWS_GOOGLE_DELTA_VALUE(By.xpath(
			"//span[contains(text(),'Google')]//parent::div[@class='tf-header']//following-sibling::div//span[@class='delta-small-text']"),
			"Total Profile Views Google Delta Value"),

	TOTAL_PROFILE_VIWES_GOOGLE_DATA_INACTIVE(By.xpath("//div[@class='list-group-item']//span[contains(text(),'Google')]"),"Total Profile Views"),

	/** The table cell value. */
	TABLE_CELL_VALUE(By.xpath(
			"//tbody//tr[@class='total']//td[%s]//div[@class='tbl-delta--wrp']//span[@class='value1']"),
			"Table Cell Value"),

	/** The download csv. */
	DOWNLOAD_CSV(By.xpath("//span[contains(text(),'Download CSV')]//parent::button"), "Download CSV Button"),

	/** The date range. */
	FROM_DATE(By.xpath("//div[@class='react-datepicker-wrapper']//button//preceding-sibling::input[@placeholder='MM/DD/YYYY']"),
			"From Date"),
	/** The previous month. */
	PREVIOUS_MONTH_PICKER(By.xpath("//button[contains(@class,'datepicker__navigation--previous')]"), "Previous month."),

	/** The next month. */
	NEXT_MONTH_PICKER(By.xpath("//button[contains(@class,'datepicker__navigation--next')]"), "Next month."),

	/** The to date. */
	TO_DATE(By.xpath("//div[@class='react-datepicker__input-container']//input[contains(@placeholder,'Most Recent')]"),
			"To Date"),

	/** The month dropdown. */
	MONTH_DROPDOWN(By.xpath("//select[@class='react-datepicker__month-select']"), "Month drop down"),

	/** The year dropdown. */
	YEAR_DROPDOWN(By.xpath("//select[@class='react-datepicker__year-select']"), "Year drop down."),

	/** The calendar. */
	CALENDAR(By.xpath("//div[@class='react-datepicker__month-container']"), "Calendar"),
	
	/** The double digit calendar day. */
	DOUBLE_DIGIT_CALENDAR_DAY("(//div[contains(@class,'react-datepicker') and text()='%s'])[last()]",
			"Day of the Month"),

	/** The single digit calendar day. */
	SINGLE_DIGIT_CALENDAR_DAY("(//div[contains(@class,'react-datepicker') and text()='%s'])[1]",
			"Day of the Month"),
	
	DAY_OF_THE_MONTH("//div[contains(@class,'react-datepicker') and text()='%s']",
			"Day of the Month"),

	/** The platform. */
	PLATFORM_SECTION(By.xpath("//section[@class='item-g filter ra-filter-sec']//div//h3[contains(text(),'Platform')]"),
			"Platforms"),

	/** The all platform. */
	ALL_PLATFORM(By.xpath("//div[@class='fltr-imc selectsocial']//button//img[contains(@src,'all-platform')]"),
			"All Platform"),

	/** The all platform in active. */
	ALL_PLATFORM_IN_ACTIVE(
			By.xpath("//div[@class='fltr-imc selectsocial']//button//img[contains(@src,'all-platform')]"),
			"All Platform In Active mode"),

	/** The facebook platform. */
	FACEBOOK_PLATFORM(By.xpath("//div[@class='fltr-imc selectsocial']//button//img[contains(@src,'fb-platform.svg')]"),
			"Facebook Platform"),

	/** The facebook platform in active. */
	FACEBOOK_PLATFORM_IN_ACTIVE(
			By.xpath("//div[@class='fltr-imc selectsocial']//button//img[contains(@src,'fb-platform.svg')]"),
			"Facebook Platform In Active mode"),

	/** The table firstrow facebook data. */
	TABLE_FIRSTROW_FACEBOOK_DATA(By.xpath("//tbody//tr[1]//td[1]//div//img[contains(@src,'fb-lv.svg')]"),
			"Table loaded data"),

	/** The twitter platform. */
	TWITTER_PLATFORM(By.xpath("//button[@class='roundedbtn btn btn-link ']/img[contains(@src,'twitter-platform.svg')]"),
			"Twitter Platform"),

	/** The instagram platform. */
	INSTAGRAM_PLATFORM(
			By.xpath("//button[@class='roundedbtn btn btn-link ']/img[contains(@src,'instagram-platform.svg')]"),
			"Instagram Platform"),

	/** The linkedin platform. */
	LINKEDIN_PLATFORM(
			By.xpath("//button[@class='roundedbtn btn btn-link ']/img[contains(@src,'linkedin-platform.svg')]"),
			"LinkedIn Platform"),

	/** The google platform. */
	GOOGLE_PLATFORM(
			By.xpath("//div[@class='fltr-imc selectsocial']//button//img[contains(@src,'google-platform.svg')]"),
			"Google Platform"),

	/** The google platform in active. */
	GOOGLE_PLATFORM_IN_ACTIVE(
			By.xpath("//div[@class='fltr-imc selectsocial']//button//img[contains(@src,'google-platform.svg')]"),
			"Google Platform_In Active"),

	/** The table firstrow google data. */
	TABLE_FIRSTROW_GOOGLE_DATA(By.xpath("//tbody//tr//td[1]//div//img[contains(@src,'google')]"),
			"Table First Row Google data"),

	/** The clear filter button. */
	CLEAR_FILTER_BUTTON(By.xpath("//div[@class='filter-item clear-filter']//div//button//span[text()='Clear Filter']//parent::button"), "Clear_Filter"),
	
	/** The clear filter button disabled. */
	CLEAR_FILTER_BUTTON_DISABLED(By.xpath(
			"//div[@class='filter-item clear-filter']//div[contains(@class,'pointer-events-none')]"),
			"Clear Filter Button Disabled"),

	TABLE_FACEBOOK_PROFILE_VIEWS_COUNT(By.xpath("//table//thead//th//span[text()='Profile Views']//ancestor::div//tbody//td[2]//span[@class='value1']"),"Table Facebook Profile Views Count"),

	/** The table view list. */
	TABLE_DATA_LIST(By.xpath("//table[@class=' responsiveTable']//tbody//tr"), "Table list data"),

	/** TableView list footer. */
	TABLE_FOOTER_ROW(By.xpath("//table[@class='  responsiveTable analytics_platform--page table']//tbody//tr[last()]"), "TableView list footer Row"),

	/** The location selector. */
	LOCATION_SELECTOR(By.xpath("//section//*[text()='Location Selector']//parent::div//span[@class='lcs-name']"), "Location Selecter."),

	/** The location selector open. */
	LOCATION_SELECTOR_OPEN(By.xpath(
			"//div[@class='asm-btn']//parent::div[@class='modal-footer']//preceding-sibling::div[@class='asm-accord']"),
			"Location Selecter Open."),

	/** The location selector hub tab. */
	LOCATION_SELECTOR_HUB_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Hubs']"),
			"Location Selecter Hub tab."),

	/** The location selector hub tab open. */
	LOCATION_SELECTOR_HUB_TAB_OPEN(
			By.xpath("//img[contains(@src,'hubs')]//ancestor::ul"),
			"Location Selecter Hub Tab Open."),
	
	/** The location selector hub tab open. */
	LOCATION_SELECTOR_DROPDOWN_USER("//div//ul[@class='hub-list']//span[contains(text(),\"%s\")]",
			"Location Selecter Dropdown User"),

	/** The location selector location tab. */
	LOCATION_SELECTOR_LOCATION_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Locations']"),
			"Location Selecter Location tab."),

	/** The location selector locationlist tab. */
	LOCATION_SELECTOR_LOCATIONLIST_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Location Lists']"),
			"Location Selecter Location tab."),
	
	/** The location selector locationlist tab open. */
	LOCATION_SELECTOR_LOCATIONLIST_TAB_OPEN(By.xpath("//div[@class='card']//div[contains(@class,'collapse show')]//ul[@class='hub-list']"),
			"Location Selecter Location List tab Open"),

	/** The location selector location tab open. */
	LOCATION_SELECTOR_LOCATION_TAB_OPEN(
			By.xpath("//div[@class='accordion']//div[@class='card']//div[contains(@class,'collapse show')]//ul"),
			"Location Selecter Hub Tab Open"),

	/** The list of hubs. */
	LIST_OF_HUBS(By.xpath(
			"//img[contains(@src,'hub')]//parent::label//span[@class='lcs-name']"),
			"List of Hubs"),

	/** The list of locations. */
	LIST_OF_LOCATIONS(By.xpath(
			"//img[contains(@src,'location')]//parent::label//span[@class='lcs-name']"),
			"List of Locations"),

	/** The list of locationlist. */
	LIST_OF_LOCATIONLIST(By.xpath(
			"//img[contains(@src,'locationLists')]//parent::label//span[@class='lcs-name']"),
			"List of Location list"),

	LOCATOR_SELECTOR_NAME("//span[@class='lcs-name' and contains(@title,'%s')]", "The Location selector Name"),

	// LOCATION_SELECTOR_CHOOSE_HUB(By.xpath("//div[@class='card']//div[@class='collapse
	// show']//ul[@class='hub-list']//li//label//span[text()='']"), "Location
	// Selecter Hub Tab Open."),

	// LOCATION_SELECTOR_ACTIVE_HUB(By.xpath("//div[@class='card']//div[@class='collapse
	// show']//ul[@class='hub-list']//li//label//span[contains(@class,'active') and
	// text()='Alvarado']"), "Location Selecter Hub Tab Open."),

	LOCATION_SELECTOR_ALL_LOCATION_BUTTON(By.xpath("//div[@class='all-locs']//label//input//following-sibling::span[text()='All Locations']"), "All location button"),

	/** The location selector ok button. */
	LOCATION_SELECTOR_OK_BUTTON(By.xpath("//div[@class='asm-btn']//div//button[text()='Ok']"),
			"Location Selecter Ok Button"),

	/** The location selector search tab. */
	LOCATION_SELECTOR_SEARCH_TAB(By.xpath("//div[@class='asm-lf']//input[@placeholder = 'Search']"),
			"Location Selecter Search Tab"),

	/** The location selector cancel button. */
	LOCATION_SELECTOR_CANCEL_BUTTON(By.xpath("//div[@class='asm-btn']//div//button[text()='Cancel']"),
			"Location Selector Cancel Button"),

	/** The location selector close button. */
	LOCATION_SELECTOR_CLOSE_BUTTON(By.xpath("//img[@class='close-icon']"), "Location Selector Close Button"),
	
	  /** The date picker. */
    DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]","Date Picker"),
	
	STATS_COUNT_TOOL_TIP_VALUE(By.xpath("//div[@class='common-tooltip--wrp']//span[@class='cust-tooltip-txt']"),"Stats Count Tool Tip value"),
	
	/** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),

	Y_AXIS_CHART_GRID(By.xpath("//div[@class='g-centre']//*[local-name()='g' and @class='highcharts-grid highcharts-xaxis-grid']//*[local-name()='path' and @class='highcharts-grid-line']"),"Y Axis Chart Grid"),

	FACEBOOK_Y_AXIS_COUNT(By.xpath("//span[text()='Facebook']//parent::div//parent::div//span[@class='y-value fontincrese-txt']"),"FACEBOOK_Y_AXIS_COUNT"),

	GOOGLE_Y_AXIS_COUNT(By.xpath("//span[text()='Google']//parent::div//parent::div//span[@class='y-value fontincrese-txt']"),"Google Y Axis Count"),

	TABLE_FACEBOOK_VALUE(By.xpath("//table//tbody//tr//span[text()='Facebook']//parent::div//parent::td//following-sibling::td//span[@class='value1']"),"Table Facebook value"),

	TABLE_GOOGLE_VALUE(By.xpath("//table//tbody//tr//span[text()='Google']//parent::div//parent::td//following-sibling::td//span[@class='value1']"),"Table Facebook value"),
	PROFILE_TABLE_ROWS(By.xpath("//div[contains(@class,'profile-tbl')]//table//tbody//tr"), "PROFILE_TABLE_ROWS");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new analytics tab page analytics enum.
	 *
	 * @param byLocator   the by locator
	 * @param description the description
	 */
	private AnalyticsTabPageAnalyticsEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new analytics tab page analytics enum.
	 *
	 * @param xpath       the xpath
	 * @param description the description
	 */
	private AnalyticsTabPageAnalyticsEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return byLocator;
	}

	/**
	 * Gets the by xpath.
	 *
	 * @return the by xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}
}

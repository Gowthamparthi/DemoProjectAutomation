package com.rallio.automation.newrallio.data;

import com.rallio.automation.bussiness.newRallio.entity.*;
import com.rallio.automation.common.util.*;
import org.testng.annotations.*;

import static com.rallio.automation.common.manager.ConfigManager.*;

// TODO: Auto-generated Javadoc
/**
 * The Class NewRallioDataProvider.
 */
public class NewRallioDataProvider {

	/**
	 * Gets the user.
	 *
	 * @return the user
	 */
	@DataProvider(name = "fetchuser")
	public static Object[][] getUser() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("user.login"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}

	/**
	 * Gets the brand user.
	 *
	 * @return the brand user
	 */
	@DataProvider(name = "branduser")
	public static Object[][] getBrandUser() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("brandUser.login"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}
	
	/**
	 * Gets the brand user info.
	 *
	 * @return the brand user info
	 */
	@DataProvider(name = "fetchBrandUser")
	public static Object[][] getBrandUserInfo() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("user.HubLogin"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}

	/**
	 * Gets the location user.
	 *
	 * @return the location user
	 */
	@DataProvider(name = "locationLogin")
	public static Object[][] getLocationUser() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("user.locationLogin"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}
	@DataProvider(name = "aiLocationLogin")
	public static Object[][] getAiLocationLogin() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("user.aiLocationLogin"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}

	/**
	 * Gets the LA user.
	 *
	 * @return the LA user
	 */
	@DataProvider(name = "fetchL2User")
	public static Object[][] getLAUser() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("user.locationTwoLogin"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}

	/**
	 * Gets the SF user.
	 *
	 * @return the SF user
	 */
	@DataProvider(name = "fetchSFUser")
	public static Object[][] getSFUser() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("user.BeanMeUpSFlogin"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}

	/**
	 * Gets the hub user.
	 *
	 * @return the hub user
	 */
	@DataProvider(name = "fetchHubUser")
	public static Object[][] getHubUser() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("hubUser.login"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}

	@DataProvider(name = "fetchHubUser2")
	public static Object[][] getHubUser2() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("hubUser2.login"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}
	/**
	 * Gets the invalid user.
	 *
	 * @return the invalid user
	 */
	@DataProvider(name = "invaliduser")
	public static Object[][] getInvalidUser() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("invalidUser.login"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}

	/**
	 * Gets the super admin user.
	 *
	 * @return the super admin user
	 */
	@DataProvider(name = "superadminuser")
	public static Object[][] getSuperAdminUser() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("superAdminUser.login"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}

	/**
	 * Gets the now tech user.
	 *
	 * @return the now tech user
	 */
	@DataProvider(name = "fetchNowTechuser")
	public static Object[][] getNowTechUser() {

		NowTechUser nowTechUser = JsonUtil.getObject(getValue("user.login"), NowTechUser.class);
		return new Object[][] { { nowTechUser } };
	}
	
	/**
	 * Gets the social profiles brand user.
	 *
	 * @return the social profiles brand user
	 */
	@DataProvider(name = "socialProfilesBranduser")
	public static Object[][] getSocialProfilesBrandUser() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("socialProfiles.brandLogin"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}
	
	/**
	 * Gets the EC location user.
	 *
	 * @return the EC location user
	 */
	@DataProvider(name = "ECLocationUser")
	public static Object[][] getECLocationUser() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("user.EC_1_locationLogin"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}

	/**
	 * Gets the hub user credential whith All type notifcations enabled.
	 *
	 * @return the hub user credential
	 */
	@DataProvider(name = "NotificationEnabledHub")
	public static Object[][] getHubUserCredential() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("notificationsEnabledHubUser"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}
	
	/**
	 * Gets the revv emp user credential.
	 *
	 * @return the revv emp user credential
	 */
	@DataProvider(name = "revvempUser")
	public static Object[][] getRevvEmpUserCredential() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("revvempUser.login"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}
	
	/**
	 * Gets the revv brand user credential.
	 *
	 * @return the revv brand user credential
	 */
	@DataProvider(name = "revvbrandUser")
	public static Object[][] getRevvBrandUserCredential() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("revvbrandUser.login"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}
	
	@DataProvider(name = "superCutsBranduser")
	public static Object[][] getBrandUser01() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("superCutsbrandUser.login"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}
	
	@DataProvider(name = "myProfileUser")
	public static Object[][] getEndUser01() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("user.locationUserMyProfile"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}
	
	@DataProvider(name = "myProfileHubUser")
	public static Object[][] getHubUser01() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("user.hubUserMyProfile"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}
	
	@DataProvider(name = "brandUser2")
	public static Object[][] getBrandUser02() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("brandUser2.login"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}
	
	@DataProvider(name = "multibranduser1")
	public static Object[][] getMultiBrand() {
		
		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("superAdminUser.login"), NewRallioUser.class);
		MultiBrand AdvantixBrand = JsonUtil.getObject(getValue("Advantix"), MultiBrand.class);		
		
		return new Object[][] { {newRallioUser,AdvantixBrand } };
	}
	
	@DataProvider(name = "multibranduser2")
	public static Object[][] getMultiBrand2() {
		
		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("superAdminUser.login"), NewRallioUser.class);
		MultiBrand painlessPostingBrand = JsonUtil.getObject(getValue("PainlessPosting"), MultiBrand.class);		
		
		return new Object[][] { {newRallioUser,painlessPostingBrand } };
	}
	
	@DataProvider(name = "multibranduser3")
	public static Object[][] getMultiBrand3() {
		
		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("superAdminUser.login"), NewRallioUser.class);
		MultiBrand myLocalCMO = JsonUtil.getObject(getValue("MyLocalCMO"), MultiBrand.class);		
		
		return new Object[][] { {newRallioUser,myLocalCMO } };
	}

	@DataProvider(name = "multibranduser4")
	public static Object[][] getMultiBrand4() {
		MultiBrand ssoRedirection = JsonUtil.getObject(getValue("ssoLocationUser.login"), MultiBrand.class);
		return new Object[][] { {ssoRedirection } };
	}
	@DataProvider(name = "opaertaionalCategoryHubUser")
	public static Object[][] getHubUserLogin() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("user.operationalCategoryHubUser"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}
	
	@DataProvider(name = "opaertaionalCategoryLocationUser")
	public static Object[][] getLocationUserLogin() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("user.operationalCategoryLocationUser"), NewRallioUser.class);
		return new Object[][] { { newRallioUser } };
	}

	@DataProvider(name = "contentSupplier")
	public static Object[][] getContentSupplierLogin() {

		NewRallioUser newRallioUser = JsonUtil.getObject(getValue("user.cotentSupplier"), NewRallioUser.class);
		return new Object[][]{{newRallioUser}};
	}
}

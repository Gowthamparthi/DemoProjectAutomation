package com.rallio.automation.newrallio.enums;

// TODO: Auto-generated Javadoc

/**
 * The Enum CommunityTabFilterEnum.
 */
public enum PlatformEngagementFilterEnum {

	/** The all. */
	ALL,

	/** The facebook. */
	FACEBOOK,

	/** The twitter. */
	TWITTER,

	/** The instagram. */
	INSTAGRAM,

	/** The linkedin. */
	LINKEDIN,
	
	/** The google. */
	GOOGLE,

	/** The TikTok. */
	TIKTOK,
	
	/** The yelp. */
	YELP,

	/** The like. */
	LIKE,

	/** The comment. */
	COMMENT,

	/** The post. */
	POST,

	/** The message. */
	MESSAGE,
	
	/** The inbox. */
	INBOX,

	Direct_Messages,
	
	/** The location posts. */
	LOCATION_POSTS,
	
	/** The la test. */
	LA_TEST,
	
	/** The social test location. */
	SOCIAL_TEST_LOCATION
}

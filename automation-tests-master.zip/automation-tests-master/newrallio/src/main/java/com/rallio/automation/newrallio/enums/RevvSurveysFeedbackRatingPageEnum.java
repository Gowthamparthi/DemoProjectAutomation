package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

public enum RevvSurveysFeedbackRatingPageEnum {
	
	PAGE_LOAD(By.xpath("//body//section[@class='customer-survey--experience content']"),"REVV_SURVEYS_FEEDBACK_RATING_PAGE"),
	
	NO_THANKS_BUTTON(By.xpath("//button[@class='btn button-cancel' and text()='No - Thanks']"),"NO_THANKS_BUTTON"),
	 
	SURE_BUTTON(By.xpath("//button[@class='btn button-connect button-sure' and text()='SURE']"),"SURE_BUTTON"),
	
    /** The location selector cancel button. */
    EXCELLENT_RATING(By.xpath("//h3[text()='Ratings']//parent::div[@class='filter-item']//input[@value='all']"),"EXCELLENT_RATING"),
    
    /** The location button. */
    GOOD_RATING(By.xpath("//h3[text()='Ratings']//parent::div[@class='filter-item']//span[text()='5 Stars']"),"GOOD_RATING"),
	
    /** The location selector search tab. */
    OK_RATING(By.xpath("//h3[text()='Ratings']//parent::div[@class='filter-item']//span[text()='4 Stars']"),"OK_RATING"),
    
    /** The location select from dropdown. */
    DISAPPOINTED_RATING(By.xpath("//h3[text()='Ratings']//parent::div[@class='filter-item']//span[text()='3 Stars']"),"DISAPPOINTED_RATING"),

  /** The location list dropdown. */
    POOR_RATING(By.xpath("//h3[text()='Ratings']//parent::div[@class='filter-item']//span[text()='2 Stars']"),"POOR_RATING"),
  
  /** The location selector ok button. */
    CANT_SEE_THIS_EMAIL(By.xpath("//h3[text()='Ratings']//parent::div[@class='filter-item']//span[text()='1 Star']"),"CANT_SEE_THIS_EMAIL"),
    
    SURVEY_RATING_FEEDBACK_FIELD(By.xpath("//div[@id='feedback']//textarea[@id='comment-area-survey']"),"SURVEY_RATING_FEEDBACK_FIELD"),

    SURVEY_RATING_FEEDBACK_YES_BY_PHONE_BUTTON(By.xpath("//button[@class='btn button-connect' and text()='Yes - By Phone']"),"SURVEY_RATING_FEEDBACK_YES_BY_PHONE_BUTTON"),

    SURVEY_RATING_FEEDBACK_YES_BY_EMAIL_BUTTON(By.xpath("//button[@class='btn button-connect' and text()='Yes - By Email']"),"SURVEY_RATING_FEEDBACK_YES_BY_PHONE_BUTTON"),
    
    SURVEY_RATING_FEEDBACK_NO_THANKS_BUTTON(By.xpath("//button[@class='btn button-cancel' and text()='No - Thanks']"),"SURVEY_RATING_FEEDBACK_NO_THANKS_BUTTON"),

    SURVEY_RATING_FEEDBACK_PHONE_NUMBER_FIELD(By.xpath("//input[@id='survey_customer_phone_number']"),"SURVEY_RATING_FEEDBACK_PHONE_NUMBER_FIELD"),

    SURVEY_RATING_FEEDBACK_EMAIL_FIELD(By.xpath("//input[@id='survey_customer_email']"),"SURVEY_RATING_FEEDBACK_EMAIL_FIELD"),

    SURVEY_RATING_FEEDBACK_CONFIRM_BUTTON(By.xpath("//input[contains(@id,'survey_customer')]//following-sibling::button[text()='CONFIRM']"),"SURVEY_RATING_FEEDBACK_CONFIRM_BUTTON"),

    SURVEY_WILL_YOU_LEAVE_US_AN_ONLINE_REVIEW_CONTENT(By.xpath("//h1[text()='Will you leave us an online review?']//parent::div[contains(@class,'survey-header')]"),"WILL_YOU_LEAVE_US_AN_ONLINE_REVIEW_CONTENT"),
    
    SURVEY_WILL_YOU_LEAVE_US_AN_ONLINE_REVIEW_SURE_BUTTON(By.xpath("//button[text()='SURE']"),"SURVEY_WILL_YOU_LEAVE_US_AN_ONLINE_REVIEW_SURE_BUTTON"),

    SURVEY_WILL_YOU_LEAVE_US_AN_ONLINE_REVIEW_NO_THANKS_BUTTON(By.xpath("//button[text()='No - Thanks']"),"SURVEY_WILL_YOU_LEAVE_US_AN_ONLINE_REVIEW_NO_THANKS_BUTTON"),

    SURVEY_THANK_YOU_CONTENT(By.xpath("//h1[text()='THANK YOU']//parent::div[@id='headerThanks']//following-sibling::div//h2[text()='FOR PROVIDING YOUR VALUABLE FEEDBACK!']"),"SURVEY_THANK_YOU_CONTENT");


	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new revv SS page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private RevvSurveysFeedbackRatingPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new revv SS page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private RevvSurveysFeedbackRatingPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}

}

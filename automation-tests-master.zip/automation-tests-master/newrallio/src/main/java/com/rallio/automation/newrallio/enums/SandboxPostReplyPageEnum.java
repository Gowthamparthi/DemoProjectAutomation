package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum SandboxPostReplyPageEnum.
 */
public enum SandboxPostReplyPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//div[@class='pmisorMain']//div[@class='pmisorCnt']"), "Page load"),
	
	/** Facebook post icon. */
	FACEBOOK_POST_ICON(By.xpath("//div[@class='pmisorCnt']//div[@class='gm-item']//img[contains(@src,'facebook.svg')]//parent::div//following-sibling::div//h3[text()='Facebook']"),"Facebook post icon"),
	
	/** The post location name. */
	POST_LOCATION_NAME(By.xpath("//div[@class='pmisorCnt']//div[@class='gm-item']//div[@class='gm-head']//div//h3[text()]"),"Post location name"),
	
	/** The post link button. */
	POST_LINK_BUTTON(By.xpath("//div[@class='pmisorCnt']//div[@class='gm-item']//img[contains(@src,'link.svg')]//parent::button"),"Post link button"),
	
	/** The facebook post like button. */
	FACEBOOK_POST_LIKE_BUTTON(By.xpath("//div[@class='pmisorCnt']//div[@class='gm-item']//img[contains(@src,'like-mg.svg')]//parent::button"),"Facebook post like button"),
	
	/** The facebook post liked. */
	FACEBOOK_POST_LIKED(By.xpath("//div[@class='pmisorCnt']//div[@class='gm-item']//img[contains(@src,'like-a-mg.svg')]"),"Facebook post liked"),
	
	/** The reply text area. */
	REPLY_TEXT_AREA(By.xpath("//div[@class='pmisorRight']//div[@class='ap-big-textarea']//textarea"),"Reply text area"),
	
	/** The emoji button. */
	EMOJI_BUTTON(By.xpath("//div[@class='pmisorRight']//div[@class='ap-emoji']//button"),"Emoji button"),
	
	/** The select emoji. */
	SELECT_EMOJI(By.xpath("//div[@class='pmisorRight']//div[@class='ap-emoji']//section//ul//li//button"),"Select emoji"),
	
	/** The send reply button. */
	SEND_REPLY_BUTTON(By.xpath("//div[@class='pmisorRight']//div[@class='pmsior-action']//button[text()='Send Reply']"),"Send reply button"),
	
	/** The cancel button. */
	CANCEL_BUTTON(By.xpath("//div[@class='pmisorRight']//div[@class='pmsior-action']//button[text()='Cancel']"),"Cancel button"),
	
	/** The linkedin post icon. */
	LINKEDIN_POST_ICON(By.xpath("//div[@class='pmisorCnt']//div[@class='gm-item']//img[contains(@src,'linkedin.svg')]//parent::div//following-sibling::div//h3[text()='Linkedin']"),"LinkedIn post icon"),
	
	/** The linkedin post like button. */
	LINKEDIN_POST_LIKE_BUTTON(By.xpath("//div[@class='pmisorCnt']//div[@class='gm-item']//img[contains(@src,'linkedinLike.svg')]//parent::button"),"LinkedIn post like button"),
	
	/** The linkedin post liked. */
	LINKEDIN_POST_LIKED(By.xpath("//div[@class='pmisorCnt']//div[@class='gm-item']//img[contains(@src,'linkedinLike-a.svg')]//parent::button"),"LinkedIn post liked");

	/** The by locator. */
	private By byLocator;

	/** The xpath. */
	private String xpath;

	/** The description. */
	private String description;

	/**
	 * Instantiates a new sandbox post reply page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private SandboxPostReplyPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new sandbox post reply page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private SandboxPostReplyPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return byLocator;
	}

	/**
	 * Gets the by xpath.
	 *
	 * @return the by xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}
}

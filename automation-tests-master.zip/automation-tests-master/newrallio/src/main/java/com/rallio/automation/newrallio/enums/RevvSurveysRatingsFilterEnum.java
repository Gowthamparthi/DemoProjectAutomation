package com.rallio.automation.newrallio.enums;

public enum RevvSurveysRatingsFilterEnum {

	ONE_STAR,
	
	/** The two star. */
	TWO_STAR,
	
	/** The three star. */
	THREE_STAR,
	
	/** The four star. */
	FOUR_STAR,
	
	/** The five star. */
	FIVE_STAR,
	
}

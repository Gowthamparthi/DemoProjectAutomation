package com.rallio.automation.newrallio.enums;


// TODO: Auto-generated Javadoc
/**
 * The Enum ReputationTabFilterEnum.
 */
public enum ReputationTabPlatformFilterEnum {

	/** The all. */
	ALL,
	
	/** The facebook. */
	FACEBOOK,
	
	/** The yelp. */
	YELP,
	
	/** The google. */
	GOOGLE;
}

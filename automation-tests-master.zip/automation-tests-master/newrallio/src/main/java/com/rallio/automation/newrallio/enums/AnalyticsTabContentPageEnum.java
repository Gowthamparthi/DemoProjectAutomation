

package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum AnalyticsTabContentsPageEnum.
 */
public enum AnalyticsTabContentPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath(
	        "//li[@class='ripple active']//span[text()='Content']//following::section[@class='item-g filter ra-filter-sec anlFilter']//ancestor::div//div[@class='g-centre']//div[@class='infinite-scroll-component__outerdiv']"),
	        "Page load"),

	/** The page contents. */
	PAGE_CONTENTS(By.xpath("//table//tbody//div[@class='sm-post r-flx']//parent::td//parent::tr"), "Page contents"),

	LIKE_BUTTON_FB(By.xpath("//div[@aria-label='Like']//span//i[@data-visualcompletion='css-img']"),"Facebook Like button"),

	LIKED_POST_FB(By.xpath("//div[@role='button']//span[text()='Coffee And Tea']//preceding::div[contains(@aria-label,'Like:')]"),"Liked Post displayed Facebook"),

	/** The page contents. */
	INTERCOM(By.xpath("//div[@id='intercom-container']//div[@class='intercom-dud02y e11rlguj1']"), "The intercom"),


	PAGE_CONTENTS_TEXT(By.xpath("//table//tbody//div[@class='sm-post r-flx']//parent::td//parent::tr//p"),"Page Contents Text"),

	/** The hub page contents. */
	HUB_PAGE_CONTENTS(By.xpath("//div[contains(@class,'mainContent')]//table[not(contains(@class,'loading'))]//tbody//following-sibling::tbody//div//parent::td//parent::tr"), "Hub page contents"),

	/** The multiple locations button. */
	MULTIPLE_LOCATIONS_BUTTON(By.xpath("//tbody//tr//td//span[text()='Multiple Locations']"), "Multiple locations button"),

	/** The multiple locations post with timezone. */
	MULTIPLE_LOCATIONS_POST_WITH_TIMEZONE(By.xpath("//div[@class='ml-fteen']//span[@class='sm-time l-t']"), "MULTIPLE_LOCATIONS_POST_WITH_TIMEZONE"),

	/** The back to all post. */
	BACK_TO_ALL_POST(By.xpath("//span[text()='Back to All Post']"), "Back to all post"),

	/** The no data to show. */
	NO_DATA_TO_SHOW(By.xpath("//*[text()=' No Data to show']"), "No data to show"),

	/** The page footer. */
	PAGE_FOOTER(By.xpath("//table//tbody//following-sibling::tbody//tr[last()]"), "Page footer"),

	/** The hub page footer. */
	HUB_PAGE_FOOTER(By.xpath("//table//tbody//following-sibling::tbody//tr[last()]"), "Hub page footer"),

	MULTIPLE_LOCATION_FOOTER(By.xpath("//table//tbody//tr[last()]"),"Multiple Location Footer"),
	
	/** The date posted button. */
	DATE_POSTED_BUTTON(By.xpath("//div[contains(@class,'mainContent')]//table//thead//th//span[text()='Date Posted']"), "Date posted button"),

	/** The published button. */
	PUBLISHED_BUTTON(By.xpath("//div[contains(@class,'mainContent')]//table//thead//th//span//span[text()='Published']"), "Published button"),

	PUBLISHED_BUTTON_TOOLTIP(By.xpath("//div[@class='common-tooltip--wrp' and text()='The number of times a post was published to pages.']"),"Published Button ToolTip"),
	
	/** The impressions button. */
	IMPRESSIONS_BUTTON(By.xpath("//div[contains(@class,'mainContent')]//table//thead//th//span//span[text()='Impressions']"), "impressions button"),

	IMPRESSION_TOTAL_NOT_AVAILABLE(By.xpath("//tbody//td//div[text()='Not Available']"),"Impression Not Available"),

	/** The impressions organic button. */
	IMPRESSIONS_ORGANIC_BUTTON(By.xpath("//div[contains(@class,'mainContent')]//table//thead//th//span//span[text()='Impressions (Organic)']"), "Impressions organic button"),

	/** The impressions paid button. */
	IMPRESSIONS_PAID_BUTTON(By.xpath("//div[contains(@class,'mainContent')]//table//thead//th//span//span[text()='Impressions (Paid)']"), "Impressions paid button"),

	/** The engagement button. */
	ENGAGEMENT_BUTTON(By.xpath("//div[contains(@class,'mainContent')]//table//thead//th//span//span[text()='Engagement']"), "Engagement button"),

	/** The likes button. */
	LIKES_BUTTON(By.xpath("//div[contains(@class,'mainContent')]//table//thead//th//span//span[text()='Likes']"), "Likes button"),

	/** The comments button. */
	COMMENTS_BUTTON(By.xpath("//div[contains(@class,'mainContent')]//table//thead//th//span//span[text()='Comments']"), "Comments button"),

	/** The shares button. */
	SHARES_BUTTON(By.xpath("//div[contains(@class,'mainContent')]//table//thead//th//span//span[text()='Shares']"), "Shares button"),

	/** The clicks button. */
	CLICKS_BUTTON(By.xpath("//div[contains(@class,'mainContent')]//table//thead//th//span//span[text()='Clicks']"), "Clicks button"),

	/** The rate button. */
	RATE_BUTTON(By.xpath("//div[contains(@class,'mainContent')]//table//thead//th//span//span[text()='Rate']"), "rate button"),

	PROMOTE_BUTTON(By.xpath("//div[contains(@class,'mainContent')]//table//thead//th//span//span[text()='Rate']//following::div//span[text()='Promote']"),"Promote Button"),

	/** The spend button. */
	SPEND_BUTTON(By.xpath("//div[contains(@class,'mainContent')]//table//thead//th//span//span[text()='Spend']"), "Spend button"),

	/** The down arrow. */
	DOWN_ARROW(By.xpath("//div[contains(@class,'mainContent')]//table//thead//th[contains(@class,'sort-active')]//img[contains(@src,'sort.svg') and @class='sort-cus ']"),
	        "Down arrow"),

	/** The up arrow. */
	UP_ARROW(By.xpath(
	        "//div[contains(@class,'mainContent')]//table//thead//th[contains(@class,'sort-active')]//img[contains(@src,'sort.svg') and contains(@class,'sort-icon__rotate')]"),
	        "Up arrow"),

	/** The totals count. */
	TOTALS_COUNT(By.xpath("//div[contains(@class,'mainContent')]//table//tbody//div[text()='Totals']//parent::div//span"), "Totals count"),

	/** The from range value. */
	FROM_RANGE_VALUE(By.xpath("//div[contains(@class,'mainContent')]//table//tbody//div[@class='date-range']//span[1]"), "From range value"),

	/** The to range value. */
	TO_RANGE_VALUE(By.xpath("//div[contains(@class,'mainContent')]//table//tbody//div[@class='date-range']//span[3]"), "To range value"),

	/** The published count. */
	PUBLISHED_COUNT(By.xpath("//div[text()='Totals']//parent::div//parent::td//following-sibling::td[1]//div[text()]"),
	        "Published count"),

	IMPRESSION_BUTTON_TOOLTIP(By.xpath("//div[@class='common-tooltip--wrp' and contains(text(),\"The number of times a post has been displayed in a person's feed.\")]"),"Impressions Tool Tip"),
	
	ENGAGEMENT_BUTTON_TOOLTIP(By.xpath("//div[@class='common-tooltip--wrp' and contains(text(),\"The number of comments, likes, shares and other interactions on posts published during the selected date range.\")]"),"ENGAGEMENT_BUTTON_TOOLTIP"),
	
	RATE_BUTTON_TOOLTIP(By.xpath("//div[@class='common-tooltip--wrp' and contains(text(),\"The engagement rate percentage is a measure of engagement divided by impressions.\")]"),"RATE_BUTTON_TOOLTIP"),
	
	SPEND_BUTTON_TOOLTIP(By.xpath("//div[@class='common-tooltip--wrp' and contains(text(),\"The amount spent in this platform to promote a post via boosting.\")]"),"Spend Button ToolTip"),
	
	IMPRESSION_ORGANIC_COUNT_TOOLTIP(By.xpath("//div[@class='ca-tlp-item']//span[text()='Organic']//following-sibling::span"),"IMPRESSION_ORGANIC_COUNT_TOOLTIP"),
	
	IMPRESSION_PAID_COUNT_TOOLTIP(By.xpath("//div[@class='ca-tlp-item']//span[text()='Paid']//following-sibling::span"),"IMPRESSION_PAID_COUNT_TOOLTIP"),
	
	ENGAGEMENT_LIKES_COUNT_TOOLTIP(By.xpath("//div[@class='ca-tlp-item']//span[text()='Likes']//following-sibling::span"),"ENGAGEMENT_LIKES_COUNT_TOOLTIP"),
	
	ENGAGEMENT_SHARES_COUNT_TOOLTIP(By.xpath("//div[@class='ca-tlp-item']//span[text()='Shares']//following-sibling::span"),"ENGAGEMENT_SHARES_COUNT_TOOLTIP"),
	
	ENGAGEMENT_COMMENTS_COUNT_TOOLTIP(By.xpath("//div[@class='ca-tlp-item']//span[text()='Comments']//following-sibling::span"),"ENGAGEMENT_COMMENTS_COUNT_TOOLTIP"),
	
	ENGAGEMENT_CLICKS_COUNT_TOOLTIP(By.xpath("//div[@class='ca-tlp-item']//span[text()='Clicks']//following-sibling::span"),"ENGAGEMENT_CLICKS_COUNT_TOOLTIP"),
	
	RATE_COUNT_TOOLTIP(By.xpath("//div[@class='ca-tlp-item']//span[text()='Rate equals Engagement ' and text()=' divided by impressions.']"),"RATE_COUNT_TOOLTIP"),
	
	/** The impressions count. */
	IMPRESSIONS_COUNT(By.xpath("//div[text()='Totals']//parent::div//parent::td//following-sibling::td[2]//div[text()]"),
	        "Impressions count"),

	/** The impressions count. */
	HUB_IMPRESSIONS_COUNT(
	        By.xpath("//div[contains(@class,'mainContent')]//table//tbody//tr[contains(@class,'total')]//span[text()='Impressions']//ancestor::td[contains(@class,'pivoted')]"),
	        "Impressions count"),

	/** The engagement count. */
	ENGAGEMENT_COUNT(By.xpath("//div[text()='Totals']//parent::div//parent::td//following-sibling::td[3]//div[text()]"),
	        "Engagement count"),

	/** The engagement count. */
	HUB_ENGAGEMENT_COUNT(
	        By.xpath("//div[contains(@class,'mainContent')]//table//tbody//tr[contains(@class,'total')]//span[text()='Engagement']//ancestor::td[contains(@class,'pivoted')]"),
	        "Engagement count"),

	/** The rate count. */
	RATE_COUNT(By.xpath("//div[text()='Totals']//parent::div//parent::td//following-sibling::td[4]//div[@class='txt-sign']"),
	        "Rate count"),

	/** The rate count. */
	HUB_RATE_COUNT(By.xpath("//div[contains(@class,'mainContent')]//table//tbody//tr[contains(@class,'total')]//span[text()='Rate']//ancestor::td[contains(@class,'pivoted')]"),
	        "Rate count"),

	/** The spend amount. */
	SPEND_AMOUNT(By.xpath("//div[text()='Totals']//parent::div//parent::td//following-sibling::td[5]//div//div//span[text()]"),
	        "Spend amount"),

	/** The totals count multiple location. */
	TOTALS_COUNT_MULTIPLE_LOCATION(By.xpath("//div[text()='Totals']//parent::div//div[contains(@class,'total-count')]//span"), "Total count multiple locations"),

	/** The post logo multiple locations. */
	POST_LOGO_MULTIPLE_LOCATIONS(By.xpath("//div[contains(@class,'sm-post')]//img[@alt='post']"), "Post logo multiple locations"),

	/** The post location multiple locations. */
	POST_LOCATION_MULTIPLE_LOCATIONS(By.xpath("//div[contains(@class,'sm-post')]//div[contains(@class,'ca-location-name')]"), "Post location multiple locations"),

	/** The post date time multiple locations. */
	POST_DATE_TIME_MULTIPLE_LOCATIONS(By.xpath("//div[contains(@class,'sm-post')]//div//span[@class='sm-date l-d']//following-sibling::span"), "Post date time multiple locations"),

	/** The post date time. */
	POST_DATE_TIME(By.xpath("//tbody//tr[not(@class='total')]//span[@class='sm-date']//following-sibling::span[@class='sm-time']"),
	        "Post date time"),

	/** The post data. */
	POST_DATA(By.xpath("//tbody//tr[not(@class='total')]//p[contains(@class,'sm-message') and text()]"), "Post data"),

	/** The post impression count. */
	POST_IMPRESSION_COUNT(By.xpath("//span[text()='Impressions']//ancestor::table//tbody//following-sibling::tbody//tr//td[2]//span[text()]"),
	        "Post impression count"),

	/** The post engagement count. */
	POST_ENGAGEMENT_COUNT(By.xpath("//span[text()='Engagement']//ancestor::table//tbody//following-sibling::tbody//tr//td[3]//span[text()]"),
	        "Post engagement count"),

	/** The post engagement count value. */
	POST_ENGAGEMENT_COUNT_VALUE(By.xpath("//span[text()='Engagement']//ancestor::table//tbody//following-sibling::tbody//tr//td[3]//span[text()]"),"Engagement Count Value"),
	
	/** The post rate count. */
	POST_RATE_COUNT(By.xpath(
	        "//span[text()='Rate']//ancestor::table//tbody//following-sibling::tbody//tr//td[4]//span[text()]"),
	        "Post rate count"),

	/** The post spend count. */
	POST_SPEND_COUNT(By.xpath("//span[text()='Spend']//ancestor::table//tbody//following-sibling::tbody//tr//td[5]//div[text()]"), "post spend count"),

	CLICKS_COLUMN_COUNT(By.xpath("//span[text()='Clicks']//ancestor::table//tbody//following-sibling::tbody//tr//td[3]//span[text()]"),"Clicks Column Count"),
	
	/** The hub post published count. */
	HUB_POST_PUBLISHED_COUNT(By.xpath("//tbody//tr[not(@class='total')]//td[contains(@class,'pivoted')][1]//div[contains(@class,'r-flx')]//span"),
	        "Hub post published count"),

	/** The post impression count. */
	HUB_POST_IMPRESSION_COUNT(By.xpath("//span[text()='Impressions']//ancestor::table//tbody//following-sibling::tbody//tr//td[3]//span[text()]"),
	        "Hub Post impression count"),

	/** The post engagement count. */
	HUB_POST_ENGAGEMENT_COUNT(By.xpath("//span[text()='Engagement']//ancestor::table//tbody//following-sibling::tbody//tr//td[4]//span[text()]"),
	        "Hub Post engagement count"),

	/** The post rate count. */
	HUB_POST_RATE_COUNT(By.xpath(
	        "//span[text()='Rate']//ancestor::table//tbody//following-sibling::tbody//tr//td[5]//span[text()]"),
	        "Hub Post rate count"),

	/** The hub post spend count. */
	HUB_POST_SPEND_COUNT(By.xpath("//span[text()='Spend']//ancestor::table//tbody//following-sibling::tbody//tr//td[6]//div[text()]"),
	        "Hub post spend count"),

	/** The multi post impression count. */
	MULTI_POST_IMPRESSION_COUNT(By.xpath("//th//span[text()='Impressions']//ancestor::table//tbody//tr//td[2]//span[contains(@class,'cur-normal')]"),
	        "Multi post impression count"),

	/** The multi post engagement count. */
	MULTI_POST_ENGAGEMENT_COUNT(By.xpath("//th//span[text()='Engagement']//ancestor::table//tbody//tr//td[3]//span[contains(@class,'cur-normal')]"),
	        "Multi post engagement count"),

	/** The multi post rate count. */
	MULTI_POST_RATE_COUNT(By.xpath("//th//span[text()='Rate']//ancestor::table//tbody//tr//td[4]//span[contains(@class,'cur-normal')]"),
	        "Multi post rate count"),

	/** The multi post spend count. */
	MULTI_POST_SPEND_COUNT(By.xpath("//th//span[text()='Spend']//ancestor::table//tbody//tr//td[5]//div[text()]"),
	        "Multi post spend count"),

	/** The clear filter. */
	CLEAR_FILTER(By.xpath("//button//span[text()='Clear Filter']"),
	        "Clear filter"),

	/** The clear filter active. */
	CLEAR_FILTER_ACTIVE(By.xpath("//div[@class='react-ripples ac-primary-box' and not(contains(@class,'pointer-events-none'))]//button//span[text()='Clear Filter']"),
	        "Clear filter active"),

	/** The branduser clear filter. */
	BRANDUSER_CLEAR_FILTER(By.xpath("//button[@class='ac-btn ac-primary-light ac-block ac-outline ' and text()='Clear Filter']"), "BrandUser clear filter"),
	
	/** The download csv button. */
	DOWNLOAD_CSV_BUTTON(By.xpath("//section[contains(@class,'item-g filter ra-filter-sec')]//button//span[text()='Download CSV']//parent::button"), "Download csv button"),

	/** The download started message. */
	DOWNLOAD_STARTED_MESSAGE(By.xpath("//*[contains(text(),'Download started')]"), "Download started message"),

	/** The download done message. */
	DOWNLOAD_DONE_MESSAGE(By.xpath("//div//span[text()='Done!']"),"The download Done Message"),
	
	/** The month picker. */
	MONTH_PICKER(By.xpath("//select[@class='react-datepicker__month-select']"), "Month picker"),

	/** The year picker. */
	YEAR_PICKER(By.xpath("//select[@class='react-datepicker__year-select']"), "Year picker"),

	/** The from date. */
	FROM_DATE(By.xpath("//div[@class='dp-item date-end__wrp dp-from']//div[contains(@class,'react-datepicker__input-container')]//input[@placeholder='MM/DD/YYYY']"), "From date"),

	/** The from date active. */
	FROM_DATE_ACTIVE(By.xpath("//section[contains(@class,'filter')]//div[@class='dp-item']"), "From date active"),

	/** The from date content. */
	FROM_DATE_CONTENT(By.xpath("//div[contains(@class,'dp-from')]//div[@class='react-datepicker__input-container']//input"), "From date content"),

	/** The select from date. */
	SELECT_FROM_DATE("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]", "Select From date"),

	/** The select from date with month. */
	SELECT_FROM_DATE_WITH_MONTH(
	        "//section[contains(@class,'filter')]//div[contains(@class,'dp-item dp-from')]//div[2]//div[@aria-disabled='false' and  contains(@aria-label,'%s')]",
	        "Select from date with month"),

	/** The from date previous month. */
	FROM_DATE_PREVIOUS_MONTH(By.xpath("//section[contains(@class,'filter')]//div[@class='react-datepicker']//button[@aria-label='Previous Month']"),
	        "From date previous month button"),

	/** The from date next month. */
	FROM_DATE_NEXT_MONTH(By.xpath("//section[contains(@class,'filter')]//div[@class='react-datepicker']//button[@aria-label='Next Month']"),
	        "From date next month button"),

	/** The select date from calendar. */
	SELECT_DATE_FROM_CALENDAR(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week']//div[@aria-disabled='false']"), "Select date from calendar"),

	/** The calendar displayed. */
	CALENDAR_DISPLAYED(By.xpath("//div[@class='react-datepicker__month']"), "Calendar displayed"),

	/** The select last date. */
	SELECT_LAST_DATE(By.xpath("//div[@class='react-datepicker__month']//div[@class='react-datepicker__week'][3]//div[@aria-disabled='false'][last()]"), "Select last date"),

	/** The to date. */
	TO_DATE(By.xpath("//div[@class='dp-item date-end__wrp dp-to']//div[contains(@class,'react-datepicker__input-container')]//input"), "To date"),

	/** The to date active. */
	TO_DATE_ACTIVE(By.xpath("//section[contains(@class,'filter')]//div[@class='dp-item dp-to active']"), "To date active"),

	/** The to date content. */
	TO_DATE_CONTENT(By.xpath("//div[contains(@class,'dp-to')]//div[@class='react-datepicker__input-container']//input"), "To date content"),

	/** The to date content from calendar. */
	TO_DATE_CONTENT_FROM_CALENDAR(By.xpath("//section[contains(@class,'filter')]//div[contains(@class,'dp-item dp-to')]//div[contains(@class,'today react-datepicker')]"), "To date content from calendar"),
	
	/** The to date previous month. */
	TO_DATE_PREVIOUS_MONTH(By.xpath("//section[contains(@class,'filter')]//div[@class='react-datepicker']//button[@aria-label='Previous Month']"),
	        "To date previous month button"),

	/** The to date next month. */
	TO_DATE_NEXT_MONTH(By.xpath("//section[contains(@class,'filter')]//div[@class='react-datepicker']//button[@aria-label='Next Month']"), "To date next month button"),

	/** The select to date. */
	SELECT_TO_DATE("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]", "Select To date"),

	/** The select to date with month. */
	SELECT_TO_DATE_WITH_MONTH("//section[contains(@class,'filter')]//div[contains(@class,'dp-item date-end__wrp dp-to')]//div[2]//div[@aria-disabled='false' and  contains(@aria-label,'%s')]",
	        "Select to date with month"),

	/** The platform filter. */
	PLATFORM_FILTER(By.xpath("//section[contains(@class,'filter')]//div[@class='filter-item']//h3[text()='Platform']"), "Platform filter"),

	/** The all filter button. */
	ALL_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'all-platform.svg')]//parent::button"),
	        "All filter button"),

	/** The all filter selected. */
	ALL_FILTER_SELECTED(
	        By.xpath(
	                "//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'all-platform.svg')]//parent::button[contains(@class,'active')]"),
	        "All filter selected"),

	/** The facebook filter button. */
	FACEBOOK_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'fb-platform')]//parent::button"),
	        "Facebook filter button"),

	/** The facebook filter selected. */
	FACEBOOK_FILTER_SELECTED(
	        By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'fb-platform')]//parent::button[contains(@class,'active')]"),
	        "Facebook filter selected"),

	/** The twitter filter button. */
	TWITTER_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'twitter-platform')]//parent::button"),
	        "Twitter filter button"),

	/** The twitter filter selected. */
	TWITTER_FILTER_SELECTED(
	        By.xpath(
	                "//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'twitter-platform')]//parent::button[contains(@class,'active')]"),
	        "Twitter filter selected"),

	/** The linkedin filter button. */
	LINKEDIN_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'linkedin-platform')]//parent::button"),
	        "LinkedIn filter button"),

	/** The linkedin filter selected. */
	LINKEDIN_FILTER_SELECTED(By
	        .xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'linkedin-platform')]//parent::button[contains(@class,'active')]"),
	        "LinkedIn filter selected"),

	/** The instagram filter button. */
	INSTAGRAM_FILTER_BUTTON(By.xpath("//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'instagram-platform')]//parent::button"),
	        "Instagram filter button"),

	/** The instagram filter selected. */
	INSTAGRAM_FILTER_SELECTED(By.xpath(
	        "//section[contains(@class,'filter')]//div[@class='fltr-imc selectsocial']//img[contains(@src,'instagram-platform')]//parent::button[contains(@class,'active')]"),
	        "Instagram filter selected"),
	
	/** The locations filter. */
	LOCATIONS_FILTER(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='filter-item fltr-drp']//h3[text()='Locations']"), "Locations filter"),

	/** The locations filter dropdown. */
	LOCATIONS_FILTER_DROPDOWN(By.xpath("//section[contains(@class,'item-g filter')]//h3[text()='Locations']//parent::div//div//button"), "Locations filter dropdown"),

	/** The locations filter current location. */
	LOCATIONS_FILTER_CURRENT_LOCATION(By.xpath("//section[contains(@class,'item-g filter')]//h3[text()='Locations']//parent::div//div//button//span"), "Locations filter dropdown"),

	/** The select from locations filter. */
	SELECT_FROM_LOCATIONS_FILTER("//div[@id='locations-dropdown-outbox']//div[contains(@class,'rs-drp__menu-list')]//div[contains(text(),'%s')]", "Seect from locations filter"),

	/** The locations filter search box. */
	LOCATIONS_FILTER_SEARCH_BOX(By.xpath("//div[contains(@class,'rs-drp__value-container')]//input"), "Locations filter search box"),

	/** The hub filter. */
	HUB_FILTER(By.xpath("//h3[text()='Post Source']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='Hub']"), "Hub filter"),

	/** The hub filter active. */
	HUB_FILTER_ACTIVE(By.xpath(
	        "//h3[text()='Post Source']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='Hub']//ancestor::label[@class='active']"),
	        "Hub filter active"),

	/** The local filter. */
	LOCAL_FILTER(By.xpath("//h3[text()='Post Source']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='Local']"), "local filter"),

	/** The local filter active. */
	LOCAL_FILTER_ACTIVE(By.xpath(
	        "//h3[text()='Post Source']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='Local']//ancestor::label[@class='active']"),
	        "Local filter active"),

	/** The engagement filter. */
	ENGAGEMENT_FILTER(By.xpath("//section[contains(@class,'filter')]//div[@class='filter-item']//h3[text()='Engagement Type']"), "Engagement filter"),

	/** The all filter. */
	ENGAGEMENT_ALL_FILTER(By.xpath(
	        "//section[contains(@class,'filter')]//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='All']"),
	        "Engagement All filter"),

	/** The all filter active. */
	ENGAGEMENT_ALL_FILTER_ACTIVE(By
	        .xpath("//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='All']//ancestor::label[@class='active']"),
	        "Engagement All filter active"),

	/** The comment filter. */
	COMMENT_FILTER(By.xpath(
	        "//section[contains(@class,'filter')]//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[contains(text(),'Comment')]"),
	        "Comment filter"),

	/** The comment filter active. */
	COMMENT_FILTER_ACTIVE(By.xpath(
	        "//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[contains(text(),'Comment')]//ancestor::label[@class='active']"),
	        "Comment filter active"),

	/** The likes filter. */
	LIKES_FILTER(By.xpath(
	        "//section[contains(@class,'filter')]//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='Likes']"),
	        "Likes filter"),

	/** The likes filter active. */
	LIKES_FILTER_ACTIVE(By.xpath(
	        "//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='Likes']//ancestor::label[@class='active']"),
	        "Likes filter active"),

	/** The shares filter. */
	SHARES_FILTER(By.xpath(
	        "//section[contains(@class,'filter')]//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='Shares']"),
	        "Shares filter"),

	/** The shares filter active. */
	SHARES_FILTER_ACTIVE(By.xpath(
	        "//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='Shares']//ancestor::label[@class='active']"),
	        "Shares filter active"),

	/** The clicks filter. */
	CLICKS_FILTER(By.xpath(
	        "//section[contains(@class,'filter')]//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='Clicks']"),
	        "Clicks filter"),

	/** The clicks filter active. */
	CLICKS_FILTER_ACTIVE(By.xpath(
	        "//h3[text()='Engagement Type']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='Clicks']//ancestor::label[@class='active']"),
	        "Clicks filter active"),

	/** The impressions filter. */
	IMPRESSIONS_FILTER(By.xpath("//section[contains(@class,'filter')]//div[@class='filter-item']//h3[text()='Impressions']"), "Impressions filter"),

	/** The impressions all filter. */
	IMPRESSIONS_ALL_FILTER(By.xpath(
	        "//section[contains(@class,'filter')]//h3[text()='Impressions']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='All']"),
	        "Impressions all filter"),

	/** The impressions all filter active. */
	IMPRESSIONS_ALL_FILTER_ACTIVE(By.xpath(
	        "//h3[text()='Impressions']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='All']//ancestor::label[@class='active']"),
	        "Impressions all filter active"),

	/** The organic filter. */
	ORGANIC_FILTER(By.xpath(
	        "//section[contains(@class,'filter')]//h3[text()='Impressions']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='Organic']"),
	        "Organic filter"),

	/** The organic filter active. */
	ORGANIC_FILTER_ACTIVE(By.xpath(
	        "//h3[text()='Impressions']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='Organic']//ancestor::label[@class='active']"),
	        "Organic filter active"),

	/** The paid filter. */
	PAID_FILTER(By.xpath(
	        "//section[contains(@class,'filter')]//h3[text()='Impressions']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='Paid']"),
	        "Paid filter"),

	/** The paid filter active. */
	PAID_FILTER_ACTIVE(By.xpath(
	        "//h3[text()='Impressions']//parent::div[@class='filter-item']//div[contains(@class,'form-group')]//label//span[text()='Paid']//ancestor::label[@class='active']"),
	        "Paid filter active"),
	/** The post location. */
	POST_LOCATION(By.xpath("//div[contains(@class,'list-item ')]//div[@class='li-top']//div[@class='lvt-details']//h3"), "Post location"),
    
    /** The common post. */
    ////////////////////////////////////////////////////////////////////////////////////////////
	COMMON_POST(By.xpath("//div[contains(@class,'mainContent')]//table//tbody//tr[not(@class='total')]//div[@class='sm-post r-flx']"),
			"Common post"),

	/** The second common post. */
	SECOND_COMMON_POST(By.xpath("//div[contains(@class,'mainContent')]//table//tbody//tr[2]//td//div[@class='sm-post r-flx']"),"SECOND_COMMON_POST"),

	SECOND_COMMON_POST_WITH_TEXT(By.xpath("//div[contains(@class,'mainContent')]//table//tbody//tr[2]//div[@class='sm-post r-flx']//p"),"SECOND_COMMON_POST"),

	COMMON_POST_WITH_TEXT(By.xpath("//div[contains(@class,'mainContent')]//table//tbody//tr//div[@class='sm-post r-flx']//p[text()]"),"Common Post With Text"),

	SECOND_COMMON_POST_WITHOUT_TEXT(By.xpath("//div[contains(@class,'mainContent')]//table//tbody//tr[2]//div[@class='sm-post r-flx']"),"Second common post without Text"),

	/** The posts detailed view - Profile icon */
	POSTS_DETAILED_VIEW_PROFILE_ICON(By.xpath("//div[contains(@class,'pluginSkinLight')]//img[@role='img']"), "Posts detailed view - profile icon"),

	/** The posts detailed view - Linkedin profile icon */
	POSTS_DETAILED_VIEW_LINKEDIN_PROFILE_ICON(By.xpath("//body//article//img[@data-ghost-classes='bg-color-entity-ghost-background']"), "Posts detailed view - Linkedin profile icon"),

	/** The posts detailed view - Linkedin page name */
	POSTS_DETAILED_VIEW_LINKEDIN_PAGE_NAME(By.xpath("//body//article//div[contains(@class,'text-color-text ')]//a"), "Posts detailed view - Linkedin page name"),

	/** The posts detailed view - Linkedin time stamp */
	POSTS_DETAILED_VIEW_LINKEDIN_TIME_STAMP(By.xpath("//body//article//div//span//time[@class='flex-none']"), "Posts detailed view -Linkedin Time stamp"),

	/** The posts detailed view - Linkedin text */
	POSTS_DETAILED_VIEW_LINKEDIN_TEXT(By.xpath("//body//article//p[@data-test-id='main-feed-activity-embed-card__commentary']"), "Posts detailed view -Linkedin text"),

	/** The post by text. */
	POST_BY_TEXT(
	        "//div[contains(@class,'sm-post')]//p[text()='%s']",
	        "Post By Text"),

	/** The posts detailed view frame. */
	POSTS_DETAILED_VIEW_FRAME(By.xpath("//div[@class='modal-body']//iframe[@class='as-modal-sm-post']"), "POSTS_DETAILED_VIEW_FRAME"),

	/** The posts detailed view. */
	POSTS_DETAILED_VIEW(By.xpath("//div[@class='modal-body']//*[contains(@class,'as-modal-sm-post')]"), "Posts detailed view"),

	DETAILVIEW_POST_ID_AND_DATE(By.xpath("//div[@class='modal-body']//div[@class='prime-sub-dtls']//h3[@class='prime-post-id']//parent::div//span[@class='prime-post-date']"),"DetailView Post Id"),
	DETAILVIEW_POST_IMAGE_SECTION(By.xpath("//div[@class='as-modal-left-card']//img"),"Detailview Post image Section"),
	
	/** The detailed view post profile icon. */
	DETAILED_VIEW_POST_PROFILE_ICON(By.xpath("//ul[@class='share-images ']//li//img"),
	        "DetailedView post profile icon"),
	DETAILED_VIEW_POST_SOCIAL_PLATFORM_ICON(By.xpath("//div[@class='modal-body']//div[@class='fltr-imc selectsocial']//button[@class='roundedbtn btn btn-link']//img"),"Detailed view Post Social Platform Icon"),
	
	/** The deatil view post facebook icon. */
	DETAIL_VIEW_POST_FACEBOOK_ICON(By.xpath("//button[@class='roundedbtn btn btn-link']//img[contains(@src,'fb-platform.svg') and @alt='Platform']"),"DEATIL_VIEW_POST_FACEBOOK_ICON"),
	
	/** The detail view post instagram icon. */
	DETAIL_VIEW_POST_INSTAGRAM_ICON(By.xpath("//button[@class='roundedbtn btn btn-link']//img[contains(@src,'instagram-platform.svg') and @alt='Platform']"),"DEATIL_VIEW_POST_INSTAGRAM_ICON"),
	
	/** The detail view post linkedin icon. */
	DETAIL_VIEW_POST_LINKEDIN_ICON(By.xpath("//button[@class='roundedbtn btn btn-link']//img[contains(@src,'instagram-platform.svg') and @alt='Platform']"),"DEATIL_VIEW_POST_LINKEDIN_ICON"),
	
	/** The deatailed view post profile image. */
	DEATAILED_VIEW_POST_PROFILE_IMAGE(By.xpath("//header[@class='share-update-card__header']//a//img"),"Deatiled View Post Profile Image"),
	
	DETAILED_VIEW_POST_VIEW_PROFILE_BUTTON(By.xpath("//div[@class='HeaderCta']//a[text()='View profile']"),"Detailed view Post View Profile Button"),
	
	/** The detailed view post profile icon no longer available. */
	DETAILED_VIEW_POST_PROFILE_ICON_NO_LONGER_AVAILABLE(By.xpath("//*[contains(text(),'This Facebook post is no longer available.')]"),
	        "DETAILED_VIEW_POST_PROFILE_ICON_NO_LONGER_AVAILABLE"),

    /** The detailed view post like button. *///span[@class='embeddedLikeButton']//div[text()='Like']
    DETAILED_VIEW_POST_LIKE_BUTTON(By.xpath("//div[text()='Like']//parent::div//parent::div//i[1]"), "DetailedView post like button"),

	/** The detailed view post share button. *///td//a//div[@title='Share' and text()='Share']
	DETAILED_VIEW_POST_SHARE_BUTTON(By.xpath("//div[text()='Share']//parent::div//parent::div//i[1]"), "DetailedView post share button"),

	/** The detailed view post comment button. *///td//a//div[text()='Comment']
	DETAILED_VIEW_POST_COMMENT_BUTTON(By.xpath("//div[text()='Comment']//parent::div//parent::div//i[1]"), "DetailedView post comment button"),

	/** The detailed view post impressions. */
	DETAILED_VIEW_POST_IMPRESSIONS(By.xpath("//div[@class='modal-content']//div[@class='tile-list--container']//span[text()='Impressions']"), "DetailedView post impressions"),

	/** The detailed view impression linkedin count. */
	DETAILVIEW_IMPRESSION_LINKEDIN_COUNT(By.xpath("//div[text()='Impressions']//preceding-sibling::span[@class='tile-wrp__value' and text()]"),"Detailview Impression Linkedin Count"),

	/** The detailed view post engagement. */
	DETAILED_VIEW_POST_ENGAGEMENT(By.xpath("//div[@class='modal-content']//div[@class='tile-list--container']//span[text()='Engagement']"), "DetailedView post engagement"),

	/** The detailed view post clicks. */
	DETAILED_VIEW_POST_CLICKS(By.xpath("//div[@class='modal-content']//div[@class='tile-list--container']//span[text()='Post Clicks']"), "DetailedView post clicks"),

	/** The detailed view post negative feedback. */
	DETAILED_VIEW_POST_NEGATIVE_FEEDBACK(By.xpath("//div[@class='modal-content']//div[@class='tile-list--container']//span[text()='Negative Feedback']"),
	        "DetailedView post negativeFeedback"),
	
	DETAILED_VIEW_INGTAGRAM_POST_LIKES(By.xpath("//div[@class='Feedback']//a[@class='Likes']"),"Detailed View Instagram Post likes"),
	
	DETAILED_VIEW_INGTAGRAM_POST_SHARE(By.xpath("//div[@class='Feedback']//a[@class='Share']"),"Detailed View Instagram Post Share"),
	
	DETAILED_VIEW_INGTAGRAM_POST_COMMENT(By.xpath("//div[@class='Feedback']//a[@class='Comments']"),"Detailed View Instagram Comments Share"),
	
	DETAILED_VIEW_INSTAGRAM_POST_SAVE(By.xpath("//div[@class='Feedback']//a[@class='Save']"),"DETAILED_VIEW_INSTAGRAM_POST_SAVE"),
	
    DETAILED_VIEW_INSTAGRAM_POST_ADD_COMMENT(By.xpath("//div[@class='Footer']//a[@class='CommentInput']"),"Detailed View Instagram Post Add Comment"),	
	
	DETAILED_VIEW_INSTAGRAM_POST_COMMENT_ICON(By.xpath("//div[@class='Footer']//a[@class='Glyph']//i"),"Detailed View Instagram Post Comment Icon"),
    
    /** The month dropdown. */
	MONTH_DROPDOWN(By.xpath("//select[@class='react-datepicker__month-select']"), "Month drop down"),

	/** The year dropdown. */
	YEAR_DROPDOWN(By.xpath("//select[@class='react-datepicker__year-select']"), "Year drop down."),

	/** The detailed view post close button. */
	DETAILED_VIEW_POST_CLOSE_BUTTON(By.xpath("//div[@class='modal-content']//img[@alt='close']"), "DetailedView post close button"),

	/** The detailed view post name. */
	DETAILED_VIEW_POST_NAME(By.xpath("//div[@class='prime-sub-dtls']//h3[@class='prime-post-id']"), "DetailedView post name"),

	/** The detailed view post previous button. */
	DETAILED_VIEW_POST_PREVIOUS_BUTTON(By.xpath("//div[@class='modal-content']//div[@class='navigate-icon prev-icon']"), "DetailedView post previous button"),

	/** The detailed view post next button. */
	DETAILED_VIEW_POST_NEXT_BUTTON(By.xpath("//div[@class='modal-content']//div[@class='navigate-icon next-icon']"), "DetailedView post next button"),
	
	DETAILVIEW_IMPRESSION_NOT_APPLICABLE_COUNT(By.xpath("//div[text()='Impressions']//preceding-sibling::span[@class='tile-wrp__value' and text()='N/A']"),"Detailview Impressions Not Applicable"),
	
	DETAILVIEW_IMPRESSION_APPLICABLE_COUNT(By.xpath("//div[text()='Impressions']//preceding-sibling::span[@class='tile-wrp__value' and not(text()='N/A')]"),"Detailview Impressions  Applicable"),
	
	DETAILVIEW_IMPRESSION_ORGANIC_COUNT(By.xpath("//div[text()='Organic']//preceding-sibling::span[@class='tile-wrp__value' and text()]"),"Detailview Impression Organic Count"),
	
	DETAILVIEW_IMPRESSION_PAID_COUNT(By.xpath("//div[text()='Paid']//preceding-sibling::span[@class='tile-wrp__value' and text()]"),"Detailview Impression Paid Count"),
	
	DETAILVIEW_ENGAGEMENT_LIKES_COUNT(By.xpath("//div[text()='Likes']//preceding-sibling::span[@class='tile-wrp__value' and text()]"),"Detailview Engagement Likes Count"),
	
	DETAILVIEW_ENGAGEMENT_COMMENTS_COUNT(By.xpath("//div[text()='Comments']//preceding-sibling::span[@class='tile-wrp__value' and text()]"),"Detailview Engagement Comments Count"),
	
	DETAILVIEW_ENGAGEMENT_SHARES_COUNT(By.xpath("//div[text()='Shares']//preceding-sibling::span[@class='tile-wrp__value' and text()]"),"Detailview Engagement Shares Count"),
	
	DETAILVIEW_POSTCLICKS_IMAGE_VIEWS_COUNT(By.xpath("//div[text()='Image Views']//preceding-sibling::span[@class='tile-wrp__value' and text()]"),"DETAILVIEW_POSTCLICKS_IMAGE_VIEWS_COUNT"),
	DETAILVIEW_POSTCLICKS_LINK_CLICKS_COUNT(By.xpath("//div[text()='Link Clicks']//preceding-sibling::span[@class='tile-wrp__value' and text()]"),"DetailView Post Clicks Link Clicks Count"),
	DETAILVIEW_POSTCLICKS_OTHER_CLICKS_COUNT(By.xpath("//div[text()='Other Clicks']//preceding-sibling::span[@class='tile-wrp__value' and text()]"),"DetailView Post Clicks Other Clicks Cout"),

	DETAILVIEW_FACEBOOK_PAGE_NAME(By.xpath("//div[contains(@class,'pluginSkinLight')]//div[contains(@class,'_6a')]//a//abbr//span[@class='timestampContent']"),"DetailView Facebook page timestamp"),

	DETAILVIEW_FACEBOOK_TIMESTAMP(By.xpath("//div[contains(@class,'pluginSkinLight')]//div[@class='_6a _3-8w']//span[@class='_2_79 _50f7']"),"DetailView Facebook page name"),

	DETAILVIEW_FACEBOOK_ICON(By.xpath("//div[contains(@class,'pluginSkinLight')]//div[contains(@class,'clearfix')]//img[contains(@src,'static.xx.fbcdn')]"),"Detail View Facebook icon"),

	DETAILVIEW_FACEBOOK_TEXT(By.xpath("//div[contains(@class,'pluginSkinLight')]//div[@data-testid='post_message']//p[text()]"),"Detail View Facebook icon"),

	/** The linkedin detailview sign in. */
	LINKEDIN_DETAILVIEW_SIGN_IN(By.xpath("//p[contains(@class,'feed-cta-banner__text')]//a[text()='sign in']"),"Linkedin DetailView Sign in"),
	DETAILVIEW_POST_CLICKS(By.xpath("//div[text()='Post Clicks']//preceding-sibling::span[@class='tile-wrp__value' and text()]"),"Detail View Post Clicks"),

	DETAILVIEW_NEGATIVEFEEDBACK_HIDE_POST_COUNT(By.xpath("//div[text()='Hide Post']//preceding-sibling::span[@class='tile-wrp__value' and text()]"),"Detailview Negative Feedback Hide Post Count"),
	
	DETAILVIEW_NEGATIVEFEEDBACK_HIDE_ALL_POST_COUNT(By.xpath("//div[text()='Hide All Post']//preceding-sibling::span[@class='tile-wrp__value' and text()]"),"Detailview Negative Feedback Hide Post Count"),
	
	DETAILVIEW_NEGATIVEFEEDBACK_UNLIKE_PAGE_COUNT(By.xpath("//div[text()='Unlike Page']//preceding-sibling::span[@class='tile-wrp__value' and text()]"),"Detailview Negative Feedback Unlike Page Count"),
	
	DETAILVIEW_NEGATIVEFEEDBACK_REPORT_AS_SPAM_COUNT(By.xpath("//div[text()='Report as Spam']//preceding-sibling::span[@class='tile-wrp__value' and text()]"),"Detailview NegativeFeedback Report As Spam Count"),
	
	DETAILVIEW_LINKEDIN_POST_CLICK_NOT_APPLICABLE_COUNT(By.xpath("//div[text()='Post Clicks']//preceding-sibling::span[@class='tile-wrp__value' and text()='N/A']"),"Detailview Linkedin Post Clicks Not Applicable"),
	
	DETAILVIEW_LINKEDIN_POST_CLICK_APPLICABLE_COUNT(By.xpath("//div[text()='Post Clicks']//preceding-sibling::span[@class='tile-wrp__value' and not(text()='N/A')]"),"DETAILVIEW_LINKEDIN_POST_CLICK_APPLICABLE_COUNT"),
	
	/** The location selector button. */
	LOCATION_SELECTOR_BUTTON(By.xpath("//h3[text()='Location Selector']//following-sibling::div[@class='locAction']//span"), "Location selector button"),

	/** The location selector view. */
	LOCATION_SELECTOR_VIEW(By.xpath("//div[@class='modal-body']//h3[text()='Location Selector']//parent::div//parent::div//div[@class='asm-accord']"), "Location selector view"),

	/** The hubs dropdown. */
	HUBS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='accordion']//span[@class='lca-head' and text()='Hubs']"), "Hubs dropdown"),

	/** The location lists dropdown. */
	LOCATION_LISTS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='accordion']//span[@class='lca-head' and text()='Location Lists']"),
	        "LocationLists dropdown"),

	/** The locations dropdown. */
	LOCATIONS_DROPDOWN(By.xpath("//div[@class='modal-body']//div[@class='accordion']//span[@class='lca-head' and text()='Locations']"), "Locations dropdown"),

	/** The location selector dropdown list. */
	LOCATION_SELECTOR_DROPDOWN_LIST(By.xpath("//div[@class='modal-body']//div[@class='open card-header']//parent::div[@class='accordion-item']//following-sibling::div//ul[@class='hub-list']"),
	        "Location selector dropdown list"),

	/** The location selector search. */
	LOCATION_SELECTOR_SEARCH(By.xpath("//h3[text()='Location Selector']//following-sibling::div//input[@name='Locations']"), "Location selector search"),

	/** The select dropdown list. */
	SELECT_DROPDOWN_LIST("//div[@class='modal-body']//div[@class='open card-header']//parent::div[@class='accordion-item']//following-sibling::div//ul//li//span[contains(text(),'%s')]",
	        "Select dropdown list"),

	/** The selected dropdown list. */
	SELECTED_DROPDOWN_LIST(
	        "//div[@class='modal-body']//div[@class='open card-header']//parent::div[@class='accordion-item']//following-sibling::div//ul//li//input[@checked]//following-sibling::div//span[contains(text(),'%s')]",
	        "Selected dropdown list"),
	
	/** The selected dropdown list headcount. */
	SELECTED_DROPDOWN_LIST_HEADCOUNT(
	        "//div[@class='modal-body']//div[@class='open card-header']//parent::div[@class='accordion-item']//following-sibling::div//ul//li//input[@checked]//following-sibling::div//span[contains(text(),'%s')]//following-sibling::span","Selected dropdown List Count"),
	
	/** The location selector cancel button. */
	LOCATION_SELECTOR_CANCEL_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Cancel']"), "Location selector cancel button"),

	/** The location selector ok button. */
	LOCATION_SELECTOR_OK_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Ok']"), "Location selector ok button"),

	/** The previous month. */
	PREVIOUS_MONTH_PICKER(By.xpath("//div[@class='react-datepicker']//button[contains(@class,'datepicker__navigation--previous')]"), "Previous month."),

	/** The next month. */
	NEXT_MONTH_PICKER(By.xpath("//div[@class='react-datepicker']//button[contains(@class,'datepicker__navigation--next')]"), "Next month."),

	 /** The date picker. */
    DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]","Date Picker"),
    
	/** The facebook contents. */
	FACEBOOK_CONTENTS(By.xpath("//tbody//tr[not(@class='total')]//td//button//span[text()='Boost']"), "FACEBOOK_CONTENTS"),

	/** The sortby dropdowns. */
	SORTBY_DROPDOWNS(
	        By.xpath("//div[text()='Sort by']//parent::div//parent::div//div[@class='sortby-list__wrp']//div[@class='ds-dropdown']//following-sibling::div[@class='ds-dropdown']"),
	        "Sortby dropdowns"),
	
	/** The tags text. */
	TAGS_TEXT(By.xpath("//section[@class='item-g filter ra-filter-sec anlFilter']//div[@class='filter-item']//h3[contains(text(),Tags)]"),"tags Text"),
	
	 /** The tags inputbox. */
 	TAGS_INPUTBOX(By.xpath("//div[@class='filter-item']//div[@class='react-tags__search-wrapper']//input[@placeholder='Search tags']"),"Tags Input Box"),
	
	
	/** The favourite tags text. */
	FAVOURITE_TAGS_TEXT(By.xpath("//div[@class='filter-item']//following::div[contains(@class,'filter-item filter-item-tag__item')]//h3[text()='Favorite Tags']"),"Favourite Tags Text"),
	
	/** The enagagemnt hover text. */
	ENAGAGEMNT_HOVER_TEXT(By.xpath("//div[@class='common-tooltip--wrp' and text()='The number of comments, likes, shares and other interactions on posts published during the selected date range.']"),"Enagement Hover Text"),
	
	/** The rate hover text. */
	RATE_HOVER_TEXT(By.xpath("//div[@class='common-tooltip--wrp' and text()='The engagement rate percentage is a measure of engagement divided by impressions.']"),"Enagement Hover Text"),
	
	/** The favourite tags list. */
	FAVOURITE_TAGS_LIST(By.xpath("//div[@class='filter-item']//following::div[contains(@class,'filter-item filter-item-tag__item')]"),"Favourite Tags List"),
	
	/** The favourite tags edit. */
	FAVOURITE_TAGS_EDIT(By.xpath("//div[@class='edit-icon-post']//following-sibling::span[@class='cf-values' and text()='Edit']"),"FAVOURITE TAGS EDIT"),

	/** The EDI T FAVOURIT E TA G AN D CANC el. */
	EDIT_FAVOURITE_TAG_AND_CANCEl(
	        By.xpath("//div[@class='eftMain']//div[text()='Edit Favorite Tags']//ancestor::div//img[@alt='close']"),
	        "The Edit Favourite Tag And cancel"),

	/** The edit favouritetag describtion. */
	EDIT_FAVOURITETAG_DESCRIBTION(By.xpath("//p[@class='eft-descrptn' and text()]"), "The Edit Tag Describtion"),

	/** The favourite tags withstar. */
	FAVOURITE_TAGS_WITHSTAR("//span[text()='%s']//ancestor::div[@class='eft-items']//span[@class='checkmark fullSelectCheck']", "The Favourite Tags with Star"),

	/** The favourite tags withoutstar. */
	FAVOURITE_TAGS_WITHOUTSTAR("//span[text()='%s']//ancestor::div[@class='eft-items']//span[@class='checkmark']", "The Favourite Tag without star"),

	/** The favouritetag edit searchbox. */
	FAVOURITETAG_EDIT_SEARCHBOX(By.xpath("//div[@class='react-tags__search']//ancestor::div[@class='eftMain']//input[@class='react-tags__search-input']"), "The Favourite Tag Search Box"),

	/** The linkedin detailview like. */
	LINKEDIN_DETAILVIEW_LIKE(By.xpath("//span[contains(@class,'social-action-bar__button-text') and contains(text(),'Like')]"),"LinkedIn Detailview Like"),
	
	/** The linkedin detailview comment. */
	LINKEDIN_DETAILVIEW_COMMENT(By.xpath("//span[contains(@class,'social-action-bar__button-text') and contains(text(),'Comment')]"),"Linkedin DetailView Comment"),
	
	/** The linkedin detailview share. */
	LINKEDIN_DETAILVIEW_SHARE(By.xpath("//span[contains(@class,'embedded-social-share') and contains(text(),'Share')]"),"Linkedin DetailView Share"),

	LINKEDIN_SHARE_THE_POST(By.xpath("//*[contains(text(),'Share this post')]"),"LinkedIn Share the Post"),

	LINKEDIN_SHARE_THE_POST_CLOSE(By.xpath("//*[local-name()='icon' and @class='embedded-social-share__modal-dismiss-btn-icon lazy-loaded']//*[@class='artdeco-icon lazy-loaded']"),"Share The Post Close"),

	LINKEDIN_DETAILVIEW_ADD_A_COMMENT_TEXT(By.xpath("//p[contains(text(),'To view or add a comment, ')]"),"LinkedIn DetailView Add A comment Text"),
	
	LINKEDIN_DETAILVIEW_SIGIN_BUTTON(By.xpath("//p[contains(text(),'To view or add a comment, ')]//a[text()='sign in']"),"LinkedIn DetailView Sigin Button"),
	
	/** The common reels list. */
	///REELS ONLY
	COMMON_REELS_LIST(By.xpath("//td//div[@class='r-txt-left']//following-sibling::div[@class='sm-post r-flx']//p[contains(@class,'sm-message r-ml2')]"),"Common Reels List name"),
	
	/** The commom reels. */
	 COMMON_REELS_SECOND(By.xpath("//tbody//tr//td[contains(@class,'sort-active')]//div[@class='sm-post r-flx']//following::p[2]"),"Common Second Reels"),
	
   /** The contents loading symbol. */
   CONTENTS_LOADING_SYMBOL("//div[contains(@class,'loader')]//span[@class='info-state']//ancestor::div[@class='content-g']","Contents Loading Symbol"),
	
	/** The type filter reelsonly button. */
	TYPE_FILTER_REELSONLY_BUTTON(By.xpath("//h3[text()='Type']//parent::div//span[text()='Reels Only']"),"Reels Only Button"),
	
	/** The reelsonly button active. */
	REELSONLY_BUTTON_ACTIVE(By.xpath("//label[@class='active']//*[contains(@class,'input') and @value='reels']"),"Reels Only Button Acitve"),
	
	/** The reels detailpage. */
	REELS_DETAILPAGE(By.xpath("//div[@class='modal-content']"),"Reels Detail Page Load"),
	
	/** The reels detailpage postid. */
	REELS_DETAILPAGE_POSTID(By.xpath("//div[contains(@class,'as-modal-tab')]//h3[@class='prime-post-id']"),"Reels Detail Page PostID"),
	
	/** The reels detailpage date. */
	REELS_DETAILPAGE_DATE(By.xpath("//div[contains(@class,'as-modal-tab')]//span[@class='prime-post-date']"),"Reels Detail Page Date"),
	
	/** The reels detailpage fbicon. */
	REELS_DETAILPAGE_FBICON(By.xpath("//div[contains(@class,'as-modal-tab')]//following-sibling::div[@class='fltr-imc selectsocial']//button//img[contains(@src,'fb-platform.svg')]"),"Reels Detail Page FBicon"),
	
	/** The reels detailpage instaicon. */
	REELS_DETAILPAGE_INSTAICON(By.xpath("//div[contains(@class,'as-modal-tab')]//following-sibling::div[@class='fltr-imc selectsocial']//button//img[contains(@src,'instagram-platform.svg')]"),"Reels Detail Page Instagram icon"),
    
	/** The reels detailpage fbreels iframe. */
	REELS_DETAILPAGE_FBREELS_IFRAME(By.xpath("//div[@class='as-modal-left-card']//iframe[contains(@src,'https://www.facebook.com')]"),"Reels Detail Page FB Frame"),
	
	/** The reels detailpage instareels iframe. */
	REELS_DETAILPAGE_INSTAREELS_IFRAME(By.xpath("//div[@class='as-modal-left-card']//iframe[contains(@src,'https://www.instagram.com')]"),"REELS_DETAILPAGE_INSTAREELS_IFRAME"),
	
	/** The reels detailpage postdescrption. */
	REELS_DETAILPAGE_POSTDESCRPTION(By.xpath("//div[@class='as-modal-left-card']//div[@class='sm-message']//p[text()]"),"Reels Descrption"),
	
	/** The reels detailpage video. */
	REELS_DETAILPAGE_VIDEO(By.xpath("//div[contains(@class,'r-flx full-width')]//video[contains(@src,'.mp4')]"),"Reels detail page Video"),
	
	/** The reels detailpage uniqueimpression. */
	REELS_DETAILPAGE_UNIQUEIMPRESSION(By.xpath("//div[text()='Unique Impression']//preceding-sibling::span[@class='tile-wrp__value' and text()]"),"Reels DetailPage UniqueImression value"),
	
	/** The reels detailpage likesvalue. */
	REELS_DETAILPAGE_LIKESVALUE(By.xpath("//div[text()='Likes']//preceding-sibling::span[@class='tile-wrp__value' and text()]"),"Reels Like Value"),
	
	/** The reels detailpage sharesvalue. */
	REELS_DETAILPAGE_SHARESVALUE(By.xpath("//div[text()='Shares']//preceding-sibling::span[@class='tile-wrp__value' and text()]"),"Reels Shares Value"),
	
	/** The reels detailpage commentsvalue. */
	REELS_DETAILPAGE_COMMENTSVALUE(By.xpath("//div[text()='Comments']//preceding-sibling::span[@class='tile-wrp__value' and text()]"),"Reels Comments Value"),
	
	/** The reels detailpage avgtimewathcedvalue. */
	REELS_DETAILPAGE_AVGTIMEWATHCEDVALUE(By.xpath("//span[text()='Reels Insights']//following::div[text()='Average Time Watched']//preceding-sibling::span[text()]"),"Reels DetailPage Avg Time Watched Value"),
	
	/** The reels detailpage totaltimewathcedvalue. */
	REELS_DETAILPAGE_TOTALTIMEWATHCEDVALUE(By.xpath("//span[text()='Reels Insights']//following::div[text()='Total Time Watched']//preceding-sibling::span[text()]"),"Reels DetailPage Total Time Watched Value"),
	
	/** The reels detailpage playcountvalue. */
	REELS_DETAILPAGE_PLAYCOUNTVALUE(By.xpath("//span[text()='Reels Insights']//following::div[text()='Play Count']//preceding-sibling::span[text()]"),"Reels DetailPage Play Count Value"),
	
	/** The reels detailpage close button. */
	REELS_DETAILPAGE_CLOSE_BUTTON(By.xpath("//div[@class='modal-content']//img[@class='mod__close--img']"),"Reels DetailPage Close Icon"),
	
	/** The reels detailpage previous button. */
	REELS_DETAILPAGE_PREVIOUS_BUTTON(By.xpath("//div[@class='modal-content']//div[@class='navigate-icon prev-icon']"),"Reels DetailPage Prevoius Icon"),
	
	/** The reels detailpage next button. */
	REELS_DETAILPAGE_NEXT_BUTTON(By.xpath("//div[@class='modal-content']//div[@class='navigate-icon next-icon']"),"Reels DetailPage Next Icon"),
	
	/** The aveargetime watched button. */
	AVEARGETIME_WATCHED_BUTTON(By.xpath("//tr[@data-testid='tr']//th//span[text()='Average Time Watched']"), "Average Time Watched button"),
	
	/** The totaltime watched button. */
	TOTALTIME_WATCHED_BUTTON(By.xpath("//tr[@data-testid='tr']//th//span[text()='Total Time Watched']"), "Average Time Watched button"),
	
	/** The playcount button. */
	PLAYCOUNT_BUTTON(By.xpath("//tr[@data-testid='tr']//th//span[text()='Play Count']"), "Average Time Watched button"),
	
	
	/** The avgtime watched count. */
	AVGTIME_WATCHED_COUNT(By.xpath("//span[text()='Average Time Watched']//following::tr[@class='total']//td[5]"),"Average Count Value"),
	
	/** The totaltime count count. */
	TOTALTIME_COUNT_COUNT(By.xpath("//span[text()='Average Time Watched']//following::tr[@class='total']//td[6]"),"Reels Page Total Time Button"),
	
	/** The playcount count. */
	PLAYCOUNT_COUNT(By.xpath("//span[text()='Average Time Watched']//following::tr[@class='total']//td[7]"),"Reels page PlayCount"),
	
	/** The reels contents. */
	REELS_CONTENTS(By.xpath("//div//div[contains(@class,'content-table__wrp reels-data-active')]//table"),"Reels page Contents"),
	
	
	/** The instagram reels contents. */
	INSTAGRAM_REELS_CONTENTS(By.xpath("//div[contains(@class,'table-size-wrp resuseTable nd-y content-table__wrp reels-data-active')]//table//tbody//following-sibling::tbody//tr"),"Instagram Reels page Contents"),
	
	/** The facebook reels contents. */
	FACEBOOK_REELS_CONTENTS(By.xpath("//tbody//td//img[contains(@src,'https://rallio-production-uploads.s3.amazonaws.com/rehost-fb')]"),"Facebook Reels page Contents"),
	
	/** The location selector hub tab. */
	LOCATION_SELECTOR_HUB_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Hubs']"),
			"Location Selecter Hub tab."),
	
	/** The location selector hub tab open. */
	LOCATION_SELECTOR_HUB_TAB_OPEN(
			By.xpath("//img[contains(@src,'hubs')]//ancestor::ul"),
			"Location Selecter Hub Tab Open."),
	
	/** The favourite tag firsttag. */
	FAVOURITE_TAG_FIRSTTAG(
			By.xpath("//h3[text()='Favorite Tags']//following::div//span[@class='fav-tags'][1]"),"Favourtie tag first tag"),
	
	/** The likes button inengagement place. */
	LIKES_BUTTON_INENGAGEMENT_PLACE(By.xpath("//div[contains(@class,'mainContent')]//table//thead//th//span//span[text()='Likes']"),
			"Likes button Header"),

	/** The local likes countlist. */
	LOCAL_LIKES_COUNTLIST(By.xpath("//span[text()='Likes']//ancestor::div//tr//td[3]//div[@class='r-flx r-flx-ac']//span[text()]"),
			"Local Likes  List values"),
	
	/** The local Comments countlist. */
	LOCAL_COMMENT_COUNTLIST(By.xpath("//span[text()='Comments']//ancestor::div//tr//td[3]//div[@class='r-flx r-flx-ac']//span[text()]"),
			"Local Comments  List values"),
	
	LOCAL_SHARE_COUNTLIST(By.xpath("//span[text()='Shares']//ancestor::div//tr//td[3]//div[@class='r-flx r-flx-ac']//span[text()]"),
			"Local Share  List values"),
	
	LOCAL_CLICKS_COUNTLIST(By.xpath("//span[text()='Clicks']//ancestor::div//tr//td[3]//div[@class='r-flx r-flx-ac']//span[text()]"),
			"Local Click  List values"),
	
	/** The local impression countlist. */
	LOCAL_IMPRESSION_COUNTLIST(By.xpath("//span[text()='Impressions']//ancestor::div//tr//td[2]//div[@class='r-flx r-flx-ac']//span[text()]"),
			"Local Impression  List values"),
	
	/** The comments button inengagement place. */
	COMMENTS_BUTTON_INENGAGEMENT_PLACE(By.xpath("//div[contains(@class,'mainContent')]//table//thead//th//span//span[text()='Comments']"),
			"Comments button Header"),
	
	/** The shares button inengagement place. */
	SHARES_BUTTON_INENGAGEMENT_PLACE(By.xpath("//div[contains(@class,'mainContent')]//table//thead//th//span//span[text()='Shares']"),
			"Shares button Header"),
	
	/** The clicks button inengagement place. */
	CLICKS_BUTTON_INENGAGEMENT_PLACE(By.xpath("//div[contains(@class,'mainContent')]//table//thead//th//span//span[text()='Clicks']"),
			"clicks button Header"),

	
	/** The likes count list. */
	LIKES_COUNT_LIST(By.xpath("//span[text()='Likes']//ancestor::table//tbody//following-sibling::tbody//tr//td[4]//span[text()]"),"Likes Count List"),
	
	/** The comments count list. */
	COMMENTS_COUNT_LIST(By.xpath("//span[text()='Comments']//ancestor::table//tbody//following-sibling::tbody//tr//td[4]//span[text()]"),"Comments Count List"),
	
	/** The shares count list. */
	SHARES_COUNT_LIST(By.xpath("//span[text()='Shares']//ancestor::table//tbody//following-sibling::tbody//tr//td[4]//span[text()]"),"Shares Count List"),
	
	/** The clicks count list. */
	CLICKS_COUNT_LIST(By.xpath("//span[text()='Clicks']//ancestor::table//tbody//following-sibling::tbody//tr//td[4]//span[text()]"),"Clicks Count List"),
	
	/** The engagement count list. */
	ENGAGEMENT_COUNT_LIST(By.xpath("//span[text()='Engagement']//ancestor::table//tbody//following-sibling::tbody//tr//td[4]//span[text()]"),"Engagement Count List"),
	
	/** The impressions count list. */
	IMPRESSIONS_COUNT_LIST(By.xpath("//span[text()='Impressions']//ancestor::table//tbody//following-sibling::tbody//tr//td[3]//span[text()]"),"Impression Count List"),
	
	/** The local impressions count list. */
	LOCAL_IMPRESSIONS_COUNT_LIST(By.xpath("//span[text()='Impressions']//ancestor::table//tbody//following-sibling::tbody//tr//td[2]//span[text()]"),"Local Impression Count List"),
	
	LOCAL_IMPRESSIONS_ORGANIC_COUNT_LIST(By.xpath("//span[text()='Impressions (Organic)']//ancestor::table//tbody//following-sibling::tbody//tr//td[2]//span[text()]"),"Local Impressions Organic Count List"),
	
	LOCAL_IMPRESSIONS_PAID_COUNT_LIST(By.xpath("//span[text()='Impressions (Paid)']//ancestor::table//tbody//following-sibling::tbody//tr//td[2]//span[text()]"),"Local Impressions Paid Count List"),
	
	/** The impressions count listvalue. */
	IMPRESSIONS_COUNT_LISTVALUE(By.xpath("//p[@class='sm-message r-ml2 ']//parent::div[@class='sm-post r-flx']//ancestor::tr//td[2]//div[@class='r-flx r-flx-ac']//span"),"Impression Count Lists"),
	
	IMPRESSIONS_ORGANIC_COUNT_LIST(By.xpath("//span[text()='Impressions (Organic)']//ancestor::table//tbody//following-sibling::tbody//tr//td[3]//div//span[text()]"),"Impressions Organic Count"),
	
	IMPRESSION_PAID_COUNT_LIST(By.xpath("//span[text()='Impressions (Paid)']//ancestor::table//tbody//following-sibling::tbody//tr//td[3]//div//span[text()]"),"Impression Paid Count List"),
	
	/** The published count list. */
	PUBLISHED_COUNT_LIST(By.xpath("//span[text()='Published']//ancestor::table//tbody//following-sibling::tbody//tr//td[2]//span[text()]"),"Published Count List"),
	
	/** The date count list. */
	DATE_COUNT_LIST(By.xpath("//tr//following::tr//span[@class='sm-date']"),"Date Count List"),
	
	/** The totaltime wathced count list. */
	TOTALTIME_WATHCED_COUNT_LIST(By.xpath("//tr//td//div//span[text()='Total Time Watched']//parent::span//ancestor::td[@class=' pivoted']"),"Toatl Time Watched Count List"),
	
	/** The averagetime wathced count list. */
	AVERAGETIME_WATHCED_COUNT_LIST(By.xpath("//span[text()='Average Time Watched']//parent::div//parent::div//parent::td[text()]"),"AveargeTime Watched Count List"),
	
	/** The playcount count list. */
	PLAYCOUNT_COUNT_LIST(By.xpath("//tr//td//div//span[text()='Play Count']//parent::span//ancestor::td[@class=' pivoted']"),"AveargeTime Watched Count List"),
	
	LINKEDIN_DETAIVIEW_LINKEDIN_ICON(By.xpath("//button[@data-tracking-control-name='public_post_embed_social-share_linkedin']//icon"),"Linkedin Detailview Linkedin icon"),

    LINKEDIN_DETAILVIEW_FACEBOOK_ICON(By.xpath("//button[@data-tracking-control-name='public_post_embed_social-share_facebook']//icon"),"Linkedin Detailview facbook Icon"),

	LINKEDIN_DETAILVIEW_TWITTER_ICON(By.xpath("//button[@data-tracking-control-name='public_post_embed_social-share_twitter']//icon"),"Linkedin Detailview twitter Icon"),

	LINKEDIN_ICON_DETAILVIEW_SHARE_IN_POST(By.xpath("//span[text()='Share in a post']"),"Share in a Post"),

    LINKEDIN_ICON_DETAILVIEW_SHARE_POST_FIELD(By.xpath("//div[contains(@class,'share-creation-state')]//div[@class='editor-content ql-container']//div[@class='ql-editor ql-blank']"),"Linkedin Icon Detailview Share post Field"),

    LINKEDIN_ICON_DETAILVIEW_SHARE_POST_BUTTON(By.xpath("//span[@class='artdeco-button__text' and text()='Post']"),"Linkedin icon Detailview Share Post Button"),

	LINKEDIN_ICON_DETAILVIEW_SHARE_POST_SUCCESSFUL(By.xpath("//span[text()='Post successful.']"),"Linkedin Icon Detailview Share Post SuccessFul"),

	LINKEDIN_ICON_DETAILVIEW_SHARE_POST_VIEW_POST_BUTTON(By.xpath("//a[text()='View post']"),"LINKEDIN_ICON_DETAILVIEW_SHARE_POST_VIEW_POST_BUTTON"),

	TEXT("//*[text()='%s']","Yes the text is present"),

	/** The reels post bytext. */
	REELS_POST_BYTEXT("//p[contains(@class,'sm-message') and contains(text(),'%s')]","Reels Post with a tag name"),
	
	/** The favourite active tag. */
	FAVOURITE_ACTIVE_TAG(By.xpath("//h3[text()='Favorite Tags']//following::div[2]//span[@class='fav-tags active' and text()='green tea']"),"Active Favourite Green Tea Tag"),
	
	/** The favourite active tag bytagname. */
	FAVOURITE_ACTIVE_TAG_BYTAGNAME("//h3[text()='Favorite Tags']//following::div//span[@class='fav-tags active' and contains(text(),'%s')]","Active Favourite Tag By Name"),
	
	/** The reels date range. */
	REELS_DATE_RANGE("//div[@class='date-range']//span[contains(text(),'%s')]","Reels From  and To Date"),
	
	/** The totals row value. */
	TOTALS_ROW_VALUE(By.xpath("//tr[@class='total']//td[@colspan='3']//following-sibling::td"),"Active Favourite Green Tea Tag"),
	
	
	/** The location selector. */
	LOCATION_SELECTOR(By.xpath("//section//*[text()='Location Selector']//parent::div//span[@class='lcs-name']"),
			"Location Selecter."),

	/** The location selector open. */
	LOCATION_SELECTOR_OPEN(By.xpath(
			"//div[@class='asm-btn']//parent::div[@class='modal-footer']//preceding-sibling::div[@class='asm-accord']"),
			"Location Selecter Open."),

	/**  Location search option. */ 
	LOCATION_SEARCH(By.xpath("//input[@type='text' and @name='Locations']") , "Location selector Search option"), 

//	/** The location selector hub tab. */
//	LOCATION_SELECTOR_HUB_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Hubs']"),
//			"Location Selecter Hub tab."),
//
//	/** The location selector hub tab open. */
//	LOCATION_SELECTOR_HUB_TAB_OPEN(
//			By.xpath("//img[contains(@src,'hubs')]//ancestor::div[contains(@class,'collapse show')]"),
//			"Location Selecter Hub Tab Open."),

	/** The location selector location tab. */
	LOCATION_SELECTOR_ALL_LOCATION_TAB(By.xpath("//input[@name='selectedLocation']//following-sibling::span[text()='All Locations']"), "The All Locations selector tab."),

	/** The location selector byname. */
	LOCATION_SELECTOR_BYNAME("//div[contains(@class,'list-item')]//div[@class='lvt-details']//h3[contains(text(),'%s')]","The Location Selector By name"),
	
	/** The location selector location tab. */
	LOCATION_SELECTOR_LOCATION_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Locations']"),
			"Location Selecter Location tab."),

	/** The location selector locationlist tab. */
	LOCATION_SELECTOR_LOCATIONLIST_TAB(By.xpath("//div[contains(@class,'accordion')]//span[text()='Location Lists']"),
			"Location Selecter Location List tab."),

	/** The location selector hub option. */
	LOCATION_SELECTOR_HUB_OPTION(By.xpath("//span[@class='lca-head' and text()='Hubs']"),
			"Location Selecter hub option."),


	/** The location selector locationlist tab. */
	LOCATION_SELECTOR_LOCATIONLIST_TAB_OPEN(
			By.xpath("//div[contains(@class,'accordion')]//span[text()='Location Lists']"),
			"Location Selecter Location List tab Open"),

	/** The location selector location tab open. */
	LOCATION_SELECTOR_LOCATION_TAB_OPEN(
			By.xpath("//img[contains(@src,'location')]//ancestor::div[contains(@class,'collapse show')]"),
			"Location Selecter Location Tab Open"),

	/** The location selector dropdown user. */
	LOCATION_SELECTOR_DROPDOWN_USER("//div//ul[@class='hub-list']//span[contains(text(),\"%s\")]",
			"Location Selecter Dropdown User."),

	/** The list of hubs. */
	LIST_OF_HUBS(By.xpath("//img[contains(@src,'hub')]//parent::label//span[@class='lcs-name']"), "List of Hubs"),

	/** The list of locations. */
	LIST_OF_LOCATIONS(By.xpath(
			"//div[contains(@class,'collapse show')]//img[contains(@src,'location') and not(contains(@src,'Lists'))]"),
			"List of Locations"),

	/** The list of locationlist. */
	LIST_OF_LOCATIONLIST(By.xpath(
			"//div[@class='card']//div[@class='collapse show']//ul[@class='hub-list']//li//label//span[contains(@class,'list')]"),
			"List of Location list"),

	// LOCATION_SELECTOR_CHOOSE_HUB(By.xpath("//div[@class='card']//div[@class='collapse
	// show']//ul[@class='hub-list']//li//label//span[text()='']"), "Location
	// Selecter Hub Tab Open."),

	// LOCATION_SELECTOR_ACTIVE_HUB(By.xpath("//div[@class='card']//div[@class='collapse
	// show']//ul[@class='hub-list']//li//label//span[contains(@class,'active') and
	// text()='Alvarado']"), "Location Selecter Hub Tab Open."),

	/** The location selector ok button. */
//	LOCATION_SELECTOR_OK_BUTTON(By.xpath("//div[@class='asm-btn']//div//button[text()='Ok']"),
//			"Location Selecter Ok Button"),

	/** The location selector search tab. */
	LOCATION_SELECTOR_SEARCH_TAB(By.xpath("//div[@class='asm-lf']//input[@placeholder = 'Search']"),
			"Location Selecter Search Tab"),

//	/** The location selector cancel button. */
//	LOCATION_SELECTOR_CANCEL_BUTTON(By.xpath("//div[@class='asm-btn']//div//button[text()='Cancel']"),
//			"Location Selector Cancel Button"),

	/** The location selector close button. */
	LOCATION_SELECTOR_CLOSE_BUTTON(By.xpath("//img[@class='close-icon']"), "Location Selector Close Button"),

	/** The locations filter modal. */
	LOCATIONS_FILTER_MODAL(By.xpath("//div[@class='modal-content']//div[@class='modal-body']"),
			"Locations filter modal"),

	/** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back To Top Button"),

	/** The tag page contents. */
	//TAGS ENUMS
	TAG_PAGE_CONTENTS(By.xpath("//div[contains(@class,'tg-s-tabs')]//following-sibling::div[contains(@class,'list tagsList ')]"), "Tag Page Contents"),
	
	/** The tag page content name. */
	TAG_PAGE_CONTENT_NAME(By.xpath("//div[contains(@class,'list tagsList ')]//*[local-name()='g'][@class='highcharts-axis-labels highcharts-xaxis-labels']"),"TAG_PAGE_CONTENT_NAME"),
	
	/** The type filter allposts filter. */
	TYPE_FILTER_ALLPOSTS_FILTER(By.xpath("//h3[text()='Type']//parent::div//span[text()='All Posts']"),"Tags Filter Button"),

	/** The type filter tags filter. */
	TYPE_FILTER_TAGS_FILTER(By.xpath("//h3[text()='Type']//parent::div//span[text()='Tags']"),"Tags All Posts Filter"),
	
	/** The type filter tags filter active. */
	TYPE_FILTER_TAGS_FILTER_ACTIVE(By.xpath("//h3[text()='Type']//parent::div//label[@class='active']//span[text()='Tags']"),"TYPE_FILTER_TAGS_FILTER_ACTIVE"),
	
	/** The tags page listview text. */
	TAGS_PAGE_LISTVIEW_TEXT(By.xpath("//div[@class='back-all__wrp']//span[text()='List' and text()=' View']"),"Tags Page List View Text Button"),
	
	/** The tags page published text. */
	TAGS_PAGE_PUBLISHED_TEXT(By.xpath("//div[@class='tg-steps step active']//h5[text()='Published']"),"Tags Page Published Text Button"),
	
	/** The tags page engagement text. */
	TAGS_PAGE_ENGAGEMENT_TEXT(By.xpath("//div[@class='tg-steps step ']//h5[text()='Engagement']"),"Tags Page Engagement Text Button"),
	
	/** The tags page impression text. */
	TAGS_PAGE_IMPRESSION_TEXT(By.xpath("//div[@class='tg-steps step ']//h5[text()='Impressions']"),"Tags Page Impressions Text Button"),
	
	/** The tags page rate text. */
	TAGS_PAGE_RATE_TEXT(By.xpath("//div[@class='tg-steps step ']//h5[text()='Rate']"),"Tags Page Rate Text Button"),
	
	/** The date range box. */
	DATE_RANGE_BOX(By.xpath("//div[@class='filter-item date-picker dpt-on']//div[contains(@class,'dp-from')]//following::div[contains(@class,'dp-to')]"),"Date range Box"),
	
	/** The tags page tagscount. */
	TAGS_PAGE_TAGSCOUNT(By.xpath("//*[local-name()='g' and contains(@class,'highcharts-bar')]//*[local-name()='text']"),"TAGS_PAGE_TAGSCOUNT"),
	
	/** The favourite tag by name. */
	FAVOURITE_TAG_BY_NAME("//div[@class='fts']//span[@class='fav-tags' and text()='%s']","FAVOURITE_TAG_BY_NAME"),
	
	/** The favourite tag by name active. */
	FAVOURITE_TAG_BY_NAME_ACTIVE("//div[@class='fts']//span[@class='fav-tags active' and text()='%s']","FAVOURITE_TAG_BY_NAME"),
	
	/** The tags header button by name. */
	TAGS_HEADER_BUTTON_BY_NAME("//div[contains(@class,'tg-s-tabs')]//div[@class='tg-steps step ']//img[@alt='%s']", "TAGS_HEADER_BUTTON_BY_NAME"),

	/** The tags header button by name active. */
	TAGS_HEADER_BUTTON_BY_NAME_ACTIVE("//div[contains(@class,'tg-s-tabs')]//div[@class='tg-steps step active']//img[@alt='%s']", "TAGS_HEADER_BUTTON_BY_NAME_ACTIVE"),
	
	/** The tags engagement header with filter type. */
	TAGS_ENGAGEMENT_HEADER_WITH_FILTER_TYPE("//div[@class='tg-steps step active']//img[@alt='Engagement'] //parent::div//h5[text()='Engagement' and text()='(%s)']",
			"TAGS_ENGAGEMENT_HEADER_WITH_FILTER_TYPE"),
	
	/** The tags impressions header with filter type. */
	TAGS_IMPRESSIONS_HEADER_WITH_FILTER_TYPE("//div[@class='tg-steps step active']//img[@alt='Impressions'] //parent::div//h5[text()='Impressions' and text()='(%s)']",
			"TAGS_IMPRESSIONS_HEADER_WITH_FILTER_TYPE"),
	
	/** The tags chart view button. */
	TAGS_CHART_VIEW_BUTTON(By.xpath("//span[text()='Chart' and text()=' View']//parent::div//img[contains(@src,'chart')]"),"TAGS_CHART_VIEW_BUTTON"),

	/** The tags list view button. */
	TAGS_LIST_VIEW_BUTTON(By.xpath("//span[text()='List' and text()=' View']//parent::div//img[contains(@src,'view')]"),"TAGS_LIST_VIEW_BUTTON"),
	
	/** The tags table. */
	TAGS_TABLE(By.xpath("//table[contains(@class,'table-cmn')]//thead//tr"),"TAGS_TABLE_COLUMN_BY_NAME"),
	
	/** The tags table total count. */
	TAGS_TABLE_TOTAL_COUNT(By.xpath("//table[contains(@class,'table-cmn')]//thead//tr//th[1]//span//span"),"TAGS_TABLE_TOTAL_COUNT"),
	
	/** The tags table list. */
	TAGS_TABLE_LIST(By.xpath("//div[contains(@class,'tagsList')]//table//tbody//tr//td[1]//div[2]//span"),"TAGS_TABLE_LIST"),
	
	/** The published column list. */
	PUBLISHED_COLUMN_LIST(By.xpath("//span[text()='Published ']//ancestor::table//tbody//tr//td[2]//span[@class='value1' and text()]"),"PUBLISHED_TABLE_LIST"),
	
	/** The impressions column list. */
	IMPRESSIONS_COLUMN_LIST(By.xpath("//span[text()='Impressions ']//ancestor::table//tbody//tr//td[3]//span[@class='value1' and text()]"),"IMPRESSIONS_COLUMN_LIST"),
	
	/** The engagements column list. */
	ENGAGEMENTS_COLUMN_LIST(By.xpath("//span[text()='Engagement ']//ancestor::table//tbody//tr//td[4]//span[@class='value1' and text()]"),"ENGAGEMENTS_COLUMN_LIST"),
	
	/** The rate column list. */
	RATE_COLUMN_LIST(By.xpath("//span[text()='Rate ']//ancestor::table//tbody//tr//td[5]//span[@class='value1' and text()]"),"RATE_COLUMN_LIST"),
	
	IMPRESSION_COLOUMN_COUNTLIST(By.xpath("//span[text()='Impressions']//ancestor::table//tbody//following-sibling::tbody//tr//td[3]//span"),"Impression Coloumn CountList"),
	
	/** The impressions column list. */
	LOCAL_IMPRESSIONS_COLUMN_LIST(By.xpath("//span[text()]//parent::span//parent::div//parent::td//div[@class='r-flx r-flx-ac']//span[@class='r-mr2 r-txt-ws__nwrp cur-normal']"),"Local IMPRESSIONS_COLUMN_LIST"),
	
	LOCAL_ENGAGEMENT_COLUMN_LIST(By.xpath("//span[text()='Engagement']//ancestor::table//tbody//following-sibling::tbody//tr//td[3]//span[text()]"),"Loacl Engagement Column list"),
	
	LOCAL_RATE_COLUMN_LIST(By.xpath("//span[text()='Rate']//ancestor::table//tbody//following-sibling::tbody//tr//td[4]//span[text()]"),"Loacl Rate Column list"),
	
	RATE_COLOUMN_LIST(By.xpath("//span[text()='Rate']//ancestor::table//tbody//following-sibling::tbody//tr//td[5]//span[text()]"),"Rate Column List"),
	
	/** The tags table column by name. */
	TAGS_TABLE_COLUMN_BY_NAME("//table//thead//tr//th//span[starts-with(text(),'%s')]","TAGS_TABLE_COLUMN_BY_NAME"),
	
	/** The no data found. */
	NO_DATA_FOUND(By.xpath("//*[text()='No Data Found.']"), "NO_DATA_FOUND"),
		
	/** The ai type ai assisted filter. */
	AI_TYPE_AI_ASSISTED_FILTER(By.xpath("//h3[text()='AI Type']//parent::div[@class='filter-item']//input[@class='option-input radio']//following-sibling::span[text()='AI Assisted']"),"AI TYPE AI ASSISTED FILTER"),
	
	/** The ai type non ai assisted filter. */
	AI_TYPE_NON_AI_ASSISTED_FILTER(By.xpath("//h3[text()='AI Type']//parent::div[@class='filter-item']//input[@class='option-input radio']//following-sibling::span[text()='Non-AI Assisted']"),"Non Ai Assisted Filter"),
	
	/** The ai type ai assisted filter active. */
	AI_TYPE_AI_ASSISTED_FILTER_ACTIVE(By.xpath("//h3[text()='AI Type']//parent::div[@class='filter-item']//input[@class='option-input radio']//following-sibling::span[text()='AI Assisted']"),"AI_TYPE_AI_ASSISTED_FILTER_ACTIVE"),
	
	/** The ai type non ai assisted filter active. */
	AI_TYPE_NON_AI_ASSISTED_FILTER_ACTIVE(By.xpath("//h3[text()='AI Type']//parent::div[@class='filter-item']//input[@class='option-input radio']//following-sibling::span[text()='AI Assisted']"),"AI_TYPE_NON_AI_ASSISTED_FILTER_ACTIVE"),

	/** The tags table list by column name. */
	TAGS_TABLE_LIST_BY_COLUMN_NAME("//table//tbody//tr//td//span[starts-with(text(),'%s')]//parent::span//parent::div//following-sibling::div//span","TAGS_TABLE_LIST_BY_COLUMN_NAME"),
	
	/** The multiple location list. */
	MULTIPLE_LOCATION_LIST(By.xpath("//tr//td//div[@class='sm-post r-flx']//img[@class='ca-location-img']"),"Multiple location list"),

	/** The multiple location table location data */
	MULTIPLE_LOCATION_TABLE_LOCATION_DATA("//table[contains(@class,'responsiveTable')]//div[@class='ml-fteen']//div[contains(@class,'ca-location-name') and text()='%s']","Multiple location table location data"),

	/** The One locations button. */
	ONE_LOCATIONS_BUTTON(By.xpath("//tbody//span[text()='One location']"), "One locations button"),

	TABLE_LIST_CONTENT_FOOTER(By.xpath("(//div[contains(@class,'tagsList')]//table//tbody//tr//td[1]//div[2]//span)[last()]"),"Table List Content Footer"),

	;
	
	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new analytics tab contents page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private AnalyticsTabContentPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new analytics tab contents page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private AnalyticsTabContentPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return byLocator;
	}

	/**
	 * Gets the by xpath.
	 *
	 * @return the by xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}
}




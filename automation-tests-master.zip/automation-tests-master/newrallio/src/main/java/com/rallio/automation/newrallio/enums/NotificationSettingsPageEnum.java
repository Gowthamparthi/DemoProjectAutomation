package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum NotificationSettingsPageEnum.
 */
public enum NotificationSettingsPageEnum {
	
	/** The page load. */
	PAGE_LOAD(By.xpath(
			"//div//h3[text()='Notification Settings']//parent::div//parent::div[@class='notification-settings-content-section']"),
			"Notification Settings Page load"),
	
	CLOSE_BUTTON(By.xpath(
			"//div[@class='mod__close--icon']//img[contains(@src,'close2.svg')]"),
			"Notification Settings Page Close Button"),

	/** The notification settings headline text. */
	NOTIFICATION_SETTINGS_HEADLINE_TEXT(
			By.xpath("//div[@class='notification-settings-content-section']//div//h3[text()='Notification Settings']"),
			"Notification Settings Text"),

	/** The receive sms notification. */
	RECEIVE_SMS_NOTIFICATION(By.xpath(
			"//img[contains(@src,'arrow-down-grey.svg')]//parent::div//parent::div[text()='Receive SMS Notifications']"),
			"Receive SMS Notification."),
	
	RECEIVE_SMS_NOTIFICATION_DROPDOWN_CLOSED(By.xpath(
			"//div[text()='Receive SMS Notifications']//div//img[@class='arrow-point']"),
			"Receive SMS Notification Dropdown Closed."),

	/** The sms notification save button. */
	SMS_NOTIFICATION_SAVE_BUTTON(By.xpath(
			"//div[text()='Receive SMS Notifications']//parent::div//following-sibling::div//div//div[@class='save-btn ap-actions']//div//button[text()='Save']"),
			"SMS Notification Save Button."),

	/** The sms notification phone number box. */
	SMS_NOTIFICATION_PHONE_NUMBER_BOX(By.xpath(
			"//img[contains(@src,'arrow-down-grey.svg')]//parent::div//parent::div[text()='Receive SMS Notifications']"),
			"Phone Number Box"),

	/** The sms notification toggle button. */
	SMS_NOTIFICATION_TOGGLE_BUTTON(By.xpath(
			"//div[text()='Receive SMS Notifications']//parent::div//following-sibling::div//div//div[@class='sms-notify-togle-section']//div//div//div[contains(@class,'react-switch-section')]"),
			"SMS Notification Toggle Button."),

	/** The sms notification description. */
	SMS_NOTIFICATION_DESCRIPTION(By.xpath(
			"//div//p[contains(text(),'Turning on this feature will send the user SMS notifications when the assets')]//following-sibling::p[contains(text(),'turn off the SMS notifications')]"),
			"SMS_Notification_Description"),

	/** The receive email notification. */
	RECEIVE_EMAIL_NOTIFICATION(By.xpath(
			"//img[contains(@src,'arrow-down-grey.svg')]//parent::div//parent::div[text()='Receive Email Notifications']"),
			"Receive Email Notification."),
	
	RECEIVE_EMAIL_NOTIFICATION_DROPDOWN_CLOSED(By.xpath(
			"//div[text()='Receive Email Notifications']//div//img[@class='arrow-point']"),
			"Receive Email Notification Dropdown Closed."),
	
	EMAIL_NOTIFICATION_DESCRIPTION(By.xpath("//div//p[contains(text(),'Turning on this feature will send you all notifications for the locations you have access to, such as content approval emails, disconnection notifications,')]"
			),
			"Email_Notification_Description"),

	/** The email notification save button. */
	EMAIL_NOTIFICATION_SAVE_BUTTON(By.xpath(
			"//div[text()='Receive Email Notifications']//parent::div//following-sibling::div//div//div[@class='save-btn ap-actions']//div//button[text()='Save']"),
			"Email Notification Save Button."),

	/** The email notification toggle button. */
	EMAIL_NOTIFICATION_TOGGLE_BUTTON(By.xpath(
			"//div[text()='Receive Email Notifications']//parent::div//following-sibling::div//div//div[@class='sms-notify-togle-section']//div//div[contains(@class,'react-switch-section')]"),
			"Email_notification_Toggle_Button"),

	/** The review notifications. */
	REVIEW_NOTIFICATIONS(By.xpath(
			"//img[contains(@src,'arrow-down-grey.svg')]//parent::div//parent::div[text()='Review Notifications']"),
			"Review Notifications."),
	
	REVIEW_NOTIFICATION_DROPDOWN_CLOSED(By.xpath(
			"//div[text()='Review Notifications']//div//img[@class='arrow-point']"),
			"Review Notification Dropdown Closed."),

	/** The review notification save button. */
	REVIEW_NOTIFICATION_SAVE_BUTTON(By.xpath(
			"//div[text()='Review Notifications']//parent::div//following-sibling::div//div//div[@class='save-btn ap-actions']//div//button[text()='Save']"),
			"Review Notification Save Button."),

	/** The review notification description. */
	REVIEW_NOTIFICATION_DESCRIPTION(
			By.xpath("//div//p[contains(text(),'By checking the options below, you will receive reviews with those ratings. To receive all reviews, turn on all the ratings.')]"),
			"Review notifications Description."),

	/** The review notification one star toggle button. */
	REVIEW_NOTIFICATION_ONE_STAR_TOGGLE_BUTTON(
			By.xpath("//h2[text()='1 Star']//following-sibling::div//div[@class='react-switch-section active']"),
			"Reviews_Onestar_Toggle_Button."),

	/** The review notification two star toggle button. */
	REVIEW_NOTIFICATION_TWO_STAR_TOGGLE_BUTTON(
			By.xpath("//h2[text()='2 Stars']//following-sibling::div//div[@class='react-switch-section active']"),
			"Reviews_Twostar_Toggle_Button."),

	/** The review notification three star toggle button. */
	REVIEW_NOTIFICATION_THREE_STAR_TOGGLE_BUTTON(
			By.xpath("//h2[text()='3 Stars']//following-sibling::div//div[@class='react-switch-section active']"),
			"Reviews_Threestar_Toggle_Button."),

	/** The review notification four star toggle button. */
	REVIEW_NOTIFICATION_FOUR_STAR_TOGGLE_BUTTON(
			By.xpath("//h2[text()='4 Stars']//following-sibling::div//div[@class='react-switch-section active']"),
			"Reviews_Fourstar_Toggle_Button."),

	/** The review notification five star toggle button. */
	REVIEW_NOTIFICATION_FIVE_STAR_TOGGLE_BUTTON(
			By.xpath("//h2[text()='5 Stars']//following-sibling::div//div[@class='react-switch-section active']"),
			"Reviews_Fivestar_Toggle_Button."),

	/** The facebook notifications. */
	FACEBOOK_NOTIFICATIONS(By.xpath(
			"//img[contains(@src,'arrow-down-grey.svg')]//parent::div//parent::div[text()='Facebook Notifications']"),
			"Facebook Notification."),
	
	FACEBOOK_NOTIFICATION_DROPDOWN_CLOSED(By.xpath(
			"//div[text()='Facebook Notifications']//img[@class='arrow-point']"),
			"Facebook Notification Dropdown Closed."),

	/** The recommend reviews. */
	FACEBOOK_RECOMMEND_REVIEWS(
			By.xpath("//h2[text()='Recommend Reviews']//parent::div//div[contains(@class,'react-switch-section')]"),
			"Recommended Reviews"),

	/** The not recommend reviews. */
	FACEBOOK_NOT_RECOMMEND_REVIEWS(By
			.xpath("//h2[text()='Not Recommend Reviews']//parent::div//div[contains(@class,'react-switch-section')]"),
			"Not Recommended Reviews"),

	/** The facebook notification save button. */
	FACEBOOK_NOTIFICATION_SAVE_BUTTON(By.xpath(
			"//h2[text()='Not Recommend Reviews']//parent::div//following-sibling::div[@class='save-btn ap-actions']//div//button"),
			"Facebook notification Save Button."),

	/** The reports tab. */
	REPORTS_TAB(By.xpath("//img[contains(@src,'arrow-down-grey.svg')]//parent::div//parent::div[text()='Reports']"),
			"Reports Tab"),
	
	REPORTSTAB_NOTIFICATION_DROPDOWN_CLOSED(By.xpath(
			"//div[text()='Reports']//parent::div//img[@class='arrow-point']"),
			"Reports Dropdown Closed."),

	/** The monthly report toggle button. */
	MONTHLY_REPORT_TOGGLE_BUTTON(
			By.xpath("//h2[text()='Monthly Reports']//parent::div//div[contains(@class,'react-switch-section')]"),
			"Monthly Report Toggle Button"),

	/** The monthly report save button. */
	MONTHLY_REPORT_SAVE_BUTTON(By.xpath(
			"//h2[text()='Monthly Reports']//parent::div//following-sibling::div[@class='save-btn ap-actions']//div//button"),
			"Monthly Report Save Button"),

	/** The save all button. */
	SAVE_ALL_BUTTON(By.xpath("//div[contains(@class,'saveall save-btn ap-actions')]//div//button[text()='Save All']"),
			"Save All Button"),
	
	/** Revv settings dropdown */
	REVV_SETTINGS_DROPDOWN(By.xpath(
			"//div[@class='card__header--wrp accordion-item' and text()='Receive Email Notifications']//div[@class='acc__arrow--icon']"),
			"Revv settings dropdown"),
	
	/** Revv settings Survey result - Email option */
	REVV_SETTINGS_SURVEY_RESULT_EMAIL_OPTION(By.xpath(
			"//div[@class='acc-card  active card']//div//span[@class='fltlabels' and text()='Survey Results - Email']"),
			"Revv settings Survey result - Email option"),
	

	/** Revv settings Survey result - Daily summary option */
	REVV_SETTINGS_SURVEY_RESULT_DAILY_SUMMARY(By.xpath(
			"//div[@class='acc-card  active card']//div//span[@class='fltlabels' and text()='Survey Results - Daily Summary']"),
			"Revv settings Survey result - Daily summary option"),
	
	/** Revv settings Survey save button */
	REVV_SETTINGS_SAVE_BUTTON(By.xpath(
			"//div[@class='save-btn ap-actions']//div//button[@class='ac-btn ac-primary size-xs disabled' and text()='Save']"),
			"Revv settings save button"),
	
	;

	public By getByLocator() {
		return byLocator;
	}

	public void setByLocator(By byLocator) {
		this.byLocator = byLocator;
	}

	public String getxPath() {
		return xPath;
	}

	public void setxPath(String xPath) {
		this.xPath = xPath;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	/** The by locator. */
	private By byLocator;

	/** The x path. */
	private String xPath;

	/** The description. */
	private String description;

	/**
	 * Instantiates a new team management tab login enum.
	 *
	 * @param byLocator   the by locator
	 * @param description the description
	 */
	private NotificationSettingsPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;

	}

	/**
	 * Instantiates a new team management tab login enum.
	 *
	 * @param xPath       the x path
	 * @param description the description
	 */
	private NotificationSettingsPageEnum(String xPath, String description) {

		this.xPath = xPath;
		this.description = description;

	}
	
	
	
	
	
	
	
}

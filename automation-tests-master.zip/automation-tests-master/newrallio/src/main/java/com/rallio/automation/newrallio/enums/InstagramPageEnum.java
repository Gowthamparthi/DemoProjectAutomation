package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum InstagramPageEnum.
 */
public enum InstagramPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//div[@class='rgFsT   ']//h1[text()='Instagram']"),"Page load"),

	INSTAGRAM_PAGELOAD(By.xpath("//*[local-name()='svg' and @aria-label='Instagram']"),"INSTAGRAM_PAGELOAD"),

	IMSTAGRAM_PROFILE_PICTURE(By.xpath("//main[@class='xvbhtw8 x78zum5 xdt5ytf x1iyjqo2']//img[@alt=\"testerlocation's profile picture\"]"),"IMSTAGRAM_PROFILE_PICTURE"),

	INSTA_LOGIN_BUTTON(By.xpath("//a[text()='Log In']"),"Insta Login Button"),

	/** The email input. */
	EMAIL_INPUT(By.xpath("//input[@name='username' and @type='text']"),"Email input"),
	
	/** The password input. */
	PASSWORD_INPUT(By.xpath("//input[@name='password' and @type='password']"),"Password input"),
	
	/** The login button. */
	LOGIN_BUTTON(By.xpath("//div[text()='Log in']//parent::button[@type='submit']"),"LogIn button"),

	INSTAGRAM_LOGIN_IN_DETAILVIEW(By.xpath("//div[@class='x9f619 x1n2onr6 x1ja2u2z']"),"INSTAGRAM_LOGIN_IN_DETAILVIEW"),

	/** The not now button. */
	NOT_NOW_BUTTON(By.xpath("//div[@class='cmbtv']//parent::button[text()='Not Now']"),"Not now button"),

	PROFILE_BUTTON(By.xpath("//div[@class='xopu45v xu3j5b3 xm81vs4 x1vjfegm']//div[@class='x1n2onr6']//img[@alt]"),"Profile button"),

	CONTINUE_AS_AXAUTOTEST(By.xpath("//div[text()='Continue as axrautotest']"),"Continue As AxAutoTest"),

	POSTS_FIRST_IMAGE(By.xpath("(//div[@class='_aagw'])[1]"),"POSTS_FIRST_IMAGE"),

	TOTAL_IMAGE_LIST(By.xpath("//div[@class='_aamj _acvz _acnc _acng']//div[contains(@class,'_acnb')]"),"Total Image List"),

	INSTA_STORY_PREVIOUS_BUTTON(By.xpath("//div[@class='x5yr21d x1n2onr6 xh8yej3']//div[@class='x6s0dn4 x78zum5 xdt5ytf xl56j7k']//*[local-name()='svg' and @aria-label='Previous']"),"INSTA_STORY_PREVIOUS_BUTTON"),

	INSTA_STORY_NEXT_BUTTON(By.xpath("//div[@class='x5yr21d x1n2onr6 xh8yej3']//div[@class='x6s0dn4 x78zum5 xdt5ytf xl56j7k']//*[local-name()='svg' and @aria-label='Next']"),"INSTA_STORY_PREVIOUS_BUTTON"),

	INSTA_STORY_PAUSE_BUTTON(By.xpath("//div[@class='x5yr21d x1n2onr6 xh8yej3']//div[@class='x6s0dn4 x78zum5 xdt5ytf xl56j7k']//*[local-name()='svg' and @aria-label='Pause']"),"INSTA_STORY_PAUSE_BUTTON"),

	INSTAGRAM_STORY_DETAILVIEW(By.xpath("//div[@class='x5yr21d x1n2onr6 xh8yej3']"),"INSTAGRAM_STORY_DETAILVIEW"),

	STORY_IMAGE_NAME("//div[@class]//img[contains(@alt,\"Photo by Coffee and Tea on %s.\")]","Story Image Name"),

	/** The social media name. */
	SOCIAL_MEDIA_NAME(By.xpath("//div[contains(@class,'_7UhW9')]//div[contains(@class,'vwCYk')]//a[text()]"),"Social media name");
	
	/** The by locator. */
	private By byLocator;

	/** The xpath. */
	private String xpath;

	/** The description. */
	private String description;
	
	
	/**
	 * Instantiates a new instagram page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private InstagramPageEnum(By byLocator, String description) {
		
		this.byLocator = byLocator;
		this.description = description;
	}
	
	
	/**
	 * Instantiates a new instagram page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private InstagramPageEnum(String xpath, String description) {
		
		this.xpath = xpath;
		this.description = description;
	}
	
	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return byLocator;
	}

	/**
	 * Gets the by xpath.
	 *
	 * @return the by xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}
}

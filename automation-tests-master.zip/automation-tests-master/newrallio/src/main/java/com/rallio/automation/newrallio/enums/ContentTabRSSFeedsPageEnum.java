package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

public enum ContentTabRSSFeedsPageEnum {

	PAGE_LOAD(By.xpath(
			"//li[@class='ripple active']//span[text()='RSS Feeds']//ancestor::div//section[@id='main-container-sec']//div[contains(@class,'rssfeed-list-wrp')]"),
			"PAGE_LOAD"),
	
	RSS_FEED_TEXT(By.xpath("//img[contains(@src,'rssfeed.svg')]//parent::div//following-sibling::span[text()='RSS Feed']"),"RSS_FEED_TEXT"),
		
	CONFIGURE_RSS_FEED_BUTTON(By.xpath("//button[text()='Configure RSS Feeds']"),"CONFIGURE_RSS_FEED_BUTTON"),
	
		CONFIGURE_RSS_FEEDS_PAGE(By.xpath("//div[contains(@class,'rssfeed-form')]//input[@name='name']//ancestor::div[contains(@class,'rssfeed-form')]//input[@name='url']"),"CONFIGURE_RSS_FEEDS_PAGE"),

		CONFIGURE_RSS_FEEDS_PAGE_NAME_FIELD(By.xpath("//div[contains(@class,'rssfeed-form')]//span[contains(text(),'Name')]//preceding-sibling::input[@name='name']"),"CONFIGURE_RSS_FEEDS_PAGE_NAME_FIELD"),

		CONFIGURE_RSS_FEEDS_PAGE_URL_FIELD(By.xpath("//div[contains(@class,'rssfeed-form')]//span[contains(text(),'www.RSSfeedurl.xml')]//preceding-sibling::input[@name='url']"),"CONFIGURE_RSS_FEEDS_PAGE_URL_FIELD"),

		CONFIGURE_RSS_FEEDS_PAGE_URL_DISABLED_FIELD("//input[@class='form-control events-none pointer-events-none' and @value='%s']","CONFIGURE_RSS_FEEDS_PAGE_URL_DISABLED_FIELD"),
		
		CONFIGURE_RSS_FEEDS_PAGE_NAME_FIELD_WITH_CONTENT(By.xpath("//div[contains(@class,'rssfeed-form')]//input[@name='name' and @value]"),"CONFIGURE_RSS_FEEDS_PAGE_NAME_FIELD_WITH_CONTENT"),

		CONFIGURE_RSS_FEEDS_PAGE_URL_FIELD_WITH_CONTENT(By.xpath("//div[contains(@class,'rssfeed-form')]//input[@name='url' and @value]"),"CONFIGURE_RSS_FEEDS_PAGE_URL_FIELD_WITH_CONTENT"),

		CONFIGURE_RSS_FEEDS_PAGE_ADD_IMAGE_ICON(By.xpath("//img[@alt='rss-add-images']//parent::div"),"CONFIGURE_RSS_FEEDS_PAGE_ADD_IMAGE_ICON"),

		CONFIGURE_RSS_FEEDS_PAGE_DELETE_FEED_ICON(By.xpath("//img[@alt='delete-red']//parent::div"),"CONFIGURE_RSS_FEEDS_PAGE_DELETE_FEED_ICON"),
		
		CONFIGURE_RSS_FEEDS_PAGE_DELETED_POPUP(By.xpath("//img[@alt='delete-red']//parent::div"),"CONFIGURE_RSS_FEEDS_PAGE_DELETED_POPUP"),

		CONFIGURE_RSS_FEEDS_PAGE_CLOSE_ICON(By.xpath("//div[contains(@class,'rssfeedlist')]//img[@class='close-ico pointer']"),"CONFIGURE_RSS_FEEDS_PAGE_CLOSE_ICON"),
       
		CONFIGURE_RSS_FEEDS_PAGE_INPUT_URL_FIELD("//div[@class='center-section']//input[@class='form-control events-none pointer-events-none' and @value=\"%s\"]","CONFIGURE_RSS_FEEDS_PAGE_INPUT_URL_FIELD"),

	CREATE_POST_COLUMN_LINK_ICON(By.xpath("//th[text()='Create Post']//ancestor::table//td//div[@class='link-icon']//img[@alt='Link']"),"CREATE_POST_COLUMN_LINK_ICON"),

	TITLE_COLUMN_VALUE(By.xpath("//th[text()='Title']//parent::tr//parent::thead//following-sibling::tbody//tr//td[2]"),"TITLE_COLUMN_VALUE"),

	DESCRIPTION_COLUMN_CONTENT(By.xpath("//th[text()='Description']//ancestor::table//tbody//td[@class='description-width ']//span[text()]"),"DESCRIPTION_COLUMN_CONTENT"),
	
	TABLE_ROW(By.xpath("//div[contains(@class,'rssfeed-list')]//tbody//tr[last()]"),"TABLE_ROW"),
	
	TABLE_FOOTER_CONTENT(By.xpath("//div[contains(@class,'rssfeed-list')]//tbody//tr[last()]"),"TABLE_FOOTER_CONTENT");

	
	
	
	private By byLocator;

	private String xpath, description;

	private ContentTabRSSFeedsPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	private ContentTabRSSFeedsPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	public By getByLocator() {

		return this.byLocator;
	}

	public String getXpath() {

		return xpath;
	}

	public String getDescription() {

		return this.description;
	}
	
}

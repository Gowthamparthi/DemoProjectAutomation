package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

public enum SettingsTabProfilePageEnum {

    PAGE_LOAD(By.xpath("//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Profile']//ancestor::header//parent::div//following-sibling::main//div[contains(@class,'connec-allrallio-profile-wrp dl-business-details')]"), "Setting Tab Profile Page Load"),

    BRAND_LOGO_TEXT(By.xpath("//div[@class='content-left-section']//h3[text()='Brand Logo']"),"Brand Logo Text"),

    BRAND_LOGO_IMAGE(By.xpath("//div[@class='image-holder']//img"),"BRAND_LOGO_IMAGE"),

    UPLOAD_IMAGE(By.xpath("//div[@class='upload-image']"),"Upload Image"),

    UPLOAD_IMAGE_INPUT(By.xpath("//div[@class='upload-image']//input"),"Upload Image Input"),

    BRAND_LOGO_IMAGE_SPECIFICATION(By.xpath("//span[@class='note-info' and text()='(Please ensure that the profile image is a jpg, jpeg or png and less than 2MB)']"),"Brand Logo Image Specification"),

    CANCEL_BUTTON(By.xpath("//button[contains(@class,'ac-btn ac-secondary-white') and text()='Cancel']"),"Cancel button"),

    SAVE_BUTTON(By.xpath("//button[contains(@class,'ac-btn ac-primary size-xs') and text()='Save']"),"Save button"),

    SAVED_MESSAGE(By.xpath("//span[@class='success-mess-txt' and text()='Saved']"),"Sved Message"),

    DELETE_ICON(By.xpath("//div[@class='overlay']//span[@class='icon']"),"Delete Icon"),

    DELETE_DETAILVIEW_DELETE_BUTTON(By.xpath("//button[@class='modal-btn-action-itm modal-delete-btn' and text()='Delete']"),"Detailview Delete Button"),

    DELETE_DETAILVIEW_CANCEL_BUTTON(By.xpath("//button[@class='modal-btn-action-itm modal-cancel-btn' and text()='Cancel']"),"Detailview Cancel Button"),

    DELETE_DONE_POPUP(By.xpath("//span[@class='success-mess-txt' and text()='Done!']"),"Delete Done Popup"),

    ;

    /**
     * The by locator.
     */
    private By byLocator;

    /**
     * The description.
     */
    private String xpath, description;

    /**
     * Instantiates a Settings Tab Profile PageEnum
     *
     * @param byLocator   the by locator
     * @param description the description
     */
    private SettingsTabProfilePageEnum(By byLocator, String description) {

        this.byLocator = byLocator;
        this.description = description;
    }

    /**
     * Instantiates a  Settings Tab Profile Page Enum.
     *
     * @param xpath       the xpath
     * @param description the description
     */
    private SettingsTabProfilePageEnum(String xpath, String description) {

        this.xpath = xpath;
        this.description = description;
    }

    /**
     * Gets the by locator.
     *
     * @return the by locator
     */
    public By getByLocator() {

        return this.byLocator;
    }

    /**
     * Gets the xpath.
     *
     * @return the xpath
     */
    public String getXpath() {

        return xpath;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {

        return this.description;
    }
}

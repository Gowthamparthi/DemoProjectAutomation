/*
 * 
 */
package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum NeedHelpPageEnum.
 */
public enum NeedHelpPageEnum {

	/** The page load Analytics Content Page. */
	PAGE_LOAD(By.xpath(
	        "//li[@class='ripple active']//span[text()='Social']//following::section[@class='item-g filter ra-filter-sec anlFilter']//ancestor::div//div[@class='g-centre']//div[contains(@class,'mainContent analytics')]"),
	        "Page load"),

	RALLIO_HELPCENTER_HEDER(By.xpath("//span[@class='header__name' and text()='Rallio Help Center']"),"Rallio Help Center"),
	
	/** Analytics tab. */
	ANALYTICS_TAB(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Analytics']"), "Analytics tab"),

	/** The analytics tab social analytics.*/
	ANALYTICS_TAB_SOCIAL_ANALYTICS(By.xpath("//div[contains(@class,'sub-nav-tabs animate')]//ul//li//span[@class='sub-nav-item-txt' and contains(text(),'Social')]"),
	        "Analytics tab SocialAnalytics"),

	/** The need help. */
	NEED_HELP(By.xpath("//aside[contains(@class,'need-help')]//div[@class='nh-txt']//h4[text()='Need Help?']"), "Click the Need Help"),

	/** The need help socialpage pageload. */
	NEED_HELP_SOCIALPAGE_LOCATIONPAGELOAD(
	        By.xpath("//header[text()='Social Analytics Overview']"),
	        "The Social Analyics Needhelp Pageload"),

	/** The need help socialpage pageload. */
	NEED_HELP_SOCIALPAGE_HUBPAGELOAD(
	        By.xpath("//header[ text()='Social Analytics Overview']"),
	        "The Hub-Social Analyics Needhelp Pageload"),

	/** Analytics tab ContentAnalytics. */
	ANALYTICS_TAB_CONTENT_ANALYTICS(By.xpath(
	        "//li[contains(@class,'nav-item')]//span[text()='Analytics']//ancestor::main//preceding-sibling::div[contains(@class,'header-wrap')]//header//span[text()='Content']"),
	        "Analytics Tab Content PageLoad"),

	/** The analytics tab content pageload. */
	ANALYTICS_TAB_CONTENT_PAGELOAD(By.xpath("//li[@class='ripple active']//span[text()='Content']//ancestor::div[@class='resizing-wrap']//div[@class='row']"),
	        "The Analytics tab contents Page load"),

	/** The analytics tab page. */
	ANALYTICS_TAB_PAGE(By.xpath("//li//span[text()='Page']"), "The Analytics Tab Page click"),

	/** The teammanagement tab. */
	TEAMMANAGEMENT_TAB(By.xpath("//li//span[text()='Team Management']"), "The TeamManageMent Tab click"),

	/** The teammanagement tab logins. */
	TEAMMANAGEMENT_TAB_LOGINS(By.xpath("//li//span[text()='Logins']"), "The Team Management Logins click"),

	/** The analytics tab page pageload. */
	ANALYTICS_TAB_PAGE_PAGELOAD(By.xpath(
	        "//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Page']//ancestor::div[contains(@class,'header-wrap')]//following-sibling::main//section//div[@class='content-g']"),
	        "The Analytics Tab Page Pageload"),

	/** The need help page pageload. */
	NEED_HELP_PAGE_LOCATIONPAGELOAD(
	        By.xpath("//header[text()='Page Analytics']"),
	        "The Need Help Page Pageload"),

	/** The need help page hubpageload. */
	NEED_HELP_PAGE_HUBPAGELOAD(
	        By.xpath("//header[ text()='Page Analytics']"),
	        "The Need Help Page Pageload"),

	/** The need help content page pageload. */
	NEED_HELP_CONTENT_PAGE_LOCATIONPAGELOAD(
	        By.xpath("//header[text()='Content Analytics']"),
	        "Analutics Tab Content NeedHelp Pageload"),

	/** The need help content page hubpageload. */
	NEED_HELP_CONTENT_PAGE_HUBPAGELOAD(
	        By.xpath("//header[ text()='Hub User - Content Analytics']"),
	        "Analutics Tab Hub-Content NeedHelp Pageload"),

	/** The need help creator page pageload. */
	NEED_HELP_CREATOR_PAGE_LOCATIONPAGELOAD(
	        By.xpath("//div[@class='article__meta']//header[text()='Creating and Scheduling a Post']"),
	        "Creator NeedHelp PageLoad"),
	
	NEED_HELP_CREATOR_PAGE_HUBPAGELOAD(
	        By.xpath("//div[@class='article__meta']//header[text()='Creating a Post']"),
	        "Creator NeedHelp HubPageLoad"),

	NEED_HELP_POSTS_PAGE_HUBPAGELOAD(By.xpath("//header[ text()='Navigating Your Posts']"),
	        "The Need help Posts page load"),
	
	NEED_HELP_POSTS_PAGE_LOCATIONSPAGELOAD(By.xpath("//header[ text()='Managing Your Posts']"),
	        "The Need help Posts page load"),

	/** The need help media page pageload. */
	NEED_HELP_MEDIA_PAGE_LOCATIONPAGELOAD(By.xpath("//header[ text()='Media Gallery']"),
	        "Media NeedHelp PageLoad"),

	/** The need help media page hubpageload. */
	NEED_HELP_MEDIA_PAGE_HUBPAGELOAD(By.xpath("//header[ text()='Media Gallery']"), "Media Need Help Pageload"),

	/** The need help rssfeed page locationpageload. */
	NEED_HELP_RSSFEED_PAGE_HUBPAGELOAD(By.xpath("//header[@class='jsx-2579233455 header text-header-font']//following:div//div[@class='collection o__ltr']"),
	        "The Need help RSS Feed Page load"),

	NEED_HELP_RSSFEED_PAGE_LOCATIONPAGELOAD(By.xpath("//header[ text()='RSS Feed']"),
	        "The Need help RSS Feed Page load"),

	/** The need help calendar page pageload. */
	NEED_HELP_CALENDAR_PAGE_LOCATIONPAGELOAD(
	        By.xpath("//div[@class='article__meta']//header[text()='Managing Content in the Calendar']"),
	        "The Need help calendar pageload"),

	/** The need help calendar page hubpageload. */
	NEED_HELP_CALENDAR_PAGE_HUBPAGELOAD(By.xpath("//header[@class='jsx-2579233455 header text-header-font']"), "The Need help calendar pageload"),

	/** The need help inbox page pageload. */
	NEED_HELP_INBOX_PAGE_PAGELOAD(By.xpath("//div[@class='article__meta']//header[text()='Managing Your Inbox']"),
	        "The Need help Inbox pageload"),

	/** The need help sandbox page pageload. */
	NEED_HELP_SANDBOX_PAGE_PAGELOAD(By.xpath("//div[@class='article__meta']//header[text()='Understanding the Sandbox']"),
	        "The Need Help Snadbox pageload"),

	/** The need help reviews page pageload. */
	NEED_HELP_REVIEWS_PAGE_PAGELOAD(By.xpath("//div[@class='article__meta']//header[text()='Managing Your Reviews']"),
	        "The Need help Reviews Pageload"),

	/** The need help outbox page pageload. */
	NEED_HELP_OUTBOX_PAGE_PAGELOAD(By.xpath("//div[@class='article__meta']//header[text()='Using the Outbox']"),
	        "The Need help Outbox PageLoad"),

	/** The need help outbox hub pagepageload. */
	NEED_HELP_OUTBOX_HUB_PAGEPAGELOAD(By.xpath("//div[@class='article__meta']//header[text()='The Outbox']"),
	        "The Need help Outbox PageLoad"),

	/** The need help overview page pageload. */
	NEED_HELP_OVERVIEW_PAGE_PAGELOAD(
	        By.xpath("//header[ text()='Overview of Employee Advocacy']"),
	        "The Need help Overview Pageload"),

	/** The need help rewards pageload. */
	NEED_HELP_REWARDS_PAGELOAD(By.xpath(""),""),
	
	/** The need help leaderboard page pageload. */
	NEED_HELP_LEADERBOARD_PAGE_PAGELOAD(
	        By.xpath("//header[ text()='Employee Advocacy Leaderboard']"),
	        "The Need Help Leaderboard pafgeload"),

	/** The need help analytics leaderboard pageload. */
	NEED_HELP_ANALYTICS_LEADERBOARD_PAGELOAD(
	        By.xpath("//header[ text()='Understanding the Leaderboard Analytics']"),
	        "The Need Help Analyics Leaderboard Pageload"),

	/** The need help profileimaginary hubpageload. */
	NEED_HELP_PROFILEIMAGINARY_HUBPAGELOAD(By.xpath("//header[text()='Profile Imagery']"), "The Need Help ProfileImaginary paeload"),

	/** The need help rallioprofile page pageload. */
	NEED_HELP_RALLIOPROFILE_PAGE_PAGELOAD(
	        By.xpath("//div[@class='article__meta']//header[text()='Managing Your Profile Settings']"),
	        "The Need Help RallioProfile Pageload"),

	/** The need help socialprofile page pageload. */
	NEED_HELP_SOCIALPROFILE_PAGE_PAGELOAD(
	        By.xpath("//div[@class='article__meta']//header[text()='Connecting Your Social Profiles']"),
	        "The Need Help page SocialProfile Pageload"),

	/** The need help fbads page pageload. */
	NEED_HELP_FBADS_PAGE_PAGELOAD(By.xpath("//div[@class='article__meta']//header[text()='Facebook Ads']"),
	        "The Need Help Fb Ads Pageload"),

	/** The need help reviews pageload. */
	NEED_HELP_SETTING_REVIEWS_PAGELOAD(By.xpath("//div[@class='article__meta']//header[text()='Editing Your Auto-Filled Review Responses']"), "The Need Help Reviews Page"),

	/** The need help releaseform pageload. */
	NEED_HELP_RELEASEFORM_PAGELOAD(By.xpath("//div[@class='article__meta']//header[text()='Model Release Form']"), "The Need Help Release form pageload"),

	/** The need help logins locationpageload. */
	NEED_HELP_LOGINS_LOCATIONPAGELOAD(By.xpath("//section[@data-testid='landing-section']"), "The Need Help Locationuser logins pageload"),

	/** The need help connections hubpageload. */
	NEED_HELP_CONNECTIONS_HUBPAGELOAD(By.xpath("//div[@class='article__meta']//header[text()='Your Connections']"), "The Need Help connections Pageload"),

	/** The need help lists hubpageload. */
	NEED_HELP_LISTS_HUBPAGELOAD(By.xpath("//div[@class='article__meta']//header[text()='Account Lists']"), "The Need Help Lists Pageload"),

	/** The need help permissions hubpageload. */
	NEED_HELP_PERMISSIONS_HUBPAGELOAD(By.xpath("//div[@class='article__meta']//header[text()='Managing Hub Permissions']"), "The Need help Permissions Pageload"),

	/** The rss feed tab. */
	RSS_FEED_TAB(By.xpath("//span[text()='RSS Feeds']//parent::li"), "Rss Feed Tab"),

	/** The setting tab reviews. */
	SETTING_TAB_REVIEWS(By.xpath("//span[text()='Reviews']"), "The Setting Tab reviews click"),

	/** The setting tab releaseform. */
	SETTING_TAB_RELEASEFORM(By.xpath("//li//span[text()='Release Form']"), "The Setting Tab Releaseform"),

	/** The rss feed pageload. */
	RSS_FEED_PAGELOAD(By.xpath("//span[text()='RSS Feed']//ancestor::div//table//tr//th//parent::tr//parent::thead//following-sibling::tbody"), "Rss Feed PageLoad"),

	/** The releaseform pageload. */
	RELEASEFORM_PAGELOAD(By.xpath(
	        "//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Release Form']//ancestor::div[contains(@class,'header-wrap')]//following-sibling::main//section//div[@class='content-g']"),
	        "The Release Form Pageload"),

	/** The logins pageload. */
	LOGINS_PAGELOAD(By.xpath(
	        "//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Logins']//ancestor::div[contains(@class,'header-wrap')]//following-sibling::main//section//div[@class='content-g']"),
	        "The Logins Pageload");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new need help page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private NeedHelpPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new need help page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private NeedHelpPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

public enum AIReviewResponderEnum {

    PAGE_LOAD(By.xpath("//li[@class='ripple active']//span[text()='AI Review Responder']//ancestor::div//div[@class='airItem airResponse accordion-item']"), "The AI Review Responder Page Load"),

    AI_REVIEW_RESPONSE_BUTTON(By.xpath("//div[@class='airItem airResponse accordion-item']//button[text()='AI Review Response Set-up']"), "The AI Review Response Button"),

    AI_REVIEW_RESPONSE_ACTIVE(By.xpath("//div[@class='airItem airResponse accordion-item']//div[@class='accordion-collapse collapse show']//div[@class='tab-content']//div[contains(@class,'pd-field-group air-section air-emojis') and not(contains(@class,'pointer-events-none'))]"), "The AI Review Response Active"),

    AI_REVIEW_RESPONSE_ENABLE_SWITCH(By.xpath("//div[@class='airItem airResponse accordion-item']//div[@class='accordion-collapse collapse show']//div[@class='wbl-head' and text()='Enable']//parent::div//following-sibling::div//input[@class='form-check-input']"),"The AI Review Response Enable Switch"),

    AI_REVIEW_RESPONDER_DETAILVIEW_HEADERS("//div[contains(@class,'airItem airResponse')]//div[@class='accordion-collapse collapse show']//div[@class='wbl-head' and text()='%s']", "The AI Review Responder Detail View Headers"),

    EMOJIS_SECTION_SELECT_REVIEW_TEXT(By.xpath("//div[@class='accordion-collapse collapse show']//div[@class='wbl-head' and text()='Emojis']//following::div//p[text()='Select the review ratings you want to include emojis in the responses.']"), "Emojis Section Select Review Text"),

    EMOJIS_SECTION_GOOGLE_TEXT(By.xpath("//div[text()='Emojis']//parent::div//following-sibling::div[@class='wb-f-main']//div[@class='sFilsWrap']//h3[text()='Google']"), "Emojis Section Google Text"),

    GOOGLE_FIVE_STAR_REVIEWS_CHECKBOX("//div[text()='%s']//parent::div//following-sibling::div[@class='wb-f-main']//div[@class='sFilsWrap']//div[@class='form-group']//span[@class='sr-item five-star']//parent::label//span[@class='labelText' and text()='5 Stars']//parent::label//input[@class='option-input checkbox']", " Google Five Star Reviews"),

    GOOGLE_FOUR_STAR_REVIEWS_CHECKBOX("//div[text()='%s']//parent::div//following-sibling::div[@class='wb-f-main']//div[@class='sFilsWrap']//div[@class='form-group']//span[@class='sr-item four-star']//parent::label//span[@class='labelText' and text()='4 Stars']//parent::label//input[@class='option-input checkbox']", "Google Four Star Reviews"),

    GOOGLE_THREE_STAR_REVIEWS_CHECKBOX("//div[text()='%s']//parent::div//following-sibling::div[@class='wb-f-main']//div[@class='sFilsWrap']//div[@class='form-group']//span[@class='sr-item three-star']//parent::label//span[@class='labelText' and text()='3 Stars']//parent::label//input[@class='option-input checkbox']","Google Three Star Reviews"),

    GOOGLE_TWO_STAR_REVIEWS_CHECKBOX("//div[text()='%s']//parent::div//following-sibling::div[@class='wb-f-main']//div[@class='sFilsWrap']//div[@class='form-group']//span[@class='sr-item two-star']//parent::label//span[@class='labelText' and text()='2 Stars']//parent::label//input[@class='option-input checkbox']","Google Three Star Reviews"),

    GOOGLE_ONE_STAR_REVIEWS_CHECKBOX("//div[text()='%s']//parent::div//following-sibling::div[@class='wb-f-main']//div[@class='sFilsWrap']//div[@class='form-group']//span[@class='sr-item one-star']//parent::label//span[@class='labelText' and text()='1 Star']//parent::label//input[@class='option-input checkbox']","Google Three Star Reviews"),

    FACEBOOK_RECOMMENDED_CHECKBOX("//div[text()='%s']//parent::div//following-sibling::div[@class='wb-f-main']//div[@class='sFilsWrap']//h3[text()='Facebook']//parent::div[@class='sFils-item']//span[text()='Recommended']//parent::div//parent::label//input","Facebook Recommended"),

    FACEBOOK_NOTRECOMMENDED_CHECKBOX("//div[text()='%s']//parent::div//following-sibling::div[@class='wb-f-main']//div[@class='sFilsWrap']//h3[text()='Facebook']//parent::div[@class='sFils-item']//span[text()='Not Recommended']//parent::div//parent::label//input","Facebook NotRecommended"),

    CONTACT_INFORMATION_TEXT(By.xpath("//div[@class='accordion-collapse collapse show']//div[@class='wbl-head' and text()='Contact Information']//following::div//p[text()='To include contact information in the responses, enter the contact details and choose the review ratings where it should appear.']"),"Contact Information Text"),

    CONTACT_INFORMATION_PHONE_NUMBER(By.xpath("//div[@class='form-group form-field-item m-align-items ']//span[text()='Phone Number']//parent::div//input[@name='contact_information_phone']"),"Contact Information Phone Number"),

    CONTACT_INFORMATION_EMAIL_ADDRESS(By.xpath("//div[@class='form-group form-field-item m-align-items ']//span[text()='Email Address']//parent::div//input[@name='contact_information_email']"),"Contact Information Email Address"),

    CONTACT_INFORMATION_LOCALIZE_CHECKBOX(By.xpath("//div[text()='Contact Information']//ancestor::div[contains(@class,'pd-field-group air-section air-contact')]//div[@class='air-checkBox-item ciCheckbox']//span[contains(text(),'Localize the contact information')]//parent::div//parent::label//input"),"Contact Information Localize Checkbox"),

    CONTACT_INFORMATION_LOCALIZE_ICON(By.xpath("//div[text()='Contact Information']//ancestor::div[contains(@class,'pd-field-group air-section air-contact')]//div[@class='air-checkBox-item ciCheckbox']//span[contains(text(),'Localize the contact information')]//parent::div//div//img"),"Contact Information Localize Icon"),

    CONTACT_INFORMATION_LOCALIZE_TOOL_TIP(By.xpath("//div[text()='Checking this option will use the local phone number and email in place of the ones defined above.']"),"Contact Information Localize Tool Tip"),

    KEYWORD_AI_PLAYBOOK_LINK(By.xpath("//div[text()='Keywords']//ancestor::div[contains(@class,'pd-field-group air-section air-keyword')]//p[text()='Rallio AI will incorporate the keywords from your' and text()='into the responses whenever possible.']//a[text()='AI Playbook']"),"The Keyword AI Playbook Link"),

    KEYWORD_MY_AIPLAYBOOK_CHECKBOX(By.xpath("//div[text()='Keywords']//ancestor::div[contains(@class,'pd-field-group air-section air-keyword')]//span[text()='My AI Playbook Keyword Section is Up-To-Date.']//parent::label//input"),"The Keyword My AIPlaybook Checkbox"),

    AI_REVIEW_AUTOMATION_BUTTON(By.xpath("//div[@class='airItem airAutomation accordion-item']//button[text()='AI Review Automation Set-up']"), "The AI Review Automation Button"),

    AI_REVIEW_AUTOMATION_ACTIVE(By.xpath("//div[@class='airItem airAutomation accordion-item']//div[@class='accordion-collapse collapse show']//div[@class='tab-content']"), "The AI Review Automation Active"),

    ENABLE_SWITCH(By.xpath("//div[@class='wbl-head' and text()='Enable']//parent::div//ancestor::div[@class='airItem airAutomation accordion-item']//div[@class='form-switch']//input"),"Enable Switch"),

    ENABLE_SECTION_ACTIVE(By.xpath("//div[@class='wbl-head' and text()='Enable']//parent::div//ancestor::div[@class='airItem airAutomation accordion-item']//div[@class='pd-field-group air-section air-schedule']"),"Enable Section Active"),

    SCHEDULE_ALL_LOCATION_CHEDKBOX(By.xpath("//div[text()='Schedule']//ancestor::div[@class='pd-field-group air-section air-schedule']//span[text()='All Locations']//parent::label//input"),"Schedule All Location Checkbox"),

    SCHEDULE_SPECIFIC_LOCATION_LIST_CHECKBOX(By.xpath("//div[text()='Schedule']//ancestor::div[@class='pd-field-group air-section air-schedule']//span[text()='Specific Locations/Lists']//parent::label//input"),"Schedule Specific Location List Checkbox"),

    PLATFORM_RATING_WITH_TEXT(By.xpath("//div[text()='Platform & Rating']//parent::div//following-sibling::div[@class='wb-f-main']//p[text()='Choose the review ratings that should receive automated responses.']"),"Platform Rating With Text"),

    START_DATE_WITH_TEXT(By.xpath("//div[text()='Start Date']//parent::div//following-sibling::div[@class='wb-f-main']//p[text()='Choose the start date (past or present) for the review responses begin.']"),"Start Date With Text"),

    START_DATE_DATE_PICKER(By.xpath("//div[text()='Start Date']//parent::div//following-sibling::div[@class='wb-f-main']//div[@class='react-datepicker__input-container']//input"),"Start Date Date Picker"),

    PREVIEWSAMPLE_BUTTON_INACTIVE(By.xpath("//div[@class='airItem airAutomation accordion-item']//button[contains(@class,'pointer-events-none') and text()='Preview Samples']"),"Preview Sample Button Inactive"),

    PREVIEWSAMPLE_BUTTON_ACTIVE(By.xpath("//div[@class='airItem airAutomation accordion-item']//button[not(contains(@class,'pointer-events-none')) and text()='Preview Samples']"),"Preview Sample Button Inactive"),

    //PreviewSample Detailview
    PREVIEW_SAMPLE_DETAILVIEW(By.xpath("//div[@class='loader loader-ai']//following::span[text()=\"Prior to starting, let me generate some previews for you.\"]"),"PREVIEW_SAMPLE_DETAILVIEW"),

    TERMS_AND_CONDITION_LINK(By.xpath("//h3[text()='Terms and Conditions']//ancestor::div[@class='settings-rallio-profile-new-section']//span[text()='By clicking begin you agree to the' and text()='Agreement.']//parent::span//a[text()='Terms and Conditions']"),"Terms And Condition Link"),

    PREVIEW_SAMPLE_DETAILVIEW_CANCEL(By.xpath("//div[contains(@class,'react-ripples ac-secondary-box edit-ripple__wrp')]//button[text()='Cancel']"),"Preview Sample Detailview Cancel"),

    PREVIEW_SAMPLE_DETAILVIEW_START(By.xpath("//div[contains(@class,'react-ripples ac-primary-box')]//button[text()='Start']"),"Preview Sample Detailview Cancel"),

    PREVIEW_SAMPLE_DETAILVIEW_CONTENTS(By.xpath("//div[@class='modal-body']//div[@class='airrPMain']//div//span[@class='spin-txt']"),"Preview Sample Detailview Contents"),

    PREVIEW_SAMPLE_DETAILVIEW_CLOSE(By.xpath("//span[text()='Preview']//ancestor::div[@class='sec-header multi-headItems']//img[@alt='close']"),"Preview Sample Detailview Close"),

    FACEBOOK_NOT_RECOMMENDED_REVIEW(By.xpath("//span[contains(text(),'not recommend')]//ancestor::div[@class='list-view review-list__main']//img[contains(@src,'fb-lv.svg')]//parent::div//parent::div//parent::div//following-sibling::div[@class='airrPNote']//p"),"Facebook Not Recommended Review"),

    FACEBOOK_RECOMMENDED_REVIEW(By.xpath("//span[contains(text(),'recommend') and not(contains(text(),'does not'))]//ancestor::div[@class='list-view review-list__main']//img[contains(@src,'fb-lv.svg')]//parent::div//parent::div//parent::div//following-sibling::div[@class='airrPNote']//p"),"Facebook  Recommended Review"),

    GOOGLE_FIVE_STAR_REVIEWS(By.xpath("//span[contains(@class,'sr-item five-star')]//ancestor::div[@class='list-view review-list__main']//img[contains(@src,'google-Iv.svg')]//parent::div//parent::div//parent::div//following-sibling::div[@class='airrPNote']//p"),"Google Five Star Reviews"),

    AUTOMATION_REVIEW_CANCEL_BUTTON(By.xpath("//div[@class='airItem airAutomation accordion-item']//button[contains(@class,'ac-btn ac-secondary-white') and text()='Cancel']"),"Automation Review Cancel Button"),

    ;

    /**
     * The by locator.
     */
    private By byLocator;

    /**
     * The description.
     */
    private String xpath, description;

    /**
     * Instantiates a new ai review responder enum.
     *
     * @param byLocator   the by locator
     * @param description the description
     */
    private AIReviewResponderEnum(By byLocator, String description) {

        this.byLocator = byLocator;
        this.description = description;
    }

    /**
     * Instantiates a new ai review responder enum.
     *
     * @param xpath       the xpath
     * @param description the description
     */
    private AIReviewResponderEnum(String xpath, String description) {

        this.xpath = xpath;
        this.description = description;
    }

    /**
     * Gets the by locator.
     *
     * @return the by locator
     */
    public By getByLocator() {

        return byLocator;
    }

    /**
     * Gets the by xpath.
     *
     * @return the by xpath
     */
    public String getXpath() {

        return xpath;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {

        return description;
    }
}

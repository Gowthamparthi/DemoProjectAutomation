package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum NewRallioHomePageEnum.
 */
public enum NewRallioHomePageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath(
	        "//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='Posts']//ancestor::div//section[contains(@class,'item-g filter post--filter post-filter__main')]//preceding::div//section[@id='main-container-sec']//div[@class='content-g']//div[contains(@class,'g-post postwrap mbl-head--margin')]"),
	        "The page load"),

	/** Navigation main menu header. */
	NAVIGATION_MAIN_MENU_HEADER(By.xpath("//li[contains(@class,'nav-item')]//span[text()]"), "Navigation main menu header"),

	/** Navigation sub menu header. */
	NAVIGATION_SUB_MENU_HEADER(By.xpath("//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[@class='sub-nav-item-txt']"), "Navigation sub menu header"),
	
	/** Brand Hub Location name. */
	BRAND_HUB_LOCATION_NAME(By.xpath("//div[@class='ds-dropdown']//parent::div//button//span"), "Brand Hub Location name"),
	
	/** The brand hub locationfilter home icon. */
	BRAND_HUB_LOCATIONFILTER_HOME_ICON(By.xpath("//div[@class='home-action']//img"),
			"Brand Hub Location Filter home icon"),

	/** Brand Hub Location dropdown. */
	BRAND_HUB_LOCATION_DROPDOWN(By.xpath("//div[@class='brand-profile h-assorted']//div[@class='ds-dropdown']//div[contains(@class,'ds-menu')]"), "Brand Hub Location dropdown"),

	/** Brand Hub Location dropdown search. */
	BRAND_HUB_LOCATION_DROPDOWN_SEARCH(By.xpath("//div[@class='ds-drp-indicator']//parent::div//preceding-sibling::div//input"), "Brand Hub Location dropdown search"),

	/** Select account from dropdown. */
	SELECT_ACCOUNT_FROM_DROPDOWN("//div[@class='brand-profile h-assorted']//div[@class='ds-dropdown']//div[@class='ds-menu']//div[contains(@id,'react-select') and text()='%s']",
	        "Select account from dropdown"),
	
	/** The selected account name. */
	SELECTED_ACCOUNT_NAME("//div[@class='ds-dropdown']//button//span[@class='css-19r5em7' and text()='%s']","Selected Account From Dropdown Name"),
	
	/** The listed locations of user. */
	LISTED_LOCATIONS_OF_USER(By.xpath("//div[@class='rs-drp__menu-list css-11unzgr']/div[contains(@class,'as-item location-icon-wraps rs-drp__option css-yt9ioa-option')]"),
	        "List of Locations"),
	
	/** The listed hub users. */
	LISTED_HUB_USERS(By.xpath("//div[@class='rs-drp__menu-list css-11unzgr']/div[contains(@class,'as-item admin-icon-wraps')]"),
	        "List Of Hubs"),

	/** Rallio icon. */
	RALLIO_ICON(By.xpath("//header//div//img[@alt='Logo' and contains(@src,'ralliohq') and not(contains(@src,'RenderSEO'))]"), "Rallio icon"),

	/** The prod rallio icon. */
	PROD_RALLIO_ICON(By.xpath("//header//div//img[@alt='Logo']"), "Prod Rallio icon"),
	
	/** The renderseo icon. */
	RENDERSEO_ICON(By.xpath("//header//div//img[@alt='Logo' and contains(@src,'renderseo/logo')]"), "RenderSEO icon"),
	
	/** Knowledge base. */
	KNOWLEDGE_BASE(By.xpath("//a//img[@alt='Knowledge Base']"), "Knowledge base"),

	/** Need help. */
	NEED_HELP(By.xpath("//aside//h4[text()='Need Help?']"), "Need help"),

	/** Analytics tab. */
		ANALYTICS_TAB(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Analytics']"), "Analytics tab"),

	/** Analytics tab Leaderboard. */
	ANALYTICS_TAB_LEADERBOARD(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Leaderboard']"), "Analytics tab Leaderboard"),

	/** The analytics tab leaderboard revvlocation. */
	ANALYTICS_TAB_LEADERBOARD_REVVLOCATION(By.xpath("//section[contains(@class,'item-g filter')]//div[@class='form-group']//label//input//following-sibling::span[text()='Revv Locations']"),"Revv Locations Filter"),

	/** Analytics tab ContentAnalytics. */
	ANALYTICS_TAB_CONTENT_ANALYTICS(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Analytics']//ancestor::main//preceding-sibling::div//li//span[text()='Content']"),
	        "Analytics tab ContentAnalytics"),

	/** The analytics tab social analytics. */
	ANALYTICS_TAB_SOCIAL_ANALYTICS(By.xpath(
			"//div[contains(@class,'sub-nav-tabs animate')]//ul//li//span[@class='sub-nav-item-txt' and contains(text(),'Social')]"),
			"Analytics tab SocialAnalytics"),
	
	/** The analytics tab review analytics. */
	ANALYTICS_TAB_REVIEW_ANALYTICS(By.xpath(
			"//div[contains(@class,'sub-nav-tabs animate')]//ul//li//span[@class='sub-nav-item-txt' and contains(text(),'Reviews')]"),
			"Analytics tab ReviewAnalytics"),
	
	/** Analytics tab PageAnalytics. */
		ANALYTICS_TAB_PAGE_ANALYTICS(By.xpath("//div[contains(@class,'sub-nav-tabs animate__animated animate__fadeIn')]//ul//li[3]"), "Analytics tab PageAnalytics"),

	/** Content tab. */
	CONTENT_TAB(By.xpath("//div[@class='react-ripples']//li[contains(@class,'nav-item')]//span[text()='Content']"), "Content tab"),
	
	/** The content tab creator. */
	CONTENT_TAB_CREATOR(By.xpath("//span[@class='sub-nav-item-txt' and contains(text(),'Creator')]"), "Content Tab Creator Page"),

	/** Content tab posts. */
	CONTENT_TAB_POSTS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Posts']"), "Content tab posts"),
	
	/** The content tab campaigns. */
	CONTENT_TAB_CAMPAIGNS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Campaigns']"), "CONTENT_TAB_CAMPAIGN"),

	/** Content tab mediaGallery. */
	CONTENT_TAB_MEDIA_GALLERY(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Media']"), "Content tab mediaGallery"),

	/** Content tab Calendar. */
	CONTENT_TAB_CALENDAR(By.xpath("//div[contains(@class,'sub-nav-tabs')]//ul//li//span[contains(text(),'Calendar')]"), "Content tab Calendar"),

	/** Content tab Feed. */
	CONTENT_TAB_FEED(By.xpath("//div[contains(@class,'sub-nav-tabs')]//ul//li//span[contains(text(),'Feed')]"), "Content tab Feed"),

	/** Content tab FB Ads targetting. */
	CONTENT_TAB_FB_ADS_TARGETTING(By.xpath("//li//h2[text()='Content ']//parent::li//following-sibling::li//div[text()='FB Ads Targeting']"), "Content tab FB Ads targetting"),

	/** Content tab RSS feed. */
	CONTENT_TAB_RSS_FEED(By.xpath("//div//ul//li//span[text()='RSS Feeds']"), "Content tab RSS feed"),

	CONTENT_TAB_SCHEDULER(By.xpath("//span[@class='sub-nav-item-txt' and text()='Scheduler']"),"CONTENT_TAB_SCHEDULER"),

	/** The content tab coupons. */
	CONTENT_TAB_COUPONS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Coupons']"), "Content tab coupons"),

	/** The content tab profile imagery. */
	CONTENT_TAB_PROFILE_IMAGERY(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Profile Imagery']"), "Content tab profile imagery"),

	/** Community tab. */
	COMMUNITY_TAB(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Community']"), "Community tab"),

	/** Community tab inbox. */
	COMMUNITY_TAB_INBOX(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Inbox']"), "Community tab inbox"),

	/** Community tab sandbox. */
	COMMUNITY_TAB_SANDBOX(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Sandbox']"), "Community tab sandbox"),

	/** The marketing tab. */
	MARKETING_TAB(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Marketing']"), "Marketing Tab"),

	/** The marketing tab fb ads. */
	MARKETING_TAB_FB_ADS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='FB Ads']"), "Marketing tab FB Ads"),

	/** The marketing tab Targetting page */
	MARKETING_TAB_TARGETTING(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Targeting']"), "Marketing tab Targetting page"),

	/** Reputation tab. */
	REPUTATION_TAB(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Reputation']"), "Reputation tab"),

	/** Reputation tab outbox. */
	REPUTATION_TAB_OUTBOX(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Outbox']"), "Reputation tab outbox"),

	/** Reputation tab reviews. */
	REPUTATION_TAB_REVIEWS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Reviews']"), "Reputation tab reviews"),

	REPUTATION_TAB_AIREVIEW_RESPONDER(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='AI Review Responder']"), "Reputation tab AI Review Responder"),

	/** Reputation tab Revv SSO. */
    // REPUTATION_TAB_REVV_SSO(By.xpath("//li//h2[text()='Reputation
    // ']//parent::li//following-sibling::li//div[text()='Revv (SSO)']"),
    // "Reputation tab Revv SSO"),

	/** Employee advocacy tab. */
	EMPLOYEE_ADVOCACY_TAB(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Employee Advocacy']"), "Employee advocacy tab"),

	/** Advocacy tab overview. */
	ADVOCACY_TAB_OVERVIEW(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Overview']"), "Advocacy tab overview"),

	/** Advocacy tab leaderboard. */
	ADVOCACY_TAB_LEADERBOARD(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Leaderboard']"), "Advocacy tab leaderboard"),

	/** Advocacy tab Reward Programs. */
	ADVOCACY_TAB_REWARD_PROGRAMS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Reward Programs']"), "Advocacy tab Reward Programs"),

	/** The directory listings tab. */
	DIRECTORY_LISTINGS_TAB(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Directory Listings']"), "Directory listings tab"),

	/** The directory listings tab profile. */
	DIRECTORY_LISTINGS_TAB_PROFILE(By.xpath("//div[contains(@class,'sub-nav-tabs')]//span[contains(text(),'Profile')]"), "Directory listings tab profile"),

	/** The directory listings tab listings. */
	DIRECTORY_LISTINGS_TAB_LISTINGS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Listings']"), "Directory listings tab listings"),

    /** Operations tab. */
    // OPERATIONS_TAB(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Operations']"),
    // "Operations tab"),

    /** Operations tab User Logins. */
    // OPERATIONS_TAB_USER_LOGINS(By.xpath("//li//span[@class='sub-nav-item-txt'
    // and text()='User Logins']"), "Operations tab User Logins"),

	/** Settings tab. */
	SETTINGS_TAB(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Settings']"), "Settings tab"),

	/** Settings tab Rallio profile. */
	SETTINGS_TAB_RALLIO_PROFILE(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Rallio Profile']"), "Settings tab Rallio profile"),

	/** The settings tab profile. */
	SETTINGS_TAB_PROFILE(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Profile']"),"Setting Tab Profile"),
	
	SETTING_TAB_AIPLAYBOOK(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='AI Playbook']"),"Setting Tab AI PlayBook"),
	
	/** The settings tab renderseo profile. */
	SETTINGS_TAB_RENDERSEO_PROFILE(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Profile']"), "Settings tab RenderSEO profile"),
	
	/** Settings tab Social Profile. */
	SETTINGS_TAB_SOCIAL_PROFILE(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Social Profiles']"), "Settings tab Social Profile"),

	/** The settings tab fb ads. */
	SETTINGS_TAB_FB_ADS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='FB Ads']"), "settings tab FB Ads"),

	/** The settings tab reviews. */
	SETTINGS_TAB_REVIEWS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Reviews']"), "Settings tab reviews"),

	/** The settings release form. */
	SETTINGS_TAB_RELEASE_FORM(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Release Form']"), "Settings tab release form"),

	/** The team management tab. */
	TEAM_MANAGEMENT_TAB(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Team Management']"), "Team Management tab"),

	/** The team management tab lists. */
	TEAM_MANAGEMENT_TAB_LISTS_AND_FEEDS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Lists & Feeds']"), "Team Management tab Lists and Feeds"),

	/** The team management tab permissions. */
	TEAM_MANAGEMENT_TAB_PERMISSIONS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Permissions']"), "Team management tab permissions"),

	/** The team management tab connections. */
	TEAM_MANAGEMENT_TAB_CONNECTIONS(By.xpath("//li//span[@class='sub-nav-item-txt' and text()='Connections']"), "team management tab connections"),
	
	/** The teammanagement tab logins. */
	TEAMMANAGEMENT_TAB_LOGINS(By.xpath("//li//span[text()='Logins']"), "The Team Management Logins click"),
	
	/** The linkedin reconnect alert. */
	LINKEDIN_RECONNECT_ALERT(By.xpath("//div[@class='api-alert-box alert-linkedin']//img[@alt='close']"), "Linkedin reconnect alert"),

	/** The users tab. */
	USERS_TAB(By.xpath("//li//span[text()='Users']"), "The Admin User Tab click"),
	
	/** The revv management tab. */
	REVV_TAB(By.xpath("//div[@class='react-ripples']//li[contains(@class,'nav-item animate')]//span[text()='Revv']"), "Revv Management Tab Page"),
	
	//New Rallio Revv module Locators.
	/** The revv dashboard tab. */
	REVV_DASHBOARD_TAB(By.xpath("//li[contains(@class,'ripple')]//span[@class='sub-nav-item-txt' and text()='Dashboard']"),"Revv Dashboard Tab"),
	
	/** The revv surveys tab. */
	REVV_SURVEYS_TAB(By.xpath("//li[@class='ripple']//span[text()='Surveys' and @class='sub-nav-item-txt']"),"REVV_SURVEYS_TAB"),

	REVV_TAB_LOCATIONS(By.xpath("//span[@class='sub-nav-item-txt' and text()='Locations']"),"REVV_TAB_LOCATIONS"),

	REVV_TAB_EMPLOYEES(By.xpath("//li[@class='ripple']//span[text()='Employees' and @class='sub-nav-item-txt']"),"REVV_TAB_EMPLOYEES"),

	/** The settings tab revv. */
	SETTINGS_TAB_REVV(By.xpath("//li[@class='ripple']//span[text()='Revv' and @class='sub-nav-item-txt']"),"SETTINGS_TAB_REVV"),

	REVV_TAB_SETTING(By.xpath("//li[@class='ripple']//span[text()='Settings' and @class='sub-nav-item-txt']"),"SETTINGS_TAB_REVV"),

	/** The settings tab revv global. */
	SETTINGS_TAB_REVV_GLOBAL(By.xpath("//div[contains(@class,'nav-item') and text()='Global']"),"SETTINGS_TAB_REVV_GLOBAL"),
	
	/** The settings tab revv opt in. */
	REVV_TAB_SETTINGSOPT_IN(By.xpath("//div[contains(@class,'nav-item') and text()='Opt-in']"),"SETTINGS_TAB_REVV_OPT_IN"),
	
	/** The settings tab revv survey. */
	REVV_TAB_SETTINGS_SURVEY(By.xpath("//div[contains(@class,'nav-item') and text()='Survey']"),"SETTINGS_TAB_REVV_SURVEY"),
	
	/** The settings tab revv connection. */
	SETTINGS_TAB_REVV_CONNECTION(By.xpath("//div[contains(@class,'nav-item') and text()='Connection']"),"SETTINGS_TAB_REVV_CONNECTION"),

	/** The Admin area option. */
	ADMIN_AREA(By.xpath("//li[contains(@class,'nav-item')]//span[text()='Admin Area']"),"The admin area option"),

	//Profile icon
	/** Profile icon. */
	PROFILE_ICON(By.xpath("//button[@id='dropitems-profile-items']"), "Profile icon"),
	
	/** The Edit option of profile icon. */
	MY_PROFILE_EDIT_ICON(By.xpath(
	        "//div[@class='dropdown-menu show']//a[@role='button']//img[@alt='Edit profile details']"),
	        "clicking Edit icon in profile"),

	/** Profile icon dropdown. */
	PROFILE_ICON_DROPDOWN(By.xpath("//button[@id='dropitems-profile-items']//following-sibling::div[@class='dropdown-menu show']"), "Profile icon dropdown"),

	/** The profile icon dropdown name. */
	PROFILE_ICON_DROPDOWN_NAME("//div[@class='dropdown-menu show']//a[@class='dropdown-item' and text()='%s']","Dropdown  Name"),
	
	/** Dropdown profile name. */
	DROPDOWN_PROFILE_NAME(By.xpath("//div[@class='dropdown-menu show']//a[text()][1]"), "Dropdown profile name"),
	
	/** The dropdown my profile. */
	DROPDOWN_MY_PROFILE(By.xpath("//div[@class='dropdown-menu show']//a//span[text()='My Profile']"),"DropDown My Profile"),
	
	/** Dropdown change password. */
	DROPDOWN_CHANGE_PASSWORD(By.xpath("//div[@class='dropdown-menu show']//a[text()='Change Password']"), "Dropdown change password"),

	/** The dropdown subscriptions. */
	DROPDOWN_SUBSCRIPTIONS(By.xpath("//div[@class='dropdown-menu show']//a[text()='Subscriptions']"), "Dropdown Subscriptions"),

	/** Dropdown notification settings. */
	DROPDOWN_NOTIFICATION_SETTINGS(By.xpath("//div[@class='dropdown-menu show']//a[text()='Notification Settings']"), "Dropdown notification settings"),

	/** Dropdown logOut. */
	DROPDOWN_LOGOUT(By.xpath("//div[@class='dropdown-menu show']//a[text()='Logout']"), "Dropdown logOut"),

	/** The franchiser tab. */
	FRANCHISER_TAB(By.xpath("//span[@class='sub-nav-item-txt' and text()='Franchisors']"), "Franchiser Tab"),

	ACCOUNTS_TAB(By.xpath("//span[@class='sub-nav-item-txt' and text()='Accounts']"), "Accounts tab"),
	
	/*MY_PROFILE_PAGE***/
	/** The my profile detailview location name. */
	MY_PROFILE_DETAILVIEW_USER_NAME(By.xpath("//div[@class='up-head-left']//div[@class='up-short-dtls']//h3"),"My Profile DetailView Location Name"),
	
	MY_PROFILE_DETAILVIEW_PROFILE_IMAGE_NAME(By.xpath("//div[@class='profileinfo-user-section']//div[@class='image']//img[@alt='Profile Info Image']"),"My Profile DetailView Profile Image Name"),
	
	/** The my profile detailview close button. */
	MY_PROFILE_DETAILVIEW_CLOSE_BUTTON(By.xpath("//img[@alt='close' and @class='mod__close--img']"),"My Profile DetailView Close Button"),
	
	/** The my profile detail view user ID */
	MY_PROFILE_DETAIL_VIEW_USER_ID(By.xpath("//div[@class='profile__modal--content gwhite-bg']//div[@class='up-header']//span[@class='upd-email']"),"My Profile Detail View user ID"),
	
	
	/** The my profile detail view images tab */
	MY_PROFILE_DETAIL_VIEW_IMAGES_TAB(By.xpath("//div[@class='modal-body']//div[@class='sub-nav-tabs']//button[@id='add-tabs-tab-photos']"),"My Profile Detail View images tab"),
	
	/** The my profile detail view videos tab */
	MY_PROFILE_DETAIL_VIEW_VIDEOS_TAB(By.xpath("//div[@class='modal-body']//div[@class='sub-nav-tabs']//button[@id='add-tabs-tab-videos']"),"My Profile Detail View videos tab"),
	
	/** The my profile detail view documents tab */
	MY_PROFILE_DETAIL_VIEW_DOCUMENTS_TAB(By.xpath("//div[@class='modal-body']//div[@class='sub-nav-tabs']//button[@id='add-tabs-tab-documents']"),"My Profile Detail View documents tab"),
	
	/** The my profile detail view rewards tab */
	MY_PROFILE_DETAIL_VIEW_POSTS_TAB(By.xpath("//div[@class='modal-body']//div[@class='sub-nav-tabs']//button[@id='add-tabs-tab-posts']"),"My Profile Detail View posts tab"),
	
	/** The my profile detail view posts tab */
	MY_PROFILE_DETAIL_VIEW_REWARDS_TAB(By.xpath("//div[@class='modal-body']//div[@class='sub-nav-tabs']//button[@id='add-tabs-tab-rewards']"),"My Profile Detail View rewards tab"),
	
	/** The my profile detailview facebook inactive. */
	MY_PROFILE_DETAILVIEW_FACEBOOK_INACTIVE(By.xpath("//div[@class='up-head-right']//div[@class='fltr-imc selectsocial platformAnchors']//a[@class='custom-disabled']//img[@alt='Facebook']"),"Facebook InActive"),
	
	/** The my profile detailview instagram inactive. */
	MY_PROFILE_DETAILVIEW_INSTAGRAM_INACTIVE(By.xpath("//div[@class='up-head-right']//div[@class='fltr-imc selectsocial platformAnchors']//a[@class='custom-disabled']//img[@alt='Instagram']"),"Instagram Inactive"),
	
	/** The my profile detailview twitter inactive. */
	MY_PROFILE_DETAILVIEW_TWITTER_INACTIVE(By.xpath("//div[@class='up-head-right']//div[@class='fltr-imc selectsocial platformAnchors']//a[@class='custom-disabled']//img[@alt='X (Formerly Twitter)']"),"Twitter InActive"),

	/** The my profile detaiview linkedin inactie. */
	MY_PROFILE_DETAIVIEW_LINKEDIN_INACTIVE(By.xpath("//div[@class='up-head-right']//div[@class='fltr-imc selectsocial platformAnchors']//a[@class='custom-disabled']//img[@alt='Linkedin']"),"LinkedIn Inactive"),

	/** The my profile detailview facebook active. */
	MY_PROFILE_DETAILVIEW_FACEBOOK_ACTIVE(By.xpath("//div[@class='up-head-right']//div[@class='fltr-imc selectsocial platformAnchors']//a[@rel='noopener noreferrer']//img[@alt='Facebook']"),"Facebook Active"),
	
	/** The my profile detailview instagram active. */
	MY_PROFILE_DETAILVIEW_INSTAGRAM_ACTIVE(By.xpath("//div[@class='up-head-right']//div[@class='fltr-imc selectsocial platformAnchors']//a[@rel='noopener noreferrer']//img[@alt='Instagram']"),"Instagram Active"),
	
	/** The my profile detailview twitter active. */
	MY_PROFILE_DETAILVIEW_TWITTER_ACTIVE(By.xpath("//div[@class='up-head-right']//div[@class='fltr-imc selectsocial platformAnchors']//a[@rel='noopener noreferrer']//img[@alt='X (Formerly Twitter)']"),"Twitter Active"),

	/** The my profile detailvie linkedin active. */
	MY_PROFILE_DETAILVIEW_LINKEDIN_ACTIVE(By.xpath("//div[@class='up-head-right']//div[@class='fltr-imc selectsocial platformAnchors']//a[@rel='noopener noreferrer']//img[@alt='Linkedin']"),"LinkedIn Active"),
	
	/** The my profile detail view edit icon. */
	MY_PROFILE_DETAIL_VIEW_EDIT_ICON(By.xpath("//div[@class='modal-body']//div[@class='profileinfo-user-section']//div[@class='edit-icon']"),"Detail view edit icon"),
	
	/** The my profile detail view first name. */
	MY_PROFILE_DETAIL_VIEW_FIRST_NAME(By.xpath("//div[@class='modal-body']//div[@class='up-head-right']//input[@name='firstName']"),"First name"),
	
	/** The my profile detail view last name. */
	MY_PROFILE_DETAIL_VIEW_LAST_NAME(By.xpath("//div[@class='modal-body']//div[@class='up-head-right']//input[@name='lastName']"),"Last name"),
	
	/** The my profile detail view facebook profile URL */
	MY_PROFILE_DETAIL_VIEW_FACEBOOK_PROFILE_URL(By.xpath("//div[@class='modal-body']//div[@class='up-head-right']//input[@name='facebookProfileUrl']"),"Facebook profile URL"),
	
	/** The my profile detail view Instagram profile URL */
	MY_PROFILE_DETAIL_VIEW_INSTAGRAM_PROFILE_URL(By.xpath("//div[@class='modal-body']//div[@class='up-head-right']//input[@name='instagramProfileUrl']"),"Instagram profile URL"),
	
	/** The my profile detail view twitter profile URL */
	MY_PROFILE_DETAIL_VIEW_TWITTER_PROFILE_URL(By.xpath("//div[@class='modal-body']//div[@class='up-head-right']//input[@name='twitterProfileUrl']"),"Twitter profile URL"),
	
	/** The my profile detail view linkedin profile URL */
	MY_PROFILE_DETAIL_VIEW_LINKEDIN_PROFILE_URL(By.xpath("//div[@class='modal-body']//div[@class='up-head-right']//input[@name='linkedinProfileUrl']"),"Linkedin profile URL"),
	
	/** The my profile detail view Update button */
	MY_PROFILE_DETAIL_VIEW_UPDATE_BUTTON(By.xpath("//div[@class='modal-body']//div[@class='up-head-right']//button[@type='submit']"),"Update button"),
	
	/** The my profile detail view back button */
	MY_PROFILE_DETAIL_VIEW_BACK_BUTTON(By.xpath("//div[@class='modal-body']//div[@class='up-head-right']//button[@type='reset']"),"Back button"),
	
	/** The my profile detail view image edit icon */
	MY_PROFILE_DETAIL_VIEW_IMAGE_EDIT_ICON(By.xpath("//div[@class='modal-body']//div[@class='up-head-left']//input[@type='file']"),"Image edit option"),
	
	/**  my profile detail view success message */
	MY_PROFILE_DETAIL_VIEW_SUCCESS_MESSAGE(By.xpath("//div[@class='Toastify__toast-body']//span[@class='success-mess-txt' and text()='Saved!']")," my profile detail view success message"),

	/**  my profile detail view user name */
	MY_PROFILE_DETAIL_VIEW_USER_NAME("//div[@class='modal-body']//div[@class='up-short-dtls']//span[contains(text(),'%s')]"," my profile detail view user name"),

	/**  Leaderboard page user name */
	LEADERBOARD_PAGE_USER_NAME("//tbody//div[contains(@class,'initial-status')]//div[@title='%s']","Leaderboard page user name"),
	
	/**  Leaderboard page edited image */
	MY_PROFILE_DETAIL_VIEW_IMAGE_NAME("//div[@class='profileinfo-user-section']//div[@class='image']//img[contains(@src,\"%s\")]","Leaderboard page image"),
	
	/**  Leaderboard page edited image */
	LEADERBOARD_PAGE_EDITED_IMAGE(By.xpath("//div[@class='profileinfo-user-section']//div[@class='image']")," Leaderboard image"),
	
	/**  My profile detail view fields modal*/
	MY_PROFILE_DETAIL_VIEW_EDITING_FIELDS_MODAL(By.xpath("//div[@class='profile__modal--content gwhite-bg']//div[@class='up-head-right']//div[@class='up-fields']"),"My profile detail view fields modal"),
	
	/**  My profile detail view image delete option*/
	MY_PROFILE_DETAIL_VIEW_EDIT_IMAGE_DELETE_ICON(By.xpath("//div[@class='modal-body']//button[@class='btn btn-secondary']//div[@class='delete-icon']//img[@alt='close']"),"My profile detail view image delete icon"),
	
	/**  My profile detail view With no profile picture*/
	MY_PROFILE_DETAIL_VIEW_EDIT_NO_PROFILE_PICTURE(By.xpath("//div[@class='profileinfo-user-section']//div[@class='image']//img[contains(@src,'user-avatar-common.png')]"),"My profile detail view no profile picture - default common avatar"),
	
	/**  My profile detail view search option*/
	MY_PROFILE_DETAIL_VIEW_SEARCH_OPTION(By.xpath("//div[@class='react-tags__search-input']//input[@placeholder='Search']")," My profile detail view search option"),


	/** Media tab - list of images*/
	MEDIA_TAB_LIST_OF_ASSETS(By.xpath("//div[@class='masonry-grid_column']//div[contains(@class,'m-item')]//div[@class='m-ast']"),"Media tab list of images"),

	MEDIA_LIST_COUNT("(//div[@class='masonry-grid_column']//div[contains(@class,'m-item')]//div[@class='m-ast'])[%s]","Media list"),

	MY_PROFILE_IMAGE_COUNT("(//div[@class='fade tab-pane active show']//div[@class='masonry-grid_column']//div[contains(@class,'m-item')])[%s]","Mt Profile Image Count"),

	/** My Profile detail view list of images*/
	MY_PROFILE_DETAIL_VIEW_LIST_OF_ASSETS(By.xpath("//div[@class='modal-body']//div[@class='masonry-list-view-group']//div[@class='m-item']//div[@class='m-ast-dtls']"),"Media tab list of images"),
	
	/** Videos filter. */
	VIDEOS_FILTER(By.xpath("//input[@type='radio']//following-sibling::span[text()='Video']"), "Videos filter"),
	
	/** Media list. */
	MEDIA_LIST(By.xpath("//div[@class='infinite-scroll-component local-ini']//div[@class='m-item']"), "Media list"),

	/** Post list. */
	POST_LIST(By.xpath("//div[@class='pls post-list__main']//div[contains(@class,'m-item')]"), "Post list"),


	/** Reward list. */
	REWARD_LIST(By.xpath("//div[@class='infinite-scroll-component local-ini']//tr[@data-testid='tr']"), "Reward list"),
	
	/** The Media page footer. */
	MEDIA_FOOTER(By.xpath("//div[@class='m-item'][last()]"), "Footer"),
	
	/** The footer. */
	POST_FOOTER(By.xpath("//div[@class='modal-body']//div[contains(@class,'m-item mi-compact') ][last()]"), "Footer"),
	
	/** The rewards footer. */
    REWARDS_FOOTER(By.xpath("//table[@class='responsiveTable table']//tbody//tr[last()]"), "Footer"),
	
	 /** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),
	
	/** The search result. */
	SEARCH_RESULT("//div[@class='mast-prof-txt']//span[@class='sm-txt-top' and text()='%s']",
			"Search result"),
	
	/** The Post search result. */
	POST_SEARCH_RESULT("//div[@class='infinite-scroll-component local-ini']//div[@class='msg-wrapper']//p[text()='%s']",
			"Search result"),
	
	/** The Post search result. */
	REWARD_SEARCH_RESULT("//tbody//tr//td//div[@class='cmfrt-tv-item']//span[text()='%s']",
			"Reward Search result"),
	
	/** The Document  search result. */
	DOCUMENT_SEARCH_RESULT("//div[@class='masonry-grid_column']//div[@class='mast-prof-txt']//span[text()='%s']",
			"Document Search result"),
	
	LOCATION_NAME(By.xpath("//div[@class='profileinfo-user-section']//div[@class='image']//img[@src]"),"My profile detail view no profile picture - default common avatar"),
	
	/** Search box. */
	MEDIA_SEARCH_BOX(By.xpath("//div[@class='react-tags__search-input r-mt0']//input[@placeholder='Search text']"), "Search box"),

	/** MediaSource All filter. */
	MEDIA_SOURCE_ALL_FILTER(By.xpath("//input[@name='source-Source']//following-sibling::span[contains(text(),'All')]"), "MediaSource All filter"),


	HOMEPAGE_MODULES(By.xpath("//li[contains(@class,'nav-item')]//span"), "HOMEPAGE_MODULES"),
	
	REVV_TAB_PAGE_CONNECTNOW_BUTTON(By.xpath("//span[text()='Revv']//parent::h3[text()='Already a ' and text()=' member?']//parent::div//button//span[text()='Connect now']"), "REVV_TAB_PAGE_CONNECTNOW_BUTTON"),
	
	/** The ai video donot show me checkbox. */
	AI_VIDEO_DONOT_SHOW_ME_CHECKBOX(By.xpath("//div[@class='aicoach-body']//label[@class='checkbox-item']//span[@class='checkbox-hover']//input[@name='localizePost']"),"AI Subscribtion Video Check Box"),
	
	/** The ai subscribtion video play. */
	AI_SUBSCRIBTION_VIDEO_PLAY(By.xpath("//div[@role='tooltip']//div[@class='aicoach-body']//div[@class='aicoach-cnt']//div[@class='ai-coach-video']"),"AI Subscribtion Video Play"),
	
	/**  Account switcher location name*/
	ACCOUNT_SWITCHER_LOCATION_NAME("//div[@id='account-switcher-dropdown']//div[contains(@class,'as-item location-icon-wraps') and text()='%s']","Account switcher location name"),

	VIDEO_TUTORIAL_TAB(By.xpath("//div[@class='nh-txt']//h4[text()='Video Tutorials']"),"Video Tutorial Tab"),

	FEATURE_UPDATES_TAB(By.xpath("//div[@class='nh-txt']//h4[text()='Feature Updates']"),"Feature Updates Tab"),

	FEATURE_UPDATES_PAGELOAD(By.xpath("//div[@class='premium-banner-ib premium-banner-min-height premium-banner-animation5 zoomin active']"),"Features Updates PageLoad"),

	SSO_REDIRECTION_HOME_PAGE(By.xpath("//iframe[@title='Rallio']"),"SSO Redirection Home page"),

	CALENDAR_HOME_PAGE(By.xpath("//div[@class='content-g']//div[@class='calendar-section-main-wrp calb-main mx-0']//div[contains(@class,'cal-lc-views calendar-calview')]"),"Calendar Home Page"),
	LIST_VIEW_BUTTON(
			By.xpath("//div[contains(@class,'stats global-stats-section-wrp')]//div//span[contains(text(),'LIST VIEW')]"),
			"List view button"),

	POTENTIAL_REACH_FILTER(By.xpath("//div[@class='an-stat--card stats-level-05 with-out-brand--avg']//span[@class='stats-title-text revert-w' and text()='Potential Reach']"),"Potential Reach Filter"),

	//Royal Caribbean Page

	YOUR_ACCOUNTALREADY_PAID_FOR_POPUP(By.xpath("//div[@class='w-100 bg-white d-flex justify-end align-items-center']//p[text()]"),"YOUR_ACCOUNTALREADY_PAID_FOR_POPUP"),

	COMMUNITY_TAB_LIST_TEXT(By.xpath("//div[@class='sales-cnt']/p"),"Community Tab List Text"),
	COMMUITY_TAB_HEADER("//div[@class='eaTop-cnt']//h3//span[text()='%s']","Community Tab Header"),

	COMMUNITY_TAB_VIDEO_SECTION(By.xpath("//div[@class='video-outer-element']//div[@class='m-ast-itm m-ast-video']"),"Community Tab Video Section"),

	COMMUNITY_TAB_UPGRADE(By.xpath("//button[@class='csv-btn btn btn-primary']//span[text()='Upgrade']"),"Community Tab Upgrade"),

	LIST_VIEW_UPGRADE(By.xpath("//button[@class='csv-btn btn btn-primary']//span[text()='Upgrade']"),"List View Upgrade"),

	SIDE_VIEW_UPGRADE(By.xpath("//button[@type='submit' and text()='Upgrade']"),"SIDE_VIEW_UPGRADE"),

	UPGRADE_DETAILVIEW_PRIME_MEMEBERSHIP_HEADER(By.xpath("//h2[text()='Get Premium Membership']//parent::div//p[contains(text(),'Premium membership provides unlimited AI')]"),"UPGRADE_DETAILVIEW_PRIME_MEMEBERSHIP_HEADER"),

	UPGRADE_DEATILVIEW_PRIME_FEATURES_LIST(By.xpath("//h5[text()='Premium Features']//ancestor::div[@class='raisb-cnt']//ol//li"),"Prime Features List"),

	UPGRADE_DETAILVIEW_CLOSE_BUTTON(By.xpath("//div[@class='mod__close--icon']//img[@alt='cancel']"),"UPGRADE_DETAILVIEW_CLOSE_BUTTON"),

	UPGRADE_DETAILVIEW_BEFORE_SEVEN_DAYS_PLAN("//span[@class='rais-lbl-big rais__lbl-tot' and text()='%s']//parent::div//following-sibling::div//span[@class='rais-value ravs-xbold' and text()='$ 7.95']","UPGRADE_DETAILVIEW_BEFORE"),

	UPGRADE_DETAILVIEW_AFTER_SEVEN_DAYS_PLAN("//span[@class='rais-lbl-big rais__lbl-tot' and text()='%s']//parent::div//following-sibling::div//span[@class='rais-value ravs-xbold' and text()='$ 9.95']","UPGRADE_DETAILVIEW_BEFORE"),

	UPGRADE_DETAILVIEW_BACK_BUTTON(By.xpath("//button[@class='ac-btn ac-secondary-white ac-outline' ]//span[text()='Back']"),"UPGRADE_DETAILVIEW_BACK_BUTTON"),

	UPGRADE_DETAILVIEW_MAKE_PAYMENT_BUTTON(By.xpath("//button[@class='ac-btn ac-primary' ]//span[text()='Make Payment']"),"Upgrae Detailview Make Payment Button"),

	FEED_TAB(By.xpath("//span[@class='sub-nav-item-txt' and text()='Feed']"),"FEED_TAB"),

	//Royal Caribbean Video Tab

	SUBSCRIPTION_VIDEO_PAGE_LOAD(By.xpath("//div[@class='stepper-holder']//ancestor::div//div[@class='sec-main__content']//div[@class='react-player__preview']"),"Subscribtion Video Page Load"),

	SUBSCRIBT_VIDEO_NEXT_BUTTON(By.xpath("//button[contains(@class,'ac-btn ac-primary') and text()='Next']"),"Subscription Video Next Button"),

	SUBSCRIBT_VIDEO_FINISH_BUTTON(By.xpath("//button[contains(@class,'ac-btn ac-primary') and text()='Finish']"),"Subscription Video Finish Button"),

	AUTO_GENERATE_AI_UPDATE_NOW_BUTTON(By.xpath("//div[@class='react-ripples ac-primary-box']//button[text()='Update now!']"),"Auto Generate AI Update Now Button"),

	AUTO_GENERATE_AI_POST_ALERT_CLOSE(By.xpath("//p[text()='Auto generated AI posts can now be turned on or off from the AI Playbook.']//ancestor::div[contains(@class,'api-alert-box')]//div//img[@alt='close']"),"Auto Generate AI Post Alert Close"),

	INSTAGRAM_NEED_TO_RECONNECT_FIX_THIS_BUTTON(By.xpath("//p[text()='Instagram needs to be reconnected']//parent::div//parent::div[@class='api-alert-box alert-insta']//button//span[text()='Fix This']"),"Instagram Need To Reconnect Fix This Button"),
	;


	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new new rallio home page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private NewRallioHomePageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new new rallio home page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private NewRallioHomePageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

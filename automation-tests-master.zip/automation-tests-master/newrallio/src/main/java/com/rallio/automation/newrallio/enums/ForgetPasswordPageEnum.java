package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum ForgetPasswordPageEnum.
 */
public enum ForgetPasswordPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//h2[text()='Forgot ']//span[text()='Password?']"), "Page load for forgetPassword"),

	/** The email address. */
	EMAIL_ADDRESS(By.xpath("//input[@name='forgotPasswordInputEmail']"), "Email Adress in ForgetPassword Page"),

	/** Invalid message. */
	INVALID_MESSAGE(By.xpath("//span[text()='Invalid Email Address']"), "Invalid message"),

	/** The submit button. */
	SUBMIT_BUTTON(By.xpath("//button[@class='ac-btn ac-primary ac-block' and text()='Submit']"), "Submit Button");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new dashboard page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private ForgetPasswordPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new dashboard page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private ForgetPasswordPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return byLocator;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}
}

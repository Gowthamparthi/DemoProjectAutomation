package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum ContentTabCalendarPageEnum.
 */
public enum ContentTabCalendarPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//li[@class='ripple active']//span[text()='Calendar']//ancestor::div//section[@class='item-g filter calendar-filter__main']//preceding::section[@id='main-container-sec']//div[contains(@class,'calendar-stats-section')]"), "The page load"),
	
	/** The list of posts. */
	LIST_OF_POSTS_PRESENT(
			By.xpath("//div[contains(@class,'calendar-section-main')]//div[contains(@class,'liv-right list-item')]"),
			"List Of Posts Present"),
	
	/** The page load withoutdata. */
	PAGE_LOAD_WITHOUTDATA(By.xpath("//div[@class='no-data nd-text-only dshbrd-no-data']"), "Page Without-data"),

	/** Scheduled posts stats count. */
	SCHEDULED_POSTS_STATS_COUNT(
			By.xpath("//span[@class='platform-text' and contains(text(),'Scheduled')]//following-sibling::span//div"),
			"Scheduled stats count"),
	
	/** The awaiting approval post profile icon. */
	//Awaiting Approval Elements.
	AWAITING_APPROVAL_POST_PROFILE_ICON(By.xpath(
				"//div[@class='li-view-main'][1]//div[@class='liv-right list-item'][1]//div[@class='header-section']//div[@class='p-avatar']//img[contains(@class,'social-media-post')]"),
				"Awaiting Approval profile icon"),
	
	/** The awaiting approval brandname. */
	AWAITING_APPROVAL_BRANDNAME(By.xpath("//div[@class='li-view-main'][1]//div[@class='liv-right list-item'][1]//div[@class='header-section']//div[@class='p-title']//h5"),
			"Awaiting Approval Brand name"),
	
	/** The awaiting approval date time. */
	AWAITING_APPROVAL_DATE_TIME(By.xpath("//div[@class='li-view-main'][1]//div[@class='liv-right list-item'][1]//div[@class='header-section']//div[@class='p-title']//h6"), "Events Post Date Time"),
	
	/** The awaiting approval posts stats count. */
	AWAITING_APPROVAL_POSTS_STATS_COUNT(
			By.xpath("//div[contains(@class,'approval-wrp ')]//span[@class='platform-count']//div"),
			"ApprovalAwaiting stats count"),
	
	/** The awaiting approval posts description. */
	AWAITING_APPROVAL_POSTS_DESCRIPTION(
			By.xpath("//div[@class='stats-item fb-sc stats-level-02 approval-wrp ']//span//span[contains(text(),'')]"),
			"ApprovalAwaiting Post Description"),
	
	/** The awaiting approval description of the post by position. */
	AWAITING_APPROVAL_DESCRIPTION_OF_THE_POST_BY_POSITION("//div[@class='li-view-main'][%s]//div[@class='liv-right list-item']//div[@class='desc-text']//p",
			"Awaiting Approval Post Description"),
	
	/** The awaiting approval approve button by post description. */
	AWAITING_APPROVAL_APPROVE_BUTTON_BY_POST_DESCRIPTION(
			"//div[@class='desc-text']//p[contains(text(),'%s')]//parent::div//following-sibling::div[@class='full-width-btn']//div//button[text()='Approve']",
			"Approval Awaiting Button by Post Description"),
	
	/** The awaiting approval remove button by post description. */
	AWAITING_APPROVAL_REMOVE_BUTTON_BY_POST_DESCRIPTION(
			"//div[@class='liv-right list-item']//p[text()='%s']//parent::div[@class='desc-text']//following-sibling::div[@class='header-section cal-mt-btns']//button[text()='Remove']",
			"Awaiting Approval Button by Post Description"),

	/** The events posts stats count. */
	EVENTS_POSTS_STATS_COUNT(
			By.xpath("//span[@class='platform-text' and contains(text(),'Events')]//following-sibling::span//div"),
			"Eventsposts stats count"),

	EVENTS_POSTS_LIST_VIEW(By.xpath("//div[@class='liv-right list-item']//div[@class='cal-event-notes-wrap']"),"Events Posts List View"),

	EVENTS_POSTS_CALENDAR_VIEW(By.xpath("//div[@class='creator-schedule-section-wrp purple-bg onlyText']"),"Events Post Calendar View"),

	/** The posts stats section. */
	POSTS_STATS_SECTION(By.xpath("//div[@class='calendar-stats-section-wrp']//div[contains(@class,'stats')]"), "Posts status Section"),

	/** Requested posts stats count. */
	REQUESTED_POSTS_STATS_COUNT(By.xpath(
			"//span[@class='sc-head' and contains(text(),'Requested')]//following-sibling::span[@class='sc-counts']"),
			"Requested posts stats count"),

	/** Scheduled posts list. */
	SCHEDULED_POSTS_LIST(By.xpath("//div[@class='li-view-main']//div[@class='liv-right list-item']"),
			"Scheduled posts list"),

	/** The calendar stats count. */
	CALENDAR_STATS_COUNT(By.xpath("//div[@class='chart-module-top']//span[@class='mod-count']//div"),"Calendar Stats Count"),
	
	/** The list of posts with date. */
	LIST_OF_POSTS_WITH_DATE(
			By.xpath("(//div[contains(@class,'calendar-section-main')]//div[contains(@class,'list-item')]//div[@class='remove-btn-cal ']//span)[1]"),
			"LIST_OF_POSTS_WITH_DATE"),

	/** Requested posts list. */
	REQUESTED_POSTS_LIST(
			"//div[@class='mCal-Content requested-post']//div[@class='clv-lr-cnt']//div[contains(@class,'srt-item')]",
			"Requested posts list"),

	/** The scheduled tab. */
	SCHEDULED_TAB(By.xpath("//div[contains(@class,'level-02 scheduledsection-wrp')]"), "Scheduled Tab"),

	/** The Awaiting approval tab. */
	AWAITING_APPROVAL_TAB(By.xpath("//div[contains(@class,'level-02 approval-wrp')]"), "The Awaiting approval tab."),
	
	/** The scheduled to option. */
	SCHEDULED_TO_OPTION(
			By.xpath("//div//img[contains(@src,'location')]//parent::div//parent::div[text()='Scheduled To ']//span"),
			"Scheduled To Option"),
	
	/** The scheduled to remove button. */
	SCHEDULED_TO_REMOVE_BUTTON(By.xpath("//div[contains(@class,'ac-danger-box')]//button[text()='Remove']"),
			"Scheduled To Remove Button"),

	REMOVE_BUTTON_OF_SCHEDULED_POST_IN_CALENDAR("//div[@class='liv-right list-item']//div[@class='desc-text']//p[text()='%s']//ancestor::div[@class='liv-right list-item']//div[contains(@class,'ac-danger-box')]//button[text()='Remove']","REMOVE_BUTTON_OF_SCHEDULED_POST_IN_CALENDAR"),

	REMOVE_BUTTON_OF_SCHEDULED_POST_IN_CALENDAR_DISABLE("//div[@class='liv-right list-item']//div[@class='desc-text']//p[text()='%s']//ancestor::div[@class='liv-right list-item']//div[contains(@class,'pointer-events-none')]//button[text()='Remove']","REMOVE_BUTTON_OF_SCHEDULED_POST_IN_CALENDAR_DISABLE"),


	/** The scheduled edit button. */
	SCHEDULED_EDIT_BUTTON(By.xpath("//div[contains(@class,'ac-secondary-box r-ml2')]//button[text()='Edit']"),
			"Scheduled Edit Button"),
	
	/** The scheduled edit inactive. */
	SCHEDULED_EDIT_INACTIVE("//p[text()='%s']//ancestor::div[@class='liv-right list-item']//div[contains(@class,'pointer-events-none')]//button[text()='Edit']","Scheduled Edit button Inactive"),
	
	/** The scheduled edit active. */
	SCHEDULED_EDIT_ACTIVE("//p[text()='%s']//ancestor::div[@class='liv-right list-item']//div[contains(@class,'react-ripples')]//button[text()='Edit']","Scheduled Edit button Active"),

	EDIT_DETAILVIEW_EDIT_SCHEDULE_ACTIVE(By.xpath("//div[@class='right-button-section']//button[contains(@class,'filter-sc-btn') and not(contains(@class,'events-none')) and text()='Edit Schedule']"),"Edit Schedule"),

	EDIT_DETAILVIEW_EDIT_SCHEDULE_INACTIVE(By.xpath("//div[@class='right-button-section']//button[contains(@class,'filter-sc-btn events-none') and text()='Edit Schedule']"),"Edit Schedule Inactive"),

	/** The scheduled post  edit ok button. */
	SCHEDULED_POST__EDIT_OK_BUTTON(By.xpath("//div[@class='footer-btn-section']//button[text()='Ok']"),"Scheduled Post Edit Ok Button"),

	/** The scheduled edit button by count. */
	SCHEDULED_EDIT_BUTTON_BY_COUNT(
			"//div[@class='sche-text']//span[text()='%s']//parent::div//img[contains(@src,'location')]",
			"Scheduled Edit Button By unique value"),

	/** The scheduled edit button by posttext. */
	SCHEDULED_EDIT_BUTTON_BY_POSTTEXT(
			"//div[@class='desc-text']//p[contains(text(),'%s')]//ancestor::div[contains(@class,'liv-right list-item')]//button[text()='Edit']",
			"Scheduled Edit Button By Post text"),

	/** The scheduled edit page. */
	SCHEDULED_EDIT_MAIN_PAGE(By.xpath(
			"//div[@class='post-tabs']//parent::div//parent::div[@class='post-content']//following-sibling::div[contains(@class,'addpost')]//parent::div//parent::div[contains(@class,'create-post__main')]"),
			"Scheduled Edit Page"),

	/** The scheduled edit model page. */
	SCHEDULED_EDIT_MODEL_PAGE(
			By.xpath("//div[@class='modal-content']//h3[text()='Schedule']//parent::div[@class='modal-body']"),
			"Scheduled Edit Page"),

	/** The scheduled location list. */
	SCHEDULED_LOCATION_LIST(By.xpath(
			"//div[@class='select-location-section-wrp']//div[@class='card']//div//div[@class='icons-loc']//following-sibling::span"),
			"Scheduled Location List"),

	/** The scheduled location minus button. */
	SCHEDULED_LOCATION_MINUS_BUTTON(By.xpath(
			"//div[@class='select-location-section-wrp']//div[@class='card']//div//div[@class='icons-loc']//following-sibling::span"),
			"Scheduled Location Minus Button"),

	/** The scheduled location minus button by locationname. */
	SCHEDULED_LOCATION_MINUS_BUTTON_BY_LOCATIONNAME(
			"//div[@class='select-location-section-wrp']//span[text()='%s']//parent::div//following-sibling::div//div[@class='icons']//img",
			"Scheduled Location Minus Button"),
	
	/** The scheduled to select locations tab. */
	SCHEDULED_TO_SELECT_LOCATIONS_TAB(
			"//div[@id='react-aria5640137608-9-tabpane-specific-locations-or-lists']",
			"Scheduled To Select Locations Tab"),
	
	/** The scheduled to select location search icon. */
	SCHEDULED_TO_SELECT_LOCATION_SEARCH_ICON(
			"(//div[@class='ds-menu']//div[1][@class='rs-drp__control rs-drp__control--menu-is-open css-8xdd8h-control']//div[2])[6]",
			"Scheduled To Select Location search icon"),
	
	/** The scheduled to select location search tab. */
	SCHEDULED_TO_SELECT_LOCATION_SEARCH_TAB(
		"//div[@class='rs-drp__input']//input[@id='react-select-61-input']",
			"Scheduled To Select Location search Tab"),
	
	/** The scheduled to search result location. */
	SCHEDULED_TO_SEARCH_RESULT_LOCATION(
			"(//div[@class='rs-drp__menu-list css-11unzgr']//div[contains(@class,'rs-drp__group')]//div[@title='%s'])[3]",
			"Scheduled To search result location"),
	
	////div[@class='ds-dropdown']//div[@id='selectlocations-dropdown-outbox']//div[@class='rs-drp__value-container rs-drp__value-container--has-value css-1hwfws3']//div[@class='rs-drp__input']//input

	/** The scheduled edit schedule button. */
	SCHEDULED_EDIT_SCHEDULE_BUTTON(By.xpath("//div//button[text()='Edit Schedule']"), "Scheduled Edit-schedule Button"),

	/** The scheduled hide all button. */
	SCHEDULED_HIDE_ALL_BUTTON(By.xpath("//button//span[text()='Hide All']"),
			"Scheduled Hide All Button"),

	/** The scheduled edit corporate only. */
	SCHEDULED_EDIT_CORPORATE_ONLY(
			By.xpath("//label[text()='Corporate Only']//parent::div//input[@id='formBasicCheckbox2']"),
			"Scheduled Edit-schedule Button"),

	/** The scheduled date time. */
	SCHEDULED_DATE_TIME(By.xpath(
			"//div[contains(@class,'create-post__main')]//div//div//div//span[text()='Scheduled:']//following-sibling::span"),
			"Scheduled Date Time"),

	/** The scheduled edit time button. */
	SCHEDULED_EDIT_TIME_BUTTON(By.xpath("//div//input[contains(@class,'fltr-pt-time')]"), "Scheduled Edit Time Button"),
	
	/** The random unselected time. */
	RANDOM_AVAILABLE_TIME(
			By.xpath("//div/ul[@class='react-datepicker__time-list']//li[@class='react-datepicker__time-list-item ']"),
			"Random Available Time"),

	/** The scheduled time list. */
	SCHEDULED_TIME_LIST(By.xpath("//div[contains(@class,'time-box')]//li[contains(@class,'list-item')]"),
			"Scheduled Time List"),
	
	/** The scheduled time from timelist by position. */
	SCHEDULED_TIME_FROM_TIMELIST_BY_POSITION(By.xpath("//div[contains(@class,'time-box')]//li[contains(@class,'list-item')]['%s']"),
			"Scheduled Time From Time List By Position"),

	/** The time schedule footer button. */
	TIME_SCHEDULE_FOOTER_BUTTON(By.xpath("//div[@class='btn schedule-btn' and text()='Schedule']"),
			"Scheduled Time List "),

	/** The scheduled edit date button. */
	SCHEDULED_EDIT_DATE_BUTTON(By.xpath("//div//input[contains(@class,'fltr-date-item fltr-from-date')]"),
			"Scheduled Edit date button"),

	/** The requested tab. */
	REQUESTED_TAB(By.xpath("//div[@class='ch-main']//button//span[text()='requested']"), "Requested Tab"),

	/** The awaiting approval button. */
	AWAITING_APPROVAL_BUTTON(
			By.xpath("//div[contains(@class,'stats-section')]//div[contains(@class,'approval-wrp')]"),
			"Awaiting Approval Button"),
	
	/** The awaiting approval cancel button. */
	AWAITING_APPROVAL_CANCEL_BUTTON(
			By.xpath("//div[@class='ac-btn ac-secondary-white ac-outline size-sm ' and text()='Cancel']"),
			"Awaiting Approval Cancel Button"),
	
	//Events Page Locators.
	/** The events tab button. */
	EVENTS_TAB_BUTTON(By.xpath("//div[contains(@class,'stats-section')]//div[contains(@class,'events')]"),
			"EventsTab Button"),

	/** The events page load. */
	EVENTS_PAGE_LOAD(By.xpath("//div[contains(@class,'events-wrp  active')]//ancestor::div//div[contains(@class,'calendar-section-main-wrp')]//div[contains(@class,'view-fullcalendarnew-wrp-section')]"), "EventsTab Page"),
	
	//Events Post Elements.
	/** The scheduled post profile icon. */
	EVENTS_POST_PROFILE_ICON(By.xpath(
			"//div[@class='li-view-main'][1]//div[@class='liv-right list-item'][1]//div[@class='header-section']//div[@class='p-avatar']//img[contains(@src,'user-avatar')]"),
			"Events Post Profile icon"),
	
	/** The scheduled post brandname. */
	EVENTS_POST_LOCATIONNAME(By.xpath("//div[@class='li-view-main'][1]//div[@class='liv-right list-item'][1]//div[@class='header-section']//div[@class='p-title']//h5"),
			"Events Post Brand name"),
	
	/** The events post event name. */
	EVENTS_POST_EVENT_NAME(By.xpath("//div[@class='desc-title']//parent::div//div[@class='header-section']"),
			"Events Post Event name"),
	
	/** The events post event description. */
	EVENTS_POST_EVENT_DESCRIPTION(By.xpath("//div[@class='desc-text']//parent::div//div[@class='header-section']"),
			"Events Post Event Description"),
	
	/** The scheduled post date time. */
	EVENTS_POST_DATE_TIME(By.xpath("//div[@class='li-view-main'][1]//div[@class='liv-right list-item'][1]//div[@class='header-section']//div[@class='p-title']//h6"), "Events Post Date Time"),
	
	/** The scheduled post social media preview. */
	EVENTS_POST_START_TIME(By.xpath("//div[@class='calendr-notify-section']//div[@class='first-itm']//div[text()='Start Time']"),
			"Events Post Start time"),
	////div[@class='calendr-notify-section'][1]//div[@class='first-itm']//div[2]//parent::div//following-sibling::div[@class='last-itm']//div[2]
	/** The scheduled post social media preview. */
	EVENTS_POST_END_TIME(By.xpath("//div[@class='calendr-notify-section']//div[@class='first-itm']//div[text()='End Time']"),
			"Events Post End time"),
	
	/** The scheduled post social media preview. */
	EVENTS_POST_LOCATION(By.xpath("//div[@class='calendr-notify-section']//div[@class='first-itm']//div[text()='Location']"),
			"Events Post Location"),
	
	/** The scheduled post social media preview. */
	EVENTS_POST_FREQUENCY(By.xpath("//div[@class='calendr-notify-section']//div[@class='first-itm']//div[text()='Frequency']"),
			"Events Post Frequency"),
	
	/** The events post side image. */
	EVENTS_POST_SIDE_IMAGE(By.xpath("//div[@class='event-section-main-wrp']//div[@class='right-section']"),
			"Events Post Side Image"),
	
	/** The events post event button. */
	EVENTS_POST_EVENT_BUTTON(By.xpath("//div[@class='btn cancel-btn']//input[@name='request_type_event_created']"),
			"Events Post Event Button"),
	
	/** The events post post button. */
	EVENTS_POST_POST_BUTTON(By.xpath("//div[@class='btn cancel-btn']//input[@name='request_type_post_created']"),
			"Events Post Post Button"),
	
	/** The events post promotion button. */
	EVENTS_POST_PROMOTION_BUTTON(By.xpath("//div[@class='btn cancel-btn']//input[@name='request_type_promotion_created']"),
			"Events Post Promotion Button"),
	
	/** The events post internal notes location name. */
	EVENTS_POST_INTERNAL_NOTES_LOCATION_NAME(By.xpath("//div[text()='Internal Notes']//parent::div//div[@class='p-header']//div//div[@class='p-title']//h5"),
			"Events Post Internal Notes Location name"),
	
	/** The events post internal notes profile icon. */
	EVENTS_POST_INTERNAL_NOTES_PROFILE_ICON(By.xpath("//div[text()='Internal Notes']//parent::div//div[@class='p-header']//div//div//img"),
			"Events Post Internal Notes Profile Icon"),
	
	/** The events post internal notes date and time. */
	EVENTS_POST_INTERNAL_NOTES_DATE_AND_TIME(By.xpath("//div[text()='Internal Notes']//parent::div//div[@class='p-header']//div//div[@class='p-title']//h6"),
			"Events Post Internal Notes Date and time"),
	
	/** The events post internal notes adding option. */
	EVENTS_POST_INTERNAL_NOTES_ADDING_OPTION(By.xpath("//div[@class='add-internal-notes']//div[@class='ap-small-textarea']//textarea[@id='addPostTextArea']"),
			"Events Post Internal Notes Adding Option"),
	
	/** The list view button. */
	LIST_VIEW_BUTTON(By.xpath(
			"//div[contains(@class,'stats-item mx-0')]//span[text()='LIST VIEW']"),
			"List view button"),

	/** The create post button. */
	CREATE_POST_BUTTON(By.xpath("//div[contains(@class,'calendar-stats-section')]//span[text()='CREATE POST']"),
			"Create post button"),

	/** The create post button in brand. */
	CREATE_POST_BUTTON_IN_BRAND(By.xpath("//div[contains(@class,'calendar-stats-section')]//div[3]//span[text()='CREATE POST']"),
			"CREATE_POST_BUTTON_IN_BRAND"),

	// Calendar View Page Elements
	/** Calendar view button. */
	CALENDAR_VIEW_BUTTON(
			By.xpath("//div[contains(@class,'stats global-stats-section-wrp')]//div//span[contains(text(),'CALENDAR VIEW')]"),
			"Calendar view button"),

	/** The monthly view button. */
	MONTHLY_VIEW_BUTTON(By.xpath("//button[@class='fc-dayGridMonth-button fc-button fc-button-primary']"),
			"Monthly view button"),

	/** The monthly view button active. */
	MONTHLY_VIEW_BUTTON_ACTIVE(
			By.xpath("//button[@class='fc-dayGridMonth-button fc-button fc-button-primary fc-button-active']"),
			"Monthly view button Active"),

	/** The weekly view button. */
	WEEKLY_VIEW_BUTTON(By.xpath("//button[contains(@class,'fc-dayGridWeek-button')]"),
			"Weekly view button"),

	/** The weekly view button active. */
	WEEKLY_VIEW_BUTTON_ACTIVE(
			By.xpath("//button[@class='fc-dayGridWeek-button fc-button fc-button-primary fc-button-active']"),
			"Weekly view button Active"),

	/** The day view button. */
	DAY_VIEW_BUTTON(By.xpath("//button[@class='fc-timeGridDay-button fc-button fc-button-primary']"),
			"Day view button"),

	/** The day view button active. */
	DAY_VIEW_BUTTON_ACTIVE(
			By.xpath("//button[@class='fc-timeGridDay-button fc-button fc-button-primary fc-button-active']"),
			"Day view button Active"),

	/** Daily view data */
	DAILY_VIEW_DATA(By.xpath("//tbody//td[contains(@class,'fc-timegrid-col')]//div[@class='fc-event-main']//div[contains(@class,'creator-schedule')]"), "Daily view data"),

	/** Calendar view. */
	CALENDAR_MONTHLY_VIEW(By.xpath("//div[contains(@class,'fc-dayGridMonth-view fc-view fc-daygrid monthlycalendarwrapper')]"),
			"Calendar monthly view"),

	/** The calendar weekly view. */
	CALENDAR_WEEKLY_VIEW(By.xpath("//div[@class='fc-dayGridWeek-view fc-view fc-daygrid weeklycalendarwrapper']"),
			"Calendar weekly view"),

	/** The calendar daily view. */
	CALENDAR_DAILY_VIEW(By.xpath("//div[@class='fc-timeGridDay-view fc-view fc-timegrid dailycalendarwrpper']"),
			"Calendar daily view"),

	/** The calendar view. */
	CALENDAR_VIEW(By.xpath("//div[@class='cal-lc-views calendar-calview creator-view-calendar-wrp-modal']"),
			"Calendar view"),

	/** List view. */
	LIST_VIEW(By.xpath("//div[contains(@class,'stats-section')]//div//span[contains(text(),'LIST VIEW')]"),
			"List view"),

	/** The create post button. */

	/** The no data to show. */
	NO_DATA_TO_SHOW(By.xpath("//div[contains(@class,'no-data nd-text-only dshbrd-no-data')]//span[text()='No data to show']"),
			"No data to show"),

	/** The delete. */
	DELETE_BUTTON(By.xpath("//div[@class='clv-lm-cnt']//div[@class='fcd-controls']//button"), "Delete scheduled post"),

	/** The delete alert delete button. */
	DELETE_ALERT_DELETE_BUTTON(
			By.xpath("//div[@class='modal-content']//div[@class='modal-footer']//div//button[text()='Delete']"),
			"Delete alert delete button"),

	/** The delete alert cancel button. */
	DELETE_ALERT_CANCEL_BUTTON(
			By.xpath("//div[@class='modal-content']//div[@class='modal-footer']//div//button[text()='Cancel']"),
			"Delete alert cancel button"),

	/** The post deleted message. */
	POST_DELETED_MESSAGE(By.xpath("//span[text()='Post deleted']"), "Post deleted message"),

	/** The scheduled tab time button. */
	SCHEDULED_TAB_TIME_BUTTON("//span[contains(text(),'%s')]//parent::div//label//span[text()='%s']",
			"Scheduled tab time button"),

	/** The scheduled tab content. */
	SCHEDULED_TAB_CONTENT(
			"//div[contains(@id,'facebook')]//div[@class='ap-big-textarea']//textarea[contains(text(),'%s')]",
			"Scheduled tab content"),

	/** Post Social platform. */
	POST_SOCIAL_PLATFORM("//nav[@class='nav nav-tabs']//a[@id='cal-tabs-tab-%s']", "Post Social platform"),

	/** Post Social platform active. */
	POST_SOCIAL_PLATFORM_ACTIVE(
			"//nav[@class='nav nav-tabs']//a[@id='cal-tabs-tab-%s' and @class='nav-item nav-link active']",
			"Post Social platform active"),

	/** Post location name. */
	POST_LOCATION_NAME(By.xpath("//div[@class='cal-cnt-item']//span[@class='cal-title']"), "Post location name"),

	/** Post textArea. */
	POST_TEXTAREA(By.xpath("//div[@class='cal-cnt-item']//textarea[@id='scheduled-txtarea']"), "Post textArea"),
	
	/** Post textArea Undo button. */
	POST_TEXTAREA_UNDO_BUTTON(By.xpath("//div[@class='cal-cnt-item']//img[@alt='Refresh']"),
			"Post textArea Undo button"),

	/** Include this platform button. */
	INCLUDE_THIS_PLATFORM_BUTTON(By.xpath("//div[@class='cal-cnt-item']//span[text()='Include This Platform']"),
			"Include this platform button"),

	/** DateTime in Post detailedView. */
	DATETIME_IN_POST_DETAILEDVIEW(By.xpath("//div[@class='cal-tab-base']//div[@class='ap-uploaded-date']"),
			"DateTime in Post detailedView"),

	/** Post cancel button. */
	POST_CANCEL_BUTTON(By.xpath("//div[@class='cal-tab-base']//button[text()='Cancel']"), "Post cancel button"),

	/** Post approved button. */
	POST_APPROVED_BUTTON(By.xpath("//div[@class='cal-tab-base']//button[text()='Approved']"), "Post approved button"),

	/** Post SaveChanges button. */
	POST_SAVE_CHANGES_BUTTON(By.xpath("//div[@class='cal-tab-base']//button[text()='Save Changes']"),
			"Post SaveChanges button"),

	/** Post delete button. */
	POST_DELETE_BUTTON(By.xpath("//div[@class='cal-cnt-item']//img[@alt='Delete']"), "Post delete button"),

	// Right side Elements.
	// Social Platform elements.
	/** The platform. */
	PLATFORM(By.xpath("//div[@class='filter-item']//div[@class='fltr-imc selectsocial']"), "Platform elemnt"),

	/** The facebook platform. */
	FACEBOOK_PLATFORM(By.xpath(
			"//section[contains(@class,'calendar-filter__main')]//h3//parent::div//div//button[@class='roundedbtn btn btn-link']//img[contains(@src,'fb-platform')]"),
			"Facebook Platform"),
	
	/** The facebook platform active. */
	FACEBOOK_PLATFORM_ACTIVE(
			By.xpath("//div[@class='filter-item']//button[contains(@class,'active')]//img[contains(@src,'fb-platform.svg')]"),
			"Facebook platform Active"),

	/** The twitter platform. */
	TWITTER_PLATFORM(By.xpath(
			"//section[contains(@class,'calendar-filter__main')]//h3//parent::div//div//button[@class='roundedbtn btn btn-link']//img[contains(@src,'twitter-platform')]"),
			"Twitter Platform"),
	
	/** The twitter platform active. */
	TWITTER_PLATFORM_ACTIVE(By.xpath(
			"//div//button[contains(@class,'active')]//img[contains(@src,'twitter-platform.svg')]"),
			"Twitter Platform Active"),

	/** The instagram platform. */
	INSTAGRAM_PLATFORM(By.xpath(
			"//section[contains(@class,'calendar-filter__main')]//h3//parent::div//div//button[@class='roundedbtn btn btn-link']//img[contains(@src,'instagram-platform')]"),
			"Instagram Platform"),
	
	/** The instagram platform active. */
	INSTAGRAM_PLATFORM_ACTIVE(By.xpath(
			"//div//button[contains(@class,'active')]//img[contains(@src,'instagram-platform.svg')]"),
			"Instagram Platform Active"),

	SCHEDULED_POST_INSTAGRAM_TAB("//p[@class='post-message' and text()='%s']//ancestor::div[@class='liv-right list-item']//button//img[@alt='instagram']","Scheduled Post Instagram Tab"),

	SCHEDULED_POST_TWITTER_TAB("//p[@class='post-message' and text()='%s']//ancestor::div[@class='liv-right list-item']//button//img[@alt='twitter']","Scheduled Post Instagram Tab"),

	SCHEDULED_POST_LINKEDIN_TAB("//p[@class='post-message' and text()='%s']//ancestor::div[@class='liv-right list-item']//button//img[@alt='linkedin']","Scheduled Post Instagram Tab"),

	/** The linkedin platform. */
	LINKEDIN_PLATFORM(By.xpath(
			"//section[contains(@class,'calendar-filter__main')]//h3//parent::div//div//button[@class='roundedbtn btn btn-link']//img[contains(@src,'linkedin-platform')]"),
			"LinkedIn Platform"),
	
	/** The linkedin platform active. */
	LINKEDIN_PLATFORM_ACTIVE(By.xpath(
			"//div//button[contains(@class,'active')]//img[contains(@src,'linkedin-platform.svg')]"),
			"LinkedIn Platform Active"),

	/** The google platform. */
	GOOGLE_PLATFORM(By.xpath(
			"//section[contains(@class,'calendar-filter__main')]//h3//parent::div//div//button[@class='roundedbtn btn btn-link']//img[contains(@src,'google-platform')]"),
			"Google Platform"),

	
	/** The google platform active. */
	GOOGLE_PLATFORM_ACTIVE(
			By.xpath("//div//button[contains(@class,'active')]//img[contains(@src,'google-platform.svg')]"),
			"Google Platform Active"),

	/** The TikTok platform. */
	TIKTOK_PLATFORM(By.xpath(
			"//section[contains(@class,'calendar-filter__main')]//h3//parent::div//div//button[@class='roundedbtn btn btn-link']//img[contains(@src,'tiktok-platform')]"),
			"TikTok Platform"),

	/** The All option in platform. */
	ALL_PLATFORM(By.xpath(
			"//section[contains(@class,'calendar-filter__main')]//h3//parent::div//div//button[@class='roundedbtn btn btn-link']//img[contains(@src,'all-platform')]"),
			"All platform"),

	/** The tiktok platform active. */
	TIKTOK_PLATFORM_ACTIVE(
			By.xpath("//div//button[contains(@class,'active')]//img[contains(@src,'tiktok-platform.svg')]"),
			"TikTok Platform Active"),

	/** The scheduled post social media preview. */
	SCHEDULED_POST_PREVIEW(By.xpath("//div[contains(@class,'cal-social-preview-sec')]//div[@class='card-bg']"), "Scheduled Post preview"),

	/** The scheduled post preview expand button. */
	SCHEDULED_POST_PREVIEW_EXPAND_BUTTON(By.xpath("//div[contains(@class,'cal-social-preview-sec')]//div//img[contains(@src,'expand.svg')]"), "SCHEDULED_POST_PREVIEW_EXPAND_BUTTON"),

	/** The scheduled post social media preview. */
	SCHEDULED_POST_SOCIAL_MEDIA_PREVIEW(By.xpath("//div[@class='li-view-main'][1]//div[@class='liv-right list-item']//div[@class='header-section']//div//button//img"),
			"Scheduled Post Social Media Platform"),

	/** The scheduled post date time. */
	SCHEDULED_POST_DATE_TIME(By.xpath("//div[@class='p-header-title']//ancestor::div[@class='liv-right list-item']//div[@class='p-title']//h6[text()]"), "Scheduled Post Date Time"),

	SCHEDULED_POST_TIME_FIELD("//div[@class='p-header-title']//ancestor::div[@class='liv-right list-item']//div[@class='p-title']//h6[contains(text(),\"%s\")]","Schedued Post Time Field"),

	SCHEDULED_POST_DATE_FIELD("//div[@class='p-header-title']//ancestor::div[@class='liv-right list-item']//div[@class='p-title']//h6[contains(text(),\"%s\")]","Schedued Post Date Field"),

	/** The scheduled post date time in calendar option. */
	SCHEDULED_POST_DATE_TIME_IN_CALENDAR_OPTION(By.xpath("//div[@class='li-view-main'][1]//div[@class='liv-right list-item']//div[@class='left-section']//div[@class='remove-btn-cal ']//span[1]"), "Scheduled Post Date Time In Calendar Option"),

	SCHEDULED_POST_DATE_TIME_IN_CALENDAR_POST_OPTION("//p[text()='%s']//ancestor::div[@class='liv-right list-item']//div[contains(@class,'header-section cal-mt-btns')]//div[contains(@class,'remove-btn-cal')]//span[1]","SCHEDULED_POST_DATE_TIME_IN_CALENDAR_POST_OPTION"),

	SCHEDULED_POST_DATE_TIME_IN_CALENDAR_POST_INACTIVE("//p[text()='%s']//ancestor::div[@class='liv-right list-item']//div[contains(@class,'header-section cal-mt-btns')]//div[@class='remove-btn-cal pointer-events-none']//span[1]","SCHEDULED_POST_DATE_TIME_IN_CALENDAR_POST_INACTIVE"),

	/** The scheduled post profile icon. */
	SCHEDULED_POST_PROFILE_ICON(By.xpath(
			"//div[@class='p-header-title']//ancestor::div[@class='liv-right list-item']//div[@class='p-header-title']//img[@alt='calendar user profile img']"),
			"Scheduled Post Profile icon"),
	
	/** The scheduled post remove button. */
	SCHEDULED_POST_REMOVE_BUTTON(By.xpath(
			"//div[@class='li-view-main'][1]//div[@class='liv-right list-item']//div[contains(@class,' ac-danger-box calendar-ripple')]//button[text()='Remove']"),
			"Scheduled Post Remove Button"),
	
	/** The scheduled post cancel button. */
	SCHEDULED_POST_CANCEL_BUTTON(By.xpath(
			"//div[@class='li-view-main'][1]//div[@class='liv-right list-item']//div[@class='react-ripples ripple-unset r-ml2 ac-secondary-box']/div[text()='Cancel']"),
			"Scheduled Post Cancel Button"),
	
	/** The scheduled post cancel button by description. */
	SCHEDULED_POST_CANCEL_BUTTON_BY_DESCRIPTION(
			"//p[contains(text(),'%s')]//ancestor::div[@class='liv-right list-item']//button[text()='Cancel']",
			"Scheduled Post Cancel Button"),
	
	/** The scheduled post cancel ok button. */
	SCHEDULED_POST_CANCEL_OK_BUTTON(By.xpath("//div[@class='react-ripples ac-danger-box']//button[text()='Ok']"),"Scheduled cancel Ok Button"),
	
	
	/** The scheduled post boost option by description. */
	SCHEDULED_POST_BOOST_OPTION_BY_DESCRIPTION(
			"//div[@class='liv-right list-item']//div[@class='desc-text']//p[text()='%s']//following::div[1]//div[2]//div[2]//div[text()='Cancel']",
			"Scheduled Post Boost Option"),
	
	/** The scheduled post edit button. */
	SCHEDULED_POST_EDIT_BUTTON(By.xpath(
			"//div[@class='li-view-main'][1]//div[@class='liv-right list-item']//div[contains(@class,'react-ripples ripple-unset edit-ripple__wrp r-ml2 ac-secondary-box')]//button[text()='Edit']"),
			"Scheduled Post Edit Button"),
	
	/** The scheduled post calendar nextmonth picker. */
	SCHEDULED_POST_CALENDAR_NEXTMONTH_PICKER(By.xpath(
			"//button[contains(@class,'navigation--next') and text()='Next Month']"),"ScheduledPost Calendar"),

	CALENDAR_VIEW_NEXT_MONTH_PICKER(By.xpath("//div[@class='react-datepicker']//button[contains(@class,'navigation--next') and @aria-label='Next Month']"),"CALENDAR_VIEW_NEXT_MONTH_PICKER"),

	CALENDAR_TIME_FIELD(By.xpath("//div[@class='react-datepicker__input-time-container']//input[@placeholder='Time']"),
			"Schedule view Time field"),
	CALEDNAR_VIEW_SCHEDULED_SECTION_TIME("//div[@class='react-datepicker__input-time-container']//input[@placeholder='Time' and @value=\"%s\"]","Scheduled Section Time"),


	/** The right section post by description with boost and warning img. */
	RIGHT_SECTION_POST_BY_DESCRIPTION_WITH_BOOST_AND_WARNING_IMG("//div[@class='schedule-card-section-wrp'][1]//div[@class='yellow-bg'][1]//img[contains(@src,'warning.svg')]//parent::div[1]//following::div[1]/img[contains(@src,'boost.svg')]//parent::div[1]//parent::div//following::div[contains(@class,'media-preview')][1]//div[2]//p[text()='Schedule a Post with Boost 22:16 March28']", "List View Boost button"),

	RIGHT_SECTION_POST_AWAITING_APPROVAL_PENDING_SYMBOL(By.xpath("//div[@class='img-reduce']//img[contains(@src,'warning.svg') and @alt='Approval awaiting']"),"RIGHT_SECTION_POST_AWAITING_APPROVAL_PENDING_SYMBOL"),

	// Scheduled post cenral area list elements
	
	/** The listview post social platform. */
	LISTVIEW_POST_SOCIAL_PLATFORM(By.xpath(
			"//div[@class='li-view-main'][1]//div[@class='liv-right list-item']//div[@class='header-section']//div//button//img"),
			"Scheduled List View Social platform"),

	/** The listview post social platform. */
	LISTVIEW_POST_SOCIAL_PLATFORM_FACEBOOK(By.xpath(
			"//div[@class='li-view-main'][1]//div[@class='liv-right list-item']//div[@class='header-section']//div//button//img[contains(@src,'fb-platform')]"),
			"Scheduled List View Social platform Facebook"),

	/** The listview post social platform instagram. */
	LISTVIEW_POST_SOCIAL_PLATFORM_INSTAGRAM(By.xpath(
			"//div[@class='li-view-main'][1]//div[@class='liv-right list-item']//div[@class='header-section']//div//button//img[contains(@src,'instagram-platform')]"),
			"Scheduled List View Social platform Instagram"),

	/** The listview post social platform twitter. */
	LISTVIEW_POST_SOCIAL_PLATFORM_TWITTER(By.xpath(
			"//div[@class='li-view-main'][1]//div[@class='liv-right list-item']//div[@class='header-section']//div//button//img[contains(@src,'twitter-platform')]"),
			"Scheduled List View Social platform Twitter"),

	/** The listview post social platform linkedin. */
	LISTVIEW_POST_SOCIAL_PLATFORM_LINKEDIN(By.xpath(
			"//div[@class='li-view-main'][1]//div[@class='liv-right list-item']//div[@class='header-section']//div//button//img[contains(@src,'linkedin-platform')]"),
			"Scheduled List View Social platform LinkedIn"),
	
	/** The listview post social platform google. */
	LISTVIEW_POST_SOCIAL_PLATFORM_GOOGLE(By.xpath(
			"//div[@class='li-view-main'][1]//div[@class='liv-right list-item']//div[@class='header-section']//div//button//img[contains(@src,'google-platform')]"),
			"Scheduled List View Social platform Google"),

	/** The listview post social platform tiktok. */
	LISTVIEW_POST_SOCIAL_PLATFORM_TIKTOK(By.xpath(
			"//div[@class='li-view-main'][1]//div[@class='liv-right list-item']//div[@class='header-section']//div//button//img[contains(@src,'tiktok-platform')]"),
			"Scheduled List View Social platform TikTok"),

	/** The scheduled post social media preview. */
	LISTVIEW_POST_BRAND_NAME(By.xpath(
			"//div[@class='li-view-main'][1]//div[@class='liv-right list-item']//div[@class='header-section']//div//h5"),
			"List View Post Brand name"),

	/** The scheduled post date time. */
	LISTVIEW_POST_DATE_AND_TIME(By.xpath(
			"//div[@class='li-view-main'][1]//div[@class='liv-right list-item']//div[@class='header-section']//div//h6"),
			"List View Post Date Time"),

	/** The scheduled post profile icon. */
	LISTVIEW_POST_PROFILE_ICON(By.xpath(
			"//div[@class='li-view-main'][1]//div[@class='liv-right list-item']//div[@class='header-section']//div[@class='p-avatar']//img"),
			"Scheduled Post Profile icon"),

	/** The listview post description. */
	LISTVIEW_POST_DESCRIPTION(By.xpath(
			"//div[@class='li-view-main'][1]//div[@class='liv-right list-item']//div[@class='desc-text']"),
			"List View Post description"),
	
	/** The listview post cancel button. */
	LISTVIEW_POST_CANCEL_BUTTON(By.xpath(
			"//div[@class='li-view-main'][1]//div[@class='liv-right list-item']//div[@class='react-ripples ripple-unset r-ml2 ac-secondary-box']/div[text()='Cancel']"),
			"List View Post Cancel button"),
	
	/** The scheduled post date time. */
	LISTVIEW_POST_EDIT_BUTTON(By.xpath(
			"//div[@class='li-view-main'][1]//button[text()='Edit']"),
			"List View Post Edit button"),

	/** The scheduled post profile icon. */
	LISTVIEW_POST_REMOVE_BUTTON(By.xpath(
			"//div[@class='li-view-main'][1]//button[text()='Remove']"),
			"List view post Remove button"),
	
	/** The listview post date time in calendar option. */
	LISTVIEW_POST_DATE_TIME_IN_CALENDAR_OPTION(By.xpath("//div[@class='li-view-main'][1]//div[@class='liv-right list-item']//div[@class='left-section']//div[@class='remove-btn-cal ']//span[1]"), "Scheduled Post Date Time In Calendar Option"),
	
	/** The listview post date time in calendar option by description. */
	LISTVIEW_POST_DATE_TIME_IN_CALENDAR_OPTION_BY_DESCRIPTION("//div[@class='liv-right list-item']//div[@class='desc-text']//p[text()='%s']//parent::div//following-sibling::div[2]//div[@class='remove-btn-cal ']//span[1]", "Scheduled Post Date Time In Calendar Option"),
	
	/** The listview post boost option by description. */
	LISTVIEW_POST_BOOST_OPTION_BY_DESCRIPTION("//div[@class='li-view-main'][1]//div[@class='liv-right list-item'][1]//div[@class='desc-text']//p[text()='%s']//parent::div//preceding::div[@class='header-section']//h6//span[text()='$ Boosted']", "List View Boost button"),
	
	/** The listview post by description with tag. */
	LISTVIEW_POST_BY_DESCRIPTION_WITH_TAG("//div[@class='liv-right list-item'][1]//div[@class='desc-text']//p[contains(text(),'%s')]//span[text()='%s']//parent::a[contains(@href,'')]", "List View Post by description with tag"),

	/** The listview post by description with coupon. */
	LISTVIEW_POST_BY_DESCRIPTION_WITH_COUPON("//div[@class='desc-text']//p[text()='%s']//parent::div//following::div[@class='coupon-link-preview-wrp']//div[@class='url-subhead-txt' and text()='%s']//parent::a", "List View Post by description with coupon "),

	/** The listview date time by post name. */
	LISTVIEW_DATE_TIME_BY_POST_NAME("//p[@class='post-message' and contains(text(),'%s')]//ancestor::div[@class='liv-right list-item']//div[@class='p-header-title']//h6","List of Date And Time By Post Name"),
	
	/** The scheduled post date time. */
	LISTVIEW_POST_SCHEDULE_TO_WITH_COUNT(
			By.xpath("//div[@class='li-view-main'][1]//div[contains(@class,'hubuserfootersec')]//div//div//span"),
			"List View Post Schedule To with count"),

	/** The scheduled post profile icon. */
	LISTVIEW_POST_IMAGE(By.xpath("//div[@class='li-view-main'][1]//div[@class='am-media-preview']"),
			"List view post Image"),

	/** The scheduled to button by posttext. */
	SCHEDULED_TO_BUTTON_BY_POSTTEXT(
			"//div[@class='desc-text']//p[text()='%s']//parent::div//following-sibling::div//div//div[@class='sche-text']",
			"Scheduled To Button By Post text"),

	/** The remove button. */
	REMOVE_BUTTON(By.xpath("//div[@class='btn remove-btn' and contains(text(),'Remove')]"),
			"Scheduled Post Remove Button"),

	/** The approve button. */
	APPROVE_BUTTON(By.xpath("//button[@class='ac-btn ac-primary ac-block ' and text()='Approve']"),
			"Awaiting Approve Button"),
	
	/** The approved button inactive. */
	APPROVED_BUTTON_INACTIVE("//p[@class='post-message' and contains(text(),'%s')]//ancestor::div[@class='liv-right list-item']//div[@class='full-width-btn']//div[contains(@class,'ac-primary-box pointer-events-none')]//button[text()='Approved']","Approved Button Inactive"),

	SCHEDULED_POST_APPROVED_BUTTON_INACTIVE(By.xpath("//p[@class='post-message']//ancestor::div[@class='liv-right list-item']//div[@class='full-width-btn']//div[contains(@class,'ac-primary-box pointer-events-none')]//button[text()='Approved']"),"Approved Button Inactive"),

	SCHEDULED_POST_APPROVED_BUTTON_ACTIVE(By.xpath("//p[@class='post-message']//ancestor::div[@class='liv-right list-item']//div[@class='full-width-btn']//div[contains(@class,'react-ripples ac-primary-box')]//button[text()='Approve']"),"Approve Button Active"),

	/** The approved button active. */
	APPROVED_BUTTON_ACTIVE("//p[@class='post-message' and contains(text(),'%s')]//ancestor::div[@class='liv-right list-item']//div[@class='full-width-btn']//div[contains(@class,'react-ripples ac-primary-box')]//button[text()='Approve']","Approve Button Active"),
	
	/** The approve button by position. */
	APPROVE_BUTTON_BY_POSITION("//p[text()='%s']//ancestor::div[@class='liv-right list-item']//div[@class='full-width-btn']//div//button[text()='Approve']",
			"Awaiting Approve Button"),

	/** The scheduled post brandname. */
	SCHEDULED_POST_BRANDNAME(By.xpath("//div[@class='p-header-title']//ancestor::div[@class='liv-right list-item']//div[@class='p-title']//h5"),
			"Scheduled Post Brand name"),

	/** The scheduled post description. */
	SCHEDULED_POST_DESCRIPTION(By.xpath("//div[@class='p-header-title']//ancestor::div[@class='liv-right list-item']//div[@class='desc-text']//p"),
			"Scheduled Post Description"),

	/** The scheduled post Assets. */
	SCHEDULED_POST_ASSETS(By.xpath("//div[@class='modal-body']//div[@class='liv-right list-item']//div[@class='am-media-preview']"),
			"Scheduled Post Assets"),
	
	/** The scheduled post by description. */
	SCHEDULED_POST_BY_DESCRIPTION(
			"//div[@class='liv-right list-item']//div[@class='desc-text']//p[contains(text(),'%s') and @class='post-message']",
			"Scheduled Post By Description"),

	/** The scheduled post by description of unapproved post */
	SCHEDULED_UNAPPOVED_POST_POST_BY_DESCRIPTION(
			"//div[@class='fc-event-main']//div[contains(@class,'creator-schedule')]//p[contains(text(),'%s')]",
			"The scheduled post by description of unapproved post"),

	/** The scheduled post by description with date time. */
	SCHEDULED_POST_BY_DESCRIPTION_WITH_DATE_TIME(
			"//h6[contains(text(),'%s')]//ancestor::div[@class='liv-right list-item']//div[@class='desc-text']//p[contains(text(),'%s')]",
			"Scheduled Post By PostText and date time"),
	
     /** The scheduled post platform icon. */
     //p[text()='FacebookPostText']//ancestor::div[@class='li-view-main']//div[@class='liv-right list-item']
	SCHEDULED_POST_PLATFORM_ICON("//p[text()='%s']//parent::div//preceding-sibling::div//button//img[@alt='%s']","Scheduled Post platform Icon"),

	SCHEDULED_POST_LIST_BY_BOOST_TAG("//p[contains(text(),'%s')]//ancestor::div//span[@class='cal-boost-textwithbg']","Scheduled Post By Boost Tag"),

	SCHEDULED_POST_LIST_BY_TAG("//p[contains(text(),'%s')]//a[@target='_blank']","Scheduled Post List By Tag"),

	SCHEDULED_POST_LIST_BY_LINK("//p[contains(text(),'%s')]//parent::div[@class='desc-text']//following::div[@class='new-preview csm-wrap']//div//img","Schedule Post List By Link"),

	/** The scheduled post socialmedia icon. */
	SCHEDULED_POST_SOCIALMEDIA_ICON(
			"//h6[contains(text(),'%s')]//ancestor::div[@class='liv-right list-item']//div[@class='desc-text']//p[contains(text(),'%s')]//parent::div//preceding-sibling::div//button//img[@alt='%s']",
			"Scheduled Post SocialMedia Icon"),
	////h6[contains(text(),'@7:05 PM on Aug 2, 2022')]//ancestor::div[@class='liv-right list-item']//div[@class='desc-text']//p[contains(text(),'crop test')]//parent::div//preceding-sibling::div//button[contains(@class,'active')]//img[@alt='instagram']
	
	/** The scheduled post remove button by text. */
	SCHEDULED_POST_REMOVE_BUTTON_BY_TEXT("//p[text()='%s']//ancestor::div[@class='liv-right list-item']//following::button[text()='Remove']",
			"Scheduled Post remove Button By text"),
	
	/** The scheduled post cancel button by text. */
	SCHEDULED_POST_CANCEL_BUTTON_BY_TEXT(
			"//div[@class='desc-text']//p[text()='%s']//parent::div//following-sibling::div//div[text()='Cancel']",
			"Scheduled Post Cancel Button By text"),
	
	/** The scheduled post remove by description with date time. */
	SCHEDULED_POST_REMOVE_BY_DESCRIPTION_WITH_DATE_TIME(
			"//h6[text()='%s']//ancestor::div[@class='liv-right list-item']//div[@class='desc-text']//p[contains(text(),'%s')]//parent::div//following-sibling::div//button[text()='Remove']",
			"Scheduled Post Remove By PostText and date time"),

	/** The scheduled post gallery. */
	SCHEDULED_POST_GALLERY(By.xpath("//div[@class='p-header-title']//ancestor::div[@class='liv-right list-item']//div[@class='am-media-preview']"),"The Scheduled Post image,video"),

	SCHEDULED_POST_WITH_VIDEO("//p[@class='post-message' and text()='%s']//ancestor::div[@class='liv-right list-item']//div[@class='am-media-preview pmg']//div[@class='video-outer-element']","Scheduled Post with Video"),

	/** The scheduled post text content. */
	SCHEDULED_POST_TEXT_CONTENT(By.xpath("//div[@class='p-header-title']//ancestor::div[@class='liv-right list-item']//div[@class='desc-text']"),"Scheduled Post Text Content"),
	
	/** The scheduled post gallery link. */
	SCHEDULED_POST_GALLERY_LINK(By.xpath(
			"//div[@class='p-header-title']//ancestor::div[@class='liv-right list-item']//div[@class='coupon-link-preview-wrp']"),
			"The Scheduled Gallery Link"),

	SCHEDULED_POST_WITH_BOOST_SYMBOL("",""),

	/** The preview like button. */
	PREVIEW_LIKE_BUTTON(By.xpath("//div[@class='footer-btn']//div[contains(@class,'like-icon')]"),
			"Preview Like-Button"),

	/** The preview command button. */
	PREVIEW_COMMAND_BUTTON(By.xpath("//span[contains(text(),'Comment')]//parent::div[@class='footer-btn']"),
			"Preview Command-Button"),

	/** The preview share button. */
	PREVIEW_SHARE_BUTTON(By.xpath("//span[contains(text(),'Share')]//parent::div[@class='footer-btn']"),
			"Preview Share-Button"),

	/** The calendar previous picker. */
	CALENDAR_PREVIOUS_PICKER(By.xpath("//button[contains(@class,'fc-prev-button fc-button')]//span[@class='fc-icon fc-icon-chevron-left']"), "Previous Month picker"),

	CALENDAR_VIEW_MONTH_FIELD("//div[@class='fc-toolbar-chunk']//h2[@class='fc-toolbar-title' and text()='%s']","Calendar View Month Field"),

	/** The calendar view header month. */
	CALENDAR_VIEW_HEADER_MONTH(By.xpath("//div[@class='fc-toolbar-chunk']//h2[@class='fc-toolbar-title']"),
			"Loaded Header Month"),

	/** The calendar view header month. */
	CALENDAR_VIEW_TODAY_BUTTON(
			By.xpath("//button[@class='fc-today-button fc-button fc-button-primary' and text()='Today']"),
			"Calendar view today button"),

	/** The calendar next picker. */
	CALENDAR_NEXT_PICKER(By.xpath("//button[contains(@class,'fc-next-button fc-button')]"), "Next Month picker"),

	// Expand Preview Popup Elements
	/** The expand preview icon. */
	EXPAND_PREVIEW_ICON(By.xpath("//div[@class='overlay']//div//img[contains(@src,'expand.svg')]"),
			"Preview-Popup Expand icon"),
	
	/** The expanded preview popup. */
	EXPANDED_PREVIEW_POPUP(By.xpath("//div[@class='liv-right list-item']"), "Preview-Popup"),

	/** The expanded preview social media. */
	EXPANDED_PREVIEW_SOCIAL_MEDIA(By.xpath("//div[@class='liv-right list-item']//div[@class='fltr-imc selectsocial']"),
			"Preview-Popup Post SocialMedia-Platform"),

	/** The scheduled post date time. */
	EXPANDED_PREVIEW_DATE_TIME(By.xpath("//div[@class='liv-right list-item']//div//div//div//div//div//h6"),
			"Preview-Popup Post Date-Time"),

	/** The scheduled post profile icon. */
	EXPANDED_PREVIEW_PROFILE_ICON(By.xpath("//div[@class='header-section']//div[@class='left-section']//div//img"),
			"Preview-Popup Post Profile-icon"),

	/** The remove button. */
	EXPANDED_PREVIEW_REMOVE_BUTTON(By.xpath(
			"//div[@class='liv-right list-item']//div[@class='calendar-flr-btn-wrp']//button[contains(text(),'Remove')]"),
			"Preview-Popup Post Remove-Button"),

	/** The approve button. */
	EXPANDED_PREVIEW_APPROVE_BUTTON(By.xpath(
			"//div[contains(@class,'modal-dialog-centered')]//div[@class='btn approve-btn ' and text()='Approve']"),
			"Preview-Popup Post Approve-Button"),
	
	/** The expanded preview approve button disable. */
	EXPANDED_PREVIEW_APPROVE_BUTTON_DISABLE(By.xpath(
			"//div[contains(@class,'modal-dialog-centered')]//div[contains(@class,'events-none')]//div[@class='btn approve-btn ' and text()='Approve']"),
			"Preview-Popup Post Approve-Button Disable"),
	
	/** The expanded preview approved button. */
	EXPANDED_PREVIEW_APPROVED_BUTTON(By.xpath(
			"//div[contains(@class,'modal-dialog-centered')]//div[not(contains(@class,'events-none'))]//div[contains(@class,'btn approve-btn') and text()='Approve']"),
			"EXPANDED_PREVIEW_APPROVED_BUTTON"),
	
	/** The expanded preview approved button disable. */
	EXPANDED_PREVIEW_APPROVED_BUTTON_DISABLE(By.xpath(
			"//div[contains(@class,'modal-dialog-centered')]//div[@class='btn approve-btn cursor-disable' and text()='Approved']"),
			"EXPANDED_PREVIEW_APPROVED_BUTTON_DISABLE"),
	
	/** The expanded preview edit button. */
	EXPANDED_PREVIEW_EDIT_BUTTON_HUB_USER(By.xpath("//button[contains(text(),'Edit')]"),
			"Preview-Popup Post Edit-Button"),

	/** The expanded preview edit button location user. */
	EXPANDED_PREVIEW_EDIT_BUTTON_LOCATION_USER(
			By.xpath("//div[@class='liv-right list-item']//div[@class='calendar-flr-btn-wrp']//button[text()='Edit']"),
			"Preview-Popup Post Edit-Button"),

	EXPANDED_PREVIEW_EDIT_DISABLE("//p[text()='%s']//ancestor::div[@class='liv-right list-item']//div[@class='calendar-flr-btn-wrp']//button[contains(@class,'disabled') and text()='Edit']",
			"Expand Preview Edit Disable Button"),

	/** The scheduled post brandname. */
	EXPANDED_PREVIEW_BRANDNAME(By.xpath("//div[@class='liv-right list-item']//div//div//div//div//div//h5"),
			"Preview-Popup Post Brand name"),

	/** The scheduled post description. */
	EXPANDED_PREVIEW_DESCRIPTION(By.xpath("//div[@class='liv-right list-item']//div[@class='desc-text']//p[@class='post-message']"),
			"Preview-Popup Post Description"),

	/** The expanded preview cancel button. */
	EXPANDED_PREVIEW_CANCEL_BUTTON(By.xpath(
			"//div[@class='liv-right list-item']//div[@class='calendar-flr-btn-wrp']//button[contains(text(),'Cancel')]"),
			"Preview-Popup Cancel-Button"),
	
	/** The expanded preview edit button. */
	EXPANDED_PREVIEW_EDIT_BUTTON(By.xpath("//div[@class='liv-right list-item']//div[@class='calendar-flr-btn-wrp']//button[contains(text(),'Edit')]"),"The Expand Preview Edit button"),
	
//	EXPANDED_PREVIEW_EDIT_BUTTON(By.xpath("//div[@class='btn edit-btn' and contains(text(),'Edit')]"), "Preview-Popup Edit-Button"),

	/** The expanded preview close. */
	EXPANDED_PREVIEW_CLOSE(By.xpath("//div[@class='mod__close--icon']//img[@alt='close']"),
			"Preview-Popup Close-button"),

	/** The side view post with image. */
	SIDE_VIEW_POST_WITH_IMAGE(By.xpath(
			"//section[@class='item-g filter calendar-filter__main']//div[@class='p-body']//div[@class='am-media-preview']//img"),
			"The side view post with image."),

	/** The side view post with video. */
	SIDE_VIEW_POST_WITH_VIDEO(By.xpath(
			"//section[@class='item-g filter calendar-filter__main']//div[@class='p-body']//div[@class='am-media-preview']//video"),
			"The side view post with video."),

	/** The side view post with link. */
	SIDE_VIEW_POST_WITH_LINK(By.xpath(
			"//section[@class='item-g filter calendar-filter__main']//div[@class='p-body']//div[@class='coupon-link-preview-wrp']"),
			"The side view post with link."),



	/** The created scheduled post. */
	CREATED_SCHEDULED_POST("//div[@class='li-view-main']//p[@class='post-message' and contains(text(),'%s')]",
			"Created Scheduled Post"),

	CREATED_SCHEDULE_POST_PREVIEW_IMAGE("//div[@class='li-view-main']//p[@class='post-message' and contains(text(),'%s')]//ancestor::div[@class='liv-right list-item']//li[2]//img","CREATED_SCHEDULE_POST_PREVIEW_IMAGE"),

	/** The remove created scheduled post. */
	REMOVE_CREATED_SCHEDULED_POST(
			"//div[@class='li-view-main']//p[@class='post-message' and contains(text(),'%s')]//parent::div//following-sibling::div//button[text()='Remove']",
			"Remove Created Scheduled Post"),

	/** The remove alert box. */
	REMOVE_ALERT_BOX(By.xpath(
			"//div[@class='modal-body']//div[text()='Are you sure you want to unschedule and remove this post?']"),
			"Remove Alert box"),

	/** The remove alert cancel button. */
	REMOVE_ALERT_CANCEL_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Cancel']"),
			"Remove Alert cancel button"),

	/** The cancel button. */
	CANCEL_BUTTON(By.xpath("//button[text()='Cancel']"),"Cancel Button"),
	
	/** The remove alert ok button. */
	REMOVE_ALERT_OK_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Ok']"), "Remove Alert ok button"),

	/** The profile icon. */
	PROFILE_ICON(By.xpath("//button[@id='dropitems-profile-items']"), "Profile icon"),

	/** Profile icon dropdown. */
	PROFILE_ICON_DROPDOWN(
			By.xpath("//button[@id='dropitems-profile-items']//following-sibling::div[@class='dropdown-menu show']"),
			"Profile icon dropdown"),

	/** The calendarview scheduledpost by day monthview. */
	// Monthly view scheduled post by appropriate date.
	CALENDARVIEW_SCHEDULEDPOST_BY_DAY_MONTHVIEW(
			"//div[contains(@class,'fc-daygrid-day-frame')]//a[text()='%s']//parent::div[@class='fc-daygrid-day-top']//following-sibling::div[@class='fc-daygrid-day-events']",
			 "Calendar View Scheduled Post"),
	
	/** The calendar view awaiting approval posts in monthly view. */
	CALENDAR_VIEW_AWAITING_APPROVAL_POSTS_IN_MONTHLY_VIEW(
			By.xpath("//div[@class='creator-schedule-section-wrp yellow-bg']//ancestor::table//parent::div[contains(@class,'monthlycalendarwrapper')]"),
			"Calendar View Awaiting Approval Posts in Monthly View"),
	
	/** The calendar view awaiting approval posts count in monthly view. */
	CALENDAR_VIEW_AWAITING_APPROVAL_POSTS_COUNT_IN_MONTHLY_VIEW(
			By.xpath("//div[@class='creator-schedule-section-wrp yellow-bg ']"),
			"Calendar View Awaiting Approval Posts Count in Monthly View"),
	
	/** The calendar view scheduled posts in monthly view. */
	CALENDAR_VIEW_SCHEDULED_POSTS_IN_MONTHLY_VIEW(
			By.xpath("//div[@class='creator-schedule-section-wrp blue-bg ']"),
			"Calendar View Scheduled Posts in Monthly View"),
	
	/** The calendar view scheduled post in monthly view by description. */
	CALENDAR_VIEW_SCHEDULED_POST_IN_MONTHLY_VIEW_BY_DESCRIPTION("//div[contains(@class,'creator-schedule-section-wrp')]//div[@class='grid-section']//p[@class='post-content' and text()='%s']",
			"Calendar View Scheduled Posts in Monthly View By Description"),
	
	/** The calendar view post in monthly view by description with boost and warning. */
	CALENDAR_VIEW_POST_IN_MONTHLY_VIEW_BY_DESCRIPTION_WITH_BOOST_AND_WARNING("//div[@class='fc-event-main'][1]//div[contains(@class,'yellow-bg')][1]//div//div[@class='left-section']//img[contains(@src,'warning.svg')]//parent::div[1]//following::div[1]//img[contains(@src,'boost.svg')]//ancestor::div[@class='creator-schedule-section-wrp yellow-bg']//div[@class='grid-section']//div[text()='%s']",
			"Calendar View Posts in Monthly View By Description With Boost and warning symbol"),
	
	/** The calendar view scheduled posts count in monthly view. */
	CALENDAR_VIEW_SCHEDULED_POSTS_COUNT_IN_MONTHLY_VIEW(
			By.xpath("//div[@class='creator-schedule-section-wrp blue-bg']"),
			"Calendar View Scheduled Posts in Monthly View"),
	
	/** The calendar view events posts in monthly view. */
	CALENDAR_VIEW_EVENTS_POSTS_IN_MONTHLY_VIEW(
			By.xpath("//div[@class='creator-schedule-section-wrp purple-bg']//ancestor::table//parent::div[contains(@class,'monthlycalendarwrapper')]"),
			"Calendar View Events Posts in Monthly View"),
	
	/** The calendar view events posts count in monthly view. */
	CALENDAR_VIEW_EVENTS_POSTS_COUNT_IN_MONTHLY_VIEW(
			By.xpath("//div[@class='creator-schedule-section-wrp purple-bg']"),
			"Calendar View Events Posts in Monthly View"),

	/** The weeklyview scheduled posts of the day of the week. */
	WEEKLYVIEW_SCHEDULED_POSTS_OF_THE_DAY_OF_THE_WEEK(
			"//tbody[@role='presentation']//tr//td[%s]//div[contains(@class,'fc-daygrid-day-events')]//a",
			"Weeklyview scheduled posts Of the day"),

	/** The dayview scheduled posts of the day. */
	DAYVIEW_SCHEDULED_POSTS_OF_THE_DAY(
			"//tr//td[contains(@class,'timegrid')]//div[contains(@class,'timegrid-slot')]//div[text()='%s']//parent::div//parent::td//following-sibling::td",
			"day view scheduled post of the day"),

	/** The calendarview scheduledpost moreoption of the day. */
	CALENDARVIEW_SCHEDULEDPOST_MOREOPTION_OF_THE_DAY(
			"//tr//td[contains(@class,'timegrid')]//div[contains(@class,'timegrid-slot')]//div[text()='%s']//parent::div//parent::td//following-sibling::td",
			"Scheduled posts More option of the day"),

	/** The calendarview list of scheduledposts of the day. */
	CALENDARVIEW_LIST_OF_SCHEDULEDPOSTS_OF_THE_DAY(By.xpath("//div[@class='main-cps']//div//div[contains(@class,'creator-schedule-section-wrp')]"),
			"Schedule post List of the day"),

	/** The calendarview scheduledpost list ot the day close option. */
	CALENDARVIEW_SCHEDULEDPOST_LIST_OT_THE_DAY_CLOSE_OPTION(By.xpath(
			"//div[@class='main-cps']//div//div[@class='head-section']//div[@class='close']//img"),
			"Schedule post List of the day Close button"),

	/** The calendarview scheduledpost list header month. */
	CALENDARVIEW_SCHEDULEDPOST_LIST_HEADER_MONTH("//div[@class='main-cps']//div//div[@class='head-section']//h3",
			"Schedule post List of the day header month"),

	/** The post text content. */
	POST_TEXT_CONTENT(By.xpath("//div[contains(@class,'list-item')]//div[@class='desc-text']//p"), "Post text content"),

	/** The creator type your post. */
	CREATOR_PAGE_POST_TEXT(By.xpath("//div[@class='DraftEditor-editorContainer']//div[contains(@class,'public-Draft')]//span"), "The post text in creator"),
	
	/** The edit scheduled day button. */
	EDIT_SCHEDULED_DAY_BUTTON("//div[contains(@class,'react-datepicker__day react-datepicker__day') and contains(@class,'%s') and @aria-disabled='false']",
			"Edit scheduled Day Button"),
	/** The dropdown logout. */
	DROPDOWN_LOGOUT(By.xpath("//div[@class='dropdown-menu show']//a[text()='Logout']"), "Dropdown logOut"),
	
	/** The instagram login button. */
	INSTAGRAM_LOGIN_BUTTON(By.xpath("//button//div[text()='Log In']"),"Instagram Login Button"),
	
	/** The instagram login page. */
	INSTAGRAM_LOGIN_PAGE(By.xpath("//div[@class='rgFsT   ']"),"Instagram Login Button"),
	
	/** The instagram login username. */
	INSTAGRAM_LOGIN_USERNAME(By.xpath("//input[@name='username']"),"Instagram Login UserName"),
	
	/** The instagram login password. */
	INSTAGRAM_LOGIN_PASSWORD(By.xpath("//input[@name='password']"),"Instagram Login Password"),
	
	/** The instagram login login button. */
	INSTAGRAM_LOGIN_LOGIN_BUTTON(By.xpath("//button//div[text()='Log In']"),"Instagram Login Loggin_Button"),
	
	/** The instagram profile icon. */
	INSTAGRAM_PROFILE_ICON(By.xpath("//img[contains(@alt,'profile picture')]"),"Instagram Profile Icon"),
	
	/** The instagram home icon. */
	INSTAGRAM_HOME_ICON(By.xpath("//*[local-name()='svg' and @aria-label='Home']"),"Instagram Home Icon"),
	
	/** The instagram profile tab. */
	INSTAGRAM_PROFILE_TAB(By.xpath("//div[text()='Profile']"),"Instagram Profile Tab"),
		
	/** The instagram posttab firstpost. */
	INSTAGRAM_POSTTAB_FIRSTPOST(By.xpath("(//main//div[@class=' _aa-i']//a)[1]"),"Instagram PostTab First Post"),

	/** The instagram post detail view. */
	INSTAGRAM_POST_DETAIL_VIEW(By.xpath("//div[@class='_aasx']"),"Instagram Post Detailed View"),
	
	/** The instagram post list. */
	INSTAGRAM_POST_LIST(By.xpath("(//span[text()='Published post - Edited the text'])[1]"),"Instagram Post List View"),
	
	/** The instagram post description. */
	INSTAGRAM_POST_DESCRIPTION("//div[@class='_a9zs']//span[text()='%s']","Instagram Post Description"),
	
	/** The post like button. */
	POST_LIKE_BUTTON(By.xpath("//span[@class='_aamw']//button[@class='_abl-']"), "Post like Button By Text"),

	/** The post like button by posttext. */
	POST_LIKE_BUTTON_BY_POSTTEXT(By.xpath("//div[@class='_a9zs']//span[contains(text(),'Google Chrome')]//ancestor::div[@class='_aat6']//preceding-sibling::section[2]//div[@class='_abm0 _abl_']//*[@aria-label='Like']"), "Post like Button By Text"),
	
	/** The post dislike button by posttext. */
	POST_DISLIKE_BUTTON_BY_POSTTEXT(By.xpath("//div//*[@aria-label='Unlike']"), "Post Dislike Button"),
	
	/** The instagram listview post by text. */
	INSTAGRAM_LISTVIEW_POST_BY_TEXT("(//span[text()='%s'])[1]","Instagram List View Post by Text"),
	
	/** The instagram listview post like button by text. */
	INSTAGRAM_LISTVIEW_POST_LIKE_BUTTON_BY_TEXT("(//span[text()='%s']//ancestor::div[@class='_aa-9 _aa-a']//preceding-sibling::section//span//button)[1]","Instagram List View Post Like Button"),

	/** The instagram listview post liked by text. */
	INSTAGRAM_LISTVIEW_POST_LIKED_BY_TEXT("(//span[text()='%s'])[1]//ancestor::div[@class='_aat6 _aat7']//preceding-sibling::section//span[1]//button","Instagram List View Post Like Button"),
	
	/** The instagram listview post liked count. */
	INSTAGRAM_LISTVIEW_POST_LIKED_COUNT(By.xpath("//span[text()='testPost19580350514633316Google Chrome']//ancestor::div[@class='_aa-9 _aa-a']//preceding-sibling::section//following-sibling::section//div[text()='1 like']"),"Instagram List View Post Like Button"),

	/** The instagram listview post command field by text. */
	INSTAGRAM_LISTVIEW_POST_COMMAND_FIELD_BY_TEXT("(//span[text()='%s']//ancestor::div//preceding-sibling::section//following::section//form//textarea)[1]","Instagram List View Post Command field"),
	
	/** The instagram listview post post button by text. */
	INSTAGRAM_LISTVIEW_POST_POST_BUTTON_BY_TEXT("(//span[text()='%s']//ancestor::div//preceding-sibling::section//following::section)[1]//div[text()='Post']//parent::button","Instagram List View Post Post_button"),
	
	/** The instagram listview post command by text. */
	INSTAGRAM_LISTVIEW_POST_COMMAND_BY_TEXT("(//span[text()='%s'])[1]//ancestor::div[@class='_aat6 _aat7']//following-sibling::section//form//textarea","Instagram List View Post Command field"),

	/** Content tab Calendar. */
	CONTENT_TAB_CALENDAR(By.xpath("//div[contains(@class,'sub-nav-tabs')]//ul//li//span[contains(text(),'Calendar')]"), "Content tab Calendar"),

	/** The monthly post description. */
	MONTHLY_POST_DESCRIPTION("//div[@class='fc-event-main']//div[@class='grid-section']//p[@class='post-content' and contains(text(),'%s')]","The Post decription for Month"),
	
	/** The list view post campaign tag. */
	LIST_VIEW_POST_CAMPAIGN_TAG(By.xpath(
			"//div[@class='header-section']//following-sibling::div[@class='desc-text']//p[text()='%s']//parent::div//preceding-sibling::div//div[@class='campaign-tag']//span[text()='CAMPAIGN']"),
			"List View Post Campaign tag"),
	
	/** The rightside section post campaign icon. */
	RIGHTSIDE_SECTION_POST_CAMPAIGN_ICON(
			"//section[@class='item-g filter calendar-filter__main']//p[text()='%s']//ancestor::div[@class='main-section am-media-preview pmg']//preceding-sibling::div//img[@alt='Active Campaign']",
			"Right Side Section Post Campaign tag"),

	/** The calendar view post campaign icon. */
	CALENDAR_VIEW_POST_CAMPAIGN_ICON(By.xpath(
			"//p[text()='%s']//parent::div[@class='grid-section']//preceding-sibling::div//img[@alt='Active Campaign']"),
			"Calendar View Post Campaign Tag"),

	/** The calendar view rightside section post campaign icon. */
	CALENDAR_VIEW_RIGHTSIDE_SECTION_POST_CAMPAIGN_ICON(By.xpath(
			"//section[@class='item-g filter calendar-filter__main']//p[text()='%s']//parent::div//preceding-sibling::div//following::div//div//img[@alt='Active Campaign']"),
			"Calendar View Right Side Section Campaign tag"),
	
	/** The post describtion content. */
	POST_DESCRIBTION_CONTENT(By.xpath("//div[@class='liv-right list-item']//div[@class='desc-text']//p[@class='post-message' and text()]"),"Post describtion"),
	
	/** The post describtion content. */
	POST_DESCRIBTION_FIELD("//div[@class='liv-right list-item']//div[@class='desc-text']//p[@class='post-message' and contains(text(),'%s')]","Post describtion"),
	
	/** The schedule section schedule button. */
	SCHEDULE_SECTION_SCHEDULE_BUTTON(By.xpath("//h3[text()='Schedule']//parent::div[@class='modal-body']//div[text()='Schedule']"), "Schedule section schedule button"),
	
	/** The footer. */
	FOOTER(By.xpath("//div[contains(@class,'li-view-main')][last()]"),"Footer"),

	/** The Calendar view - footer. */
	CALENDAR_VIEW_FOOTER(By.xpath("//td[@class='fc-timegrid-slot fc-timegrid-slot-lane '][last()]"),"Footer"),

	/** The calendar detailview more option footer. */
	CALENDAR_DETAILVIEW_MORE_OPTION_FOOTER(By.xpath("//div[@class='creator-schedule-section-wrp  blue-bg'][last()]"),"Calendar Detailview More Option footer"),
	
	/** The post command text field. */
	POST_COMMAND_TEXT_FIELD(By.xpath("//form[@class='_aao9']//textarea[contains(@class,'_ablz _aaoc')]"), "Post Command Text Field"),
	
	/** The monthly date total days. */
	MONTHLY_DATE_TOTAL_DAYS(By.xpath("//div[@class='fc-daygrid-day-top']//a[contains(@id,'fc-dom')]"),"Monthly date Total Days"),
	
	/** The weekly days count. */
	WEEKLY_DAYS_COUNT(By.xpath("//a[@class='fc-col-header-cell-cushion']"),"Weekly Days Count"),
	
	/** The daily view currentday. */
	DAILY_VIEW_CURRENTDAY(By.xpath("//a[@class='fc-col-header-cell-cushion']"),"Daily View Current Day"),
	
	//Calendar Post Contents
	
	/** The scheduled post time. */
	SCHEDULED_POST_TIME(By.xpath("//div[@class='fc-event-main']//div[@class='time-stamp']"),"Scheduled Post Time"),

	SCHEDULED_DETAILVIEW_POST_IMAGE(By.xpath("//div[@class='cal-social-preview-sec']//div[@class='p-body']//div//img"),"Scheduled Detailview Post Image"),

	VIEW_CALENDAR_DETAILVIEW(By.xpath("//div[@class='modal-content']//div[@class='view-fullcalendarnew-wrp-section']"),"CALENDAR_DETAILVIEW"),

	/** The scheduled post social media icon. */
	SCHEDULED_POST_SOCIAL_MEDIA_ICON(By.xpath("//div[@class='fc-event-main']//div[@class='right-section']//div[@class='social-icon-sec-new']//div[@class='gmhl-img']"),"Scheduled Post Social Media Icon"),
	
	/** The scheduled post pending approval. */
	SCHEDULED_POST_PENDING_APPROVAL(By.xpath("//div[@class='fc-daygrid-event-harness']//div[contains(@class,'creator-schedule-section-wrp yellow-bg')]//div[@class='left-section']//img[@alt='Approval awaiting']"),"Awaiting Pending Approval"),

	SCHEDULED_POST_PENDING_APPROVAL_ICON(By.xpath("//div[@class='fc-daygrid-event-harness']//div[@class='creator-schedule-section-wrp yellow-bg ']//div[@class='left-section']//img[@alt='Approval awaiting']//following::div[@class='grid-section']//img"),"Scheduled Post Pending Approval Icon"),

	/** The scheduled post image. */
	SCHEDULED_POST_IMAGE(By.xpath("//div[@class='fc-event-main']//div[@class='grid-section']//div[@class='post-img']//div[@class='gmhl-img']//img[@alt='vc-schedule-post-img']"),"Scheduled Post Image"),

	MONTHLY_CALENDAR_SCHEDULED_POST_IMAGE(By.xpath("//div[@class='fc-event-main']//div[@class='grid-section']//div[@class='post-img']"),"Monthly Calendar Scheduled Post Image"),

	/** The scheduled post. */
	SCHEDULED_POST(By.xpath("//div[@class='cal-social-preview-sec']//div[@class='p-body']//p"),"Scheduled Post"),
	
	/** The scheduled post more option. */
	SCHEDULED_POST_MORE_OPTION(By.xpath("//div[@class='fc-daygrid-day-bottom']//a[@class='fc-daygrid-more-link fc-more-link']"),"Scheduled Post more option"),
	
	/** The scheduled post video. */
	SCHEDULED_POST_VIDEO(By.xpath("//div[@class='fc-event-main']//div[@class='grid-section']//div[@class='post-video']"),"Scheduled Post Video "),
	
	/** The scheduled post link. */
	SCHEDULED_POST_LINK(By.xpath("//div[@class='fc-event-main']//div[@class='grid-section']//div[@class='post-img']//following-sibling::p//a[@rel='noreferrer noopener']"),"Scheduled Post link"),
	
	//Calendar DetailView
	
	/** The scheduled post detailview. */
	SCHEDULED_POST_DETAILVIEW(By.xpath("//div[@class='modal-body']//div[@class='cal-social-preview-sec']//div[@class='card-bg']"),"Scheduled Post detailView"),
	
	/** The scheduled post detailview rallio icon. */
	SCHEDULED_POST_DETAILVIEW_RALLIO_ICON(By.xpath("//div[@class='modal-body']//div[@class='cal-social-preview-sec']//div[@class='card-bg']//div[@class='p-avatar']//img"),"Scheduled Post Detailview Rallio icon"),
	
	/** The scheduled post deatilview location name. */
	SCHEDULED_POST_DEATILVIEW_LOCATION_NAME(By.xpath("//div[@class='modal-body']//div[@class='cal-social-preview-sec']//div[@class='card-bg']//div[@class='p-title']//h5"),"Scheduled Post DetailView Location Names"),
	
	/** The scheduled post detailview date and time. */
	SCHEDULED_POST_DETAILVIEW_DATE_AND_TIME(By.xpath("//div[@class='modal-body']//div[@class='cal-social-preview-sec']//div[@class='card-bg']//div[@class='p-title']//p"),"Scheduled Post Detailview Date and Time"),
	
	/** The scheduled post detailview social medianame. */
	SCHEDULED_POST_DETAILVIEW_SOCIAL_MEDIANAME(By.xpath("//div[@class='modal-body']//div[@class='header-section']//span"),"Scheduled Post Social Media Name"),
	
	/** The scheduled post detailview socialmedia icons. */
	SCHEDULED_POST_DETAILVIEW_SOCIALMEDIA_ICONS(By.xpath("//div[@class='modal-body']//div[@class='header-section']//div[@class='fltr-imc selectsocial']"),"Social Media Icons"),
	
	/** The scheduled post detailview post decriptions. */
	SCHEDULED_POST_DETAILVIEW_POST_DECRIPTIONS(By.xpath("//div[@class='modal-body']//div[@class='cal-social-preview-sec']//div[@class='p-body']//p"),"Scheduled DetailView Post Description"),
	
	/** The scheduled post detailview lcs. */
	//LIKE COMMENT SHARE Tab(LCS)
	SCHEDULED_POST_DETAILVIEW_LCS(By.xpath("//div[@class='modal-body']//div[@class='p-footer']//div[@class='footer-btn']"),"Scheduled Post Like,Comment,Share Tab"),
	
	/** The scheduled post detailview image. */
	SCHEDULED_POST_DETAILVIEW_IMAGE(By.xpath("//div[@class='modal-body']//div[@class='p-body']//div[@class='am-media-preview']//img[@alt='p-avatar']"),"Scheduled Post DetailView Image"),
	
	/** The scheduled post detailview pending approval. */
	SCHEDULED_POST_DETAILVIEW_PENDING_APPROVAL(By.xpath("//div[@class='modal-body']//div[@class='card-bg']//div[@class='img-reduce']//img[@alt='Approval awaiting']"),"Scheduled Post Detailview Pending Approval"),
	
	/** The scheduled post detailview close button. */
	SCHEDULED_POST_DETAILVIEW_CLOSE_BUTTON(By.xpath("//div[@class='main-cps']//div[@class='mod__close--icon']//img[@class='mod__close--img']"),"Scheduled Post Detailview close button"),
	
	/** The calendar view post description field. */
	CALENDAR_VIEW_POST_DESCRIPTION_FIELD("//div[contains(@class,'creator-schedule-section-wrp')]//div[@class='grid-section']//p[contains(text(),'%s')]","Calendar view post Description"),
	
	/** The calendar view campaign postdescription with date field. */
	CALENDAR_VIEW_CAMPAIGN_POSTDESCRIPTION_WITH_DATE_FIELD("//div[@class='fc-daygrid-day-top']//a[contains(@id,'fc-dom') and @aria-label='%s']//ancestor::div[contains(@class,'fc-daygrid-day-frame')]//div[contains(@class,'creator-schedule-section-wrp cg-green')]//p[contains(text(),'%s')]","CALENDAR_VIEW_POSTDESCRIPTION_WITH_DATE_FIELD"),
	
	/** The calendar view moreoption by date. */
	CALENDAR_VIEW_MOREOPTION_BY_DATE("//div[@class='fc-daygrid-day-top']//a[@class='fc-daygrid-day-number' and text()='%s']//ancestor::div[@class='fc-daygrid-day-frame fc-scrollgrid-sync-inner']//a[@class='fc-daygrid-more-link fc-more-link']","Calendar View MoreOption By Date"),
	
	/** The calendar view moreoption by date and month. */
	CALENDAR_VIEW_MOREOPTION_BY_DATE_AND_MONTH("//div[@class='fc-daygrid-day-top']//a[@class='fc-daygrid-day-number' and @aria-label='%s']//ancestor::div[@class='fc-daygrid-day-frame fc-scrollgrid-sync-inner']//a[@class='fc-daygrid-more-link fc-more-link']","Calendar View MoreOption By Date"),
	
	/** The calendar view moreoption post field. */
	CALENDAR_VIEW_MOREOPTION_POST_FIELD("//div[@class='modal-body']//div[contains(@class,'creator-schedule-section-wrp')]//div[@class='grid-section']//div//following::p[contains(text(),'%s')]","Calendar View moreOption Post field"),
	
	/** The calendar view moreoption campain post filed. */
	CALENDAR_VIEW_MOREOPTION_CAMPAIN_POST_FILED("//div[@class='creator-schedule-section-wrp cg-green']//p[@class='post-content' and contains(text(),'%s')]","CALENDAR_VIEW_MOREOPTION_CAMPAIN_POST_FILED"),
	
	/** The calendar view moreoption detailview cancel. */
	CALENDAR_VIEW_MOREOPTION_DETAILVIEW_CANCEL(By.xpath("//div[@class='modal-content']//div[@class='mod__close--icon']//img[@alt='close']"),"Calendar View MoreOption Detailview Cancel"),

	CALENDAR_EDIT_DETAILVIEW_CLOSE(By.xpath("//div[@class='modal-content']//div[@class='mod__close--icon header__close--icon']//img[@alt='close']"),"CALENDAR_EDIT_DETAILVIEW_CLOSE"),

	/** The schedule post time field. */
	SCHEDULE_POST_TIME_FIELD("//div[@class='p-header-title']//h6[contains(text(),'%s')]","Schedule Post time"),
	
	/** The scheduled post remove ok button. */
	SCHEDULED_POST_REMOVE_OK_BUTTON(By.xpath("//div[@class='react-ripples ac-danger-box']//button[text()='Ok']"),"SCHEDULED_POST_REMOVE_OK_BUTTON"),

	/** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),
	
	/**  The schedule post - Approved button. */
	SCHEDULED_POST_APPROVED_BUTTON(By.xpath("//div[@class='li-view-main'][1]//button[text()='Approved']"),"The schedule post - Approved button"),
	
	/** The post list location name. */
	POST_LIST_LOCATION_NAME(By.xpath("//div[@class='liv-right list-item']//div[@class='p-header-title']//div[@class='p-title']//h5"),"Post List Location Name"),

	/** The platform connect alert */
	PLATFORM_CONNECT_ALERT(By.xpath("//div[@class='Toastify']//div//span[@class='success-mess-txt' and text()='To approve this post, you need to connect a social media account.']"),"The platform connect alert"),

	/** The Awaiting approval post */
	AWAITING_APPROVAL_POST(By.xpath("//div[contains(@class,'view-fullcalendarnew')]//div[@class='fc-event-main']//div[contains(@class,'creator-schedule')]//img[@alt='Approval awaiting']"),"The Awaiting approval post"),

	/** The Scheduler page load */
	SCHEDULER_PAGE_LOAD(By.xpath("//li[@class='ripple active']//span[text()='Scheduler']//ancestor::div[contains(@class,'ra-page filter')]//section[@id='main-container-sec']//div[@class='cf-scheduler vpy-20 lpx']"),"The Scheduler page load"),

	/** The Feed page load */
	FEED_PAGE_LOAD(By.xpath("//li[@class='ripple active']//span[text()='Feed']//ancestor::div[contains(@class,'ra-page filter')]//div[contains(@class,'tml-main feed-table')]"),"The Feed page load"),

	DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]","Date Picker"),

	DISABLE_DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and @aria-disabled='true']","Date Picker"),


	;
	
	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new content tab calendar page enum.
	 *
	 * @param byLocator   the by locator
	 * @param description the description
	 */
	private ContentTabCalendarPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new content tab calendar page enum.
	 *
	 * @param xpath       the xpath
	 * @param description the description
	 */
	private ContentTabCalendarPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

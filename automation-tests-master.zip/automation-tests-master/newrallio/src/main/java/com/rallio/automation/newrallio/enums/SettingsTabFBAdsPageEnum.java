package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.*;

// TODO: Auto-generated Javadoc
/**
 * The Enum SettngsTabFBAdsPageEnum.
 */
public enum SettingsTabFBAdsPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath(
	        "//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='FB Ads']//ancestor::div//section[contains(@class,'item-g notification-cnt fbads__right--note')]//preceding::div//section[@id='main-container-sec']//div[@class='content-g']//div[contains(@class,'fb-ads__main lpx')]"),
	        "Page load"),

	/** The facebook ad account. */
	FACEBOOK_AD_ACCOUNT(
	        By.xpath("//main//div[contains(@class,'mainContent')]//img[contains(@src,'fb-lv.svg')]//ancestor::div[@class='rel-head-label']//span[text()='Facebook Ad Account']"),
	        "Facebook Ad account"),
	
	FACEBOOK_ICON(By.xpath("//div[@class='rel-icons']//img[contains(@src,'fb-lv.svg')]"),"Facebook Icon"),
	
	FACEBOOK_ADS_DESCRIPTION(By.xpath("//span[text()='Boost your posts and run ads through Facebook by connecting your Facebook ad account below. Before connecting and running ads, you must already have your billing information set up in your ad account.']//parent::div//img[contains(@src,'fbAds')]"),"Facebook Ads Description"),
	
	/** The account name. */
	ACCOUNT_NAME(By.xpath("//main//div[contains(@class,'mainContent')]//div[@class='scl-details']//span[text()='Account Name']//following-sibling::span"), "Account name"),

	/** The account id. */
	ACCOUNT_ID(By.xpath("//main//div[contains(@class,'mainContent')]//div[@class='scl-details']//span[text()='Account ID']//following-sibling::span"), "Account ID"),

	/** The connect now button. */
	CONNECT_NOW_BUTTON(By.xpath("//div[contains(@class,'mainContent animate')]//div[contains(@class,'react-ripples')]//button[text()='Connect Now']"), "Connect now button"),

	/** The disconnect button. */
	DISCONNECT_BUTTON(By.xpath("//button[text()='Disconnect']"), "Disconnect button"),

	/** The disconnect alert. */
	DISCONNECT_ALERT(By.xpath("//div[@class='modal-content']//div[@class='modal-body']//div[@class='modal-message-wraps']"), "Disconnect alert"),

	/** The disconnect alert cancel button. */
	DISCONNECT_ALERT_CANCEL_BUTTON(By.xpath("//div[@class='modal-content']//div[@class='modal-footer']//button[text()='Cancel']"), "Disconnect alert cancel button"),
	
	/** The disconnect alert ok button. */
	DISCONNECT_ALERT_OK_BUTTON(By.xpath("//div[@class='modal-content']//div[@class='modal-footer']//button[text()='Ok']"),"Disconnect alert ok button"),

	/** The change account button. */
	CHANGE_ACCOUNT_BUTTON(By.xpath("//button[text()='Change Account']"), "Change account button"),

	/** The boost setting defaults. */
	BOOST_SETTING_DEFAULTS(
	        By.xpath("//img[contains(@src,'boost')]//parent::div//parent::div//span[text()='Boost Settings Defaults']"),
	        "Boost setting defaults"),

	/** The budget. */
	BUDGET(By.xpath(
	        "//main//div[contains(@class,'mainContent')]//div[@class='fb__white--box wb-first']//div[text()='Budget']"),
	        "Budget"),

	/** The target audience. */
	TARGET_AUDIENCE(By.xpath("//div[@class='fb__white--box wb-second']//div[text()='Target Audience']"),
	        "Target audience"),

	/** The daily spend value. */
	DAILY_SPEND_VALUE(By.xpath(
	        "//input[@name='lifetime_spend']"),
	        "Daily sepnd value"),

	/** The zip code. */
	ZIP_CODE(By.xpath(
	        "//div[@class='zip-search']//input"),
	        "Zip code"),

	/** The store location. */
	STORE_LOCATION(By.xpath(
	        "//div[@class='wb-fields lzm']//div[@class='addzip']//div[@class='selected-zip']"),
	        "Store location"),

	/** The radius value. */
	RADIUS_VALUE(By.xpath(
	        "//div[@class='cust-tag cu-pointer']//div[@class='miles-dropdown ']//span"),
	        "Radius value"),

	/** The radius slider. */
	RADIUS_SLIDER(By.xpath(
	        "//main//div[contains(@class,'mainContent')]//div[@class='white-box wb-second']//span[text()='Radius']//ancestor::div[@class='wb-fields']//div[@class='wbf-inputs']//div[@class='rc-slider-handle']"),
	        "Radius slider"),

	/** The interests dropdown. */
	INTERESTS_DROPDOWN(By.xpath(
	        "//span[text()='Interests']//ancestor::div[@class='wb-fields']//div[@class='wbf-inputs']//div[@class='ilo-dropdown']"),
	        "Interests dropdown"),

	/** The interests input. */
	INTERESTS_INPUT(By.xpath(
	        "//main//div[contains(@class,'mainContent')]//div[contains(@class,'wb-second')]//span[text()='Interests']//ancestor::div[@class='wb-fields']//div[@class='wbf-inputs']//input"),
	        "Interests input"),

	AGE_SLIDER(By.xpath(
	        "//div[@class='rc-slider-rail']"),
	        "Age min slider"),
	
	/** The age min val. */
	AGE_MIN_VAL(By.xpath(
	        "//div[@class='wbf-inputs']//div[@class='rc-slider-mark']//span[1]//span"),
	        "Age min value"),

	/** The age max value. */
	AGE_MAX_VALUE(By.xpath(
	        "//div[@class='wbf-inputs']//div[@class='rc-slider-mark']//span[2]//span"),
	        "Age max value"),

	/** The age min slider. */
	AGE_MIN_SLIDER(By.xpath(
	        "//div[@class='rc-slider-handle rc-slider-handle-1']"),
	        "Age min slider"),

	/** The age max slider. */
	AGE_MAX_SLIDER(By.xpath(
	        "//div[@class='rc-slider-handle rc-slider-handle-2']"),
	        "Age max slider"),

	/** The gender all. */
	GENDER_ALL(By.xpath(
	        "//img[contains(@src,'gender-all')]//parent::div//parent::label//span[text()='All']"),
	        "Gender all"),

	/** The gender all selected. */
	GENDER_ALL_SELECTED(By.xpath(
	        "//div[@class='wbf-inputs']//div//input[@value='all']//following-sibling::label[@class='active btn btn-primary']"),
	        "Gender all selected"),

	/** The gender male. */
	GENDER_MALE(By.xpath(
	        "//div[@class='fb__white--box wb-second']//div[@class='wbf-inputs']//div[@role='group']//input[@value='male']"),
	        "Gender male"),

	/** The gender male selected. */
	GENDER_MALE_SELECTED(By.xpath(
	        "//div[@class='wbf-inputs']//div//input[@value='male']//following-sibling::label[@class='active btn btn-primary']"),
	        "Gender male selected"),

	/** The gender female. */
	GENDER_FEMALE(By.xpath(
	        "//img[contains(@src,'gender-female')]//parent::div//parent::label//span[text()='Female']"),
	        "gender female"),

	/** The gender female selected. */
	GENDER_FEMALE_SELECTED(By.xpath(
	        "//div[@class='wbf-inputs']//div//input[@value='female']//following-sibling::label[@class='active btn btn-primary']"),
	        "gender female selected"),

	/** The connections like. */
	CONNECTIONS_LIKE(By.xpath(
	        "//main//div[contains(@class,'mainContent')]//div[@class='white-box wb-second']//span[text()='Connections']//ancestor::div[@class='wb-fields']//div[@class='wbf-inputs']//div[@class='form-group']//span[text()='People who like your Page']"),
	        "Connections like"),

	/** The connections like selected. */
	CONNECTIONS_LIKE_SELECTED(By.xpath(
	        "//main//div[contains(@class,'mainContent')]//div[@class='white-box wb-second']//span[text()='Connections']//ancestor::div[@class='wb-fields']//div[@class='wbf-inputs']//div[@class='form-group']//span[text()='People who like your Page']//following::label[contains(@class,'active')]"),
	        "Connections like selected"),

	/** The connections dislike. */
	CONNECTIONS_DISLIKE(By.xpath(
	        "//main//div[contains(@class,'mainContent')]//div[@class='white-box wb-second']//span[text()='Connections']//ancestor::div[@class='wb-fields']//div[@class='wbf-inputs']//div[@class='form-group']//span[text()='People who do not like your Page']"),
	        "Connections dislike"),

	/** The connections dislike selected. */
	CONNECTIONS_DISLIKE_SELECTED(By.xpath(
	        "//main//div[contains(@class,'mainContent')]//div[@class='white-box wb-second']//span[text()='Connections']//ancestor::div[@class='wb-fields']//div[@class='wbf-inputs']//div[@class='form-group']//span[text()='People who do not like your Page']//following::label[contains(@class,'active')]"),
	        "Connections dislike selected"),

	/** The connections like friends. */
	CONNECTIONS_LIKE_FRIENDS(By.xpath(
	        "//main//div[contains(@class,'mainContent')]//div[@class='white-box wb-second']//span[text()='Connections']//ancestor::div[@class='wb-fields']//div[@class='wbf-inputs']//div[@class='form-group']//span[text()='People who like your Page and their friends']"),
	        "Connections like and friends"),

	/** The connections like friends selected. */
	CONNECTIONS_LIKE_FRIENDS_SELECTED(By.xpath(
	        "//main//div[contains(@class,'mainContent')]//div[@class='white-box wb-second']//span[text()='Connections']//ancestor::div[@class='wb-fields']//div[@class='wbf-inputs']//div[@class='form-group']//span[text()='People who like your Page and their friends']//following::label[contains(@class,'active')]"),
	        "Connections like friends selected"),

	/** The connections all. */
	CONNECTIONS_ALL(By.xpath(
	        "//main//div[contains(@class,'mainContent')]//div[@class='white-box wb-second']//span[text()='Connections']//ancestor::div[@class='wb-fields']//div[@class='wbf-inputs']//div[@class='form-group']//span[text()='All of the above']"),
	        "Connections all"),

	/** The connections all selected. */
	CONNECTIONS_ALL_SELECTED(By.xpath(
	        "//main//div[contains(@class,'mainContent')]//div[@class='white-box wb-second']//span[text()='Connections']//ancestor::div[@class='wb-fields']//div[@class='wbf-inputs']//div[@class='form-group']//span[text()='All of the above']//following::label[contains(@class,'active')]"),
	        "Connections all selected"),

	/** The save changes button. */
	SAVE_CHANGES_BUTTON(By.xpath("//button[text()='Save Changes']"),
	        "Save changes button"),
	

   /** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),
	
	LOCATION_MAP(By.xpath("//div[@class='map--wrp']//div[@id='map1']"),"MAP LOCATION"),
	
	/** The cannot save button. */
	CANNOT_SAVE_BUTTON(By.xpath("//div[contains(@class,'pointer-events-none')]//button[text()='Cannot Save']"),"Cannot save button"),

	/** The Facebook Ad Account 1 */
	FACEBOOK_AD_ACCOUNT_CURRENT_ACCOUNT(By.xpath("//div[@class='scld-item']//span[@class='scld-label' and text()='Account Name']//parent::div//span[text()='Bala Ksv']"),"Facebook current Ad account"),

	/** The Facebook Ad Account 1 */
	FACEBOOK_AD_ACCOUNT_CHANGED_ACCOUNT(By.xpath("//div[@class='scld-item']//span[@class='scld-label' and text()='Account Name']//parent::div//span[text()='Kanzy J']"),"Facebook changed Ad account"),

	/** The Interests */
	INTERESTS(By.xpath("//div[@class='fb__white--box wb-second']//div[@class='react-tags__search-input']//input[@placeholder='Add a new interest']"),"The Interests"),

	/** The Interests dropdown option */
	INTERESTS_DROPDOWN_OPTION(By.xpath("//div[@class='custom-menu-container']//nav[@class='custom-dropdown-menu active']//li[text()=' Interests >  Additional interests > Interesting Things']"),"The Interests dropdown options"),

	/** The Area*/
	AREA_ZIP_CODES(By.xpath("//div[@class='wb-fields lzm']//div[@class='zip-search-wrapper']//input[@placeholder='Add US Zip Codes']"),"The Area"),


	/** Area Address */
	AREA_ADDRESS(By.xpath("//div[@class='wb-fields lzm']//div[@class='loc-selector--wrp']//input[@placeholder='Add US Address']"),"The Area address"),

	/** Area Address dropdown option */
	AREA_ADDRESS_DROPDOWN_OPTION(By.xpath("//div[@class='edit-audience-modal']//nav[@class='custom-dropdown-menu active']//li[text()='Chariton, Iowa 50049, United States']"),"The Area address dropdown option"),

	/** Leaflet location value */
	LEAFLET_EXIXTING_LOCATION_VALUE(By.xpath("//div[@class='map--wrp']//div[contains(@class,'leaflet-container')]//div[@class='leaflet-pane leaflet-marker-pane']//img")," Leaflet location value"),

	/** Leaflet location value */
	LEAFLET_NEW_LOCATION_VALUE(By.xpath("//div[@class='map--wrp']//div[contains(@class,'leaflet-container')]//div[@class='leaflet-pane leaflet-marker-pane']//img[2]")," Leaflet location value"),

	/** Location Miles dropdown option */
	LOCATION_MILES_DROPDOWN_OPTION(By.xpath("//div[@class='cust-tag cu-pointer']//span[@title='Chariton, Iowa 50049, United States']//parent::div//div[@class='miles-dropdown ']//span[@class='lbl']"),"Location Miles dropdown option"),

	/** Location Slider */
	LOCATION_SLIDER(By.xpath("//div[@class='miles-drpdown--list']//div[contains(@class,'rc-slider rc-slider')]//div[@class='rc-slider-handle']"),"The Location Slider"),

	/** Location Slider value */
	LOCATION_SLIDER_VALUE(By.xpath("//div[@class='miles-drpdown--list']//div[contains(@class,'rc-slider rc-slider')]//div[@class='rc-slider-mark']//span//span"),"The Location Slider value"),

	/** Data saved success alert */
	DATA_SAVE_SUCCESS_ALERT(By.xpath("//div[@role='alert']//div//span[text()='Default settings updated']"),"Data saved success alert"),

	/** The Location remove option*/
	DROPDOWN_LOCATION_REMOVE_OPTION(By.xpath("//div[@class='cust-tag cu-pointer']//span[text()='Chariton, Iowa 50049, United States']//parent::div//parent::div//button"),"The Location remove option"),

	/** The Zip code remove option*/
	AREA_ZIP_CODE_REMOVE_BUTTON(By.xpath("//span[@class='ifa' and text()='50050']//span[@class='remove-zip-code']"),"The Location remove option"),

	/** The Interests remove option*/
	INTERESTS_REMOVE_OPTION(By.xpath("//span[text()=' Interests >  Additional interests > Interesting Things']//parent::button"),"The Interests remove option"),

	;

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new settngs tab FB ads page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private SettingsTabFBAdsPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new settngs tab FB ads page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private SettingsTabFBAdsPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

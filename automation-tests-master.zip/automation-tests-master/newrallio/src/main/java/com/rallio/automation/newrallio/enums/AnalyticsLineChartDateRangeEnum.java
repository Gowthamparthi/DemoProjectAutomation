package com.rallio.automation.newrallio.enums;

public enum AnalyticsLineChartDateRangeEnum {
	
	DATE_WISE,
	
	WEEK_WISE,
	
	MONTH_WISE,
	
	YEAR_WISE;
	
}

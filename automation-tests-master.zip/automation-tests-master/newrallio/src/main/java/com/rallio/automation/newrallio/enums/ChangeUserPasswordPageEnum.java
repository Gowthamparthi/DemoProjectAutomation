package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum ChangeUserPasswordPageEnum.
 */
public enum ChangeUserPasswordPageEnum {

	/** Profile icon. */
	PROFILE_ICON(By.xpath("//button[@id='dropitems-profile-items']"), "Profile icon"),

	/** Profile icon dropdown. */
	PROFILE_ICON_DROPDOWN(By.xpath("//button[@id='dropitems-profile-items']//following-sibling::div[@class='dropdown-menu show']"), "Profile icon dropdown"),

	/** Dropdown profile name. */
	DROPDOWN_PROFILE_NAME(By.xpath("//div[@class='dropdown-menu show']//a[text()][1]"), "Dropdown profile name"),

	/** Dropdown change password. */
	DROPDOWN_CHANGE_PASSWORD(By.xpath("//div[@class='dropdown-menu show']//a[text()='Change Password']"), "Dropdown change password"),

	/** The dropdown logout. */
	DROPDOWN_LOGOUT(By.xpath("//div[@class='dropdown-menu show']//a[text()='Logout']"), "Dropdown logOut"),

	/** The change password pageload. */
	CHANGE_PASSWORD_PAGELOAD(By.xpath("//div[@class='header__modal--content']"), "ChangePassword Pageload"),

	/** The change password header letters. */
	CHANGE_PASSWORD_HEADER_LETTERS(By.xpath("//div[text()='Change Password']"), "ChangePassword Header letters"),

	/** The change password hints. */
	CHANGE_PASSWORD_HINTS(By.xpath("//p[text()='Want to change your password?']//following-sibling::p[text()='No problem! Just enter your current password, and confirm your new one.']"), "ChangePassword Hints"),

	/** The current password tab. */
	CURRENT_PASSWORD_TAB(By.xpath("//input[@name='current_password']"), "Current password"),

	/** The new password tab. */
	NEW_PASSWORD_TAB(By.xpath("//input[@name='new_password']"), "New password"),

	/** The conform newpassword tab. */
	CONFORM_NEWPASSWORD_TAB(By.xpath("//input[@name='confirm_password']"), "Conform New password"),

	/** The close button. */
	CLOSE_BUTTON(By.xpath("//div[text()='Change Password']//img[contains(@src,'close-modal-icon')]"), "Close Button"),

	/** The save button. */
	SAVE_BUTTON(By.xpath("//button[contains(@class,'ac-btn ac-primary ac') and text()='Save']"), "Save Button"),

	/** The error message. */
	ERROR_MESSAGE(By.xpath("//div//span[@class='errorText' and text()='Incorrect current password']"), "Error text message");

	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new change user password page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private ChangeUserPasswordPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;

		this.description = description;
	}

	/**
	 * Instantiates a new change user password page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private ChangeUserPasswordPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}

}

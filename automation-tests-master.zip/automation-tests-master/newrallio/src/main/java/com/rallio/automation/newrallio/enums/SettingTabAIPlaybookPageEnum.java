package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum SettingTabAIPlaybookPageEnum.
 */
public enum SettingTabAIPlaybookPageEnum {

	/** The page load. */
	PAGE_LOAD(By.xpath("//div[contains(@class,'sub-nav-tabs')]//li[@class='ripple active']//span[text()='AI Playbook']//ancestor::div//section[contains(@class,'item-g notification-cnt')]//preceding::div//section[@id='main-container-sec']//div[@class='content-g']//div[contains(@class,'settings-rallio-profile-new-section')]"),"Page Load"),
	
	/** The ai playbook header. */
	AI_PLAYBOOK_HEADER(By.xpath("//div[@class='left-section-wrp']//div[contains(@class,'location-img') and text()]"),"AI Playbook Header"),
	
	/** The business info. */
	BUSINESS_INFO(By.xpath("//div[@class='content-left-section']//h3[text()='Business Info']"),"Business Info"),
	
	/** The business name. */
	BUSINESS_NAME_DISABLE_STATE(By.xpath("//div[contains(@class,'content-right-section')]//div[contains(@class,'events-none pointer')]//input[@name='name']"),"Business Name"),

	/** The business name. */
	BUSINESS_NAME(By.xpath("//div[contains(@class,'content-right-section')]//div//input[@name='name']"),"Business Name"),
	
	/** The business name error. */
	BUSINESS_NAME_ERROR(By.xpath("//div[contains(@class,'form-group form-field-item erroritem')]//input[@name='name']"),"Business name Error"),
	
	/** The website url. */
	WEBSITE_URL(By.xpath("//div[contains(@class,'content-right-section')]//div[contains(@class,'form-group')]//input[@name='business_url']"),"Website Url"),
	
	/** The website url field. */
	WEBSITE_URL_FIELD("//input[@name='business_url' and @value='%s']","WebSite Url Field"),
	
	/** The website url error. */
	WEBSITE_URL_ERROR(By.xpath("//div[contains(@class,'form-field-item erroritem')]//input[@name='business_url']"),"Website Url Error"),
	
	/** The business category. */
	BUSINESS_CATEGORY(By.xpath("//span[text()='Business Category']//ancestor::div//div[@class='cs-select__single-value css-qc6sy-singleValue']"),"Business Category"),
	
	/** The business category name. */
	BUSINESS_CATEGORY_NAME("//div[@class='cs-select__single-value css-qc6sy-singleValue' and text()='%s']","Business Category Name"),
	
	/** The business category button. */
	BUSINESS_CATEGORY_BUTTON(By.xpath("//div[@class='cs-select__indicator cs-select__dropdown-indicator css-tlfecz-indicatorContainer']"),"Business Category Button"),
	
	/** The business category dropdown. */
	BUSINESS_CATEGORY_DROPDOWN(By.xpath("//div[@class='cs-select__menu css-ik6y5r']//div[@class='cs-select__menu-list css-11unzgr']"),"Business Catagory Dropdown"),
	
	/** The business category dropdown byname. */
	BUSINESS_CATEGORY_DROPDOWN_BYNAME("//div[@class='cs-select__menu css-ik6y5r']//div[@class='cs-select__menu-list css-11unzgr']//div[@class='cs-select__option css-yt9ioa-option' and text()='%s']","Business Dropdown By Name"),
	
	/** The what do you call text. */
	HOTELS_CALL_THEM_TEXT(By.xpath("//div[@class='wdyCall']//p[text()='Hotels call them guests, doctors call them patients, ... What about you?']"),"HOTELS_CALL_THEM_TEXT"),
	
	/** The customer alias field. */
	CUSTOMER_ALIAS_FIELD(By.xpath("//div[@class='react-tags__search-wrapper']//input[@placeholder='Customer Alias']"),"Customer Alias Field"),
	
	/** The favourite tag. */
	FAVOURITE_TAG("//div[@class='list-expanded-tag-item']//span[@class='list-expanded-tag-text' and text()='%s']","Favourite Tag"),
	
	/** The favourite tag remove. */
	FAVOURITE_TAG_REMOVE("//div[@class='list-expanded-tag-item']//span[@class='list-expanded-tag-text' and text()='%s']//following-sibling::span[@class='list-expanded-tag-remove']","Favourite Tag Remove"),
	
	/** The what would someone type text. */
	WHAT_WOULD_SOMEONE_TYPE_TEXT(By.xpath("//div[@class='wdyCall']//p[text()='What would someone type when they search for you? \"Best Mexican food\", \"Haircut for children\" etc.']"),"WHAT_WOULD_SOMEONE_TYPE_TEXT"),
	
	/** The business search. */
	BUSINESS_SEARCH(By.xpath("//div[@class='react-tags__search-wrapper']//input[@placeholder='Business Search']"),"Business Search"),

	SAVE_ALL_BUTTON(By.xpath("//button[text()='Save All']"),"Save All Button"),

	/** The anything else you want text. */
	WHAT_ELSE_YOU_WANT_TEXT(By.xpath("//div[@class='wdyCall']//p[text()='What else can you share about your business that makes it unique?']"),"WHAT_ELSE_YOU_WANT_TEXT"),
	
	/** The brag about business text. */
	BRAG_ABOUT_BUSINESS_TEXT(By.xpath("//div[@class='wdyCall']//*[local-name()='textarea' and @id='exampleForm.ControlTextarea1']"),"Business Brag Field"),
	
	/** The brag about business field. */
	BRAG_ABOUT_BUSINESS_FIELD("//div[@class='wdyCall']//*[local-name()='textarea' and @id='exampleForm.ControlTextarea1' and text()='%s']","BRAG_ABOUT_BUSINESS_FIELD"),
	
	/** The cancel button. */
	CANCEL_BUTTON(By.xpath("//button[contains(@class,'ac-btn ac-secondary-white') and text()='Cancel']"),"Cancel Button"),
	
	/** The save button. */
	SAVE_BUTTON(By.xpath("//div[@class='react-ripples ripple-unset ac-primary-box']//button[contains(@class,'ac-btn ac-primary size-sm') and text()='Save']"),"SAVE Button"),
	
	/** The cancel button. */
	CANCEL_BUTTON_DISABLED(By.xpath("//button[contains(@class,'ac-outline size-sm disabled') and text()='Cancel']"),"Cancel Button"),

	CREATE_GOALS_BUTTON(By.xpath("//h3[text()='Activity Goals']//parent::div[@class='content-left-section']//following::div[@class='personaSec']//button[text()='Create Goal']"),"CREATE Goals Button"),

	/** The Documents cancel button */
	GENERAL_DOCUMENT_BROWSE_BUTTON(By.xpath("//div[contains(@class,'content-full')]//h3[text()='General Docs']//parent::div//parent::div//div[contains(@class,'react-ripples')]//button[text()='Browse']"),"The Document browse button"),

	GENERAL_DOCUMENT_DRAG_AND_DROP_BUTTON(By.xpath("//div[contains(@class,'content-full')]//h3[text()='General Docs']//parent::div//parent::div//span[text()='Drag & Drop your pdf files here to upload']"),"GENERAL_DOCUMENT_DRAG_AND_DROP_BUTTON"),

	COMPLIANCE_DOC_DRAG_AND_DROP_BUTTON(By.xpath("//div[contains(@class,'content-full')]//h3[text()='Compliance Docs']//parent::div//parent::div//span[text()='Drag & Drop your pdf files here to upload']"),"COMPLIANCE_DOC_DRAG_AND_DROP_BUTTON"),

    COMPLIANCE_DOC_BROWSE_BUTTON(By.xpath("//div[contains(@class,'content-full')]//h3[text()='Compliance Docs']//parent::div//parent::div//div[contains(@class,'react-ripples')]//button[text()='Browse']"),"Compliance Doc Browse Button"),

	/** The Customer Persona button */
	CUSTOMER_PERSONA(By.xpath("//div[contains(@class,'content-full')]//h3[text()='Customer Persona']//parent::div//parent::div//div[contains(@class,'react-ripples')]//button[text()='Generate Persona']"),"The Customer persna - generate button"),

	/** The Customer Persona text */
	CUSTOMER_PERSONA_TEXT("//div[contains(@class,'content-full')]//h3[text()='Customer Persona']//parent::div//parent::div//div[@class='tags-wrp']//span[text()='%s']","The Customer Persona text"),

	CUSTOMER_PERSONA_DESCRIPTION(By.xpath("//div[@class='personaSec']//div[@class='tags-wrp']//span"),"Customer Persona Desc"),

	GENERATE_CUSTOMER_PERSONA_BUTTON(By.xpath("//button[text()='Generate Persona']"),"Generate Customer Persona"),

	/** The Customer Persona data */
	CUSTOMER_PERSONA_DATA(By.xpath("//div[@class='personaSec']//div[@class='tags-wrp']//div//span[@class='list-expanded-tag-text']//following-sibling::span[@class='list-expanded-tag-remove']"),"The Customer Persona data"),

	/** The save button. */
	SAVE_BUTTON_DISABLED(By.xpath("//button[contains(@class,'ac-btn ac-primary size-sm disabled') and text()='Save All']"),"SAVE Button"),

	/** The add tags. */
	ADD_TAGS(By.xpath("//div[@class='react-tags__suggestions']"),"Add Tags"),
	
	/** The ai playbook updated successfully. */
	AI_PLAYBOOK_UPDATED_SUCCESSFULLY(By.xpath("//span[text()='AI playbook updated successfully!']"),"AI Playbook Updated Successfully"),
	
	/** The unsaved changes popup. */
	UNSAVED_CHANGES_POPUP(By.xpath("//div[@class='modal-content']//div[@class='modal-header']//following-sibling::div[@class='modal-footer']"),"Unsaved Changes PopUp"),
	
	/** The unsaved changes cancel button. */
	UNSAVED_CHANGES_CANCEL_BUTTON(By.xpath("//div[@class='modal-content']//div[@class='modal-header']//following-sibling::div[@class='modal-footer']//button[text()='Cancel']"),"Unsaved Changes Cancel Button"),
	
	/** The unsaved changes ok button. */
	UNSAVED_CHANGES_OK_BUTTON(By.xpath("//div[@class='modal-content']//div[@class='modal-header']//following-sibling::div[@class='modal-footer']//button[text()='Ok']"),"Unsaved Changes Cancel Button"),
	
	/** The ai subscribtion video play. */
	AI_SUBSCRIBTION_VIDEO_PLAY(By.xpath("//div[@role='tooltip']//div[@class='aicoach-body']//div[@class='aicoach-cnt']//div[@class='ai-coach-video']"),"AI Subscribtion Video Play"),
	
	/** The Customer alias serach bar. */
	CUSTOMER_ALIAS_SEARCH_BOX(By.xpath("//div[@class='react-tags__search-wrapper']//input[@placeholder='Customer Alias']"),"The Customer alias serach bar"),
	
	/** The Notification alert */
	NOTIFICATION_ALERT(By.xpath("//div[@class='right-section-wrp']//div[contains(@class,'required-content')]//span[text()='These fields are required']"),"The Notification alert"),
	
	BROWSE_BUTTON(By.xpath("//button[@class='drag__drop--btn' and text()='Browse']"),"Browse Button"),

	COMPLIANCE_DESCRIPTION_TEXT(By.xpath("//h3[text()='Compliance Description']//parent::div//parent::div[@class='content-full-wrp settins-content--wrp comp-desc']//div[contains(@class,'content-right-section')]//textarea[text()]"),"Compliance Description Text"),

	COMPLIANCE_DESCRIPTION(By.xpath("//h3[text()='Compliance Description']//ancestor::div[contains(@class,'content--wrp comp-desc')]//div[@class='form-group']//textarea[@class='form-control']"),"Compliance Description"),

	/** The ai video donot show me checkbox. */
	AI_VIDEO_DONOT_SHOW_ME_CHECKBOX(By.xpath("//div[@class='aicoach-body']//label[@class='checkbox-item']//span[@class='checkbox-hover']//input[@name='localizePost']"),"AI Subscribtion Video Check Box"),

	AUTO_GENERATED_AI_POSTS_SWITCH(By.xpath("//h3[text()='Auto Generate AI Posts']//ancestor::div[contains(@class,'settings-rallio-profile-new-section')]//div[@class='right-section']//div[contains(@class,'form-switch')]//input"),"Auto Generate AI Posts Switch"),

	AUTO_GENERATED_AI_POSTS_SWITCH_ACTIVE(By.xpath("//h3[text()='Auto Generate AI Posts']//ancestor::div[contains(@class,'settings-rallio-profile-new-section')]//div[@class='right-section']//div[@class='active form-switch']//input"),"Auto Generate AI Posts Active"),

	AUTO_GENERATED_AI_POSTS_SWITCH_INACTIVE(By.xpath("//h3[text()='Auto Generate AI Posts']//ancestor::div[contains(@class,'settings-rallio-profile-new-section')]//div[@class='right-section']//div[not(@class='active form-switch')]//input"),"Auto Generate AI Posts InActive"),

	AUTO_GENERATED_AI_POST_INFO(By.xpath("//h3[text()='Auto Generate AI Posts']//ancestor::div[contains(@class,'settings-rallio-profile-new-section')]//span"),"Auto Generated AI Posts Info"),

	;

	
	
	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;
	
	/**
	 * Instantiates a new setting tab AI playbook page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private SettingTabAIPlaybookPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new setting tab AI playbook page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private SettingTabAIPlaybookPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}

package com.rallio.automation.newrallio.enums;

import org.openqa.selenium.By;

// TODO: Auto-generated Javadoc
/**
 * The Enum RevvDashboardPageEnum.
 */
public enum RevvDashboardPageEnum {
	
	/** The page load. */
	PAGE_LOAD(By.xpath("//li[@class='ripple active']//span[text()='Dashboard']//ancestor::div//section[@class='item-g filter revv-dashboard-filter']//preceding::div[contains(@class,'non-psp-dashboard ps-0 pe-0 pb-20')]"),"Revv Dashboard Page Load"),
	
	/** The total vist stats count. */
	TOTAL_VIST_STATS_COUNT(By.xpath("//div[@class='stat-tile total-visit d-flex flex-column ']//h3[text()='TOTAL VISITS']//following-sibling::div[@class]"),"Total Vist Count"),
	
	/** The survey sent stats count. */
	SURVEY_SENT_STATS_COUNT(By.xpath("//div[@class='stat-tile survey-sent d-flex flex-column ']//section[@class='img-box']//parent::div//h3[text()='Surveys Sent']//following-sibling::div[@class='value']"),"Surveys Sent Count"),
	
	/** The survey cmpletes stats count. */
	SURVEY_COMPLETES_STATS_COUNT(By.xpath("//div[contains(@class,'stat-tile survey-completed')]//section[@class='img-box']//parent::div//h3[text()='Surveys Completed']//following-sibling::div[@class='value']"),"Surveys Completed Count"),
	
	/** The agreed to review stats count. */
	AGREED_TO_REVIEW_STATS_COUNT(By.xpath("//div[contains(@class,'stat-tile agreed-to-review')]//section[@class='img-box']//parent::div//h3[text()='Agreed to Review']//following-sibling::div[@class='value']"),"Aggreed To Review Count"),
	
	/** The reviews received stats count. */
	REVIEWS_RECEIVED_STATS_COUNT(By.xpath("//div[contains(@class,'stat-tile review-received')]//section[@class='img-box']//parent::div//h3[text()='Reviews Received']//following-sibling::div[@class='value']"),"Reviews Recevied Count"),
	
	/** The chart view. */
	CHART_VIEW_BUTTON(By.xpath("//div[contains(@class,'stat-tile chart-view')]//h3[text()='CHART VIEW']"),"Chart View"),
	
	/** The chart in detaiview. */
	CHART_IN_DETAILVIEW(By.xpath("//table[@class='non-psp__questions-list responsiveTable']//div[contains(@class,'non-psp-dash__chart')]//div[contains(@id,'surveyTableChart')]"),"Chart in Detail View"),
	
	/** The table with questions. */
	TABLE_WITH_QUESTIONS(By.xpath("//table[@class='non-psp__questions-list responsiveTable']//tr//th[text()='Questions']//ancestor::div//tbody//td//aside[@class='question-wrp d-flex align-items-center']"),"Table with Questions"),
	
	/** The my rating value. */
	MY_RATING_VALUE(By.xpath("//tbody//td//div[text()='My Rating']//parent::td//div[contains(@class,'undefined smiley-ratings')]//img//following-sibling::div[@class='smiley-value']"),"My Rating Value"),
	
	/** The vs last period value. */
	VS_LAST_PERIOD_VALUE(By.xpath("//tbody//td//div[text()='Vs. Last Period']//parent::td//div[contains(@class,'rating smiley-ratings')]//img//following-sibling::div[@class='rating-value']"),"VS Last Period Value"),
	
	/** The vs last period green symbol. */
	VS_LAST_PERIOD_GREEN_SYMBOL(By.xpath("//tbody//td//div[text()='Vs. Last Period']//parent::td//div[contains(@class,'rating smiley-ratings')]//img[contains(@src,'green.svg')]"),"VS Last Period Green Symbol"),
	
	/** The vs last period green symbol. */
	VS_LAST_PERIOD_RED_SYMBOL(By.xpath("//tbody//td//div[text()='Vs. Last Period']//parent::td//div[contains(@class,'rating smiley-ratings')]//img[contains(@src,'red.svg')]"),"VS Last Period Green Symbol"),
	
	/** The company rating dropdown. */
	COMPANY_RATING_DROPDOWN(By.xpath("//table//th//input[@value='Company Rating']"),"Company Rating Dropdown"),
	
	/** The company rating value. */
	COMPANY_RATING_VALUE(By.xpath("//tbody//tr//td//input[@value='Company Rating']//ancestor::div//td//div[contains(@class,'undefined smiley-ratings')]//following::div[contains(@class,'undefined smiley-ratings')]//img//following-sibling::div[@class='smiley-value']"),"Company Rating Value"),
	
	/** The my company rating value. */
	MY_COMPANY_RATING_VALUE(By.xpath("//tbody//td//div[text()='My Rating vs. Company']//parent::td//div[contains(@class,'rating smiley-ratings')]//img//following-sibling::div[@class='rating-value']"),"My Company Rating Value"),
	
	/** The my company rating green symbol. */
	MY_COMPANY_RATING_GREEN_SYMBOL(By.xpath("//tbody//td//div[text()='My Rating vs. Company']//parent::td//div[contains(@class,'rating smiley-ratings')]//img[contains(@src,'green.svg')]"),"My company Rating Green symbol"),
	
	/** The my company rating green symbol. */
	MY_COMPANY_RATING_RED_SYMBOL(By.xpath("//tbody//td//div[text()='My Rating vs. Company']//parent::td//div[contains(@class,'rating smiley-ratings')]//img[contains(@src,'red.svg')]"),"My company Rating Green symbol"),
	
	/** The recent comments content. */
	RECENT_COMMENTS_CONTENT(By.xpath("//div[@class='mt-20 col-lg-6 col-12']//section[contains(@class,'non-psp-card__title')]//img[@class='title-img']//following-sibling::h3[text()='Recent Comments']"),"Recent Comments Content"),
	
	/** The time of recent comments. */
	TIME_OF_RECENT_COMMENTS(By.xpath("//h3[text()='Recent Comments']//ancestor::div//div[@class='dashboard-card recent-comment card']//section//div[@class='date-time cur-pointer']"),"Time Of Recent Comment"),
	
	/** The time of recent comments field. */
	TIME_OF_RECENT_COMMENTS_FIELD("//h3[text()='Recent Comments']//ancestor::div//div[@class='dashboard-card recent-comment card']//section//div[@class='date-time cur-pointer' and contains(text(),'%s')]","Time Of Recent Comment field"),
	
	/** The location name of recentcomments. */
	LOCATION_NAME_OF_RECENTCOMMENTS(By.xpath("//h3[text()='Recent Comments']//ancestor::div//div[@class='dashboard-card recent-comment card']//section//h3[contains(@class,'loc-name')]"),"Location Name of Rcent comments"),
	
	/** The location field of recentcomments. */
	LOCATION_FIELD_OF_RECENTCOMMENTS("//h3[text()='Recent Comments']//ancestor::div//div[@class='dashboard-card recent-comment card']//section//h3[contains(@class,'loc-name') and text()='%s']","Location Field Of Recent comments"),
	
	/** The send button for recentcomments. */
	SEND_BUTTON_FOR_RECENTCOMMENTS(By.xpath("//div[@class='mt-20 col-lg-6 col-12']//div[@class='dashboard-card recent-comment card']//section[@class='comments-wrp mb-3']//img[@alt='sent']"),"Send Option for Recent Comments"),
	
	/** The recent comments sendbutton. */
	RECENT_COMMENTS_SENDBUTTON("//div[@class='mt-20 col-lg-6 col-12']//div[@class='comments-inner__wrp']//section[@class='comments-wrp mb-3']//h3[text()='Location Two Automation']//parent::aside//div//img[@alt='sent']","Recent Comments Send Button"),
	
	/** The recent comments describtion. */
	RECENT_COMMENTS_DESCRIBTION(By.xpath("//h3[text()='Recent Comments']//ancestor::div//div[@class='dashboard-card recent-comment card']//section//article[@class='desc cur-pointer' and text()]"),"Recent comment description"),
	
	/**  Recent Comments Detail View *. */
	
	RECENTLOCATION_DETAILVIEW_USER("//div[@class='dashboard-detailed__modal--scroll']//div[@class='loc-name__hldr']//span[@class='notification__loc-lbl text-dotted' and contains(text(),'%s')]","Location Name in Detailview"),
	
	/** The recentlocation detailview id. */
	RECENTLOCATION_DETAILVIEW_ID(By.xpath("//div[@class='dashboard-detailed__modal--scroll']//div[@class='loc-name__hldr']//span[@class='notification__loc-lbl']"),"Location Id Detailview"),
	
	/** The recentlocation detailview timedate. */
	RECENTLOCATION_DETAILVIEW_TIMEDATE(By.xpath("//div[@class='dashboard-detailed__modal--scroll']//div[@class='loc-name__hldr']//div[@class='notification__date fs-secondary']"),"Recent Location Time and Date in detailView"),
	
	/** The recentlocation detailview customer name. */
	RECENTLOCATION_DETAILVIEW_CUSTOMER_NAME(By.xpath("//div[@class='dashboard-detailed__modal--scroll']//div[@class='note-name-mail--wrp d-flex']//span[@class='text-dotted customer-name']"),"Recent Location Customer Name in detailview"),
	
	/** The recentlocation detailview customer id. */
	RECENTLOCATION_DETAILVIEW_CUSTOMER_ID(By.xpath("//div[@class='dashboard-detailed__modal--scroll']//div[@class='note-name-mail--wrp d-flex']//span[@class='text-dotted email']"),"Recent Location Cutomer Id DetailView"),
	
	/** The recentlocation detailview question. */
	RECENTLOCATION_DETAILVIEW_QUESTION(By.xpath("//div[@class='dashboard-detailed__modal--scroll']//table//tr//th[text()='Questions']//ancestor::div//tbody//td//div[text()='Questions']//following-sibling::div//div[@class='question']"),"Recent Location Questions"),
	
	/** The recentlocation detailview rating. */
	RECENTLOCATION_DETAILVIEW_RATING(By.xpath("//div[@class='dashboard-detailed__modal--scroll']//tbody//td//div[text()='Rating']//following-sibling::div//img[@class='smiley-icon']//following-sibling::div[@class='score-lbl']"),"Recent Location Rating DetailView"),
	
	/** The recentlocation detailview close. */
	RECENTLOCATION_DETAILVIEW_CLOSE(By.xpath("//div[@class='p-0 container-fluid']//img[@alt='close']"),"Recent Location close"),
	
	/** The recentsend detailview locationname. */
	RECENTSEND_DETAILVIEW_LOCATIONNAME("//span[text()='Recent Comments']//ancestor::div//h4[@class='recent-body-title' and contains(text(),'%s')]","Recent Send Detailview Lcation Name"),
	
	/** The recentsend detailview timedate. */
	RECENTSEND_DETAILVIEW_TIMEDATE(By.xpath("//span[text()='Recent Comments']//ancestor::div//p[@class='recent-body-date']"),"Recent Send Detailview Time And Date"),
	
	/** The recentsend detailview description. */
	RECENTSEND_DETAILVIEW_DESCRIPTION(By.xpath("//span[text()='Recent Comments']//ancestor::div//div[@class='non-psp-dashboard-body-parg']//p[@class='text-break parg__text']"),"Recent Send Detailview Description"),
	
	/** The recentsend detailview description field. */
	RECENTSEND_DETAILVIEW_DESCRIPTION_FIELD("//span[text()='Recent Comments']//ancestor::div//div[@class='non-psp-dashboard-body-parg']//p[@class='text-break parg__text' and text()='%s']","Recent Send Description Field"),
	
	/** The recentsend detailview message area. */
	RECENTSEND_DETAILVIEW_MESSAGE_AREA(By.xpath("//div[@class='inner-modal__wrp']//span[text()='Recent Comments']//ancestor::div//div[@class='dash-recent-textfield pt-20']//h4//following-sibling::div[contains(@class,'textfield-grp')]//textarea"),"Recent Send Message Area"),	
	
	/** The recentsend detailview cancel button. */
	RECENTSEND_DETAILVIEW_CANCEL_BUTTON(By.xpath("//div[@class='inner-modal__wrp']//span[text()='Recent Comments']//ancestor::div//div[@class='modal-footer']//button[text()='Cancel']"),"Recent Detailview Cancel button"),
	
	/** The recentsend detailview send button. */
	RECENTSEND_DETAILVIEW_SEND_BUTTON(By.xpath("//div[@class='inner-modal__wrp']//span[text()='Recent Comments']//ancestor::div//div[@class='modal-footer']//button[text()='Send']"),"RecentSend DetailView Send Button"),
	
    /** The email send successfully popup. */
    EMAIL_SEND_SUCCESSFULLY_POPUP(By.xpath("//div[contains(@class,'toast-body')]//span[@class='text-white fs-secondary message' and text()='Email sent successfully.']//following-sibling::button"),"Email Send Successfully"),	
	
    /** The recentsend detailview previousarrow. */
    RECENTSEND_DETAILVIEW_PREVIOUSARROW(By.xpath("//div[@class='inner-modal__wrp']//span[text()='Recent Comments']//ancestor::div//div[@class='non-psp-dashboard-header']//img[@alt='left-arrow']"),"Recent Send Detailview LeftArrow"),
	
	/** The recentsend detailview close. */
	RECENTSEND_DETAILVIEW_CLOSE(By.xpath("//div[@class='inner-modal__wrp']//span[text()='Recent Comments']//ancestor::div//div[@class='non-psp-dashboard-header']//img[@alt='close-icon']"),"Recent Send Close"),
	
	/** The recentsend detailview nextarrow. */
	RECENTSEND_DETAILVIEW_NEXTARROW(By.xpath("//div[@class='inner-modal__wrp']//span[text()='Recent Comments']//ancestor::div//div[@class='non-psp-dashboard-header']//img[@alt='right-arrow']"),"Recent Send Detailview RightArrow"),
	
	NO_CUSTOMER_CONTACT_REQUEST(By.xpath("//div[@class='no-data-to__show' and text()='No Customer Contact Requests Found.']"),"No Customer Contact Request"),
	
	/** The customer contact request. */
	CUSTOMER_CONTACT_REQUEST(By.xpath("//div[@class='mt-20 col-lg-6 col-12']//section[contains(@class,'non-psp-card__title')]//img[@class='title-img']//following-sibling::h3[text()='Customer Contact Requests']"),"Customer Contact Request"),
	
	/** The location name of customer contacts. */
	LOCATION_NAME_OF_CUSTOMER_CONTACTS(By.xpath("//h3[text()='Customer Contact Requests']//ancestor::div//div[@class='dashboard-card notification card']//span[contains(@class,'loc-name')]"),"Location Name Of Customer Contacts"),
	
	/** The location field of customercontacts. */
	LOCATION_FIELD_OF_CUSTOMERCONTACTS("//h3[text()='Customer Contact Requests']//ancestor::div//div[@class='dashboard-card notification card']//span[contains(@class,'loc-name') and text()='%s']","Location field Customer Contacts "),
	
	/** The time of customer contacts. */
	TIME_OF_CUSTOMER_CONTACTS(By.xpath("//h3[text()='Customer Contact Requests']//ancestor::div//div[@class='dashboard-card notification card']//section//following-sibling::div[@class='date-time']"),"Time of Customer Contacts"),
	
	/** The username of customer contacts. */
	USERNAME_OF_CUSTOMER_CONTACTS(By.xpath("//h3[text()='Customer Contact Requests']//ancestor::div//div[@class='dashboard-card notification card']//section//span[@class='customer-name text-dotted']"),"User Name OF Customer Contacts"),
	
	/** The useremail of customer contacts. */
	USEREMAIL_OF_CUSTOMER_CONTACTS(By.xpath("//h3[text()='Customer Contact Requests']//ancestor::div//div[@class='dashboard-card notification card']//section//span[@class='customer-name text-dotted']//parent::div//following-sibling::div[@class='customer-mail']"),"User Email Of Customer Contacts"),
	
	/** The comment of customer contacts. */
	COMMENT_OF_CUSTOMER_CONTACTS(By.xpath("//h3[text()='Customer Contact Requests']//ancestor::div//section[@class='article ps-0']//article[@class='desc cur-pointer']//div[text()]"),"Comment Of Customer contact"),
	
	/** The resolve button of customer contacts. */
	RESOLVE_BUTTON_OF_CUSTOMER_CONTACTS(By.xpath("//h3[text()='Customer Contact Requests']//ancestor::div//div[@class='dashboard-card notification card']//section//button[text()='Resolve']"),"Resolve Buttons"),
	
	/** The total value of customers contacts. */
	TOTAL_VALUE_OF_CUSTOMERS_CONTACTS(By.xpath("//h3[text()='Customer Contact Requests']//ancestor::div//section[contains(@class,'tile-card__wrp')]//div[text()='Total']//following-sibling::div[@class='value']"),"Total Value Of Customer Contacts"),
	
	/** The avg respond time customer contacts. */
	AVG_RESPOND_TIME_CUSTOMER_CONTACTS(By.xpath("//h3[text()='Customer Contact Requests']//ancestor::div//section[contains(@class,'tile-card__wrp')]//div[text()='Avg. Response Time']//following-sibling::div[@class='value']"),"Avg Respond Time Customer Contacts"),
	
	/** The unresolved value customer contacts. */
	UNRESOLVED_VALUE_CUSTOMER_CONTACTS(By.xpath("//h3[text()='Customer Contact Requests']//ancestor::div//section[contains(@class,'tile-card__wrp')]//div[text()='Unresolved']//following-sibling::div[@class='value']"),"Unresolved Value for Customer Contacts"),
	
	/** The unresolved count value. */
	UNRESOLVED_COUNT_VALUE(By.xpath("//h3[text()='Customer Contact Requests']//ancestor::div//section[contains(@class,'tile-card__wrp')]//div[text()='Unresolved']//parent::div//span[@class='unresolve__value']"),"Unresolved Count"),
	
	/** The unresolved subcount value. */
	UNRESOLVED_SUBCOUNT_VALUE(By.xpath("//h3[text()='Customer Contact Requests']//ancestor::div//section[contains(@class,'tile-card__wrp')]//div[text()='Unresolved']//following-sibling::div[@class='value']//span[@class='unresolve__subvalue']"),"Unresolved Sub Count Value"),
	
	/** The resolved customer contacts. */
	RESOLVED_COUNTVALUE(By.xpath("//h3[text()='Customer Contact Requests']//ancestor::div//section[contains(@class,'tile-card__wrp')]//div[text()='Resolved']//following-sibling::div[@class='value']"),"Resolved Customer contacts"),
	
	/** The customer contact pagepicker. */
	CUSTOMER_CONTACT_PAGEPICKER(By.xpath("//h3[text()='Customer Contact Requests']//ancestor::div//div[@class='dashboard-card focus-area card']//li[@class='ps-3 active page-item']"),"Customer Contact page Picker"),
	
	CUSTOMER_CONTACTS_DESCRIPTION_FIELD("//h3[text()='Customer Contact Requests']//parent::aside//parent::section//following-sibling::div//article//div[text()='%s']","Customer Contacts Resolve Description"),
	
	/** Customer Contacts DetailView *. */
	CUSTOMERRESOLVE_COMMENTS_HERE(By.xpath("//div[contains(@class,'modal-container--wrp')]//span[text()='How was it resolved ?']//following-sibling::textarea[@class='resolved-txt']"),"Customer Comments Resolve here Type Text"),
	
	/** The customerresolve name field. */
	CUSTOMERRESOLVE_NAME_FIELD("//div[@class='dashboard-detailed__modal--scroll']//div[@class='loc-name__hldr']//span[contains(@class,'text-dotted') and text()='%s']","Customer Resolve  Name"),
	
	/** The customerresolve date and time. */
	CUSTOMERRESOLVE_DATE_AND_TIME("//div[@class='dashboard-detailed__modal--scroll']//div[@class='loc-name__hldr']//span[text()='%s']//parent::div//following-sibling::div[contains(@class,'notification__date fs-secondary')]","Customer Resove Date and Time Field"),
	
	/** The customerresolve username field. */
	CUSTOMERRESOLVE_USERNAME_FIELD("//div[@class='dashboard-detailed__modal--scroll']//span[@class='text-dotted customer-name' and text()='%s']","Customer Resolve User Name Field"),
	
	/** The customerresolve useremail field. */
	CUSTOMERRESOLVE_USEREMAIL_FIELD("//div[@class='dashboard-detailed__modal--scroll']//span[@class='text-dotted email' and text()='%s']","Customer User Email Id"),
	
	/** The customerresolve descripton. */
	CUSTOMERRESOLVE_DESCRIPTON(By.xpath("//div[@class='dashboard-detailed__modal--scroll']//div[@class='notification-detailed-view']//article//div[text()]"),"Customer Description"),
	
	/** The customerresolve question. */
	CUSTOMERRESOLVE_QUESTION(By.xpath("//table//th[text()='Questions']//following-sibling::th[text()='Rating']//ancestor::div//div[@class='dashboard-detailed__modal--scroll']//div[contains(@class,'question-wrp')]//span[text()='Q1']//following-sibling::div[contains(text(),'How')]"),"Customer Resolve Question"),
	
	/** The customerresolve rating. */
	CUSTOMERRESOLVE_RATING(By.xpath("//div[@class='dashboard-detailed__modal--scroll']//tbody//td//div[text()='Rating']//following-sibling::div[@class='d-flex align-items-center']"),"Customer Resolve Rating View"),
	
	/** The customerresolve pagelink count. */
	CUSTOMERRESOLVE_PAGELINK_COUNT(By.xpath("//h3[text()='Customer Contact Requests']//ancestor::div//div[@class='dashboard-card notification card']//li//span[@class='page-link']"),"Customer Resolve Page Link Count"),
	
	CUSTOMERRESOLVE_PAGELINK_NEXTBUTTON(By.xpath("//h3[text()='Customer Contact Requests']//parent::aside//parent::section//parent::div//following-sibling::ul//*[local-name()='svg' and @data-testid='ChevronRightIcon']"),"Customer Contact Resolve Next Button"),
	
	/** The customerresolve nextarrow. */
	CUSTOMERRESOLVE_NEXTARROW(By.xpath("//div[@class='inner-modal__wrp']//div[@class='p-0 container-fluid']//img[contains(@class,'nav-next__icon  cur-pointer')]"),"Customer Resolve Next Arrow"),
	
	/** The customerresolve previousarrow. */
	CUSTOMERRESOLVE_PREVIOUSARROW(By.xpath("//div[@class='inner-modal__wrp']//div[@class='p-0 container-fluid']//img[contains(@class,'nav-prev__icon cur-pointer')]"),"Customer Resolve Previous Arrow"),
	
	/** The customerresolve clear inactive. */
	CUSTOMERRESOLVE_CLEAR_INACTIVE(By.xpath("//div[@class='action-btn__wrp']//button[contains(@class,'disabled') and text()='Clear']"),"Customer Resolve Inactive"),
	
	/** The customerresolve clear active. */
	CUSTOMERRESOLVE_CLEAR_ACTIVE(By.xpath("//div[@class='action-btn__wrp']//button[contains(@class,'disabled') and text()='Clear']"),"//div[@class='action-btn__wrp']//button[contains(@class,'clear-btn') and text()='Clear']"),
	
	/** The custome rresolve button inactive. */
	CUSTOME_RRESOLVE_BUTTON_INACTIVE(By.xpath("//div[@class='action-btn__wrp']//button[contains(@class,'disabled') and text()='Resolve']"),""),
	
	/** The custome rresolve button active. */
	CUSTOME_RRESOLVE_BUTTON_ACTIVE(By.xpath("//div[@class='action-btn__wrp']//button[contains(@class,'resolved-btn  btn btn-primary') and text()='Resolve']"),"Customer Resolve Button Active"),
	
	/** The customer resolve close button. */
	CUSTOMER_RESOLVE_CLOSE_BUTTON(By.xpath("//div[@class='inner-modal__wrp']//img[@class='non-psp-mod-close cur-pointer']"),""),
	
	/** The resolve sent successfully popup. */
	RESOLVE_SENT_SUCCESSFULLY_POPUP(By.xpath("//div[contains(@class,'toast-body')]//span[text()='Survey updated successfully.']"),"Resolve sent Successfully"),
	
	
	/** The reviews rating content. */
	REVIEWS_RATING_CONTENT(By.xpath("//div//section[contains(@class,'non-psp-card__title')]//img[@class='title-img']//following-sibling::h3[text()='Reviews Rating']"),"Reviews Rating Content"),
	
	/** The take me to reviews button. */
	TAKE_ME_TO_REVIEWS_BUTTON(By.xpath("//div[@class='dashboard-card reputation card']//section//button[text()='Take me to review analytics']"),"Take me to Reviews Analytics"),
	
	/** The reviews all button. */
	REVIEWS_ALL_BUTTON(By.xpath("//div[@class='dashboard-card reputation card']//section//div[contains(@class,'social-media')]//img[@alt='all']"),"All Button"),
	
	/** The reviews all button active. */
	REVIEWS_ALL_BUTTON_ACTIVE(By.xpath("//div[@class='dashboard-card reputation card']//section//div[contains(@class,'social-media')]//img[@alt='all' and @class='active']"),"All button Active"),
	
	/** The reviews yelp button. */
	REVIEWS_YELP_BUTTON(By.xpath("//div[@class='dashboard-card reputation card']//section//div[contains(@class,'social-media')]//img[@alt='yelp']"),"Reviews Yelp button"),
	
	/** The reviews yelp button active. */
	REVIEWS_YELP_BUTTON_ACTIVE(By.xpath("//div[@class='dashboard-card reputation card']//section//div[contains(@class,'social-media')]//img[@alt='yelp' and @class='active']"),"Reviews Yelp Button Active"),
	
	/** The reviews facebook button. */
	REVIEWS_FACEBOOK_BUTTON(By.xpath("//div[@class='dashboard-card reputation card']//section//div[contains(@class,'social-media')]//img[@alt='facebook']"),"Reviews Facebook Button"),
	
	/** The reviews facebook button active. */
	REVIEWS_FACEBOOK_BUTTON_ACTIVE(By.xpath("//div[@class='dashboard-card reputation card']//section//div[contains(@class,'social-media')]//img[@alt='facebook' and @class='active']"),"Reviews Facebook Button Active"),
	
	/** The reviews google button. */
	REVIEWS_GOOGLE_BUTTON(By.xpath("//div[@class='dashboard-card reputation card']//section//div[contains(@class,'social-media')]//img[@alt='google']"),"Reviews Google button"),
	
	/** The reviews google button active. */
	REVIEWS_GOOGLE_BUTTON_ACTIVE(By.xpath("//div[@class='dashboard-card reputation card']//section//div[contains(@class,'social-media')]//img[@alt='google' and @class='active']"),"Reviews Google button Active"),
	
	/** The reviews rating chart. */
	REVIEWS_RATING_CHART(By.xpath("//h3[text()='Reviews Rating']//ancestor::div//section[@class='chart-hldr']//div[@class='highcharts-container ']"),"Reviews Rating Chart"),
	
	
	/** The focus area content. */
	FOCUS_AREA_CONTENT(By.xpath("//div[@class='mt-20 col-lg-6 col-12']//section[contains(@class,'non-psp-card__title')]//img[@class='title-img']//following-sibling::h3[text()='Focus Area']"),"Focus Area Content"),
	
	/** The from and to date focus. */
	FROM_AND_TO_DATE_FOCUS(By.xpath("//h3[text()='Focus Area']//ancestor::div//div[@class='dashboard-card focus-area card']//div[@class='date-time']"),"From And To date of focus Area"),
	
	/** The focus area text content. */
	FOCUS_AREA_TEXT_CONTENT(By.xpath("//h3[text()='Focus Area']//ancestor::div//div[@class='dashboard-card focus-area card']//article[text()]"),"Focus Area Text Content"),
	
	/** The focus area smiley rating. */
	FOCUS_AREA_SMILEY_RATING(By.xpath("//h3[text()='Focus Area']//ancestor::div//div[@class='dashboard-card focus-area card']//aside[contains(@class,'d-flex align-items-center')]"),"Focus Area Smiley Rating"),
	
	/** The focus area smiey value. */
	FOCUS_AREA_SMIEY_VALUE(By.xpath("//div[@class='dashboard-card focus-area card']//aside[contains(@class,'d-flex align-items')]//img//following-sibling::span[@class='smile-value']"),"Focus Area Smiley Value"),
	
	/** The focus area rating value. */
	FOCUS_AREA_RATING_VALUE(By.xpath("//div[@class='dashboard-card focus-area card']//aside[contains(@class,'d-flex align-items')]//img//following-sibling::span[@class='value']"),"Focus Area Rating Value"),
	
	/** The focus area days. */
	FOCUS_AREA_DAYS(By.xpath("//h3[text()='Focus Area']//ancestor::div//div[@class='dashboard-card focus-area card']//section[@class='circular-progress__wrp d-flex justify-content-center']"),"Focus Area Days"),
	
	/** The focus area pagepicker active. */
	FOCUS_AREA_PAGEPICKER_ACTIVE(By.xpath("//h3[text()='Focus Area']//ancestor::div//div[@class='dashboard-card focus-area card']//li[@class='ps-3 active page-item']"),"Focus Area Page Picker Active"),
	
	/** The focusarea day active. */
	FOCUSAREA_DAY_ACTIVE(By.xpath("//*[local-name()='svg' and @class='CircularProgressbar cur-pointer']//*[@class='CircularProgressbar-text']"),"Focus Area Days Active"),
	
	/** The focusarea day detailview dates. */
	FOCUSAREA_DAY_DETAILVIEW_DATES(By.xpath("//div[@class='fa-mod-loc--wrp']//h3[text()='Focus Area']//ancestor::div//div[@class='modal-body']//div[@class='fa-mod-date']"),"Focus Area Day Detailview Date"),
	
	/** The focusarea day detailview question. */
	FOCUSAREA_DAY_DETAILVIEW_QUESTION(By.xpath("//div[@class='fa-mod-loc--wrp']//h3[text()='Focus Area']//ancestor::div//div[@class='modal-body']//div[@class='fa-mod-question']"),"Focus Area Day Detail View Questions"),
	
	/** The focusarea day detaiview smileyvalue. */
	FOCUSAREA_DAY_DETAIVIEW_SMILEYVALUE(By.xpath("//div[@class='fa-mod-loc--wrp']//h3[text()='Focus Area']//ancestor::div//div[@class='modal-body']//div[contains(@class,'smiley-ratings')]//div[@class='smiley-value']"),"Focus Area Smiley Value"),
	
	/** The focusarea day detailview ratingvalue. */
	FOCUSAREA_DAY_DETAILVIEW_RATINGVALUE(By.xpath("//div[@class='fa-mod-loc--wrp']//h3[text()='Focus Area']//ancestor::div//div[@class='modal-body']//div[contains(@class,'smiley-ratings')]//div[@class='rating-value']"),"Focus Area Rating Value"),
	
	/** The focusarea day detailview table. */
	FOCUSAREA_DAY_DETAILVIEW_TABLE(By.xpath("//h3[text()='Focus Area']//ancestor::div//div[@class='modal-body']//div[@class='circular-progress-wrp']//parent::div//div[@class='fa-tooltip']//tbody"),"Focus Area Table View"),
	
	/** The focusarea day detailview close. */
	FOCUSAREA_DAY_DETAILVIEW_CLOSE(By.xpath("//div[@class='modal-body']//div[@class='mod-close__icon cur-pointer']"),"Focus Area Detailview Close"),	
	
	/** The focusarea detailview activeday field. */
	FOCUSAREA_DETAILVIEW_ACTIVEDAY_PINKFIELD("//div[@class='circular-progress-wrp']//div[@class='txt-label pink-variant-one-text' and text()='%s']","Focus Area Active Pink Day Field"),
	
	/** The focusarea detailview activeday yellowfield. */
	FOCUSAREA_DETAILVIEW_ACTIVEDAY_YELLOWFIELD("//div[@class='circular-progress-wrp']//div[@class='txt-label yellow-variant-two-text' and text()='%s']","Focus Area Active Yellow Field"),
	
	FOCUSAREA_DETAILVIEW_ACTIVEDAY_GREENFIELD("//div[@class='circular-progress-wrp']//div[@class='txt-label green-variant-two-text' and text()='%s']","Focus Area Active Green Field"),
	
	FOCUSAREA_DETAILVIEW_ACTIVEDAY_REDFIELD("//div[@class='circular-progress-wrp']//div[@class='txt-label red-variant-two-text' and text()='%s']","Focus Area Active Green Field"),
	
	/** The focusarea detailview inactiveday field. */
	FOCUSAREA_DETAILVIEW_INACTIVEDAY_FIELD("//div[@class='circular-progress-wrp']//div[@class='txt-label na-variant-text' and text()='%s']","Focus Area Inactive Day Field"),
	
	/** The focusarea red symbol. */
	FOCUSAREA_RED_SYMBOL(By.xpath("//aside[contains(@class,'d-flex align-items')]//div[@class='d-flex align-items-center']//img[contains(@src,'red.svg')]"),"Focus Area Rating Red Symbol"),
	
	/** The focusarea green symbol. */
	FOCUSAREA_GREEN_SYMBOL(By.xpath("//aside[contains(@class,'d-flex align-items')]//div[@class='d-flex align-items-center']//img[contains(@src,'green.svg')]"),"Focus Area Green Symbol"),
	

	
	/** The location selector. */
	LOCATION_SELECTOR(By.xpath("//div[@class='filter-item fltr-drp']//h3[text()='Location Selector']//following-sibling::div[@class='locAction']//span[text()]"),"Location Selector Button"),
	
	/** The location selector all option. */
	LOCATION_SELECTOR_ALL_OPTION(By.xpath("//div[@class='filter-item fltr-drp']//h3[text()='Location Selector']//following-sibling::div[@class='locAction']//span[text()='All']"),"Location Selector ALl Option"),
	
	/** The clear filter inactive. */
	CLEAR_FILTER_INACTIVE(By.xpath("//div[@class='filter-item clear-filter']//div[@class='react-ripples ac-primary-box  pointer-events-none']//button"),"Clear Filter Inactive"),
	
	/** The clear filter active. */
	CLEAR_FILTER_ACTIVE(By.xpath("//div[@class='filter-item clear-filter']//div[@class='react-ripples ac-primary-box']//button"),"Clear Filter Button Active"),
	
	/** The from date. */
	FROM_DATE(By.xpath("//div[@class='react-datepicker-wrapper']//div[@class='react-datepicker__input-container']//input[@placeholder='MM/DD/YYYY']"),"From Date"),
	
	/** The to date. */
	TO_DATE(By.xpath("//div[@class='react-datepicker-wrapper']//div[@class='react-datepicker__input-container']//input[@placeholder='Most Recent']"),"To Date"),
	
    /** The date picker with zero. */
    DATE_PICKER_WITH_ZERO("//div[@class='react-datepicker__month']//div[contains(@class,'react-datepicker__day react-datepicker__day--00%s')]","Date with zero"),
    
    /** The date picker. */
    DATE_PICKER("//div[contains(@class,'react-datepicker__day--') and text()='%s' and not(@aria-disabled='true')]","Date Picker"),
    
    /** The month dropdown. */
	MONTH_DROPDOWN(By.xpath("//select[@class='react-datepicker__month-select']"), "Month drop down"),

	/** The year dropdown. */
	YEAR_DROPDOWN(By.xpath("//select[@class='react-datepicker__year-select']"), "Year drop down."),

	/** The previous month. */
	PREVIOUS_MONTH_PICKER(By.xpath("//button[contains(@class,'datepicker__navigation--previous')]"), "Previous month."),

	/** The next month. */
	NEXT_MONTH_PICKER(By.xpath("//button[contains(@class,'datepicker__navigation--next')]"), "Next month."),

	/** The all location button. */
	ALL_LOCATION_BUTTON(By.xpath("//div[@class=' cur-pointer all-selection' and text()='All Locations']"),"All Location Button"),
	
	/** The all location active. */
	ALL_LOCATION_ACTIVE(By.xpath("//div[@class='active cur-pointer all-selection' and text()='All Locations']"),"All Location Selector Actives"),
	
    /** The location button. */
    LOCATION_BUTTON(By.xpath("//div[@class='modal-body']//div[@class='accordion']//button[@class='accordion-button collapsed' and text()='Locations  ']"),"Location Button"),
	
    /** The location selector search tab. */
    LOCATION_SELECTOR_SEARCH_TAB(By.xpath("//div[@class='non-psp-loc-search']//input[@placeholder='Search']"),"Location Selector Search Tab"),
    
    /** The location select from dropdown. */
    LOCATION_SELECT_FROM_DROPDOWN("//div[@class='accordion-collapse collapse show']//li//span[@class='lbl ' and text()='%s']","Locationn select from dropdown"),
    
    /** The location list dropdown. */
    LOCATION_LIST_DROPDOWN(By.xpath("//div[@class='accordion-collapse collapse show']//div[@class='overflow-hidden accordion-body']//ul"),"Location List Dropdown"),
    
    /** The location selector ok button. */
    LOCATION_SELECTOR_OK_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Ok']"),"Location Selector Ok"),
    
    /** The location selector cancel button. */
    LOCATION_SELECTOR_CANCEL_BUTTON(By.xpath("//div[@class='modal-footer']//button[text()='Cancel']"),"Location Selector Cancel Button"),
    
    /** The surveys tab. */
    SURVEYS_TAB(By.xpath("//li[@class='ripple']//span[text()='Surveys']"),"Surveys Tab"),
    
    /** The line chart x axis labels. */
	LINE_CHART_X_AXIS_LABELS(By.xpath("//*[@class='highcharts-root']//*[@class='highcharts-axis-labels highcharts-xaxis-labels']//*"), "Line Chart X-axis labels"),

    /** The line chart y axis verticalline. */
    LINE_CHART_Y_AXIS_VERTICALLINE(By.xpath("//*[local-name()='svg' and @aria-label]//*[name()='g' and @class='highcharts-grid highcharts-xaxis-grid']//*[name()='path']"),"Y- Axis Line Data"),
    
    /** The total platform data count. */
    TOTAL_PLATFORM_DATA_COUNT(By.xpath("//div[@class='tooltip-tile-wrp']//div[@class='chart-tlp-lbl']//span[text()='Total']/../following-sibling::span"),"Total Platform Chart Count"),

	FACEBOOK_PLATFORM_DATA_COUNT(By.xpath("//div[@class='tooltip-tile-wrp']//div[@class='chart-tlp-lbl']//span[text()='Facebook']/../following-sibling::span"),"Facebook Platform Chart Count"),

	DATE_RATING_REVIEW(By.xpath("//div[@class='tooltip-tile-wrp']//div[@class='chart-tlp-lbl']//span[text()='Facebook']/../following-sibling::span//preceding::span[@class='ra-tooltip-date' and text()]"),"Date value of Rating Review"),

	/** The day of the month. */
	DAY_OF_THE_MONTH("//div[contains(@class,'react-datepicker') and text()='%s']", "Day of the Month"),

    DATE_RANGE_FOR_WEEK(By.xpath("//div[contains(@class,'react-datepicker__day--in-range')]"),"Date Range For Week"),
    
    /** The back to top button. */
	BACK_TO_TOP_BUTTON(By.xpath("//div[@id='backToTopBtn' and @class='scrollTop scrolled-d']"),"Back to Top button"),
	
    
    ;
	/** The by locator. */
	private By byLocator;

	/** The description. */
	private String xpath, description;

	/**
	 * Instantiates a new revv SS page enum.
	 *
	 * @param byLocator the by locator
	 * @param description the description
	 */
	private RevvDashboardPageEnum(By byLocator, String description) {

		this.byLocator = byLocator;
		this.description = description;
	}

	/**
	 * Instantiates a new revv SS page enum.
	 *
	 * @param xpath the xpath
	 * @param description the description
	 */
	private RevvDashboardPageEnum(String xpath, String description) {

		this.xpath = xpath;
		this.description = description;
	}

	/**
	 * Gets the by locator.
	 *
	 * @return the by locator
	 */
	public By getByLocator() {

		return this.byLocator;
	}

	/**
	 * Gets the xpath.
	 *
	 * @return the xpath
	 */
	public String getXpath() {

		return xpath;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return this.description;
	}
}



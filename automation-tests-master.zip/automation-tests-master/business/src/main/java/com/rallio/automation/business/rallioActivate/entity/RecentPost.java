package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class RecentPost.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RecentPost {

	/** The account id. */
	private int account_id;

	/** The account image url. */
	private String account_image_url;

	/** The account name. */
	private String account_name;

	/** The account time zone. */
	private String account_time_zone;

	/** The action url. */
	private String action_url;

	/** The content. */
	private String content;

	/** The deleted from platform. */
	private boolean deleted_from_platform;

	/** The engagement. */
	private int engagement;

	/** The facebook text. */
	private String facebook_text;

	/** The scheduled for. */
	private String scheduled_for;

	/** The feed. */
	private String feed;

	/** The from. */
	private String from;

	/** The id. */
	private int id;

	/** The image url. */
	private String image_url;

	/** The is video. */
	private boolean is_video;

	/** The last activity at. */
	private String last_activity_at;

	/** The liked. */
	private boolean liked;

	/** The link. */
	private RecentPostLinks link;

	/** The originally posted at. */
	private String originally_posted_at;

	/** The photo urls. */
	private List<String> photo_urls;

	/** The post type. */
	private String post_type;

	/** The posted using rallio. */
	private boolean posted_using_rallio;

	/** The profile picture url. */
	private String profile_picture_url;

	/** The provider. */
	private String provider;

	/** The read comments count. */
	private int read_comments_count;

	/** The read replies count. */
	private int read_replies_count;

	/** The remote id. */
	private String remote_id;

	/** The replied. */
	private boolean replied;

	/** The retweeted. */
	private boolean retweeted;

	/** The summary. */
	private String summary;

	/** The total comments count. */
	private int total_comments_count;

	/** The total replies count. */
	private int total_replies_count;

	/** The type. */
	private String type;

	/** The statistics. */
	private RecentPostStatistics statistics;

	/** The stats. */
	private List<RecentPostStats> stats;

	/**
	 * Gets the account id.
	 *
	 * @return the account id
	 */
	public int getAccount_id() {

		return account_id;
	}

	/**
	 * Sets the account id.
	 *
	 * @param account_id the new account id
	 */
	public void setAccount_id(int account_id) {

		this.account_id = account_id;
	}

	/**
	 * Gets the account image url.
	 *
	 * @return the account image url
	 */
	public String getAccount_image_url() {

		return account_image_url;
	}

	/**
	 * Sets the account image url.
	 *
	 * @param account_image_url the new account image url
	 */
	public void setAccount_image_url(String account_image_url) {

		this.account_image_url = account_image_url;
	}

	/**
	 * Gets the account name.
	 *
	 * @return the account name
	 */
	public String getAccount_name() {

		return account_name;
	}

	/**
	 * Sets the account name.
	 *
	 * @param account_name the new account name
	 */
	public void setAccount_name(String account_name) {

		this.account_name = account_name;
	}

	/**
	 * Gets the account time zone.
	 *
	 * @return the account time zone
	 */
	public String getAccount_time_zone() {

		return account_time_zone;
	}

	/**
	 * Sets the account time zone.
	 *
	 * @param account_time_zone the new account time zone
	 */
	public void setAccount_time_zone(String account_time_zone) {

		this.account_time_zone = account_time_zone;
	}

	/**
	 * Gets the action url.
	 *
	 * @return the action url
	 */
	public String getAction_url() {

		return action_url;
	}

	/**
	 * Sets the action url.
	 *
	 * @param action_url the new action url
	 */
	public void setAction_url(String action_url) {

		this.action_url = action_url;
	}

	/**
	 * Gets the content.
	 *
	 * @return the content
	 */
	public String getContent() {

		return content;
	}

	/**
	 * Sets the content.
	 *
	 * @param content the new content
	 */
	public void setContent(String content) {

		this.content = content;
	}

	/**
	 * Checks if is deleted from platform.
	 *
	 * @return true, if is deleted from platform
	 */
	public boolean isDeleted_from_platform() {

		return deleted_from_platform;
	}

	/**
	 * Sets the deleted from platform.
	 *
	 * @param deleted_from_platform the new deleted from platform
	 */
	public void setDeleted_from_platform(boolean deleted_from_platform) {

		this.deleted_from_platform = deleted_from_platform;
	}

	/**
	 * Gets the engagement.
	 *
	 * @return the engagement
	 */
	public int getEngagement() {

		return engagement;
	}

	/**
	 * Sets the engagement.
	 *
	 * @param engagement the new engagement
	 */
	public void setEngagement(int engagement) {

		this.engagement = engagement;
	}

	/**
	 * Gets the facebook text.
	 *
	 * @return the facebook text
	 */
	public String getFacebook_text() {

		return facebook_text;
	}

	/**
	 * Sets the facebook text.
	 *
	 * @param facebook_text the new facebook text
	 */
	public void setFacebook_text(String facebook_text) {

		this.facebook_text = facebook_text;
	}

	/**
	 * Gets the scheduled for.
	 *
	 * @return the scheduled for
	 */
	public String getScheduled_for() {

		return scheduled_for;
	}

	/**
	 * Sets the scheduled for.
	 *
	 * @param scheduled_for the new scheduled for
	 */
	public void setScheduled_for(String scheduled_for) {

		this.scheduled_for = scheduled_for;
	}

	/**
	 * Gets the feed.
	 *
	 * @return the feed
	 */
	public String getFeed() {

		return feed;
	}

	/**
	 * Sets the feed.
	 *
	 * @param feed the new feed
	 */
	public void setFeed(String feed) {

		this.feed = feed;
	}

	/**
	 * Gets the from.
	 *
	 * @return the from
	 */
	public String getFrom() {

		return from;
	}

	/**
	 * Sets the from.
	 *
	 * @param from the new from
	 */
	public void setFrom(String from) {

		this.from = from;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/**
	 * Gets the image url.
	 *
	 * @return the image url
	 */
	public String getImage_url() {

		return image_url;
	}

	/**
	 * Sets the image url.
	 *
	 * @param image_url the new image url
	 */
	public void setImage_url(String image_url) {

		this.image_url = image_url;
	}

	/**
	 * Checks if is checks if is video.
	 *
	 * @return true, if is checks if is video
	 */
	public boolean isIs_video() {

		return is_video;
	}

	/**
	 * Sets the checks if is video.
	 *
	 * @param is_video the new checks if is video
	 */
	public void setIs_video(boolean is_video) {

		this.is_video = is_video;
	}

	/**
	 * Gets the last activity at.
	 *
	 * @return the last activity at
	 */
	public String getLast_activity_at() {

		return last_activity_at;
	}

	/**
	 * Sets the last activity at.
	 *
	 * @param last_activity_at the new last activity at
	 */
	public void setLast_activity_at(String last_activity_at) {

		this.last_activity_at = last_activity_at;
	}

	/**
	 * Checks if is liked.
	 *
	 * @return true, if is liked
	 */
	public boolean isLiked() {

		return liked;
	}

	/**
	 * Sets the liked.
	 *
	 * @param liked the new liked
	 */
	public void setLiked(boolean liked) {

		this.liked = liked;
	}

	/**
	 * Gets the link.
	 *
	 * @return the link
	 */
	public RecentPostLinks getLink() {

		return link;
	}

	/**
	 * Sets the link.
	 *
	 * @param link the new link
	 */
	public void setLink(RecentPostLinks link) {

		this.link = link;
	}

	/**
	 * Gets the originally posted at.
	 *
	 * @return the originally posted at
	 */
	public String getOriginally_posted_at() {

		return originally_posted_at;
	}

	/**
	 * Sets the originally posted at.
	 *
	 * @param originally_posted_at the new originally posted at
	 */
	public void setOriginally_posted_at(String originally_posted_at) {

		this.originally_posted_at = originally_posted_at;
	}

	/**
	 * Gets the photo urls.
	 *
	 * @return the photo urls
	 */
	public List<String> getPhoto_urls() {

		return photo_urls;
	}

	/**
	 * Sets the photo urls.
	 *
	 * @param photo_urls the new photo urls
	 */
	public void setPhoto_urls(List<String> photo_urls) {

		this.photo_urls = photo_urls;
	}

	/**
	 * Gets the post type.
	 *
	 * @return the post type
	 */
	public String getPost_type() {

		return post_type;
	}

	/**
	 * Sets the post type.
	 *
	 * @param post_type the new post type
	 */
	public void setPost_type(String post_type) {

		this.post_type = post_type;
	}

	/**
	 * Checks if is posted using rallio.
	 *
	 * @return true, if is posted using rallio
	 */
	public boolean isPosted_using_rallio() {

		return posted_using_rallio;
	}

	/**
	 * Sets the posted using rallio.
	 *
	 * @param posted_using_rallio the new posted using rallio
	 */
	public void setPosted_using_rallio(boolean posted_using_rallio) {

		this.posted_using_rallio = posted_using_rallio;
	}

	/**
	 * Gets the profile picture url.
	 *
	 * @return the profile picture url
	 */
	public String getProfile_picture_url() {

		return profile_picture_url;
	}

	/**
	 * Sets the profile picture url.
	 *
	 * @param profile_picture_url the new profile picture url
	 */
	public void setProfile_picture_url(String profile_picture_url) {

		this.profile_picture_url = profile_picture_url;
	}

	/**
	 * Gets the provider.
	 *
	 * @return the provider
	 */
	public String getProvider() {

		return provider;
	}

	/**
	 * Sets the provider.
	 *
	 * @param provider the new provider
	 */
	public void setProvider(String provider) {

		this.provider = provider;
	}

	/**
	 * Gets the read comments count.
	 *
	 * @return the read comments count
	 */
	public int getRead_comments_count() {

		return read_comments_count;
	}

	/**
	 * Sets the read comments count.
	 *
	 * @param read_comments_count the new read comments count
	 */
	public void setRead_comments_count(int read_comments_count) {

		this.read_comments_count = read_comments_count;
	}

	/**
	 * Gets the read replies count.
	 *
	 * @return the read replies count
	 */
	public int getRead_replies_count() {

		return read_replies_count;
	}

	/**
	 * Sets the read replies count.
	 *
	 * @param read_replies_count the new read replies count
	 */
	public void setRead_replies_count(int read_replies_count) {

		this.read_replies_count = read_replies_count;
	}

	/**
	 * Gets the remote id.
	 *
	 * @return the remote id
	 */
	public String getRemote_id() {

		return remote_id;
	}

	/**
	 * Sets the remote id.
	 *
	 * @param remote_id the new remote id
	 */
	public void setRemote_id(String remote_id) {

		this.remote_id = remote_id;
	}

	/**
	 * Checks if is replied.
	 *
	 * @return true, if is replied
	 */
	public boolean isReplied() {

		return replied;
	}

	/**
	 * Sets the replied.
	 *
	 * @param replied the new replied
	 */
	public void setReplied(boolean replied) {

		this.replied = replied;
	}

	/**
	 * Checks if is retweeted.
	 *
	 * @return true, if is retweeted
	 */
	public boolean isRetweeted() {

		return retweeted;
	}

	/**
	 * Sets the retweeted.
	 *
	 * @param retweeted the new retweeted
	 */
	public void setRetweeted(boolean retweeted) {

		this.retweeted = retweeted;
	}

	/**
	 * Gets the summary.
	 *
	 * @return the summary
	 */
	public String getSummary() {

		return summary;
	}

	/**
	 * Sets the summary.
	 *
	 * @param summary the new summary
	 */
	public void setSummary(String summary) {

		this.summary = summary;
	}

	/**
	 * Gets the total comments count.
	 *
	 * @return the total comments count
	 */
	public int getTotal_comments_count() {

		return total_comments_count;
	}

	/**
	 * Sets the total comments count.
	 *
	 * @param total_comments_count the new total comments count
	 */
	public void setTotal_comments_count(int total_comments_count) {

		this.total_comments_count = total_comments_count;
	}

	/**
	 * Gets the total replies count.
	 *
	 * @return the total replies count
	 */
	public int getTotal_replies_count() {

		return total_replies_count;
	}

	/**
	 * Sets the total replies count.
	 *
	 * @param total_replies_count the new total replies count
	 */
	public void setTotal_replies_count(int total_replies_count) {

		this.total_replies_count = total_replies_count;
	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {

		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(String type) {

		this.type = type;
	}

	/**
	 * Gets the statistics.
	 *
	 * @return the statistics
	 */
	public RecentPostStatistics getStatistics() {

		return statistics;
	}

	/**
	 * Sets the statistics.
	 *
	 * @param statistics the new statistics
	 */
	public void setStatistics(RecentPostStatistics statistics) {

		this.statistics = statistics;
	}

	/**
	 * Gets the stats.
	 *
	 * @return the stats
	 */
	public List<RecentPostStats> getStats() {

		return stats;
	}

	/**
	 * Sets the stats.
	 *
	 * @param stats the new stats
	 */
	public void setStats(List<RecentPostStats> stats) {

		this.stats = stats;
	}

}

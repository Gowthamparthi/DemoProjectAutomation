package com.rallio.automation.business.rallioLocalCenter.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class CalendarEvent.
 */
public class CalendarEvent {

	/** The address. */
	private String address;

	/** The description. */
	private String description;

	/** The end datetime. */
	private String end_datetime;

	/** The event type event. */
	private boolean event_type_event;

	/** The event type post. */
	private boolean event_type_post;

	/** The event type promotion. */
	private boolean event_type_promotion;

	/** The occurrence. */
	private CalendarEventOccurence occurrence;

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public String getAddress() {

		return address;
	}

	/**
	 * Sets the address.
	 *
	 * @param address the new address
	 */
	public void setAddress(String address) {

		this.address = address;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}

	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(String description) {

		this.description = description;
	}

	/**
	 * Gets the end datetime.
	 *
	 * @return the end datetime
	 */
	public String getEnd_datetime() {

		return end_datetime;
	}

	/**
	 * Sets the end datetime.
	 *
	 * @param end_datetime the new end datetime
	 */
	public void setEnd_datetime(String end_datetime) {

		this.end_datetime = end_datetime;
	}

	/**
	 * Checks if is event type event.
	 *
	 * @return true, if is event type event
	 */
	public boolean isEvent_type_event() {

		return event_type_event;
	}

	/**
	 * Sets the event type event.
	 *
	 * @param event_type_event the new event type event
	 */
	public void setEvent_type_event(boolean event_type_event) {

		this.event_type_event = event_type_event;
	}

	/**
	 * Checks if is event type post.
	 *
	 * @return true, if is event type post
	 */
	public boolean isEvent_type_post() {

		return event_type_post;
	}

	/**
	 * Sets the event type post.
	 *
	 * @param event_type_post the new event type post
	 */
	public void setEvent_type_post(boolean event_type_post) {

		this.event_type_post = event_type_post;
	}

	/**
	 * Checks if is event type promotion.
	 *
	 * @return true, if is event type promotion
	 */
	public boolean isEvent_type_promotion() {

		return event_type_promotion;
	}

	/**
	 * Sets the event type promotion.
	 *
	 * @param event_type_promotion the new event type promotion
	 */
	public void setEvent_type_promotion(boolean event_type_promotion) {

		this.event_type_promotion = event_type_promotion;
	}

	/**
	 * Gets the occurrence.
	 *
	 * @return the occurrence
	 */
	public CalendarEventOccurence getOccurrence() {

		return occurrence;
	}

	/**
	 * Sets the occurrence.
	 *
	 * @param occurrence the new occurrence
	 */
	public void setOccurrence(CalendarEventOccurence occurrence) {

		this.occurrence = occurrence;
	}

	/**
	 * Gets the recurrence type id.
	 *
	 * @return the recurrence type id
	 */
	public int getRecurrence_type_id() {

		return recurrence_type_id;
	}

	/**
	 * Sets the recurrence type id.
	 *
	 * @param recurrence_type_id the new recurrence type id
	 */
	public void setRecurrence_type_id(int recurrence_type_id) {

		this.recurrence_type_id = recurrence_type_id;
	}

	/**
	 * Gets the start datetime.
	 *
	 * @return the start datetime
	 */
	public String getStart_datetime() {

		return start_datetime;
	}

	/**
	 * Sets the start datetime.
	 *
	 * @param start_datetime the new start datetime
	 */
	public void setStart_datetime(String start_datetime) {

		this.start_datetime = start_datetime;
	}

	/**
	 * Gets the title.
	 *
	 * @return the title
	 */
	public String getTitle() {

		return title;
	}

	/**
	 * Sets the title.
	 *
	 * @param title the new title
	 */
	public void setTitle(String title) {

		this.title = title;
	}

	/** The recurrence type id. */
	private int recurrence_type_id;

	/** The start datetime. */
	private String start_datetime;

	/** The title. */
	private String title;

}

package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

import com.fasterxml.jackson.annotation.*;
import com.rallio.automation.common.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Franchisors.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Franchisors {

	/** The id. */
	private int id;

	/** The name. */
	private String name;

	/** The email. */
	private String email;

	/** The created at. */
	private String created_at;

	/** The auto approve franchise posts. */
	private boolean auto_approve_franchise_posts;

	/** The franchise content ratio. */
	private int franchise_content_ratio;

	/** The logo name. */
	private String logo_name;

	/** The has tracpoint api key. */
	private boolean has_tracpoint_api_key;

	/** The tracpoint api key. */
	private String tracpoint_api_key;

	/** The has tracpoint coupons. */
	private boolean has_tracpoint_coupons;

	/** The has rallio coupons. */
	private boolean has_rallio_coupons;

	/** The has coupons. */
	private boolean has_coupons;

	/** The corporate account id. */
	private String corporate_account_id;

	/** The permissions list id. */
	private int permissions_list_id;

	/** The coupon provider. */
	private String coupon_provider;

	/** The review alert ratings. */
	private List<Integer> review_alert_ratings;

	/** The detail id. */
	private int detail_id;

	/** The report logo url. */
	private String report_logo_url;

	/** The media release text. */
	private String media_release_text;

	/** The ancestor media release text. */
	private String ancestor_media_release_text;

	/** The customizable facebook link previews. */
	private boolean customizable_facebook_link_previews;

	/** The employee login. */
	private boolean employee_login;

	/** The mobile app login feature. */
	private boolean mobile_app_login_feature;

	/** The media upload feature. */
	private String media_upload_feature;

	/** The personal profiles feature. */
	private boolean personal_profiles_feature;

	/** The reviews approval feature. */
	private boolean reviews_approval_feature;

	/** The calendar scheduling feature. */
	private boolean calendar_scheduling_feature;

	/** The employee leaderboard feature. */
	private boolean employee_leaderboard_feature;

	/** The comment media assets feature. */
	private String comment_media_assets_feature;

	/** The media asset like dislike feature. */
	private String media_asset_like_dislike_feature;

	/** The gmb feature. */
	private boolean gmb_feature;

	/** The review reply template 1 star. */
	private String review_reply_template_1_star;

	/** The review reply template 2 starl. */
	private String review_reply_template_2_starl;

	/** The review reply template 3 star. */
	private String review_reply_template_3_star;

	/** The review reply template 4 star. */
	private String review_reply_template_4_star;

	/** The review reply template 5 star. */
	private String review_reply_template_5_star;

	/** The logo url. */
	private String logo_url;

	/** The logo thumbnail url. */
	private String logo_thumbnail_url;

	/** The logo cloudinary id. */
	private String logo_cloudinary_id;

	/** The child present. */
	private boolean child_present;

	/** The child count. */
	private int child_count;

	/** The descendant accounts count. */
	private int descendant_accounts_count;

	/** The latitude. */
	private String latitude;

	/** The longitude. */
	private String longitude;

	/** The address. */
	private String address;

	/** The accounts. */
	private List<AccountsList> accounts;

	/**
	 * Gets the accounts.
	 *
	 * @return the accounts
	 */
	public List<AccountsList> getAccounts() {

		return accounts;
	}

	/**
	 * Sets the accounts.
	 *
	 * @param accounts the new accounts
	 */
	public void setAccounts(List<AccountsList> accounts) {

		this.accounts = accounts;
	}

	/**
	 * Checks if is child present.
	 *
	 * @return true, if is child present
	 */
	public boolean isChild_present() {

		return child_present;
	}

	/**
	 * Sets the child present.
	 *
	 * @param child_present the new child present
	 */
	public void setChild_present(boolean child_present) {

		this.child_present = child_present;
	}

	/**
	 * Gets the child count.
	 *
	 * @return the child count
	 */
	public int getChild_count() {

		return child_count;
	}

	/**
	 * Sets the child count.
	 *
	 * @param child_count the new child count
	 */
	public void setChild_count(int child_count) {

		this.child_count = child_count;
	}

	/**
	 * Gets the descendant accounts count.
	 *
	 * @return the descendant accounts count
	 */
	public int getDescendant_accounts_count() {

		return descendant_accounts_count;
	}

	/**
	 * Sets the descendant accounts count.
	 *
	 * @param descendant_accounts_count the new descendant accounts count
	 */
	public void setDescendant_accounts_count(int descendant_accounts_count) {

		this.descendant_accounts_count = descendant_accounts_count;
	}

	/**
	 * Gets the latitude.
	 *
	 * @return the latitude
	 */
	public String getLatitude() {

		return latitude;
	}

	/**
	 * Sets the latitude.
	 *
	 * @param latitude the new latitude
	 */
	public void setLatitude(String latitude) {

		this.latitude = latitude;
	}

	/**
	 * Gets the longitude.
	 *
	 * @return the longitude
	 */
	public String getLongitude() {

		return longitude;
	}

	/**
	 * Sets the longitude.
	 *
	 * @param longitude the new longitude
	 */
	public void setLongitude(String longitude) {

		this.longitude = longitude;
	}

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public String getAddress() {

		return address;
	}

	/**
	 * Sets the address.
	 *
	 * @param address the new address
	 */
	public void setAddress(String address) {

		this.address = address;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {

		return email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {

		this.email = email;
	}

	/**
	 * Gets the created at.
	 *
	 * @return the created at
	 */
	public String getCreated_at() {

		return created_at;
	}

	/**
	 * Sets the created at.
	 *
	 * @param created_at the new created at
	 */
	public void setCreated_at(String created_at) {

		this.created_at = created_at;
	}

	/**
	 * Checks if is auto approve franchise posts.
	 *
	 * @return true, if is auto approve franchise posts
	 */
	public boolean isAuto_approve_franchise_posts() {

		return auto_approve_franchise_posts;
	}

	/**
	 * Sets the auto approve franchise posts.
	 *
	 * @param auto_approve_franchise_posts the new auto approve franchise posts
	 */
	public void setAuto_approve_franchise_posts(boolean auto_approve_franchise_posts) {

		this.auto_approve_franchise_posts = auto_approve_franchise_posts;
	}

	/**
	 * Gets the franchise content ratio.
	 *
	 * @return the franchise content ratio
	 */
	public int getFranchise_content_ratio() {

		return franchise_content_ratio;
	}

	/**
	 * Sets the franchise content ratio.
	 *
	 * @param franchise_content_ratio the new franchise content ratio
	 */
	public void setFranchise_content_ratio(int franchise_content_ratio) {

		this.franchise_content_ratio = franchise_content_ratio;
	}

	/**
	 * Gets the logo name.
	 *
	 * @return the logo name
	 */
	public String getLogo_name() {

		return logo_name;
	}

	/**
	 * Sets the logo name.
	 *
	 * @param logo_name the new logo name
	 */
	public void setLogo_name(String logo_name) {

		this.logo_name = logo_name;
	}

	/**
	 * Checks if is checks for tracpoint api key.
	 *
	 * @return true, if is checks for tracpoint api key
	 */
	public boolean isHas_tracpoint_api_key() {

		return has_tracpoint_api_key;
	}

	/**
	 * Sets the checks for tracpoint api key.
	 *
	 * @param has_tracpoint_api_key the new checks for tracpoint api key
	 */
	public void setHas_tracpoint_api_key(boolean has_tracpoint_api_key) {

		this.has_tracpoint_api_key = has_tracpoint_api_key;
	}

	/**
	 * Gets the tracpoint api key.
	 *
	 * @return the tracpoint api key
	 */
	public String getTracpoint_api_key() {

		return tracpoint_api_key;
	}

	/**
	 * Sets the tracpoint api key.
	 *
	 * @param tracpoint_api_key the new tracpoint api key
	 */
	public void setTracpoint_api_key(String tracpoint_api_key) {

		this.tracpoint_api_key = tracpoint_api_key;
	}

	/**
	 * Checks if is checks for tracpoint coupons.
	 *
	 * @return true, if is checks for tracpoint coupons
	 */
	public boolean isHas_tracpoint_coupons() {

		return has_tracpoint_coupons;
	}

	/**
	 * Sets the checks for tracpoint coupons.
	 *
	 * @param has_tracpoint_coupons the new checks for tracpoint coupons
	 */
	public void setHas_tracpoint_coupons(boolean has_tracpoint_coupons) {

		this.has_tracpoint_coupons = has_tracpoint_coupons;
	}

	/**
	 * Checks if is checks for rallio coupons.
	 *
	 * @return true, if is checks for rallio coupons
	 */
	public boolean isHas_rallio_coupons() {

		return has_rallio_coupons;
	}

	/**
	 * Sets the checks for rallio coupons.
	 *
	 * @param has_rallio_coupons the new checks for rallio coupons
	 */
	public void setHas_rallio_coupons(boolean has_rallio_coupons) {

		this.has_rallio_coupons = has_rallio_coupons;
	}

	/**
	 * Checks if is checks for coupons.
	 *
	 * @return true, if is checks for coupons
	 */
	public boolean isHas_coupons() {

		return has_coupons;
	}

	/**
	 * Sets the checks for coupons.
	 *
	 * @param has_coupons the new checks for coupons
	 */
	public void setHas_coupons(boolean has_coupons) {

		this.has_coupons = has_coupons;
	}

	/**
	 * Gets the corporate account id.
	 *
	 * @return the corporate account id
	 */
	public String getCorporate_account_id() {

		return corporate_account_id;
	}

	/**
	 * Sets the corporate account id.
	 *
	 * @param corporate_account_id the new corporate account id
	 */
	public void setCorporate_account_id(String corporate_account_id) {

		this.corporate_account_id = corporate_account_id;
	}

	/**
	 * Gets the permissions list id.
	 *
	 * @return the permissions list id
	 */
	public int getPermissions_list_id() {

		return permissions_list_id;
	}

	/**
	 * Sets the permissions list id.
	 *
	 * @param permissions_list_id the new permissions list id
	 */
	public void setPermissions_list_id(int permissions_list_id) {

		this.permissions_list_id = permissions_list_id;
	}

	/**
	 * Gets the coupon provider.
	 *
	 * @return the coupon provider
	 */
	public String getCoupon_provider() {

		return coupon_provider;
	}

	/**
	 * Sets the coupon provider.
	 *
	 * @param coupon_provider the new coupon provider
	 */
	public void setCoupon_provider(String coupon_provider) {

		this.coupon_provider = coupon_provider;
	}

	/**
	 * Gets the review alert ratings.
	 *
	 * @return the review alert ratings
	 */
	public List<Integer> getReview_alert_ratings() {

		return review_alert_ratings;
	}

	/**
	 * Sets the review alert ratings.
	 *
	 * @param review_alert_ratings the new review alert ratings
	 */
	public void setReview_alert_ratings(List<Integer> review_alert_ratings) {

		this.review_alert_ratings = review_alert_ratings;
	}

	/**
	 * Gets the detail id.
	 *
	 * @return the detail id
	 */
	public int getDetail_id() {

		return detail_id;
	}

	/**
	 * Sets the detail id.
	 *
	 * @param detail_id the new detail id
	 */
	public void setDetail_id(int detail_id) {

		this.detail_id = detail_id;
	}

	/**
	 * Gets the report logo url.
	 *
	 * @return the report logo url
	 */
	public String getReport_logo_url() {

		return report_logo_url;
	}

	/**
	 * Sets the report logo url.
	 *
	 * @param report_logo_url the new report logo url
	 */
	public void setReport_logo_url(String report_logo_url) {

		this.report_logo_url = report_logo_url;
	}

	/**
	 * Gets the media release text.
	 *
	 * @return the media release text
	 */
	public String getMedia_release_text() {

		return media_release_text;
	}

	/**
	 * Sets the media release text.
	 *
	 * @param media_release_text the new media release text
	 */
	public void setMedia_release_text(String media_release_text) {

		this.media_release_text = media_release_text;
	}

	/**
	 * Gets the ancestor media release text.
	 *
	 * @return the ancestor media release text
	 */
	public String getAncestor_media_release_text() {

		return ancestor_media_release_text;
	}

	/**
	 * Sets the ancestor media release text.
	 *
	 * @param ancestor_media_release_text the new ancestor media release text
	 */
	public void setAncestor_media_release_text(String ancestor_media_release_text) {

		this.ancestor_media_release_text = ancestor_media_release_text;
	}

	/**
	 * Checks if is customizable facebook link previews.
	 *
	 * @return true, if is customizable facebook link previews
	 */
	public boolean isCustomizable_facebook_link_previews() {

		return customizable_facebook_link_previews;
	}

	/**
	 * Sets the customizable facebook link previews.
	 *
	 * @param customizable_facebook_link_previews the new customizable facebook
	 *            link previews
	 */
	public void setCustomizable_facebook_link_previews(boolean customizable_facebook_link_previews) {

		this.customizable_facebook_link_previews = customizable_facebook_link_previews;
	}

	/**
	 * Checks if is employee login.
	 *
	 * @return true, if is employee login
	 */
	public boolean isEmployee_login() {

		return employee_login;
	}

	/**
	 * Sets the employee login.
	 *
	 * @param employee_login the new employee login
	 */
	public void setEmployee_login(boolean employee_login) {

		this.employee_login = employee_login;
	}

	/**
	 * Checks if is mobile app login feature.
	 *
	 * @return true, if is mobile app login feature
	 */
	public boolean isMobile_app_login_feature() {

		return mobile_app_login_feature;
	}

	/**
	 * Sets the mobile app login feature.
	 *
	 * @param mobile_app_login_feature the new mobile app login feature
	 */
	public void setMobile_app_login_feature(boolean mobile_app_login_feature) {

		this.mobile_app_login_feature = mobile_app_login_feature;
	}

	/**
	 * Gets the media upload feature.
	 *
	 * @return the media upload feature
	 */
	public String getMedia_upload_feature() {

		return media_upload_feature;
	}

	/**
	 * Sets the media upload feature.
	 *
	 * @param media_upload_feature the new media upload feature
	 */
	public void setMedia_upload_feature(String media_upload_feature) {

		this.media_upload_feature = media_upload_feature;
	}

	/**
	 * Checks if is personal profiles feature.
	 *
	 * @return true, if is personal profiles feature
	 */
	public boolean isPersonal_profiles_feature() {

		return personal_profiles_feature;
	}

	/**
	 * Sets the personal profiles feature.
	 *
	 * @param personal_profiles_feature the new personal profiles feature
	 */
	public void setPersonal_profiles_feature(boolean personal_profiles_feature) {

		this.personal_profiles_feature = personal_profiles_feature;
	}

	/**
	 * Checks if is reviews approval feature.
	 *
	 * @return true, if is reviews approval feature
	 */
	public boolean isReviews_approval_feature() {

		return reviews_approval_feature;
	}

	/**
	 * Sets the reviews approval feature.
	 *
	 * @param reviews_approval_feature the new reviews approval feature
	 */
	public void setReviews_approval_feature(boolean reviews_approval_feature) {

		this.reviews_approval_feature = reviews_approval_feature;
	}

	/**
	 * Checks if is calendar scheduling feature.
	 *
	 * @return true, if is calendar scheduling feature
	 */
	public boolean isCalendar_scheduling_feature() {

		return calendar_scheduling_feature;
	}

	/**
	 * Sets the calendar scheduling feature.
	 *
	 * @param calendar_scheduling_feature the new calendar scheduling feature
	 */
	public void setCalendar_scheduling_feature(boolean calendar_scheduling_feature) {

		this.calendar_scheduling_feature = calendar_scheduling_feature;
	}

	/**
	 * Checks if is employee leaderboard feature.
	 *
	 * @return true, if is employee leaderboard feature
	 */
	public boolean isEmployee_leaderboard_feature() {

		return employee_leaderboard_feature;
	}

	/**
	 * Sets the employee leaderboard feature.
	 *
	 * @param employee_leaderboard_feature the new employee leaderboard feature
	 */
	public void setEmployee_leaderboard_feature(boolean employee_leaderboard_feature) {

		this.employee_leaderboard_feature = employee_leaderboard_feature;
	}

	/**
	 * Gets the comment media assets feature.
	 *
	 * @return the comment media assets feature
	 */
	public String getComment_media_assets_feature() {

		return comment_media_assets_feature;
	}

	/**
	 * Sets the comment media assets feature.
	 *
	 * @param comment_media_assets_feature the new comment media assets feature
	 */
	public void setComment_media_assets_feature(String comment_media_assets_feature) {

		this.comment_media_assets_feature = comment_media_assets_feature;
	}

	/**
	 * Gets the media asset like dislike feature.
	 *
	 * @return the media asset like dislike feature
	 */
	public String getMedia_asset_like_dislike_feature() {

		return media_asset_like_dislike_feature;
	}

	/**
	 * Sets the media asset like dislike feature.
	 *
	 * @param media_asset_like_dislike_feature the new media asset like dislike
	 *            feature
	 */
	public void setMedia_asset_like_dislike_feature(String media_asset_like_dislike_feature) {

		this.media_asset_like_dislike_feature = media_asset_like_dislike_feature;
	}

	/**
	 * Checks if is gmb feature.
	 *
	 * @return true, if is gmb feature
	 */
	public boolean isGmb_feature() {

		return gmb_feature;
	}

	/**
	 * Sets the gmb feature.
	 *
	 * @param gmb_feature the new gmb feature
	 */
	public void setGmb_feature(boolean gmb_feature) {

		this.gmb_feature = gmb_feature;
	}

	/**
	 * Gets the review reply template 1 star.
	 *
	 * @return the review reply template 1 star
	 */
	public String getReview_reply_template_1_star() {

		return review_reply_template_1_star;
	}

	/**
	 * Sets the review reply template 1 star.
	 *
	 * @param review_reply_template_1_star the new review reply template 1 star
	 */
	public void setReview_reply_template_1_star(String review_reply_template_1_star) {

		this.review_reply_template_1_star = review_reply_template_1_star;
	}

	/**
	 * Gets the review reply template 2 starl.
	 *
	 * @return the review reply template 2 starl
	 */
	public String getReview_reply_template_2_starl() {

		return review_reply_template_2_starl;
	}

	/**
	 * Sets the review reply template 2 starl.
	 *
	 * @param review_reply_template_2_starl the new review reply template 2
	 *            starl
	 */
	public void setReview_reply_template_2_starl(String review_reply_template_2_starl) {

		this.review_reply_template_2_starl = review_reply_template_2_starl;
	}

	/**
	 * Gets the review reply template 3 star.
	 *
	 * @return the review reply template 3 star
	 */
	public String getReview_reply_template_3_star() {

		return review_reply_template_3_star;
	}

	/**
	 * Sets the review reply template 3 star.
	 *
	 * @param review_reply_template_3_star the new review reply template 3 star
	 */
	public void setReview_reply_template_3_star(String review_reply_template_3_star) {

		this.review_reply_template_3_star = review_reply_template_3_star;
	}

	/**
	 * Gets the review reply template 4 star.
	 *
	 * @return the review reply template 4 star
	 */
	public String getReview_reply_template_4_star() {

		return review_reply_template_4_star;
	}

	/**
	 * Sets the review reply template 4 star.
	 *
	 * @param review_reply_template_4_star the new review reply template 4 star
	 */
	public void setReview_reply_template_4_star(String review_reply_template_4_star) {

		this.review_reply_template_4_star = review_reply_template_4_star;
	}

	/**
	 * Gets the review reply template 5 star.
	 *
	 * @return the review reply template 5 star
	 */
	public String getReview_reply_template_5_star() {

		return review_reply_template_5_star;
	}

	/**
	 * Sets the review reply template 5 star.
	 *
	 * @param review_reply_template_5_star the new review reply template 5 star
	 */
	public void setReview_reply_template_5_star(String review_reply_template_5_star) {

		this.review_reply_template_5_star = review_reply_template_5_star;
	}

	/**
	 * Gets the logo url.
	 *
	 * @return the logo url
	 */
	public String getLogo_url() {

		return logo_url;
	}

	/**
	 * Sets the logo url.
	 *
	 * @param logo_url the new logo url
	 */
	public void setLogo_url(String logo_url) {

		this.logo_url = logo_url;
	}

	/**
	 * Gets the logo thumbnail url.
	 *
	 * @return the logo thumbnail url
	 */
	public String getLogo_thumbnail_url() {

		return logo_thumbnail_url;
	}

	/**
	 * Sets the logo thumbnail url.
	 *
	 * @param logo_thumbnail_url the new logo thumbnail url
	 */
	public void setLogo_thumbnail_url(String logo_thumbnail_url) {

		this.logo_thumbnail_url = logo_thumbnail_url;
	}

	/**
	 * Gets the logo cloudinary id.
	 *
	 * @return the logo cloudinary id
	 */
	public String getLogo_cloudinary_id() {

		return logo_cloudinary_id;
	}

	/**
	 * Sets the logo cloudinary id.
	 *
	 * @param logo_cloudinary_id the new logo cloudinary id
	 */
	public void setLogo_cloudinary_id(String logo_cloudinary_id) {

		this.logo_cloudinary_id = logo_cloudinary_id;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {

		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {

		this.name = name;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return ConvertPojoToHtml.convert(this);
	}

}

package com.rallio.automation.bussiness.newRallio.entity;

public class Crop {

	private int x;

	private int y;

	private double height;

	private double width;

	private int rotate;

	private int scaleX;

	private int scaleY;

	public int getX() {

		return x;
	}

	public void setX(int x) {

		this.x = x;
	}

	public int getY() {

		return y;
	}

	public void setY(int y) {

		this.y = y;
	}

	public double getHeight() {

		return height;
	}

	public void setHeight(double height) {

		this.height = height;
	}

	public double getWidth() {

		return width;
	}

	public void setWidth(double width) {

		this.width = width;
	}

	public int getRotate() {

		return rotate;
	}

	public void setRotate(int rotate) {

		this.rotate = rotate;
	}

	public int getScaleX() {

		return scaleX;
	}

	public void setScaleX(int scaleX) {

		this.scaleX = scaleX;
	}

	public int getScaleY() {

		return scaleY;
	}

	public void setScaleY(int scaleY) {

		this.scaleY = scaleY;
	}

}

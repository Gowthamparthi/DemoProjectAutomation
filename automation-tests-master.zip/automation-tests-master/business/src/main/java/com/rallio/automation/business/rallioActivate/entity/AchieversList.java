package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class AchieversList.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AchieversList {

	/** The program id. */
	private int programId;

	/** The rewards. */
	private String rewards;

	/** The total score. */
	private String totalScore;

	/** The user name. */
	private String userName;

	/** The advocacy posts. */
	private String advocacyPosts;

	/** The assets submitted. */
	private String assetsSubmitted;

	/** The engagement from assets. */
	private String engagementFromAssets;

	/** The program. */
	private ProgramAction programAction;

	/**
	 * Gets the program action.
	 *
	 * @return the program action
	 */
	public ProgramAction getProgramAction() {

		return programAction;
	}

	/**
	 * Sets the program action.
	 *
	 * @param programAction the new program action
	 */
	public void setProgramAction(ProgramAction programAction) {

		this.programAction = programAction;
	}

	/**
	 * Gets the program id.
	 *
	 * @return the program id
	 */
	public int getProgramId() {

		return programId;
	}

	/**
	 * Sets the program id.
	 *
	 * @param programId the new program id
	 */
	public void setProgramId(int programId) {

		this.programId = programId;
	}

	/**
	 * Gets the rewards.
	 *
	 * @return the rewards
	 */
	public String getRewards() {

		return rewards;
	}

	/**
	 * Sets the rewards.
	 *
	 * @param rewards the new rewards
	 */
	public void setRewards(String rewards) {

		this.rewards = rewards;
	}

	/**
	 * Gets the total score.
	 *
	 * @return the total score
	 */
	public String getTotalScore() {

		return totalScore;
	}

	/**
	 * Sets the total score.
	 *
	 * @param totalScore the new total score
	 */
	public void setTotalScore(String totalScore) {

		this.totalScore = totalScore;
	}

	/**
	 * Gets the user name.
	 *
	 * @return the user name
	 */
	public String getUserName() {

		return userName;
	}

	/**
	 * Sets the user name.
	 *
	 * @param userName the new user name
	 */
	public void setUserName(String userName) {

		this.userName = userName;
	}

	/**
	 * Gets the advocacy posts.
	 *
	 * @return the advocacy posts
	 */
	public String getAdvocacyPosts() {

		return advocacyPosts;
	}

	/**
	 * Sets the advocacy posts.
	 *
	 * @param advocacyPosts the new advocacy posts
	 */
	public void setAdvocacyPosts(String advocacyPosts) {

		this.advocacyPosts = advocacyPosts;
	}

	/**
	 * Gets the assets submitted.
	 *
	 * @return the assets submitted
	 */
	public String getAssetsSubmitted() {

		return assetsSubmitted;
	}

	/**
	 * Sets the assets submitted.
	 *
	 * @param assetsSubmitted the new assets submitted
	 */
	public void setAssetsSubmitted(String assetsSubmitted) {

		this.assetsSubmitted = assetsSubmitted;
	}

	/**
	 * Gets the engagement from assets.
	 *
	 * @return the engagement from assets
	 */
	public String getEngagementFromAssets() {

		return engagementFromAssets;
	}

	/**
	 * Sets the engagement from assets.
	 *
	 * @param engagementFromAssets the new engagement from assets
	 */
	public void setEngagementFromAssets(String engagementFromAssets) {

		this.engagementFromAssets = engagementFromAssets;
	}

}

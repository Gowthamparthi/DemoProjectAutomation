package com.rallio.automation.business.rallioWebApp.entity;

import java.util.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.rallio.automation.business.rallioActivate.entity.LeaderBoardList;

// TODO: Auto-generated Javadoc
/**
 * The Class AdvocacyPosts.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AdvocacyPosts {

	/** The advocacy posts. */
	private ArrayList<LeaderBoardList> advocacy_posts;
	
	/** The total assets submitted count. */
	private String total_assets_submitted_count;

	/** The total engagement from assets count. */
	private String total_engagement_from_assets_count;

	/** The total advocacy posts count. */
	private String total_advocacy_posts_count;

	/** The overall score. */
	private String overall_score;

	/** The brand ranking. */
	private String brand_ranking;

	/**
	 * Gets the total assets submitted count.
	 *
	 * @return the total assets submitted count
	 */
	public String getTotal_assets_submitted_count() {
		return total_assets_submitted_count;
	}

	/**
	 * Sets the total assets submitted count.
	 *
	 * @param total_assets_submitted_count the new total assets submitted count
	 */
	public void setTotal_assets_submitted_count(String total_assets_submitted_count) {
		this.total_assets_submitted_count = total_assets_submitted_count;
	}

	/**
	 * Gets the total engagement from assets count.
	 *
	 * @return the total engagement from assets count
	 */
	public String getTotal_engagement_from_assets_count() {
		return total_engagement_from_assets_count;
	}

	/**
	 * Sets the total engagement from assets count.
	 *
	 * @param total_engagement_from_assets_count the new total engagement from assets count
	 */
	public void setTotal_engagement_from_assets_count(String total_engagement_from_assets_count) {
		this.total_engagement_from_assets_count = total_engagement_from_assets_count;
	}

	/**
	 * Gets the total advocacy posts count.
	 *
	 * @return the total advocacy posts count
	 */
	public String getTotal_advocacy_posts_count() {
		return total_advocacy_posts_count;
	}

	/**
	 * Sets the total advocacy posts count.
	 *
	 * @param total_advocacy_posts_count the new total advocacy posts count
	 */
	public void setTotal_advocacy_posts_count(String total_advocacy_posts_count) {
		this.total_advocacy_posts_count = total_advocacy_posts_count;
	}

	/**
	 * Gets the overall score.
	 *
	 * @return the overall score
	 */
	public String getOverall_score() {
		return overall_score;
	}

	/**
	 * Sets the overall score.
	 *
	 * @param overall_score the new overall score
	 */
	public void setOverall_score(String overall_score) {
		this.overall_score = overall_score;
	}

	/**
	 * Gets the brand ranking.
	 *
	 * @return the brand ranking
	 */
	public String getBrand_ranking() {
		return brand_ranking;
	}

	/**
	 * Sets the brand ranking.
	 *
	 * @param brand_ranking the new brand ranking
	 */
	public void setBrand_ranking(String brand_ranking) {
		this.brand_ranking = brand_ranking;
	}

}

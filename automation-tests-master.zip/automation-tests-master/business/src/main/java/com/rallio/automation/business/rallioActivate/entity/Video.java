package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Video.
 */
public class Video {

	/** The video name. */
	private String videoName;

	/** The uploaded by. */
	private String uploadedBy;

	/** The location. */
	private String location;

	/**
	 * Gets the video name.
	 *
	 * @return the video name
	 */
	public String getVideoName() {

		return videoName;
	}

	/**
	 * Sets the video name.
	 *
	 * @param videoName the new video name
	 */
	public void setVideoName(String videoName) {

		this.videoName = videoName;
	}

	/**
	 * Gets the uploaded by.
	 *
	 * @return the uploaded by
	 */
	public String getUploadedBy() {

		return uploadedBy;
	}

	/**
	 * Sets the uploaded by.
	 *
	 * @param uploadedBy the new uploaded by
	 */
	public void setUploadedBy(String uploadedBy) {

		this.uploadedBy = uploadedBy;
	}

	/**
	 * Gets the location.
	 *
	 * @return the location
	 */
	public String getLocation() {

		return location;
	}

	/**
	 * Sets the location.
	 *
	 * @param location the new location
	 */
	public void setLocation(String location) {

		this.location = location;
	}
}

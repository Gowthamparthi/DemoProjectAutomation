package com.rallio.automation.bussiness.newRallio.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class TopLevelFranchisor.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class TopLevelFranchisor {

	/** The avatar url. */
	private String avatar_url;

	/** The cover photo url. */
	private String cover_photo_url;

	/** The email. */
	private String email;

	/** The id. */
	private int id;

	/** The logo cloudinary id. */
	private String logo_cloudinary_id;

	/** The logo thumbnail url. */
	private String logo_thumbnail_url;

	/** The logo url. */
	private String logo_url;

	/** The name. */
	private String name;

	/** The profile image url. */
	private String profile_image_url;

	/** The pv location id. */
	private String pv_location_id;

	/**
	 * Gets the avatar url.
	 *
	 * @return the avatar url
	 */
	public String getAvatar_url() {

		return avatar_url;
	}

	/**
	 * Sets the avatar url.
	 *
	 * @param avatar_url the new avatar url
	 */
	public void setAvatar_url(String avatar_url) {

		this.avatar_url = avatar_url;
	}

	/**
	 * Gets the cover photo url.
	 *
	 * @return the cover photo url
	 */
	public String getCover_photo_url() {

		return cover_photo_url;
	}

	/**
	 * Sets the cover photo url.
	 *
	 * @param cover_photo_url the new cover photo url
	 */
	public void setCover_photo_url(String cover_photo_url) {

		this.cover_photo_url = cover_photo_url;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {

		return email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {

		this.email = email;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/**
	 * Gets the logo cloudinary id.
	 *
	 * @return the logo cloudinary id
	 */
	public String getLogo_cloudinary_id() {

		return logo_cloudinary_id;
	}

	/**
	 * Sets the logo cloudinary id.
	 *
	 * @param logo_cloudinary_id the new logo cloudinary id
	 */
	public void setLogo_cloudinary_id(String logo_cloudinary_id) {

		this.logo_cloudinary_id = logo_cloudinary_id;
	}

	/**
	 * Gets the logo thumbnail url.
	 *
	 * @return the logo thumbnail url
	 */
	public String getLogo_thumbnail_url() {

		return logo_thumbnail_url;
	}

	/**
	 * Sets the logo thumbnail url.
	 *
	 * @param logo_thumbnail_url the new logo thumbnail url
	 */
	public void setLogo_thumbnail_url(String logo_thumbnail_url) {

		this.logo_thumbnail_url = logo_thumbnail_url;
	}

	/**
	 * Gets the logo url.
	 *
	 * @return the logo url
	 */
	public String getLogo_url() {

		return logo_url;
	}

	/**
	 * Sets the logo url.
	 *
	 * @param logo_url the new logo url
	 */
	public void setLogo_url(String logo_url) {

		this.logo_url = logo_url;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {

		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {

		this.name = name;
	}

	/**
	 * Gets the profile image url.
	 *
	 * @return the profile image url
	 */
	public String getProfile_image_url() {

		return profile_image_url;
	}

	/**
	 * Sets the profile image url.
	 *
	 * @param profile_image_url the new profile image url
	 */
	public void setProfile_image_url(String profile_image_url) {

		this.profile_image_url = profile_image_url;
	}

	/**
	 * Gets the pv location id.
	 *
	 * @return the pv location id
	 */
	public String getPv_location_id() {

		return pv_location_id;
	}

	/**
	 * Sets the pv location id.
	 *
	 * @param pv_location_id the new pv location id
	 */
	public void setPv_location_id(String pv_location_id) {

		this.pv_location_id = pv_location_id;
	}
}

package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

import com.rallio.automation.common.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Program.
 */
public class Program {

	/** The program details. */
	private ProgramDetails programDetails;

	/** The program actions. */
	private List<ProgramActions> programActions;

	/** The program locations. */
	private List<ProgramLocations> programLocations;

	/**
	 * Gets the program locations.
	 *
	 * @return the program locations
	 */
	public List<ProgramLocations> getProgramLocations() {

		return programLocations;
	}

	/**
	 * Sets the program locations.
	 *
	 * @param programLocations the new program locations
	 */
	public void setProgramLocations(List<ProgramLocations> programLocations) {

		this.programLocations = programLocations;
	}

	/**
	 * Gets the program actions.
	 *
	 * @return the program actions
	 */
	public List<ProgramActions> getProgramActions() {

		return programActions;
	}

	/**
	 * Sets the program actions.
	 *
	 * @param programActions the new program actions
	 */
	public void setProgramActions(List<ProgramActions> programActions) {

		this.programActions = programActions;
	}

	/** The program payment. */
	private ProgramPayment programPayment;

	/**
	 * Gets the program payment.
	 *
	 * @return the program payment
	 */
	public ProgramPayment getProgramPayment() {

		return programPayment;
	}

	/**
	 * Sets the program payment.
	 *
	 * @param programPayment the new program payment
	 */
	public void setProgramPayment(ProgramPayment programPayment) {

		this.programPayment = programPayment;
	}

	/**
	 * Gets the program details.
	 *
	 * @return the program details
	 */
	public ProgramDetails getProgramDetails() {

		return programDetails;
	}

	/**
	 * Sets the program details.
	 *
	 * @param programDetails the new program details
	 */
	public void setProgramDetails(ProgramDetails programDetails) {

		this.programDetails = programDetails;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return ConvertPojoToHtml.convert(this);
	}

}

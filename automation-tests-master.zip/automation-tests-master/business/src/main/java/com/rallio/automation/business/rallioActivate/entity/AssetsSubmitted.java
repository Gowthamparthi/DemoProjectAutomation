package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

// TODO: Auto-generated Javadoc
/**
 * The Class Assets.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssetsSubmitted {

	/** The total assets submitted score. */
	private String total_assets_submitted_score;

	/** The total assets submitted count. */
	private String total_assets_submitted_count;

	/** The assets submitted. */
	private ArrayList<LeaderBoardList> assets_submitted;

	/**
	 * Gets the assets submitted.
	 *
	 * @return the assets submitted
	 */
	public ArrayList<LeaderBoardList> getAssets_submitted() {

		return assets_submitted;
	}

	/**
	 * Sets the assets submitted.
	 *
	 * @param assets_submitted the new assets submitted
	 */
	public void setAssets_submitted(ArrayList<LeaderBoardList> assets_submitted) {

		this.assets_submitted = assets_submitted;
	}

	/**
	 * Gets the total assets submitted score.
	 *
	 * @return the total assets submitted score
	 */
	public String getTotal_assets_submitted_score() {

		return total_assets_submitted_score;
	}

	/**
	 * Sets the total assets submitted score.
	 *
	 * @param total_assets_submitted_score the new total assets submitted score
	 */
	public void setTotal_assets_submitted_score(String total_assets_submitted_score) {

		this.total_assets_submitted_score = total_assets_submitted_score;
	}

	/**
	 * Gets the total assets submitted count.
	 *
	 * @return the total assets submitted count
	 */
	public String getTotal_assets_submitted_count() {

		return total_assets_submitted_count;
	}

	/**
	 * Sets the total assets submitted count.
	 *
	 * @param total_assets_submitted_count the new total assets submitted count
	 */
	public void setTotal_assets_submitted_count(String total_assets_submitted_count) {

		this.total_assets_submitted_count = total_assets_submitted_count;
	}

}

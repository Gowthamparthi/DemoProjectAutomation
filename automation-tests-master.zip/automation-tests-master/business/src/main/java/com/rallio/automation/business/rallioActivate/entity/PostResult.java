package com.rallio.automation.business.rallioActivate.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class PostResult.
 */
public class PostResult {

	/** The date. */
	private String date;

	/** The facebook posts count. */
	private int facebook_posts_count;

	/** The instagram posts count. */
	private int instagram_posts_count;

	/** The linkedin posts count. */
	private int linkedin_posts_count;

	/** The twitter posts count. */
	private int twitter_posts_count;

	/**
	 * Gets the date.
	 *
	 * @return the date
	 */
	public String getDate() {

		return date;
	}

	/**
	 * Sets the date.
	 *
	 * @param date the new date
	 */
	public void setDate(String date) {

		this.date = date;
	}

	/**
	 * Gets the facebook posts count.
	 *
	 * @return the facebook posts count
	 */
	public int getFacebook_posts_count() {

		return facebook_posts_count;
	}

	/**
	 * Sets the facebook posts count.
	 *
	 * @param facebook_posts_count the new facebook posts count
	 */
	public void setFacebook_posts_count(int facebook_posts_count) {

		this.facebook_posts_count = facebook_posts_count;
	}

	/**
	 * Gets the instagram posts count.
	 *
	 * @return the instagram posts count
	 */
	public int getInstagram_posts_count() {

		return instagram_posts_count;
	}

	/**
	 * Sets the instagram posts count.
	 *
	 * @param instagram_posts_count the new instagram posts count
	 */
	public void setInstagram_posts_count(int instagram_posts_count) {

		this.instagram_posts_count = instagram_posts_count;
	}

	/**
	 * Gets the linkedin posts count.
	 *
	 * @return the linkedin posts count
	 */
	public int getLinkedin_posts_count() {

		return linkedin_posts_count;
	}

	/**
	 * Sets the linkedin posts count.
	 *
	 * @param linkedin_posts_count the new linkedin posts count
	 */
	public void setLinkedin_posts_count(int linkedin_posts_count) {

		this.linkedin_posts_count = linkedin_posts_count;
	}

	/**
	 * Gets the twitter posts count.
	 *
	 * @return the twitter posts count
	 */
	public int getTwitter_posts_count() {

		return twitter_posts_count;
	}

	/**
	 * Sets the twitter posts count.
	 *
	 * @param twitter_posts_count the new twitter posts count
	 */
	public void setTwitter_posts_count(int twitter_posts_count) {

		this.twitter_posts_count = twitter_posts_count;
	}

}

package com.rallio.automation.business.rallioActivate.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class CardDetails.
 */
public class CardDetails {

	/** The duration. */
	private int duration;

	/** The amount. */
	private int amount;

	/** The end date. */
	private long endDate;

	/** The program duration. */
	private int programDuration;

	/** The occurrences. */
	private int occurrences;

	/**
	 * Gets the duration.
	 *
	 * @return the duration
	 */
	public int getDuration() {

		return duration;
	}

	/**
	 * Sets the duration.
	 *
	 * @param duration the new duration
	 */
	public void setDuration(int duration) {

		this.duration = duration;
	}

	/**
	 * Gets the amount.
	 *
	 * @return the amount
	 */
	public int getAmount() {

		return amount;
	}

	/**
	 * Sets the amount.
	 *
	 * @param amount the new amount
	 */
	public void setAmount(int amount) {

		this.amount = amount;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public long getEndDate() {

		return endDate;
	}

	/**
	 * Sets the end date.
	 *
	 * @param endDate the new end date
	 */
	public void setEndDate(long endDate) {

		this.endDate = endDate;
	}

	/**
	 * Gets the program duration.
	 *
	 * @return the program duration
	 */
	public int getProgramDuration() {

		return programDuration;
	}

	/**
	 * Sets the program duration.
	 *
	 * @param programDuration the new program duration
	 */
	public void setProgramDuration(int programDuration) {

		this.programDuration = programDuration;
	}

	/**
	 * Gets the occurrences.
	 *
	 * @return the occurrences
	 */
	public int getOccurrences() {

		return occurrences;
	}

	/**
	 * Sets the occurrences.
	 *
	 * @param occurrences the new occurrences
	 */
	public void setOccurrences(int occurrences) {

		this.occurrences = occurrences;
	}

}

package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class MonthlyPostMetrics.
 */
public class MonthlyPostMetrics {

	/** The total posts result. */
	private List<PostResult> total_posts_result;

	/** The published posts result. */
	private List<PostResult> published_posts_result;

	/** The used posts result. */
	private List<PostResult> used_posts_result;

	/**
	 * Gets the total posts result.
	 *
	 * @return the total posts result
	 */
	public List<PostResult> getTotal_posts_result() {

		return total_posts_result;
	}

	/**
	 * Sets the total posts result.
	 *
	 * @param total_posts_result the new total posts result
	 */
	public void setTotal_posts_result(List<PostResult> total_posts_result) {

		this.total_posts_result = total_posts_result;
	}

	/**
	 * Gets the published posts result.
	 *
	 * @return the published posts result
	 */
	public List<PostResult> getPublished_posts_result() {

		return published_posts_result;
	}

	/**
	 * Sets the published posts result.
	 *
	 * @param published_posts_result the new published posts result
	 */
	public void setPublished_posts_result(List<PostResult> published_posts_result) {

		this.published_posts_result = published_posts_result;
	}

	/**
	 * Gets the used posts result.
	 *
	 * @return the used posts result
	 */
	public List<PostResult> getUsed_posts_result() {

		return used_posts_result;
	}

	/**
	 * Sets the used posts result.
	 *
	 * @param used_posts_result the new used posts result
	 */
	public void setUsed_posts_result(List<PostResult> used_posts_result) {

		this.used_posts_result = used_posts_result;
	}

}

package com.rallio.automation.bussiness.newRallio.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class SurveyCustomer.
 */
public class SurveyCustomer {

	/** The customer name. */
	String customerName;

	/** The customer mailid. */
	String customerMailid;

	/** The customer mobile number. */
	String customerMobileNumber;

	/** The customer feedback. */
	String customerFeedback;

	/** The customer survey status. */
	String customerSurveyStatus;

	/** The location name. */
	String locationName;

	/** The surebutton. */
	boolean surebutton;

	/** The no thanks button. */
	boolean noThanksButton;

	/** The confirm button. */
	boolean confirmButton;

	/** The review rating. */
	int reviewRating;

	/**
	 * Gets the customer name.
	 *
	 * @return the customer name
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * Sets the customer name.
	 *
	 * @param customerName the new customer name
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	/**
	 * Gets the customer mobile number.
	 *
	 * @return the customer mobile number
	 */
	public String getCustomerMobileNumber() {
		return customerMobileNumber;
	}

	/**
	 * Gets the customer mailid.
	 *
	 * @return the customer mailid
	 */
	public String getCustomerMailid() {
		return customerMailid;
	}

	/**
	 * Sets the customer mailid.
	 *
	 * @param customerMailid the new customer mailid
	 */
	public void setCustomerMailid(String customerMailid) {
		this.customerMailid = customerMailid;
	}

	/**
	 * Sets the customer mobile number.
	 *
	 * @param customerMobileNumber the new customer mobile number
	 */
	public void setCustomerMobileNumber(String customerMobileNumber) {
		this.customerMobileNumber = customerMobileNumber;
	}

	/**
	 * Gets the customer feedback.
	 *
	 * @return the customer feedback
	 */
	public String getCustomerFeedback() {
		return customerFeedback;
	}

	/**
	 * Sets the customer feedback.
	 *
	 * @param customerFeedback the new customer feedback
	 */
	public void setCustomerFeedback(String customerFeedback) {
		this.customerFeedback = customerFeedback;
	}

	
	/**
	 * Checks if is surebutton.
	 *
	 * @return true, if is surebutton
	 */
	public boolean isSurebutton() {
		return surebutton;
	}

	/**
	 * Sets the surebutton.
	 *
	 * @param surebutton the new surebutton
	 */
	public void setSurebutton(boolean surebutton) {
		this.surebutton = surebutton;
	}

	/**
	 * Checks if is no thanks button.
	 *
	 * @return true, if is no thanks button
	 */
	public boolean isNoThanksButton() {
		return noThanksButton;
	}

	/**
	 * Sets the no thanks button.
	 *
	 * @param noThanksButton the new no thanks button
	 */
	public void setNoThanksButton(boolean noThanksButton) {
		this.noThanksButton = noThanksButton;
	}

	/**
	 * Checks if is confirm button.
	 *
	 * @return true, if is confirm button
	 */
	public boolean isConfirmButton() {
		return confirmButton;
	}

	/**
	 * Sets the confirm button.
	 *
	 * @param confirmButton the new confirm button
	 */
	public void setConfirmButton(boolean confirmButton) {
		this.confirmButton = confirmButton;
	}

	/**
	 * Gets the review rating.
	 *
	 * @return the review rating
	 */
	public int getReviewRating() {
		return reviewRating;
	}

	/**
	 * Sets the review rating.
	 *
	 * @param reviewRating the new review rating
	 */
	public void setReviewRating(int reviewRating) {
		this.reviewRating = reviewRating;
	}

	/**
	 * Gets the customer survey status.
	 *
	 * @return the customer survey status
	 */
	public String getCustomerSurveyStatus() {
		return customerSurveyStatus;
	}

	/**
	 * Sets the customer survey status.
	 *
	 * @param customerSurveyStatus the new customer survey status
	 */
	public void setCustomerSurveyStatus(String customerSurveyStatus) {
		this.customerSurveyStatus = customerSurveyStatus;
	}

	/**
	 * Gets the location name.
	 *
	 * @return the location name
	 */
	public String getLocationName() {
		return locationName;
	}

	/**
	 * Sets the location name.
	 *
	 * @param locationName the new location name
	 */
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}
}

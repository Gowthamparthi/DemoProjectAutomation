package com.rallio.automation.business.rallioLocalCenter.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class AssetsLocalMetrics.
 */
public class AssetsLocalMetrics {

	/** The approval assets count. */
	private int approval_assets_count;

	/** The assets approval awaiting count. */
	private int assets_approval_awaiting_count;

	/** The assets denied count. */
	private int assets_denied_count;

	/** The goal count. */
	private int goal_count;

	/** The total assets count. */
	private int total_assets_count;

	/** The usable assets count. */
	private int usable_assets_count;

	/**
	 * Gets the approval assets count.
	 *
	 * @return the approval assets count
	 */
	public int getApproval_assets_count() {

		return approval_assets_count;
	}

	/**
	 * Sets the approval assets count.
	 *
	 * @param approval_assets_count the new approval assets count
	 */
	public void setApproval_assets_count(int approval_assets_count) {

		this.approval_assets_count = approval_assets_count;
	}

	/**
	 * Gets the assets approval awaiting count.
	 *
	 * @return the assets approval awaiting count
	 */
	public int getAssets_approval_awaiting_count() {

		return assets_approval_awaiting_count;
	}

	/**
	 * Sets the assets approval awaiting count.
	 *
	 * @param assets_approval_awaiting_count the new assets approval awaiting
	 *            count
	 */
	public void setAssets_approval_awaiting_count(int assets_approval_awaiting_count) {

		this.assets_approval_awaiting_count = assets_approval_awaiting_count;
	}

	/**
	 * Gets the assets denied count.
	 *
	 * @return the assets denied count
	 */
	public int getAssets_denied_count() {

		return assets_denied_count;
	}

	/**
	 * Sets the assets denied count.
	 *
	 * @param assets_denied_count the new assets denied count
	 */
	public void setAssets_denied_count(int assets_denied_count) {

		this.assets_denied_count = assets_denied_count;
	}

	/**
	 * Gets the goal count.
	 *
	 * @return the goal count
	 */
	public int getGoal_count() {

		return goal_count;
	}

	/**
	 * Sets the goal count.
	 *
	 * @param goal_count the new goal count
	 */
	public void setGoal_count(int goal_count) {

		this.goal_count = goal_count;
	}

	/**
	 * Gets the total assets count.
	 *
	 * @return the total assets count
	 */
	public int getTotal_assets_count() {

		return total_assets_count;
	}

	/**
	 * Sets the total assets count.
	 *
	 * @param total_assets_count the new total assets count
	 */
	public void setTotal_assets_count(int total_assets_count) {

		this.total_assets_count = total_assets_count;
	}

	/**
	 * Gets the usable assets count.
	 *
	 * @return the usable assets count
	 */
	public int getUsable_assets_count() {

		return usable_assets_count;
	}

	/**
	 * Sets the usable assets count.
	 *
	 * @param usable_assets_count the new usable assets count
	 */
	public void setUsable_assets_count(int usable_assets_count) {

		this.usable_assets_count = usable_assets_count;
	}

}

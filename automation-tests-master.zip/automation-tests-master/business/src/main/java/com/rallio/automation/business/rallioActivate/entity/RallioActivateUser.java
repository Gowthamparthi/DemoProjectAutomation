package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.rallio.automation.business.rallioWebApp.entity.*;
import com.rallio.automation.common.util.ConvertPojoToHtml;

// TODO: Auto-generated Javadoc
/**
 * The Class RalioActivateUser.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RallioActivateUser {

	/** The user name. */
	private String userName;

	/** The password. */
	private String password;

	/** The account. */
	private String account;

	/** The program details. */
	private Program program;

	/** The Post details. */
	private PostDetails postDetails;

	/** The type. */
	private String type;

	/** The rallio web app user. */
	private RallioWebAppUser rallioWebAppUser;

	/**
	 * Gets the rallio web app user.
	 *
	 * @return the rallio web app user
	 */
	public RallioWebAppUser getRallioWebAppUser() {

		return rallioWebAppUser;
	}

	/**
	 * Sets the rallio web app user.
	 *
	 * @param rallioWebAppUser the new rallio web app user
	 */
	public void setRallioWebAppUser(RallioWebAppUser rallioWebAppUser) {

		this.rallioWebAppUser = rallioWebAppUser;
	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {

		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(String type) {

		this.type = type;
	}

	/**
	 * Gets the account.
	 *
	 * @return the account
	 */
	public String getAccount() {

		return account;
	}

	/**
	 * Sets the account.
	 *
	 * @param account the new account
	 */
	public void setAccount(String account) {

		this.account = account;
	}

	/**
	 * Sets the user name.
	 *
	 * @param userName the new user name
	 */
	public void setUserName(String userName) {

		this.userName = userName;
	}

	/**
	 * Sets the password.
	 *
	 * @param password the new password
	 */
	public void setPassword(String password) {

		this.password = password;
	}

	/**
	 * Sets the program.
	 *
	 * @param program the new program
	 */
	public void setProgram(Program program) {

		this.program = program;
	}

	/**
	 * Sets the post details.
	 *
	 * @param postDetails the new post details
	 */
	public void setPostDetails(PostDetails postDetails) {

		this.postDetails = postDetails;
	}

	/**
	 * Gets the program.
	 *
	 * @return the program
	 */
	public Program getProgram() {

		return program;
	}

	/**
	 * Gets the post details.
	 *
	 * @return the post details
	 */
	public PostDetails getPostDetails() {

		return postDetails;
	}

	/**
	 * Gets the user name.
	 *
	 * @return the user name
	 */
	public String getUserName() {

		return userName;
	}

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {

		return password;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return ConvertPojoToHtml.convert(this);
	}
}

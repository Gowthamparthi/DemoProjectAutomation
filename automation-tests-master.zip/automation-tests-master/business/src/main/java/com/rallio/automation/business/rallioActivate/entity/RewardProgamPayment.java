package com.rallio.automation.business.rallioActivate.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class RewardProgamPayment.
 */
public class RewardProgamPayment {

	/** The email. */
	private String email;

	/** The amount. */
	private int amount;

	/** The description. */
	private String description;

	/** The is save card. */
	private boolean isSaveCard;

	/** The card id. */
	private String cardId;

	/** The details. */
	private CardDetails details;

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {

		return email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {

		this.email = email;
	}

	/**
	 * Gets the amount.
	 *
	 * @return the amount
	 */
	public int getAmount() {

		return amount;
	}

	/**
	 * Sets the amount.
	 *
	 * @param amount the new amount
	 */
	public void setAmount(int amount) {

		this.amount = amount;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}

	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(String description) {

		this.description = description;
	}

	/**
	 * Checks if is save card.
	 *
	 * @return true, if is save card
	 */
	public boolean isSaveCard() {

		return isSaveCard;
	}

	/**
	 * Sets the save card.
	 *
	 * @param isSaveCard the new save card
	 */
	public void setSaveCard(boolean isSaveCard) {

		this.isSaveCard = isSaveCard;
	}

	/**
	 * Gets the card id.
	 *
	 * @return the card id
	 */
	public String getCardId() {

		return cardId;
	}

	/**
	 * Sets the card id.
	 *
	 * @param cardId the new card id
	 */
	public void setCardId(String cardId) {

		this.cardId = cardId;
	}

	/**
	 * Gets the details.
	 *
	 * @return the details
	 */
	public CardDetails getDetails() {

		return details;
	}

	/**
	 * Sets the details.
	 *
	 * @param details the new details
	 */
	public void setDetails(CardDetails details) {

		this.details = details;
	}
}

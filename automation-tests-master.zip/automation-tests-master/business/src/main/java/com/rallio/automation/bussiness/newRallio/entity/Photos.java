package com.rallio.automation.bussiness.newRallio.entity;

import com.fasterxml.jackson.annotation.*;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Photos {

	private int account_id;

	private String account_name;

	private int brand_id;

	private String brand_name;

	private String cloudinary_id;

	private String comments;

	private boolean copy_to_descendants;

	private String created_at;

	private int created_by_user_id;

	private String created_by_user_name;

	private String created_user_profile_photo_url;

	private int franchisor_id;

	private String franchisor_name;

	private int id;

	private String liked;

	private String md5;

	private boolean media_release;

	private String media_type;

	private String medium_size_url;

	private String name;

	private int original_franchisor_id;

	private String original_franchisor_name;

	private String produced_by;

	private String source;

	private String tags_list;

	private String thumbnail_url;

	private Transformations transformations;

	private boolean trashed;

	private String url;

	private int used_count;

	private String verticals_list;

	public int getAccount_id() {

		return account_id;
	}

	public void setAccount_id(int account_id) {

		this.account_id = account_id;
	}

	public String getAccount_name() {

		return account_name;
	}

	public void setAccount_name(String account_name) {

		this.account_name = account_name;
	}

	public int getBrand_id() {

		return brand_id;
	}

	public void setBrand_id(int brand_id) {

		this.brand_id = brand_id;
	}

	public String getBrand_name() {

		return brand_name;
	}

	public void setBrand_name(String brand_name) {

		this.brand_name = brand_name;
	}

	public String getCloudinary_id() {

		return cloudinary_id;
	}

	public void setCloudinary_id(String cloudinary_id) {

		this.cloudinary_id = cloudinary_id;
	}

	public String getComments() {

		return comments;
	}

	public void setComments(String comments) {

		this.comments = comments;
	}

	public boolean isCopy_to_descendants() {

		return copy_to_descendants;
	}

	public void setCopy_to_descendants(boolean copy_to_descendants) {

		this.copy_to_descendants = copy_to_descendants;
	}

	public String getCreated_at() {

		return created_at;
	}

	public void setCreated_at(String created_at) {

		this.created_at = created_at;
	}

	public int getCreated_by_user_id() {

		return created_by_user_id;
	}

	public void setCreated_by_user_id(int created_by_user_id) {

		this.created_by_user_id = created_by_user_id;
	}

	public String getCreated_by_user_name() {

		return created_by_user_name;
	}

	public void setCreated_by_user_name(String created_by_user_name) {

		this.created_by_user_name = created_by_user_name;
	}

	public String getCreated_user_profile_photo_url() {

		return created_user_profile_photo_url;
	}

	public void setCreated_user_profile_photo_url(String created_user_profile_photo_url) {

		this.created_user_profile_photo_url = created_user_profile_photo_url;
	}

	public int getFranchisor_id() {

		return franchisor_id;
	}

	public void setFranchisor_id(int franchisor_id) {

		this.franchisor_id = franchisor_id;
	}

	public String getFranchisor_name() {

		return franchisor_name;
	}

	public void setFranchisor_name(String franchisor_name) {

		this.franchisor_name = franchisor_name;
	}

	public int getId() {

		return id;
	}

	public void setId(int id) {

		this.id = id;
	}

	public String getLiked() {

		return liked;
	}

	public void setLiked(String liked) {

		this.liked = liked;
	}

	public String getMd5() {

		return md5;
	}

	public void setMd5(String md5) {

		this.md5 = md5;
	}

	public boolean isMedia_release() {

		return media_release;
	}

	public void setMedia_release(boolean media_release) {

		this.media_release = media_release;
	}

	public String getMedia_type() {

		return media_type;
	}

	public void setMedia_type(String media_type) {

		this.media_type = media_type;
	}

	public String getMedium_size_url() {

		return medium_size_url;
	}

	public void setMedium_size_url(String medium_size_url) {

		this.medium_size_url = medium_size_url;
	}

	public String getName() {

		return name;
	}

	public void setName(String name) {

		this.name = name;
	}

	public int getOriginal_franchisor_id() {

		return original_franchisor_id;
	}

	public void setOriginal_franchisor_id(int original_franchisor_id) {

		this.original_franchisor_id = original_franchisor_id;
	}

	public String getOriginal_franchisor_name() {

		return original_franchisor_name;
	}

	public void setOriginal_franchisor_name(String original_franchisor_name) {

		this.original_franchisor_name = original_franchisor_name;
	}

	public String getProduced_by() {

		return produced_by;
	}

	public void setProduced_by(String produced_by) {

		this.produced_by = produced_by;
	}

	public String getSource() {

		return source;
	}

	public void setSource(String source) {

		this.source = source;
	}

	public String getTags_list() {

		return tags_list;
	}

	public void setTags_list(String tags_list) {

		this.tags_list = tags_list;
	}

	public String getThumbnail_url() {

		return thumbnail_url;
	}

	public void setThumbnail_url(String thumbnail_url) {

		this.thumbnail_url = thumbnail_url;
	}

	public Transformations getTransformations() {

		return transformations;
	}

	public void setTransformations(Transformations transformations) {

		this.transformations = transformations;
	}

	public boolean isTrashed() {

		return trashed;
	}

	public void setTrashed(boolean trashed) {

		this.trashed = trashed;
	}

	public String getUrl() {

		return url;
	}

	public void setUrl(String url) {

		this.url = url;
	}

	public int getUsed_count() {

		return used_count;
	}

	public void setUsed_count(int used_count) {

		this.used_count = used_count;
	}

	public String getVerticals_list() {

		return verticals_list;
	}

	public void setVerticals_list(String verticals_list) {

		this.verticals_list = verticals_list;
	}

}

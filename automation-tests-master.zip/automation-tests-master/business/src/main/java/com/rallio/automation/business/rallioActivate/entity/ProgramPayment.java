package com.rallio.automation.business.rallioActivate.entity;

import com.rallio.automation.common.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class ProgramPayment.
 */
public class ProgramPayment {

	/** The card number. */
	private String cardNumber;

	/** The month year. */
	private String monthYear;

	/** The cvc. */
	private String cvc;

	/** The card name. */
	private String cardName;

	/**
	 * Gets the card number.
	 *
	 * @return the card number
	 */
	public String getCardNumber() {

		return cardNumber;
	}

	/**
	 * Sets the card number.
	 *
	 * @param cardNumber the new card number
	 */
	public void setCardNumber(String cardNumber) {

		this.cardNumber = cardNumber;
	}

	/**
	 * Gets the month year.
	 *
	 * @return the month year
	 */
	public String getMonthYear() {

		return monthYear;
	}

	/**
	 * Sets the month year.
	 *
	 * @param monthYear the new month year
	 */
	public void setMonthYear(String monthYear) {

		this.monthYear = monthYear;
	}

	/**
	 * Gets the cvc.
	 *
	 * @return the cvc
	 */
	public String getCvc() {

		return cvc;
	}

	/**
	 * Sets the cvc.
	 *
	 * @param cvc the new cvc
	 */
	public void setCvc(String cvc) {

		this.cvc = cvc;
	}

	/**
	 * Gets the card name.
	 *
	 * @return the card name
	 */
	public String getCardName() {

		return cardName;
	}

	/**
	 * Sets the card name.
	 *
	 * @param cardName the new card name
	 */
	public void setCardName(String cardName) {

		this.cardName = cardName;
	}

	@Override
	public String toString() {

		return ConvertPojoToHtml.convert(this);
	}
}

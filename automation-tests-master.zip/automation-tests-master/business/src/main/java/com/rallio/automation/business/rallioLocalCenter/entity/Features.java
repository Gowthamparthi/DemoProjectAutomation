package com.rallio.automation.business.rallioLocalCenter.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Features.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Features {

	/** The activate. */
	private boolean activate;

	/** The directory listings. */
	private boolean directory_listings;

	/** The directory listings visible. */
	private boolean directory_listings_visible;
	
	
	public boolean isRallio_local_assets_notification() {
	
		return rallio_local_assets_notification;
	}

	
	public void setRallio_local_assets_notification(boolean rallio_local_assets_notification) {
	
		this.rallio_local_assets_notification = rallio_local_assets_notification;
	}

	private boolean rallio_local_assets_notification;
	
	/**
	 * Checks if is activate.
	 *
	 * @return true, if is activate
	 */
	public boolean isActivate() {

		return activate;
	}

	/**
	 * Sets the activate.
	 *
	 * @param activate the new activate
	 */
	public void setActivate(boolean activate) {

		this.activate = activate;
	}

	/**
	 * Checks if is directory listings.
	 *
	 * @return true, if is directory listings
	 */
	public boolean isDirectory_listings() {

		return directory_listings;
	}

	/**
	 * Sets the directory listings.
	 *
	 * @param directory_listings the new directory listings
	 */
	public void setDirectory_listings(boolean directory_listings) {

		this.directory_listings = directory_listings;
	}

	/**
	 * Checks if is directory listings visible.
	 *
	 * @return true, if is directory listings visible
	 */
	public boolean isDirectory_listings_visible() {

		return directory_listings_visible;
	}

	/**
	 * Sets the directory listings visible.
	 *
	 * @param directory_listings_visible the new directory listings visible
	 */
	public void setDirectory_listings_visible(boolean directory_listings_visible) {

		this.directory_listings_visible = directory_listings_visible;
	}

}

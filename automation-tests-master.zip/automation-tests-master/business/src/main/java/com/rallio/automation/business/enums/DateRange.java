package com.rallio.automation.business.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum DateRange.
 */
public enum DateRange {

	/** The last month. */
	LAST_MONTH("Last Month"),

	/** The month to date. */
	MONTH_TO_DATE("Month To Date"),

	/** The year to date. */
	YEAR_TO_DATE("Year To Date"),

	/** The all time. */
	ALL_TIME("All Time");

	/** The text. */
	private String text;

	/**
	 * Instantiates a new date range.
	 *
	 * @param text the text
	 */
	private DateRange(String text) {

		this.text = text;
	}

	/**
	 * Gets the text.
	 *
	 * @return the text
	 */
	public String getText() {

		return text;
	}
}

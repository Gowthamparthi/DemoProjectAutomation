package com.rallio.automation.business.rallioLocalCenter.entity;

import java.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Strategists.
 */
public class Strategists {

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return "Strategists [firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + ", id=" + id + ", mobile=" + mobile + ", isHub=" + isHub + ", hubs=" + hubs
		        + ", locations=" + locations + "]";
	}

	/** The first name. */
	private String firstName;

	/** The last name. */
	private String lastName;

	/** The email. */
	private String email;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/** The id. */
	private int id;

	/**
	 * Gets the mobile.
	 *
	 * @return the mobile
	 */
	public String getMobile() {

		return mobile;
	}

	/**
	 * Sets the mobile.
	 *
	 * @param mobile the new mobile
	 */
	public void setMobile(String mobile) {

		this.mobile = mobile;
	}

	/** The mobile. */
	private String mobile;

	/** The is hub. */
	private boolean isHub;

	/** The hubs. */
	private String hubs;

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {

		return firstName;
	}

	/**
	 * Sets the first name.
	 *
	 * @param firstName the new first name
	 */
	public void setFirstName(String firstName) {

		this.firstName = firstName;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {

		return lastName;
	}

	/**
	 * Sets the last name.
	 *
	 * @param lastName the new last name
	 */
	public void setLastName(String lastName) {

		this.lastName = lastName;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {

		return email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {

		this.email = email;
	}

	/**
	 * Checks if is hub.
	 *
	 * @return true, if is hub
	 */
	public boolean isHub() {

		return isHub;
	}

	/**
	 * Sets the hub.
	 *
	 * @param isHub the new hub
	 */
	public void setHub(boolean isHub) {

		this.isHub = isHub;
	}

	/**
	 * Gets the hubs.
	 *
	 * @return the hubs
	 */
	public String getHubs() {

		return hubs;
	}

	/**
	 * Sets the hubs.
	 *
	 * @param hubs the new hubs
	 */
	public void setHubs(String hubs) {

		this.hubs = hubs;
	}

	/**
	 * Gets the locations.
	 *
	 * @return the locations
	 */
	public List<String> getLocations() {

		return locations;
	}

	/**
	 * Sets the locations.
	 *
	 * @param locations the new locations
	 */
	public void setLocations(List<String> locations) {

		this.locations = locations;
	}

	/** The locations. */
	private List<String> locations;
}

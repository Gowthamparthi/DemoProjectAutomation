package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Links.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Links {

	/** The content comments. */
	private String content_comments;

	/** The content moderator comments. */
	private String content_moderator_comments;

	/**
	 * Gets the content comments.
	 *
	 * @return the content comments
	 */
	public String getContent_comments() {

		return content_comments;
	}

	/**
	 * Sets the content comments.
	 *
	 * @param content_comments the new content comments
	 */
	public void setContent_comments(String content_comments) {

		this.content_comments = content_comments;
	}

	/**
	 * Gets the content moderator comments.
	 *
	 * @return the content moderator comments
	 */
	public String getContent_moderator_comments() {

		return content_moderator_comments;
	}

	/**
	 * Sets the content moderator comments.
	 *
	 * @param content_moderator_comments the new content moderator comments
	 */
	public void setContent_moderator_comments(String content_moderator_comments) {

		this.content_moderator_comments = content_moderator_comments;
	}

}

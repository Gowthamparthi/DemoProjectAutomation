package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

// TODO: Auto-generated Javadoc
/**
 * The Class Contents.
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class Contents {

	/** The account list. */
	private AccountsList account_list;

	/** The auto schedule. */
	private boolean auto_schedule;


	@Override
	public String toString() {

		return "Contents [facebook_text=" + facebook_text + ", photo_ids=" + photo_ids + ", sent_to_franchisor=" + sent_to_franchisor + ", tags_list=" + tags_list
		        + ", use_facebook=" + use_facebook + ", use_google=" + use_google + ", use_instagram=" + use_instagram + ", use_linkedin=" + use_linkedin + ", use_twitter="
		        + use_twitter + ", video_id=" + video_id + ", franchisor_id=" + franchisor_id + "]";
	}

	/** The boost offer id. */
	private int boost_offer_id;

	/** The can edit. */
	private boolean can_edit;

	/** The created at. */
	private String created_at;

	/** The created user. */
	private User created_user;

	/** The date range locked. */
	private boolean date_range_locked;

	/** The delete from platforms after expiry. */
	private boolean delete_from_platforms_after_expiry;

	/** The disabled. */
	private boolean disabled;

	/** The end date. */
	private String end_date;

	/** The facebook text. */
	private String facebook_text;

	/** The franchisor. */
	private Franchisors franchisor;

	/** The franchisor list. */
	private FranchisorList franchisor_list;

	/** The google text. */
	private String google_text;

	/** The has parent. */
	private boolean has_parent;

	/** The id. */
	private int id;

	/** The instagram text. */
	private String instagram_text;

	/** The link id. */
	private String link_id;

	/** The linkedin text. */
	private String linkedin_text;

	/** The links. */
	private Links links;

	/** The lock descendants. */
	private boolean lock_descendants;

	/** The locked. */
	private boolean locked;

	/** The mobile app only enabled. */
	private boolean mobile_app_only_enabled;

	/** The moderation status. */
	private String moderation_status;

	/** The personalized facebook text. */
	private String personalized_facebook_text;

	/** The personalized google text. */
	private String personalized_google_text;

	/** The personalized instagram text. */
	private String personalized_instagram_text;

	/** The personalized linkedin text. */
	private String personalized_linkedin_text;

	/** The personalized twitter text. */
	private String personalized_twitter_text;

	/** The photo id. */
	private int photo_id;

	/** The photo ids. */
	private List<Integer> photo_ids;

	/** The photo urls. */
	private List<String> photo_urls;

	/** The post published count. */
	private int post_published_count;

	/** The repeat. */
	private boolean repeat;

	/** The scheduled anywhere. */
	private boolean scheduled_anywhere;

	/** The sent to franchisor. */
	private boolean sent_to_franchisor;

	/** The start date. */
	private String start_date;

	/** The status id. */
	private int status_id;

	/** The syndicate to account databases. */
	private boolean syndicate_to_account_databases;

	/** The tags list. */
	private String tags_list;

	/** The tone cautionary. */
	private int tone_cautionary;

	/** The tone educational. */
	private int tone_educational;

	/** The tone empathetic. */
	private int tone_empathetic;

	/** The tone engaging. */
	private int tone_engaging;

	/** The tone humorous. */
	private int tone_humorous;

	/** The tone inspirational. */
	private int tone_inspirational;

	/** The tone professional. */
	private int tone_professional;

	/** The tone quirky. */
	private int tone_quirky;

	/** The trashed. */
	private boolean trashed;

	/** The twitter text. */
	private String twitter_text;

	/** The updated at. */
	private String updated_at;

	/** The use facebook. */
	private boolean use_facebook;

	/** The use google. */
	private boolean use_google;

	/** The use instagram. */
	private boolean use_instagram;

	/** The use linkedin. */
	private boolean use_linkedin;

	/** The use shortened link. */
	private boolean use_shortened_link;

	/** The use twitter. */
	private boolean use_twitter;

	/** The use twitter photo. */
	private boolean use_twitter_photo;

	/** The verticals list. */
	private String verticals_list;

	/** The video id. */
	private String video_id;

	/** The video url. */
	private String video_url;

	/** The user id. */
	private int user_id;
	
	private boolean content_origins;
    
	private int franchisor_id;

	
	public int getFranchisor_id() {
	
		return franchisor_id;
	}


	
	public void setFranchisor_id(int franchisor_id) {
	
		this.franchisor_id = franchisor_id;
	}

	
	public boolean isContent_origins() {
	
		return content_origins;
	}

	
	public void setContent_origins(boolean content_origins) {
	
		this.content_origins = content_origins;
	}


	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public int getUser_id() {

		return user_id;
	}

	/**
	 * Sets the user id.
	 *
	 * @param user_id the new user id
	 */
	public void setUser_id(int user_id) {

		this.user_id = user_id;
	}

	/**
	 * Gets the account list.
	 *
	 * @return the account list
	 */
	public AccountsList getAccount_list() {

		return account_list;
	}

	/**
	 * Sets the account list.
	 *
	 * @param account_list the new account list
	 */
	public void setAccount_list(AccountsList account_list) {

		this.account_list = account_list;
	}

	/**
	 * Checks if is auto schedule.
	 *
	 * @return true, if is auto schedule
	 */
	public boolean isAuto_schedule() {

		return auto_schedule;
	}

	/**
	 * Sets the auto schedule.
	 *
	 * @param auto_schedule the new auto schedule
	 */
	public void setAuto_schedule(boolean auto_schedule) {

		this.auto_schedule = auto_schedule;
	}

	/**
	 * Gets the boost offer id.
	 *
	 * @return the boost offer id
	 */
	public int getBoost_offer_id() {

		return boost_offer_id;
	}

	/**
	 * Sets the boost offer id.
	 *
	 * @param boost_offer_id the new boost offer id
	 */
	public void setBoost_offer_id(int boost_offer_id) {

		this.boost_offer_id = boost_offer_id;
	}

	/**
	 * Checks if is can edit.
	 *
	 * @return true, if is can edit
	 */
	public boolean isCan_edit() {

		return can_edit;
	}

	/**
	 * Sets the can edit.
	 *
	 * @param can_edit the new can edit
	 */
	public void setCan_edit(boolean can_edit) {

		this.can_edit = can_edit;
	}

	/**
	 * Gets the created at.
	 *
	 * @return the created at
	 */
	public String getCreated_at() {

		return created_at;
	}

	/**
	 * Sets the created at.
	 *
	 * @param created_at the new created at
	 */
	public void setCreated_at(String created_at) {

		this.created_at = created_at;
	}

	/**
	 * Gets the created user.
	 *
	 * @return the created user
	 */
	public User getCreated_user() {

		return created_user;
	}

	/**
	 * Sets the created user.
	 *
	 * @param created_user the new created user
	 */
	public void setCreated_user(User created_user) {

		this.created_user = created_user;
	}

	/**
	 * Checks if is date range locked.
	 *
	 * @return true, if is date range locked
	 */
	public boolean isDate_range_locked() {

		return date_range_locked;
	}

	/**
	 * Sets the date range locked.
	 *
	 * @param date_range_locked the new date range locked
	 */
	public void setDate_range_locked(boolean date_range_locked) {

		this.date_range_locked = date_range_locked;
	}

	/**
	 * Checks if is delete from platforms after expiry.
	 *
	 * @return true, if is delete from platforms after expiry
	 */
	public boolean isDelete_from_platforms_after_expiry() {

		return delete_from_platforms_after_expiry;
	}

	/**
	 * Sets the delete from platforms after expiry.
	 *
	 * @param delete_from_platforms_after_expiry the new delete from platforms
	 *            after expiry
	 */
	public void setDelete_from_platforms_after_expiry(boolean delete_from_platforms_after_expiry) {

		this.delete_from_platforms_after_expiry = delete_from_platforms_after_expiry;
	}

	/**
	 * Checks if is disabled.
	 *
	 * @return true, if is disabled
	 */
	public boolean isDisabled() {

		return disabled;
	}

	/**
	 * Sets the disabled.
	 *
	 * @param disabled the new disabled
	 */
	public void setDisabled(boolean disabled) {

		this.disabled = disabled;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public String getEnd_date() {

		return end_date;
	}

	/**
	 * Sets the end date.
	 *
	 * @param end_date the new end date
	 */
	public void setEnd_date(String end_date) {

		this.end_date = end_date;
	}

	/**
	 * Gets the facebook text.
	 *
	 * @return the facebook text
	 */
	public String getFacebook_text() {

		return facebook_text;
	}

	/**
	 * Sets the facebook text.
	 *
	 * @param facebook_text the new facebook text
	 */
	public void setFacebook_text(String facebook_text) {

		this.facebook_text = facebook_text;
	}

	/**
	 * Gets the franchisor.
	 *
	 * @return the franchisor
	 */
	public Franchisors getFranchisor() {

		return franchisor;
	}

	/**
	 * Sets the franchisor.
	 *
	 * @param franchisor the new franchisor
	 */
	public void setFranchisor(Franchisors franchisor) {

		this.franchisor = franchisor;
	}

	/**
	 * Gets the franchisor list.
	 *
	 * @return the franchisor list
	 */
	public FranchisorList getFranchisor_list() {

		return franchisor_list;
	}

	/**
	 * Sets the franchisor list.
	 *
	 * @param franchisor_list the new franchisor list
	 */
	public void setFranchisor_list(FranchisorList franchisor_list) {

		this.franchisor_list = franchisor_list;
	}

	/**
	 * Gets the google text.
	 *
	 * @return the google text
	 */
	public String getGoogle_text() {

		return google_text;
	}

	/**
	 * Sets the google text.
	 *
	 * @param google_text the new google text
	 */
	public void setGoogle_text(String google_text) {

		this.google_text = google_text;
	}

	/**
	 * Checks if is checks for parent.
	 *
	 * @return true, if is checks for parent
	 */
	public boolean isHas_parent() {

		return has_parent;
	}

	/**
	 * Sets the checks for parent.
	 *
	 * @param has_parent the new checks for parent
	 */
	public void setHas_parent(boolean has_parent) {

		this.has_parent = has_parent;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/**
	 * Gets the instagram text.
	 *
	 * @return the instagram text
	 */
	public String getInstagram_text() {

		return instagram_text;
	}

	/**
	 * Sets the instagram text.
	 *
	 * @param instagram_text the new instagram text
	 */
	public void setInstagram_text(String instagram_text) {

		this.instagram_text = instagram_text;
	}

	/**
	 * Gets the link id.
	 *
	 * @return the link id
	 */
	public String getLink_id() {

		return link_id;
	}

	/**
	 * Sets the link id.
	 *
	 * @param link_id the new link id
	 */
	public void setLink_id(String link_id) {

		this.link_id = link_id;
	}

	/**
	 * Gets the linkedin text.
	 *
	 * @return the linkedin text
	 */
	public String getLinkedin_text() {

		return linkedin_text;
	}

	/**
	 * Sets the linkedin text.
	 *
	 * @param linkedin_text the new linkedin text
	 */
	public void setLinkedin_text(String linkedin_text) {

		this.linkedin_text = linkedin_text;
	}

	/**
	 * Gets the links.
	 *
	 * @return the links
	 */
	public Links getLinks() {

		return links;
	}

	/**
	 * Sets the links.
	 *
	 * @param links the new links
	 */
	public void setLinks(Links links) {

		this.links = links;
	}

	/**
	 * Checks if is lock descendants.
	 *
	 * @return true, if is lock descendants
	 */
	public boolean isLock_descendants() {

		return lock_descendants;
	}

	/**
	 * Sets the lock descendants.
	 *
	 * @param lock_descendants the new lock descendants
	 */
	public void setLock_descendants(boolean lock_descendants) {

		this.lock_descendants = lock_descendants;
	}

	/**
	 * Checks if is locked.
	 *
	 * @return true, if is locked
	 */
	public boolean isLocked() {

		return locked;
	}

	/**
	 * Sets the locked.
	 *
	 * @param locked the new locked
	 */
	public void setLocked(boolean locked) {

		this.locked = locked;
	}

	/**
	 * Checks if is mobile app only enabled.
	 *
	 * @return true, if is mobile app only enabled
	 */
	public boolean isMobile_app_only_enabled() {

		return mobile_app_only_enabled;
	}

	/**
	 * Sets the mobile app only enabled.
	 *
	 * @param mobile_app_only_enabled the new mobile app only enabled
	 */
	public void setMobile_app_only_enabled(boolean mobile_app_only_enabled) {

		this.mobile_app_only_enabled = mobile_app_only_enabled;
	}

	/**
	 * Gets the moderation status.
	 *
	 * @return the moderation status
	 */
	public String getModeration_status() {

		return moderation_status;
	}

	/**
	 * Sets the moderation status.
	 *
	 * @param moderation_status the new moderation status
	 */
	public void setModeration_status(String moderation_status) {

		this.moderation_status = moderation_status;
	}

	/**
	 * Gets the personalized facebook text.
	 *
	 * @return the personalized facebook text
	 */
	public String getPersonalized_facebook_text() {

		return personalized_facebook_text;
	}

	/**
	 * Sets the personalized facebook text.
	 *
	 * @param personalized_facebook_text the new personalized facebook text
	 */
	public void setPersonalized_facebook_text(String personalized_facebook_text) {

		this.personalized_facebook_text = personalized_facebook_text;
	}

	/**
	 * Gets the personalized google text.
	 *
	 * @return the personalized google text
	 */
	public String getPersonalized_google_text() {

		return personalized_google_text;
	}

	/**
	 * Sets the personalized google text.
	 *
	 * @param personalized_google_text the new personalized google text
	 */
	public void setPersonalized_google_text(String personalized_google_text) {

		this.personalized_google_text = personalized_google_text;
	}

	/**
	 * Gets the personalized instagram text.
	 *
	 * @return the personalized instagram text
	 */
	public String getPersonalized_instagram_text() {

		return personalized_instagram_text;
	}

	/**
	 * Sets the personalized instagram text.
	 *
	 * @param personalized_instagram_text the new personalized instagram text
	 */
	public void setPersonalized_instagram_text(String personalized_instagram_text) {

		this.personalized_instagram_text = personalized_instagram_text;
	}

	/**
	 * Gets the personalized linkedin text.
	 *
	 * @return the personalized linkedin text
	 */
	public String getPersonalized_linkedin_text() {

		return personalized_linkedin_text;
	}

	/**
	 * Sets the personalized linkedin text.
	 *
	 * @param personalized_linkedin_text the new personalized linkedin text
	 */
	public void setPersonalized_linkedin_text(String personalized_linkedin_text) {

		this.personalized_linkedin_text = personalized_linkedin_text;
	}

	/**
	 * Gets the personalized twitter text.
	 *
	 * @return the personalized twitter text
	 */
	public String getPersonalized_twitter_text() {

		return personalized_twitter_text;
	}

	/**
	 * Sets the personalized twitter text.
	 *
	 * @param personalized_twitter_text the new personalized twitter text
	 */
	public void setPersonalized_twitter_text(String personalized_twitter_text) {

		this.personalized_twitter_text = personalized_twitter_text;
	}

	/**
	 * Gets the photo id.
	 *
	 * @return the photo id
	 */
	public int getPhoto_id() {

		return photo_id;
	}

	/**
	 * Sets the photo id.
	 *
	 * @param photo_id the new photo id
	 */
	public void setPhoto_id(int photo_id) {

		this.photo_id = photo_id;
	}

	/**
	 * Gets the photo ids.
	 *
	 * @return the photo ids
	 */
	public List<Integer> getPhoto_ids() {

		return photo_ids;
	}

	/**
	 * Sets the photo ids.
	 *
	 * @param photo_ids the new photo ids
	 */
	public void setPhoto_ids(List<Integer> photo_ids) {

		this.photo_ids = photo_ids;
	}

	/**
	 * Gets the photo urls.
	 *
	 * @return the photo urls
	 */
	public List<String> getPhoto_urls() {

		return photo_urls;
	}

	/**
	 * Sets the photo urls.
	 *
	 * @param photo_urls the new photo urls
	 */
	public void setPhoto_urls(List<String> photo_urls) {

		this.photo_urls = photo_urls;
	}

	/**
	 * Gets the post published count.
	 *
	 * @return the post published count
	 */
	public int getPost_published_count() {

		return post_published_count;
	}

	/**
	 * Sets the post published count.
	 *
	 * @param post_published_count the new post published count
	 */
	public void setPost_published_count(int post_published_count) {

		this.post_published_count = post_published_count;
	}

	/**
	 * Checks if is repeat.
	 *
	 * @return true, if is repeat
	 */
	public boolean isRepeat() {

		return repeat;
	}

	/**
	 * Sets the repeat.
	 *
	 * @param repeat the new repeat
	 */
	public void setRepeat(boolean repeat) {

		this.repeat = repeat;
	}

	/**
	 * Checks if is scheduled anywhere.
	 *
	 * @return true, if is scheduled anywhere
	 */
	public boolean isScheduled_anywhere() {

		return scheduled_anywhere;
	}

	/**
	 * Sets the scheduled anywhere.
	 *
	 * @param scheduled_anywhere the new scheduled anywhere
	 */
	public void setScheduled_anywhere(boolean scheduled_anywhere) {

		this.scheduled_anywhere = scheduled_anywhere;
	}

	/**
	 * Checks if is sent to franchisor.
	 *
	 * @return true, if is sent to franchisor
	 */
	public boolean isSent_to_franchisor() {

		return sent_to_franchisor;
	}

	/**
	 * Sets the sent to franchisor.
	 *
	 * @param sent_to_franchisor the new sent to franchisor
	 */
	public void setSent_to_franchisor(boolean sent_to_franchisor) {

		this.sent_to_franchisor = sent_to_franchisor;
	}

	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public String getStart_date() {

		return start_date;
	}

	/**
	 * Sets the start date.
	 *
	 * @param start_date the new start date
	 */
	public void setStart_date(String start_date) {

		this.start_date = start_date;
	}

	/**
	 * Gets the status id.
	 *
	 * @return the status id
	 */
	public int getStatus_id() {

		return status_id;
	}

	/**
	 * Sets the status id.
	 *
	 * @param status_id the new status id
	 */
	public void setStatus_id(int status_id) {

		this.status_id = status_id;
	}

	/**
	 * Checks if is syndicate to account databases.
	 *
	 * @return true, if is syndicate to account databases
	 */
	public boolean isSyndicate_to_account_databases() {

		return syndicate_to_account_databases;
	}

	/**
	 * Sets the syndicate to account databases.
	 *
	 * @param syndicate_to_account_databases the new syndicate to account
	 *            databases
	 */
	public void setSyndicate_to_account_databases(boolean syndicate_to_account_databases) {

		this.syndicate_to_account_databases = syndicate_to_account_databases;
	}

	/**
	 * Gets the tags list.
	 *
	 * @return the tags list
	 */
	public String getTags_list() {

		return tags_list;
	}

	/**
	 * Sets the tags list.
	 *
	 * @param tags_list the new tags list
	 */
	public void setTags_list(String tags_list) {

		this.tags_list = tags_list;
	}

	/**
	 * Gets the tone cautionary.
	 *
	 * @return the tone cautionary
	 */
	public int getTone_cautionary() {

		return tone_cautionary;
	}

	/**
	 * Sets the tone cautionary.
	 *
	 * @param tone_cautionary the new tone cautionary
	 */
	public void setTone_cautionary(int tone_cautionary) {

		this.tone_cautionary = tone_cautionary;
	}

	/**
	 * Gets the tone educational.
	 *
	 * @return the tone educational
	 */
	public int getTone_educational() {

		return tone_educational;
	}

	/**
	 * Sets the tone educational.
	 *
	 * @param tone_educational the new tone educational
	 */
	public void setTone_educational(int tone_educational) {

		this.tone_educational = tone_educational;
	}

	/**
	 * Gets the tone empathetic.
	 *
	 * @return the tone empathetic
	 */
	public int getTone_empathetic() {

		return tone_empathetic;
	}

	/**
	 * Sets the tone empathetic.
	 *
	 * @param tone_empathetic the new tone empathetic
	 */
	public void setTone_empathetic(int tone_empathetic) {

		this.tone_empathetic = tone_empathetic;
	}

	/**
	 * Gets the tone engaging.
	 *
	 * @return the tone engaging
	 */
	public int getTone_engaging() {

		return tone_engaging;
	}

	/**
	 * Sets the tone engaging.
	 *
	 * @param tone_engaging the new tone engaging
	 */
	public void setTone_engaging(int tone_engaging) {

		this.tone_engaging = tone_engaging;
	}

	/**
	 * Gets the tone humorous.
	 *
	 * @return the tone humorous
	 */
	public int getTone_humorous() {

		return tone_humorous;
	}

	/**
	 * Sets the tone humorous.
	 *
	 * @param tone_humorous the new tone humorous
	 */
	public void setTone_humorous(int tone_humorous) {

		this.tone_humorous = tone_humorous;
	}

	/**
	 * Gets the tone inspirational.
	 *
	 * @return the tone inspirational
	 */
	public int getTone_inspirational() {

		return tone_inspirational;
	}

	/**
	 * Sets the tone inspirational.
	 *
	 * @param tone_inspirational the new tone inspirational
	 */
	public void setTone_inspirational(int tone_inspirational) {

		this.tone_inspirational = tone_inspirational;
	}

	/**
	 * Gets the tone professional.
	 *
	 * @return the tone professional
	 */
	public int getTone_professional() {

		return tone_professional;
	}

	/**
	 * Sets the tone professional.
	 *
	 * @param tone_professional the new tone professional
	 */
	public void setTone_professional(int tone_professional) {

		this.tone_professional = tone_professional;
	}

	/**
	 * Gets the tone quirky.
	 *
	 * @return the tone quirky
	 */
	public int getTone_quirky() {

		return tone_quirky;
	}

	/**
	 * Sets the tone quirky.
	 *
	 * @param tone_quirky the new tone quirky
	 */
	public void setTone_quirky(int tone_quirky) {

		this.tone_quirky = tone_quirky;
	}

	/**
	 * Checks if is trashed.
	 *
	 * @return true, if is trashed
	 */
	public boolean isTrashed() {

		return trashed;
	}

	/**
	 * Sets the trashed.
	 *
	 * @param trashed the new trashed
	 */
	public void setTrashed(boolean trashed) {

		this.trashed = trashed;
	}

	/**
	 * Gets the twitter text.
	 *
	 * @return the twitter text
	 */
	public String getTwitter_text() {

		return twitter_text;
	}

	/**
	 * Sets the twitter text.
	 *
	 * @param twitter_text the new twitter text
	 */
	public void setTwitter_text(String twitter_text) {

		this.twitter_text = twitter_text;
	}

	/**
	 * Gets the updated at.
	 *
	 * @return the updated at
	 */
	public String getUpdated_at() {

		return updated_at;
	}

	/**
	 * Sets the updated at.
	 *
	 * @param updated_at the new updated at
	 */
	public void setUpdated_at(String updated_at) {

		this.updated_at = updated_at;
	}

	/**
	 * Checks if is use facebook.
	 *
	 * @return true, if is use facebook
	 */
	public boolean isUse_facebook() {

		return use_facebook;
	}

	/**
	 * Sets the use facebook.
	 *
	 * @param use_facebook the new use facebook
	 */
	public void setUse_facebook(boolean use_facebook) {

		this.use_facebook = use_facebook;
	}

	/**
	 * Checks if is use google.
	 *
	 * @return true, if is use google
	 */
	public boolean isUse_google() {

		return use_google;
	}

	/**
	 * Sets the use google.
	 *
	 * @param use_google the new use google
	 */
	public void setUse_google(boolean use_google) {

		this.use_google = use_google;
	}

	/**
	 * Checks if is use instagram.
	 *
	 * @return true, if is use instagram
	 */
	public boolean isUse_instagram() {

		return use_instagram;
	}

	/**
	 * Sets the use instagram.
	 *
	 * @param use_instagram the new use instagram
	 */
	public void setUse_instagram(boolean use_instagram) {

		this.use_instagram = use_instagram;
	}

	/**
	 * Checks if is use linkedin.
	 *
	 * @return true, if is use linkedin
	 */
	public boolean isUse_linkedin() {

		return use_linkedin;
	}

	/**
	 * Sets the use linkedin.
	 *
	 * @param use_linkedin the new use linkedin
	 */
	public void setUse_linkedin(boolean use_linkedin) {

		this.use_linkedin = use_linkedin;
	}

	/**
	 * Checks if is use shortened link.
	 *
	 * @return true, if is use shortened link
	 */
	public boolean isUse_shortened_link() {

		return use_shortened_link;
	}

	/**
	 * Sets the use shortened link.
	 *
	 * @param use_shortened_link the new use shortened link
	 */
	public void setUse_shortened_link(boolean use_shortened_link) {

		this.use_shortened_link = use_shortened_link;
	}

	/**
	 * Checks if is use twitter.
	 *
	 * @return true, if is use twitter
	 */
	public boolean isUse_twitter() {

		return use_twitter;
	}

	/**
	 * Sets the use twitter.
	 *
	 * @param use_twitter the new use twitter
	 */
	public void setUse_twitter(boolean use_twitter) {

		this.use_twitter = use_twitter;
	}

	/**
	 * Checks if is use twitter photo.
	 *
	 * @return true, if is use twitter photo
	 */
	public boolean isUse_twitter_photo() {

		return use_twitter_photo;
	}

	/**
	 * Sets the use twitter photo.
	 *
	 * @param use_twitter_photo the new use twitter photo
	 */
	public void setUse_twitter_photo(boolean use_twitter_photo) {

		this.use_twitter_photo = use_twitter_photo;
	}

	/**
	 * Gets the verticals list.
	 *
	 * @return the verticals list
	 */
	public String getVerticals_list() {

		return verticals_list;
	}

	/**
	 * Sets the verticals list.
	 *
	 * @param verticals_list the new verticals list
	 */
	public void setVerticals_list(String verticals_list) {

		this.verticals_list = verticals_list;
	}

	/**
	 * Gets the video id.
	 *
	 * @return the video id
	 */
	public String getVideo_id() {

		return video_id;
	}

	/**
	 * Sets the video id.
	 *
	 * @param video_id the new video id
	 */
	public void setVideo_id(String video_id) {

		this.video_id = video_id;
	}

	/**
	 * Gets the video url.
	 *
	 * @return the video url
	 */
	public String getVideo_url() {

		return video_url;
	}

	/**
	 * Sets the video url.
	 *
	 * @param video_url the new video url
	 */
	public void setVideo_url(String video_url) {

		this.video_url = video_url;
	}

}

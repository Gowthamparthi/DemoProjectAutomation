package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

// TODO: Auto-generated Javadoc
/**
 * The Class TotalScore.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class TotalScore {

	/** The overall score. */
	private List<LeaderBoardList> overall_score;

	/** The total overall score. */
	private String total_overall_score;

	/**
	 * Gets the overall score.
	 *
	 * @return the overall score
	 */
	public List<LeaderBoardList> getOverall_score() {

		return overall_score;
	}

	/**
	 * Sets the overall score.
	 *
	 * @param overall_score the new overall score
	 */
	public void setOverall_score(List<LeaderBoardList> overall_score) {

		this.overall_score = overall_score;
	}

	/**
	 * Gets the total overall score.
	 *
	 * @return the total overall score
	 */
	public String getTotal_overall_score() {

		return total_overall_score;
	}

	/**
	 * Sets the total overall score.
	 *
	 * @param total_overall_score the new total overall score
	 */
	public void setTotal_overall_score(String total_overall_score) {

		this.total_overall_score = total_overall_score;
	}

}

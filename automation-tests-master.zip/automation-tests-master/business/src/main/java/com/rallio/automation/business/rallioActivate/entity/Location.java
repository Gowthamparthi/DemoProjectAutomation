package com.rallio.automation.business.rallioActivate.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class Location.
 */
public class Location {

	/** The name. */
	private String name;

	/** The account id. */
	private String account_id;

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {

		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {

		this.name = name;
	}

	/**
	 * Gets the account id.
	 *
	 * @return the account id
	 */
	public String getAccount_id() {

		return account_id;
	}

	/**
	 * Sets the account id.
	 *
	 * @param account_id the new account id
	 */
	public void setAccount_id(String account_id) {

		this.account_id = account_id;
	}

}

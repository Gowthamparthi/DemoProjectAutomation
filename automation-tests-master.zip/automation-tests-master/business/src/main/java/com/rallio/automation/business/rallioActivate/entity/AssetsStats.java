package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class AssetsStats.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssetsStats {

	/** The recent media assets count. */
	private int recent_media_assets_count;

	/** The total assets count. */
	private int total_assets_count;

	/** The used assets count. */
	private int used_assets_count;

	/** The recent media assets submitted date. */
	private String recent_media_assets_submitted_date;

	/**
	 * Gets the recent media assets count.
	 *
	 * @return the recent media assets count
	 */
	public int getRecent_media_assets_count() {

		return recent_media_assets_count;
	}

	/**
	 * Sets the recent media assets count.
	 *
	 * @param recent_media_assets_count the new recent media assets count
	 */
	public void setRecent_media_assets_count(int recent_media_assets_count) {

		this.recent_media_assets_count = recent_media_assets_count;
	}

	/**
	 * Gets the total assets count.
	 *
	 * @return the total assets count
	 */
	public int getTotal_assets_count() {

		return total_assets_count;
	}

	/**
	 * Sets the total assets count.
	 *
	 * @param total_assets_count the new total assets count
	 */
	public void setTotal_assets_count(int total_assets_count) {

		this.total_assets_count = total_assets_count;
	}

	/**
	 * Gets the used assets count.
	 *
	 * @return the used assets count
	 */
	public int getUsed_assets_count() {

		return used_assets_count;
	}

	/**
	 * Sets the used assets count.
	 *
	 * @param used_assets_count the new used assets count
	 */
	public void setUsed_assets_count(int used_assets_count) {

		this.used_assets_count = used_assets_count;
	}

	/**
	 * Gets the recent media assets submitted date.
	 *
	 * @return the recent media assets submitted date
	 */
	public String getRecent_media_assets_submitted_date() {

		return recent_media_assets_submitted_date;
	}

	/**
	 * Sets the recent media assets submitted date.
	 *
	 * @param recent_media_assets_submitted_date the new recent media assets
	 *            submitted date
	 */
	public void setRecent_media_assets_submitted_date(String recent_media_assets_submitted_date) {

		this.recent_media_assets_submitted_date = recent_media_assets_submitted_date;
	}

}

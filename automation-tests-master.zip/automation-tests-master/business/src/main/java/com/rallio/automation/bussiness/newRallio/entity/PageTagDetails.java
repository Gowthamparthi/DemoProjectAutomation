package com.rallio.automation.bussiness.newRallio.entity;

/**
 * The Class PageTagDetails.
 */
public class PageTagDetails {

}

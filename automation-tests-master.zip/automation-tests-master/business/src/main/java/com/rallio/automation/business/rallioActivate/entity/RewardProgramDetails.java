package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class RewardProgramDetails.
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class RewardProgramDetails {

	@Override
	public String toString() {

		return "RewardProgramDetails [accountId=" + accountId + ", accountName=" + accountName + ", address=" + address + ", adminEmail=" + adminEmail + ", createdAt=" + createdAt
		        + ", duration=" + duration + ", emailInvitationMessage=" + emailInvitationMessage + ", emailNotificationLastModified=" + emailNotificationLastModified
		        + ", emailNotificationStatus=" + emailNotificationStatus + ", endafter=" + endafter + ", endDate=" + endDate + ", franchisorId=" + franchisorId
		        + ", franchisorName=" + franchisorName + ", name=" + name + ", occurrences=" + occurrences + ", programBudget=" + programBudget + ", programDuration="
		        + programDuration + ", programId=" + programId + ", recommendedType=" + recommendedType + ", recurringPaymentSubscriptionId=" + recurringPaymentSubscriptionId
		        + ", rewardEmailLogoUrl=" + rewardEmailLogoUrl + ", rewardEmailScheduleDate=" + rewardEmailScheduleDate + ", rewardsType=" + rewardsType + ", rewardTimezone="
		        + rewardTimezone + ", stage=" + stage + ", startDate=" + startDate + ", typeCode=" + typeCode + ", selectedLocationCount=" + selectedLocationCount
		        + ", achieversCount=" + achieversCount + ", programBudgetSpent=" + programBudgetSpent + ", userId=" + userId + ", userName=" + userName + "]";
	}

	/** The account id. */
	private int accountId;

	/** The account name. */
	private String accountName;

	/** The address. */
	private String address;

	/** The admin email. */
	private String adminEmail;

	/** The created at. */
	private String createdAt;

	/** The duration. */
	private int duration;

	/** The email invitation message. */
	private String emailInvitationMessage;

	/** The email notification last modified. */
	private String emailNotificationLastModified;

	/** The email notification status. */
	private int emailNotificationStatus;

	/** The endafter. */
	private int endafter;

	/** The end date. */
	private String endDate;

	/** The franchisor id. */
	private int franchisorId;

	/** The franchisor name. */
	private String franchisorName;

	/** The name. */
	private String name;

	/** The occurrences. */
	private int occurrences;

	/** The program budget. */
	private String programBudget;

	/** The program duration. */
	private int programDuration;

	/** The program id. */
	private int programId;

	/** The recommended type. */
	private int recommendedType;

	/** The recurring payment subscription id. */
	private String recurringPaymentSubscriptionId;

	/** The reward email logo url. */
	private String rewardEmailLogoUrl;

	/** The reward email schedule date. */
	private String rewardEmailScheduleDate;

	/** The rewards type. */
	private int rewardsType;

	/** The reward timezone. */
	private String rewardTimezone;

	/** The stage. */
	private int stage;

	/** The start date. */
	private String startDate;

	/** The type code. */
	private int typeCode;

	/** The selected location count. */
	private int selectedLocationCount;

	/**
	 * Gets the selected location count.
	 *
	 * @return the selected location count
	 */
	public int getSelectedLocationCount() {

		return selectedLocationCount;
	}

	/**
	 * Sets the selected location count.
	 *
	 * @param selectedLocationCount the new selected location count
	 */
	public void setSelectedLocationCount(int selectedLocationCount) {

		this.selectedLocationCount = selectedLocationCount;
	}

	/**
	 * Gets the achievers count.
	 *
	 * @return the achievers count
	 */
	public int getAchieversCount() {

		return achieversCount;
	}

	/**
	 * Sets the achievers count.
	 *
	 * @param achieversCount the new achievers count
	 */
	public void setAchieversCount(int achieversCount) {

		this.achieversCount = achieversCount;
	}

	/** The achievers count. */
	private int achieversCount;

	/**
	 * Gets the program budget spent.
	 *
	 * @return the program budget spent
	 */
	public String getProgramBudgetSpent() {

		return programBudgetSpent;
	}

	/**
	 * Sets the program budget spent.
	 *
	 * @param programBudgetSpent the new program budget spent
	 */
	public void setProgramBudgetSpent(String programBudgetSpent) {

		this.programBudgetSpent = programBudgetSpent;
	}

	/** The program budget spent. */
	private String programBudgetSpent;

	/**
	 * Gets the account id.
	 *
	 * @return the account id
	 */
	public int getAccountId() {

		return accountId;
	}

	/**
	 * Sets the account id.
	 *
	 * @param accountId the new account id
	 */
	public void setAccountId(int accountId) {

		this.accountId = accountId;
	}

	/**
	 * Gets the account name.
	 *
	 * @return the account name
	 */
	public String getAccountName() {

		return accountName;
	}

	/**
	 * Sets the account name.
	 *
	 * @param accountName the new account name
	 */
	public void setAccountName(String accountName) {

		this.accountName = accountName;
	}

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public String getAddress() {

		return address;
	}

	/**
	 * Sets the address.
	 *
	 * @param address the new address
	 */
	public void setAddress(String address) {

		this.address = address;
	}

	/**
	 * Gets the admin email.
	 *
	 * @return the admin email
	 */
	public String getAdminEmail() {

		return adminEmail;
	}

	/**
	 * Sets the admin email.
	 *
	 * @param adminEmail the new admin email
	 */
	public void setAdminEmail(String adminEmail) {

		this.adminEmail = adminEmail;
	}

	/**
	 * Gets the created at.
	 *
	 * @return the created at
	 */
	public String getCreatedAt() {

		return createdAt;
	}

	/**
	 * Sets the created at.
	 *
	 * @param createdAt the new created at
	 */
	public void setCreatedAt(String createdAt) {

		this.createdAt = createdAt;
	}

	/**
	 * Gets the duration.
	 *
	 * @return the duration
	 */
	public int getDuration() {

		return duration;
	}

	/**
	 * Sets the duration.
	 *
	 * @param duration the new duration
	 */
	public void setDuration(int duration) {

		this.duration = duration;
	}

	/**
	 * Gets the email invitation message.
	 *
	 * @return the email invitation message
	 */
	public String getEmailInvitationMessage() {

		return emailInvitationMessage;
	}

	/**
	 * Sets the email invitation message.
	 *
	 * @param emailInvitationMessage the new email invitation message
	 */
	public void setEmailInvitationMessage(String emailInvitationMessage) {

		this.emailInvitationMessage = emailInvitationMessage;
	}

	/**
	 * Gets the email notification last modified.
	 *
	 * @return the email notification last modified
	 */
	public String getEmailNotificationLastModified() {

		return emailNotificationLastModified;
	}

	/**
	 * Sets the email notification last modified.
	 *
	 * @param emailNotificationLastModified the new email notification last
	 *            modified
	 */
	public void setEmailNotificationLastModified(String emailNotificationLastModified) {

		this.emailNotificationLastModified = emailNotificationLastModified;
	}

	/**
	 * Gets the email notification status.
	 *
	 * @return the email notification status
	 */
	public int getEmailNotificationStatus() {

		return emailNotificationStatus;
	}

	/**
	 * Sets the email notification status.
	 *
	 * @param emailNotificationStatus the new email notification status
	 */
	public void setEmailNotificationStatus(int emailNotificationStatus) {

		this.emailNotificationStatus = emailNotificationStatus;
	}

	/**
	 * Gets the endafter.
	 *
	 * @return the endafter
	 */
	public int getEndafter() {

		return endafter;
	}

	/**
	 * Sets the endafter.
	 *
	 * @param endafter the new endafter
	 */
	public void setEndafter(int endafter) {

		this.endafter = endafter;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public String getEndDate() {

		return endDate;
	}

	/**
	 * Sets the end date.
	 *
	 * @param endDate the new end date
	 */
	public void setEndDate(String endDate) {

		this.endDate = endDate;
	}

	/**
	 * Gets the franchisor id.
	 *
	 * @return the franchisor id
	 */
	public int getFranchisorId() {

		return franchisorId;
	}

	/**
	 * Sets the franchisor id.
	 *
	 * @param franchisorId the new franchisor id
	 */
	public void setFranchisorId(int franchisorId) {

		this.franchisorId = franchisorId;
	}

	/**
	 * Gets the franchisor name.
	 *
	 * @return the franchisor name
	 */
	public String getFranchisorName() {

		return franchisorName;
	}

	/**
	 * Sets the franchisor name.
	 *
	 * @param franchisorName the new franchisor name
	 */
	public void setFranchisorName(String franchisorName) {

		this.franchisorName = franchisorName;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {

		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {

		this.name = name;
	}

	/**
	 * Gets the occurrences.
	 *
	 * @return the occurrences
	 */
	public int getOccurrences() {

		return occurrences;
	}

	/**
	 * Sets the occurrences.
	 *
	 * @param occurrences the new occurrences
	 */
	public void setOccurrences(int occurrences) {

		this.occurrences = occurrences;
	}

	/**
	 * Gets the program budget.
	 *
	 * @return the program budget
	 */
	public String getProgramBudget() {

		return programBudget;
	}

	/**
	 * Sets the program budget.
	 *
	 * @param programBudget the new program budget
	 */
	public void setProgramBudget(String programBudget) {

		this.programBudget = programBudget;
	}

	/**
	 * Gets the program duration.
	 *
	 * @return the program duration
	 */
	public int getProgramDuration() {

		return programDuration;
	}

	/**
	 * Sets the program duration.
	 *
	 * @param programDuration the new program duration
	 */
	public void setProgramDuration(int programDuration) {

		this.programDuration = programDuration;
	}

	/**
	 * Gets the program id.
	 *
	 * @return the program id
	 */
	public int getProgramId() {

		return programId;
	}

	/**
	 * Sets the program id.
	 *
	 * @param programId the new program id
	 */
	public void setProgramId(int programId) {

		this.programId = programId;
	}

	/**
	 * Gets the recommended type.
	 *
	 * @return the recommended type
	 */
	public int getRecommendedType() {

		return recommendedType;
	}

	/**
	 * Sets the recommended type.
	 *
	 * @param recommendedType the new recommended type
	 */
	public void setRecommendedType(int recommendedType) {

		this.recommendedType = recommendedType;
	}

	/**
	 * Gets the recurring payment subscription id.
	 *
	 * @return the recurring payment subscription id
	 */
	public String getRecurringPaymentSubscriptionId() {

		return recurringPaymentSubscriptionId;
	}

	/**
	 * Sets the recurring payment subscription id.
	 *
	 * @param recurringPaymentSubscriptionId the new recurring payment
	 *            subscription id
	 */
	public void setRecurringPaymentSubscriptionId(String recurringPaymentSubscriptionId) {

		this.recurringPaymentSubscriptionId = recurringPaymentSubscriptionId;
	}

	/**
	 * Gets the reward email logo url.
	 *
	 * @return the reward email logo url
	 */
	public String getRewardEmailLogoUrl() {

		return rewardEmailLogoUrl;
	}

	/**
	 * Sets the reward email logo url.
	 *
	 * @param rewardEmailLogoUrl the new reward email logo url
	 */
	public void setRewardEmailLogoUrl(String rewardEmailLogoUrl) {

		this.rewardEmailLogoUrl = rewardEmailLogoUrl;
	}

	/**
	 * Gets the reward email schedule date.
	 *
	 * @return the reward email schedule date
	 */
	public String getRewardEmailScheduleDate() {

		return rewardEmailScheduleDate;
	}

	/**
	 * Sets the reward email schedule date.
	 *
	 * @param rewardEmailScheduleDate the new reward email schedule date
	 */
	public void setRewardEmailScheduleDate(String rewardEmailScheduleDate) {

		this.rewardEmailScheduleDate = rewardEmailScheduleDate;
	}

	/**
	 * Gets the rewards type.
	 *
	 * @return the rewards type
	 */
	public int getRewardsType() {

		return rewardsType;
	}

	/**
	 * Sets the rewards type.
	 *
	 * @param rewardsType the new rewards type
	 */
	public void setRewardsType(int rewardsType) {

		this.rewardsType = rewardsType;
	}

	/**
	 * Gets the reward timezone.
	 *
	 * @return the reward timezone
	 */
	public String getRewardTimezone() {

		return rewardTimezone;
	}

	/**
	 * Sets the reward timezone.
	 *
	 * @param rewardTimezone the new reward timezone
	 */
	public void setRewardTimezone(String rewardTimezone) {

		this.rewardTimezone = rewardTimezone;
	}

	/**
	 * Gets the stage.
	 *
	 * @return the stage
	 */
	public int getStage() {

		return stage;
	}

	/**
	 * Sets the stage.
	 *
	 * @param stage the new stage
	 */
	public void setStage(int stage) {

		this.stage = stage;
	}

	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public String getStartDate() {

		return startDate;
	}

	/**
	 * Sets the start date.
	 *
	 * @param startDate the new start date
	 */
	public void setStartDate(String startDate) {

		this.startDate = startDate;
	}

	/**
	 * Gets the type code.
	 *
	 * @return the type code
	 */
	public int getTypeCode() {

		return typeCode;
	}

	/**
	 * Sets the type code.
	 *
	 * @param typeCode the new type code
	 */
	public void setTypeCode(int typeCode) {

		this.typeCode = typeCode;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public int getUserId() {

		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(int userId) {

		this.userId = userId;
	}

	/**
	 * Gets the user name.
	 *
	 * @return the user name
	 */
	public String getUserName() {

		return userName;
	}

	/**
	 * Sets the user name.
	 *
	 * @param userName the new user name
	 */
	public void setUserName(String userName) {

		this.userName = userName;
	}

	/** The user id. */
	private int userId;

	/** The user name. */
	private String userName;

}

package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class RewardProgramLocations.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RewardProgramLocations {

	@Override
	public String toString() {

		return "RewardProgramLocations [franchisors=" + franchisors + ", accounts=" + accounts + ", selectedLocationCount=" + selectedLocationCount + "]";
	}

	/** The franchisors. */
	private List<Franchisors> franchisors;

	/** The accounts. */
	private List<AccountsList> accounts;

	/** The selected location count. */
	private int selectedLocationCount;

	/**
	 * Gets the franchisors.
	 *
	 * @return the franchisors
	 */
	public List<Franchisors> getFranchisors() {

		return franchisors;
	}

	/**
	 * Sets the franchisors.
	 *
	 * @param franchisors the new franchisors
	 */
	public void setFranchisors(List<Franchisors> franchisors) {

		this.franchisors = franchisors;
	}

	/**
	 * Gets the accounts.
	 *
	 * @return the accounts
	 */
	public List<AccountsList> getAccounts() {

		return accounts;
	}

	/**
	 * Sets the accounts.
	 *
	 * @param accounts the new accounts
	 */
	public void setAccounts(List<AccountsList> accounts) {

		this.accounts = accounts;
	}

	/**
	 * Gets the selected location count.
	 *
	 * @return the selected location count
	 */
	public int getSelectedLocationCount() {

		return selectedLocationCount;
	}

	/**
	 * Sets the selected location count.
	 *
	 * @param selectedLocationCount the new selected location count
	 */
	public void setSelectedLocationCount(int selectedLocationCount) {

		this.selectedLocationCount = selectedLocationCount;
	}
}

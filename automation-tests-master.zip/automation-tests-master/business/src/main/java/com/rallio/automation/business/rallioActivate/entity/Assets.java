package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Assets.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Assets {

	/** The account id. */
	private int account_id;

	/** The cloudinary id. */
	private String cloudinary_id;

	/** The comments. */
	private String comments;

	/** The copy to descendants. */
	private boolean copy_to_descendants;

	/** The created at. */
	private String created_at;

	/** The created by user name. */
	private String created_by_user_name;

	/** The franchisor id. */
	private int franchisor_id;

	/** The id. */
	private int id;

	/** The liked. */
	private String liked;

	/** The md 5. */
	private String md5;

	/** The medium size url. */
	private String medium_size_url;

	/** The name. */
	private String name;

	/** The produced by. */
	private String produced_by;

	/** The tags list. */
	private String tags_list;

	/** The thumbnail url. */
	private String thumbnail_url;

	/** The transformations. */
	private Transformation transformations;

	/** The trashed. */
	private boolean trashed;

	/** The url. */
	private String url;

	/** The franchisor name. */
	private String franchisor_name;

	/** The account name. */
	private String account_name;

	/** The account address. */
	private String account_address;

	/** The cloudinary resource type. */
	private String cloudinary_resource_type;

	/** The media type. */
	private String media_type;

	/** The used count. */
	private int used_count;

	/** The created user. */
	private User created_user;

	/** The media releases. */
	private List<MediaReleases> media_releases;

	/** The brand id. */
	private int brand_id;

	/** The brand name. */
	private String brand_name;

	/** The source. */
	private String source;

	/** The updated at. */
	private String updated_at;

	/**
	 * Gets the account id.
	 *
	 * @return the account id
	 */
	public int getAccount_id() {

		return account_id;
	}

	/**
	 * Sets the account id.
	 *
	 * @param account_id the new account id
	 */
	public void setAccount_id(int account_id) {

		this.account_id = account_id;
	}

	/**
	 * Gets the cloudinary id.
	 *
	 * @return the cloudinary id
	 */
	public String getCloudinary_id() {

		return cloudinary_id;
	}

	/**
	 * Sets the cloudinary id.
	 *
	 * @param cloudinary_id the new cloudinary id
	 */
	public void setCloudinary_id(String cloudinary_id) {

		this.cloudinary_id = cloudinary_id;
	}

	/**
	 * Gets the comments.
	 *
	 * @return the comments
	 */
	public String getComments() {

		return comments;
	}

	/**
	 * Sets the comments.
	 *
	 * @param comments the new comments
	 */
	public void setComments(String comments) {

		this.comments = comments;
	}

	/**
	 * Checks if is copy to descendants.
	 *
	 * @return true, if is copy to descendants
	 */
	public boolean isCopy_to_descendants() {

		return copy_to_descendants;
	}

	/**
	 * Sets the copy to descendants.
	 *
	 * @param copy_to_descendants the new copy to descendants
	 */
	public void setCopy_to_descendants(boolean copy_to_descendants) {

		this.copy_to_descendants = copy_to_descendants;
	}

	/**
	 * Gets the created at.
	 *
	 * @return the created at
	 */
	public String getCreated_at() {

		return created_at;
	}

	/**
	 * Sets the created at.
	 *
	 * @param created_at the new created at
	 */
	public void setCreated_at(String created_at) {

		this.created_at = created_at;
	}

	/**
	 * Gets the created by user name.
	 *
	 * @return the created by user name
	 */
	public String getCreated_by_user_name() {

		return created_by_user_name;
	}

	/**
	 * Sets the created by user name.
	 *
	 * @param created_by_user_name the new created by user name
	 */
	public void setCreated_by_user_name(String created_by_user_name) {

		this.created_by_user_name = created_by_user_name;
	}

	/**
	 * Gets the franchisor id.
	 *
	 * @return the franchisor id
	 */
	public int getFranchisor_id() {

		return franchisor_id;
	}

	/**
	 * Sets the franchisor id.
	 *
	 * @param franchisor_id the new franchisor id
	 */
	public void setFranchisor_id(int franchisor_id) {

		this.franchisor_id = franchisor_id;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/**
	 * Gets the liked.
	 *
	 * @return the liked
	 */
	public String getLiked() {

		return liked;
	}

	/**
	 * Sets the liked.
	 *
	 * @param liked the new liked
	 */
	public void setLiked(String liked) {

		this.liked = liked;
	}

	/**
	 * Gets the md 5.
	 *
	 * @return the md 5
	 */
	public String getMd5() {

		return md5;
	}

	/**
	 * Sets the md 5.
	 *
	 * @param md5 the new md 5
	 */
	public void setMd5(String md5) {

		this.md5 = md5;
	}

	/**
	 * Gets the medium size url.
	 *
	 * @return the medium size url
	 */
	public String getMedium_size_url() {

		return medium_size_url;
	}

	/**
	 * Sets the medium size url.
	 *
	 * @param medium_size_url the new medium size url
	 */
	public void setMedium_size_url(String medium_size_url) {

		this.medium_size_url = medium_size_url;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {

		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {

		this.name = name;
	}

	/**
	 * Gets the produced by.
	 *
	 * @return the produced by
	 */
	public String getProduced_by() {

		return produced_by;
	}

	/**
	 * Sets the produced by.
	 *
	 * @param produced_by the new produced by
	 */
	public void setProduced_by(String produced_by) {

		this.produced_by = produced_by;
	}

	/**
	 * Gets the tags list.
	 *
	 * @return the tags list
	 */
	public String getTags_list() {

		return tags_list;
	}

	/**
	 * Sets the tags list.
	 *
	 * @param tags_list the new tags list
	 */
	public void setTags_list(String tags_list) {

		this.tags_list = tags_list;
	}

	/**
	 * Gets the thumbnail url.
	 *
	 * @return the thumbnail url
	 */
	public String getThumbnail_url() {

		return thumbnail_url;
	}

	/**
	 * Sets the thumbnail url.
	 *
	 * @param thumbnail_url the new thumbnail url
	 */
	public void setThumbnail_url(String thumbnail_url) {

		this.thumbnail_url = thumbnail_url;
	}

	/**
	 * Gets the transformations.
	 *
	 * @return the transformations
	 */
	public Transformation getTransformations() {

		return transformations;
	}

	/**
	 * Sets the transformations.
	 *
	 * @param transformations the new transformations
	 */
	public void setTransformations(Transformation transformations) {

		this.transformations = transformations;
	}

	/**
	 * Checks if is trashed.
	 *
	 * @return true, if is trashed
	 */
	public boolean isTrashed() {

		return trashed;
	}

	/**
	 * Sets the trashed.
	 *
	 * @param trashed the new trashed
	 */
	public void setTrashed(boolean trashed) {

		this.trashed = trashed;
	}

	/**
	 * Gets the url.
	 *
	 * @return the url
	 */
	public String getUrl() {

		return url;
	}

	/**
	 * Sets the url.
	 *
	 * @param url the new url
	 */
	public void setUrl(String url) {

		this.url = url;
	}

	/**
	 * Gets the franchisor name.
	 *
	 * @return the franchisor name
	 */
	public String getFranchisor_name() {

		return franchisor_name;
	}

	/**
	 * Sets the franchisor name.
	 *
	 * @param franchisor_name the new franchisor name
	 */
	public void setFranchisor_name(String franchisor_name) {

		this.franchisor_name = franchisor_name;
	}

	/**
	 * Gets the account name.
	 *
	 * @return the account name
	 */
	public String getAccount_name() {

		return account_name;
	}

	/**
	 * Sets the account name.
	 *
	 * @param account_name the new account name
	 */
	public void setAccount_name(String account_name) {

		this.account_name = account_name;
	}

	/**
	 * Gets the account address.
	 *
	 * @return the account address
	 */
	public String getAccount_address() {

		return account_address;
	}

	/**
	 * Sets the account address.
	 *
	 * @param account_address the new account address
	 */
	public void setAccount_address(String account_address) {

		this.account_address = account_address;
	}

	/**
	 * Gets the cloudinary resource type.
	 *
	 * @return the cloudinary resource type
	 */
	public String getCloudinary_resource_type() {

		return cloudinary_resource_type;
	}

	/**
	 * Sets the cloudinary resource type.
	 *
	 * @param cloudinary_resource_type the new cloudinary resource type
	 */
	public void setCloudinary_resource_type(String cloudinary_resource_type) {

		this.cloudinary_resource_type = cloudinary_resource_type;
	}

	/**
	 * Gets the media type.
	 *
	 * @return the media type
	 */
	public String getMedia_type() {

		return media_type;
	}

	/**
	 * Sets the media type.
	 *
	 * @param media_type the new media type
	 */
	public void setMedia_type(String media_type) {

		this.media_type = media_type;
	}

	/**
	 * Gets the used count.
	 *
	 * @return the used count
	 */
	public int getUsed_count() {

		return used_count;
	}

	/**
	 * Sets the used count.
	 *
	 * @param used_count the new used count
	 */
	public void setUsed_count(int used_count) {

		this.used_count = used_count;
	}

	/**
	 * Gets the created user.
	 *
	 * @return the created user
	 */
	public User getCreated_user() {

		return created_user;
	}

	/**
	 * Sets the created user.
	 *
	 * @param created_user the new created user
	 */
	public void setCreated_user(User created_user) {

		this.created_user = created_user;
	}

	/**
	 * Gets the media releases.
	 *
	 * @return the media releases
	 */
	public List<MediaReleases> getMedia_releases() {

		return media_releases;
	}

	/**
	 * Sets the media releases.
	 *
	 * @param media_releases the new media releases
	 */
	public void setMedia_releases(List<MediaReleases> media_releases) {

		this.media_releases = media_releases;
	}

	/**
	 * Gets the brand id.
	 *
	 * @return the brand id
	 */
	public int getBrand_id() {

		return brand_id;
	}

	/**
	 * Sets the brand id.
	 *
	 * @param brand_id the new brand id
	 */
	public void setBrand_id(int brand_id) {

		this.brand_id = brand_id;
	}

	/**
	 * Gets the brand name.
	 *
	 * @return the brand name
	 */
	public String getBrand_name() {

		return brand_name;
	}

	/**
	 * Sets the brand name.
	 *
	 * @param brand_name the new brand name
	 */
	public void setBrand_name(String brand_name) {

		this.brand_name = brand_name;
	}

	/**
	 * Gets the source.
	 *
	 * @return the source
	 */
	public String getSource() {

		return source;
	}

	/**
	 * Sets the source.
	 *
	 * @param source the new source
	 */
	public void setSource(String source) {

		this.source = source;
	}

	/**
	 * Gets the updated at.
	 *
	 * @return the updated at
	 */
	public String getUpdated_at() {

		return updated_at;
	}

	/**
	 * Sets the updated at.
	 *
	 * @param updated_at the new updated at
	 */
	public void setUpdated_at(String updated_at) {

		this.updated_at = updated_at;
	}

}

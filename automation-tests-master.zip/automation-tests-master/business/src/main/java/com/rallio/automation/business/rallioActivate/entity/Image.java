package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Media.
 */
public class Image {

	/** The media name. */
	private String imageName;

	/** The uploaded by. */
	private String uploadedBy;

	/** The location. */
	private String location;

	/** The tags. */
	private List<String> tags;

	/**
	 * Gets the uploaded by.
	 *
	 * @return the uploaded by
	 */
	public String getUploadedBy() {

		return uploadedBy;
	}

	/**
	 * Sets the uploaded by.
	 *
	 * @param uploadedBy the new uploaded by
	 */
	public void setUploadedBy(String uploadedBy) {

		this.uploadedBy = uploadedBy;
	}

	/**
	 * Gets the location.
	 *
	 * @return the location
	 */
	public String getLocation() {

		return location;
	}

	/**
	 * Sets the location.
	 *
	 * @param location the new location
	 */
	public void setLocation(String location) {

		this.location = location;
	}

	/**
	 * Gets the tags.
	 *
	 * @return the tags
	 */
	public List<String> getTags() {

		return tags;
	}

	/**
	 * Sets the tags.
	 *
	 * @param tags the new tags
	 */
	public void setTags(List<String> tags) {

		this.tags = tags;
	}

	/**
	 * Gets the image name.
	 *
	 * @return the image name
	 */
	public String getImageName() {

		return imageName;
	}

	/**
	 * Sets the image name.
	 *
	 * @param imageName the new image name
	 */
	public void setImageName(String imageName) {

		this.imageName = imageName;
	}
}

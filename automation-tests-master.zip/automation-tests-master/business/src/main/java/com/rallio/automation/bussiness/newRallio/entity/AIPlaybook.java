package com.rallio.automation.bussiness.newRallio.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class AIPlaybook.
 */
public class AIPlaybook {

	/** The websiteurl. */
	private String  websiteurl;

	/** The name. */
	private String businessCategory;
	
	/** The customer favourite tag. */
	private String customerFavouriteTag;

	/** The business search. */
	private String businessSearch;
	
	/** The business category name. */
	private String businessCategoryName;
	
	/** The anything else text box. */
	private String anythingElseTextBox;

	
	/**
	 * Gets the business category name.
	 *
	 * @return the business category name
	 */
	public String getBusinessCategoryName() {
		return businessCategoryName;
	}

	/**
	 * Sets the business category name.
	 *
	 * @param businessCategoryName the new business category name
	 */
	public void setBusinessCategoryName(String businessCategoryName) {
		this.businessCategoryName = businessCategoryName;
	}

	/**
	 * Gets the websiteurl.
	 *
	 * @return the websiteurl
	 */
	public String getWebsiteurl() {
		return websiteurl;
	}

	/**
	 * Sets the websiteurl.
	 *
	 * @param websiteurl the new websiteurl
	 */
	public void setWebsiteurl(String websiteurl) {
		this.websiteurl = websiteurl;
	}

	/**
	 * Gets the business category.
	 *
	 * @return the business category
	 */
	public String getBusinessCategory() {
		return businessCategory;
	}

	/**
	 * Sets the business category.
	 *
	 * @param businessCategory the new business category
	 */
	public void setBusinessCategory(String businessCategory) {
		this.businessCategory = businessCategory;
	}

	/**
	 * Gets the customer favourite tag.
	 *
	 * @return the customer favourite tag
	 */
	public String getCustomerFavouriteTag() {
		return customerFavouriteTag;
	}

	/**
	 * Sets the customer favourite tag.
	 *
	 * @param customerFavouriteTag the new customer favourite tag
	 */
	public void setCustomerFavouriteTag(String customerFavouriteTag) {
		this.customerFavouriteTag = customerFavouriteTag;
	}

	/**
	 * Gets the business search.
	 *
	 * @return the business search
	 */
	public String getBusinessSearch() {
		return businessSearch;
	}

	/**
	 * Sets the business search.
	 *
	 * @param businessSearch the new business search
	 */
	public void setBusinessSearch(String businessSearch) {
		this.businessSearch = businessSearch;
	}

	/**
	 * Gets the anything else text box.
	 *
	 * @return the anything else text box
	 */
	public String getAnythingElseTextBox() {
		return anythingElseTextBox;
	}

	/**
	 * Sets the anything else text box.
	 *
	 * @param anythingElseTextBox the new anything else text box
	 */
	public void setAnythingElseTextBox(String anythingElseTextBox) {
		this.anythingElseTextBox = anythingElseTextBox;
	}
	
	
}

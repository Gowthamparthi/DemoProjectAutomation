package com.rallio.automation.business.rallioActivate.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class TotalAssetsStats.
 */
public class TotalAssetsStats {

	/** The total assets. */
	private int total_assets;

	/** The total photos. */
	private int total_photos;

	/** The total videos. */
	private int total_videos;

	/**
	 * Gets the total assets.
	 *
	 * @return the total assets
	 */
	public int getTotal_assets() {

		return total_assets;
	}

	/**
	 * Sets the total assets.
	 *
	 * @param total_assets the new total assets
	 */
	public void setTotal_assets(int total_assets) {

		this.total_assets = total_assets;
	}

	/**
	 * Gets the total photos.
	 *
	 * @return the total photos
	 */
	public int getTotal_photos() {

		return total_photos;
	}

	/**
	 * Sets the total photos.
	 *
	 * @param total_photos the new total photos
	 */
	public void setTotal_photos(int total_photos) {

		this.total_photos = total_photos;
	}

	/**
	 * Gets the total videos.
	 *
	 * @return the total videos
	 */
	public int getTotal_videos() {

		return total_videos;
	}

	/**
	 * Sets the total videos.
	 *
	 * @param total_videos the new total videos
	 */
	public void setTotal_videos(int total_videos) {

		this.total_videos = total_videos;
	}

}

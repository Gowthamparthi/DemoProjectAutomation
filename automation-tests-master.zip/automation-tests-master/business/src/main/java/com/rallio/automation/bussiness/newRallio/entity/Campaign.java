package com.rallio.automation.bussiness.newRallio.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class Campaign.
 */
public class Campaign {

	/** The name. */
	private String name;

	/** The description. */
	private String description;

	/** The availability. */
	private String availability;

	/** The date. */
	/* Date in the format of Mar 17,2023 */
	private String date;

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Gets the availability.
	 *
	 * @return the availability
	 */
	public String getAvailability() {
		return availability;
	}

	/**
	 * Sets the availability.
	 *
	 * @param availability the new availability
	 */
	public void setAvailability(String availability) {
		this.availability = availability;
	}

	/**
	 * Gets the date.
	 *
	 * @return the date
	 */
	public String getDate() {
		return date;
	}

	/**
	 * Sets the date.
	 *
	 * @param date the new date
	 */
	public void setDate(String date) {
		this.date = date;
	}

}

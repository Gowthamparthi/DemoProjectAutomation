package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class CommunityManagementStatsData.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class CommunityManagementStatsData {

	/** The total advocates count. */
	private int totalAdvocatesCount;

	/** The total app users in percent. */
	private int totalAppUsersInPercent;

	/**
	 * Gets the total advocates count.
	 *
	 * @return the total advocates count
	 */
	public int getTotalAdvocatesCount() {

		return totalAdvocatesCount;
	}

	/**
	 * Sets the total advocates count.
	 *
	 * @param totalAdvocatesCount the new total advocates count
	 */
	public void setTotalAdvocatesCount(int totalAdvocatesCount) {

		this.totalAdvocatesCount = totalAdvocatesCount;
	}

	/**
	 * Gets the total app users in percent.
	 *
	 * @return the total app users in percent
	 */
	public int getTotalAppUsersInPercent() {

		return totalAppUsersInPercent;
	}

	/**
	 * Sets the total app users in percent.
	 *
	 * @param totalAppUsersInPercent the new total app users in percent
	 */
	public void setTotalAppUsersInPercent(int totalAppUsersInPercent) {

		this.totalAppUsersInPercent = totalAppUsersInPercent;
	}
}

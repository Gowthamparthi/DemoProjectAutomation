package com.rallio.automation.business.rallioLocalCenter.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class AddNote.
 */
public class AddLocationNotes {

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return "AddLocationNotes [account_id=" + account_id + ", note=" + note + ", note_type=" + note_type + ", user_id=" + user_id + "]";
	}

	/** The account id. */
	private String account_id;

	/** The note. */
	private String note;

	/** The note type. */
	private int note_type;

	/** The user id. */
	private int user_id;

	/**
	 * Gets the account id.
	 *
	 * @return the account id
	 */
	public String getAccount_id() {

		return account_id;
	}

	/**
	 * Sets the account id.
	 *
	 * @param account_id the new account id
	 */
	public void setAccount_id(String account_id) {

		this.account_id = account_id;
	}

	/**
	 * Gets the note.
	 *
	 * @return the note
	 */
	public String getNote() {

		return note;
	}

	/**
	 * Sets the note.
	 *
	 * @param note the new note
	 */
	public void setNote(String note) {

		this.note = note;
	}

	/**
	 * Gets the note type.
	 *
	 * @return the note type
	 */
	public int getNote_type() {

		return note_type;
	}

	/**
	 * Sets the note type.
	 *
	 * @param note_type the new note type
	 */
	public void setNote_type(int note_type) {

		this.note_type = note_type;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public int getUser_id() {

		return user_id;
	}

	/**
	 * Sets the user id.
	 *
	 * @param user_id the new user id
	 */
	public void setUser_id(int user_id) {

		this.user_id = user_id;
	}

}

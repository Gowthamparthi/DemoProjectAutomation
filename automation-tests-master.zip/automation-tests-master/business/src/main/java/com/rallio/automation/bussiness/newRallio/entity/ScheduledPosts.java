package com.rallio.automation.bussiness.newRallio.entity;

import java.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class ScheduledPosts.
 */
public class ScheduledPosts {

	/** The account id. */
	private int account_id;

	/** The cloudinary resource type. */
	private String cloudinary_resource_type;

	/** The cloudinary video id. */
	private String cloudinary_video_id;

	/** The corporate post. */
	private boolean corporate_post;

	/** The draft. */
	private boolean draft;

	/** The end date. */
	private String end_date;

	/** The facebook boost enduser campaign id. */
	private String facebook_boost_enduser_campaign_id;

	/** The facebook text. */
	private String facebook_text;

	/** The google text. */
	private String google_text;

	/** The has facebook boost enduser campaign. */
	private boolean has_facebook_boost_enduser_campaign;

	/** The hidden. */
	private boolean hidden;

	/** The id. */
	private int id;

	/** The instagram text. */
	private String instagram_text;

	/** The link description. */
	private String link_description;

	/** The link title. */
	private String link_title;

	/** The link url. */
	private String link_url;

	/** The linkedin text. */
	private String linkedin_text;

	/** The locked. */
	private boolean locked;

	/** The page tag details. */
	private PageTagDetails page_tag_details;

	/** The photo url. */
	private String photo_url;

	/** The photo urls. */
	private List<String> photo_urls;

	/** The posted. */
	private boolean posted;

	/** The saved post id. */
	private int saved_post_id;

	/** The scheduled for. */
	private String scheduled_for;

	/** The start date. */
	private String start_date;

	/** The time zone. */
	private String time_zone;

	/** The time zone abbreviation. */
	private String time_zone_abbreviation;

	/** The twitter text. */
	private String twitter_text;

	/** The use facebook. */
	private boolean use_facebook;

	/** The use google. */
	private boolean use_google;

	/** The use instagram. */
	private boolean use_instagram;

	/** The use linkedin. */
	private boolean use_linkedin;

	/** The use twitter. */
	private boolean use_twitter;

	/** The use twitter photo. */
	private boolean use_twitter_photo;

	/**
	 * Gets the account id.
	 *
	 * @return the account id
	 */
	public int getAccount_id() {

		return account_id;
	}

	/**
	 * Sets the account id.
	 *
	 * @param account_id the new account id
	 */
	public void setAccount_id(int account_id) {

		this.account_id = account_id;
	}

	/**
	 * Gets the cloudinary resource type.
	 *
	 * @return the cloudinary resource type
	 */
	public String getCloudinary_resource_type() {

		return cloudinary_resource_type;
	}

	/**
	 * Sets the cloudinary resource type.
	 *
	 * @param cloudinary_resource_type the new cloudinary resource type
	 */
	public void setCloudinary_resource_type(String cloudinary_resource_type) {

		this.cloudinary_resource_type = cloudinary_resource_type;
	}

	/**
	 * Gets the cloudinary video id.
	 *
	 * @return the cloudinary video id
	 */
	public String getCloudinary_video_id() {

		return cloudinary_video_id;
	}

	/**
	 * Sets the cloudinary video id.
	 *
	 * @param cloudinary_video_id the new cloudinary video id
	 */
	public void setCloudinary_video_id(String cloudinary_video_id) {

		this.cloudinary_video_id = cloudinary_video_id;
	}

	/**
	 * Checks if is corporate post.
	 *
	 * @return true, if is corporate post
	 */
	public boolean isCorporate_post() {

		return corporate_post;
	}

	/**
	 * Sets the corporate post.
	 *
	 * @param corporate_post the new corporate post
	 */
	public void setCorporate_post(boolean corporate_post) {

		this.corporate_post = corporate_post;
	}

	/**
	 * Checks if is draft.
	 *
	 * @return true, if is draft
	 */
	public boolean isDraft() {

		return draft;
	}

	/**
	 * Sets the draft.
	 *
	 * @param draft the new draft
	 */
	public void setDraft(boolean draft) {

		this.draft = draft;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public String getEnd_date() {

		return end_date;
	}

	/**
	 * Sets the end date.
	 *
	 * @param end_date the new end date
	 */
	public void setEnd_date(String end_date) {

		this.end_date = end_date;
	}

	/**
	 * Gets the facebook boost enduser campaign id.
	 *
	 * @return the facebook boost enduser campaign id
	 */
	public String getFacebook_boost_enduser_campaign_id() {

		return facebook_boost_enduser_campaign_id;
	}

	/**
	 * Sets the facebook boost enduser campaign id.
	 *
	 * @param facebook_boost_enduser_campaign_id the new facebook boost enduser
	 *            campaign id
	 */
	public void setFacebook_boost_enduser_campaign_id(String facebook_boost_enduser_campaign_id) {

		this.facebook_boost_enduser_campaign_id = facebook_boost_enduser_campaign_id;
	}

	/**
	 * Gets the facebook text.
	 *
	 * @return the facebook text
	 */
	public String getFacebook_text() {

		return facebook_text;
	}

	/**
	 * Sets the facebook text.
	 *
	 * @param facebook_text the new facebook text
	 */
	public void setFacebook_text(String facebook_text) {

		this.facebook_text = facebook_text;
	}

	/**
	 * Gets the google text.
	 *
	 * @return the google text
	 */
	public String getGoogle_text() {

		return google_text;
	}

	/**
	 * Sets the google text.
	 *
	 * @param google_text the new google text
	 */
	public void setGoogle_text(String google_text) {

		this.google_text = google_text;
	}

	/**
	 * Checks if is checks for facebook boost enduser campaign.
	 *
	 * @return true, if is checks for facebook boost enduser campaign
	 */
	public boolean isHas_facebook_boost_enduser_campaign() {

		return has_facebook_boost_enduser_campaign;
	}

	/**
	 * Sets the checks for facebook boost enduser campaign.
	 *
	 * @param has_facebook_boost_enduser_campaign the new checks for facebook
	 *            boost enduser campaign
	 */
	public void setHas_facebook_boost_enduser_campaign(boolean has_facebook_boost_enduser_campaign) {

		this.has_facebook_boost_enduser_campaign = has_facebook_boost_enduser_campaign;
	}

	/**
	 * Checks if is hidden.
	 *
	 * @return true, if is hidden
	 */
	public boolean isHidden() {

		return hidden;
	}

	/**
	 * Sets the hidden.
	 *
	 * @param hidden the new hidden
	 */
	public void setHidden(boolean hidden) {

		this.hidden = hidden;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/**
	 * Gets the instagram text.
	 *
	 * @return the instagram text
	 */
	public String getInstagram_text() {

		return instagram_text;
	}

	/**
	 * Sets the instagram text.
	 *
	 * @param instagram_text the new instagram text
	 */
	public void setInstagram_text(String instagram_text) {

		this.instagram_text = instagram_text;
	}

	/**
	 * Gets the link description.
	 *
	 * @return the link description
	 */
	public String getLink_description() {

		return link_description;
	}

	/**
	 * Sets the link description.
	 *
	 * @param link_description the new link description
	 */
	public void setLink_description(String link_description) {

		this.link_description = link_description;
	}

	/**
	 * Gets the link title.
	 *
	 * @return the link title
	 */
	public String getLink_title() {

		return link_title;
	}

	/**
	 * Sets the link title.
	 *
	 * @param link_title the new link title
	 */
	public void setLink_title(String link_title) {

		this.link_title = link_title;
	}

	/**
	 * Gets the link url.
	 *
	 * @return the link url
	 */
	public String getLink_url() {

		return link_url;
	}

	/**
	 * Sets the link url.
	 *
	 * @param link_url the new link url
	 */
	public void setLink_url(String link_url) {

		this.link_url = link_url;
	}

	/**
	 * Gets the linkedin text.
	 *
	 * @return the linkedin text
	 */
	public String getLinkedin_text() {

		return linkedin_text;
	}

	/**
	 * Sets the linkedin text.
	 *
	 * @param linkedin_text the new linkedin text
	 */
	public void setLinkedin_text(String linkedin_text) {

		this.linkedin_text = linkedin_text;
	}

	/**
	 * Checks if is locked.
	 *
	 * @return true, if is locked
	 */
	public boolean isLocked() {

		return locked;
	}

	/**
	 * Sets the locked.
	 *
	 * @param locked the new locked
	 */
	public void setLocked(boolean locked) {

		this.locked = locked;
	}

	/**
	 * Gets the page tag details.
	 *
	 * @return the page tag details
	 */
	public PageTagDetails getPage_tag_details() {

		return page_tag_details;
	}

	/**
	 * Sets the page tag details.
	 *
	 * @param page_tag_details the new page tag details
	 */
	public void setPage_tag_details(PageTagDetails page_tag_details) {

		this.page_tag_details = page_tag_details;
	}

	/**
	 * Gets the photo url.
	 *
	 * @return the photo url
	 */
	public String getPhoto_url() {

		return photo_url;
	}

	/**
	 * Sets the photo url.
	 *
	 * @param photo_url the new photo url
	 */
	public void setPhoto_url(String photo_url) {

		this.photo_url = photo_url;
	}

	/**
	 * Gets the photo urls.
	 *
	 * @return the photo urls
	 */
	public List<String> getPhoto_urls() {

		return photo_urls;
	}

	/**
	 * Sets the photo urls.
	 *
	 * @param photo_urls the new photo urls
	 */
	public void setPhoto_urls(List<String> photo_urls) {

		this.photo_urls = photo_urls;
	}

	/**
	 * Checks if is posted.
	 *
	 * @return true, if is posted
	 */
	public boolean isPosted() {

		return posted;
	}

	/**
	 * Sets the posted.
	 *
	 * @param posted the new posted
	 */
	public void setPosted(boolean posted) {

		this.posted = posted;
	}

	/**
	 * Gets the saved post id.
	 *
	 * @return the saved post id
	 */
	public int getSaved_post_id() {

		return saved_post_id;
	}

	/**
	 * Sets the saved post id.
	 *
	 * @param saved_post_id the new saved post id
	 */
	public void setSaved_post_id(int saved_post_id) {

		this.saved_post_id = saved_post_id;
	}

	/**
	 * Gets the scheduled for.
	 *
	 * @return the scheduled for
	 */
	public String getScheduled_for() {

		return scheduled_for;
	}

	/**
	 * Sets the scheduled for.
	 *
	 * @param scheduled_for the new scheduled for
	 */
	public void setScheduled_for(String scheduled_for) {

		this.scheduled_for = scheduled_for;
	}

	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public String getStart_date() {

		return start_date;
	}

	/**
	 * Sets the start date.
	 *
	 * @param start_date the new start date
	 */
	public void setStart_date(String start_date) {

		this.start_date = start_date;
	}

	/**
	 * Gets the time zone.
	 *
	 * @return the time zone
	 */
	public String getTime_zone() {

		return time_zone;
	}

	/**
	 * Sets the time zone.
	 *
	 * @param time_zone the new time zone
	 */
	public void setTime_zone(String time_zone) {

		this.time_zone = time_zone;
	}

	/**
	 * Gets the time zone abbreviation.
	 *
	 * @return the time zone abbreviation
	 */
	public String getTime_zone_abbreviation() {

		return time_zone_abbreviation;
	}

	/**
	 * Sets the time zone abbreviation.
	 *
	 * @param time_zone_abbreviation the new time zone abbreviation
	 */
	public void setTime_zone_abbreviation(String time_zone_abbreviation) {

		this.time_zone_abbreviation = time_zone_abbreviation;
	}

	/**
	 * Gets the twitter text.
	 *
	 * @return the twitter text
	 */
	public String getTwitter_text() {

		return twitter_text;
	}

	/**
	 * Sets the twitter text.
	 *
	 * @param twitter_text the new twitter text
	 */
	public void setTwitter_text(String twitter_text) {

		this.twitter_text = twitter_text;
	}

	/**
	 * Checks if is use facebook.
	 *
	 * @return true, if is use facebook
	 */
	public boolean isUse_facebook() {

		return use_facebook;
	}

	/**
	 * Sets the use facebook.
	 *
	 * @param use_facebook the new use facebook
	 */
	public void setUse_facebook(boolean use_facebook) {

		this.use_facebook = use_facebook;
	}

	/**
	 * Checks if is use google.
	 *
	 * @return true, if is use google
	 */
	public boolean isUse_google() {

		return use_google;
	}

	/**
	 * Sets the use google.
	 *
	 * @param use_google the new use google
	 */
	public void setUse_google(boolean use_google) {

		this.use_google = use_google;
	}

	/**
	 * Checks if is use instagram.
	 *
	 * @return true, if is use instagram
	 */
	public boolean isUse_instagram() {

		return use_instagram;
	}

	/**
	 * Sets the use instagram.
	 *
	 * @param use_instagram the new use instagram
	 */
	public void setUse_instagram(boolean use_instagram) {

		this.use_instagram = use_instagram;
	}

	/**
	 * Checks if is use linkedin.
	 *
	 * @return true, if is use linkedin
	 */
	public boolean isUse_linkedin() {

		return use_linkedin;
	}

	/**
	 * Sets the use linkedin.
	 *
	 * @param use_linkedin the new use linkedin
	 */
	public void setUse_linkedin(boolean use_linkedin) {

		this.use_linkedin = use_linkedin;
	}

	/**
	 * Checks if is use twitter.
	 *
	 * @return true, if is use twitter
	 */
	public boolean isUse_twitter() {

		return use_twitter;
	}

	/**
	 * Sets the use twitter.
	 *
	 * @param use_twitter the new use twitter
	 */
	public void setUse_twitter(boolean use_twitter) {

		this.use_twitter = use_twitter;
	}

	/**
	 * Checks if is use twitter photo.
	 *
	 * @return true, if is use twitter photo
	 */
	public boolean isUse_twitter_photo() {

		return use_twitter_photo;
	}

	/**
	 * Sets the use twitter photo.
	 *
	 * @param use_twitter_photo the new use twitter photo
	 */
	public void setUse_twitter_photo(boolean use_twitter_photo) {

		this.use_twitter_photo = use_twitter_photo;
	}

}

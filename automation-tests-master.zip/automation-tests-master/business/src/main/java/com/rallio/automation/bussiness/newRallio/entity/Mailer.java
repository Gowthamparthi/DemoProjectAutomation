package com.rallio.automation.bussiness.newRallio.entity;

import com.rallio.automation.common.enums.FilterBy;
import com.rallio.automation.common.enums.MailerType;

// TODO: Auto-generated Javadoc
/**
 * The Class Mailer.
 */
public class Mailer {

	/** The email id. */
	private String emailId;

	/** The first name. */
	private String firstName;

	/** The last name. */
	private String lastName;

	/** The password. */
	private String password;

	/** The host. */
	private String host;

	/** The port. */
	private String port;

	/** The protocol. */
	private String protocol;

	/** The mail store. */
	private String mailStore;

	/** The email content. */
	private String emailContent;

	/** The email subject. */
	private String emailSubject;

	/** The email from. */
	private String emailFrom;

	/** The has attachments. */
	private boolean hasAttachments;

	/** The attachment data. */
	private String attachmentData;

	/** The emails count. */
	private int emailsCount;

	/** The filter by. */
	private FilterBy filterBy;

	/** The reply content. */
	private String replyContent;

	/** The mailer type. */
	private MailerType mailerType;

	/**
	 * Gets the email id.
	 *
	 * @return the email id
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * Sets the email id.
	 *
	 * @param emailId the new email id
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets the first name.
	 *
	 * @param firstName the new first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Sets the last name.
	 *
	 * @param lastName the new last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Sets the password.
	 *
	 * @param password the new password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Gets the host.
	 *
	 * @return the host
	 */
	public String getHost() {
		return host;
	}

	/**
	 * Sets the host.
	 *
	 * @param host the new host
	 */
	public void setHost(String host) {
		this.host = host;
	}

	/**
	 * Gets the port.
	 *
	 * @return the port
	 */
	public String getPort() {
		return port;
	}

	/**
	 * Sets the port.
	 *
	 * @param port the new port
	 */
	public void setPort(String port) {
		this.port = port;
	}

	/**
	 * Gets the protocol.
	 *
	 * @return the protocol
	 */
	public String getProtocol() {
		return protocol;
	}

	/**
	 * Sets the protocol.
	 *
	 * @param protocol the new protocol
	 */
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	/**
	 * Gets the mail store.
	 *
	 * @return the mail store
	 */
	public String getMailStore() {
		return mailStore;
	}

	/**
	 * Sets the mail store.
	 *
	 * @param mailStore the new mail store
	 */
	public void setMailStore(String mailStore) {
		this.mailStore = mailStore;
	}

	/**
	 * Gets the email content.
	 *
	 * @return the email content
	 */
	public String getEmailContent() {
		return emailContent;
	}
	/**
	 * Sets the email content.
	 *
	 * @param emailContent the new email content
	 */
	public void setEmailContent(String emailContent) {
		this.emailContent = emailContent;
	}

	/**
	 * Gets the email subject.
	 *
	 * @return the email subject
	 */
	public String getEmailSubject() {
		return emailSubject;
	}

	/**
	 * Sets the email subject.
	 *
	 * @param emailSubject the new email subject
	 */
	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}

	/**
	 * Gets the email from.
	 *
	 * @return the email from
	 */
	public String getEmailFrom() {
		return emailFrom;
	}

	/**
	 * Sets the email from.
	 *
	 * @param emailFrom the new email from
	 */
	public void setEmailFrom(String emailFrom) {
		this.emailFrom = emailFrom;
	}

	/**
	 * Checks if is checks for attachments.
	 *
	 * @return true, if is checks for attachments
	 */
	public boolean isHasAttachments() {
		return hasAttachments;
	}

	/**
	 * Sets the checks for attachments.
	 *
	 * @param hasAttachments the new checks for attachments
	 */
	public void setHasAttachments(boolean hasAttachments) {
		this.hasAttachments = hasAttachments;
	}

	/**
	 * Gets the attachment data.
	 *
	 * @return the attachment data
	 */
	public String getAttachmentData() {
		return attachmentData;
	}

	/**
	 * Sets the attachment data.
	 *
	 * @param attachmentData the new attachment data
	 */
	public void setAttachmentData(String attachmentData) {
		this.attachmentData = attachmentData;
	}

	/**
	 * Gets the emails count.
	 *
	 * @return the emails count
	 */
	public int getEmailsCount() {
		return emailsCount;
	}

	/**
	 * Sets the emails count.
	 *
	 * @param emailsCount the new emails count
	 */
	public void setEmailsCount(int emailsCount) {
		this.emailsCount = emailsCount;
	}

	/**
	 * Gets the filter by.
	 *
	 * @return the filter by
	 */
	public FilterBy getFilterBy() {
		return filterBy;
	}

	/**
	 * Sets the filter by.
	 *
	 * @param filterBy the new filter by
	 */
	public void setFilterBy(FilterBy filterBy) {
		this.filterBy = filterBy;
	}

	/**
	 * Gets the reply content.
	 *
	 * @return the reply content
	 */
	public String getReplyContent() {
		return replyContent;
	}

	/**
	 * Sets the reply content.
	 *
	 * @param replyContent the new reply content
	 */
	public void setReplyContent(String replyContent) {
		this.replyContent = replyContent;
	}

	/**
	 * Gets the mailer type.
	 *
	 * @return the mailer type
	 */
	public MailerType getMailerType() {
		return mailerType;
	}

	/**
	 * Sets the mailer type.
	 *
	 * @param mailerType the new mailer type
	 */
	public void setMailerType(MailerType mailerType) {
		this.mailerType = mailerType;
	}
	
}

package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class BrandAndHubs.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class BrandAndHubs {

	/** The franchisors. */
	private List<Franchisors> franchisors;

	/** The accounts. */
	private List<AccountsList> accounts;

	/**
	 * Gets the franchisors.
	 *
	 * @return the franchisors
	 */
	public List<Franchisors> getFranchisors() {

		return franchisors;
	}

	/**
	 * Sets the franchisors.
	 *
	 * @param franchisors the new franchisors
	 */
	public void setFranchisors(List<Franchisors> franchisors) {

		this.franchisors = franchisors;
	}

	/**
	 * Gets the accounts.
	 *
	 * @return the accounts
	 */
	public List<AccountsList> getAccounts() {

		return accounts;
	}

	/**
	 * Sets the accounts.
	 *
	 * @param accounts the new accounts
	 */
	public void setAccounts(List<AccountsList> accounts) {

		this.accounts = accounts;
	}

}

package com.rallio.automation.business.rallioActivate.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class MediaReleases.
 */
public class MediaReleases {

	/** The id. */
	private int id;

	/** The name. */
	private String name;

	/** The photo id. */
	private int photo_id;

	/** The signature url. */
	private String signature_url;

	/** The signed at. */
	private String signed_at;

	/** The text. */
	private String text;

	/** The url. */
	private String url;

	/** The user id. */
	private int user_id;

	/** The video id. */
	private int video_id;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {

		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {

		this.name = name;
	}

	/**
	 * Gets the photo id.
	 *
	 * @return the photo id
	 */
	public int getPhoto_id() {

		return photo_id;
	}

	/**
	 * Sets the photo id.
	 *
	 * @param photo_id the new photo id
	 */
	public void setPhoto_id(int photo_id) {

		this.photo_id = photo_id;
	}

	/**
	 * Gets the signature url.
	 *
	 * @return the signature url
	 */
	public String getSignature_url() {

		return signature_url;
	}

	/**
	 * Sets the signature url.
	 *
	 * @param signature_url the new signature url
	 */
	public void setSignature_url(String signature_url) {

		this.signature_url = signature_url;
	}

	/**
	 * Gets the signed at.
	 *
	 * @return the signed at
	 */
	public String getSigned_at() {

		return signed_at;
	}

	/**
	 * Sets the signed at.
	 *
	 * @param signed_at the new signed at
	 */
	public void setSigned_at(String signed_at) {

		this.signed_at = signed_at;
	}

	/**
	 * Gets the text.
	 *
	 * @return the text
	 */
	public String getText() {

		return text;
	}

	/**
	 * Sets the text.
	 *
	 * @param text the new text
	 */
	public void setText(String text) {

		this.text = text;
	}

	/**
	 * Gets the url.
	 *
	 * @return the url
	 */
	public String getUrl() {

		return url;
	}

	/**
	 * Sets the url.
	 *
	 * @param url the new url
	 */
	public void setUrl(String url) {

		this.url = url;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public int getUser_id() {

		return user_id;
	}

	/**
	 * Sets the user id.
	 *
	 * @param user_id the new user id
	 */
	public void setUser_id(int user_id) {

		this.user_id = user_id;
	}

	/**
	 * Gets the video id.
	 *
	 * @return the video id
	 */
	public int getVideo_id() {

		return video_id;
	}

	/**
	 * Sets the video id.
	 *
	 * @param video_id the new video id
	 */
	public void setVideo_id(int video_id) {

		this.video_id = video_id;
	}
}

package com.rallio.automation.business.rallioLocalCenter.entity;

import java.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class StrategistLocations.
 */
public class StrategistLocations {

	/**
	 * Gets the brand.
	 *
	 * @return the brand
	 */
	public String getBrand() {

		return brand;
	}

	@Override
	public String toString() {

		return "StrategistLocations [brand=" + brand + ", locations=" + locations + "]";
	}

	/**
	 * Sets the brand.
	 *
	 * @param brand the new brand
	 */
	public void setBrand(String brand) {

		this.brand = brand;
	}

	/** The brand. */
	private String brand;

	/** The locations. */
	private List<String> locations;

	/**
	 * Gets the locations.
	 *
	 * @return the locations
	 */
	public List<String> getLocations() {

		return locations;
	}

	/**
	 * Sets the locations.
	 *
	 * @param locations the new locations
	 */
	public void setLocations(List<String> locations) {

		this.locations = locations;
	}

}

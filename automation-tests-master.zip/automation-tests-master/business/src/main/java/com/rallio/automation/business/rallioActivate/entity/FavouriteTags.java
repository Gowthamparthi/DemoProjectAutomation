package com.rallio.automation.business.rallioActivate.entity;

import com.rallio.automation.common.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class FavouriteTags.
 */
public class FavouriteTags {

	/** The favourite. */
	private boolean favorite;

	/**
	 * Checks if is favorite.
	 *
	 * @return true, if is favorite
	 */
	public boolean isFavorite() {

		return favorite;
	}

	/**
	 * Sets the favorite.
	 *
	 * @param favorite the new favorite
	 */
	public void setFavorite(boolean favorite) {

		this.favorite = favorite;
	}

	/** The tag name. */
	private String tag_name;

	/**
	 * Gets the tag name.
	 *
	 * @return the tag name
	 */
	public String getTag_name() {

		return tag_name;
	}

	/**
	 * Sets the tag name.
	 *
	 * @param tag_name the new tag name
	 */
	public void setTag_name(String tag_name) {

		this.tag_name = tag_name;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return ConvertPojoToHtml.convert(this);
	}

}

package com.rallio.automation.bussiness.newRallio.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class Stats.
 */
public class Stats {

	/** The number. */
	private int number;

	/** The label. */
	private String label;

	/**
	 * Gets the number.
	 *
	 * @return the number
	 */
	public int getNumber() {

		return number;
	}

	/**
	 * Sets the number.
	 *
	 * @param number the new number
	 */
	public void setNumber(int number) {

		this.number = number;
	}

	/**
	 * Gets the label.
	 *
	 * @return the label
	 */
	public String getLabel() {

		return label;
	}

	/**
	 * Sets the label.
	 *
	 * @param label the new label
	 */
	public void setLabel(String label) {

		this.label = label;
	}

}

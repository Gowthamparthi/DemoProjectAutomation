package com.rallio.automation.business.rallioLocalCenter.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class ReviewsLocalMetrics.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReviewsLocalMetrics {

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	/*@Override
	public String toString() {

		return "ReviewsLocalMetrics [awaiting_for_response_approval_count=" + awaiting_for_response_approval_count + ", awaiting_for_response_approval_percentage="
		        + awaiting_for_response_approval_percentage + ", not_responded_count=" + not_responded_count + ", replied_percentage=" + replied_percentage + ", responded_count="
		        + responded_count + ", review_response_rate=" + review_response_rate + ", total_reviews_count=" + total_reviews_count + "]";
	}

	/** The awaiting for response approval count. */
	private int awaiting_for_response_approval_count;

	/** The awaiting for response approval percentage. */
	private Object awaiting_for_response_approval_percentage;

	/** The not responded count. */
	private int not_responded_count;

	/** The replied percentage. */
	private Object replied_percentage;

	/** The responded count. */
	private int responded_count;

	/** The review response rate. */
	private Double review_response_rate;

	/** The total reviews count. */
	private int total_reviews_count;

	/**
	 * Gets the awaiting for response approval count.
	 *
	 * @return the awaiting for response approval count
	 */
	public int getAwaiting_for_response_approval_count() {

		return awaiting_for_response_approval_count;
	}

	/**
	 * Sets the awaiting for response approval count.
	 *
	 * @param awaiting_for_response_approval_count the new awaiting for response
	 *            approval count
	 */
	public void setAwaiting_for_response_approval_count(int awaiting_for_response_approval_count) {

		this.awaiting_for_response_approval_count = awaiting_for_response_approval_count;
	}

	/**
	 * Gets the awaiting for response approval percentage.
	 *
	 * @return the awaiting for response approval percentage
	 */
	public Object getAwaiting_for_response_approval_percentage() {

		return awaiting_for_response_approval_percentage;
	}

	/**
	 * Sets the awaiting for response approval percentage.
	 *
	 * @param awaiting_for_response_approval_percentage the new awaiting for
	 *            response approval percentage
	 */
	public void setAwaiting_for_response_approval_percentage(Object awaiting_for_response_approval_percentage) {

		this.awaiting_for_response_approval_percentage = awaiting_for_response_approval_percentage;
	}

	/**
	 * Gets the not responded count.
	 *
	 * @return the not responded count
	 */
	public int getNot_responded_count() {

		return not_responded_count;
	}

	/**
	 * Sets the not responded count.
	 *
	 * @param not_responded_count the new not responded count
	 */
	public void setNot_responded_count(int not_responded_count) {

		this.not_responded_count = not_responded_count;
	}

	/**
	 * Gets the replied percentage.
	 *
	 * @return the replied percentage
	 */
	public Object getReplied_percentage() {

		return replied_percentage;
	}

	/**
	 * Sets the replied percentage.
	 *
	 * @param replied_percentage the new replied percentage
	 */
	public void setReplied_percentage(Object replied_percentage) {

		this.replied_percentage = replied_percentage;
	}

	/**
	 * Gets the responded count.
	 *
	 * @return the responded count
	 */
	public int getResponded_count() {

		return responded_count;
	}

	/**
	 * Sets the responded count.
	 *
	 * @param responded_count the new responded count
	 */
	public void setResponded_count(int responded_count) {

		this.responded_count = responded_count;
	}

	/**
	 * Gets the review response rate.
	 *
	 * @return the review response rate
	 */
	public Double getReview_response_rate() {

		return review_response_rate;
	}

	/**
	 * Sets the review response rate.
	 *
	 * @param review_response_rate the new review response rate
	 */
	public void setReview_response_rate(Double review_response_rate) {

		this.review_response_rate = review_response_rate;
	}

	/**
	 * Gets the total reviews count.
	 *
	 * @return the total reviews count
	 */
	public int getTotal_reviews_count() {

		return total_reviews_count;
	}

	/**
	 * Sets the total reviews count.
	 *
	 * @param total_reviews_count the new total reviews count
	 */
	public void setTotal_reviews_count(int total_reviews_count) {

		this.total_reviews_count = total_reviews_count;
	}
}

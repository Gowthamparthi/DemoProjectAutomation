package com.rallio.automation.bussiness.newRallio.entity;

import java.util.ArrayList;
import java.util.Map;

public class MultiBrand {
	
	
	String brandName;
	
	String userName;
	
	String password;
	
	String logo;
	
	String signinPage;
	
	String signinUrl;
	
	String homePage;
	
	String homePageUrl;
	
	String location;

	
	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	ArrayList<String> modules;

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSigninPage() {
		return signinPage;
	}

	public void setSigninPage(String signinPage) {
		this.signinPage = signinPage;
	}

	public String getSigninUrl() {
		return signinUrl;
	}

	public void setSigninUrl(String signinUrl) {
		this.signinUrl = signinUrl;
	}

	public String getHomePage() {
		return homePage;
	}

	public void setHomePage(String homePage) {
		this.homePage = homePage;
	}

	public String getHomePageUrl() {
		return homePageUrl;
	}

	public void setHomePageUrl(String homePageUrl) {
		this.homePageUrl = homePageUrl;
	}

	public ArrayList<String> getModules() {
		return modules;
	}

	public void setModules(ArrayList<String> modules) {
		this.modules = modules;
	}


}

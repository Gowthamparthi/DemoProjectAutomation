package com.rallio.automation.business.rallioActivate.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class RecentPostStats.
 */
public class RecentPostStats {

	/** The label. */
	private String label;

	/** The number. */
	private int number;

	/**
	 * Gets the label.
	 *
	 * @return the label
	 */
	public String getLabel() {

		return label;
	}

	/**
	 * Sets the label.
	 *
	 * @param label the new label
	 */
	public void setLabel(String label) {

		this.label = label;
	}

	/**
	 * Gets the number.
	 *
	 * @return the number
	 */
	public int getNumber() {

		return number;
	}

	/**
	 * Sets the number.
	 *
	 * @param number the new number
	 */
	public void setNumber(int number) {

		this.number = number;
	}

}

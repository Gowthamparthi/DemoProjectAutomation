package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class User.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class User {

	/** The id. */
	private int id;

	/** The name. */
	private String name;

	/** The profile photo url. */
	private String profile_photo_url;

	/** The email. */
	private String email;

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {

		return email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {

		this.email = email;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {

		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {

		this.name = name;
	}

	/**
	 * Gets the profile photo url.
	 *
	 * @return the profile photo url
	 */
	public String getProfile_photo_url() {

		return profile_photo_url;
	}

	/**
	 * Sets the profile photo url.
	 *
	 * @param profile_photo_url the new profile photo url
	 */
	public void setProfile_photo_url(String profile_photo_url) {

		this.profile_photo_url = profile_photo_url;
	}

}

package com.rallio.automation.business.rallioLocalCenter.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class BusinessPhotos.
 */
public class BusinessPhotos {

	/** The id. */
	private String id;

	/** The photo. */
	private String photo;

	/** The type. */
	private String type;

	/** The synup id. */
	private String synup_id;

	/**
	 * Gets the synup id.
	 *
	 * @return the synup id
	 */
	public String getSynup_id() {

		return synup_id;
	}

	/**
	 * Sets the synup id.
	 *
	 * @param synup_id the new synup id
	 */
	public void setSynup_id(String synup_id) {

		this.synup_id = synup_id;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(String id) {

		this.id = id;
	}

	/**
	 * Gets the photo.
	 *
	 * @return the photo
	 */
	public String getPhoto() {

		return photo;
	}

	/**
	 * Sets the photo.
	 *
	 * @param photo the new photo
	 */
	public void setPhoto(String photo) {

		this.photo = photo;
	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {

		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(String type) {

		this.type = type;
	}

}

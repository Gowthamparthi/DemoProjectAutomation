package com.rallio.automation.business.rallioLocalCenter.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class UsersStats.
 */
public class UsersStats {

	/** The total users. */
	private int total_users;

	/** The admins count. */
	private int admins_count;

	/** The non admins count. */
	private int non_admins_count;

	/**
	 * Gets the total users.
	 *
	 * @return the total users
	 */
	public int getTotal_users() {

		return total_users;
	}

	/**
	 * Sets the total users.
	 *
	 * @param total_users the new total users
	 */
	public void setTotal_users(int total_users) {

		this.total_users = total_users;
	}

	/**
	 * Gets the admins count.
	 *
	 * @return the admins count
	 */
	public int getAdmins_count() {

		return admins_count;
	}

	/**
	 * Sets the admins count.
	 *
	 * @param admins_count the new admins count
	 */
	public void setAdmins_count(int admins_count) {

		this.admins_count = admins_count;
	}

	/**
	 * Gets the non admins count.
	 *
	 * @return the non admins count
	 */
	public int getNon_admins_count() {

		return non_admins_count;
	}

	/**
	 * Sets the non admins count.
	 *
	 * @param non_admins_count the new non admins count
	 */
	public void setNon_admins_count(int non_admins_count) {

		this.non_admins_count = non_admins_count;
	}
}

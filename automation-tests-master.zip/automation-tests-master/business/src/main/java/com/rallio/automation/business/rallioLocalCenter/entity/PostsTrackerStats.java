package com.rallio.automation.business.rallioLocalCenter.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class PostsTrackerStats.
 */
public class PostsTrackerStats {

	/** The accounts count. */
	private int accounts_count;

	/** The boost dollars spent. */
	private int boost_dollars_spent;

	/** The published posts count. */
	private int published_posts_count;

	/**
	 * Gets the accounts count.
	 *
	 * @return the accounts count
	 */
	public int getAccounts_count() {

		return accounts_count;
	}

	/**
	 * Sets the accounts count.
	 *
	 * @param accounts_count the new accounts count
	 */
	public void setAccounts_count(int accounts_count) {

		this.accounts_count = accounts_count;
	}

	/**
	 * Gets the boost dollars spent.
	 *
	 * @return the boost dollars spent
	 */
	public int getBoost_dollars_spent() {

		return boost_dollars_spent;
	}

	/**
	 * Sets the boost dollars spent.
	 *
	 * @param boost_dollars_spent the new boost dollars spent
	 */
	public void setBoost_dollars_spent(int boost_dollars_spent) {

		this.boost_dollars_spent = boost_dollars_spent;
	}

	/**
	 * Gets the published posts count.
	 *
	 * @return the published posts count
	 */
	public int getPublished_posts_count() {

		return published_posts_count;
	}

	/**
	 * Sets the published posts count.
	 *
	 * @param published_posts_count the new published posts count
	 */
	public void setPublished_posts_count(int published_posts_count) {

		this.published_posts_count = published_posts_count;
	}

}

package com.rallio.automation.bussiness.newRallio.entity;


public class FranchisorGroups {

}

package com.rallio.automation.business.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum RankingMetric.
 */
public enum RankingMetric {

	/** The assets submitted. */
	ASSETS_SUBMITTED("Assets Submitted"),

	/** The engagement from assets. */
	ENGAGEMENT_FROM_ASSETS("Engagement From Assets"),

	/** The advocacy posts. */
	ADVOCACY_POSTS("Advocacy Posts"),

	/** The total score. */
	TOTAL_SCORE("Total Score");

	/** The text. */
	private String text;

	/**
	 * Instantiates a new ranking metric.
	 *
	 * @param text the text
	 */
	private RankingMetric(String text) {

		this.text = text;
	}

	/**
	 * Gets the text.
	 *
	 * @return the text
	 */
	public String getText() {

		return this.text;
	}
}

package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class SavedPosts.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SavedPosts {

	/** The account. */
	private AccountsList account;

	/** The boost offer id. */
	private String boost_offer_id;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return "SavedPosts [account=" + account + ", boost_offer_id=" + boost_offer_id + ", cloudinary_resource_type=" + cloudinary_resource_type + ", cloudinary_video_id="
		        + cloudinary_video_id + ", created_at=" + created_at + ", created_user=" + created_user + ", end_date=" + end_date + ", franchisor=" + franchisor + ", id=" + id
		        + ", link_preview_description=" + link_preview_description + ", link_preview_image_url=" + link_preview_image_url + ", link_preview_image_url_choices="
		        + link_preview_image_url_choices + ", link_preview_title=" + link_preview_title + ", locked=" + locked + ", long_text=" + long_text + ", mobile_app_only_enabled="
		        + mobile_app_only_enabled + ", photo_url=" + photo_url + ", photo_urls=" + photo_urls + ", post_published_count=" + post_published_count + ", rejected=" + rejected
		        + ", short_text=" + short_text + ", start_date=" + start_date + ", syndicated_from_content_id=" + syndicated_from_content_id + ", tags_list=" + tags_list
		        + ", trashed=" + trashed + ", updated_at=" + updated_at + ", url=" + url + ", use_facebook=" + use_facebook + ", use_google=" + use_google + ", use_instagram="
		        + use_instagram + ", use_linkedin=" + use_linkedin + ", use_twitter=" + use_twitter + ", use_twitter_photo=" + use_twitter_photo + ", video_url=" + video_url
		        + ", account_id=" + account_id + "]";
	}

	/** The cloudinary resource type. */
	private String cloudinary_resource_type;

	/** The cloudinary video id. */
	private String cloudinary_video_id;

	/** The created at. */
	private String created_at;

	/** The created user. */
	private User created_user;

	/** The end date. */
	private String end_date;

	/** The franchisor. */
	private Franchisors franchisor;

	/** The id. */
	private int id;

	/** The link preview description. */
	private String link_preview_description;

	/** The link preview image url. */
	private String link_preview_image_url;

	/** The link preview image url choices. */
	private List<String> link_preview_image_url_choices;

	/** The link preview title. */
	private String link_preview_title;

	/** The locked. */
	private boolean locked;

	/** The long text. */
	private String long_text;

	/** The mobile app only enabled. */
	private boolean mobile_app_only_enabled;

	/** The photo url. */
	private String photo_url;

	/** The photo urls. */
	private List<String> photo_urls;

	/** The post published count. */
	private int post_published_count;

	/** The rejected. */
	private boolean rejected;

	/** The short text. */
	private String short_text;

	/** The start date. */
	private String start_date;

	/** The status id. */
	private String status_id;

	/** The syndicated from content id. */
	private String syndicated_from_content_id;

	/** The tags list. */
	private String tags_list;

	/** The trashed. */
	private boolean trashed;

	/** The updated at. */
	private String updated_at;

	/** The url. */
	private String url;

	/** The use facebook. */
	private boolean use_facebook;

	/** The use google. */
	private boolean use_google;

	/** The use instagram. */
	private boolean use_instagram;

	/** The use linkedin. */
	private boolean use_linkedin;

	/** The use twitter. */
	private boolean use_twitter;

	/** The use twitter photo. */
	private boolean use_twitter_photo;

	/** The video url. */
	private String video_url;

	/**
	 * Gets the account id.
	 *
	 * @return the account id
	 */
	public int getAccount_id() {

		return account_id;
	}

	/**
	 * Sets the account id.
	 *
	 * @param account_id the new account id
	 */
	public void setAccount_id(int account_id) {

		this.account_id = account_id;
	}

	/** The account id. */
	private int account_id;

	/**
	 * Gets the account.
	 *
	 * @return the account
	 */
	public AccountsList getAccount() {

		return account;
	}

	/**
	 * Sets the account.
	 *
	 * @param account the new account
	 */
	public void setAccount(AccountsList account) {

		this.account = account;
	}

	/**
	 * Gets the boost offer id.
	 *
	 * @return the boost offer id
	 */
	public String getBoost_offer_id() {

		return boost_offer_id;
	}

	/**
	 * Sets the boost offer id.
	 *
	 * @param boost_offer_id the new boost offer id
	 */
	public void setBoost_offer_id(String boost_offer_id) {

		this.boost_offer_id = boost_offer_id;
	}

	/**
	 * Gets the cloudinary resource type.
	 *
	 * @return the cloudinary resource type
	 */
	public String getCloudinary_resource_type() {

		return cloudinary_resource_type;
	}

	/**
	 * Sets the cloudinary resource type.
	 *
	 * @param cloudinary_resource_type the new cloudinary resource type
	 */
	public void setCloudinary_resource_type(String cloudinary_resource_type) {

		this.cloudinary_resource_type = cloudinary_resource_type;
	}

	/**
	 * Gets the cloudinary video id.
	 *
	 * @return the cloudinary video id
	 */
	public String getCloudinary_video_id() {

		return cloudinary_video_id;
	}

	/**
	 * Sets the cloudinary video id.
	 *
	 * @param cloudinary_video_id the new cloudinary video id
	 */
	public void setCloudinary_video_id(String cloudinary_video_id) {

		this.cloudinary_video_id = cloudinary_video_id;
	}

	/**
	 * Gets the created at.
	 *
	 * @return the created at
	 */
	public String getCreated_at() {

		return created_at;
	}

	/**
	 * Sets the created at.
	 *
	 * @param created_at the new created at
	 */
	public void setCreated_at(String created_at) {

		this.created_at = created_at;
	}

	/**
	 * Gets the created user.
	 *
	 * @return the created user
	 */
	public User getCreated_user() {

		return created_user;
	}

	/**
	 * Sets the created user.
	 *
	 * @param created_user the new created user
	 */
	public void setCreated_user(User created_user) {

		this.created_user = created_user;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public String getEnd_date() {

		return end_date;
	}

	/**
	 * Sets the end date.
	 *
	 * @param end_date the new end date
	 */
	public void setEnd_date(String end_date) {

		this.end_date = end_date;
	}

	/**
	 * Gets the franchisor.
	 *
	 * @return the franchisor
	 */
	public Franchisors getFranchisor() {

		return franchisor;
	}

	/**
	 * Sets the franchisor.
	 *
	 * @param franchisor the new franchisor
	 */
	public void setFranchisor(Franchisors franchisor) {

		this.franchisor = franchisor;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/**
	 * Gets the link preview description.
	 *
	 * @return the link preview description
	 */
	public String getLink_preview_description() {

		return link_preview_description;
	}

	/**
	 * Sets the link preview description.
	 *
	 * @param link_preview_description the new link preview description
	 */
	public void setLink_preview_description(String link_preview_description) {

		this.link_preview_description = link_preview_description;
	}

	/**
	 * Gets the link preview image url.
	 *
	 * @return the link preview image url
	 */
	public String getLink_preview_image_url() {

		return link_preview_image_url;
	}

	/**
	 * Sets the link preview image url.
	 *
	 * @param link_preview_image_url the new link preview image url
	 */
	public void setLink_preview_image_url(String link_preview_image_url) {

		this.link_preview_image_url = link_preview_image_url;
	}

	/**
	 * Gets the link preview image url choices.
	 *
	 * @return the link preview image url choices
	 */
	public List<String> getLink_preview_image_url_choices() {

		return link_preview_image_url_choices;
	}

	/**
	 * Sets the link preview image url choices.
	 *
	 * @param link_preview_image_url_choices the new link preview image url
	 *            choices
	 */
	public void setLink_preview_image_url_choices(List<String> link_preview_image_url_choices) {

		this.link_preview_image_url_choices = link_preview_image_url_choices;
	}

	/**
	 * Gets the link preview title.
	 *
	 * @return the link preview title
	 */
	public String getLink_preview_title() {

		return link_preview_title;
	}

	/**
	 * Sets the link preview title.
	 *
	 * @param link_preview_title the new link preview title
	 */
	public void setLink_preview_title(String link_preview_title) {

		this.link_preview_title = link_preview_title;
	}

	/**
	 * Checks if is locked.
	 *
	 * @return true, if is locked
	 */
	public boolean isLocked() {

		return locked;
	}

	/**
	 * Sets the locked.
	 *
	 * @param locked the new locked
	 */
	public void setLocked(boolean locked) {

		this.locked = locked;
	}

	/**
	 * Gets the long text.
	 *
	 * @return the long text
	 */
	public String getLong_text() {

		return long_text;
	}

	/**
	 * Sets the long text.
	 *
	 * @param long_text the new long text
	 */
	public void setLong_text(String long_text) {

		this.long_text = long_text;
	}

	/**
	 * Checks if is mobile app only enabled.
	 *
	 * @return true, if is mobile app only enabled
	 */
	public boolean isMobile_app_only_enabled() {

		return mobile_app_only_enabled;
	}

	/**
	 * Sets the mobile app only enabled.
	 *
	 * @param mobile_app_only_enabled the new mobile app only enabled
	 */
	public void setMobile_app_only_enabled(boolean mobile_app_only_enabled) {

		this.mobile_app_only_enabled = mobile_app_only_enabled;
	}

	/**
	 * Gets the photo url.
	 *
	 * @return the photo url
	 */
	public String getPhoto_url() {

		return photo_url;
	}

	/**
	 * Sets the photo url.
	 *
	 * @param photo_url the new photo url
	 */
	public void setPhoto_url(String photo_url) {

		this.photo_url = photo_url;
	}

	/**
	 * Gets the photo urls.
	 *
	 * @return the photo urls
	 */
	public List<String> getPhoto_urls() {

		return photo_urls;
	}

	/**
	 * Sets the photo urls.
	 *
	 * @param photo_urls the new photo urls
	 */
	public void setPhoto_urls(List<String> photo_urls) {

		this.photo_urls = photo_urls;
	}

	/**
	 * Gets the post published count.
	 *
	 * @return the post published count
	 */
	public int getPost_published_count() {

		return post_published_count;
	}

	/**
	 * Sets the post published count.
	 *
	 * @param post_published_count the new post published count
	 */
	public void setPost_published_count(int post_published_count) {

		this.post_published_count = post_published_count;
	}

	/**
	 * Checks if is rejected.
	 *
	 * @return true, if is rejected
	 */
	public boolean isRejected() {

		return rejected;
	}

	/**
	 * Sets the rejected.
	 *
	 * @param rejected the new rejected
	 */
	public void setRejected(boolean rejected) {

		this.rejected = rejected;
	}

	/**
	 * Gets the short text.
	 *
	 * @return the short text
	 */
	public String getShort_text() {

		return short_text;
	}

	/**
	 * Sets the short text.
	 *
	 * @param short_text the new short text
	 */
	public void setShort_text(String short_text) {

		this.short_text = short_text;
	}

	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public String getStart_date() {

		return start_date;
	}

	/**
	 * Sets the start date.
	 *
	 * @param start_date the new start date
	 */
	public void setStart_date(String start_date) {

		this.start_date = start_date;
	}

	/**
	 * Gets the status id.
	 *
	 * @return the status id
	 */
	public String getStatus_id() {

		return status_id;
	}

	/**
	 * Sets the status id.
	 *
	 * @param status_id the new status id
	 */
	public void setStatus_id(String status_id) {

		this.status_id = status_id;
	}

	/**
	 * Gets the syndicated from content id.
	 *
	 * @return the syndicated from content id
	 */
	public String getSyndicated_from_content_id() {

		return syndicated_from_content_id;
	}

	/**
	 * Sets the syndicated from content id.
	 *
	 * @param syndicated_from_content_id the new syndicated from content id
	 */
	public void setSyndicated_from_content_id(String syndicated_from_content_id) {

		this.syndicated_from_content_id = syndicated_from_content_id;
	}

	/**
	 * Gets the tags list.
	 *
	 * @return the tags list
	 */
	public String getTags_list() {

		return tags_list;
	}

	/**
	 * Sets the tags list.
	 *
	 * @param tags_list the new tags list
	 */
	public void setTags_list(String tags_list) {

		this.tags_list = tags_list;
	}

	/**
	 * Checks if is trashed.
	 *
	 * @return true, if is trashed
	 */
	public boolean isTrashed() {

		return trashed;
	}

	/**
	 * Sets the trashed.
	 *
	 * @param trashed the new trashed
	 */
	public void setTrashed(boolean trashed) {

		this.trashed = trashed;
	}

	/**
	 * Gets the updated at.
	 *
	 * @return the updated at
	 */
	public String getUpdated_at() {

		return updated_at;
	}

	/**
	 * Sets the updated at.
	 *
	 * @param updated_at the new updated at
	 */
	public void setUpdated_at(String updated_at) {

		this.updated_at = updated_at;
	}

	/**
	 * Gets the url.
	 *
	 * @return the url
	 */
	public String getUrl() {

		return url;
	}

	/**
	 * Sets the url.
	 *
	 * @param url the new url
	 */
	public void setUrl(String url) {

		this.url = url;
	}

	/**
	 * Checks if is use facebook.
	 *
	 * @return true, if is use facebook
	 */
	public boolean isUse_facebook() {

		return use_facebook;
	}

	/**
	 * Sets the use facebook.
	 *
	 * @param use_facebook the new use facebook
	 */
	public void setUse_facebook(boolean use_facebook) {

		this.use_facebook = use_facebook;
	}

	/**
	 * Checks if is use google.
	 *
	 * @return true, if is use google
	 */
	public boolean isUse_google() {

		return use_google;
	}

	/**
	 * Sets the use google.
	 *
	 * @param use_google the new use google
	 */
	public void setUse_google(boolean use_google) {

		this.use_google = use_google;
	}

	/**
	 * Checks if is use instagram.
	 *
	 * @return true, if is use instagram
	 */
	public boolean isUse_instagram() {

		return use_instagram;
	}

	/**
	 * Sets the use instagram.
	 *
	 * @param use_instagram the new use instagram
	 */
	public void setUse_instagram(boolean use_instagram) {

		this.use_instagram = use_instagram;
	}

	/**
	 * Checks if is use linkedin.
	 *
	 * @return true, if is use linkedin
	 */
	public boolean isUse_linkedin() {

		return use_linkedin;
	}

	/**
	 * Sets the use linkedin.
	 *
	 * @param use_linkedin the new use linkedin
	 */
	public void setUse_linkedin(boolean use_linkedin) {

		this.use_linkedin = use_linkedin;
	}

	/**
	 * Checks if is use twitter.
	 *
	 * @return true, if is use twitter
	 */
	public boolean isUse_twitter() {

		return use_twitter;
	}

	/**
	 * Sets the use twitter.
	 *
	 * @param use_twitter the new use twitter
	 */
	public void setUse_twitter(boolean use_twitter) {

		this.use_twitter = use_twitter;
	}

	/**
	 * Checks if is use twitter photo.
	 *
	 * @return true, if is use twitter photo
	 */
	public boolean isUse_twitter_photo() {

		return use_twitter_photo;
	}

	/**
	 * Sets the use twitter photo.
	 *
	 * @param use_twitter_photo the new use twitter photo
	 */
	public void setUse_twitter_photo(boolean use_twitter_photo) {

		this.use_twitter_photo = use_twitter_photo;
	}

	/**
	 * Gets the video url.
	 *
	 * @return the video url
	 */
	public String getVideo_url() {

		return video_url;
	}

	/**
	 * Sets the video url.
	 *
	 * @param video_url the new video url
	 */
	public void setVideo_url(String video_url) {

		this.video_url = video_url;
	}

}

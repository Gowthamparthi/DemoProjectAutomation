package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class ListOfLocations.
 */
public class ListOfLocations {

	/** The accounts count. */
	private int accounts_count;

	/** The accounts. */
	private List<LocationsList> accounts;

	/**
	 * Gets the accounts count.
	 *
	 * @return the accounts count
	 */
	public int getAccounts_count() {

		return accounts_count;
	}

	/**
	 * Sets the accounts count.
	 *
	 * @param accounts_count the new accounts count
	 */
	public void setAccounts_count(int accounts_count) {

		this.accounts_count = accounts_count;
	}

	/**
	 * Gets the accounts.
	 *
	 * @return the accounts
	 */
	public List<LocationsList> getAccounts() {

		return accounts;
	}

	/**
	 * Sets the accounts.
	 *
	 * @param accounts the new accounts
	 */
	public void setAccounts(List<LocationsList> accounts) {

		this.accounts = accounts;
	}

}

package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class RecentPostStatistics.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RecentPostStatistics {

	/** The engagement comments. */
	private int engagement_comments;

	/** The engagement likes. */
	private int engagement_likes;

	/** The engagement shares. */
	private int engagement_shares;

	/**
	 * Gets the engagement comments.
	 *
	 * @return the engagement comments
	 */
	public int getEngagement_comments() {

		return engagement_comments;
	}

	/**
	 * Sets the engagement comments.
	 *
	 * @param engagement_comments the new engagement comments
	 */
	public void setEngagement_comments(int engagement_comments) {

		this.engagement_comments = engagement_comments;
	}

	/**
	 * Gets the engagement likes.
	 *
	 * @return the engagement likes
	 */
	public int getEngagement_likes() {

		return engagement_likes;
	}

	/**
	 * Sets the engagement likes.
	 *
	 * @param engagement_likes the new engagement likes
	 */
	public void setEngagement_likes(int engagement_likes) {

		this.engagement_likes = engagement_likes;
	}

	/**
	 * Gets the engagement shares.
	 *
	 * @return the engagement shares
	 */
	public int getEngagement_shares() {

		return engagement_shares;
	}

	/**
	 * Sets the engagement shares.
	 *
	 * @param engagement_shares the new engagement shares
	 */
	public void setEngagement_shares(int engagement_shares) {

		this.engagement_shares = engagement_shares;
	}

}

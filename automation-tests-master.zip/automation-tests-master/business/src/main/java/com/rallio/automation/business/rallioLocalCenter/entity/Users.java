package com.rallio.automation.business.rallioLocalCenter.entity;

import java.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Users.
 */
public class Users {

	/** The users. */
	private ArrayList<UsersList> users;

	/**
	 * Gets the users.
	 *
	 * @return the users
	 */
	public ArrayList<UsersList> getUsers() {

		return users;
	}

	/**
	 * Sets the users.
	 *
	 * @param users the new users
	 */
	public void setUsers(ArrayList<UsersList> users) {

		this.users = users;
	}
}

package com.rallio.automation.business.rallioActivate.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class Employee.
 */
public class Employee {

	/** The user id. */
	private String user_id;

	/** The last name. */
	private String last_name;

	/** The first name. */
	private String first_name;

	/** The display name. */
	private String display_name;

	/** The profile photo url. */
	private String profile_photo_url;

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUser_id() {

		return user_id;
	}

	/**
	 * Sets the user id.
	 *
	 * @param user_id the new user id
	 */
	public void setUser_id(String user_id) {

		this.user_id = user_id;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLast_name() {

		return last_name;
	}

	/**
	 * Sets the last name.
	 *
	 * @param last_name the new last name
	 */
	public void setLast_name(String last_name) {

		this.last_name = last_name;
	}

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirst_name() {

		return first_name;
	}

	/**
	 * Sets the first name.
	 *
	 * @param first_name the new first name
	 */
	public void setFirst_name(String first_name) {

		this.first_name = first_name;
	}

	/**
	 * Gets the display name.
	 *
	 * @return the display name
	 */
	public String getDisplay_name() {

		return display_name;
	}

	/**
	 * Sets the display name.
	 *
	 * @param display_name the new display name
	 */
	public void setDisplay_name(String display_name) {

		this.display_name = display_name;
	}

	/**
	 * Gets the profile photo url.
	 *
	 * @return the profile photo url
	 */
	public String getProfile_photo_url() {

		return profile_photo_url;
	}

	/**
	 * Sets the profile photo url.
	 *
	 * @param profile_photo_url the new profile photo url
	 */
	public void setProfile_photo_url(String profile_photo_url) {

		this.profile_photo_url = profile_photo_url;
	}

}

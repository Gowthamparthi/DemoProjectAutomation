package com.rallio.automation.business.rallioLocalCenter.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class CalendarEventOccurence.
 */
public class CalendarEventOccurence {

	/** The end datetime. */
	private String end_datetime;

	/** The start datetime. */
	private String start_datetime;

	/**
	 * Gets the end datetime.
	 *
	 * @return the end datetime
	 */
	public String getEnd_datetime() {

		return end_datetime;
	}

	/**
	 * Sets the end datetime.
	 *
	 * @param end_datetime the new end datetime
	 */
	public void setEnd_datetime(String end_datetime) {

		this.end_datetime = end_datetime;
	}

	/**
	 * Gets the start datetime.
	 *
	 * @return the start datetime
	 */
	public String getStart_datetime() {

		return start_datetime;
	}

	/**
	 * Sets the start datetime.
	 *
	 * @param start_datetime the new start datetime
	 */
	public void setStart_datetime(String start_datetime) {

		this.start_datetime = start_datetime;
	}
}

package com.rallio.automation.bussiness.newRallio.entity;

import java.util.List;

public class DownloadCsvColumns {
	
    private List<String> columns;

	public List<String> getColumns() {
		return columns;
	}

	public void setColumns(List<String> columns) {
		this.columns = columns;
	}
}

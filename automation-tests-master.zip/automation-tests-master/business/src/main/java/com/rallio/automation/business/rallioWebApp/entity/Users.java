package com.rallio.automation.business.rallioWebApp.entity;

import java.util.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

// TODO: Auto-generated Javadoc
/**
 * The Class Users.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Users {

    private int id;

    private String email;

    private String first_name;

    private String last_name;

    private String company_name;

    private boolean admin;

    private boolean franchisor;

    private boolean franchisor_group_user;

    private int detail_id;

    private boolean disable_scheduled_posting;

    private boolean has_facebook_boost_access;

    private boolean receive_monthly_enduser_report;

    private List<Integer> review_alert_ratings;
    
    private User user;

    public void setId(Integer id){
        this.id = id;
    }
    public Integer getId(){
        return this.id;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public String getEmail(){
        return this.email;
    }
    public void setFirst_name(String first_name){
        this.first_name = first_name;
    }
    public String getFirst_name(){
        return this.first_name;
    }
    public void setLast_name(String last_name){
        this.last_name = last_name;
    }
    public String getLast_name(){
        return this.last_name;
    }
    public void setCompany_name(String company_name){
        this.company_name = company_name;
    }
    public String getCompany_name(){
        return this.company_name;
    }
    public void setAdmin(boolean admin){
        this.admin = admin;
    }
    public boolean getAdmin(){
        return this.admin;
    }
    public void setFranchisor(boolean franchisor){
        this.franchisor = franchisor;
    }
    public boolean getFranchisor(){
        return this.franchisor;
    }
    public void setFranchisor_group_user(boolean franchisor_group_user){
        this.franchisor_group_user = franchisor_group_user;
    }
    public boolean getFranchisor_group_user(){
        return this.franchisor_group_user;
    }
    public void setDetail_id(int detail_id){
        this.detail_id = detail_id;
    }
    public int getDetail_id(){
        return this.detail_id;
    }
    public void setDisable_scheduled_posting(boolean disable_scheduled_posting){
        this.disable_scheduled_posting = disable_scheduled_posting;
    }
    public boolean getDisable_scheduled_posting(){
        return this.disable_scheduled_posting;
    }
    public void setHas_facebook_boost_access(boolean has_facebook_boost_access){
        this.has_facebook_boost_access = has_facebook_boost_access;
    }
    public boolean getHas_facebook_boost_access(){
        return this.has_facebook_boost_access;
    }
    public void setReceive_monthly_enduser_report(boolean receive_monthly_enduser_report){
        this.receive_monthly_enduser_report = receive_monthly_enduser_report;
    }
    public boolean getReceive_monthly_enduser_report(){
        return this.receive_monthly_enduser_report;
    }
    public void setReview_alert_ratings(List<Integer> review_alert_ratings){
        this.review_alert_ratings = review_alert_ratings;
    }
    public List<Integer> getReview_alert_ratings(){
        return this.review_alert_ratings;
    }
    
    public void setUser(User user){
        this.user = user;
    }
    public User getUser(){
        return this.user;
    }
}

package com.rallio.automation.business.rallioActivate.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class RewardProgramSchedulerDetails.
 */
public class RewardProgramSchedulerDetails {

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return "RewardProgramSchedulerDetails [programName=" + programName + ", endDate=" + endDate + ", budget=" + budget + ", startDate=" + startDate + "]";
	}

	/** The program name. */
	private String programName;

	/** The end date. */
	private String endDate;

	/** The budget. */
	private String budget;

	/** The start date. */
	private String startDate;

	/** The env. */
	private String env;

	/**
	 * Gets the env.
	 *
	 * @return the env
	 */
	public String getEnv() {

		return env;
	}

	/**
	 * Sets the env.
	 *
	 * @param env the new env
	 */
	public void setEnv(String env) {

		this.env = env;
	}

	/**
	 * Gets the browser.
	 *
	 * @return the browser
	 */
	public String getBrowser() {

		return browser;
	}

	/**
	 * Sets the browser.
	 *
	 * @param browser the new browser
	 */
	public void setBrowser(String browser) {

		this.browser = browser;
	}

	/** The browser. */
	private String browser;

	/**
	 * Gets the program name.
	 *
	 * @return the program name
	 */
	public String getProgramName() {

		return programName;
	}

	/**
	 * Sets the program name.
	 *
	 * @param programName the new program name
	 */
	public void setProgramName(String programName) {

		this.programName = programName;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public String getEndDate() {

		return endDate;
	}

	/**
	 * Sets the end date.
	 *
	 * @param endDate the new end date
	 */
	public void setEndDate(String endDate) {

		this.endDate = endDate;
	}

	/**
	 * Gets the budget.
	 *
	 * @return the budget
	 */
	public String getBudget() {

		return budget;
	}

	/**
	 * Sets the budget.
	 *
	 * @param budget the new budget
	 */
	public void setBudget(String budget) {

		this.budget = budget;
	}

	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public String getStartDate() {

		return startDate;
	}

	/**
	 * Sets the start date.
	 *
	 * @param startDate the new start date
	 */
	public void setStartDate(String startDate) {

		this.startDate = startDate;
	}

}

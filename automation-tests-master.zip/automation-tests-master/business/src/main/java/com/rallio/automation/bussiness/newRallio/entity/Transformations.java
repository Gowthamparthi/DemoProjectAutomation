package com.rallio.automation.bussiness.newRallio.entity;

public class Transformations {

	private int rotate;

	private Crop crop;

	private boolean enhance;

	public int getRotate() {

		return rotate;
	}

	public void setRotate(int rotate) {

		this.rotate = rotate;
	}

	public Crop getCrop() {

		return crop;
	}

	public void setCrop(Crop crop) {

		this.crop = crop;
	}

	public boolean isEnhance() {

		return enhance;
	}

	public void setEnhance(boolean enhance) {

		this.enhance = enhance;
	}

}

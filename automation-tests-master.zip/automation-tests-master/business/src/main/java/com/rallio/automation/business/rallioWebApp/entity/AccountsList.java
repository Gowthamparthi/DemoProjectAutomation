package com.rallio.automation.business.rallioWebApp.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

// TODO: Auto-generated Javadoc
/**
 * The Class AccountsList.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountsList {

    private List<Accounts> accounts;

    public void setAccounts(List<Accounts> accounts){
        this.accounts = accounts;
    }
    public List<Accounts> getAccounts(){
        return this.accounts;
    }
	@Override
	public String toString() {
		return "AccountsList [accounts=" + accounts + "]";
	}
    
    
}

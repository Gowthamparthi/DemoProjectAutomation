package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class CommunityManagementAdvocatesData.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class CommunityManagementAdvocatesData {

	/** The advocate id. */
	private int advocateId;

	/** The first name. */
	private String firstName;

	/** The last name. */
	private String lastName;

	/** The email. */
	private String email;

	/** The contact. */
	private String contact;

	/** The email status. */
	private boolean emailStatus;

	/** The app status. */
	private boolean appStatus;

	/** The invite email date. */
	private String inviteEmailDate;

	/** The app installed date. */
	private String appInstalledDate;

	/** The recent activity date. */
	private String recentActivityDate;

	/**
	 * Gets the advocate id.
	 *
	 * @return the advocate id
	 */
	public int getAdvocateId() {

		return advocateId;
	}

	/**
	 * Sets the advocate id.
	 *
	 * @param advocateId the new advocate id
	 */
	public void setAdvocateId(int advocateId) {

		this.advocateId = advocateId;
	}

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {

		return firstName;
	}

	/**
	 * Sets the first name.
	 *
	 * @param firstName the new first name
	 */
	public void setFirstName(String firstName) {

		this.firstName = firstName;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {

		return lastName;
	}

	/**
	 * Sets the last name.
	 *
	 * @param lastName the new last name
	 */
	public void setLastName(String lastName) {

		this.lastName = lastName;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {

		return email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {

		this.email = email;
	}

	/**
	 * Gets the contact.
	 *
	 * @return the contact
	 */
	public String getContact() {

		return contact;
	}

	/**
	 * Sets the contact.
	 *
	 * @param contact the new contact
	 */
	public void setContact(String contact) {

		this.contact = contact;
	}

	/**
	 * Checks if is email status.
	 *
	 * @return true, if is email status
	 */
	public boolean isEmailStatus() {

		return emailStatus;
	}

	/**
	 * Sets the email status.
	 *
	 * @param emailStatus the new email status
	 */
	public void setEmailStatus(boolean emailStatus) {

		this.emailStatus = emailStatus;
	}

	/**
	 * Checks if is app status.
	 *
	 * @return true, if is app status
	 */
	public boolean isAppStatus() {

		return appStatus;
	}

	/**
	 * Sets the app status.
	 *
	 * @param appStatus the new app status
	 */
	public void setAppStatus(boolean appStatus) {

		this.appStatus = appStatus;
	}

	/**
	 * Gets the invite email date.
	 *
	 * @return the invite email date
	 */
	public String getInviteEmailDate() {

		return inviteEmailDate;
	}

	/**
	 * Sets the invite email date.
	 *
	 * @param inviteEmailDate the new invite email date
	 */
	public void setInviteEmailDate(String inviteEmailDate) {

		this.inviteEmailDate = inviteEmailDate;
	}

	/**
	 * Gets the app installed date.
	 *
	 * @return the app installed date
	 */
	public String getAppInstalledDate() {

		return appInstalledDate;
	}

	/**
	 * Sets the app installed date.
	 *
	 * @param appInstalledDate the new app installed date
	 */
	public void setAppInstalledDate(String appInstalledDate) {

		this.appInstalledDate = appInstalledDate;
	}

	/**
	 * Gets the recent activity date.
	 *
	 * @return the recent activity date
	 */
	public String getRecentActivityDate() {

		return recentActivityDate;
	}

	/**
	 * Sets the recent activity date.
	 *
	 * @param recentActivityDate the new recent activity date
	 */
	public void setRecentActivityDate(String recentActivityDate) {

		this.recentActivityDate = recentActivityDate;
	}
}

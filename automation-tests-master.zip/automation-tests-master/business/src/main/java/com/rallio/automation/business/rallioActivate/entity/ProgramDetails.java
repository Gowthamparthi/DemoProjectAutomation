package com.rallio.automation.business.rallioActivate.entity;

import com.rallio.automation.common.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class ProgramDetails.
 */
public class ProgramDetails {

	/** The program name. */
	private String programName;

	/** The program type. */
	private String programType;

	/** The program duration. */
	private String programDuration;

	/** The program ongoingDuration. */
	private String ongoingDuration;

	/** The budget. */
	private String budget;

	/** The duration summary. */
	private String durationSummary;

	/**
	 * Gets the budget.
	 *
	 * @return the budget
	 */
	public String getBudget() {

		return budget;
	}

	/**
	 * Sets the budget.
	 *
	 * @param budget the new budget
	 */
	public void setBudget(String budget) {

		this.budget = budget;
	}

	/**
	 * Gets the program type.
	 *
	 * @return the program type
	 */
	public String getProgramType() {

		return programType;
	}

	/**
	 * Sets the program type.
	 *
	 * @param programType the new program type
	 */
	public void setProgramType(String programType) {

		this.programType = programType;
	}

	/**
	 * Gets the program duration.
	 *
	 * @return the program duration
	 */
	public String getProgramDuration() {

		return programDuration;
	}

	/**
	 * Sets the program duration.
	 *
	 * @param programDuration the new program duration
	 */
	public void setProgramDuration(String programDuration) {

		this.programDuration = programDuration;
	}

	/**
	 * Gets the ongoing duration.
	 *
	 * @return the ongoing duration
	 */
	public String getOngoingDuration() {

		return ongoingDuration;
	}

	/**
	 * Sets the ongoing duration.
	 *
	 * @param ongoingDuration the new ongoing duration
	 */
	public void setOngoingDuration(String ongoingDuration) {

		this.ongoingDuration = ongoingDuration;
	}

	/**
	 * Sets the program name.
	 *
	 * @param programName the new program name
	 */
	public void setProgramName(String programName) {

		this.programName = programName;
	}

	/**
	 * Gets the program name.
	 *
	 * @return the program name
	 */
	public String getProgramName() {

		return programName;
	}

	/**
	 * Gets the duration summary.
	 *
	 * @return the duration summary
	 */
	public String getDurationSummary() {

		return durationSummary;
	}

	/**
	 * Sets the duration summary.
	 *
	 * @param durationSummary the new duration summary
	 */
	public void setDurationSummary(String durationSummary) {

		this.durationSummary = durationSummary;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return ConvertPojoToHtml.convert(this);
	}
}

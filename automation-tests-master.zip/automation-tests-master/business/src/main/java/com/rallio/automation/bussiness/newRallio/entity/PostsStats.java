package com.rallio.automation.bussiness.newRallio.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class PostsStats.
 */
public class PostsStats {

	/** The boosted posts. */
	private int boosted_posts;

	/** The not published posts. */
	private int not_published_posts;

	/** The published posts. */
	private int published_posts;

	/** The total posts. */
	private int total_posts;

	/**
	 * Gets the boosted posts.
	 *
	 * @return the boosted posts
	 */
	public int getBoosted_posts() {

		return boosted_posts;
	}

	/**
	 * Sets the boosted posts.
	 *
	 * @param boosted_posts the new boosted posts
	 */
	public void setBoosted_posts(int boosted_posts) {

		this.boosted_posts = boosted_posts;
	}

	/**
	 * Gets the not published posts.
	 *
	 * @return the not published posts
	 */
	public int getNot_published_posts() {

		return not_published_posts;
	}

	/**
	 * Sets the not published posts.
	 *
	 * @param not_published_posts the new not published posts
	 */
	public void setNot_published_posts(int not_published_posts) {

		this.not_published_posts = not_published_posts;
	}

	/**
	 * Gets the published posts.
	 *
	 * @return the published posts
	 */
	public int getPublished_posts() {

		return published_posts;
	}

	/**
	 * Sets the published posts.
	 *
	 * @param published_posts the new published posts
	 */
	public void setPublished_posts(int published_posts) {

		this.published_posts = published_posts;
	}

	/**
	 * Gets the total posts.
	 *
	 * @return the total posts
	 */
	public int getTotal_posts() {

		return total_posts;
	}

	/**
	 * Sets the total posts.
	 *
	 * @param total_posts the new total posts
	 */
	public void setTotal_posts(int total_posts) {

		this.total_posts = total_posts;
	}

}

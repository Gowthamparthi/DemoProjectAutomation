package com.rallio.automation.business.rallioActivate.entity;

import com.rallio.automation.common.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class PostMetrics.
 */
public class PostMetrics {

	/** The posts count. */
	private String posts_count;

	/** The published posts. */
	private String published_posts;

	/** The used posts. */
	private String used_posts;

	/**
	 * Gets the posts count.
	 *
	 * @return the posts count
	 */
	public String getPosts_count() {

		return posts_count;
	}

	/**
	 * Sets the posts count.
	 *
	 * @param posts_count the new posts count
	 */
	public void setPosts_count(String posts_count) {

		this.posts_count = posts_count;
	}

	/**
	 * Gets the published posts.
	 *
	 * @return the published posts
	 */
	public String getPublished_posts() {

		return published_posts;
	}

	/**
	 * Sets the published posts.
	 *
	 * @param published_posts the new published posts
	 */
	public void setPublished_posts(String published_posts) {

		this.published_posts = published_posts;
	}

	/**
	 * Gets the used posts.
	 *
	 * @return the used posts
	 */
	public String getUsed_posts() {

		return used_posts;
	}

	/**
	 * Sets the used posts.
	 *
	 * @param used_posts the new used posts
	 */
	public void setUsed_posts(String used_posts) {

		this.used_posts = used_posts;
	}
	@Override
	public String toString() {

		return ConvertPojoToHtml.convert(this);
	}

}

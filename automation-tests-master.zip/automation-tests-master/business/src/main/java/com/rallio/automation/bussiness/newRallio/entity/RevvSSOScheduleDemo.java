package com.rallio.automation.bussiness.newRallio.entity;


// TODO: Auto-generated Javadoc
/**
 * The Class RevvSSOScheduleDemo.
 */
public class RevvSSOScheduleDemo {

	/** The name. */
	private String name;
	
	/** The company. */
	private String company;
	
	/** The email. */
	private String email;
	
	/** The phone number. */
	private String phoneNumber;
	
	/** The number of location. */
	private String numberOfLocation;

	/** The comment or message. */
	private String commentOrMessage;
	
	/**
	 * Gets the comment or message.
	 *
	 * @return the comment or message
	 */
	public String getCommentOrMessage() {
	
		return commentOrMessage;
	}


	
	/**
	 * Sets the comment or message.
	 *
	 * @param commentOrMessage the new comment or message
	 */
	public void setCommentOrMessage(String commentOrMessage) {
	
		this.commentOrMessage = commentOrMessage;
	}


	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
	
		return name;
	}

	
	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
	
		this.name = name;
	}

	
	/**
	 * Gets the company.
	 *
	 * @return the company
	 */
	public String getCompany() {
	
		return company;
	}

	
	/**
	 * Sets the company.
	 *
	 * @param company the new company
	 */
	public void setCompany(String company) {
	
		this.company = company;
	}

	
	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
	
		return email;
	}

	
	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {
	
		this.email = email;
	}

	
	/**
	 * Gets the phone number.
	 *
	 * @return the phone number
	 */
	public String getPhoneNumber() {
	
		return phoneNumber;
	}

	
	/**
	 * Sets the phone number.
	 *
	 * @param phoneNumber the new phone number
	 */
	public void setPhoneNumber(String phoneNumber) {
	
		this.phoneNumber = phoneNumber;
	}

	
	/**
	 * Gets the number of location.
	 *
	 * @return the number of location
	 */
	public String getNumberOfLocation() {
	
		return numberOfLocation;
	}

	
	/**
	 * Sets the number of location.
	 *
	 * @param numberOfLocation the new number of location
	 */
	public void setNumberOfLocation(String numberOfLocation) {
	
		this.numberOfLocation = numberOfLocation;
	}
}

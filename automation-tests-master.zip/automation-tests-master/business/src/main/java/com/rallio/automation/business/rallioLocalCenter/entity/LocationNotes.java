package com.rallio.automation.business.rallioLocalCenter.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class LocationNotes.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class LocationNotes {

	/** The account id. */
	private int account_id;

	/** The created at. */
	private String created_at;

	/** The id. */
	private int id;

	/** The note. */
	private String note;

	/** The note type. */
	private String note_type;

	/** The trashed. */
	private boolean trashed;

	/** The updated at. */
	private String updated_at;

	/** The user id. */
	private int user_id;

	/**
	 * Gets the account id.
	 *
	 * @return the account id
	 */
	public int getAccount_id() {

		return account_id;
	}

	/**
	 * Sets the account id.
	 *
	 * @param account_id the new account id
	 */
	public void setAccount_id(int account_id) {

		this.account_id = account_id;
	}

	/**
	 * Gets the created at.
	 *
	 * @return the created at
	 */
	public String getCreated_at() {

		return created_at;
	}

	/**
	 * Sets the created at.
	 *
	 * @param created_at the new created at
	 */
	public void setCreated_at(String created_at) {

		this.created_at = created_at;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/**
	 * Gets the note.
	 *
	 * @return the note
	 */
	public String getNote() {

		return note;
	}

	/**
	 * Sets the note.
	 *
	 * @param note the new note
	 */
	public void setNote(String note) {

		this.note = note;
	}

	/**
	 * Gets the note type.
	 *
	 * @return the note type
	 */
	public String getNote_type() {

		return note_type;
	}

	/**
	 * Sets the note type.
	 *
	 * @param note_type the new note type
	 */
	public void setNote_type(String note_type) {

		this.note_type = note_type;
	}

	/**
	 * Checks if is trashed.
	 *
	 * @return true, if is trashed
	 */
	public boolean isTrashed() {

		return trashed;
	}

	/**
	 * Sets the trashed.
	 *
	 * @param trashed the new trashed
	 */
	public void setTrashed(boolean trashed) {

		this.trashed = trashed;
	}

	/**
	 * Gets the updated at.
	 *
	 * @return the updated at
	 */
	public String getUpdated_at() {

		return updated_at;
	}

	/**
	 * Sets the updated at.
	 *
	 * @param updated_at the new updated at
	 */
	public void setUpdated_at(String updated_at) {

		this.updated_at = updated_at;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public int getUser_id() {

		return user_id;
	}

	/**
	 * Sets the user id.
	 *
	 * @param user_id the new user id
	 */
	public void setUser_id(int user_id) {

		this.user_id = user_id;
	}

}

package com.rallio.automation.business.rallioWebApp.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class ConsolidateAdvocacy.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ConsolidateAdvocacy {

	/** The employee. */
	private Employee employee;

	/** The assets submitted count. */
	private int assets_submitted_count;

	/** The assets submitted points. */
	private int assets_submitted_points;

	/** The engagement from assets count. */
	private int engagement_from_assets_count;

	/** The engagement from assets points. */
	private int engagement_from_assets_points;

	/** The advocacy posts count. */
	private int advocacy_posts_count;

	/** The advocacy posts points. */
	private int advocacy_posts_points;

	/** The total score. */
	private int total_score;

	/** The location ranking. */
	private int location_ranking;

	/** The brand ranking. */
	private int brand_ranking;

	/**
	 * Gets the employee.
	 *
	 * @return the employee
	 */
	public Employee getEmployee() {

		return employee;
	}

	/**
	 * Sets the employee.
	 *
	 * @param employee the new employee
	 */
	public void setEmployee(Employee employee) {

		this.employee = employee;
	}

	/**
	 * Gets the assets submitted count.
	 *
	 * @return the assets submitted count
	 */
	public int getAssets_submitted_count() {

		return assets_submitted_count;
	}

	/**
	 * Sets the assets submitted count.
	 *
	 * @param assets_submitted_count the new assets submitted count
	 */
	public void setAssets_submitted_count(int assets_submitted_count) {

		this.assets_submitted_count = assets_submitted_count;
	}

	/**
	 * Gets the assets submitted points.
	 *
	 * @return the assets submitted points
	 */
	public int getAssets_submitted_points() {

		return assets_submitted_points;
	}

	/**
	 * Sets the assets submitted points.
	 *
	 * @param assets_submitted_points the new assets submitted points
	 */
	public void setAssets_submitted_points(int assets_submitted_points) {

		this.assets_submitted_points = assets_submitted_points;
	}

	/**
	 * Gets the engagement from assets count.
	 *
	 * @return the engagement from assets count
	 */
	public int getEngagement_from_assets_count() {

		return engagement_from_assets_count;
	}

	/**
	 * Sets the engagement from assets count.
	 *
	 * @param engagement_from_assets_count the new engagement from assets count
	 */
	public void setEngagement_from_assets_count(int engagement_from_assets_count) {

		this.engagement_from_assets_count = engagement_from_assets_count;
	}

	/**
	 * Gets the engagement from assets points.
	 *
	 * @return the engagement from assets points
	 */
	public int getEngagement_from_assets_points() {

		return engagement_from_assets_points;
	}

	/**
	 * Sets the engagement from assets points.
	 *
	 * @param engagement_from_assets_points the new engagement from assets points
	 */
	public void setEngagement_from_assets_points(int engagement_from_assets_points) {

		this.engagement_from_assets_points = engagement_from_assets_points;
	}

	/**
	 * Gets the advocacy posts count.
	 *
	 * @return the advocacy posts count
	 */
	public int getAdvocacy_posts_count() {

		return advocacy_posts_count;
	}

	/**
	 * Sets the advocacy posts count.
	 *
	 * @param advocacy_posts_count the new advocacy posts count
	 */
	public void setAdvocacy_posts_count(int advocacy_posts_count) {

		this.advocacy_posts_count = advocacy_posts_count;
	}

	/**
	 * Gets the advocacy posts points.
	 *
	 * @return the advocacy posts points
	 */
	public int getAdvocacy_posts_points() {

		return advocacy_posts_points;
	}

	/**
	 * Sets the advocacy posts points.
	 *
	 * @param advocacy_posts_points the new advocacy posts points
	 */
	public void setAdvocacy_posts_points(int advocacy_posts_points) {

		this.advocacy_posts_points = advocacy_posts_points;
	}

	/**
	 * Gets the total score.
	 *
	 * @return the total score
	 */
	public int getTotal_score() {

		return total_score;
	}

	/**
	 * Sets the total score.
	 *
	 * @param total_score the new total score
	 */
	public void setTotal_score(int total_score) {

		this.total_score = total_score;
	}

	/**
	 * Gets the location ranking.
	 *
	 * @return the location ranking
	 */
	public int getLocation_ranking() {

		return location_ranking;
	}

	/**
	 * Sets the location ranking.
	 *
	 * @param location_ranking the new location ranking
	 */
	public void setLocation_ranking(int location_ranking) {

		this.location_ranking = location_ranking;
	}

	/**
	 * Gets the brand ranking.
	 *
	 * @return the brand ranking
	 */
	public int getBrand_ranking() {

		return brand_ranking;
	}

	/**
	 * Sets the brand ranking.
	 *
	 * @param brand_ranking the new brand ranking
	 */
	public void setBrand_ranking(int brand_ranking) {

		this.brand_ranking = brand_ranking;
	}
}

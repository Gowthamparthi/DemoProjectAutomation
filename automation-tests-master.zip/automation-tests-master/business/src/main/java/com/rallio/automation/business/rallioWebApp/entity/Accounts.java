package com.rallio.automation.business.rallioWebApp.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Accounts {

	private int id;

	private String name;

	private String franchisor_id;


	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return this.id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	public void setFranchisor_id(String franchisor_id) {
		this.franchisor_id = franchisor_id;
	}

	public String getFranchisor_id() {
		return this.franchisor_id;
	}

	@Override
	public String toString() {
		return "Accounts [id=" + id + ", name=" + name + ", franchisor_id=" + franchisor_id + "]";
	}

	
}

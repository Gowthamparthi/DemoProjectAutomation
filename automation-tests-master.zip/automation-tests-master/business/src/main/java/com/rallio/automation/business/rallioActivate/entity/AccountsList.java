package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;
import com.rallio.automation.common.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class AccountsList.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountsList {

	/** The id. */
	private int id;

	/** The name. */
	private String name;

	/** The child present. */
	private boolean child_present;

	/** The child count. */
	private int child_count;

	/** The descendant accounts count. */
	private int descendant_accounts_count;

	/** The latitude. */
	private String latitude;

	/** The longitude. */
	private String longitude;

	/** The address. */
	private String address;

	/**
	 * Checks if is child present.
	 *
	 * @return true, if is child present
	 */
	public boolean isChild_present() {

		return child_present;
	}

	/**
	 * Sets the child present.
	 *
	 * @param child_present the new child present
	 */
	public void setChild_present(boolean child_present) {

		this.child_present = child_present;
	}

	/**
	 * Gets the child count.
	 *
	 * @return the child count
	 */
	public int getChild_count() {

		return child_count;
	}

	/**
	 * Sets the child count.
	 *
	 * @param child_count the new child count
	 */
	public void setChild_count(int child_count) {

		this.child_count = child_count;
	}

	/**
	 * Gets the descendant accounts count.
	 *
	 * @return the descendant accounts count
	 */
	public int getDescendant_accounts_count() {

		return descendant_accounts_count;
	}

	/**
	 * Sets the descendant accounts count.
	 *
	 * @param descendant_accounts_count the new descendant accounts count
	 */
	public void setDescendant_accounts_count(int descendant_accounts_count) {

		this.descendant_accounts_count = descendant_accounts_count;
	}

	/**
	 * Gets the latitude.
	 *
	 * @return the latitude
	 */
	public String getLatitude() {

		return latitude;
	}

	/**
	 * Sets the latitude.
	 *
	 * @param latitude the new latitude
	 */
	public void setLatitude(String latitude) {

		this.latitude = latitude;
	}

	/**
	 * Gets the longitude.
	 *
	 * @return the longitude
	 */
	public String getLongitude() {

		return longitude;
	}

	/**
	 * Sets the longitude.
	 *
	 * @param longitude the new longitude
	 */
	public void setLongitude(String longitude) {

		this.longitude = longitude;
	}

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public String getAddress() {

		return address;
	}

	/**
	 * Sets the address.
	 *
	 * @param address the new address
	 */
	public void setAddress(String address) {

		this.address = address;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {

		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {

		this.name = name;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return ConvertPojoToHtml.convert(this);
	}
}

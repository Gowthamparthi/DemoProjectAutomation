package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class RewardProgram.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RewardProgram {

	/** The program details. */
	private RewardProgramDetails programDetails;

	/** The program action. */
	private List<RewardProgramActions> programAction;

	@Override
	public String toString() {

		return "RewardProgram [programDetails=" + programDetails + ", programAction=" + programAction + ", programHuLocations=" + programHuLocations + ", paymentRequestObj="
		        + paymentRequestObj + ", achieversList=" + achieversList + "]";
	}

	/** The program hu locations. */
	private RewardProgramLocations programHuLocations;

	/** The payment request obj. */
	private RewardProgamPayment paymentRequestObj;

	/**
	 * Gets the achievers list.
	 *
	 * @return the achievers list
	 */
	public List<AchieversList> getAchieversList() {

		return achieversList;
	}

	/**
	 * Sets the achievers list.
	 *
	 * @param achieversList the new achievers list
	 */
	public void setAchieversList(List<AchieversList> achieversList) {

		this.achieversList = achieversList;
	}

	/** The achievers list. */
	private List<AchieversList> achieversList;

	/**
	 * Gets the program details.
	 *
	 * @return the program details
	 */
	public RewardProgramDetails getProgramDetails() {

		return programDetails;
	}

	/**
	 * Sets the program details.
	 *
	 * @param programDetails the new program details
	 */
	public void setProgramDetails(RewardProgramDetails programDetails) {

		this.programDetails = programDetails;
	}

	/**
	 * Gets the program action.
	 *
	 * @return the program action
	 */
	public List<RewardProgramActions> getProgramAction() {

		return programAction;
	}

	/**
	 * Sets the program action.
	 *
	 * @param programAction the new program action
	 */
	public void setProgramAction(List<RewardProgramActions> programAction) {

		this.programAction = programAction;
	}

	/**
	 * Gets the program hu locations.
	 *
	 * @return the program hu locations
	 */
	public RewardProgramLocations getProgramHuLocations() {

		return programHuLocations;
	}

	/**
	 * Sets the program hu locations.
	 *
	 * @param programHuLocations the new program hu locations
	 */
	public void setProgramHuLocations(RewardProgramLocations programHuLocations) {

		this.programHuLocations = programHuLocations;
	}

	/**
	 * Gets the payment request obj.
	 *
	 * @return the payment request obj
	 */
	public RewardProgamPayment getPaymentRequestObj() {

		return paymentRequestObj;
	}

	/**
	 * Sets the payment request obj.
	 *
	 * @param paymentRequestObj the new payment request obj
	 */
	public void setPaymentRequestObj(RewardProgamPayment paymentRequestObj) {

		this.paymentRequestObj = paymentRequestObj;
	}

}

package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class RecentPostLinks.
 */
public class RecentPostLinks {

	/** The id. */
	private int id;

	/** The url. */
	private String url;

	/** The short url. */
	private String short_url;

	/** The verticals list. */
	private String verticals_list;

	/** The tags list. */
	private String tags_list;

	/** The link preview title. */
	private String link_preview_title;

	/** The link preview description. */
	private String link_preview_description;

	/** The link preview image url. */
	private String link_preview_image_url;

	/** The link preview image url choices. */
	private List<String> link_preview_image_url_choices;

	/** The tracpoint coupon id. */
	private String tracpoint_coupon_id;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/**
	 * Gets the url.
	 *
	 * @return the url
	 */
	public String getUrl() {

		return url;
	}

	/**
	 * Sets the url.
	 *
	 * @param url the new url
	 */
	public void setUrl(String url) {

		this.url = url;
	}

	/**
	 * Gets the short url.
	 *
	 * @return the short url
	 */
	public String getShort_url() {

		return short_url;
	}

	/**
	 * Sets the short url.
	 *
	 * @param short_url the new short url
	 */
	public void setShort_url(String short_url) {

		this.short_url = short_url;
	}

	/**
	 * Gets the verticals list.
	 *
	 * @return the verticals list
	 */
	public String getVerticals_list() {

		return verticals_list;
	}

	/**
	 * Sets the verticals list.
	 *
	 * @param verticals_list the new verticals list
	 */
	public void setVerticals_list(String verticals_list) {

		this.verticals_list = verticals_list;
	}

	/**
	 * Gets the tags list.
	 *
	 * @return the tags list
	 */
	public String getTags_list() {

		return tags_list;
	}

	/**
	 * Sets the tags list.
	 *
	 * @param tags_list the new tags list
	 */
	public void setTags_list(String tags_list) {

		this.tags_list = tags_list;
	}

	/**
	 * Gets the link preview title.
	 *
	 * @return the link preview title
	 */
	public String getLink_preview_title() {

		return link_preview_title;
	}

	/**
	 * Sets the link preview title.
	 *
	 * @param link_preview_title the new link preview title
	 */
	public void setLink_preview_title(String link_preview_title) {

		this.link_preview_title = link_preview_title;
	}

	/**
	 * Gets the link preview description.
	 *
	 * @return the link preview description
	 */
	public String getLink_preview_description() {

		return link_preview_description;
	}

	/**
	 * Sets the link preview description.
	 *
	 * @param link_preview_description the new link preview description
	 */
	public void setLink_preview_description(String link_preview_description) {

		this.link_preview_description = link_preview_description;
	}

	/**
	 * Gets the link preview image url.
	 *
	 * @return the link preview image url
	 */
	public String getLink_preview_image_url() {

		return link_preview_image_url;
	}

	/**
	 * Sets the link preview image url.
	 *
	 * @param link_preview_image_url the new link preview image url
	 */
	public void setLink_preview_image_url(String link_preview_image_url) {

		this.link_preview_image_url = link_preview_image_url;
	}

	/**
	 * Gets the link preview image url choices.
	 *
	 * @return the link preview image url choices
	 */
	public List<String> getLink_preview_image_url_choices() {

		return link_preview_image_url_choices;
	}

	/**
	 * Sets the link preview image url choices.
	 *
	 * @param link_preview_image_url_choices the new link preview image url
	 *            choices
	 */
	public void setLink_preview_image_url_choices(List<String> link_preview_image_url_choices) {

		this.link_preview_image_url_choices = link_preview_image_url_choices;
	}

	/**
	 * Gets the tracpoint coupon id.
	 *
	 * @return the tracpoint coupon id
	 */
	public String getTracpoint_coupon_id() {

		return tracpoint_coupon_id;
	}

	/**
	 * Sets the tracpoint coupon id.
	 *
	 * @param tracpoint_coupon_id the new tracpoint coupon id
	 */
	public void setTracpoint_coupon_id(String tracpoint_coupon_id) {

		this.tracpoint_coupon_id = tracpoint_coupon_id;
	}

}

package com.rallio.automation.business.rallioLocalCenter.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class CustomFields.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomFields {

	/** The custom field 1. */
	private String custom_field_1;

	/** The custom field 2. */
	private String custom_field_2;

	/** The custom field 3. */
	private String custom_field_3;

	/** The custom field 4. */
	private String custom_field_4;

	/**
	 * Gets the custom field 1.
	 *
	 * @return the custom field 1
	 */
	public String getCustom_field_1() {

		return custom_field_1;
	}

	/**
	 * Sets the custom field 1.
	 *
	 * @param custom_field_1 the new custom field 1
	 */
	public void setCustom_field_1(String custom_field_1) {

		this.custom_field_1 = custom_field_1;
	}

	/**
	 * Gets the custom field 2.
	 *
	 * @return the custom field 2
	 */
	public String getCustom_field_2() {

		return custom_field_2;
	}

	/**
	 * Sets the custom field 2.
	 *
	 * @param custom_field_2 the new custom field 2
	 */
	public void setCustom_field_2(String custom_field_2) {

		this.custom_field_2 = custom_field_2;
	}

	/**
	 * Gets the custom field 3.
	 *
	 * @return the custom field 3
	 */
	public String getCustom_field_3() {

		return custom_field_3;
	}

	/**
	 * Sets the custom field 3.
	 *
	 * @param custom_field_3 the new custom field 3
	 */
	public void setCustom_field_3(String custom_field_3) {

		this.custom_field_3 = custom_field_3;
	}

	/**
	 * Gets the custom field 4.
	 *
	 * @return the custom field 4
	 */
	public String getCustom_field_4() {

		return custom_field_4;
	}

	/**
	 * Sets the custom field 4.
	 *
	 * @param custom_field_4 the new custom field 4
	 */
	public void setCustom_field_4(String custom_field_4) {

		this.custom_field_4 = custom_field_4;
	}

}

package com.rallio.automation.business.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum StrategistProfileInformationPageBLenum.
 */
public enum StrategistProfileInformationPageBLenum {

	/** The admin user. */
	ADMIN_USER,

	/** The receive notification emails. */
	RECEIVE_NOTIFICATION_EMAILS,

	/** The admin user and receive notification emails. */
	ADMIN_USER_AND_RECEIVE_NOTIFICATION_EMAILS,

	/** The normal user. */
	NORMAL_USER;
}

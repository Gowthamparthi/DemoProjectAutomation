package com.rallio.automation.business.rallioLocalCenter.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class RallioLocalCenterUser.
 */
public class RallioLocalCenterUser {

	/** The user name. */
	private String userName;

	/** The password. */
	private String password;

	/** The strategist profile information. */
	private StrategistProfileInformation strategistProfileInformation;

	/**
	 * Gets the strategist locations.
	 *
	 * @return the strategist locations
	 */
	public StrategistLocations getStrategistLocations() {

		return strategistLocations;
	}

	/**
	 * Sets the strategist locations.
	 *
	 * @param strategistLocations the new strategist locations
	 */
	public void setStrategistLocations(StrategistLocations strategistLocations) {

		this.strategistLocations = strategistLocations;
	}

	/** The strategist locations. */
	private StrategistLocations strategistLocations;

	/**
	 * Gets the strategist profile information.
	 *
	 * @return the strategist profile information
	 */
	public StrategistProfileInformation getStrategistProfileInformation() {

		return strategistProfileInformation;
	}

	/**
	 * Sets the strategist profile information.
	 *
	 * @param strategistProfileInformation the new strategist profile
	 *            information
	 */
	public void setStrategistProfileInformation(StrategistProfileInformation strategistProfileInformation) {

		this.strategistProfileInformation = strategistProfileInformation;
	}

	/**
	 * Gets the user name.
	 *
	 * @return the user name
	 */
	public String getUserName() {

		return userName;
	}

	/**
	 * Sets the user name.
	 *
	 * @param userName the new user name
	 */
	public void setUserName(String userName) {

		this.userName = userName;
	}

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {

		return password;
	}

	/**
	 * Sets the password.
	 *
	 * @param password the new password
	 */
	public void setPassword(String password) {

		this.password = password;
	}

}

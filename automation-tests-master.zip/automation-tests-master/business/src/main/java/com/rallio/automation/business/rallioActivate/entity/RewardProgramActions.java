package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class RewardProgramActions.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RewardProgramActions {

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return "RewardProgramActions [action=" + action + ", condition=" + condition + ", employeesTodo=" + employeesTodo + ", giftCost=" + giftCost + ", nonCashRewards="
		        + nonCashRewards + ", operator=" + operator + ", program=" + program + ", rewards=" + rewards + ", value=" + value + ", rewardsProgramDetailsId="
		        + rewardsProgramDetailsId + "]";
	}

	/** The action. */
	private int action;

	/** The condition. */
	private String condition;

	/** The employees todo. */
	private String employeesTodo;

	/** The gift cost. */
	private int giftCost;

	/** The non cash rewards. */
	private String nonCashRewards;

	/** The operator. */
	private String operator;

	/** The program. */
	private String program;

	/** The rewards. */
	private String rewards;

	/** The value. */
	private int value;

	/** The from. */
	private String from;

	/** The to. */
	private String to;
	
	/**
	 * Gets the from.
	 *
	 * @return the from
	 */
	public String getFrom() {

		return from;
	}

	/**
	 * Sets the from.
	 *
	 * @param from the new from
	 */
	public void setFrom(String from) {

		this.from = from;
	}

	/**
	 * Gets the to.
	 *
	 * @return the to
	 */
	public String getTo() {

		return to;
	}

	/**
	 * Sets the to.
	 *
	 * @param to the new to
	 */
	public void setTo(String to) {

		this.to = to;
	}


	/**
	 * Gets the rewards program details id.
	 *
	 * @return the rewards program details id
	 */
	public int getRewardsProgramDetailsId() {

		return rewardsProgramDetailsId;
	}

	/**
	 * Sets the rewards program details id.
	 *
	 * @param rewardsProgramDetailsId the new rewards program details id
	 */
	public void setRewardsProgramDetailsId(int rewardsProgramDetailsId) {

		this.rewardsProgramDetailsId = rewardsProgramDetailsId;
	}

	/** The rewards program details id. */
	private int rewardsProgramDetailsId;

	/**
	 * Gets the action.
	 *
	 * @return the action
	 */
	public int getAction() {

		return action;
	}

	/**
	 * Sets the action.
	 *
	 * @param action the new action
	 */
	public void setAction(int action) {

		this.action = action;
	}

	/**
	 * Gets the condition.
	 *
	 * @return the condition
	 */
	public String getCondition() {

		return condition;
	}

	/**
	 * Sets the condition.
	 *
	 * @param condition the new condition
	 */
	public void setCondition(String condition) {

		this.condition = condition;
	}

	/**
	 * Gets the employees todo.
	 *
	 * @return the employees todo
	 */
	public String getEmployeesTodo() {

		return employeesTodo;
	}

	/**
	 * Sets the employees todo.
	 *
	 * @param employeesTodo the new employees todo
	 */
	public void setEmployeesTodo(String employeesTodo) {

		this.employeesTodo = employeesTodo;
	}

	/**
	 * Gets the gift cost.
	 *
	 * @return the gift cost
	 */
	public int getGiftCost() {

		return giftCost;
	}

	/**
	 * Sets the gift cost.
	 *
	 * @param giftCost the new gift cost
	 */
	public void setGiftCost(int giftCost) {

		this.giftCost = giftCost;
	}

	/**
	 * Gets the non cash rewards.
	 *
	 * @return the non cash rewards
	 */
	public String getNonCashRewards() {

		return nonCashRewards;
	}

	/**
	 * Sets the non cash rewards.
	 *
	 * @param nonCashRewards the new non cash rewards
	 */
	public void setNonCashRewards(String nonCashRewards) {

		this.nonCashRewards = nonCashRewards;
	}

	/**
	 * Gets the operator.
	 *
	 * @return the operator
	 */
	public String getOperator() {

		return operator;
	}

	/**
	 * Sets the operator.
	 *
	 * @param operator the new operator
	 */
	public void setOperator(String operator) {

		this.operator = operator;
	}

	/**
	 * Gets the program.
	 *
	 * @return the program
	 */
	public String getProgram() {

		return program;
	}

	/**
	 * Sets the program.
	 *
	 * @param program the new program
	 */
	public void setProgram(String program) {

		this.program = program;
	}

	/**
	 * Gets the rewards.
	 *
	 * @return the rewards
	 */
	public String getRewards() {

		return rewards;
	}

	/**
	 * Sets the rewards.
	 *
	 * @param rewards the new rewards
	 */
	public void setRewards(String rewards) {

		this.rewards = rewards;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public int getValue() {

		return value;
	}

	/**
	 * Sets the value.
	 *
	 * @param value the new value
	 */
	public void setValue(int value) {

		this.value = value;
	}

}

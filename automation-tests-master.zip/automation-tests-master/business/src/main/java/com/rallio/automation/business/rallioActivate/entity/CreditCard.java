package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class CreditCard.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class CreditCard {

	/** The account balance. */
	private int account_balance;

	/** The created. */
	private long created;

	/** The currency. */
	private String currency;

	/** The email. */
	private String email;

	/** The id. */
	private String id;

	/** The default source. */
	private String default_source;

	/**
	 * Gets the account balance.
	 *
	 * @return the account balance
	 */
	public int getAccount_balance() {

		return account_balance;
	}

	/**
	 * Sets the account balance.
	 *
	 * @param account_balance the new account balance
	 */
	public void setAccount_balance(int account_balance) {

		this.account_balance = account_balance;
	}

	/**
	 * Gets the created.
	 *
	 * @return the created
	 */
	public long getCreated() {

		return created;
	}

	/**
	 * Sets the created.
	 *
	 * @param created the new created
	 */
	public void setCreated(long created) {

		this.created = created;
	}

	/**
	 * Gets the currency.
	 *
	 * @return the currency
	 */
	public String getCurrency() {

		return currency;
	}

	/**
	 * Sets the currency.
	 *
	 * @param currency the new currency
	 */
	public void setCurrency(String currency) {

		this.currency = currency;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {

		return email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {

		this.email = email;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(String id) {

		this.id = id;
	}

	/**
	 * Gets the default source.
	 *
	 * @return the default source
	 */
	public String getDefault_source() {

		return default_source;
	}

	/**
	 * Sets the default source.
	 *
	 * @param default_source the new default source
	 */
	public void setDefault_source(String default_source) {

		this.default_source = default_source;
	}

}

package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

// TODO: Auto-generated Javadoc
/**
 * The Class AssetsSubmitted.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class LeaderBoardList {

	/** The employee. */
	private Employee employee;

	/** The location. */
	private Location location;

	/** The brand ranking. */
	private String brand_ranking;

	/** The count. */
	private String count;

	/** The score. */
	private String score;

	/**
	 * Gets the employee.
	 *
	 * @return the employee
	 */
	public Employee getEmployee() {

		return employee;
	}

	/**
	 * Sets the employee.
	 *
	 * @param employee the new employee
	 */
	public void setEmployee(Employee employee) {

		this.employee = employee;
	}

	/**
	 * Gets the location.
	 *
	 * @return the location
	 */
	public Location getLocation() {

		return location;
	}

	/**
	 * Sets the location.
	 *
	 * @param location the new location
	 */
	public void setLocation(Location location) {

		this.location = location;
	}

	/**
	 * Gets the brand ranking.
	 *
	 * @return the brand ranking
	 */
	public String getBrand_ranking() {

		return brand_ranking;
	}

	/**
	 * Sets the brand ranking.
	 *
	 * @param brand_ranking the new brand ranking
	 */
	public void setBrand_ranking(String brand_ranking) {

		this.brand_ranking = brand_ranking;
	}

	/**
	 * Gets the count.
	 *
	 * @return the count
	 */
	public String getCount() {

		return count;
	}

	/**
	 * Sets the count.
	 *
	 * @param count the new count
	 */
	public void setCount(String count) {

		this.count = count;
	}

	/**
	 * Gets the score.
	 *
	 * @return the score
	 */
	public String getScore() {

		return score;
	}

	/**
	 * Sets the score.
	 *
	 * @param score the new score
	 */
	public void setScore(String score) {

		this.score = score;
	}

}

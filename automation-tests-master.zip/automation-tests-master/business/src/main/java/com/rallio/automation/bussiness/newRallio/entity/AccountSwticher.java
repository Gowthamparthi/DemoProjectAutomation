package com.rallio.automation.bussiness.newRallio.entity;

import java.util.*;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class AccountSwticher.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountSwticher {

	/** The current name. */
	private String current_name;

	/** The franchisor groups. */
	private List<FranchisorGroups> franchisor_groups;

	/** The accounts. */
	private List<Accounts> accounts;

	/** The franchisors. */
	private List<Franchisors> franchisors;

	/** The top level franchisor. */
	private TopLevelFranchisor top_level_franchisor;

	/** The current account or franchisor. */
	private CurrentAccountorFranchisor current_account_or_franchisor;

	/**
	 * Gets the current name.
	 *
	 * @return the current name
	 */
	public String getCurrent_name() {

		return current_name;
	}

	/**
	 * Sets the current name.
	 *
	 * @param current_name the new current name
	 */
	public void setCurrent_name(String current_name) {

		this.current_name = current_name;
	}

	/**
	 * Gets the franchisor groups.
	 *
	 * @return the franchisor groups
	 */
	public List<FranchisorGroups> getFranchisor_groups() {

		return franchisor_groups;
	}

	/**
	 * Sets the franchisor groups.
	 *
	 * @param franchisor_groups the new franchisor groups
	 */
	public void setFranchisor_groups(List<FranchisorGroups> franchisor_groups) {

		this.franchisor_groups = franchisor_groups;
	}

	/**
	 * Gets the accounts.
	 *
	 * @return the accounts
	 */
	public List<Accounts> getAccounts() {

		return accounts;
	}

	/**
	 * Sets the accounts.
	 *
	 * @param accounts the new accounts
	 */
	public void setAccounts(List<Accounts> accounts) {

		this.accounts = accounts;
	}

	/**
	 * Gets the franchisors.
	 *
	 * @return the franchisors
	 */
	public List<Franchisors> getFranchisors() {

		return franchisors;
	}

	/**
	 * Sets the franchisors.
	 *
	 * @param franchisors the new franchisors
	 */
	public void setFranchisors(List<Franchisors> franchisors) {

		this.franchisors = franchisors;
	}

	/**
	 * Gets the top level franchisor.
	 *
	 * @return the top level franchisor
	 */
	public TopLevelFranchisor getTop_level_franchisor() {

		return top_level_franchisor;
	}

	/**
	 * Sets the top level franchisor.
	 *
	 * @param top_level_franchisor the new top level franchisor
	 */
	public void setTop_level_franchisor(TopLevelFranchisor top_level_franchisor) {

		this.top_level_franchisor = top_level_franchisor;
	}

	/**
	 * Gets the current account or franchisor.
	 *
	 * @return the current account or franchisor
	 */
	public CurrentAccountorFranchisor getCurrent_account_or_franchisor() {

		return current_account_or_franchisor;
	}

	/**
	 * Sets the current account or franchisor.
	 *
	 * @param current_account_or_franchisor the new current account or franchisor
	 */
	public void setCurrent_account_or_franchisor(CurrentAccountorFranchisor current_account_or_franchisor) {

		this.current_account_or_franchisor = current_account_or_franchisor;
	}
}

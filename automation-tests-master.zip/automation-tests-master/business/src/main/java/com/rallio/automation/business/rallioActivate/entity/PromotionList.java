package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class PromotionList.
 */
public class PromotionList {

	/** The data. */
	private List<Promotion> data;

	/** The results count. */
	private int results_count;

	/** The status. */
	private boolean status;

	/** The type. */
	private String type;

	/**
	 * Gets the data.
	 *
	 * @return the data
	 */
	public List<Promotion> getData() {

		return data;
	}

	/**
	 * Sets the data.
	 *
	 * @param data the new data
	 */
	public void setData(List<Promotion> data) {

		this.data = data;
	}

	/**
	 * Gets the results count.
	 *
	 * @return the results count
	 */
	public int getResults_count() {

		return results_count;
	}

	/**
	 * Sets the results count.
	 *
	 * @param results_count the new results count
	 */
	public void setResults_count(int results_count) {

		this.results_count = results_count;
	}

	/**
	 * Checks if is status.
	 *
	 * @return true, if is status
	 */
	public boolean isStatus() {

		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(boolean status) {

		this.status = status;
	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {

		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(String type) {

		this.type = type;
	}

}

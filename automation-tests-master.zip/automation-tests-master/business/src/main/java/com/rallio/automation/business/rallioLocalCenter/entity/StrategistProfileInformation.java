package com.rallio.automation.business.rallioLocalCenter.entity;

import java.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class StrategistProfileInformation.
 */
public class StrategistProfileInformation {

	/** The admin. */
	private boolean admin;

	/** The account ids. */
	private List<Integer> account_ids;

	/** The email. */
	private String email;

	/** The first name. */
	private String first_name;

	/** The last name. */
	private String last_name;

	/** The mobile phone. */
	private String mobile_phone;

	/** The password. */
	private String password;

	/** The password confirmation. */
	private String password_confirmation;

	/** The receive notification emails. */
	private boolean receive_notification_emails;

	/** The franchisor ids. */
	private List<Integer> franchisor_ids;

	/** The accepted terms. */
	private boolean accepted_terms;

	/** The strategist. */
	private boolean strategist;

	/**
	 * Checks if is strategist.
	 *
	 * @return true, if is strategist
	 */
	public boolean isStrategist() {

		return strategist;
	}

	/**
	 * Sets the strategist.
	 *
	 * @param strategist the new strategist
	 */
	public void setStrategist(boolean strategist) {

		this.strategist = strategist;
	}

	/**
	 * Checks if is admin.
	 *
	 * @return true, if is admin
	 */
	public boolean isAdmin() {

		return admin;
	}

	/**
	 * Sets the admin.
	 *
	 * @param admin the new admin
	 */
	public void setAdmin(boolean admin) {

		this.admin = admin;
	}

	/**
	 * Gets the account ids.
	 *
	 * @return the account ids
	 */
	public List<Integer> getAccount_ids() {

		return account_ids;
	}

	/**
	 * Sets the account ids.
	 *
	 * @param account_ids the new account ids
	 */
	public void setAccount_ids(List<Integer> account_ids) {

		this.account_ids = account_ids;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {

		return email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {

		this.email = email;
	}

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirst_name() {

		return first_name;
	}

	/**
	 * Sets the first name.
	 *
	 * @param first_name the new first name
	 */
	public void setFirst_name(String first_name) {

		this.first_name = first_name;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLast_name() {

		return last_name;
	}

	/**
	 * Sets the last name.
	 *
	 * @param last_name the new last name
	 */
	public void setLast_name(String last_name) {

		this.last_name = last_name;
	}

	/**
	 * Gets the mobile phone.
	 *
	 * @return the mobile phone
	 */
	public String getMobile_phone() {

		return mobile_phone;
	}

	/**
	 * Sets the mobile phone.
	 *
	 * @param mobile_phone the new mobile phone
	 */
	public void setMobile_phone(String mobile_phone) {

		this.mobile_phone = mobile_phone;
	}

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {

		return password;
	}

	/**
	 * Sets the password.
	 *
	 * @param password the new password
	 */
	public void setPassword(String password) {

		this.password = password;
	}

	/**
	 * Gets the password confirmation.
	 *
	 * @return the password confirmation
	 */
	public String getPassword_confirmation() {

		return password_confirmation;
	}

	/**
	 * Sets the password confirmation.
	 *
	 * @param password_confirmation the new password confirmation
	 */
	public void setPassword_confirmation(String password_confirmation) {

		this.password_confirmation = password_confirmation;
	}

	/**
	 * Checks if is receive notification emails.
	 *
	 * @return true, if is receive notification emails
	 */
	public boolean isReceive_notification_emails() {

		return receive_notification_emails;
	}

	/**
	 * Sets the receive notification emails.
	 *
	 * @param receive_notification_emails the new receive notification emails
	 */
	public void setReceive_notification_emails(boolean receive_notification_emails) {

		this.receive_notification_emails = receive_notification_emails;
	}

	/**
	 * Gets the franchisor ids.
	 *
	 * @return the franchisor ids
	 */
	public List<Integer> getFranchisor_ids() {

		return franchisor_ids;
	}

	/**
	 * Sets the franchisor ids.
	 *
	 * @param franchisor_ids the new franchisor ids
	 */
	public void setFranchisor_ids(List<Integer> franchisor_ids) {

		this.franchisor_ids = franchisor_ids;
	}

	/**
	 * Checks if is accepted terms.
	 *
	 * @return true, if is accepted terms
	 */
	public boolean isAccepted_terms() {

		return accepted_terms;
	}

	/**
	 * Sets the accepted terms.
	 *
	 * @param accepted_terms the new accepted terms
	 */
	public void setAccepted_terms(boolean accepted_terms) {

		this.accepted_terms = accepted_terms;
	}

}

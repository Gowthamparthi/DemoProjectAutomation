package com.rallio.automation.business.rallioLocalCenter.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Posts.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Posts {

	/** The facebook text. */
	private String facebook_text;
	
	/** The scheduled for. */
	private String scheduled_for;
	
	public String getFacebook_text() {
	
		return facebook_text;
	}

	
	public void setFacebook_text(String facebook_text) {
	
		this.facebook_text = facebook_text;
	}

	
	public String getScheduled_for() {
	
		return scheduled_for;
	}

	
	public void setScheduled_for(String scheduled_for) {
	
		this.scheduled_for = scheduled_for;
	}
}

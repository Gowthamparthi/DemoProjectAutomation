package com.rallio.automation.business.rallioActivate.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class ProgramAction.
 */
public class ProgramAction {

	/** The program. */
	private String program;

	/**
	 * Gets the program.
	 *
	 * @return the program
	 */
	public String getProgram() {

		return program;
	}

	/**
	 * Sets the program.
	 *
	 * @param program the new program
	 */
	public void setProgram(String program) {

		this.program = program;
	}
}

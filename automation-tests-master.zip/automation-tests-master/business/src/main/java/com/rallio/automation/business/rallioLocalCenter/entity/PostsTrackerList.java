package com.rallio.automation.business.rallioLocalCenter.entity;

import java.util.*;

public class PostsTrackerList {

	private List<PostsTracker> posts_tracker;

	
	public List<PostsTracker> getPosts_tracker() {
	
		return posts_tracker;
	}

	
	public void setPosts_tracker(List<PostsTracker> posts_tracker) {
	
		this.posts_tracker = posts_tracker;
	}
}

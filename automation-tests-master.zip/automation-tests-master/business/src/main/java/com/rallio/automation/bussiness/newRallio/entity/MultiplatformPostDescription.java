package com.rallio.automation.bussiness.newRallio.entity;

public class MultiplatformPostDescription {
		
	
	String facebookPost;
	String instagramPost;
	String twitterPost;
	String linkedInPost;
	String googlePost;
	
	
	public String getGooglePost() {
		return googlePost;
	}
	public void setGooglePost(String googlePost) {
		this.googlePost = googlePost;
	}
	public String getFacebookPost() {
		return facebookPost;
	}
	public void setFacebookPost(String facebookPost) {
		this.facebookPost = facebookPost;
	}
	public String getInstagramPost() {
		return instagramPost;
	}
	public void setInstagramPost(String instagramPost) {
		this.instagramPost = instagramPost;
	}
	public String getTwitterPost() {
		return twitterPost;
	}
	public void setTwitterPost(String twitterPost) {
		this.twitterPost = twitterPost;
	}
	public String getLinkedInPost() {
		return linkedInPost;
	}
	public void setLinkedInPost(String linkedInPost) {
		this.linkedInPost = linkedInPost;
	}
	
	
}

package com.rallio.automation.business.rallioWebApp.entity;

import com.fasterxml.jackson.annotation.*;
import com.rallio.automation.business.rallioActivate.entity.*;
import com.rallio.automation.common.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class RalioWebAppUser.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RallioWebAppUser {

	/** The user name. */
	private String userName;

	/** The password. */
	private String password;

	/** The user account. */
	private UserAccount userAccount;

	/** The ralio activate user. */
	private RallioActivateUser ralioActivateUser;

	/** The location user name. */
	private String locationUserName;

	/** The account. */
	private String account;

	/** The type. */
	private String type;

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {

		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(String type) {

		this.type = type;
	}

	/**
	 * Gets the user name.
	 *
	 * @return the user name
	 */
	public String getUserName() {

		return userName;
	}

	/**
	 * Sets the user name.
	 *
	 * @param userName the new user name
	 */
	public void setUserName(String userName) {

		this.userName = userName;
	}

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {

		return password;
	}

	/**
	 * Sets the password.
	 *
	 * @param password the new password
	 */
	public void setPassword(String password) {

		this.password = password;
	}

	/**
	 * Gets the user account.
	 *
	 * @return the user account
	 */
	public UserAccount getUserAccount() {

		return userAccount;
	}

	/**
	 * Sets the user account.
	 *
	 * @param userAccount the new user account
	 */
	public void setUserAccount(UserAccount userAccount) {

		this.userAccount = userAccount;
	}

	/**
	 * Gets the ralio activate user.
	 *
	 * @return the ralio activate user
	 */
	public RallioActivateUser getRalioActivateUser() {

		return ralioActivateUser;
	}

	/**
	 * Sets the ralio activate user.
	 *
	 * @param ralioActivateUser the new ralio activate user
	 */
	public void setRalioActivateUser(RallioActivateUser ralioActivateUser) {

		this.ralioActivateUser = ralioActivateUser;
	}

	/**
	 * Gets the location user name.
	 *
	 * @return the location user name
	 */
	public String getLocationUserName() {

		return locationUserName;
	}

	/**
	 * Sets the location user name.
	 *
	 * @param locationUserName the new location user name
	 */
	public void setLocationUserName(String locationUserName) {

		this.locationUserName = locationUserName;
	}

	/**
	 * Gets the account.
	 *
	 * @return the account
	 */
	public String getAccount() {

		return account;
	}

	/**
	 * Sets the account.
	 *
	 * @param account the new account
	 */
	public void setAccount(String account) {

		this.account = account;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return ConvertPojoToHtml.convert(this);
	}
}

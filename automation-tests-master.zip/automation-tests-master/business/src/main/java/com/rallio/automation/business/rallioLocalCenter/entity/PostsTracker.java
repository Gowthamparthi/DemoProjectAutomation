package com.rallio.automation.business.rallioLocalCenter.entity;

import java.util.*;

import com.fasterxml.jackson.annotation.*;
import com.rallio.automation.business.rallioActivate.entity.*;

// TODO: Auto-generated Javadoc
/**
 * The Class PostsTracker.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PostsTracker {

	/** The activated. */
	private boolean activated;

	/** The business hours. */
	private List<BusinessHours> business_hours;

	/** The business photos. */
	private List<BusinessPhotos> business_photos;

	/** The calendar scheduling feature. */
	private boolean calendar_scheduling_feature;

	/** The city. */
	private String city;

	/** The comment media assets feature. */
	private boolean comment_media_assets_feature;

	/** The corporate posts auto approved. */
	private boolean corporate_posts_auto_approved;

	/** The corporate posts auto posted. */
	private boolean corporate_posts_auto_posted;

	/** The corporate posts locked. */
	private boolean corporate_posts_locked;

	/** The country code. */
	private String country_code;

	/** The created at. */
	private String created_at;

	/** The custom fields. */
	private CustomFields custom_fields;

	/** The custom posts locked. */
	private boolean custom_posts_locked;

	/** The description. */
	private String description;

	/** The directory listing feature. */
	private boolean directory_listing_feature;

	/** The dlm city. */
	private String dlm_city;

	/** The dlm country code. */
	private String dlm_country_code;

	/** The dlm facebook url. */
	private String dlm_facebook_url;

	/** The dlm hide address. */
	private boolean dlm_hide_address;

	/** The dlm linkedin url. */
	private String dlm_linkedin_url;

	/** The dlm name. */
	private String dlm_name;

	/** The dlm phone. */
	private String dlm_phone;

	/** The dlm postal code. */
	private String dlm_postal_code;

	/** The dlm state. */
	private String dlm_state;

	/** The dlm store code. */
	private String dlm_store_code;

	/** The dlm street. */
	private String dlm_street;

	/** The dlm twitter url. */
	private String dlm_twitter_url;

	/** The dlm url. */
	private String dlm_url;

	/** The employee leaderboard feature. */
	private boolean employee_leaderboard_feature;

	/** The employee login. */
	private boolean employee_login;

	/** The features. */
	private Features features;

	/** The franchisor id. */
	private int franchisor_id;

	/** The gmb feature. */
	private boolean gmb_feature;

	/** The google places account id. */
	private String google_places_account_id;

	/** The hide from admins. */
	private boolean hide_from_admins;

	/** The id. */
	private int id;

	/** The inbox responses locked. */
	private boolean inbox_responses_locked;

	/** The iqmetrix id. */
	private String iqmetrix_id;

	/** The job page url. */
	private String job_page_url;

	/** The latitude. */
	private String latitude;

	/** The local center. */
	private boolean local_center;

	/** The longitude. */
	private String longitude;

	/** The master franchisee id. */
	private String master_franchisee_id;

	/** The media asset like dislike feature. */
	private boolean media_asset_like_dislike_feature;

	/** The media upload feature. */
	private boolean media_upload_feature;

	/** The name. */
	private String name;

	/** The news rss feed urls. */
	private List<String> news_rss_feed_urls;

	/** The outreach dates. */
	private List<OutreachDates> outreach_dates;

	/** The owner email. */
	private String owner_email;

	/** The owner name. */
	private String owner_name;

	/** The payment methods. */
	private List<String> payment_methods;

	/** The person to reach. */
	private String person_to_reach;

	/** The personal profiles feature. */
	private boolean personal_profiles_feature;

	/** The phone. */
	private String phone;

	/** The posts. */
	private List<RecentPost> posts;

	/** The quota. */
	private double quota;

	/** The review alert ratings. */
	private List<Integer> review_alert_ratings;

	/** The review responses locked. */
	private boolean review_responses_locked;

	/** The reviews approval feature. */
	private boolean reviews_approval_feature;

	/** The reviews count. */
	private int reviews_count;

	/** The short name. */
	private String short_name;

	/** The state. */
	private String state;

	/** The street. */
	private String street;

	/** The synup additional category ids. */
	private List<Integer> synup_additional_category_ids;

	/** The synup location id. */
	private String synup_location_id;

	/** The synup sub category id. */
	private String synup_sub_category_id;

	/** The synup sub category name. */
	private String synup_sub_category_name;

	/** The tagline. */
	private String tagline;

	/** The time zone. */
	private String time_zone;

	/** The twitter quota. */
	private double twitter_quota;

	/** The updated at. */
	private String updated_at;

	/** The url. */
	private String url;

	/** The vertical id. */
	private String vertical_id;

	/** The year of incorporation. */
	private int year_of_incorporation;

	/** The yelp account id. */
	private int yelp_account_id;

	/** The zip. */
	private String zip;

	/**
	 * Checks if is activated.
	 *
	 * @return true, if is activated
	 */
	public boolean isActivated() {

		return activated;
	}

	/**
	 * Sets the activated.
	 *
	 * @param activated the new activated
	 */
	public void setActivated(boolean activated) {

		this.activated = activated;
	}

	/**
	 * Gets the business hours.
	 *
	 * @return the business hours
	 */
	public List<BusinessHours> getBusiness_hours() {

		return business_hours;
	}

	/**
	 * Sets the business hours.
	 *
	 * @param business_hours the new business hours
	 */
	public void setBusiness_hours(List<BusinessHours> business_hours) {

		this.business_hours = business_hours;
	}

	/**
	 * Gets the business photos.
	 *
	 * @return the business photos
	 */
	public List<BusinessPhotos> getBusiness_photos() {

		return business_photos;
	}

	/**
	 * Sets the business photos.
	 *
	 * @param business_photos the new business photos
	 */
	public void setBusiness_photos(List<BusinessPhotos> business_photos) {

		this.business_photos = business_photos;
	}

	/**
	 * Checks if is calendar scheduling feature.
	 *
	 * @return true, if is calendar scheduling feature
	 */
	public boolean isCalendar_scheduling_feature() {

		return calendar_scheduling_feature;
	}

	/**
	 * Sets the calendar scheduling feature.
	 *
	 * @param calendar_scheduling_feature the new calendar scheduling feature
	 */
	public void setCalendar_scheduling_feature(boolean calendar_scheduling_feature) {

		this.calendar_scheduling_feature = calendar_scheduling_feature;
	}

	/**
	 * Gets the city.
	 *
	 * @return the city
	 */
	public String getCity() {

		return city;
	}

	/**
	 * Sets the city.
	 *
	 * @param city the new city
	 */
	public void setCity(String city) {

		this.city = city;
	}

	/**
	 * Checks if is comment media assets feature.
	 *
	 * @return true, if is comment media assets feature
	 */
	public boolean isComment_media_assets_feature() {

		return comment_media_assets_feature;
	}

	/**
	 * Sets the comment media assets feature.
	 *
	 * @param comment_media_assets_feature the new comment media assets feature
	 */
	public void setComment_media_assets_feature(boolean comment_media_assets_feature) {

		this.comment_media_assets_feature = comment_media_assets_feature;
	}

	/**
	 * Checks if is corporate posts auto approved.
	 *
	 * @return true, if is corporate posts auto approved
	 */
	public boolean isCorporate_posts_auto_approved() {

		return corporate_posts_auto_approved;
	}

	/**
	 * Sets the corporate posts auto approved.
	 *
	 * @param corporate_posts_auto_approved the new corporate posts auto
	 *            approved
	 */
	public void setCorporate_posts_auto_approved(boolean corporate_posts_auto_approved) {

		this.corporate_posts_auto_approved = corporate_posts_auto_approved;
	}

	/**
	 * Checks if is corporate posts auto posted.
	 *
	 * @return true, if is corporate posts auto posted
	 */
	public boolean isCorporate_posts_auto_posted() {

		return corporate_posts_auto_posted;
	}

	/**
	 * Sets the corporate posts auto posted.
	 *
	 * @param corporate_posts_auto_posted the new corporate posts auto posted
	 */
	public void setCorporate_posts_auto_posted(boolean corporate_posts_auto_posted) {

		this.corporate_posts_auto_posted = corporate_posts_auto_posted;
	}

	/**
	 * Checks if is corporate posts locked.
	 *
	 * @return true, if is corporate posts locked
	 */
	public boolean isCorporate_posts_locked() {

		return corporate_posts_locked;
	}

	/**
	 * Sets the corporate posts locked.
	 *
	 * @param corporate_posts_locked the new corporate posts locked
	 */
	public void setCorporate_posts_locked(boolean corporate_posts_locked) {

		this.corporate_posts_locked = corporate_posts_locked;
	}

	/**
	 * Gets the country code.
	 *
	 * @return the country code
	 */
	public String getCountry_code() {

		return country_code;
	}

	/**
	 * Sets the country code.
	 *
	 * @param country_code the new country code
	 */
	public void setCountry_code(String country_code) {

		this.country_code = country_code;
	}

	/**
	 * Gets the created at.
	 *
	 * @return the created at
	 */
	public String getCreated_at() {

		return created_at;
	}

	/**
	 * Sets the created at.
	 *
	 * @param created_at the new created at
	 */
	public void setCreated_at(String created_at) {

		this.created_at = created_at;
	}

	/**
	 * Gets the custom fields.
	 *
	 * @return the custom fields
	 */
	public CustomFields getCustom_fields() {

		return custom_fields;
	}

	/**
	 * Sets the custom fields.
	 *
	 * @param custom_fields the new custom fields
	 */
	public void setCustom_fields(CustomFields custom_fields) {

		this.custom_fields = custom_fields;
	}

	/**
	 * Checks if is custom posts locked.
	 *
	 * @return true, if is custom posts locked
	 */
	public boolean isCustom_posts_locked() {

		return custom_posts_locked;
	}

	/**
	 * Sets the custom posts locked.
	 *
	 * @param custom_posts_locked the new custom posts locked
	 */
	public void setCustom_posts_locked(boolean custom_posts_locked) {

		this.custom_posts_locked = custom_posts_locked;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {

		return description;
	}

	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(String description) {

		this.description = description;
	}

	/**
	 * Checks if is directory listing feature.
	 *
	 * @return true, if is directory listing feature
	 */
	public boolean isDirectory_listing_feature() {

		return directory_listing_feature;
	}

	/**
	 * Sets the directory listing feature.
	 *
	 * @param directory_listing_feature the new directory listing feature
	 */
	public void setDirectory_listing_feature(boolean directory_listing_feature) {

		this.directory_listing_feature = directory_listing_feature;
	}

	/**
	 * Gets the dlm city.
	 *
	 * @return the dlm city
	 */
	public String getDlm_city() {

		return dlm_city;
	}

	/**
	 * Sets the dlm city.
	 *
	 * @param dlm_city the new dlm city
	 */
	public void setDlm_city(String dlm_city) {

		this.dlm_city = dlm_city;
	}

	/**
	 * Gets the dlm country code.
	 *
	 * @return the dlm country code
	 */
	public String getDlm_country_code() {

		return dlm_country_code;
	}

	/**
	 * Sets the dlm country code.
	 *
	 * @param dlm_country_code the new dlm country code
	 */
	public void setDlm_country_code(String dlm_country_code) {

		this.dlm_country_code = dlm_country_code;
	}

	/**
	 * Gets the dlm facebook url.
	 *
	 * @return the dlm facebook url
	 */
	public String getDlm_facebook_url() {

		return dlm_facebook_url;
	}

	/**
	 * Sets the dlm facebook url.
	 *
	 * @param dlm_facebook_url the new dlm facebook url
	 */
	public void setDlm_facebook_url(String dlm_facebook_url) {

		this.dlm_facebook_url = dlm_facebook_url;
	}

	/**
	 * Checks if is dlm hide address.
	 *
	 * @return true, if is dlm hide address
	 */
	public boolean isDlm_hide_address() {

		return dlm_hide_address;
	}

	/**
	 * Sets the dlm hide address.
	 *
	 * @param dlm_hide_address the new dlm hide address
	 */
	public void setDlm_hide_address(boolean dlm_hide_address) {

		this.dlm_hide_address = dlm_hide_address;
	}

	/**
	 * Gets the dlm linkedin url.
	 *
	 * @return the dlm linkedin url
	 */
	public String getDlm_linkedin_url() {

		return dlm_linkedin_url;
	}

	/**
	 * Sets the dlm linkedin url.
	 *
	 * @param dlm_linkedin_url the new dlm linkedin url
	 */
	public void setDlm_linkedin_url(String dlm_linkedin_url) {

		this.dlm_linkedin_url = dlm_linkedin_url;
	}

	/**
	 * Gets the dlm name.
	 *
	 * @return the dlm name
	 */
	public String getDlm_name() {

		return dlm_name;
	}

	/**
	 * Sets the dlm name.
	 *
	 * @param dlm_name the new dlm name
	 */
	public void setDlm_name(String dlm_name) {

		this.dlm_name = dlm_name;
	}

	/**
	 * Gets the dlm phone.
	 *
	 * @return the dlm phone
	 */
	public String getDlm_phone() {

		return dlm_phone;
	}

	/**
	 * Sets the dlm phone.
	 *
	 * @param dlm_phone the new dlm phone
	 */
	public void setDlm_phone(String dlm_phone) {

		this.dlm_phone = dlm_phone;
	}

	/**
	 * Gets the dlm postal code.
	 *
	 * @return the dlm postal code
	 */
	public String getDlm_postal_code() {

		return dlm_postal_code;
	}

	/**
	 * Sets the dlm postal code.
	 *
	 * @param dlm_postal_code the new dlm postal code
	 */
	public void setDlm_postal_code(String dlm_postal_code) {

		this.dlm_postal_code = dlm_postal_code;
	}

	/**
	 * Gets the dlm state.
	 *
	 * @return the dlm state
	 */
	public String getDlm_state() {

		return dlm_state;
	}

	/**
	 * Sets the dlm state.
	 *
	 * @param dlm_state the new dlm state
	 */
	public void setDlm_state(String dlm_state) {

		this.dlm_state = dlm_state;
	}

	/**
	 * Gets the dlm store code.
	 *
	 * @return the dlm store code
	 */
	public String getDlm_store_code() {

		return dlm_store_code;
	}

	/**
	 * Sets the dlm store code.
	 *
	 * @param dlm_store_code the new dlm store code
	 */
	public void setDlm_store_code(String dlm_store_code) {

		this.dlm_store_code = dlm_store_code;
	}

	/**
	 * Gets the dlm street.
	 *
	 * @return the dlm street
	 */
	public String getDlm_street() {

		return dlm_street;
	}

	/**
	 * Sets the dlm street.
	 *
	 * @param dlm_street the new dlm street
	 */
	public void setDlm_street(String dlm_street) {

		this.dlm_street = dlm_street;
	}

	/**
	 * Gets the dlm twitter url.
	 *
	 * @return the dlm twitter url
	 */
	public String getDlm_twitter_url() {

		return dlm_twitter_url;
	}

	/**
	 * Sets the dlm twitter url.
	 *
	 * @param dlm_twitter_url the new dlm twitter url
	 */
	public void setDlm_twitter_url(String dlm_twitter_url) {

		this.dlm_twitter_url = dlm_twitter_url;
	}

	/**
	 * Gets the dlm url.
	 *
	 * @return the dlm url
	 */
	public String getDlm_url() {

		return dlm_url;
	}

	/**
	 * Sets the dlm url.
	 *
	 * @param dlm_url the new dlm url
	 */
	public void setDlm_url(String dlm_url) {

		this.dlm_url = dlm_url;
	}

	/**
	 * Checks if is employee leaderboard feature.
	 *
	 * @return true, if is employee leaderboard feature
	 */
	public boolean isEmployee_leaderboard_feature() {

		return employee_leaderboard_feature;
	}

	/**
	 * Sets the employee leaderboard feature.
	 *
	 * @param employee_leaderboard_feature the new employee leaderboard feature
	 */
	public void setEmployee_leaderboard_feature(boolean employee_leaderboard_feature) {

		this.employee_leaderboard_feature = employee_leaderboard_feature;
	}

	/**
	 * Checks if is employee login.
	 *
	 * @return true, if is employee login
	 */
	public boolean isEmployee_login() {

		return employee_login;
	}

	/**
	 * Sets the employee login.
	 *
	 * @param employee_login the new employee login
	 */
	public void setEmployee_login(boolean employee_login) {

		this.employee_login = employee_login;
	}

	/**
	 * Gets the features.
	 *
	 * @return the features
	 */
	public Features getFeatures() {

		return features;
	}

	/**
	 * Sets the features.
	 *
	 * @param features the new features
	 */
	public void setFeatures(Features features) {

		this.features = features;
	}

	/**
	 * Gets the franchisor id.
	 *
	 * @return the franchisor id
	 */
	public int getFranchisor_id() {

		return franchisor_id;
	}

	/**
	 * Sets the franchisor id.
	 *
	 * @param franchisor_id the new franchisor id
	 */
	public void setFranchisor_id(int franchisor_id) {

		this.franchisor_id = franchisor_id;
	}

	/**
	 * Checks if is gmb feature.
	 *
	 * @return true, if is gmb feature
	 */
	public boolean isGmb_feature() {

		return gmb_feature;
	}

	/**
	 * Sets the gmb feature.
	 *
	 * @param gmb_feature the new gmb feature
	 */
	public void setGmb_feature(boolean gmb_feature) {

		this.gmb_feature = gmb_feature;
	}

	/**
	 * Gets the google places account id.
	 *
	 * @return the google places account id
	 */
	public String getGoogle_places_account_id() {

		return google_places_account_id;
	}

	/**
	 * Sets the google places account id.
	 *
	 * @param google_places_account_id the new google places account id
	 */
	public void setGoogle_places_account_id(String google_places_account_id) {

		this.google_places_account_id = google_places_account_id;
	}

	/**
	 * Checks if is hide from admins.
	 *
	 * @return true, if is hide from admins
	 */
	public boolean isHide_from_admins() {

		return hide_from_admins;
	}

	/**
	 * Sets the hide from admins.
	 *
	 * @param hide_from_admins the new hide from admins
	 */
	public void setHide_from_admins(boolean hide_from_admins) {

		this.hide_from_admins = hide_from_admins;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/**
	 * Checks if is inbox responses locked.
	 *
	 * @return true, if is inbox responses locked
	 */
	public boolean isInbox_responses_locked() {

		return inbox_responses_locked;
	}

	/**
	 * Sets the inbox responses locked.
	 *
	 * @param inbox_responses_locked the new inbox responses locked
	 */
	public void setInbox_responses_locked(boolean inbox_responses_locked) {

		this.inbox_responses_locked = inbox_responses_locked;
	}

	/**
	 * Gets the iqmetrix id.
	 *
	 * @return the iqmetrix id
	 */
	public String getIqmetrix_id() {

		return iqmetrix_id;
	}

	/**
	 * Sets the iqmetrix id.
	 *
	 * @param iqmetrix_id the new iqmetrix id
	 */
	public void setIqmetrix_id(String iqmetrix_id) {

		this.iqmetrix_id = iqmetrix_id;
	}

	/**
	 * Gets the job page url.
	 *
	 * @return the job page url
	 */
	public String getJob_page_url() {

		return job_page_url;
	}

	/**
	 * Sets the job page url.
	 *
	 * @param job_page_url the new job page url
	 */
	public void setJob_page_url(String job_page_url) {

		this.job_page_url = job_page_url;
	}

	/**
	 * Gets the latitude.
	 *
	 * @return the latitude
	 */
	public String getLatitude() {

		return latitude;
	}

	/**
	 * Sets the latitude.
	 *
	 * @param latitude the new latitude
	 */
	public void setLatitude(String latitude) {

		this.latitude = latitude;
	}

	/**
	 * Checks if is local center.
	 *
	 * @return true, if is local center
	 */
	public boolean isLocal_center() {

		return local_center;
	}

	/**
	 * Sets the local center.
	 *
	 * @param local_center the new local center
	 */
	public void setLocal_center(boolean local_center) {

		this.local_center = local_center;
	}

	/**
	 * Gets the longitude.
	 *
	 * @return the longitude
	 */
	public String getLongitude() {

		return longitude;
	}

	/**
	 * Sets the longitude.
	 *
	 * @param longitude the new longitude
	 */
	public void setLongitude(String longitude) {

		this.longitude = longitude;
	}

	/**
	 * Gets the master franchisee id.
	 *
	 * @return the master franchisee id
	 */
	public String getMaster_franchisee_id() {

		return master_franchisee_id;
	}

	/**
	 * Sets the master franchisee id.
	 *
	 * @param master_franchisee_id the new master franchisee id
	 */
	public void setMaster_franchisee_id(String master_franchisee_id) {

		this.master_franchisee_id = master_franchisee_id;
	}

	/**
	 * Checks if is media asset like dislike feature.
	 *
	 * @return true, if is media asset like dislike feature
	 */
	public boolean isMedia_asset_like_dislike_feature() {

		return media_asset_like_dislike_feature;
	}

	/**
	 * Sets the media asset like dislike feature.
	 *
	 * @param media_asset_like_dislike_feature the new media asset like dislike
	 *            feature
	 */
	public void setMedia_asset_like_dislike_feature(boolean media_asset_like_dislike_feature) {

		this.media_asset_like_dislike_feature = media_asset_like_dislike_feature;
	}

	/**
	 * Checks if is media upload feature.
	 *
	 * @return true, if is media upload feature
	 */
	public boolean isMedia_upload_feature() {

		return media_upload_feature;
	}

	/**
	 * Sets the media upload feature.
	 *
	 * @param media_upload_feature the new media upload feature
	 */
	public void setMedia_upload_feature(boolean media_upload_feature) {

		this.media_upload_feature = media_upload_feature;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {

		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {

		this.name = name;
	}

	/**
	 * Gets the news rss feed urls.
	 *
	 * @return the news rss feed urls
	 */
	public List<String> getNews_rss_feed_urls() {

		return news_rss_feed_urls;
	}

	/**
	 * Sets the news rss feed urls.
	 *
	 * @param news_rss_feed_urls the new news rss feed urls
	 */
	public void setNews_rss_feed_urls(List<String> news_rss_feed_urls) {

		this.news_rss_feed_urls = news_rss_feed_urls;
	}

	/**
	 * Gets the outreach dates.
	 *
	 * @return the outreach dates
	 */
	public List<OutreachDates> getOutreach_dates() {

		return outreach_dates;
	}

	/**
	 * Sets the outreach dates.
	 *
	 * @param outreach_dates the new outreach dates
	 */
	public void setOutreach_dates(List<OutreachDates> outreach_dates) {

		this.outreach_dates = outreach_dates;
	}

	/**
	 * Gets the owner email.
	 *
	 * @return the owner email
	 */
	public String getOwner_email() {

		return owner_email;
	}

	/**
	 * Sets the owner email.
	 *
	 * @param owner_email the new owner email
	 */
	public void setOwner_email(String owner_email) {

		this.owner_email = owner_email;
	}

	/**
	 * Gets the owner name.
	 *
	 * @return the owner name
	 */
	public String getOwner_name() {

		return owner_name;
	}

	/**
	 * Sets the owner name.
	 *
	 * @param owner_name the new owner name
	 */
	public void setOwner_name(String owner_name) {

		this.owner_name = owner_name;
	}

	/**
	 * Gets the payment methods.
	 *
	 * @return the payment methods
	 */
	public List<String> getPayment_methods() {

		return payment_methods;
	}

	/**
	 * Sets the payment methods.
	 *
	 * @param payment_methods the new payment methods
	 */
	public void setPayment_methods(List<String> payment_methods) {

		this.payment_methods = payment_methods;
	}

	/**
	 * Gets the person to reach.
	 *
	 * @return the person to reach
	 */
	public String getPerson_to_reach() {

		return person_to_reach;
	}

	/**
	 * Sets the person to reach.
	 *
	 * @param person_to_reach the new person to reach
	 */
	public void setPerson_to_reach(String person_to_reach) {

		this.person_to_reach = person_to_reach;
	}

	/**
	 * Checks if is personal profiles feature.
	 *
	 * @return true, if is personal profiles feature
	 */
	public boolean isPersonal_profiles_feature() {

		return personal_profiles_feature;
	}

	/**
	 * Sets the personal profiles feature.
	 *
	 * @param personal_profiles_feature the new personal profiles feature
	 */
	public void setPersonal_profiles_feature(boolean personal_profiles_feature) {

		this.personal_profiles_feature = personal_profiles_feature;
	}

	/**
	 * Gets the phone.
	 *
	 * @return the phone
	 */
	public String getPhone() {

		return phone;
	}

	/**
	 * Sets the phone.
	 *
	 * @param phone the new phone
	 */
	public void setPhone(String phone) {

		this.phone = phone;
	}

	/**
	 * Gets the posts.
	 *
	 * @return the posts
	 */
	public List<RecentPost> getPosts() {

		return posts;
	}

	/**
	 * Sets the posts.
	 *
	 * @param posts the new posts
	 */
	public void setPosts(List<RecentPost> posts) {

		this.posts = posts;
	}

	/**
	 * Gets the quota.
	 *
	 * @return the quota
	 */
	public double getQuota() {

		return quota;
	}

	/**
	 * Sets the quota.
	 *
	 * @param quota the new quota
	 */
	public void setQuota(double quota) {

		this.quota = quota;
	}

	/**
	 * Gets the review alert ratings.
	 *
	 * @return the review alert ratings
	 */
	public List<Integer> getReview_alert_ratings() {

		return review_alert_ratings;
	}

	/**
	 * Sets the review alert ratings.
	 *
	 * @param review_alert_ratings the new review alert ratings
	 */
	public void setReview_alert_ratings(List<Integer> review_alert_ratings) {

		this.review_alert_ratings = review_alert_ratings;
	}

	/**
	 * Checks if is review responses locked.
	 *
	 * @return true, if is review responses locked
	 */
	public boolean isReview_responses_locked() {

		return review_responses_locked;
	}

	/**
	 * Sets the review responses locked.
	 *
	 * @param review_responses_locked the new review responses locked
	 */
	public void setReview_responses_locked(boolean review_responses_locked) {

		this.review_responses_locked = review_responses_locked;
	}

	/**
	 * Checks if is reviews approval feature.
	 *
	 * @return true, if is reviews approval feature
	 */
	public boolean isReviews_approval_feature() {

		return reviews_approval_feature;
	}

	/**
	 * Sets the reviews approval feature.
	 *
	 * @param reviews_approval_feature the new reviews approval feature
	 */
	public void setReviews_approval_feature(boolean reviews_approval_feature) {

		this.reviews_approval_feature = reviews_approval_feature;
	}

	/**
	 * Gets the reviews count.
	 *
	 * @return the reviews count
	 */
	public int getReviews_count() {

		return reviews_count;
	}

	/**
	 * Sets the reviews count.
	 *
	 * @param reviews_count the new reviews count
	 */
	public void setReviews_count(int reviews_count) {

		this.reviews_count = reviews_count;
	}

	/**
	 * Gets the short name.
	 *
	 * @return the short name
	 */
	public String getShort_name() {

		return short_name;
	}

	/**
	 * Sets the short name.
	 *
	 * @param short_name the new short name
	 */
	public void setShort_name(String short_name) {

		this.short_name = short_name;
	}

	/**
	 * Gets the state.
	 *
	 * @return the state
	 */
	public String getState() {

		return state;
	}

	/**
	 * Sets the state.
	 *
	 * @param state the new state
	 */
	public void setState(String state) {

		this.state = state;
	}

	/**
	 * Gets the street.
	 *
	 * @return the street
	 */
	public String getStreet() {

		return street;
	}

	/**
	 * Sets the street.
	 *
	 * @param street the new street
	 */
	public void setStreet(String street) {

		this.street = street;
	}

	/**
	 * Gets the synup additional category ids.
	 *
	 * @return the synup additional category ids
	 */
	public List<Integer> getSynup_additional_category_ids() {

		return synup_additional_category_ids;
	}

	/**
	 * Sets the synup additional category ids.
	 *
	 * @param synup_additional_category_ids the new synup additional category
	 *            ids
	 */
	public void setSynup_additional_category_ids(List<Integer> synup_additional_category_ids) {

		this.synup_additional_category_ids = synup_additional_category_ids;
	}

	/**
	 * Gets the synup location id.
	 *
	 * @return the synup location id
	 */
	public String getSynup_location_id() {

		return synup_location_id;
	}

	/**
	 * Sets the synup location id.
	 *
	 * @param synup_location_id the new synup location id
	 */
	public void setSynup_location_id(String synup_location_id) {

		this.synup_location_id = synup_location_id;
	}

	/**
	 * Gets the synup sub category id.
	 *
	 * @return the synup sub category id
	 */
	public String getSynup_sub_category_id() {

		return synup_sub_category_id;
	}

	/**
	 * Sets the synup sub category id.
	 *
	 * @param synup_sub_category_id the new synup sub category id
	 */
	public void setSynup_sub_category_id(String synup_sub_category_id) {

		this.synup_sub_category_id = synup_sub_category_id;
	}

	/**
	 * Gets the synup sub category name.
	 *
	 * @return the synup sub category name
	 */
	public String getSynup_sub_category_name() {

		return synup_sub_category_name;
	}

	/**
	 * Sets the synup sub category name.
	 *
	 * @param synup_sub_category_name the new synup sub category name
	 */
	public void setSynup_sub_category_name(String synup_sub_category_name) {

		this.synup_sub_category_name = synup_sub_category_name;
	}

	/**
	 * Gets the tagline.
	 *
	 * @return the tagline
	 */
	public String getTagline() {

		return tagline;
	}

	/**
	 * Sets the tagline.
	 *
	 * @param tagline the new tagline
	 */
	public void setTagline(String tagline) {

		this.tagline = tagline;
	}

	/**
	 * Gets the time zone.
	 *
	 * @return the time zone
	 */
	public String getTime_zone() {

		return time_zone;
	}

	/**
	 * Sets the time zone.
	 *
	 * @param time_zone the new time zone
	 */
	public void setTime_zone(String time_zone) {

		this.time_zone = time_zone;
	}

	/**
	 * Gets the twitter quota.
	 *
	 * @return the twitter quota
	 */
	public double getTwitter_quota() {

		return twitter_quota;
	}

	/**
	 * Sets the twitter quota.
	 *
	 * @param twitter_quota the new twitter quota
	 */
	public void setTwitter_quota(double twitter_quota) {

		this.twitter_quota = twitter_quota;
	}

	/**
	 * Gets the updated at.
	 *
	 * @return the updated at
	 */
	public String getUpdated_at() {

		return updated_at;
	}

	/**
	 * Sets the updated at.
	 *
	 * @param updated_at the new updated at
	 */
	public void setUpdated_at(String updated_at) {

		this.updated_at = updated_at;
	}

	/**
	 * Gets the url.
	 *
	 * @return the url
	 */
	public String getUrl() {

		return url;
	}

	/**
	 * Sets the url.
	 *
	 * @param url the new url
	 */
	public void setUrl(String url) {

		this.url = url;
	}

	/**
	 * Gets the vertical id.
	 *
	 * @return the vertical id
	 */
	public String getVertical_id() {

		return vertical_id;
	}

	/**
	 * Sets the vertical id.
	 *
	 * @param vertical_id the new vertical id
	 */
	public void setVertical_id(String vertical_id) {

		this.vertical_id = vertical_id;
	}

	/**
	 * Gets the year of incorporation.
	 *
	 * @return the year of incorporation
	 */
	public int getYear_of_incorporation() {

		return year_of_incorporation;
	}

	/**
	 * Sets the year of incorporation.
	 *
	 * @param year_of_incorporation the new year of incorporation
	 */
	public void setYear_of_incorporation(int year_of_incorporation) {

		this.year_of_incorporation = year_of_incorporation;
	}

	/**
	 * Gets the yelp account id.
	 *
	 * @return the yelp account id
	 */
	public int getYelp_account_id() {

		return yelp_account_id;
	}

	/**
	 * Sets the yelp account id.
	 *
	 * @param yelp_account_id the new yelp account id
	 */
	public void setYelp_account_id(int yelp_account_id) {

		this.yelp_account_id = yelp_account_id;
	}

	/**
	 * Gets the zip.
	 *
	 * @return the zip
	 */
	public String getZip() {

		return zip;
	}

	/**
	 * Sets the zip.
	 *
	 * @param zip the new zip
	 */
	public void setZip(String zip) {

		this.zip = zip;
	}

}

package com.rallio.automation.business.rallioLocalCenter.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class OutreachDates.
 */
public class OutreachDates {

	/** The account id. */
	private int account_id;

	/** The created at. */
	private String created_at;

	/** The id. */
	private int id;

	/** The outreach date. */
	private String outreach_date;

	/** The updated at. */
	private String updated_at;

	/**
	 * Gets the account id.
	 *
	 * @return the account id
	 */
	public int getAccount_id() {

		return account_id;
	}

	/**
	 * Sets the account id.
	 *
	 * @param account_id the new account id
	 */
	public void setAccount_id(int account_id) {

		this.account_id = account_id;
	}

	/**
	 * Gets the created at.
	 *
	 * @return the created at
	 */
	public String getCreated_at() {

		return created_at;
	}

	/**
	 * Sets the created at.
	 *
	 * @param created_at the new created at
	 */
	public void setCreated_at(String created_at) {

		this.created_at = created_at;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/**
	 * Gets the outreach date.
	 *
	 * @return the outreach date
	 */
	public String getOutreach_date() {

		return outreach_date;
	}

	/**
	 * Sets the outreach date.
	 *
	 * @param outreach_date the new outreach date
	 */
	public void setOutreach_date(String outreach_date) {

		this.outreach_date = outreach_date;
	}

	/**
	 * Gets the updated at.
	 *
	 * @return the updated at
	 */
	public String getUpdated_at() {

		return updated_at;
	}

	/**
	 * Sets the updated at.
	 *
	 * @param updated_at the new updated at
	 */
	public void setUpdated_at(String updated_at) {

		this.updated_at = updated_at;
	}

}

package com.rallio.automation.business.rallioLocalCenter.entity;

import java.util.*;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Users.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class UsersList {

	/** The id. */
	int id;

	/** The email. */
	String email;

	/** The first name. */
	String first_name;

	/** The last name. */
	String last_name;

	/** The franchisors. */
	ArrayList<Franchisors> franchisors;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {

		return email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {

		this.email = email;
	}

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirst_name() {

		return first_name;
	}

	/**
	 * Sets the first name.
	 *
	 * @param first_name the new first name
	 */
	public void setFirst_name(String first_name) {

		this.first_name = first_name;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return "UsersList [id=" + id + ", email=" + email + ", first_name=" + first_name + ", last_name=" + last_name + ", franchisors=" + franchisors + "]";
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLast_name() {

		return last_name;
	}

	/**
	 * Sets the last name.
	 *
	 * @param last_name the new last name
	 */
	public void setLast_name(String last_name) {

		this.last_name = last_name;
	}

	/**
	 * Gets the franchisors.
	 *
	 * @return the franchisors
	 */
	public ArrayList<Franchisors> getFranchisors() {

		return franchisors;
	}

	/**
	 * Sets the franchisors.
	 *
	 * @param franchisors the new franchisors
	 */
	public void setFranchisors(ArrayList<Franchisors> franchisors) {

		this.franchisors = franchisors;
	}
}

package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Content.
 */
public class Content {

	/** The facebook text. */
	private String facebook_text;

	/** The use facebook. */
	private boolean use_facebook;

	/** The use google. */
	private boolean use_google;

	/** The use instagram. */
	private boolean use_instagram;

	/** The use linkedin. */
	private boolean use_linkedin;

	/** The franchisor id. */
	private int franchisor_id;

	/** The photo ids. */
	private List<Integer> photo_ids;

	/** The video id. */
	private String video_id;

	/** The use twitter. */
	private boolean use_twitter;

	/** The tags list. */
	private String tags_list;

	/** The sent to franchisor. */
	private boolean sent_to_franchisor;

	/**
	 * Gets the facebook text.
	 *
	 * @return the facebook text
	 */
	public String getFacebook_text() {

		return facebook_text;
	}

	/**
	 * Sets the facebook text.
	 *
	 * @param facebook_text the new facebook text
	 */
	public void setFacebook_text(String facebook_text) {

		this.facebook_text = facebook_text;
	}

	/**
	 * Checks if is use facebook.
	 *
	 * @return true, if is use facebook
	 */
	public boolean isUse_facebook() {

		return use_facebook;
	}

	/**
	 * Sets the use facebook.
	 *
	 * @param use_facebook the new use facebook
	 */
	public void setUse_facebook(boolean use_facebook) {

		this.use_facebook = use_facebook;
	}

	/**
	 * Checks if is use google.
	 *
	 * @return true, if is use google
	 */
	public boolean isUse_google() {

		return use_google;
	}

	/**
	 * Sets the use google.
	 *
	 * @param use_google the new use google
	 */
	public void setUse_google(boolean use_google) {

		this.use_google = use_google;
	}

	/**
	 * Checks if is use instagram.
	 *
	 * @return true, if is use instagram
	 */
	public boolean isUse_instagram() {

		return use_instagram;
	}

	/**
	 * Sets the use instagram.
	 *
	 * @param use_instagram the new use instagram
	 */
	public void setUse_instagram(boolean use_instagram) {

		this.use_instagram = use_instagram;
	}

	/**
	 * Checks if is use linkedin.
	 *
	 * @return true, if is use linkedin
	 */
	public boolean isUse_linkedin() {

		return use_linkedin;
	}

	/**
	 * Sets the use linkedin.
	 *
	 * @param use_linkedin the new use linkedin
	 */
	public void setUse_linkedin(boolean use_linkedin) {

		this.use_linkedin = use_linkedin;
	}

	/**
	 * Gets the franchisor id.
	 *
	 * @return the franchisor id
	 */
	public int getFranchisor_id() {

		return franchisor_id;
	}

	/**
	 * Sets the franchisor id.
	 *
	 * @param franchisor_id the new franchisor id
	 */
	public void setFranchisor_id(int franchisor_id) {

		this.franchisor_id = franchisor_id;
	}

	/**
	 * Gets the photo ids.
	 *
	 * @return the photo ids
	 */
	public List<Integer> getPhoto_ids() {

		return photo_ids;
	}

	/**
	 * Sets the photo ids.
	 *
	 * @param photo_ids the new photo ids
	 */
	public void setPhoto_ids(List<Integer> photo_ids) {

		this.photo_ids = photo_ids;
	}

	/**
	 * Gets the video id.
	 *
	 * @return the video id
	 */
	public String getVideo_id() {

		return video_id;
	}

	/**
	 * Sets the video id.
	 *
	 * @param video_id the new video id
	 */
	public void setVideo_id(String video_id) {

		this.video_id = video_id;
	}

	/**
	 * Checks if is use twitter.
	 *
	 * @return true, if is use twitter
	 */
	public boolean isUse_twitter() {

		return use_twitter;
	}

	/**
	 * Sets the use twitter.
	 *
	 * @param use_twitter the new use twitter
	 */
	public void setUse_twitter(boolean use_twitter) {

		this.use_twitter = use_twitter;
	}

	/**
	 * Gets the tags list.
	 *
	 * @return the tags list
	 */
	public String getTags_list() {

		return tags_list;
	}

	/**
	 * Sets the tags list.
	 *
	 * @param tags_list the new tags list
	 */
	public void setTags_list(String tags_list) {

		this.tags_list = tags_list;
	}

	/**
	 * Checks if is sent to franchisor.
	 *
	 * @return true, if is sent to franchisor
	 */
	public boolean isSent_to_franchisor() {

		return sent_to_franchisor;
	}

	/**
	 * Sets the sent to franchisor.
	 *
	 * @param sent_to_franchisor the new sent to franchisor
	 */
	public void setSent_to_franchisor(boolean sent_to_franchisor) {

		this.sent_to_franchisor = sent_to_franchisor;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return "CreateContent [facebook_text=" + facebook_text + ", use_facebook=" + use_facebook + ", use_google=" + use_google + ", use_instagram=" + use_instagram
		        + ", use_linkedin=" + use_linkedin + ", franchisor_id=" + franchisor_id + ", photo_ids=" + photo_ids + ", video_id=" + video_id + ", use_twitter=" + use_twitter
		        + ", tags_list=" + tags_list + ", sent_to_franchisor=" + sent_to_franchisor + "]";
	}

}

package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Transformation.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Transformation {

	/** The enhance. */
	private boolean enhance;

	/**
	 * Checks if is enhance.
	 *
	 * @return true, if is enhance
	 */
	public boolean isEnhance() {

		return enhance;
	}

	/**
	 * Sets the enhance.
	 *
	 * @param enhance the new enhance
	 */
	public void setEnhance(boolean enhance) {

		this.enhance = enhance;
	}
}

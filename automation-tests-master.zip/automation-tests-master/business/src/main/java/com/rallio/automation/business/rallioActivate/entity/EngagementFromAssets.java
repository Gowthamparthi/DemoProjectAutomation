package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

// TODO: Auto-generated Javadoc
/**
 * The Class EngagementFromAssets.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class EngagementFromAssets {

	/** The total engagement from assets score. */
	private String total_engagement_from_assets_score;

	/** The total engagement from assets count. */
	private String total_engagement_from_assets_count;

	/** The engagement from assets. */
	private ArrayList<LeaderBoardList> engagement_from_assets;

	/**
	 * Gets the engagement from assets.
	 *
	 * @return the engagement from assets
	 */
	public ArrayList<LeaderBoardList> getEngagement_from_assets() {

		return engagement_from_assets;
	}

	/**
	 * Sets the engagement from assets.
	 *
	 * @param engagement_from_assets the new engagement from assets
	 */
	public void setEngagement_from_assets(ArrayList<LeaderBoardList> engagement_from_assets) {

		this.engagement_from_assets = engagement_from_assets;
	}

	/**
	 * Gets the total engagement from assets score.
	 *
	 * @return the total engagement from assets score
	 */
	public String getTotal_engagement_from_assets_score() {

		return total_engagement_from_assets_score;
	}

	/**
	 * Sets the total engagement from assets score.
	 *
	 * @param total_engagement_from_assets_score the new total engagement from assets score
	 */
	public void setTotal_engagement_from_assets_score(String total_engagement_from_assets_score) {

		this.total_engagement_from_assets_score = total_engagement_from_assets_score;
	}

	/**
	 * Gets the total engagement from assets count.
	 *
	 * @return the total engagement from assets count
	 */
	public String getTotal_engagement_from_assets_count() {

		return total_engagement_from_assets_count;
	}

	/**
	 * Sets the total engagement from assets count.
	 *
	 * @param total_engagement_from_assets_count the new total engagement from assets count
	 */
	public void setTotal_engagement_from_assets_count(String total_engagement_from_assets_count) {

		this.total_engagement_from_assets_count = total_engagement_from_assets_count;
	}
}

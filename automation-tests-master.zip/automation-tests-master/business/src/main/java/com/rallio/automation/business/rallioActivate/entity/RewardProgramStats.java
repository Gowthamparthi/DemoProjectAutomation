package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class RewardProgramStats.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RewardProgramStats {

	/** The total page count. */
	private int totalPageCount;

	/** The recommended program count. */
	private int recommended_program_count;

	/** The reward program count. */
	private int reward_program_count;

	/**
	 * Gets the achievers count.
	 *
	 * @return the achievers count
	 */
	public int getAchievers_count() {

		return achievers_count;
	}

	/**
	 * Sets the achievers count.
	 *
	 * @param achievers_count the new achievers count
	 */
	public void setAchievers_count(int achievers_count) {

		this.achievers_count = achievers_count;
	}

	/** The achievers count. */
	private int achievers_count;

	/**
	 * Gets the total page count.
	 *
	 * @return the total page count
	 */
	public int getTotalPageCount() {

		return totalPageCount;
	}

	/**
	 * Sets the total page count.
	 *
	 * @param totalPageCount the new total page count
	 */
	public void setTotalPageCount(int totalPageCount) {

		this.totalPageCount = totalPageCount;
	}

	/**
	 * Gets the recommended program count.
	 *
	 * @return the recommended program count
	 */
	public int getRecommended_program_count() {

		return recommended_program_count;
	}

	/**
	 * Sets the recommended program count.
	 *
	 * @param recommended_program_count the new recommended program count
	 */
	public void setRecommended_program_count(int recommended_program_count) {

		this.recommended_program_count = recommended_program_count;
	}

	/**
	 * Gets the reward program count.
	 *
	 * @return the reward program count
	 */
	public int getReward_program_count() {

		return reward_program_count;
	}

	/**
	 * Sets the reward program count.
	 *
	 * @param reward_program_count the new reward program count
	 */
	public void setReward_program_count(int reward_program_count) {

		this.reward_program_count = reward_program_count;
	}

}

package com.rallio.automation.business.rallioWebApp.entity;

import java.util.*;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Users.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class UsersList {

    /** The users. */
    private List<Users> users;

	/**
	 * Gets the users.
	 *
	 * @return the users
	 */
	public List<Users> getUsers() {
		return users;
	}

	/**
	 * Sets the users.
	 *
	 * @param users the new users
	 */
	public void setUsers(List<Users> users) {
		this.users = users;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UsersList [users=" + users + "]";
	}
	 
}

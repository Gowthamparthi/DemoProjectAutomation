package com.rallio.automation.business.rallioWebApp.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class User {
	
    private int id;

    private String email;

    private String first_name;

    private String last_name;

    private String company_name;

    private boolean admin;

    private boolean franchisor;

    private boolean content_writer;

    private boolean franchisor_group_user;

    private int detail_id;

    private boolean disable_scheduled_posting;

    private boolean has_facebook_boost_access;

    private List<Integer> review_alert_ratings;

    private boolean receive_notification_emails;

    private boolean direct_message_notification;

    private boolean receive_monthly_enduser_report;

    private String mobile_phone;

    private String profile_photo_cloudinary_id;

    private String profile_photo_url;

    private String rallio_local_assets_notification_enrolled_at;

    private List<String> features;

    private boolean rlc_account;

    public void setId(int id){
        this.id = id;
    }
    public int getId(){
        return this.id;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public String getEmail(){
        return this.email;
    }
    public void setFirst_name(String first_name){
        this.first_name = first_name;
    }
    public String getFirst_name(){
        return this.first_name;
    }
    public void setLast_name(String last_name){
        this.last_name = last_name;
    }
    public String getLast_name(){
        return this.last_name;
    }
    public void setCompany_name(String company_name){
        this.company_name = company_name;
    }
    public String getCompany_name(){
        return this.company_name;
    }
    public void setAdmin(boolean admin){
        this.admin = admin;
    }
    public boolean getAdmin(){
        return this.admin;
    }
    public void setFranchisor(boolean franchisor){
        this.franchisor = franchisor;
    }
    public boolean getFranchisor(){
        return this.franchisor;
    }
    public void setContent_writer(boolean content_writer){
        this.content_writer = content_writer;
    }
    public boolean getContent_writer(){
        return this.content_writer;
    }
    public void setFranchisor_group_user(boolean franchisor_group_user){
        this.franchisor_group_user = franchisor_group_user;
    }
    public boolean getFranchisor_group_user(){
        return this.franchisor_group_user;
    }
    public void setDetail_id(int detail_id){
        this.detail_id = detail_id;
    }
    public int getDetail_id(){
        return this.detail_id;
    }
    public void setDisable_scheduled_posting(boolean disable_scheduled_posting){
        this.disable_scheduled_posting = disable_scheduled_posting;
    }
    public boolean getDisable_scheduled_posting(){
        return this.disable_scheduled_posting;
    }
    public void setHas_facebook_boost_access(boolean has_facebook_boost_access){
        this.has_facebook_boost_access = has_facebook_boost_access;
    }
    public boolean getHas_facebook_boost_access(){
        return this.has_facebook_boost_access;
    }
    public void setReview_alert_ratings(List<Integer> review_alert_ratings){
        this.review_alert_ratings = review_alert_ratings;
    }
    public List<Integer> getReview_alert_ratings(){
        return this.review_alert_ratings;
    }
    public void setReceive_notification_emails(boolean receive_notification_emails){
        this.receive_notification_emails = receive_notification_emails;
    }
    public boolean getReceive_notification_emails(){
        return this.receive_notification_emails;
    }
    public void setDirect_message_notification(boolean direct_message_notification){
        this.direct_message_notification = direct_message_notification;
    }
    public boolean getDirect_message_notification(){
        return this.direct_message_notification;
    }
    public void setReceive_monthly_enduser_report(boolean receive_monthly_enduser_report){
        this.receive_monthly_enduser_report = receive_monthly_enduser_report;
    }
    public boolean getReceive_monthly_enduser_report(){
        return this.receive_monthly_enduser_report;
    }
    public void setMobile_phone(String mobile_phone){
        this.mobile_phone = mobile_phone;
    }
    public String getMobile_phone(){
        return this.mobile_phone;
    }
    public void setProfile_photo_cloudinary_id(String profile_photo_cloudinary_id){
        this.profile_photo_cloudinary_id = profile_photo_cloudinary_id;
    }
    public String getProfile_photo_cloudinary_id(){
        return this.profile_photo_cloudinary_id;
    }
    public void setProfile_photo_url(String profile_photo_url){
        this.profile_photo_url = profile_photo_url;
    }
    public String getProfile_photo_url(){
        return this.profile_photo_url;
    }
    public void setRallio_local_assets_notification_enrolled_at(String rallio_local_assets_notification_enrolled_at){
        this.rallio_local_assets_notification_enrolled_at = rallio_local_assets_notification_enrolled_at;
    }
    public String getRallio_local_assets_notification_enrolled_at(){
        return this.rallio_local_assets_notification_enrolled_at;
    }
    public void setFeatures(List<String> features){
        this.features = features;
    }
    public List<String> getFeatures(){
        return this.features;
    }
    public void setRlc_account(boolean rlc_account){
        this.rlc_account = rlc_account;
    }
    public boolean getRlc_account(){
        return this.rlc_account;
    }

}

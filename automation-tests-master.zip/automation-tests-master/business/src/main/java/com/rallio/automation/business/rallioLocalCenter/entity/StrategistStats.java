package com.rallio.automation.business.rallioLocalCenter.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class StrategistStats.
 */
public class StrategistStats {

	/** The accounts count. */
	private int accounts_count;

	/** The brands count. */
	private int brands_count;

	/** The strategists count. */
	private int strategists_count;

	/**
	 * Gets the accounts count.
	 *
	 * @return the accounts count
	 */
	public int getAccounts_count() {

		return accounts_count;
	}

	/**
	 * Sets the accounts count.
	 *
	 * @param accounts_count the new accounts count
	 */
	public void setAccounts_count(int accounts_count) {

		this.accounts_count = accounts_count;
	}

	/**
	 * Gets the brands count.
	 *
	 * @return the brands count
	 */
	public int getBrands_count() {

		return brands_count;
	}

	/**
	 * Sets the brands count.
	 *
	 * @param brands_count the new brands count
	 */
	public void setBrands_count(int brands_count) {

		this.brands_count = brands_count;
	}

	/**
	 * Gets the strategists count.
	 *
	 * @return the strategists count
	 */
	public int getStrategists_count() {

		return strategists_count;
	}

	/**
	 * Sets the strategists count.
	 *
	 * @param strategists_count the new strategists count
	 */
	public void setStrategists_count(int strategists_count) {

		this.strategists_count = strategists_count;
	}

}

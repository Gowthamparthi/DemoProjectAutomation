package com.rallio.automation.bussiness.newRallio.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class RallioProfileContents.
 */
public class RallioProfileContents {

	/** The rallio profile name. */
	private String rallioProfileName;

	/** The store code. */
	private String storeCode;

	/** The manager. */
	private String manager;

	/** The address. */
	private String address;

	/** The city. */
	private String city;

	/** The state province. */
	private String stateProvince;

	/** The zip postalcode. */
	private String zipPostalcode;

	/** The country. */
	private String country;

	/** The phone number. */
	private String phoneNumber;

	/** The time zone. */
	private String timeZone;

	/** The job page url. */
	private String jobPageUrl;

	/** The website url. */
	private String websiteUrl;

	/** The custom field 1. */
	private String customField1;

	/** The custom field 2. */
	private String customField2;

	/** The custom field 3. */
	private String customField3;

	/** The custom field 4. */
	private String customField4;

	private String customField5;

	private String customField6;

	private String customField7;

	/**
	 * Gets the rallio profile name.
	 *
	 * @return the rallio profile name
	 */
	public String getRallioProfileName() {

		return rallioProfileName;
	}

	/**
	 * Sets the rallio profile name.
	 *
	 * @param rallioProfileName the new rallio profile name
	 */
	public void setRallioProfileName(String rallioProfileName) {

		this.rallioProfileName = rallioProfileName;
	}

	/**
	 * Gets the store code.
	 *
	 * @return the store code
	 */
	public String getStoreCode() {

		return storeCode;
	}

	/**
	 * Sets the store code.
	 *
	 * @param storeCode the new store code
	 */
	public void setStoreCode(String storeCode) {

		this.storeCode = storeCode;
	}

	/**
	 * Gets the manager.
	 *
	 * @return the manager
	 */
	public String getManager() {

		return manager;
	}

	/**
	 * Sets the manager.
	 *
	 * @param manager the new manager
	 */
	public void setManager(String manager) {

		this.manager = manager;
	}

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public String getAddress() {

		return address;
	}

	/**
	 * Sets the address.
	 *
	 * @param address the new address
	 */
	public void setAddress(String address) {

		this.address = address;
	}

	/**
	 * Gets the city.
	 *
	 * @return the city
	 */
	public String getCity() {

		return city;
	}

	/**
	 * Sets the city.
	 *
	 * @param city the new city
	 */
	public void setCity(String city) {

		this.city = city;
	}

	/**
	 * Gets the state province.
	 *
	 * @return the state province
	 */
	public String getStateProvince() {

		return stateProvince;
	}

	/**
	 * Sets the state province.
	 *
	 * @param stateProvince the new state province
	 */
	public void setStateProvince(String stateProvince) {

		this.stateProvince = stateProvince;
	}

	/**
	 * Gets the zip postalcode.
	 *
	 * @return the zip postalcode
	 */
	public String getZipPostalcode() {

		return zipPostalcode;
	}

	/**
	 * Sets the zip postalcode.
	 *
	 * @param zipPostalcode the new zip postalcode
	 */
	public void setZipPostalcode(String zipPostalcode) {

		this.zipPostalcode = zipPostalcode;
	}

	/**
	 * Gets the country.
	 *
	 * @return the country
	 */
	public String getCountry() {

		return country;
	}

	/**
	 * Sets the country.
	 *
	 * @param country the new country
	 */
	public void setCountry(String country) {

		this.country = country;
	}

	/**
	 * Gets the phone number.
	 *
	 * @return the phone number
	 */
	public String getPhoneNumber() {

		return phoneNumber;
	}

	/**
	 * Sets the phone number.
	 *
	 * @param phoneNumber the new phone number
	 */
	public void setPhoneNumber(String phoneNumber) {

		this.phoneNumber = phoneNumber;
	}

	/**
	 * Gets the time zone.
	 *
	 * @return the time zone
	 */
	public String getTimeZone() {

		return timeZone;
	}

	/**
	 * Sets the time zone.
	 *
	 * @param timeZone the new time zone
	 */
	public void setTimeZone(String timeZone) {

		this.timeZone = timeZone;
	}

	/**
	 * Gets the job page url.
	 *
	 * @return the job page url
	 */
	public String getJobPageUrl() {

		return jobPageUrl;
	}

	/**
	 * Sets the job page url.
	 *
	 * @param jobPageUrl the new job page url
	 */
	public void setJobPageUrl(String jobPageUrl) {

		this.jobPageUrl = jobPageUrl;
	}

	/**
	 * Gets the website url.
	 *
	 * @return the website url
	 */
	public String getWebsiteUrl() {

		return websiteUrl;
	}

	/**
	 * Sets the website url.
	 *
	 * @param websiteUrl the new website url
	 */
	public void setWebsiteUrl(String websiteUrl) {

		this.websiteUrl = websiteUrl;
	}

	/**
	 * Gets the custom field 1.
	 *
	 * @return the custom field 1
	 */
	public String getCustomField1() {

		return customField1;
	}

	/**
	 * Sets the custom field 1.
	 *
	 * @param customField1 the new custom field 1
	 */
	public void setCustomField1(String customField1) {

		this.customField1 = customField1;
	}

	/**
	 * Gets the custom field 2.
	 *
	 * @return the custom field 2
	 */
	public String getCustomField2() {

		return customField2;
	}

	/**
	 * Sets the custom field 2.
	 *
	 * @param customField2 the new custom field 2
	 */
	public void setCustomField2(String customField2) {

		this.customField2 = customField2;
	}

	/**
	 * Gets the custom field 3.
	 *
	 * @return the custom field 3
	 */
	public String getCustomField3() {

		return customField3;
	}

	/**
	 * Sets the custom field 3.
	 *
	 * @param customField3 the new custom field 3
	 */
	public void setCustomField3(String customField3) {

		this.customField3 = customField3;
	}

	/**
	 * Gets the custom field 4.
	 *
	 * @return the custom field 4
	 */
	public String getCustomField4() {

		return customField4;
	}

	/**
	 * Sets the custom field 4.
	 *
	 * @param customField4 the new custom field 4
	 */
	public void setCustomField4(String customField4) {

		this.customField4 = customField4;
	}

	public String getCustomField5() {
		return customField5;
	}

	public void setCustomField5(String customField5) {
		this.customField5 = customField5;
	}

	public String getCustomField6() {
		return customField6;
	}

	public void setCustomField6(String customField6) {
		this.customField6 = customField6;
	}

	public String getCustomField7() {
		return customField7;
	}

	public void setCustomField7(String customField7) {
		this.customField7 = customField7;
	}
}

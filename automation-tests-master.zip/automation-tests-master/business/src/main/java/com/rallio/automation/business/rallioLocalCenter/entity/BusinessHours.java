package com.rallio.automation.business.rallioLocalCenter.entity;

import java.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class BusinessHours.
 */
public class BusinessHours {

	/** The day. */
	private String day;

	/** The special date. */
	private String specialDate;

	/** The type. */
	private String type;

	/** The slots. */
	private List<Slots> slots;

	/**
	 * Gets the day.
	 *
	 * @return the day
	 */
	public String getDay() {

		return day;
	}

	/**
	 * Sets the day.
	 *
	 * @param day the new day
	 */
	public void setDay(String day) {

		this.day = day;
	}

	/**
	 * Gets the special date.
	 *
	 * @return the special date
	 */
	public String getSpecialDate() {

		return specialDate;
	}

	/**
	 * Sets the special date.
	 *
	 * @param specialDate the new special date
	 */
	public void setSpecialDate(String specialDate) {

		this.specialDate = specialDate;
	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {

		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(String type) {

		this.type = type;
	}

	/**
	 * Gets the slots.
	 *
	 * @return the slots
	 */
	public List<Slots> getSlots() {

		return slots;
	}

	/**
	 * Sets the slots.
	 *
	 * @param slots the new slots
	 */
	public void setSlots(List<Slots> slots) {

		this.slots = slots;
	}

}

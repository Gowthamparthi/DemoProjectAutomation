package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;
import com.rallio.automation.common.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class ProgramActions.
 */
public class ProgramActions {

	/** The action. */
	private String action;

	/** The value. */
	private String value;

	/** The rewards. */
	private String rewards;

	/**
	 * Gets the action.
	 *
	 * @return the action
	 */
	public String getAction() {

		return action;
	}

	/**
	 * Sets the action.
	 *
	 * @param action the new action
	 */
	public void setAction(String action) {

		this.action = action;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public String getValue() {

		return value;
	}

	/**
	 * Sets the value.
	 *
	 * @param value the new value
	 */
	public void setValue(String value) {

		this.value = value;
	}

	/**
	 * Gets the rewards.
	 *
	 * @return the rewards
	 */
	public String getRewards() {

		return rewards;
	}

	/**
	 * Sets the rewards.
	 *
	 * @param rewards the new rewards
	 */
	public void setRewards(String rewards) {

		this.rewards = rewards;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return ConvertPojoToHtml.convert(this);
	}
}

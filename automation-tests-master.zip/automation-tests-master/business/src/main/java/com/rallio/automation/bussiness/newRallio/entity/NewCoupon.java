package com.rallio.automation.bussiness.newRallio.entity;

public class NewCoupon {
	
	private String couponName;
	private int quantityOfCoupon;
	private String fromDate;
	private String expirationDate;
	private String offerCopy;
	private String desclaimerCopy;
	private String uploadImagePath;

	public String getUploadImagePath() {
		return uploadImagePath;
	}
	public void setUploadImagePath(String uploadImagePath) {
		this.uploadImagePath = uploadImagePath;
	}
	public  String getCouponName() {
		return couponName;
	}
	public void setCouponName(String couponName) {
		this.couponName = couponName;
	}
	public int getQuantityOfCoupon() {
		return quantityOfCoupon;
	}
	public void setQuantityOfCoupon(int quantityOfCoupon) {
		this.quantityOfCoupon = quantityOfCoupon;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	public String getOfferCopy() {
		return offerCopy;
	}
	public void setOfferCopy(String offerCopy) {
		this.offerCopy = offerCopy;
	}
	public String getDesclaimerCopy() {
		return desclaimerCopy;
	}
	public void setDesclaimerCopy(String desclaimerCopy) {
		this.desclaimerCopy = desclaimerCopy;
	}
	
}

package com.rallio.automation.business.rallioActivate.entity;

import java.util.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

// TODO: Auto-generated Javadoc
/**
 * The Class AdvocacyPosts.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AdvocacyPosts {

	/** The total advocacy posts score. */
	private String total_advocacy_posts_score;

	/** The total advocacy posts count. */
	private String total_advocacy_posts_count;

	/** The advocacy posts. */
	private ArrayList<LeaderBoardList> advocacy_posts;

	/**
	 * Gets the advocacy posts.
	 *
	 * @return the advocacy posts
	 */
	public ArrayList<LeaderBoardList> getAdvocacy_posts() {

		return advocacy_posts;
	}

	/**
	 * Sets the advocacy posts.
	 *
	 * @param advocacy_posts the new advocacy posts
	 */
	public void setAdvocacy_posts(ArrayList<LeaderBoardList> advocacy_posts) {

		this.advocacy_posts = advocacy_posts;
	}

	/**
	 * Gets the total advocacy posts score.
	 *
	 * @return the total advocacy posts score
	 */
	public String getTotal_advocacy_posts_score() {

		return total_advocacy_posts_score;
	}

	/**
	 * Sets the total advocacy posts score.
	 *
	 * @param total_advocacy_posts_score the new total advocacy posts score
	 */
	public void setTotal_advocacy_posts_score(String total_advocacy_posts_score) {

		this.total_advocacy_posts_score = total_advocacy_posts_score;
	}

	/**
	 * Gets the total advocacy posts count.
	 *
	 * @return the total advocacy posts count
	 */
	public String getTotal_advocacy_posts_count() {

		return total_advocacy_posts_count;
	}

	/**
	 * Sets the total advocacy posts count.
	 *
	 * @param total_advocacy_posts_count the new total advocacy posts count
	 */
	public void setTotal_advocacy_posts_count(String total_advocacy_posts_count) {

		this.total_advocacy_posts_count = total_advocacy_posts_count;
	}
}

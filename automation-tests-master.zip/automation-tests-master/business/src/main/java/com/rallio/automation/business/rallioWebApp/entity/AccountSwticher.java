package com.rallio.automation.business.rallioWebApp.entity;

import java.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class AccountSwticher.
 */
public class AccountSwticher {

	/** The current name. */
	private String current_name;

	/** The accounts. */
	private List<AccountsList> accounts;

	/** The franchisors. */
	private List<AccountsList> franchisors;

	/** The franchisor groups. */
	private List<AccountsList> franchisor_groups;

	/**
	 * Gets the current name.
	 *
	 * @return the current name
	 */
	public String getCurrent_name() {

		return current_name;
	}

	/**
	 * Sets the current name.
	 *
	 * @param current_name the new current name
	 */
	public void setCurrent_name(String current_name) {

		this.current_name = current_name;
	}

	/**
	 * Gets the franchisor groups.
	 *
	 * @return the franchisor groups
	 */
	public List<AccountsList> getFranchisor_groups() {

		return franchisor_groups;
	}

	/**
	 * Sets the franchisor groups.
	 *
	 * @param franchisor_groups the new franchisor groups
	 */
	public void setFranchisor_groups(List<AccountsList> franchisor_groups) {

		this.franchisor_groups = franchisor_groups;
	}

	/**
	 * Gets the accounts.
	 *
	 * @return the accounts
	 */
	public List<AccountsList> getAccounts() {

		return accounts;
	}

	/**
	 * Sets the accounts.
	 *
	 * @param accounts the new accounts
	 */
	public void setAccounts(List<AccountsList> accounts) {

		this.accounts = accounts;
	}

	/**
	 * Gets the franchisors.
	 *
	 * @return the franchisors
	 */
	public List<AccountsList> getFranchisors() {

		return franchisors;
	}

	/**
	 * Sets the franchisors.
	 *
	 * @param franchisors the new franchisors
	 */
	public void setFranchisors(List<AccountsList> franchisors) {

		this.franchisors = franchisors;
	}

}

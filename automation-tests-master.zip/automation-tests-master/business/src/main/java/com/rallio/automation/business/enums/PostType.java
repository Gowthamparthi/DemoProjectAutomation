package com.rallio.automation.business.enums;


public enum PostType {

	PUBLISHED,
	
	NOT_PUBLISHED;
}

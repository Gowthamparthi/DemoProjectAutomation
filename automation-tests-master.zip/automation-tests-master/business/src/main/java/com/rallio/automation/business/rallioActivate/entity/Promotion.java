package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Promotion.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Promotion {

	/** The activation close. */
	private String activation_close;

	/** The card value. */
	private String card_value;

	/** The display name. */
	private String display_name;

	/** The end date. */
	private String end_date;

	/** The gift cost. */
	private String gift_cost;

	/** The launch date. */
	private String launch_date;

	/** The promotion id. */
	private String promotion_id;

	/** The promotion url. */
	private String promotion_url;

	/** The service fee. */
	private String service_fee;

	/** The show marketing. */
	private int show_marketing;

	/** The start date. */
	private String start_date;

	/**
	 * Gets the activation close.
	 *
	 * @return the activation close
	 */
	public String getActivation_close() {

		return activation_close;
	}

	/**
	 * Sets the activation close.
	 *
	 * @param activation_close the new activation close
	 */
	public void setActivation_close(String activation_close) {

		this.activation_close = activation_close;
	}

	/**
	 * Gets the card value.
	 *
	 * @return the card value
	 */
	public String getCard_value() {

		return card_value;
	}

	/**
	 * Sets the card value.
	 *
	 * @param card_value the new card value
	 */
	public void setCard_value(String card_value) {

		this.card_value = card_value;
	}

	/**
	 * Gets the display name.
	 *
	 * @return the display name
	 */
	public String getDisplay_name() {

		return display_name;
	}

	/**
	 * Sets the display name.
	 *
	 * @param display_name the new display name
	 */
	public void setDisplay_name(String display_name) {

		this.display_name = display_name;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public String getEnd_date() {

		return end_date;
	}

	/**
	 * Sets the end date.
	 *
	 * @param end_date the new end date
	 */
	public void setEnd_date(String end_date) {

		this.end_date = end_date;
	}

	/**
	 * Gets the gift cost.
	 *
	 * @return the gift cost
	 */
	public String getGift_cost() {

		return gift_cost;
	}

	/**
	 * Sets the gift cost.
	 *
	 * @param gift_cost the new gift cost
	 */
	public void setGift_cost(String gift_cost) {

		this.gift_cost = gift_cost;
	}

	/**
	 * Gets the launch date.
	 *
	 * @return the launch date
	 */
	public String getLaunch_date() {

		return launch_date;
	}

	/**
	 * Sets the launch date.
	 *
	 * @param launch_date the new launch date
	 */
	public void setLaunch_date(String launch_date) {

		this.launch_date = launch_date;
	}

	/**
	 * Gets the promotion id.
	 *
	 * @return the promotion id
	 */
	public String getPromotion_id() {

		return promotion_id;
	}

	/**
	 * Sets the promotion id.
	 *
	 * @param promotion_id the new promotion id
	 */
	public void setPromotion_id(String promotion_id) {

		this.promotion_id = promotion_id;
	}

	/**
	 * Gets the promotion url.
	 *
	 * @return the promotion url
	 */
	public String getPromotion_url() {

		return promotion_url;
	}

	/**
	 * Sets the promotion url.
	 *
	 * @param promotion_url the new promotion url
	 */
	public void setPromotion_url(String promotion_url) {

		this.promotion_url = promotion_url;
	}

	/**
	 * Gets the service fee.
	 *
	 * @return the service fee
	 */
	public String getService_fee() {

		return service_fee;
	}

	/**
	 * Sets the service fee.
	 *
	 * @param service_fee the new service fee
	 */
	public void setService_fee(String service_fee) {

		this.service_fee = service_fee;
	}

	/**
	 * Gets the show marketing.
	 *
	 * @return the show marketing
	 */
	public int getShow_marketing() {

		return show_marketing;
	}

	/**
	 * Sets the show marketing.
	 *
	 * @param show_marketing the new show marketing
	 */
	public void setShow_marketing(int show_marketing) {

		this.show_marketing = show_marketing;
	}

	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public String getStart_date() {

		return start_date;
	}

	/**
	 * Sets the start date.
	 *
	 * @param start_date the new start date
	 */
	public void setStart_date(String start_date) {

		this.start_date = start_date;
	}

}

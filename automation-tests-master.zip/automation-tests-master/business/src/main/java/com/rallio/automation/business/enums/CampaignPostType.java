package com.rallio.automation.business.enums;

public enum CampaignPostType {

	CREATE_POST,
	
	ADD_POST;
	
}

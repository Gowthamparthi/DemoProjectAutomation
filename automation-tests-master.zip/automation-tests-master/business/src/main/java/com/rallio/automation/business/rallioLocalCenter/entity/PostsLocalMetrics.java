package com.rallio.automation.business.rallioLocalCenter.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class PostsLocalMetrics.
 */
public class PostsLocalMetrics {

	/** The scheduled posts count. */
	private int scheduled_posts_count;

	/** The goal count. */
	private int goal_count;

	/** The left to create count. */
	private int left_to_create_count;

	/** The published posts count. */
	private int published_posts_count;

	/** The unpublished posts count. */
	private int unpublished_posts_count;

	/**
	 * Gets the scheduled posts count.
	 *
	 * @return the scheduled posts count
	 */
	public int getScheduled_posts_count() {

		return scheduled_posts_count;
	}

	/**
	 * Sets the scheduled posts count.
	 *
	 * @param scheduled_posts_count the new scheduled posts count
	 */
	public void setScheduled_posts_count(int scheduled_posts_count) {

		this.scheduled_posts_count = scheduled_posts_count;
	}

	/**
	 * Gets the goal count.
	 *
	 * @return the goal count
	 */
	public int getGoal_count() {

		return goal_count;
	}

	/**
	 * Sets the goal count.
	 *
	 * @param goal_count the new goal count
	 */
	public void setGoal_count(int goal_count) {

		this.goal_count = goal_count;
	}

	/**
	 * Gets the left to create count.
	 *
	 * @return the left to create count
	 */
	public int getLeft_to_create_count() {

		return left_to_create_count;
	}

	/**
	 * Sets the left to create count.
	 *
	 * @param left_to_create_count the new left to create count
	 */
	public void setLeft_to_create_count(int left_to_create_count) {

		this.left_to_create_count = left_to_create_count;
	}

	/**
	 * Gets the published posts count.
	 *
	 * @return the published posts count
	 */
	public int getPublished_posts_count() {

		return published_posts_count;
	}

	/**
	 * Sets the published posts count.
	 *
	 * @param published_posts_count the new published posts count
	 */
	public void setPublished_posts_count(int published_posts_count) {

		this.published_posts_count = published_posts_count;
	}

	/**
	 * Gets the unpublished posts count.
	 *
	 * @return the unpublished posts count
	 */
	public int getUnpublished_posts_count() {

		return unpublished_posts_count;
	}

	/**
	 * Sets the unpublished posts count.
	 *
	 * @param unpublished_posts_count the new unpublished posts count
	 */
	public void setUnpublished_posts_count(int unpublished_posts_count) {

		this.unpublished_posts_count = unpublished_posts_count;
	}

}

package com.rallio.automation.business.rallioLocalCenter.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class CalendarRequestsDetails.
 */
public class CalendarRequestsDetails {

	/** The calendar events. */
	private String calendar_events;

	/** The calendar events local metrics. */
	private CalendarEventsLocalMetrics calendar_events_local_metrics;

	/**
	 * Gets the calendar events.
	 *
	 * @return the calendar events
	 */
	public String getCalendar_events() {

		return calendar_events;
	}

	/**
	 * Sets the calendar events.
	 *
	 * @param calendar_events the new calendar events
	 */
	public void setCalendar_events(String calendar_events) {

		this.calendar_events = calendar_events;
	}

	/**
	 * Gets the calendar events local metrics.
	 *
	 * @return the calendar events local metrics
	 */
	public CalendarEventsLocalMetrics getCalendar_events_local_metrics() {

		return calendar_events_local_metrics;
	}

	/**
	 * Sets the calendar events local metrics.
	 *
	 * @param calendar_events_local_metrics the new calendar events local
	 *            metrics
	 */
	public void setCalendar_events_local_metrics(CalendarEventsLocalMetrics calendar_events_local_metrics) {

		this.calendar_events_local_metrics = calendar_events_local_metrics;
	}
}

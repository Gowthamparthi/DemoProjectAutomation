package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class TotalMetrics.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class TotalMetrics {

	/** The users count. */
	private int users_count;

	/**
	 * Gets the users count.
	 *
	 * @return the users count
	 */
	public int getUsers_count() {

		return users_count;
	}

	/**
	 * Sets the users count.
	 *
	 * @param users_count the new users count
	 */
	public void setUsers_count(int users_count) {

		this.users_count = users_count;
	}

	/** The assets stats. */
	private AssetsStats assets_stats;

	/**
	 * Gets the assets stats.
	 *
	 * @return the assets stats
	 */
	public AssetsStats getAssets_stats() {

		return assets_stats;
	}

	/**
	 * Sets the assets stats.
	 *
	 * @param assets_stats the new assets stats
	 */
	public void setAssets_stats(AssetsStats assets_stats) {

		this.assets_stats = assets_stats;
	}

}

package com.rallio.automation.business.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum AccountType.
 */
public enum AccountType {

	/** The franchisor. */
	FRANCHISOR,

	/** The location. */
	LOCATION
}

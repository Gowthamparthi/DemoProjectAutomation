package com.rallio.automation.business.rallioLocalCenter.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class CalendarEventsLocalMetrics.
 */
public class CalendarEventsLocalMetrics {

	/** The remaining events count. */
	private int remaining_events_count;

	/** The remaining posts count. */
	private int remaining_posts_count;
	
	/** The remaining promotions count. */
	private int remaining_promotions_count;

	/** The total calendar events count. */
	private int total_calendar_events_count;


	/**
	 * Gets the remaining events count.
	 *
	 * @return the remaining events count
	 */
	public int getRemaining_events_count() {

		return remaining_events_count;
	}

	/**
	 * Sets the remaining events count.
	 *
	 * @param remaining_events_count the new remaining events count
	 */
	public void setRemaining_events_count(int remaining_events_count) {

		this.remaining_events_count = remaining_events_count;
	}

	/**
	 * Gets the remaining posts count.
	 *
	 * @return the remaining posts count
	 */
	public int getRemaining_posts_count() {

		return remaining_posts_count;
	}

	/**
	 * Sets the remaining posts count.
	 *
	 * @param remaining_posts_count the new remaining posts count
	 */
	public void setRemaining_posts_count(int remaining_posts_count) {

		this.remaining_posts_count = remaining_posts_count;
	}

	/**
	 * Gets the remaining promotions count.
	 *
	 * @return the remaining promotions count
	 */
	public int getRemaining_promotions_count() {

		return remaining_promotions_count;
	}

	/**
	 * Sets the remaining promotions count.
	 *
	 * @param remaining_promotions_count the new remaining promotions count
	 */
	public void setRemaining_promotions_count(int remaining_promotions_count) {

		this.remaining_promotions_count = remaining_promotions_count;
	}

	/**
	 * Gets the total calendar events count.
	 *
	 * @return the total calendar events count
	 */
	public int getTotal_calendar_events_count() {

		return total_calendar_events_count;
	}

	/**
	 * Sets the total calendar events count.
	 *
	 * @param total_calendar_events_count the new total calendar events count
	 */
	public void setTotal_calendar_events_count(int total_calendar_events_count) {

		this.total_calendar_events_count = total_calendar_events_count;
	}


}

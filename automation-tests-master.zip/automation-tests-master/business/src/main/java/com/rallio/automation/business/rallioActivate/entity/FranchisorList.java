package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class FranchisorList.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class FranchisorList {

	/** The id. */
	private int id;

	/** The name. */
	private String name;

	/** The owner franchisor id. */
	private String owner_franchisor_id;

	/** The single franchisor id. */
	private String single_franchisor_id;

	/** The single franchisor name. */
	private String single_franchisor_name;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {

		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {

		this.name = name;
	}

	/**
	 * Gets the owner franchisor id.
	 *
	 * @return the owner franchisor id
	 */
	public String getOwner_franchisor_id() {

		return owner_franchisor_id;
	}

	/**
	 * Sets the owner franchisor id.
	 *
	 * @param owner_franchisor_id the new owner franchisor id
	 */
	public void setOwner_franchisor_id(String owner_franchisor_id) {

		this.owner_franchisor_id = owner_franchisor_id;
	}

	/**
	 * Gets the single franchisor id.
	 *
	 * @return the single franchisor id
	 */
	public String getSingle_franchisor_id() {

		return single_franchisor_id;
	}

	/**
	 * Sets the single franchisor id.
	 *
	 * @param single_franchisor_id the new single franchisor id
	 */
	public void setSingle_franchisor_id(String single_franchisor_id) {

		this.single_franchisor_id = single_franchisor_id;
	}

	/**
	 * Gets the single franchisor name.
	 *
	 * @return the single franchisor name
	 */
	public String getSingle_franchisor_name() {

		return single_franchisor_name;
	}

	/**
	 * Sets the single franchisor name.
	 *
	 * @param single_franchisor_name the new single franchisor name
	 */
	public void setSingle_franchisor_name(String single_franchisor_name) {

		this.single_franchisor_name = single_franchisor_name;
	}

}

package com.rallio.automation.business.rallioActivate.entity;

import com.rallio.automation.common.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class ProgramLocations.
 */
public class ProgramLocations {

	/**
	 * Gets the location.
	 *
	 * @return the location
	 */
	public String getLocation() {

		return location;
	}

	/**
	 * Sets the location.
	 *
	 * @param location the new location
	 */
	public void setLocation(String location) {

		this.location = location;
	}

	/** The location. */
	private String location;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return ConvertPojoToHtml.convert(this);
	}

}

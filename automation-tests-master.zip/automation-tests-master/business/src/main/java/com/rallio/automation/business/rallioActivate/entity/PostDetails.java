package com.rallio.automation.business.rallioActivate.entity;

import com.rallio.automation.business.enums.*;
import com.rallio.automation.common.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class PostDetails.
 */
public class PostDetails {

	/** The post name. */
	private String postName;

	/** The author. */
	private String author;

	/** The created date. */
	private String createdDate;

	/** The updated date. */
	private String updatedDate;

	/** The location. */
	private String location;

	/** The post type. */
	private PostType postType;

	/** The has media. */
	private boolean mediaPresent;

	
	/**
	 * Checks if is media present.
	 *
	 * @return true, if is media present
	 */
	public boolean isMediaPresent() {

		return mediaPresent;
	}

	/**
	 * Sets the media present.
	 *
	 * @param mediaPresent the new media present
	 */
	public void setMediaPresent(boolean mediaPresent) {

		this.mediaPresent = mediaPresent;
	}

	/**
	 * Gets the author.
	 *
	 * @return the author
	 */
	public String getAuthor() {

		return author;
	}

	/**
	 * Sets the author.
	 *
	 * @param author the new author
	 */
	public void setAuthor(String author) {

		this.author = author;
	}

	/**
	 * Gets the created date.
	 *
	 * @return the created date
	 */
	public String getCreatedDate() {

		return createdDate;
	}

	/**
	 * Sets the created date.
	 *
	 * @param createdDate the new created date
	 */
	public void setCreatedDate(String createdDate) {

		this.createdDate = createdDate;
	}

	/**
	 * Gets the updated date.
	 *
	 * @return the updated date
	 */
	public String getUpdatedDate() {

		return updatedDate;
	}

	/**
	 * Sets the updated date.
	 *
	 * @param updatedDate the new updated date
	 */
	public void setUpdatedDate(String updatedDate) {

		this.updatedDate = updatedDate;
	}

	/**
	 * Gets the location.
	 *
	 * @return the location
	 */
	public String getLocation() {

		return location;
	}

	/**
	 * Sets the location.
	 *
	 * @param location the new location
	 */
	public void setLocation(String location) {

		this.location = location;
	}

	/**
	 * Gets the post type.
	 *
	 * @return the post type
	 */
	public PostType getPostType() {

		return postType;
	}

	/**
	 * Sets the post type.
	 *
	 * @param postType the new post type
	 */
	public void setPostType(PostType postType) {

		this.postType = postType;
	}

	/**
	 * Sets the post name.
	 *
	 * @param postName the new post name
	 */
	public void setPostName(String postName) {

		this.postName = postName;
	}

	/**
	 * Gets the post name.
	 *
	 * @return the post name
	 */
	public String getPostName() {

		return postName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return ConvertPojoToHtml.convert(this);
	}
}

package com.rallio.automation.business.rallioLocalCenter.entity;


public class Slots {

	/** The end. */
	private String end;

	/** The start. */
	private String start;

	/**
	 * Gets the end.
	 *
	 * @return the end
	 */
	public String getEnd() {

		return end;
	}

	/**
	 * Sets the end.
	 *
	 * @param end the new end
	 */
	public void setEnd(String end) {

		this.end = end;
	}

	/**
	 * Gets the start.
	 *
	 * @return the start
	 */
	public String getStart() {

		return start;
	}

	/**
	 * Sets the start.
	 *
	 * @param start the new start
	 */
	public void setStart(String start) {

		this.start = start;
	}
}

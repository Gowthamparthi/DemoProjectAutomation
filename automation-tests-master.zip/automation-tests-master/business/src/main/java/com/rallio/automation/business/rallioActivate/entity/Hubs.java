package com.rallio.automation.business.rallioActivate.entity;


public class Hubs {

}

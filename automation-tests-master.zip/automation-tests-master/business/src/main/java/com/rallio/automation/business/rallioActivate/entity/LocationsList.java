package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;
import com.rallio.automation.common.util.*;

// TODO: Auto-generated Javadoc
/**
 * The Class LocationsList.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class LocationsList {

	/** The id. */
	private int id;

	/** The name. */
	private String name;

	/** The franchisor. */
	private Franchisors franchisor;

	/** The brand. */
	private Brand brand;

	/** The address. */
	private String address;

	/** The latitude. */
	private String latitude;

	/** The longitude. */
	private String longitude;

	/** The time_zone. */
	private String time_zone;


	/**
	 * Gets the franchisor.
	 *
	 * @return the franchisor
	 */
	public Franchisors getFranchisor() {

		return franchisor;
	}

	/**
	 * Sets the franchisor.
	 *
	 * @param franchisor the new franchisor
	 */
	public void setFranchisor(Franchisors franchisor) {

		this.franchisor = franchisor;
	}

	/**
	 * Gets the time zone.
	 *
	 * @return the time zone
	 */
	public String getTime_zone() {

		return time_zone;
	}

	/**
	 * Sets the time zone.
	 *
	 * @param time_zone the new time zone
	 */
	public void setTime_zone(String time_zone) {

		this.time_zone = time_zone;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {

		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {

		this.name = name;
	}

	/**
	 * Gets the brand.
	 *
	 * @return the brand
	 */
	public Brand getBrand() {

		return brand;
	}

	/**
	 * Sets the brand.
	 *
	 * @param brand the new brand
	 */
	public void setBrand(Brand brand) {

		this.brand = brand;
	}

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public String getAddress() {

		return address;
	}

	/**
	 * Sets the address.
	 *
	 * @param address the new address
	 */
	public void setAddress(String address) {

		this.address = address;
	}

	/**
	 * Gets the latitude.
	 *
	 * @return the latitude
	 */
	public String getLatitude() {

		return latitude;
	}

	/**
	 * Sets the latitude.
	 *
	 * @param latitude the new latitude
	 */
	public void setLatitude(String latitude) {

		this.latitude = latitude;
	}

	/**
	 * Gets the longitude.
	 *
	 * @return the longitude
	 */
	public String getLongitude() {

		return longitude;
	}

	/**
	 * Sets the longitude.
	 *
	 * @param longitude the new longitude
	 */
	public void setLongitude(String longitude) {

		this.longitude = longitude;
	}

	/**
	 * Gets the time zone.
	 *
	 * @return the time zone
	 */
	public String getTimeZone() {

		return time_zone;
	}

	/**
	 * Sets the time zone.
	 *
	 * @param time_zone the new time zone
	 */
	public void setTimeZone(String time_zone) {

		this.time_zone = time_zone;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return ConvertPojoToHtml.convert(this);
	}
}

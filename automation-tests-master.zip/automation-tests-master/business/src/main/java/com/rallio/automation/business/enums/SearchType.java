package com.rallio.automation.business.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum SearchType.
 */
public enum SearchType {

	/** The valid search. */
	VALID_SEARCH,

	/** The invalid search. */
	INVALID_SEARCH;
}

package com.rallio.automation.business.rallioWebApp.entity;

public class UserAccount {

}

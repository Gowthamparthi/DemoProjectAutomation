package com.rallio.automation.business.rallioActivate.entity;

import com.fasterxml.jackson.annotation.*;

// TODO: Auto-generated Javadoc
/**
 * The Class CurrentAccountorFranchisor.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class CurrentAccountorFranchisor {

	/** The id. */
	private int id;

	/** The name. */
	private String name;

	/** The child present. */
	private boolean child_present;

	/** The child count. */
	private int child_count;

	/** The logo url. */
	private String logo_url;

	/** The logo thumbnail url. */
	private String logo_thumbnail_url;

	/** The latitude. */
	private String latitude;

	/** The longitude. */
	private String longitude;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {

		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {

		this.id = id;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {

		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {

		this.name = name;
	}

	/**
	 * Checks if is child present.
	 *
	 * @return true, if is child present
	 */
	public boolean isChild_present() {

		return child_present;
	}

	/**
	 * Sets the child present.
	 *
	 * @param child_present the new child present
	 */
	public void setChild_present(boolean child_present) {

		this.child_present = child_present;
	}

	/**
	 * Gets the child count.
	 *
	 * @return the child count
	 */
	public int getChild_count() {

		return child_count;
	}

	/**
	 * Sets the child count.
	 *
	 * @param child_count the new child count
	 */
	public void setChild_count(int child_count) {

		this.child_count = child_count;
	}

	/**
	 * Gets the logo url.
	 *
	 * @return the logo url
	 */
	public String getLogo_url() {

		return logo_url;
	}

	/**
	 * Sets the logo url.
	 *
	 * @param logo_url the new logo url
	 */
	public void setLogo_url(String logo_url) {

		this.logo_url = logo_url;
	}

	/**
	 * Gets the logo thumbnail url.
	 *
	 * @return the logo thumbnail url
	 */
	public String getLogo_thumbnail_url() {

		return logo_thumbnail_url;
	}

	/**
	 * Sets the logo thumbnail url.
	 *
	 * @param logo_thumbnail_url the new logo thumbnail url
	 */
	public void setLogo_thumbnail_url(String logo_thumbnail_url) {

		this.logo_thumbnail_url = logo_thumbnail_url;
	}

	/**
	 * Gets the latitude.
	 *
	 * @return the latitude
	 */
	public String getLatitude() {

		return latitude;
	}

	/**
	 * Sets the latitude.
	 *
	 * @param latitude the new latitude
	 */
	public void setLatitude(String latitude) {

		this.latitude = latitude;
	}

	/**
	 * Gets the longitude.
	 *
	 * @return the longitude
	 */
	public String getLongitude() {

		return longitude;
	}

	/**
	 * Sets the longitude.
	 *
	 * @param longitude the new longitude
	 */
	public void setLongitude(String longitude) {

		this.longitude = longitude;
	}

}
